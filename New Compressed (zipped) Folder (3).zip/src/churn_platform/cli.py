"""Command-line interface: ``churn-platform <command>`` (or ``python -m churn_platform``)."""

from __future__ import annotations

import argparse
import getpass
import json
import os
import secrets
import sys
from datetime import date
from typing import Any

from . import __version__


def _password(args: argparse.Namespace, *, generate: bool = False) -> tuple[str, bool]:
    """Password from --password-env (name of an environment variable), a prompt, or generated."""
    if getattr(args, "password_env", None):
        value = os.environ.get(args.password_env)
        if not value:
            raise SystemExit(f"environment variable {args.password_env} is empty or not set")
        return value, False
    if generate:
        return secrets.token_urlsafe(12) + "-A1a", True
    if not sys.stdin.isatty():
        raise SystemExit("no password given: use --password-env VAR (the value is read from that environment variable)")
    try:
        first = getpass.getpass("Password: ")
        second = getpass.getpass("Repeat password: ")
    except (KeyboardInterrupt, EOFError) as stop:
        # Ctrl-C or Ctrl-D at the prompt.  getpass has switched the terminal's echo back on; the cursor still stands
        # behind the prompt, hence the line break.  No traceback: nothing went wrong, the operator changed their mind.
        print("\ncancelled: no password was entered, nothing was changed", file=sys.stderr)
        raise SystemExit(130 if isinstance(stop, KeyboardInterrupt) else 1) from None
    if first != second:
        raise SystemExit("passwords do not match")
    return first, False


def _print(data: Any) -> None:
    print(json.dumps(data, indent=2, default=str))


def cmd_migrate(args: argparse.Namespace) -> int:
    from . import dbadmin

    dbadmin.upgrade(args.revision)
    _print(dbadmin.status())
    return 0


def cmd_downgrade(args: argparse.Namespace) -> int:
    from . import dbadmin

    dbadmin.downgrade(args.revision)
    _print(dbadmin.status())
    return 0


def cmd_db_status(_args: argparse.Namespace) -> int:
    from . import dbadmin

    status = dbadmin.status()
    drift = [str(d)[:300] for d in dbadmin.schema_drift()] if status["current"] else ["database is not migrated"]
    _print({**status, "schema_drift": drift})
    return 0 if status["up_to_date"] and not drift else 1


def cmd_create_tenant(args: argparse.Namespace) -> int:
    from .db import session_scope
    from .services import auth

    with session_scope() as s:
        tenant = auth.create_tenant(s, args.slug, args.name or args.slug)
        _print({"tenant_id": tenant.id, "slug": tenant.slug, "name": tenant.name})
    return 0


def cmd_create_user(args: argparse.Namespace) -> int:
    from sqlalchemy import select

    from .db import session_scope
    from .models import Tenant
    from .services import auth

    with session_scope() as s:  # before the prompt: nobody should type a password twice to learn that the tenant is missing
        if s.execute(select(Tenant.id).where(Tenant.slug == args.tenant)).first() is None:
            raise SystemExit(f"tenant '{args.tenant}' does not exist (create it with create-tenant)")
    password, _ = _password(args)
    with session_scope() as s:
        tenant = s.execute(select(Tenant).where(Tenant.slug == args.tenant)).scalar_one()
        user = auth.create_user(s, tenant_id=tenant.id, email=args.email, full_name=args.name or args.email, role=args.role, password=password)
        _print({"user_id": user.id, "email": user.email, "role": user.role, "tenant": tenant.slug})
    return 0


def cmd_worker(args: argparse.Namespace) -> int:
    from .config import get_settings
    from .logging_setup import configure_logging
    from .worker.runner import Worker

    settings = get_settings()
    configure_logging(settings.log_level, settings.log_json)
    worker = Worker(settings)
    if args.once:
        worker.maintenance()
        _print({"processed": worker.drain(), "progress_skipped": worker.progress_skipped})
        return 0
    worker.run_forever()
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    import signal

    import uvicorn

    from .config import get_settings

    if args.forwarded_allow_ips is not None:
        # The 1.0 option gave the HTTP server a list of its own.  One list decides now, for every part of the application.
        print("error: --forwarded-allow-ips was replaced by the setting CHURN_TRUSTED_PROXIES in 1.1.0. Put the addresses or CIDR "
              "ranges of your reverse proxies there (comma-separated) and remove the option.", file=sys.stderr)  # fmt: skip
        return 2

    def exit_cleanly(*_: object) -> None:
        raise SystemExit(0)

    # uvicorn shuts down gracefully on SIGTERM and then re-delivers the signal to the handler that was installed before
    # it started.  With Python's default handler the process would be reported as killed (exit 143) after a clean
    # shutdown; with this one it exits 0, like the worker command.  A SIGTERM that arrives before uvicorn listens for
    # signals also ends the process at once.
    signal.signal(signal.SIGTERM, exit_cleanly)
    settings = get_settings()
    # log_config=None: uvicorn keeps its hands off the logging configuration, so its messages go through the same
    # (JSON) handler as the application's and a log pipeline sees a single format.
    # proxy_headers=False: the HTTP server must not rewrite the client address or the scheme from forwarded headers.
    # The application decides that itself, for peers listed in CHURN_TRUSTED_PROXIES and for nobody else (netpolicy).
    # uvicorn's own handling trusts 127.0.0.1 unless told otherwise: with it switched on, any client on this machine
    # could choose its address and claim HTTPS whatever CHURN_TRUSTED_PROXIES said (DEF-082).
    uvicorn.run("churn_platform.api.app:create_app", factory=True, host=args.host, port=args.port, workers=args.workers,
                log_level=settings.log_level.lower(), log_config=None, access_log=False, proxy_headers=False, server_header=False)  # fmt: skip
    return 0


def cmd_seed_demo(args: argparse.Namespace) -> int:
    from . import dbadmin
    from .services import demo

    if not dbadmin.status()["up_to_date"]:
        dbadmin.upgrade("head")
    password, generated = _password(args, generate=True)
    end = date.fromisoformat(args.end_date) if args.end_date else None
    try:
        summary = demo.seed_demo(slug=args.slug, password=password, customers=args.customers, months=args.months, seed=args.seed,
                                 end_date=end, n_iter=args.n_iter, log=lambda message: print(f"  {message}", file=sys.stderr))  # fmt: skip
    except demo.DemoError as exc:
        raise SystemExit(str(exc)) from exc
    out = {k: summary[k] for k in ("tenant", "synthetic", "users", "model", "batch", "recommendations", "experiment")}
    if generated:
        out["generated_password"] = password
        out["note"] = "Every demo user shares this generated password. It is shown once; SYNTHETIC data only."
    _print(out)
    return 0


def cmd_nightly(args: argparse.Namespace) -> int:
    """Queue the nightly pipeline for a tenant (for cron / Airflow); ``--wait`` also runs it here."""
    from sqlalchemy import select

    from .db import read_session, session_scope
    from .models import Job, Tenant
    from .services import demo, pipeline
    from .worker.runner import Worker

    with session_scope() as s:
        tenant = s.execute(select(Tenant).where(Tenant.slug == args.tenant)).scalar_one_or_none()
        if tenant is None:
            raise SystemExit(f"tenant '{args.tenant}' does not exist")
        tenant_id = tenant.id
        job, started = pipeline.start(s, demo.system_principal(s, tenant_id))
        job_id = job.id
    if not args.wait:
        _print({"queued_job_id": job_id, "already_running": not started})
        return 0
    Worker().drain()
    with read_session() as s:
        failed = s.execute(select(Job.id, Job.job_type, Job.error).where(Job.tenant_id == tenant_id, Job.id >= job_id, Job.status == "failed")).all()
        runs = pipeline.last_runs(s, tenant_id, limit=1)
    if failed:
        _print({"status": "failed", "failed_jobs": [{"id": i, "type": t, "error": (e or "")[:400]} for i, t, e in failed]})
        return 1
    _print({"status": "completed", "steps": (runs[0].get("result") or {}).get("steps") if runs else None})
    return 0


def _tenant_id(slug: str) -> int:
    from sqlalchemy import select

    from .db import read_session
    from .models import Tenant

    with read_session() as s:
        tenant_id = s.execute(select(Tenant.id).where(Tenant.slug == slug)).scalar_one_or_none()
    if tenant_id is None:
        raise SystemExit(f"tenant '{slug}' does not exist")
    return tenant_id


def cmd_pipeline_step(args: argparse.Namespace) -> int:
    """Run one pipeline step for an external orchestrator; idempotent per (tenant, step, run key).
    Exit 0: the step succeeded (now or earlier).  Exit 1: it failed.  Exit 3: still running (without --wait, or timed out)."""
    from .services import orchestration

    result = orchestration.run_step(_tenant_id(args.tenant), args.step, args.run_key, wait=args.wait, inline=args.inline,
                                    timeout_seconds=args.timeout, orchestrator=args.orchestrator, dag_id=args.dag_id,
                                    dag_run_id=args.dag_run_id or args.run_key, task_id=args.task_id, force=args.force)  # fmt: skip
    run = result["run"]
    _print({"action": result["action"], "status": run["status"], "step": run["step"], "run_key": run["run_key"], "attempts": run["attempts"],
            "job_ids": run["job_ids"], "as_of_date": run["as_of_date"], "error": run["error"], "timed_out": result.get("timed_out", False)})  # fmt: skip
    if run["status"] in ("succeeded", "skipped"):
        return 0
    return 1 if run["status"] == "failed" else 3


def cmd_sentiment_model(args: argparse.Namespace) -> int:
    """Fetch, verify or describe the local sentiment model (the only command that downloads anything)."""
    from .services import sentiment

    if args.action == "fetch":
        print(f"Fetching '{args.model}' (pinned revision, every file verified against its SHA-256) ...")
        result = sentiment.fetch_model(args.model)
        _print({k: result[k] for k in ("directory", "model_id", "revision", "license", "source")})
        return 0
    if args.action == "verify":
        problems = sentiment.verify_directory(sentiment.model_directory(args.model), args.model)
        _print({"directory": str(sentiment.model_directory(args.model)), "verified": not problems, "problems": problems})
        return 1 if problems else 0
    info, fallback, problem = sentiment.describe_provider()
    _print({"configured": sentiment.get_settings().sentiment_provider, "problem": problem, "fallback_reason": fallback,
            "provider": None if info is None else {"provider": info.provider, "model_id": info.model_id, "model_version": info.model_version,
                                                   "checksum_sha256": info.checksum_sha256, "is_baseline": info.is_baseline,
                                                   "languages": list(info.languages)},
            "runtime_problem": sentiment.runtime_problem(), "model_directory": str(sentiment.model_directory())})  # fmt: skip
    return 1 if problem else 0


def cmd_verify_audit(args: argparse.Namespace) -> int:
    from sqlalchemy import select

    from .db import read_session
    from .models import Tenant
    from .services import audit

    with read_session() as s:
        tenant = s.execute(select(Tenant).where(Tenant.slug == args.tenant)).scalar_one_or_none()
        if tenant is None:
            raise SystemExit(f"tenant '{args.tenant}' does not exist")
        result = audit.verify_chain(s, tenant.id)
    _print(result)
    return 0 if result["valid"] else 1


def cmd_backup(args: argparse.Namespace) -> int:
    from . import backup as backup_module

    manifest = backup_module.backup(args.to, data_dir=args.data_dir, note=args.note)
    _print({"archive": manifest["archive"], "members": len(manifest["members"]), "revision": manifest["revision"],
            "engine": manifest["engine"]})
    return 0


def cmd_restore(args: argparse.Namespace) -> int:
    from . import backup as backup_module

    result = backup_module.restore(args.source, data_dir=args.data_dir, force=args.force)
    _print(result)
    return 0 if result["revision_matches"] else 1


def cmd_backup_check(args: argparse.Namespace) -> int:
    from . import backup as backup_module

    report = backup_module.inspect(args.source)
    _print({"archive": report["archive"], "valid": report["valid"], "problems": report["problems"],
            "revision": report["manifest"].get("revision"), "created_at": report["manifest"].get("created_at")})
    return 0 if report["valid"] else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="churn-platform", description="Customer churn prediction and retention platform")
    parser.add_argument("--version", action="version", version=f"churn-platform {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("migrate", help="apply database migrations")
    p.add_argument("--revision", default="head")
    p.set_defaults(func=cmd_migrate)
    p = sub.add_parser("downgrade", help="revert database migrations to a revision ('base' removes everything)")
    p.add_argument("revision")
    p.set_defaults(func=cmd_downgrade)
    sub.add_parser("db-status", help="migration revision and schema drift (exit 1 when not in sync)").set_defaults(func=cmd_db_status)

    p = sub.add_parser("create-tenant", help="create a tenant")
    p.add_argument("--slug", required=True)
    p.add_argument("--name")
    p.set_defaults(func=cmd_create_tenant)
    p = sub.add_parser("create-user", help="create a user (password via prompt or --password-env)")
    p.add_argument("--tenant", required=True)
    p.add_argument("--email", required=True)
    p.add_argument("--name")
    p.add_argument("--role", default="admin")
    p.add_argument("--password-env", metavar="VAR", help="name of the environment variable holding the password")
    p.set_defaults(func=cmd_create_user)

    p = sub.add_parser("worker", help="run the background job worker")
    p.add_argument("--once", action="store_true", help="process the queue until it is empty, then exit")
    p.set_defaults(func=cmd_worker)
    p = sub.add_parser("serve", help="run the HTTP API and web application")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--workers", type=int, default=1)
    p.add_argument("--forwarded-allow-ips", default=None, help=argparse.SUPPRESS)  # 1.0 option: refused with a pointer to CHURN_TRUSTED_PROXIES
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("seed-demo", help="create a tenant filled with SYNTHETIC data and run the whole lifecycle")
    p.add_argument("--slug", default="demo")
    p.add_argument("--customers", type=int, default=1200)
    p.add_argument("--months", type=int, default=15)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--end-date", help="last day of synthetic history (YYYY-MM-DD; default: yesterday)")
    p.add_argument("--n-iter", type=int, default=6, help="hyper-parameter candidates per algorithm")
    p.add_argument("--password-env", metavar="VAR", help="environment variable holding the password for all demo users")
    p.set_defaults(func=cmd_seed_demo)

    p = sub.add_parser("nightly", help="queue the nightly pipeline for a tenant")
    p.add_argument("--tenant", required=True)
    p.add_argument("--wait", action="store_true", help="run the queued jobs in this process and report the outcome")
    p.set_defaults(func=cmd_nightly)
    p = sub.add_parser("pipeline-step", help="run one nightly-pipeline step for an external orchestrator (idempotent per run key)")
    p.add_argument("--tenant", required=True)
    p.add_argument("--step", required=True, help="data_quality | signals | labels | features | scoring | recommendations | monitoring")
    p.add_argument("--run-key", required=True, help="identifies the orchestrator's run (use the DAG run id); the same key never runs a step twice")
    p.add_argument("--orchestrator", default="airflow", choices=["airflow", "operator"])
    p.add_argument("--dag-id")
    p.add_argument("--dag-run-id")
    p.add_argument("--task-id")
    p.add_argument("--wait", action="store_true", help="follow the step to its end (exit 0 succeeded, 1 failed, 3 still running)")
    p.add_argument("--inline", action="store_true", help="also execute the queued jobs in this process (no separate worker)")
    p.add_argument("--timeout", type=float, default=7200.0, help="seconds to wait with --wait")
    p.add_argument("--force", action="store_true", help="run although CHURN_ORCHESTRATOR is not 'airflow' (one-off operator runs)")
    p.set_defaults(func=cmd_pipeline_step)
    p = sub.add_parser("sentiment-model", help="fetch, verify or describe the local sentiment model")
    p.add_argument("action", choices=["fetch", "verify", "status"])
    p.add_argument("--model", default="nlptown-multilingual", help="nlptown-multilingual (default) | distilbert-student-multilingual")
    p.set_defaults(func=cmd_sentiment_model)
    p = sub.add_parser("backup", help="write a checksummed archive of the database and data directory")
    p.add_argument("--to", required=True, help="archive to write (e.g. backup-2026-11-12.tar.gz)")
    p.add_argument("--data-dir", default=None, help="data directory (default: CHURN_DATA_DIR)")
    p.add_argument("--note", default=None, help="why this backup was taken")
    p.set_defaults(func=cmd_backup)

    p = sub.add_parser("restore", help="restore an archive after checking every checksum, then verify the database")
    p.add_argument("--from", dest="source", required=True, help="archive to restore")
    p.add_argument("--data-dir", default=None, help="where to put the restored data directory")
    p.add_argument("--force", action="store_true", help="replace an existing database and data directory")
    p.set_defaults(func=cmd_restore)

    p = sub.add_parser("backup-check", help="check an archive against its manifest without restoring it")
    p.add_argument("--from", dest="source", required=True)
    p.set_defaults(func=cmd_backup_check)

    p = sub.add_parser("verify-audit", help="verify a tenant's audit hash chain (exit 1 when broken)")
    p.add_argument("--tenant", required=True)
    p.set_defaults(func=cmd_verify_audit)
    return parser


def main(argv: list[str] | None = None) -> int:
    from .errors import AppError

    args = build_parser().parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except AppError as exc:
        print(f"error: {exc.message}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:  # Ctrl-C during a one-off command (serve and worker stop on the signal themselves)
        print("interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
