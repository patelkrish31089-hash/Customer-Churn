"""HTTP API (FastAPI).  ``create_app`` builds the application."""

from .app import create_app

__all__ = ["create_app"]
