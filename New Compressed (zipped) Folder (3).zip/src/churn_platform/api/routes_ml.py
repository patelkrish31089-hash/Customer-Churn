"""Modelling and action routes: datasets, training, evaluation, explanations, registry, predictions,
Customer 360, retention, CRM and monitoring."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy import select

from ..errors import NotFound, ValidationFailed
from ..models import (
    Alert,
    CRMConnection,
    CRMDelivery,
    Customer,
    DriftReport,
    Experiment,
    Intervention,
    MLDataset,
    ModelEvaluation,
    ModelRun,
    ModelVersion,
    Prediction,
    PredictionBatch,
    Schedule,
    UpliftModel,
)
from ..security import Principal
from ..services import (
    crm,
    customer360,
    evaluation,
    experiments,
    explain,
    mlprep,
    monitoring,
    pipeline,
    predictions,
    registry,
    retention,
    signals,
    training,
)
from ..services.common import get_owned, paginate, to_dict
from .deps import Body, job_ref, limited, reading, require, writing

router = APIRouter()


# ----------------------------------------------------------------------------- datasets and training
class DatasetBody(Body):
    name: str = Field(min_length=1, max_length=120)
    contract_id: int
    policy_id: int | None = None
    valid_dates: int = Field(2, ge=1, le=24)
    test_dates: int = Field(2, ge=1, le=24)
    embargo_days: int = Field(0, ge=0, le=365)
    target: str = "all"


class TrainBody(Body):
    dataset_id: int
    algorithms: list[str] | None = None
    imbalance: str = "auto"
    n_iter: int = Field(6, ge=1, le=40)
    cv_folds: int = Field(3, ge=2, le=6)
    seed: int = Field(42, ge=0, le=2**31 - 1)


class EvaluateBody(Body):
    split: str = "valid"
    cost_policy_id: int | None = None


@router.get("/ml/datasets", tags=["ml"])
def list_datasets(principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(MLDataset).where(MLDataset.tenant_id == principal.tenant_id).order_by(MLDataset.id.desc())).scalars().all()
        return {"items": [mlprep.dataset_view(d) for d in rows], "total": len(rows)}


@router.post("/ml/datasets", status_code=202, tags=["ml"])
def build_dataset(body: DatasetBody, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        dataset, job = mlprep.start_build(s, principal, name=body.name, contract_id=body.contract_id, policy_id=body.policy_id,
                                          valid_dates=body.valid_dates, test_dates=body.test_dates, embargo_days=body.embargo_days,
                                          target=body.target)  # fmt: skip
        return {"dataset": mlprep.dataset_view(dataset), "job": job_ref(job)}


@router.get("/ml/datasets/{dataset_id}", tags=["ml"])
def get_dataset(dataset_id: int, principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        return mlprep.dataset_view(get_owned(s, MLDataset, principal.tenant_id, dataset_id, label="Dataset"))


@router.get("/ml/algorithms", tags=["ml"])
def algorithms(_: Principal = Depends(require("ml:read"))) -> dict:
    return {"algorithms": training.algorithm_status(), "imbalance_strategies": list(training.IMBALANCE)}


@router.post("/ml/training", status_code=202, tags=["ml"])
def start_training(body: TrainBody, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        runs, job = training.start_training(s, principal, dataset_id=body.dataset_id, algorithms=body.algorithms, imbalance=body.imbalance,
                                            n_iter=body.n_iter, cv_folds=body.cv_folds, seed=body.seed)  # fmt: skip
        return {"runs": [training.run_view(r) for r in runs], "job": job_ref(job)}


@router.get("/ml/runs", tags=["ml"])
def list_runs(dataset_id: int | None = None, principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        items = training.leaderboard(s, principal.tenant_id, dataset_id)
        return {"items": items, "total": len(items),
                "ranking": "validation PR-AUC (the test split is never used for ranking or selection)"}  # fmt: skip


@router.get("/ml/runs/{run_id}", tags=["ml"])
def get_run(run_id: int, principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        run = get_owned(s, ModelRun, principal.tenant_id, run_id, label="Model run")
        out = training.run_view(run, full=True)
        evaluations = s.execute(select(ModelEvaluation).where(ModelEvaluation.model_run_id == run.id).order_by(ModelEvaluation.id)).scalars().all()
        out["evaluations"] = [evaluation.evaluation_view(e) for e in evaluations]
        latest = explain.latest_global(s, principal.tenant_id, run.id)
        out["global_explanation"] = explain.explanation_view(latest) if latest else None
        return out


@router.post("/ml/runs/{run_id}/evaluate", tags=["ml"])
def evaluate_run(run_id: int, body: EvaluateBody | None = None, principal: Principal = Depends(require("ml:train"))) -> dict:
    body = body or EvaluateBody()
    with writing() as s:
        return evaluation.evaluation_view(evaluation.evaluate(s, principal, run_id, split=body.split, cost_policy_id=body.cost_policy_id))


@router.post("/ml/runs/{run_id}/explain", tags=["ml"])
def explain_run(run_id: int, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        return explain.explanation_view(explain.global_explanation(s, principal, run_id))


# ----------------------------------------------------------------------------- registry
class RegisterBody(Body):
    run_id: int
    name: str = Field("churn-model", min_length=1, max_length=120)


class ReviewBody(Body):
    approve: bool
    note: str | None = Field(None, max_length=2000)


class StageBody(Body):
    stage: str


@router.get("/ml/registry", tags=["registry"])
def list_versions(principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(ModelVersion, ModelRun).join(ModelRun, ModelRun.id == ModelVersion.model_run_id)
                         .where(ModelVersion.tenant_id == principal.tenant_id).order_by(ModelVersion.id.desc())).all()  # fmt: skip
        return {"items": [registry.version_view(v, r) for v, r in rows], "total": len(rows)}


@router.post("/ml/registry", status_code=201, tags=["registry"])
def register_version(body: RegisterBody, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        return registry.version_view(registry.register(s, principal, body.run_id, body.name))


@router.post("/ml/registry/{version_id}/review", tags=["registry"])
def review_version(version_id: int, body: ReviewBody, principal: Principal = Depends(require("ml:approve"))) -> dict:
    with writing() as s:
        return registry.version_view(registry.review(s, principal, version_id, approve=body.approve, note=body.note))


@router.post("/ml/registry/{version_id}/stage", tags=["registry"])
def stage_version(version_id: int, body: StageBody, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        return registry.version_view(registry.set_stage(s, principal, version_id, body.stage))


# ----------------------------------------------------------------------------- predictions
class BatchBody(Body):
    as_of_date: str | None = None
    model_version_id: int | None = None


@router.post("/predictions/batches", status_code=202, tags=["predictions"])
def start_batch(body: BatchBody | None = None, principal: Principal = Depends(require("predict:run"))) -> dict:
    body = body or BatchBody()
    with writing() as s:
        batch, job = predictions.start_batch(s, principal, tenant_id=principal.tenant_id, model_version_id=body.model_version_id,
                                             as_of_date=body.as_of_date)  # fmt: skip
        return {"batch": to_dict(batch), "job": job_ref(job), "already_exists": job is None}


@router.get("/predictions/batches", tags=["predictions"])
def list_batches(page: int = 1, page_size: int = 20, principal: Principal = Depends(require("predict:read"))) -> dict:
    with reading() as s:
        stmt = select(PredictionBatch).where(PredictionBatch.tenant_id == principal.tenant_id, PredictionBatch.kind != "single")
        return paginate(s, stmt.order_by(PredictionBatch.id.desc()), page=page, page_size=page_size)


@router.get("/predictions/batches/{batch_id}", tags=["predictions"])
def get_batch(batch_id: int, principal: Principal = Depends(require("predict:read"))) -> dict:
    with reading() as s:
        batch = get_owned(s, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
        out = to_dict(batch)
        out["distribution"] = predictions.distribution(s, principal.tenant_id, batch.id) if batch.status == "completed" else None
        return out


@router.get("/predictions/batches/{batch_id}/predictions", tags=["predictions"])
def list_predictions(batch_id: int, tier: str | None = None, page: int = 1, page_size: int = 50,
                     principal: Principal = Depends(require("predict:read"))) -> dict:
    if tier is not None and tier not in predictions.TIERS:
        raise ValidationFailed("tier must be high, medium or low", details={"field": "tier"})
    with reading() as s:
        get_owned(s, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
        stmt = select(Prediction, Customer).join(Customer, Customer.id == Prediction.customer_id).where(Prediction.batch_id == batch_id)
        if tier:
            stmt = stmt.where(Prediction.risk_tier == tier)
        return paginate(s, stmt.order_by(Prediction.probability.desc(), Prediction.id), page=page, page_size=page_size, scalars=False,
                        serializer=lambda r: predictions.prediction_view(r[0], r[1]))  # fmt: skip


@router.get("/predictions/batches/{batch_id}/export.csv", tags=["predictions"])
def export_batch(batch_id: int, principal: Principal = Depends(require("customers:export")),
                 _limit: None = Depends(limited("export", "rate_limit_export_per_minute"))) -> Response:
    """Batch output for reverse ETL: user id, churn probability, risk tier and the top three reasons."""
    with writing() as s:  # the export is audited
        text = predictions.export(s, principal, batch_id)
    return Response(text, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="churn-predictions-batch-{batch_id}.csv"'})  # fmt: skip


@router.get("/predictions/{prediction_id}/explanation", tags=["predictions"])
def prediction_explanation(prediction_id: int, principal: Principal = Depends(require("predict:read"))) -> dict:
    with writing() as s:  # the explanation is computed once and stored
        return predictions.local_explanation(s, principal, prediction_id)


@router.post("/customers/{customer_id}/predict", tags=["predictions"])
def predict_customer(customer_id: int, principal: Principal = Depends(require("predict:run")),
                     _limit: None = Depends(limited("predict", "rate_limit_predict_per_minute"))) -> dict:
    with writing() as s:
        return predictions.predict_single(s, principal, customer_id)


# ----------------------------------------------------------------------------- Customer 360
@router.get("/customers", tags=["customers"])
def list_customers(q: str | None = None, tier: str | None = None, sort: str = "risk", page: int = 1, page_size: int = 50,
                   principal: Principal = Depends(require("customers:read"))) -> dict:
    with reading() as s:
        return customer360.list_customers(s, principal.tenant_id, q=q, tier=tier, sort=sort, page=page, page_size=page_size)


@router.get("/customers/{customer_id}", tags=["customers"])
def get_customer(customer_id: int, principal: Principal = Depends(require("customers:read"))) -> dict:
    with reading() as s:
        return customer360.detail(s, principal.tenant_id, customer_id)


# ----------------------------------------------------------------------------- retention
class GenerateBody(Body):
    batch_id: int


class ExecuteBody(Body):
    connection_id: int | None = None


class OutcomeBody(Body):
    outcome: str
    note: str | None = Field(None, max_length=2000)


@router.post("/retention/recommendations/generate", status_code=202, tags=["retention"])
def generate_recommendations(body: GenerateBody, principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return {"job": job_ref(retention.start_generation(s, principal, body.batch_id))}


@router.get("/retention/recommendations", tags=["retention"])
def list_recommendations(batch_id: int | None = None, scope: str = "current", segment: str | None = None, status: str | None = None,
                         page: int = 1, page_size: int = 50, principal: Principal = Depends(require("retention:read"))) -> dict:
    """The work queue by default: the newest scoring date plus approved actions still to be carried out.
    ``batch_id`` shows one scoring date, ``scope=all`` everything on record."""
    with reading() as s:
        return retention.listing(s, principal.tenant_id, batch_id=batch_id, scope=scope, segment=segment, status=status,
                                 page=page, page_size=page_size)  # fmt: skip


@router.post("/retention/recommendations/{recommendation_id}/review", tags=["retention"])
def review_recommendation(recommendation_id: int, body: ReviewBody,
                          principal: Principal = Depends(require("retention:write", "retention:approve"))) -> dict:
    """Approve or dismiss a proposal, or withdraw an approved action that has not been carried out.
    Actions marked "needs human review" can only be approved with the ``retention:approve`` permission."""
    with writing() as s:
        return retention.view(retention.review(s, principal, recommendation_id, approve=body.approve, note=body.note))


@router.post("/retention/recommendations/{recommendation_id}/execute", tags=["retention"])
def execute_recommendation(recommendation_id: int, body: ExecuteBody | None = None,
                           principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return retention.execute(s, principal, recommendation_id, connection_id=(body or ExecuteBody()).connection_id)


@router.get("/retention/interventions", tags=["retention"])
def list_interventions(page: int = 1, page_size: int = 50, principal: Principal = Depends(require("retention:read"))) -> dict:
    with reading() as s:
        stmt = select(Intervention).where(Intervention.tenant_id == principal.tenant_id).order_by(Intervention.id.desc())
        out = paginate(s, stmt, page=page, page_size=page_size)
        ids = {item["customer_id"] for item in out["items"]}
        names = {row.id: row for row in s.execute(select(Customer.id, Customer.external_id, Customer.name).where(Customer.id.in_(ids)))} if ids else {}
        for item in out["items"]:
            row = names.get(item["customer_id"])
            item["customer_external_id"], item["customer_name"] = (row.external_id, row.name) if row else (None, None)
        return out


@router.post("/retention/interventions/{intervention_id}/outcome", tags=["retention"])
def intervention_outcome(intervention_id: int, body: OutcomeBody, principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return to_dict(retention.record_outcome(s, principal, intervention_id, body.outcome, body.note))


# ----------------------------------------------------------------------------- CRM
class ConnectionBody(Body):
    provider: str
    name: str = Field(min_length=1, max_length=120)
    base_url: str = Field(min_length=8, max_length=400)
    mode: str = "TEST_ONLY"
    access_token: str | None = Field(None, min_length=8, max_length=4000)
    field_mapping: dict[str, str] | None = None
    auth_type: str = "token"  # "oauth" connections are authorised later, at the vendor's consent screen


class SyncBody(Body):
    batch_id: int
    tiers: list[str] = ["high", "medium"]


@router.get("/crm/connections", tags=["crm"])
def list_connections(principal: Principal = Depends(require("crm:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(CRMConnection).where(CRMConnection.tenant_id == principal.tenant_id).order_by(CRMConnection.name)).scalars().all()
        return {"items": [crm.connection_view(c) for c in rows], "total": len(rows), "providers": list(crm.PROVIDERS), "modes": list(crm.MODES)}


@router.post("/crm/connections", status_code=201, tags=["crm"])
def create_connection(body: ConnectionBody, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return crm.connection_view(crm.create_connection(s, principal, provider=body.provider, name=body.name, base_url=body.base_url,
                                                         mode=body.mode, access_token=body.access_token, field_mapping=body.field_mapping,
                                                         auth_type=body.auth_type))  # fmt: skip


@router.post("/crm/connections/{connection_id}/sync", status_code=202, tags=["crm"])
def sync_scores(connection_id: int, body: SyncBody, principal: Principal = Depends(require("crm:write")),
                _limit: None = Depends(limited("sync", "rate_limit_sync_per_minute"))) -> dict:
    bad = [t for t in body.tiers if t not in predictions.TIERS]
    if bad or not body.tiers:
        raise ValidationFailed("tiers must be a non-empty subset of high, medium, low", details={"field": "tiers"})
    with writing() as s:
        return crm.sync_risk_scores(s, principal, connection_id, body.batch_id, tuple(body.tiers))


@router.get("/crm/deliveries", tags=["crm"])
def list_deliveries(connection_id: int | None = None, status: str | None = None, page: int = 1, page_size: int = 50,
                    principal: Principal = Depends(require("crm:read"))) -> dict:
    with reading() as s:
        stmt = select(CRMDelivery).where(CRMDelivery.tenant_id == principal.tenant_id)
        if connection_id:
            stmt = stmt.where(CRMDelivery.connection_id == connection_id)
        if status:
            stmt = stmt.where(CRMDelivery.status == status)
        return paginate(s, stmt.order_by(CRMDelivery.id.desc()), page=page, page_size=page_size, serializer=crm.delivery_view)


# ----------------------------------------------------------------------------- monitoring
class MonitorBody(Body):
    model_version_id: int | None = None
    with_evidently: bool = False


class AckBody(Body):
    resolve: bool = False


@router.post("/monitoring/runs", status_code=202, tags=["monitoring"])
def start_monitoring(body: MonitorBody | None = None, principal: Principal = Depends(require("mlops:write"))) -> dict:
    body = body or MonitorBody()
    with writing() as s:
        job = monitoring.start(s, principal, tenant_id=principal.tenant_id, model_version_id=body.model_version_id,
                               with_evidently=body.with_evidently)  # fmt: skip
        return {"job": job_ref(job)}


@router.get("/monitoring/latest", tags=["monitoring"])
def monitoring_latest(principal: Principal = Depends(require("mlops:read"))) -> dict:
    with reading() as s:
        version = monitoring.model_version_or_none(s, principal.tenant_id)
        return {"reports": monitoring.latest_reports(s, principal.tenant_id),
                "production_model": registry.version_view(version) if version else None}  # fmt: skip


@router.get("/monitoring/reports", tags=["monitoring"])
def monitoring_reports(kind: str | None = None, page: int = 1, page_size: int = 20, principal: Principal = Depends(require("mlops:read"))) -> dict:
    with reading() as s:
        stmt = select(DriftReport).where(DriftReport.tenant_id == principal.tenant_id)
        if kind:
            stmt = stmt.where(DriftReport.kind == kind)
        return paginate(s, stmt.order_by(DriftReport.id.desc()), page=page, page_size=page_size,
                        serializer=lambda r: to_dict(r, exclude={"result"}))  # fmt: skip


@router.get("/alerts", tags=["monitoring"])
def list_alerts(status: str | None = None, page: int = 1, page_size: int = 50, principal: Principal = Depends(require("mlops:read"))) -> dict:
    with reading() as s:
        stmt = select(Alert).where(Alert.tenant_id == principal.tenant_id)
        if status:
            stmt = stmt.where(Alert.status == status)
        return paginate(s, stmt.order_by(Alert.id.desc()), page=page, page_size=page_size)


@router.post("/alerts/{alert_id}/acknowledge", tags=["monitoring"])
def acknowledge_alert(alert_id: int, body: AckBody | None = None, principal: Principal = Depends(require("mlops:write"))) -> dict:
    with writing() as s:
        return to_dict(monitoring.acknowledge(s, principal, alert_id, resolve=(body or AckBody()).resolve))


# ----------------------------------------------------------------------------- experiments and uplift
class ExperimentBody(Body):
    name: str = Field(min_length=1, max_length=160)
    hypothesis: str | None = Field(None, max_length=4000)
    treatment_share: float = Field(0.5, ge=0.05, le=0.95)
    baseline_rate: float | None = Field(None, gt=0, lt=1)
    min_detectable_effect: float | None = Field(None, gt=-1, lt=1)
    alpha: float = Field(0.05, gt=0, lt=0.5)
    power: float = Field(0.8, ge=0.5, lt=1)
    outcome_window_days: int | None = Field(None, ge=1, le=365)


class SampleSizeBody(Body):
    baseline_rate: float = Field(gt=0, lt=1)
    min_detectable_effect: float = Field(gt=-1, lt=1)
    alpha: float = Field(0.05, gt=0, lt=0.5)
    power: float = Field(0.8, ge=0.5, lt=1)
    treatment_share: float = Field(0.5, ge=0.05, le=0.95)


class DecisionBody(Body):
    approve: bool


class AssignBody(Body):
    batch_id: int
    tiers: list[str] = ["high", "medium"]


class UpliftBody(Body):
    experiment_id: int
    contract_id: int
    delta: float = Field(0.02, gt=0, lt=0.5)


class UpliftScoreBody(Body):
    as_of_date: str | None = None


@router.post("/experiments/sample-size", tags=["experiments"])
def experiment_sample_size(body: SampleSizeBody, _: Principal = Depends(require("retention:read"))) -> dict:
    return experiments.sample_size(body.baseline_rate, body.min_detectable_effect, body.alpha, body.power, body.treatment_share)


@router.get("/experiments", tags=["experiments"])
def list_experiments(principal: Principal = Depends(require("retention:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(Experiment).where(Experiment.tenant_id == principal.tenant_id).order_by(Experiment.id.desc())).scalars().all()
        return {"items": [experiments.view(e) for e in rows], "total": len(rows)}


@router.post("/experiments", status_code=201, tags=["experiments"])
def create_experiment(body: ExperimentBody, principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return experiments.view(experiments.create(s, principal, **body.model_dump()))


@router.get("/experiments/{experiment_id}", tags=["experiments"])
def get_experiment(experiment_id: int, principal: Principal = Depends(require("retention:read"))) -> dict:
    with reading() as s:
        return experiments.view(get_owned(s, Experiment, principal.tenant_id, experiment_id, label="Experiment"))


@router.post("/experiments/{experiment_id}/submit", tags=["experiments"])
def submit_experiment(experiment_id: int, principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return experiments.view(experiments.submit(s, principal, experiment_id))


@router.post("/experiments/{experiment_id}/review", tags=["experiments"])
def review_experiment(experiment_id: int, body: DecisionBody, principal: Principal = Depends(require("retention:approve"))) -> dict:
    with writing() as s:
        return experiments.view(experiments.review(s, principal, experiment_id, approve=body.approve))


@router.post("/experiments/{experiment_id}/assign", tags=["experiments"])
def assign_experiment(experiment_id: int, body: AssignBody, principal: Principal = Depends(require("retention:write"))) -> dict:
    bad = [t for t in body.tiers if t not in predictions.TIERS]
    if bad or not body.tiers:
        raise ValidationFailed("tiers must be a non-empty subset of high, medium, low", details={"field": "tiers"})
    with writing() as s:
        return experiments.assign(s, principal, experiment_id, body.batch_id, tuple(body.tiers))


@router.post("/experiments/{experiment_id}/analyse", tags=["experiments"])
def analyse_experiment(experiment_id: int, principal: Principal = Depends(require("retention:write"))) -> dict:
    with writing() as s:
        return experiments.analyse(s, principal, experiment_id)


@router.get("/uplift/models", tags=["experiments"])
def list_uplift_models(principal: Principal = Depends(require("retention:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(UpliftModel).where(UpliftModel.tenant_id == principal.tenant_id).order_by(UpliftModel.id.desc())).scalars().all()
        return {"items": [experiments.uplift_view(m) for m in rows], "total": len(rows)}


@router.post("/uplift/models", status_code=201, tags=["experiments"])
def fit_uplift_model(body: UpliftBody, principal: Principal = Depends(require("ml:train"))) -> dict:
    signals.ensure_ready(principal.tenant_id)  # before the write transaction below: computing features in it must only read
    with writing() as s:
        return experiments.uplift_view(experiments.fit_uplift(s, principal, body.experiment_id, body.contract_id, body.delta))


@router.post("/uplift/models/{model_id}/review", tags=["experiments"])
def review_uplift_model(model_id: int, body: DecisionBody, principal: Principal = Depends(require("ml:approve"))) -> dict:
    with writing() as s:
        return experiments.uplift_view(experiments.review_uplift(s, principal, model_id, approve=body.approve))


@router.post("/uplift/models/{model_id}/score", tags=["experiments"])
def score_uplift_model(model_id: int, body: UpliftScoreBody | None = None, principal: Principal = Depends(require("ml:train"))) -> dict:
    with writing() as s:
        return experiments.score(s, principal, model_id, (body or UpliftScoreBody()).as_of_date)


@router.get("/uplift/models/{model_id}/segments", tags=["experiments"])
def uplift_segments(model_id: int, principal: Principal = Depends(require("retention:read"))) -> dict:
    with reading() as s:
        return experiments.segment_summary(s, principal.tenant_id, model_id)


# ----------------------------------------------------------------------------- nightly pipeline
class ScheduleBody(Body):
    hour_utc: int = Field(2, ge=0, le=23)
    enabled: bool = True


@router.post("/pipeline/runs", status_code=202, tags=["pipeline"])
def start_pipeline(principal: Principal = Depends(require("mlops:write"))) -> dict:
    with writing() as s:
        job, started = pipeline.start(s, principal)
        return {"job": job_ref(job), "steps": list(pipeline.STEPS), "already_running": not started}


@router.get("/pipeline", tags=["pipeline"])
def pipeline_status(principal: Principal = Depends(require("mlops:read"))) -> dict:
    with reading() as s:
        schedule = s.execute(select(Schedule).where(Schedule.tenant_id == principal.tenant_id, Schedule.name == "nightly-pipeline")).scalar_one_or_none()
        return {"steps": list(pipeline.STEPS), "schedule": to_dict(schedule) if schedule else None,
                "runs": pipeline.last_runs(s, principal.tenant_id)}  # fmt: skip


@router.put("/pipeline/schedule", tags=["pipeline"])
def save_schedule(body: ScheduleBody, principal: Principal = Depends(require("mlops:write"))) -> dict:
    with writing() as s:
        return to_dict(pipeline.ensure_schedule(s, principal, hour_utc=body.hour_utc, enabled=body.enabled))


__all__ = ["Any", "NotFound", "router"]
