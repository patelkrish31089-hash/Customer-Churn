"""Customer-signal routes (1.1.0): support sentiment, the product-feature catalogue and adoption, identity mapping
and active users, and the history of slowly changing customer attributes."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import Field
from sqlalchemy import select

from ..errors import ValidationFailed
from ..models import AdoptionRun, IdentityReconciliation, SentimentAnnotationBatch, SentimentRun
from ..security import Principal
from ..services import adoption, annotations, attributes, identity, sentiment
from ..services.common import get_owned, paginate, parse_date, to_dict
from .deps import Body, job_ref, reading, require, writing

router = APIRouter()


# ----------------------------------------------------------------------------- sentiment
class AnalyseBody(Body):
    texts: list[str] = Field(min_length=1, max_length=50)


class EvaluateBody(Body):
    dataset_name: str = Field(min_length=1, max_length=200)
    rows: list[dict[str, Any]] = Field(min_length=1, max_length=20000)
    is_synthetic: bool = False


@router.get("/signals/sentiment", tags=["signals"])
def sentiment_status(days: int = 180, principal: Principal = Depends(require("signals:read"))) -> dict:
    if not 7 <= days <= 1095:
        raise ValidationFailed("days must be between 7 and 1095", details={"field": "days"})
    with reading() as s:
        runs = s.execute(select(SentimentRun).where(SentimentRun.tenant_id == principal.tenant_id).order_by(SentimentRun.id.desc()).limit(10)).scalars().all()
        return {"status": sentiment.status(s, principal.tenant_id), "summary": sentiment.summary(s, principal.tenant_id, days),
                "runs": [to_dict(r) for r in runs]}  # fmt: skip


@router.get("/signals/sentiment/scores", tags=["signals"])
def sentiment_scores(label: str | None = None, state: str | None = None, language: str | None = None, q: str | None = None,
                     customer_id: int | None = None, page: int = 1, page_size: int = 50,
                     principal: Principal = Depends(require("signals:read"))) -> dict:  # fmt: skip
    with reading() as s:
        model = sentiment.active_model(s, principal.tenant_id)
        if model is None:
            return {"items": [], "total": 0, "page": page, "page_size": page_size, "model": None}
        stmt = sentiment.scores_query(principal.tenant_id, model.id, label=label, state=state, language=language, q=q, customer_id=customer_id)
        return {**paginate(s, stmt, page=page, page_size=page_size, scalars=False, serializer=sentiment.score_view), "model": sentiment.model_view(model)}


@router.post("/signals/sentiment/runs", status_code=202, tags=["signals"])
def sentiment_run(principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        run, job = sentiment.start_run(s, principal)
        return {"run": to_dict(run), "job": job_ref(job)}


@router.post("/signals/sentiment/analyse", tags=["signals"])
def sentiment_analyse(body: AnalyseBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    """Score texts without storing anything (a way to see what the active provider does with a message)."""
    provider, fallback = sentiment.get_provider()
    results = sentiment.analyse(list(body.texts), provider)
    return {"provider": {"provider": provider.info.provider, "model_id": provider.info.model_id, "is_baseline": provider.info.is_baseline},
            "fallback_reason": fallback, "results": [sentiment.analysis_view(r) for r in results]}  # fmt: skip


@router.post("/signals/sentiment/evaluations", status_code=201, tags=["signals"])
def sentiment_evaluate(body: EvaluateBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        return sentiment.evaluation_view(sentiment.evaluate(s, principal, dataset_name=body.dataset_name, rows=body.rows, is_synthetic=body.is_synthetic))


# ----------------------------------------------------------------------------- product-feature catalogue
class CatalogBody(Body):
    feature_key: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=160)
    description: str | None = Field(None, max_length=2000)
    category: str | None = Field(None, max_length=60)
    availability: str = "ga"
    release_date: str | None = None
    retired_date: str | None = None
    eligibility: dict[str, Any] | None = None
    event_mapping: list[dict[str, Any]] = Field(min_length=1, max_length=50)
    adoption_rule: dict[str, Any] | None = None
    owner: str | None = Field(None, max_length=200)
    is_core: bool = False


class ReviewBody(Body):
    approve: bool
    note: str | None = Field(None, max_length=1000)


class ActiveBody(Body):
    active: bool


@router.get("/signals/catalog", tags=["signals"])
def catalog_list(principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return {**adoption.list_catalog(s, principal.tenant_id), "telemetry": adoption.telemetry_names(s, principal.tenant_id)}


@router.post("/signals/catalog", status_code=201, tags=["signals"])
def catalog_create(body: CatalogBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        return adoption.feature_view(adoption.create_feature(s, principal, body.model_dump()))


@router.post("/signals/catalog/{feature_id}/submit", tags=["signals"])
def catalog_submit(feature_id: int, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        return adoption.feature_view(adoption.submit(s, principal, feature_id))


@router.post("/signals/catalog/{feature_id}/review", tags=["signals"])
def catalog_review(feature_id: int, body: ReviewBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return adoption.feature_view(adoption.review(s, principal, feature_id, approve=body.approve, note=body.note))


@router.post("/signals/catalog/{feature_id}/active", tags=["signals"])
def catalog_active(feature_id: int, body: ActiveBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return adoption.feature_view(adoption.set_active(s, principal, feature_id, body.active))


# ----------------------------------------------------------------------------- adoption
class AdoptionRunBody(Body):
    as_of_date: str | None = None
    window_days: int = Field(30, ge=1, le=365)


@router.get("/signals/adoption", tags=["signals"])
def adoption_overview(principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        latest = adoption.latest_run(s, principal.tenant_id)
        runs = s.execute(select(AdoptionRun).where(AdoptionRun.tenant_id == principal.tenant_id).order_by(AdoptionRun.id.desc()).limit(10)).scalars().all()
        return {"latest": adoption.run_view(latest) if latest is not None else None, "trend": adoption.trend(s, principal.tenant_id),
                "runs": [adoption.run_view(r, with_result=False) for r in runs]}  # fmt: skip


@router.post("/signals/adoption/runs", status_code=202, tags=["signals"])
def adoption_run(body: AdoptionRunBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        run, job = adoption.start_run(s, principal, as_of=parse_date(body.as_of_date, field="as_of_date"), window_days=body.window_days)
        return {"run": adoption.run_view(run, with_result=False), "job": job_ref(job)}


@router.get("/signals/adoption/runs/{run_id}", tags=["signals"])
def adoption_run_detail(run_id: int, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return adoption.run_view(get_owned(s, AdoptionRun, principal.tenant_id, run_id, label="Adoption run"))


@router.get("/signals/adoption/runs/{run_id}/facts", tags=["signals"])
def adoption_facts(run_id: int, feature_key: str | None = None, state: str | None = None, customer_id: int | None = None, q: str | None = None,
                   page: int = 1, page_size: int = 50, principal: Principal = Depends(require("signals:read"))) -> dict:  # fmt: skip
    with reading() as s:
        get_owned(s, AdoptionRun, principal.tenant_id, run_id, label="Adoption run")
        stmt = adoption.facts_query(principal.tenant_id, run_id, feature_key=feature_key, state=state, customer_id=customer_id, q=q)
        return paginate(s, stmt, page=page, page_size=page_size, scalars=False, serializer=adoption.fact_view)


# ----------------------------------------------------------------------------- identity and active users
class ReconcileBody(Body):
    window_days: int = Field(90, ge=7, le=730)


class LinkStatusBody(Body):
    status: str
    note: str | None = Field(None, max_length=1000)


class MergeBody(Body):
    keep_key: str = Field(min_length=3, max_length=64)
    merge_key: str = Field(min_length=3, max_length=64)
    note: str | None = Field(None, max_length=1000)


class UnmergeBody(Body):
    merged_key: str = Field(min_length=3, max_length=64)
    note: str | None = Field(None, max_length=1000)


class CandidateBody(Body):
    merge: bool
    note: str | None = Field(None, max_length=1000)


class ImportLinksBody(Body):
    rows: list[dict[str, Any]] = Field(min_length=1, max_length=50000)


@router.get("/signals/identity", tags=["signals"])
def identity_overview(principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        runs = s.execute(select(IdentityReconciliation).where(IdentityReconciliation.tenant_id == principal.tenant_id)
                         .order_by(IdentityReconciliation.id.desc()).limit(5)).scalars().all()  # fmt: skip
        return {**identity.overview(s, principal.tenant_id), "candidates": identity.candidates(s, principal.tenant_id),
                "runs": [to_dict(r, exclude={"result"}) for r in runs]}  # fmt: skip


@router.get("/signals/identity/links", tags=["signals"])
def identity_links(status: str | None = None, q: str | None = None, customer_id: int | None = None, user_key: str | None = None, page: int = 1,
                   page_size: int = 50, principal: Principal = Depends(require("signals:read"))) -> dict:  # fmt: skip
    with reading() as s:
        stmt = identity.links_query(principal.tenant_id, status=status, q=q, customer_id=customer_id, user_key_value=user_key)
        return paginate(s, stmt, page=page, page_size=page_size, scalars=False, serializer=identity.link_row_view)


@router.post("/signals/identity/reconciliations", status_code=202, tags=["signals"])
def identity_reconcile(body: ReconcileBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        entry, job = identity.start_reconciliation(s, principal, window_days=body.window_days)
        return {"reconciliation": to_dict(entry, exclude={"result"}), "job": job_ref(job)}


@router.post("/signals/identity/links/import", tags=["signals"])
def identity_import(body: ImportLinksBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        return identity.import_links(s, principal, body.rows)


@router.post("/signals/identity/links/{link_id}/status", tags=["signals"])
def identity_link_status(link_id: int, body: LinkStatusBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return identity.link_view(identity.set_status(s, principal, link_id, body.status, body.note))


@router.post("/signals/identity/merge", tags=["signals"])
def identity_merge(body: MergeBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return identity.merge(s, principal, body.keep_key, body.merge_key, note=body.note)


@router.post("/signals/identity/unmerge", tags=["signals"])
def identity_unmerge(body: UnmergeBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return identity.unmerge(s, principal, body.merged_key, note=body.note)


@router.post("/signals/identity/candidates/{candidate_id}/review", tags=["signals"])
def identity_candidate_review(candidate_id: int, body: CandidateBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return to_dict(identity.review_candidate(s, principal, candidate_id, merge_them=body.merge, note=body.note))


# ----------------------------------------------------------------------------- attribute history
class AttributeBody(Body):
    attribute: str
    value: str | None = Field(None, max_length=300)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    basis: str = "correction"
    note: str = Field(min_length=1, max_length=1000)


@router.get("/signals/attributes", tags=["signals"])
def attributes_summary(principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return attributes.summary(s, principal.tenant_id)


@router.get("/signals/attributes/customers/{customer_id}", tags=["signals"])
def attributes_timeline(customer_id: int, at: datetime | None = None, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        out = attributes.timeline(s, principal.tenant_id, customer_id)
        if at is not None:
            out["at"] = {"moment": at, "as_known_then": {a: attributes.value_at(s, principal.tenant_id, customer_id, a, at) for a in attributes.TRACKED},
                         "as_known_today": {a: attributes.value_at(s, principal.tenant_id, customer_id, a, at, as_known=False) for a in attributes.TRACKED}}  # fmt: skip
        return out


@router.post("/signals/attributes/customers/{customer_id}", status_code=201, tags=["signals"])
def attributes_record(customer_id: int, body: AttributeBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        row = attributes.record(s, principal, customer_id, attribute=body.attribute, value=body.value, valid_from=body.valid_from,
                                valid_to=body.valid_to, basis=body.basis, note=body.note)  # fmt: skip
        return to_dict(row)


# ----------------------------------------------------------------------------- human annotation of support text (1.2.0)
class AnnotationBatchBody(Body):
    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(None, max_length=2000)
    is_synthetic: bool = True
    language: str | None = Field(None, max_length=12)
    sample: int = Field(200, ge=1, le=5000)
    interaction_ids: list[int] | None = Field(None, max_length=5000)


class AnnotationBody(Body):
    interaction_id: int
    label: str = Field(min_length=1, max_length=12)
    note: str | None = Field(None, max_length=2000)


class AdjudicationBody(AnnotationBody):
    pass


@router.get("/signals/sentiment/annotation-batches", tags=["signals"])
def annotation_batches(status: str | None = None, page: int = 1, page_size: int = 50,
                       principal: Principal = Depends(require("signals:read"))) -> dict:  # fmt: skip
    with reading() as s:
        return annotations.list_batches(s, principal.tenant_id, status=status, page=page, page_size=page_size)


@router.post("/signals/sentiment/annotation-batches", status_code=201, tags=["signals"])
def annotation_batch_create(body: AnnotationBatchBody, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        batch = annotations.create_batch(s, principal, name=body.name, description=body.description, is_synthetic=body.is_synthetic,
                                         language=body.language, sample=body.sample, interaction_ids=body.interaction_ids)  # fmt: skip
        return annotations.batch_view(s, batch)


@router.get("/signals/sentiment/annotation-batches/{batch_id}", tags=["signals"])
def annotation_batch(batch_id: int, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return annotations.batch_view(s, get_owned(s, SentimentAnnotationBatch, principal.tenant_id, batch_id, label="Annotation batch"))  # fmt: skip


@router.get("/signals/sentiment/annotation-batches/{batch_id}/items", tags=["signals"])
def annotation_items(batch_id: int, only_unlabelled_by_me: bool = False, page: int = 1, page_size: int = 50,
                     principal: Principal = Depends(require("signals:read"))) -> dict:  # fmt: skip
    with reading() as s:
        batch = get_owned(s, SentimentAnnotationBatch, principal.tenant_id, batch_id, label="Annotation batch")  # fmt: skip
        return annotations.items_of(s, batch, principal=principal, only_unlabelled_by_me=only_unlabelled_by_me, page=page, page_size=page_size)


@router.post("/signals/sentiment/annotation-batches/{batch_id}/labels", status_code=201, tags=["signals"])
def annotation_submit(batch_id: int, body: AnnotationBody, principal: Principal = Depends(require("signals:annotate"))) -> dict:
    with writing() as s:
        return annotations.submit(s, principal, batch_id, body.interaction_id, body.label, body.note)


@router.get("/signals/sentiment/annotation-batches/{batch_id}/agreement", tags=["signals"])
def annotation_agreement(batch_id: int, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return annotations.agreement(s, principal, batch_id)


@router.post("/signals/sentiment/annotation-batches/{batch_id}/adjudications", tags=["signals"])
def annotation_adjudicate(batch_id: int, body: AdjudicationBody, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        return annotations.adjudicate(s, principal, batch_id, body.interaction_id, body.label, body.note)


@router.post("/signals/sentiment/annotation-batches/{batch_id}/freeze", tags=["signals"])
def annotation_freeze(batch_id: int, principal: Principal = Depends(require("signals:approve"))) -> dict:
    with writing() as s:
        batch = annotations.freeze(s, principal, batch_id)
        return annotations.batch_view(s, batch)


@router.get("/signals/sentiment/annotation-batches/{batch_id}/export", tags=["signals"])
def annotation_export(batch_id: int, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        rows = annotations.export_rows(s, principal, batch_id)
        return {"batch_id": batch_id, "rows": len(rows), "labelled": rows}


@router.post("/signals/sentiment/annotation-batches/{batch_id}/evaluate", status_code=201, tags=["signals"])
def annotation_evaluate(batch_id: int, principal: Principal = Depends(require("signals:write"))) -> dict:
    with writing() as s:
        return annotations.evaluate_batch(s, principal, batch_id)


@router.get("/signals/sentiment/annotation-batches/{batch_id}/disagreements-with-model", tags=["signals"])
def annotation_model_disagreements(batch_id: int, principal: Principal = Depends(require("signals:read"))) -> dict:
    with reading() as s:
        return annotations.model_disagreements(s, principal, batch_id)
