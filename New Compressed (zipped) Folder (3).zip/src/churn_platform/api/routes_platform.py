"""Platform routes (1.1.0): model lifecycle and promotion gates, external orchestration, the MLflow registry."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from pydantic import Field
from sqlalchemy import select

from .. import netpolicy
from ..config import get_settings
from ..db import session_scope
from ..errors import AppError
from ..models import Campaign, NotificationSuppression, NotificationTemplate, User
from ..security import Principal
from ..services import auth, campaigns, crm, crm_oauth, mlflow_mirror, notify, orchestration, ratelimit, registry, reverse_etl, sso
from ..services.common import get_owned, paginate, to_dict
from .deps import Body, authenticated, client_ip, job_ref, limited, reading, require, writing

router = APIRouter()


# ----------------------------------------------------------------------------- model lifecycle
@router.get("/ml/registry/gates", tags=["registry"])
def promotion_gates(principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        gates, policy_id = registry.promotion_gates(s, principal.tenant_id)
        return {"gates": gates, "policy_id": policy_id, "source": "approved promotion-gate policy" if policy_id else "built-in defaults (no policy approved)"}


@router.post("/ml/registry/{version_id}/validate", tags=["registry"])
def validate_version(version_id: int, principal: Principal = Depends(require("ml:train"))) -> dict:
    """Check the version against the promotion gates.  A failed check is recorded, not raised."""
    with writing() as s:
        return registry.validate(s, principal, version_id)


@router.get("/ml/registry/{version_id}/transitions", tags=["registry"])
def version_transitions(version_id: int, principal: Principal = Depends(require("ml:read"))) -> dict:
    with reading() as s:
        items = registry.transitions(s, principal.tenant_id, version_id)
        return {"items": items, "total": len(items)}


@router.get("/ml/registry/mlflow", tags=["registry"])
def mlflow_registry(name: str = "churn-model", principal: Principal = Depends(require("mlops:read"))) -> dict:
    """What the MLflow registry says about this model: which versions its aliases name."""
    settings = get_settings()
    out: dict = {"registry_of_record": settings.model_registry, "mlflow_configured": mlflow_mirror.enabled(),
                 "registered_model": mlflow_mirror.registered_name(principal.tenant_id, name) if mlflow_mirror.enabled() else None, "aliases": {}}  # fmt: skip
    if not mlflow_mirror.enabled():
        out["status"] = "not_configured"
        return out
    try:
        for alias in ("validated", "staging", "production"):
            found = mlflow_mirror.resolve_alias(principal.tenant_id, name, alias, use_cache=False)
            out["aliases"][alias] = None if found is None else {k: found[k] for k in ("mlflow_version", "platform_version_id", "artifact_sha256", "lifecycle_state")}
        out["status"] = "reachable"
    except mlflow_mirror.RegistryUnavailable as exc:
        out["status"], out["error"] = "unreachable", str(exc)
    return out


# ----------------------------------------------------------------------------- orchestration
@router.get("/pipeline/orchestration", tags=["pipeline"])
def orchestration_status(principal: Principal = Depends(require("jobs:read"))) -> dict:
    with reading() as s:
        return orchestration.status(s, principal.tenant_id)


# ----------------------------------------------------------------------------- sessions
@router.post("/auth/rotate", tags=["auth"])
def rotate_session(principal: Principal = Depends(authenticated)) -> dict:
    """Replace this session's token (the web app does this by itself; see ``session.rotate_after`` in /auth/me)."""
    with writing() as s:
        return auth.rotate(s, principal)


# ----------------------------------------------------------------------------- single sign-on (OpenID Connect)
BINDING_COOKIE = "churn_sso"


class ProviderBody(Body):
    name: str = Field(min_length=1, max_length=120)
    issuer: str = Field(min_length=8, max_length=400)
    client_id: str = Field(min_length=1, max_length=300)
    client_secret: str | None = Field(None, max_length=2000)
    scopes: str | None = Field(None, max_length=300)
    role_claim: str | None = Field(None, max_length=100)
    role_mapping: dict[str, str] | None = None
    default_role: str | None = None
    allowed_email_domains: list[str] | None = None
    auto_provision: bool | None = None
    trust_idp_mfa: bool | None = None
    enabled: bool | None = None


class ProviderPatch(Body):
    name: str | None = Field(None, min_length=1, max_length=120)
    issuer: str | None = Field(None, min_length=8, max_length=400)
    client_id: str | None = Field(None, min_length=1, max_length=300)
    client_secret: str | None = Field(None, max_length=2000)
    scopes: str | None = Field(None, max_length=300)
    role_claim: str | None = Field(None, max_length=100)
    role_mapping: dict[str, str] | None = None
    default_role: str | None = None
    allowed_email_domains: list[str] | None = None
    auto_provision: bool | None = None
    trust_idp_mfa: bool | None = None
    enabled: bool | None = None


class ExchangeBody(Body):
    code: str = Field(min_length=10, max_length=200)


def _request_base(request: Request) -> str:
    return str(request.base_url).rstrip("/")


def _cookie_secure(request: Request) -> bool:
    return netpolicy.is_secure(request.url.scheme, request.client.host if request.client else None, request.headers.get("x-forwarded-proto"))


@router.get("/auth/oidc/providers", tags=["auth"])
def sso_public_providers(tenant: str, request: Request) -> dict:
    """Sign-in methods of an organisation (names only), for the sign-in page."""
    ratelimit.enforce("login_ip", client_ip(request) or "unknown", get_settings().rate_limit_login_per_minute)
    with reading() as s:
        return {"items": sso.public_providers(s, tenant)}


@router.get("/auth/oidc/{provider_id}/start", tags=["auth"], include_in_schema=True)
def sso_start(provider_id: int, request: Request) -> RedirectResponse:
    """Send the browser to the identity provider.  Sets the cookie that ties the login to this browser."""
    ratelimit.enforce("login_ip", client_ip(request) or "unknown", get_settings().rate_limit_login_per_minute)
    with writing() as s:
        started = sso.begin(s, provider_id, request_base=_request_base(request))
    response = RedirectResponse(started["authorization_url"], status_code=302)
    response.set_cookie(BINDING_COOKIE, started["binding"], max_age=900, httponly=True, samesite="lax", secure=_cookie_secure(request),
                        path="/api/v1/auth/oidc")  # fmt: skip
    return response


@router.get("/auth/oidc/callback", tags=["auth"], include_in_schema=True)
def sso_callback(request: Request, state: str | None = None, code: str | None = None, error: str | None = None) -> RedirectResponse:
    """Where the identity provider sends the browser back.  Ends in the web app with a one-time code, or a reason."""
    binding = request.cookies.get(BINDING_COOKIE)
    try:
        with writing() as s:
            exchange = sso.callback(s, state=state, code=code, binding=binding, error=error, ip=client_ip(request),
                                    user_agent=request.headers.get("user-agent"))  # fmt: skip
        target = f"/#/sso?code={quote(exchange)}"
    except AppError as exc:
        with session_scope() as s:  # the refusal is on record, and the state cannot be tried again
            sso.record_refusal(s, state, exc.code)
        target = f"/#/sso?error={quote(exc.code)}&message={quote(exc.message)}"
    return RedirectResponse(target, status_code=302)


@router.post("/auth/oidc/exchange", tags=["auth"])
def sso_exchange(body: ExchangeBody, request: Request) -> Any:
    from fastapi.responses import JSONResponse

    ratelimit.enforce("login_ip", client_ip(request) or "unknown", get_settings().rate_limit_login_per_minute)
    with writing() as s:
        result = sso.exchange(s, body.code, request.cookies.get(BINDING_COOKIE))
    response = JSONResponse(result)
    response.delete_cookie(BINDING_COOKIE, path="/api/v1/auth/oidc")
    return response


@router.get("/admin/security/identity-providers", tags=["admin"])
def sso_list(principal: Principal = Depends(require("admin:security"))) -> dict:
    with reading() as s:
        items = sso.list_providers(s, principal.tenant_id)
        return {"items": items, "total": len(items), "redirect_uri": sso.redirect_uri(get_settings().public_base_url or ""),
                "public_base_url_set": bool(get_settings().public_base_url)}  # fmt: skip


@router.post("/admin/security/identity-providers", status_code=201, tags=["admin"])
def sso_create(body: ProviderBody, principal: Principal = Depends(require("admin:security"))) -> dict:
    with writing() as s:
        return sso.provider_view(sso.create_provider(s, principal, body.model_dump(exclude_none=True)))


@router.patch("/admin/security/identity-providers/{provider_id}", tags=["admin"])
def sso_update(provider_id: int, body: ProviderPatch, principal: Principal = Depends(require("admin:security"))) -> dict:
    with writing() as s:
        return sso.provider_view(sso.update_provider(s, principal, provider_id, body.model_dump(exclude_unset=True)))


@router.post("/admin/security/identity-providers/{provider_id}/test", tags=["admin"])
def sso_test(provider_id: int, principal: Principal = Depends(require("admin:security"))) -> dict:
    with writing() as s:
        return sso.test_provider(s, principal, provider_id)


@router.delete("/admin/security/identity-providers/{provider_id}", tags=["admin"])
def sso_delete(provider_id: int, principal: Principal = Depends(require("admin:security"))) -> dict:
    with writing() as s:
        sso.delete_provider(s, principal, provider_id)
    return {"ok": True}


@router.get("/admin/security/overview", tags=["admin"])
def security_overview(principal: Principal = Depends(require("admin:security"))) -> dict:
    """How this installation is protected: limits (shared by all server processes), proxy trust, sessions, sign-on."""
    settings = get_settings()
    with reading() as s:
        providers = sso.list_providers(s, principal.tenant_id)
        own = {f"user:{user_id}": email for user_id, email in s.execute(select(User.id, User.email).where(User.tenant_id == principal.tenant_id))}
    # The counters are shared by every tenant of the installation.  A tenant sees the per-user counters of its own
    # users and nothing else: no addresses, no account names, no other tenant's activity.
    limit_of = {"export": settings.rate_limit_export_per_minute, "predict": settings.rate_limit_predict_per_minute, "sync": settings.rate_limit_sync_per_minute}
    counted = [{"limit": c["bucket"], "user": own[c["subject"]], "requests": c["hits"], "allowed": limit_of.get(c["bucket"])}
               for c in ratelimit.snapshot(1000, subject_prefix="user:") if c["subject"] in own][:15]  # fmt: skip
    return {
        "rate_limits": {"enabled": settings.rate_limit_enabled, "store": "database table rate_limit_counters (shared by every server process)",
                        "when_the_store_fails": settings.rate_limit_store_failure,
                        "per_minute": {"sign_in_per_address": settings.rate_limit_login_per_minute, "sign_in_per_account": settings.rate_limit_login_account_per_minute,
                                       "changes_per_address": settings.rate_limit_ip_per_minute, "changes_per_session": settings.rate_limit_api_per_minute,
                                       "exports_per_user": settings.rate_limit_export_per_minute, "single_predictions_per_user": settings.rate_limit_predict_per_minute,
                                       "crm_syncs_per_user": settings.rate_limit_sync_per_minute},
                        "own_users_this_minute": counted},
        "proxy": {"trusted_proxies": settings.trusted_proxy_list, "forwarded_headers": "believed only from the trusted proxies" if settings.trusted_proxy_list
                  else "ignored (no trusted proxy configured)", "force_https": settings.force_https, "hsts_seconds": settings.hsts_seconds,
                  "public_base_url": settings.public_base_url},
        "sessions": {"lifetime_minutes": settings.session_ttl_minutes, "idle_minutes": settings.session_idle_minutes,
                     "token_replaced_every_minutes": settings.session_rotate_minutes, "transport": "bearer token in the Authorization header (no cookie)"},
        "single_sign_on": {"providers": len(providers), "enabled": sum(1 for p in providers if p["enabled"])},
    }  # fmt: skip


# ----------------------------------------------------------------------------- CRM: OAuth, events from the CRM, reverse ETL
class OAuthConfigBody(Body):
    client_id: str = Field(min_length=1, max_length=300)
    client_secret: str = Field(min_length=1, max_length=2000)
    scopes: list[str] | None = None
    oauth_endpoints: dict[str, str] | None = None
    webhook_secret: str | None = Field(None, min_length=16, max_length=200)


class SyncBody(Body):
    name: str = Field(min_length=1, max_length=160)
    entity: str = "risk_scores"
    destination: str = "export"
    connection_id: int | None = None
    export_format: str | None = "csv"
    field_mapping: dict[str, str] | None = None
    filters: dict[str, Any] | None = None


class DecisionBody(Body):
    approve: bool
    note: str | None = Field(None, max_length=1000)


class SyncRunBody(Body):
    batch_id: int | None = None


class EnabledBody(Body):
    enabled: bool


@router.post("/crm/connections/{connection_id}/oauth", tags=["crm"])
def crm_oauth_configure(connection_id: int, body: OAuthConfigBody, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return crm.connection_view(crm_oauth.configure(s, principal, connection_id, **body.model_dump()))


@router.post("/crm/connections/{connection_id}/oauth/start", tags=["crm"])
def crm_oauth_start(connection_id: int, request: Request, principal: Principal = Depends(require("crm:write"))) -> dict:
    """Returns the CRM's consent URL; the web app opens it."""
    with writing() as s:
        return crm_oauth.begin(s, principal, connection_id, request_base=_request_base(request))


@router.get("/crm/oauth/callback", tags=["crm"], include_in_schema=True)
def crm_oauth_callback(state: str | None = None, code: str | None = None, error: str | None = None) -> RedirectResponse:
    """Where the CRM sends the browser back.  The state ties it to an authorisation that a signed-in user started."""
    try:
        with writing() as s:
            connection = crm_oauth.callback(s, state=state, code=code, error=error)
            target = f"/#/syncs?connected={connection.id}"
    except AppError as exc:
        target = f"/#/syncs?oauth_error={quote(exc.message)}"
    return RedirectResponse(target, status_code=302)


@router.post("/crm/connections/{connection_id}/disconnect", tags=["crm"])
def crm_disconnect(connection_id: int, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return crm.connection_view(crm_oauth.disconnect(s, principal, connection_id))


@router.post("/crm/webhooks/{connection_id}", status_code=202, tags=["crm"], include_in_schema=True)
async def crm_webhook(connection_id: int, request: Request) -> dict:
    """Signed events from the CRM (HubSpot v3 signature, Intercom X-Hub-Signature, or X-Signature with the connection's secret)."""
    ratelimit.enforce("webhook", f"crm:{connection_id}:{client_ip(request)}", get_settings().rate_limit_ip_per_minute)
    body = await request.body()
    url = (get_settings().public_base_url or _request_base(request)).rstrip("/") + request.url.path
    with writing() as s:
        return crm_oauth.receive(s, connection_id, method=request.method, url=url, body=body, headers=dict(request.headers))


@router.get("/crm/connections/{connection_id}/events", tags=["crm"])
def crm_events(connection_id: int, principal: Principal = Depends(require("crm:read"))) -> dict:
    with reading() as s:
        items = crm_oauth.events(s, principal.tenant_id, connection_id)
        return {"items": items, "total": len(items)}


@router.get("/crm/reverse-etl", tags=["crm"])
def reverse_etl_overview(principal: Principal = Depends(require("crm:read"))) -> dict:
    with reading() as s:
        return reverse_etl.overview(s, principal.tenant_id)


@router.post("/crm/reverse-etl/syncs", status_code=201, tags=["crm"])
def reverse_etl_create(body: SyncBody, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return reverse_etl.sync_view(reverse_etl.create(s, principal, body.model_dump()))


@router.post("/crm/reverse-etl/syncs/{sync_id}/submit", tags=["crm"])
def reverse_etl_submit(sync_id: int, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return reverse_etl.sync_view(reverse_etl.submit(s, principal, sync_id))


@router.post("/crm/reverse-etl/syncs/{sync_id}/review", tags=["crm"])
def reverse_etl_review(sync_id: int, body: DecisionBody, principal: Principal = Depends(require("crm:approve"))) -> dict:
    with writing() as s:
        return reverse_etl.sync_view(reverse_etl.review(s, principal, sync_id, approve=body.approve, note=body.note))


@router.post("/crm/reverse-etl/syncs/{sync_id}/enabled", tags=["crm"])
def reverse_etl_enabled(sync_id: int, body: EnabledBody, principal: Principal = Depends(require("crm:approve"))) -> dict:
    with writing() as s:
        return reverse_etl.sync_view(reverse_etl.set_enabled(s, principal, sync_id, body.enabled))


@router.post("/crm/reverse-etl/syncs/{sync_id}/runs", status_code=202, tags=["crm"])
def reverse_etl_run(sync_id: int, body: SyncRunBody, principal: Principal = Depends(require("crm:write")),
                    _limit: None = Depends(limited("sync", "rate_limit_sync_per_minute"))) -> dict:
    with writing() as s:
        run, job = reverse_etl.start_run(s, principal, sync_id, body.batch_id)
        return {"run": reverse_etl.run_view(run), "job": job_ref(job)}


@router.post("/crm/reverse-etl/runs/{run_id}/verify", tags=["crm"])
def reverse_etl_verify(run_id: int, principal: Principal = Depends(require("crm:write"))) -> dict:
    with writing() as s:
        return reverse_etl.run_view(reverse_etl.verify(s, principal, run_id))


@router.get("/crm/reverse-etl/runs/{run_id}/download", tags=["crm"])
def reverse_etl_download(run_id: int, principal: Principal = Depends(require("customers:export")),
                         _limit: None = Depends(limited("export", "rate_limit_export_per_minute"))) -> Any:
    from fastapi.responses import Response

    with writing() as s:
        data, name, media = reverse_etl.download(s, principal, run_id)
    return Response(content=data, media_type=media, headers={"Content-Disposition": f'attachment; filename="{name}"'})


# ----------------------------------------------------------------------------- notifications
class NotifyProviderBody(Body):
    name: str = Field(min_length=1, max_length=120)
    channel: str
    provider: str
    config: dict[str, Any] | None = None
    credentials: dict[str, Any] | None = None
    webhook_secret: str | None = Field(None, min_length=16, max_length=200)
    is_default: bool = True


class ModeBody(Body):
    mode: str


class TemplateBody(Body):
    code: str = Field(min_length=2, max_length=80)
    channel: str
    subject: str | None = Field(None, max_length=300)
    body: str = Field(min_length=1, max_length=20000)
    category: str = "marketing"
    locale: str = Field("en", max_length=12)


class TestMessageBody(Body):
    customer_id: int
    channel: str
    template_code: str
    variables: dict[str, Any] | None = None
    recipient: str | None = Field(None, max_length=320)


class LiftBody(Body):
    note: str = Field(min_length=1, max_length=1000)


@router.get("/notifications", tags=["notifications"])
def notifications_overview(days: int = 30, principal: Principal = Depends(require("notify:read"))) -> dict:
    with reading() as s:
        templates = s.execute(select(NotificationTemplate).where(NotificationTemplate.tenant_id == principal.tenant_id)
                              .order_by(NotificationTemplate.code, NotificationTemplate.channel, NotificationTemplate.version.desc())).scalars().all()  # fmt: skip
        suppressions = s.execute(select(NotificationSuppression).where(NotificationSuppression.tenant_id == principal.tenant_id)
                                 .order_by(NotificationSuppression.id.desc()).limit(100)).scalars().all()  # fmt: skip
        return {**notify.overview(s, principal.tenant_id, days), "templates": [notify.template_view(t) for t in templates],
                "suppression_list": [to_dict(x) for x in suppressions], "variables": list(notify.VARIABLES),
                "providers_by_channel": {k: list(v) for k, v in notify.PROVIDERS.items()}}  # fmt: skip


@router.get("/notifications/messages", tags=["notifications"])
def notifications_messages(status: str | None = None, channel: str | None = None, campaign_id: int | None = None, customer_id: int | None = None, page: int = 1,
                           page_size: int = 50, principal: Principal = Depends(require("notify:read"))) -> dict:  # fmt: skip
    with reading() as s:
        stmt = notify.messages_query(principal.tenant_id, status=status, channel=channel, campaign_id=campaign_id, customer_id=customer_id)
        return paginate(s, stmt, page=page, page_size=page_size, scalars=False, serializer=notify.message_row_view)


@router.post("/notifications/providers", status_code=201, tags=["notifications"])
def notifications_provider_create(body: NotifyProviderBody, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return notify.provider_view(notify.create_provider(s, principal, **body.model_dump()))


@router.post("/notifications/providers/{provider_id}/mode", tags=["notifications"])
def notifications_provider_mode(provider_id: int, body: ModeBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        return notify.provider_view(notify.set_mode(s, principal, provider_id, body.mode))


@router.post("/notifications/templates", status_code=201, tags=["notifications"])
def notifications_template_create(body: TemplateBody, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return notify.template_view(notify.create_template(s, principal, **body.model_dump()))


@router.post("/notifications/templates/{template_id}/submit", tags=["notifications"])
def notifications_template_submit(template_id: int, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return notify.template_view(notify.submit_template(s, principal, template_id))


@router.post("/notifications/templates/{template_id}/review", tags=["notifications"])
def notifications_template_review(template_id: int, body: DecisionBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        return notify.template_view(notify.review_template(s, principal, template_id, approve=body.approve, note=body.note))


@router.post("/notifications/messages", status_code=201, tags=["notifications"])
def notifications_send_one(body: TestMessageBody, principal: Principal = Depends(require("notify:write"))) -> dict:
    """One message to one customer through the same checks as a campaign (consent, suppression, caps, provider mode)."""
    import secrets as _secrets

    with writing() as s:
        message = notify.send(s, tenant_id=principal.tenant_id, customer_id=body.customer_id, channel=body.channel, template_code=body.template_code,
                              variables=body.variables, recipient=body.recipient, idempotency_key=f"manual:{principal.user_id}:{_secrets.token_hex(8)}",
                              created_by=principal.user_id)  # fmt: skip
        return notify.message_view(message)


@router.post("/notifications/messages/{message_id}/read", tags=["notifications"])
def notifications_mark_read(message_id: int, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return notify.message_view(notify.mark_read(s, principal.tenant_id, message_id))


@router.post("/notifications/suppressions/{suppression_id}/lift", tags=["notifications"])
def notifications_lift(suppression_id: int, body: LiftBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        return to_dict(notify.lift_suppression(s, principal, suppression_id, body.note))


@router.post("/notifications/webhooks/{provider_id}", status_code=202, tags=["notifications"], include_in_schema=True)
async def notifications_webhook(provider_id: int, request: Request) -> dict:
    """Signed delivery events from a message vendor (``X-Signature: sha256=<hex HMAC of the raw body>``)."""
    ratelimit.enforce("webhook", f"notify:{provider_id}:{client_ip(request)}", get_settings().rate_limit_ip_per_minute)
    body = await request.body()
    with writing() as s:
        return notify.receive_events(s, provider_id, body, request.headers.get("x-signature"))


@router.get("/notifications/unsubscribe", tags=["notifications"], include_in_schema=True)
def notifications_unsubscribe(t: str, request: Request) -> Any:
    """The link in a marketing message.  No sign-in: the link itself is the proof."""
    from fastapi.responses import HTMLResponse

    ratelimit.enforce("unsubscribe", client_ip(request) or "unknown", get_settings().rate_limit_login_per_minute)
    with writing() as s:
        notify.unsubscribe(s, t)
    return HTMLResponse("<!doctype html><meta charset=utf-8><title>Unsubscribed</title><p style='font:16px system-ui;margin:3rem'>"
                        "You have been unsubscribed. You will not receive further marketing messages on this channel.</p>")


# ----------------------------------------------------------------------------- campaigns
class CampaignBody(Body):
    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(None, max_length=2000)
    segment: str | None = Field(None, max_length=60)
    action_code: str | None = Field(None, max_length=60)
    offer: dict[str, Any] | None = None
    requires_consent: bool = True
    eligibility: dict[str, Any]
    cooldown_days: int = Field(30, ge=0, le=365)
    ab_test: dict[str, Any] | None = None
    steps: list[dict[str, Any]] = Field(min_length=1, max_length=12)


class PresetBody(Body):
    preset: str


class StartBody(Body):
    dry_run: bool = True


class RunStateBody(Body):
    action: str


@router.get("/campaigns", tags=["campaigns"])
def campaigns_list(principal: Principal = Depends(require("notify:read"))) -> dict:
    with reading() as s:
        items = campaigns.list_campaigns(s, principal.tenant_id)
        return {"items": items, "total": len(items), "presets": {k: {"name": v["name"], "description": v["description"]} for k, v in campaigns.PRESETS.items()}}


@router.post("/campaigns", status_code=201, tags=["campaigns"])
def campaigns_create(body: CampaignBody, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return campaigns.campaign_view(s, campaigns.create(s, principal, body.model_dump()))


@router.post("/campaigns/presets", status_code=201, tags=["campaigns"])
def campaigns_preset(body: PresetBody, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return campaigns.campaign_view(s, campaigns.create_preset(s, principal, body.preset))


@router.get("/campaigns/{campaign_id}", tags=["campaigns"])
def campaigns_detail(campaign_id: int, principal: Principal = Depends(require("notify:read"))) -> dict:
    with reading() as s:
        return campaigns.results(s, principal, campaign_id)


@router.get("/campaigns/{campaign_id}/enrollments", tags=["campaigns"])
def campaigns_enrollments(campaign_id: int, page: int = 1, page_size: int = 50, principal: Principal = Depends(require("notify:read"))) -> dict:
    with reading() as s:
        get_owned(s, Campaign, principal.tenant_id, campaign_id, label="Campaign")
        return paginate(s, campaigns.enrollments_query(principal.tenant_id, campaign_id), page=page, page_size=page_size, scalars=False,
                        serializer=campaigns.enrollment_view)  # fmt: skip


@router.get("/campaigns/{campaign_id}/preview", tags=["campaigns"])
def campaigns_preview(campaign_id: int, principal: Principal = Depends(require("notify:read"))) -> dict:
    with reading() as s:
        return campaigns.preview(s, principal, campaign_id)


@router.post("/campaigns/{campaign_id}/submit", tags=["campaigns"])
def campaigns_submit(campaign_id: int, principal: Principal = Depends(require("notify:write"))) -> dict:
    with writing() as s:
        return campaigns.campaign_view(s, campaigns.submit(s, principal, campaign_id))


@router.post("/campaigns/{campaign_id}/review", tags=["campaigns"])
def campaigns_review(campaign_id: int, body: DecisionBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        return campaigns.campaign_view(s, campaigns.review(s, principal, campaign_id, approve=body.approve, note=body.note))


@router.post("/campaigns/{campaign_id}/start", status_code=202, tags=["campaigns"])
def campaigns_start(campaign_id: int, body: StartBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        out = campaigns.start(s, principal, campaign_id, dry_run=body.dry_run)
        return {**out, "job": {"id": out["job_id"]}}


@router.post("/campaigns/{campaign_id}/state", tags=["campaigns"])
def campaigns_state(campaign_id: int, body: RunStateBody, principal: Principal = Depends(require("notify:approve"))) -> dict:
    with writing() as s:
        return campaigns.campaign_view(s, campaigns.set_run_state(s, principal, campaign_id, body.action))
