"""Data routes: sources, uploads, imports, quarantine, data quality, labels, feature store, analytics."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, File, Request, UploadFile
from pydantic import Field
from sqlalchemy import func, select

from ..config import get_settings
from ..errors import PayloadTooLarge, ValidationFailed
from ..models import (
    ChurnLabel,
    Correction,
    Customer,
    DatasetVersion,
    DataSource,
    DQFinding,
    DQRule,
    DQRun,
    FeatureContract,
    FeatureRun,
    ImportRun,
    LabelRun,
    QuarantineRecord,
)
from ..security import Principal
from ..services import analytics, features, ingestion, labels, quality, schemas
from ..services.common import get_owned, paginate, to_dict
from .deps import Body, authenticated, job_ref, reading, require, writing

router = APIRouter()
WEBHOOK_MAX_BYTES = 5 * 1024 * 1024


# ----------------------------------------------------------------------------- schemas / sources / uploads
class SourceCreate(Body):
    name: str = Field(min_length=1, max_length=120)
    entity_type: str
    kind: str = "file"
    description: str | None = Field(None, max_length=2000)
    config: dict[str, Any] | None = None
    webhook_secret: str | None = Field(None, min_length=16, max_length=200)


class MappingBody(Body):
    mapping: dict[str, Any]


class ImportBody(Body):
    dataset_version_id: int | None = None
    mode: str = "full"


@router.get("/data/schemas", tags=["data"])
def entity_schemas(_: Principal = Depends(require("data:read"))) -> dict:
    return {"load_order": list(schemas.LOAD_ORDER),
            "entities": {name: [{"name": f.name, "type": f.type, "required": f.required} for f in fields]
                         for name, fields in schemas.ENTITY_SCHEMAS.items()}}  # fmt: skip


@router.get("/data/sources", tags=["data"])
def list_sources(principal: Principal = Depends(require("data:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(DataSource).where(DataSource.tenant_id == principal.tenant_id).order_by(DataSource.name)).scalars().all()
        return {"items": [ingestion.source_view(src, ingestion.current_mapping(s, src.id)) for src in rows], "total": len(rows)}


@router.post("/data/sources", status_code=201, tags=["data"])
def create_source(body: SourceCreate, principal: Principal = Depends(require("data:write"))) -> dict:
    with writing() as s:
        source = ingestion.create_source(s, principal, name=body.name, entity_type=body.entity_type, kind=body.kind,
                                         description=body.description, config=body.config, webhook_secret=body.webhook_secret)  # fmt: skip
        return ingestion.source_view(source)


@router.put("/data/sources/{source_id}/mapping", tags=["data"])
def set_mapping(source_id: int, body: MappingBody, principal: Principal = Depends(require("data:write"))) -> dict:
    with writing() as s:
        source = get_owned(s, DataSource, principal.tenant_id, source_id, label="Data source")
        mapping = ingestion.set_mapping(s, principal, source, body.mapping)
        return ingestion.source_view(source, mapping)


@router.post("/data/sources/{source_id}/files", status_code=201, tags=["data"])
def upload_file(source_id: int, file: UploadFile = File(...), principal: Principal = Depends(require("data:write"))) -> dict:
    """Upload a raw file (CSV, TSV, TXT, JSON, JSONL, XLSX, Parquet).  It is hashed, stored
    immutably and registered as a dataset version; nothing is imported until an import is started."""
    from pathlib import Path

    limit = get_settings().max_upload_mb * 1024 * 1024
    name = Path(file.filename or "upload").name
    tmp = ingestion.new_temp_path(Path(name).suffix.lower())
    size = 0
    try:
        with open(tmp, "wb") as out:
            while chunk := file.file.read(1024 * 1024):
                size += len(chunk)
                if size > limit:
                    raise PayloadTooLarge(f"File exceeds the {get_settings().max_upload_mb} MB upload limit")
                out.write(chunk)
        if size == 0:
            raise ValidationFailed("the uploaded file is empty", details={"field": "file"})
        with writing() as s:
            source = get_owned(s, DataSource, principal.tenant_id, source_id, label="Data source")
            version, duplicate = ingestion.register_file(s, source=source, tmp_path=tmp, file_name=name,
                                                         created_by=principal.user_id, actor=principal)  # fmt: skip
            return {"dataset_version": to_dict(version, exclude={"storage_path"}), "already_registered": duplicate,
                    "discovered_schema": source.discovered_schema}  # fmt: skip
    finally:
        tmp.unlink(missing_ok=True)


@router.get("/data/sources/{source_id}/versions", tags=["data"])
def list_versions(source_id: int, page: int = 1, page_size: int = 50, principal: Principal = Depends(require("data:read"))) -> dict:
    with reading() as s:
        get_owned(s, DataSource, principal.tenant_id, source_id, label="Data source")
        stmt = select(DatasetVersion).where(DatasetVersion.source_id == source_id).order_by(DatasetVersion.id.desc())
        return paginate(s, stmt, page=page, page_size=page_size, serializer=lambda v: to_dict(v, exclude={"storage_path"}))


@router.post("/data/sources/{source_id}/imports", status_code=202, tags=["data"])
def start_import(source_id: int, body: ImportBody | None = None, principal: Principal = Depends(require("data:write"))) -> dict:
    body = body or ImportBody()
    with writing() as s:
        run, job = ingestion.start_import(s, principal, source_id, dataset_version_id=body.dataset_version_id, mode=body.mode)
        # a REST source has nothing to import until the pull has fetched it: the import run is created by that job
        return {"import_run": to_dict(run) if run is not None else None, "job": job_ref(job)}


@router.post("/data/sources/{source_id}/pull", status_code=202, tags=["data"])
def start_pull(source_id: int, body: ImportBody | None = None, principal: Principal = Depends(require("data:write"))) -> dict:
    """Fetch a REST source now and import what it returns."""
    with writing() as s:
        source = get_owned(s, DataSource, principal.tenant_id, source_id, label="Data source")
        if source.kind != "rest_api":
            raise ValidationFailed("only REST API sources can be pulled")
        _, job = ingestion.start_import(s, principal, source.id, mode=(body or ImportBody()).mode)
        return {"job": job_ref(job)}


@router.post("/data/webhooks/{source_id}", status_code=202, tags=["data"], include_in_schema=True)
async def webhook(source_id: int, request: Request) -> dict:
    """Signed webhook receiver (HMAC-SHA256 of the raw body in ``X-Signature: sha256=<hex>``).
    Authentication is the shared secret of the source, not a user session."""
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > WEBHOOK_MAX_BYTES:
        raise PayloadTooLarge("Webhook body exceeds 5 MB")
    chunks, size = [], 0
    async for chunk in request.stream():  # an unauthenticated caller never makes the server buffer more than the cap
        size += len(chunk)
        if size > WEBHOOK_MAX_BYTES:
            raise PayloadTooLarge("Webhook body exceeds 5 MB")
        chunks.append(chunk)
    body = b"".join(chunks)
    signature, key = request.headers.get("x-signature"), request.headers.get("idempotency-key")

    def work() -> dict:
        with writing() as s:
            return ingestion.receive_webhook(s, source_id, body, signature, key)

    from starlette.concurrency import run_in_threadpool

    return await run_in_threadpool(work)


@router.get("/data/imports", tags=["data"])
def list_imports(page: int = 1, page_size: int = 50, source_id: int | None = None, principal: Principal = Depends(require("data:read"))) -> dict:
    with reading() as s:
        stmt = select(ImportRun).where(ImportRun.tenant_id == principal.tenant_id)
        if source_id:
            stmt = stmt.where(ImportRun.source_id == source_id)
        return paginate(s, stmt.order_by(ImportRun.id.desc()), page=page, page_size=page_size)


@router.get("/data/imports/{run_id}", tags=["data"])
def get_import(run_id: int, principal: Principal = Depends(require("data:read"))) -> dict:
    with reading() as s:
        return to_dict(get_owned(s, ImportRun, principal.tenant_id, run_id, label="Import run"))


class QuarantineReview(Body):
    ids: list[int] = Field(min_length=1, max_length=1000)
    action: str
    corrected: dict[int, dict[str, Any]] | None = None
    note: str | None = Field(None, max_length=2000)


@router.get("/data/quarantine", tags=["data"])
def list_quarantine(page: int = 1, page_size: int = 50, status: str | None = "open", entity_type: str | None = None,
                    principal: Principal = Depends(require("data:read"))) -> dict:
    with reading() as s:
        stmt = select(QuarantineRecord).where(QuarantineRecord.tenant_id == principal.tenant_id)
        if status:
            stmt = stmt.where(QuarantineRecord.status == status)
        if entity_type:
            stmt = stmt.where(QuarantineRecord.entity_type == entity_type)
        return paginate(s, stmt.order_by(QuarantineRecord.id.desc()), page=page, page_size=page_size)


@router.post("/data/quarantine/review", tags=["data"])
def review_quarantine(body: QuarantineReview, principal: Principal = Depends(require("quality:review"))) -> dict:
    with writing() as s:
        return ingestion.review_quarantine(s, principal, body.ids, body.action, corrected=body.corrected, note=body.note)


@router.get("/data/summary", tags=["data"])
def data_summary(principal: Principal = Depends(require("data:read"))) -> dict:
    from ..models import ENTITY_MODELS

    with reading() as s:
        counts = {name: s.execute(select(func.count()).select_from(model).where(model.tenant_id == principal.tenant_id)).scalar_one()
                  for name, model in ENTITY_MODELS.items()}  # fmt: skip
        open_q = s.execute(select(func.count()).select_from(QuarantineRecord).where(
            QuarantineRecord.tenant_id == principal.tenant_id, QuarantineRecord.status == "open")).scalar_one()  # fmt: skip
        synthetic = s.execute(select(func.count()).select_from(DatasetVersion).where(
            DatasetVersion.tenant_id == principal.tenant_id, DatasetVersion.is_synthetic.is_(True))).scalar_one()  # fmt: skip
        return {"rows": counts, "open_quarantine": open_q, "synthetic_dataset_versions": synthetic, **analytics.headline(s, principal.tenant_id)}


# ----------------------------------------------------------------------------- data quality
class DQStart(Body):
    entity_types: list[str] | None = None


class CorrectionBody(Body):
    entity_type: str
    entity_id: int
    field: str
    new_value: Any = None
    reason: str = Field(min_length=5, max_length=2000)
    finding_id: int | None = None


class ReviewBody(Body):
    approve: bool
    note: str | None = Field(None, max_length=2000)


@router.get("/quality/rules", tags=["quality"])
def list_rules(principal: Principal = Depends(require("quality:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(DQRule).where(DQRule.tenant_id == principal.tenant_id).order_by(DQRule.entity_type, DQRule.name)).scalars().all()
        return {"items": [to_dict(r) for r in rows], "total": len(rows)}


@router.post("/quality/runs", status_code=202, tags=["quality"])
def start_quality(body: DQStart | None = None, principal: Principal = Depends(require("quality:write"))) -> dict:
    with writing() as s:
        run, job = quality.start_run(s, principal, (body or DQStart()).entity_types)
        return {"dq_run": to_dict(run), "job": job_ref(job)}


@router.get("/quality/runs", tags=["quality"])
def list_quality(page: int = 1, page_size: int = 20, principal: Principal = Depends(require("quality:read"))) -> dict:
    with reading() as s:
        return paginate(s, select(DQRun).where(DQRun.tenant_id == principal.tenant_id).order_by(DQRun.id.desc()), page=page, page_size=page_size)


@router.get("/quality/runs/{run_id}/findings", tags=["quality"])
def list_findings(run_id: int, page: int = 1, page_size: int = 50, rule_id: int | None = None,
                  principal: Principal = Depends(require("quality:read"))) -> dict:
    with reading() as s:
        get_owned(s, DQRun, principal.tenant_id, run_id, label="Data-quality run")
        stmt = select(DQFinding).where(DQFinding.run_id == run_id)
        if rule_id:
            stmt = stmt.where(DQFinding.rule_id == rule_id)
        return paginate(s, stmt.order_by(DQFinding.id), page=page, page_size=page_size)


@router.get("/quality/corrections", tags=["quality"])
def list_corrections(page: int = 1, page_size: int = 50, status: str | None = None, principal: Principal = Depends(require("quality:read"))) -> dict:
    with reading() as s:
        stmt = select(Correction).where(Correction.tenant_id == principal.tenant_id)
        if status:
            stmt = stmt.where(Correction.status == status)
        return paginate(s, stmt.order_by(Correction.id.desc()), page=page, page_size=page_size)


@router.post("/quality/corrections", status_code=201, tags=["quality"])
def propose_correction(body: CorrectionBody, principal: Principal = Depends(require("quality:write"))) -> dict:
    with writing() as s:
        return to_dict(quality.propose_correction(s, principal, entity_type=body.entity_type, entity_id=body.entity_id, field=body.field,
                                                  new_value=body.new_value, reason=body.reason, finding_id=body.finding_id))  # fmt: skip


@router.post("/quality/corrections/{correction_id}/review", tags=["quality"])
def review_correction(correction_id: int, body: ReviewBody, principal: Principal = Depends(require("quality:review"))) -> dict:
    with writing() as s:
        return to_dict(quality.review_correction(s, principal, correction_id, approve=body.approve, note=body.note))


# ----------------------------------------------------------------------------- labels
class RangeBody(Body):
    start: str | None = None
    end: str | None = None
    as_of_dates: list[str] | None = None
    policy_id: int | None = None


@router.post("/labels/runs", status_code=202, tags=["labels"])
def start_labels(body: RangeBody, principal: Principal = Depends(require("labels:write"))) -> dict:
    with writing() as s:
        run, job = labels.start_run(s, principal, policy_id=body.policy_id, as_of_dates=body.as_of_dates, start=body.start, end=body.end)
        return {"label_run": to_dict(run), "job": job_ref(job)}


@router.get("/labels/runs", tags=["labels"])
def list_label_runs(page: int = 1, page_size: int = 20, principal: Principal = Depends(require("labels:read"))) -> dict:
    with reading() as s:
        return paginate(s, select(LabelRun).where(LabelRun.tenant_id == principal.tenant_id).order_by(LabelRun.id.desc()), page=page, page_size=page_size)


@router.get("/labels/summary", tags=["labels"])
def label_summary(policy_id: int | None = None, principal: Principal = Depends(require("labels:read"))) -> dict:
    with reading() as s:
        return labels.summary(s, principal.tenant_id, policy_id)


@router.get("/labels", tags=["labels"])
def list_labels(as_of_date: str | None = None, status: str | None = None, page: int = 1, page_size: int = 50,
                principal: Principal = Depends(require("labels:read"))) -> dict:
    from ..services.common import parse_date

    with reading() as s:
        stmt = select(ChurnLabel, Customer).join(Customer, Customer.id == ChurnLabel.customer_id).where(ChurnLabel.tenant_id == principal.tenant_id)
        if as_of_date:
            stmt = stmt.where(ChurnLabel.as_of_date == parse_date(as_of_date, field="as_of_date"))
        if status:
            stmt = stmt.where(ChurnLabel.status == status)
        stmt = stmt.order_by(ChurnLabel.as_of_date.desc(), ChurnLabel.customer_id)
        return paginate(s, stmt, page=page, page_size=page_size, scalars=False, serializer=lambda r: labels.label_view(r[0], r[1]))


# ----------------------------------------------------------------------------- feature store
class ContractCreate(Body):
    name: str = Field("churn_core", min_length=1, max_length=120)
    features: list[str] | None = None
    exclude_snapshot: bool = False


class DecisionBody(Body):
    approve: bool


class MaterializeBody(Body):
    contract_id: int
    start: str | None = None
    end: str | None = None
    as_of_dates: list[str] | None = None
    publish_online: bool = True


@router.get("/features/catalog", tags=["features"])
def feature_catalog(_: Principal = Depends(require("features:read"))) -> dict:
    with reading() as s:
        items = features.catalog_view(s) if features.registry_is_current(s) else None
    if items is None:  # the first call after an upgrade mirrors the code catalog into the registry table
        with writing() as s:
            features.sync_registry(s)
            items = features.catalog_view(s)
    return {"items": items, "total": len(items), "engine_hash": features.feature_engine.engine_hash(),
            "forbidden_source_columns": list(features.feature_engine.FORBIDDEN_SOURCE_COLUMNS)}  # fmt: skip


@router.get("/features/contracts", tags=["features"])
def list_contracts(principal: Principal = Depends(require("features:read"))) -> dict:
    with reading() as s:
        rows = s.execute(select(FeatureContract).where(FeatureContract.tenant_id == principal.tenant_id)
                         .order_by(FeatureContract.name, FeatureContract.version.desc())).scalars().all()  # fmt: skip
        return {"items": [features.contract_view(c) for c in rows], "total": len(rows)}


@router.post("/features/contracts", status_code=201, tags=["features"])
def create_contract(body: ContractCreate, principal: Principal = Depends(require("features:write"))) -> dict:
    with writing() as s:
        return features.contract_view(features.create_contract(s, principal, name=body.name, features=body.features,
                                                               exclude_snapshot=body.exclude_snapshot))  # fmt: skip


@router.post("/features/contracts/{contract_id}/review", tags=["features"])
def review_contract(contract_id: int, body: DecisionBody, principal: Principal = Depends(require("features:approve"))) -> dict:
    with writing() as s:
        return features.contract_view(features.review_contract(s, principal, contract_id, approve=body.approve))


@router.post("/features/materializations", status_code=202, tags=["features"])
def materialize(body: MaterializeBody, principal: Principal = Depends(require("features:write"))) -> dict:
    with writing() as s:
        run, job = features.start_materialization(s, principal, contract_id=body.contract_id, as_of_dates=body.as_of_dates,
                                                  start=body.start, end=body.end, publish_online=body.publish_online)  # fmt: skip
        return {"feature_run": to_dict(run), "job": job_ref(job)}


@router.get("/features/runs", tags=["features"])
def list_feature_runs(page: int = 1, page_size: int = 20, principal: Principal = Depends(require("features:read"))) -> dict:
    with reading() as s:
        return paginate(s, select(FeatureRun).where(FeatureRun.tenant_id == principal.tenant_id).order_by(FeatureRun.id.desc()), page=page, page_size=page_size)


@router.get("/features/store", tags=["features"])
def store_status(principal: Principal = Depends(require("features:read"))) -> dict:
    with reading() as s:
        return features.store_status(s, principal.tenant_id)


@router.get("/features/online/{contract_id}/{customer_id}", tags=["features"])
def online_vector(contract_id: int, customer_id: int, principal: Principal = Depends(require("features:read"))) -> dict:
    with reading() as s:
        get_owned(s, FeatureContract, principal.tenant_id, contract_id, label="Feature contract")
        return features.online_vector(s, principal.tenant_id, contract_id, customer_id)


# ----------------------------------------------------------------------------- analytics
class AnalysisBody(Body):
    kind: str
    segment: str | None = None


@router.post("/analytics/reports", status_code=202, tags=["analytics"])
def start_analysis(body: AnalysisBody, principal: Principal = Depends(require("analytics:run"))) -> dict:
    with writing() as s:
        report, job = analytics.start(s, principal, body.kind, {"segment": body.segment} if body.segment else {})
        return {"report": to_dict(report, exclude={"result"}), "job": job_ref(job)}


@router.get("/analytics/reports/latest", tags=["analytics"])
def latest_analysis(kind: str, segment: str | None = None, principal: Principal = Depends(require("analytics:read"))) -> dict:
    if kind not in analytics.KINDS:
        raise ValidationFailed(f"kind must be one of {', '.join(analytics.KINDS)}", details={"field": "kind"})
    with reading() as s:
        return {"report": analytics.latest(s, principal.tenant_id, kind, segment), "segments": list(analytics.SEGMENTS)}


__all__ = ["authenticated", "router"]
