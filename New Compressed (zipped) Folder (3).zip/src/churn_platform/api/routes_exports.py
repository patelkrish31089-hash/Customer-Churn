"""Export routes: start a delivery, watch it, resume it, reconcile it (1.3.0).

The delivery layer had no caller until these routes existed.  They are thin on purpose — every rule lives in
:mod:`churn_platform.services.exports` — and they exist so that a run is something an operator can start and a
reviewer can read, rather than something only a test can reach.

Permissions: reading a run is ``customers:read``, because a run names its destination, its counts and its watermark and
no customer data; starting, resuming or reconciling one is ``customers:export``, because it moves customer records out
of the platform.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends
from pydantic import Field

from ..security import Principal
from ..services import exports
from .deps import Body, job_ref, limited, reading, require, writing

router = APIRouter()


class ExportStartBody(Body):
    """What to export and where.  ``batch_id`` defaults to the tenant's latest completed batch."""

    destination: str = Field(min_length=1, max_length=40)
    batch_id: int | None = Field(default=None, ge=1)
    limit: int | None = Field(default=None, ge=1, le=200_000)
    full: bool = False


@router.get("/exports/destinations", tags=["exports"])
def export_destinations(principal: Principal = Depends(require("customers:read"))) -> dict:
    """The destinations this installation knows about, and whether each one can be used here."""
    with reading() as s:
        return {"items": exports.overview(s, principal.tenant_id)["destinations"]}


@router.get("/exports/overview", tags=["exports"])
def export_overview(principal: Principal = Depends(require("customers:read"))) -> dict:
    with reading() as s:
        return exports.overview(s, principal.tenant_id)


@router.get("/exports/runs", tags=["exports"])
def export_runs(limit: int = 25, principal: Principal = Depends(require("customers:read"))) -> dict:
    with reading() as s:
        items = exports.list_runs(s, principal.tenant_id, limit=limit)
        return {"items": items, "total": len(items)}


@router.post("/exports/runs", status_code=202, tags=["exports"])
def export_start(body: ExportStartBody, principal: Principal = Depends(require("customers:export")),
                 _limit: None = Depends(limited("export", "rate_limit_export_per_minute"))) -> dict:
    """Start an export run.  The run row is written before the job, so a job that never runs is still visible."""
    with writing() as s:
        run, job = exports.start(s, principal, body.model_dump())
        return {"run": exports.run_view(run), "job": job_ref(job)}


@router.get("/exports/runs/{run_id}", tags=["exports"])
def export_run_detail(run_id: int, principal: Principal = Depends(require("customers:read"))) -> dict:
    with reading() as s:
        run = exports.get_owned_run(s, principal.tenant_id, run_id)
        return {"run": exports.run_view(run), "backlog": exports.outstanding_view(s, principal.tenant_id, run.destination)}


@router.get("/exports/backlog", tags=["exports"])
def export_backlog(destination: str, limit: int = 100, principal: Principal = Depends(require("customers:read"))) -> dict:
    """What is outstanding for one destination: the records a resumed run would send."""
    with reading() as s:
        return exports.outstanding_view(s, principal.tenant_id, destination, limit=limit)


@router.post("/exports/runs/{run_id}/resume", status_code=202, tags=["exports"])
def export_resume(run_id: int, principal: Principal = Depends(require("customers:export")),
                  _limit: None = Depends(limited("export", "rate_limit_export_per_minute"))) -> dict:
    with writing() as s:
        run, job = exports.resume(s, principal, run_id)
        return {"run": exports.run_view(run), "job": job_ref(job)}


@router.post("/exports/runs/{run_id}/reconcile", tags=["exports"])
def export_reconcile(run_id: int, principal: Principal = Depends(require("customers:export"))) -> dict[str, Any]:
    """Ask the destination what it holds for this run and compare it with the recorded acknowledgements."""
    with writing() as s:
        return exports.reconcile_run(s, principal, run_id)
