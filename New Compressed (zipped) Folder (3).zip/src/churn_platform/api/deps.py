"""Request plumbing shared by all routers: authentication, permissions, units of work."""

from __future__ import annotations

import contextlib
from collections.abc import Callable, Iterator
from typing import Any

from fastapi import Depends, Request
from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Session

from ..db import read_session, session_scope
from ..errors import Forbidden, Unauthorized
from ..security import Principal
from ..services import auth


class Body(BaseModel):
    """Base for request bodies: unknown fields are rejected instead of silently ignored."""

    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def bearer_token(request: Request) -> str | None:
    header = request.headers.get("authorization", "")
    scheme, _, token = header.partition(" ")
    return token.strip() or None if scheme.lower() == "bearer" else None


def current_principal(request: Request) -> Principal:
    """Authenticate with the bearer token.  No cookies are used, so there is no CSRF surface."""
    principal = auth.authenticate_token(bearer_token(request))
    request.state.principal = principal
    return principal


def require(*permissions: str) -> Callable[..., Principal]:
    """The caller must hold the permission; with several, any one of them is enough."""
    wanted = " or ".join(f"'{p}'" for p in permissions)

    def dependency(principal: Principal = Depends(current_principal)) -> Principal:
        if principal.mfa_enrollment_required:
            raise Forbidden("Multi-factor authentication must be set up before this account can be used",
                            code="mfa_enrollment_required")  # fmt: skip
        if not any(principal.can(p) for p in permissions):
            raise Forbidden(f"This action requires the {wanted} permission", code="permission_denied")
        return principal

    return dependency


def authenticated(principal: Principal = Depends(current_principal)) -> Principal:
    return principal


@contextlib.contextmanager
def reading() -> Iterator[Session]:
    """Read-only unit of work (never takes SQLite's write lock)."""
    with read_session() as session:
        yield session


@contextlib.contextmanager
def writing() -> Iterator[Session]:
    """Write unit of work: committed before the response is produced, rolled back on any error."""
    with session_scope() as session:
        yield session


def job_ref(job: Any) -> dict | None:
    return None if job is None else {"id": job.id, "job_type": job.job_type, "status": job.status}


def client_ip(request: Request) -> str | None:
    """The client's address; forwarded headers count only when the peer is a configured proxy."""
    from ..netpolicy import client_address

    return client_address(request.client.host if request.client else None, request.headers.get("x-forwarded-for"))


def limited(bucket: str, setting: str) -> Callable[..., None]:
    """Dependency: a per-user limit (per minute, shared by all server processes) on an expensive operation."""

    def dependency(request: Request) -> None:
        from ..config import get_settings
        from ..services import ratelimit

        principal = getattr(request.state, "principal", None)
        subject = f"user:{principal.user_id}" if principal is not None else f"ip:{client_ip(request)}"
        ratelimit.enforce(bucket, subject, int(getattr(get_settings(), setting)))

    return dependency


__all__ = ["Body", "Unauthorized", "authenticated", "bearer_token", "client_ip", "current_principal", "job_ref", "reading",
           "require", "writing"]  # fmt: skip
