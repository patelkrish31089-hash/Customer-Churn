"""Application factory: middleware, error envelope, routers and the static single-page app."""

from __future__ import annotations

import contextlib
import hashlib
import time
from collections.abc import AsyncIterator
from importlib import resources
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, Response
from sqlalchemy import text
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from .. import __version__, netpolicy
from ..config import get_settings
from ..db import get_engine
from ..errors import AppError, PayloadTooLarge
from ..logging_setup import accept_correlation_id, configure_logging, correlation_id_var, get_logger

log = get_logger("api")
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; "
       "object-src 'none'; base-uri 'self'; form-action 'self'")  # fmt: skip


def envelope(status: int, code: str, message: str, details: object = None) -> JSONResponse:
    body = {"error": {"code": code, "message": message, "details": details, "correlation_id": correlation_id_var.get()}}
    return JSONResponse(body, status_code=status)


class BodyLimitMiddleware:
    """Stop reading a request body once it exceeds the limit and answer 413.

    The declared Content-Length is checked first (cheap), but a body sent with chunked transfer encoding declares
    nothing, so the bytes that actually arrive are counted as well.  The read is aborted by raising inside
    ``receive``; whatever the application makes of that aborted read is replaced by the 413 response.
    """

    def __init__(self, app: ASGIApp, max_bytes: int, message: str) -> None:
        self.app, self.max_bytes, self.message = app, max_bytes, message

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        received, exceeded, started = 0, False, False

        async def limited() -> Message:
            nonlocal received, exceeded
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > self.max_bytes:
                    exceeded = True
                    raise PayloadTooLarge(self.message)
            return message

        async def guarded(message: Message) -> None:
            nonlocal started
            if exceeded and not started:
                return  # the application's reaction to the aborted read (e.g. "could not parse the body") is not the answer
            if message["type"] == "http.response.start":
                started = True
            await send(message)

        try:
            await self.app(scope, limited, guarded)
        except PayloadTooLarge:
            if started:
                raise
        if exceeded and not started:
            await envelope(413, "payload_too_large", self.message)(scope, receive, send)


def web_root() -> Path:
    return Path(str(resources.files("churn_platform") / "web"))


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level, settings.log_json)

    @contextlib.asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        get_engine()
        if settings.embedded_worker:
            from ..worker.runner import start_embedded_worker

            start_embedded_worker()
        yield
        if settings.embedded_worker:
            from ..worker.runner import stop_embedded_worker

            stop_embedded_worker()

    docs = not settings.is_production_like
    app = FastAPI(title="Churn Platform API", version=__version__, lifespan=lifespan, docs_url="/api/docs" if docs else None,
                  redoc_url=None, openapi_url="/api/openapi.json" if docs else None)  # fmt: skip

    body_limit = (settings.max_upload_mb + 1) * 1024 * 1024  # one megabyte of slack for multipart framing
    too_large = f"Request body exceeds {settings.max_upload_mb} MB"
    app.add_middleware(BodyLimitMiddleware, max_bytes=body_limit, message=too_large)

    def _limit(request: Request) -> Any:
        """Shared limits that apply before anything else: every request counts against its client address, and
        requests that change something also count against the session that sends them."""
        from ..netpolicy import client_address
        from ..services import ratelimit

        if not settings.rate_limit_enabled:
            return None
        address = client_address(request.client.host if request.client else None, request.headers.get("x-forwarded-for")) or "unknown"
        if request.method in ("GET", "HEAD", "OPTIONS"):
            return None  # reads are not counted in the shared store (one write per read would cost more than the read)
        verdict = ratelimit.hit("ip_write", address, settings.rate_limit_ip_per_minute)
        token = request.headers.get("authorization", "")
        if verdict.allowed and token:
            verdict = ratelimit.hit("session_write", hashlib.sha256(token.encode()).hexdigest()[:32], settings.rate_limit_api_per_minute)
        return verdict

    @app.middleware("http")
    async def _context(request: Request, call_next):  # type: ignore[no-untyped-def]
        correlation_id = accept_correlation_id(request.headers.get("x-correlation-id"))
        token = correlation_id_var.set(correlation_id)
        started = time.perf_counter()
        try:
            declared = request.headers.get("content-length")
            verdict = _limit(request) if request.url.path.startswith("/api/") else None
            if declared and declared.isdigit() and int(declared) > body_limit:
                response: Response = envelope(413, "payload_too_large", too_large)
            elif verdict is not None and not verdict.allowed:
                response = envelope(429, "rate_limited", "Too many requests; wait a minute and try again",
                                    {"retry_after_seconds": verdict.retry_after, "limit_per_minute": verdict.limit})  # fmt: skip
            else:
                response = await call_next(request)
            if verdict is not None:
                response.headers.update(verdict.headers())
        except Exception:  # last-resort guard: never leak internals
            log.exception("unhandled error", extra={"ctx": {"path": request.url.path, "method": request.method}})
            response = envelope(500, "internal_error", "An unexpected error occurred. Quote the correlation id when reporting it.")
        finally:
            correlation_id_var.reset(token)
        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = CSP + ("" if settings.allow_framing else "; frame-ancestors 'none'")
        if not settings.allow_framing:
            response.headers["X-Frame-Options"] = "DENY"
        peer = request.client.host if request.client else None
        if netpolicy.is_secure(request.url.scheme, peer, request.headers.get("x-forwarded-proto")) and settings.hsts_seconds > 0:
            response.headers["Strict-Transport-Security"] = f"max-age={settings.hsts_seconds}; includeSubDomains"
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
            principal = getattr(request.state, "principal", None)
            log.info("request", extra={"ctx": {"method": request.method, "path": request.url.path, "status": response.status_code,
                                               "ms": round((time.perf_counter() - started) * 1000, 1),
                                               "user_id": getattr(principal, "user_id", None),
                                               "tenant_id": getattr(principal, "tenant_id", None)}})  # fmt: skip
        return response

    @app.exception_handler(AppError)
    async def _app_error(_request: Request, exc: AppError) -> JSONResponse:
        response = envelope(exc.status_code, exc.code, exc.message, exc.details)
        if exc.status_code == 429 and isinstance(exc.details, dict) and exc.details.get("retry_after_seconds"):
            response.headers["Retry-After"] = str(int(exc.details["retry_after_seconds"]))  # every refusal says when to come back
        return response

    @app.exception_handler(RequestValidationError)
    async def _validation(_request: Request, exc: RequestValidationError) -> JSONResponse:
        details = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()]
        return envelope(422, "validation_failed", "The request is not valid", details)

    @app.exception_handler(StarletteHTTPException)
    async def _http(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
        codes = {404: "not_found", 405: "method_not_allowed", 413: "payload_too_large", 415: "unsupported_media_type"}
        return envelope(exc.status_code, codes.get(exc.status_code, "http_error"), str(exc.detail))

    @app.get("/healthz", include_in_schema=False)
    def healthz() -> dict:
        return {"status": "ok", "version": __version__}

    @app.get("/readyz", include_in_schema=False)
    def readyz() -> Response:
        try:
            with get_engine().connect() as conn:
                conn.execute(text("SELECT 1"))
        except Exception:
            log.exception("readiness check failed")
            return JSONResponse({"status": "unavailable", "database": "error"}, status_code=503)
        return JSONResponse({"status": "ready", "database": "ok"})

    from . import routes_core, routes_data, routes_exports, routes_ml, routes_platform, routes_signals

    for module in (routes_core, routes_data, routes_platform, routes_ml, routes_signals, routes_exports):
        app.include_router(module.router, prefix="/api/v1")

    @app.api_route("/api/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
    def _api_not_found(rest: str) -> JSONResponse:
        return envelope(404, "not_found", f"No API route matches /api/{rest}")

    root = web_root()

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str) -> Response:
        """Static assets, with the single-page app's index.html for every other path."""
        if path:
            candidate = (root / path).resolve()
            if candidate.is_file() and root.resolve() in candidate.parents:
                headers = {"Cache-Control": "no-cache"}
                return FileResponse(candidate, headers=headers)
            if "." in path.rsplit("/", 1)[-1]:
                return envelope(404, "not_found", "File not found")
        index = root / "index.html"
        if not index.is_file():
            return envelope(404, "not_found", "The web application is not installed")
        return FileResponse(index, headers={"Cache-Control": "no-cache"})

    return app
