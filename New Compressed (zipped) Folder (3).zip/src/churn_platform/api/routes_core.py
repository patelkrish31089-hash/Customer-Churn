"""Core routes: authentication, users, audit trail, jobs, policies and system information."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Query, Request
from pydantic import Field
from sqlalchemy import func, or_, select

from .. import __version__
from ..config import get_settings
from ..db import utcnow
from ..models import AuditEvent, AuthSession, DatasetVersion, Job, Policy, User
from ..security import ROLE_PERMISSIONS, ROLES, Principal
from ..services import audit, auth, jobs, policies, ratelimit
from ..services.common import get_owned, paginate, to_dict
from .deps import Body, authenticated, client_ip, reading, require, writing

router = APIRouter()


def _rate_limit(key: str, account: str | None = None) -> None:
    """Sign-in attempts per minute, per client address and per account, counted in the shared store so that
    every server process sees the same total."""
    settings = get_settings()
    message = "Too many sign-in attempts; wait a minute and try again"
    ratelimit.enforce("login_ip", key, settings.rate_limit_login_per_minute, message)
    if account:
        ratelimit.enforce("login_account", account.strip().lower()[:200], settings.rate_limit_login_account_per_minute, message)


# ----------------------------------------------------------------------------- auth
class LoginBody(Body):
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=1000)
    otp: str | None = Field(None, max_length=12)


class PasswordBody(Body):
    current_password: str = Field(min_length=1, max_length=1000)
    new_password: str = Field(min_length=1, max_length=1000)


class CodeBody(Body):
    code: str = Field(min_length=6, max_length=12)


class SecretBody(Body):
    password: str = Field(min_length=1, max_length=1000)


@router.post("/auth/login", tags=["auth"])
def login(body: LoginBody, request: Request) -> dict:
    _rate_limit(client_ip(request) or "unknown", body.email)
    with writing() as s:
        return auth.login(s, email=body.email, password=body.password, otp=body.otp, ip=client_ip(request),
                          user_agent=request.headers.get("user-agent"))  # fmt: skip


@router.post("/auth/logout", tags=["auth"])
def logout(principal: Principal = Depends(authenticated)) -> dict:
    with writing() as s:
        auth.logout(s, principal)
    return {"ok": True}


@router.get("/auth/me", tags=["auth"])
def me(principal: Principal = Depends(authenticated)) -> dict:
    with reading() as s:
        user = auth.get_user_or_404(s, principal.tenant_id, principal.user_id)
        view = auth.user_view(user)
        view["session"] = auth.session_info(s, principal)
    view["permissions"] = sorted(principal.permissions)
    view["mfa_enrollment_required"] = principal.mfa_enrollment_required
    return view


@router.post("/auth/password", tags=["auth"])
def change_password(body: PasswordBody, principal: Principal = Depends(authenticated)) -> dict:
    with writing() as s:
        auth.change_password(s, principal, body.current_password, body.new_password)
    return {"ok": True}


@router.post("/auth/mfa/begin", tags=["auth"])
def mfa_begin(principal: Principal = Depends(authenticated)) -> dict:
    with writing() as s:
        return auth.mfa_begin(s, principal)


@router.post("/auth/mfa/confirm", tags=["auth"])
def mfa_confirm(body: CodeBody, principal: Principal = Depends(authenticated)) -> dict:
    with writing() as s:
        auth.mfa_confirm(s, principal, body.code)
    return {"ok": True}


@router.post("/auth/mfa/disable", tags=["auth"])
def mfa_disable(body: SecretBody, principal: Principal = Depends(authenticated)) -> dict:
    with writing() as s:
        auth.mfa_disable(s, principal, body.password)
    return {"ok": True}


# ----------------------------------------------------------------------------- users / sessions / audit
class UserCreate(Body):
    email: str = Field(min_length=3, max_length=320)
    full_name: str = Field(min_length=1, max_length=200)
    role: str
    password: str = Field(min_length=1, max_length=1000)


class UserUpdate(Body):
    role: str | None = None
    is_active: bool | None = None
    password: str | None = Field(None, min_length=1, max_length=1000)


@router.get("/admin/users", tags=["admin"])
def list_users(page: int = 1, page_size: int = 50, principal: Principal = Depends(require("admin:users"))) -> dict:
    with reading() as s:
        return paginate(s, select(User).where(User.tenant_id == principal.tenant_id).order_by(User.email), page=page,
                        page_size=page_size, serializer=auth.user_view)  # fmt: skip


@router.post("/admin/users", status_code=201, tags=["admin"])
def create_user(body: UserCreate, principal: Principal = Depends(require("admin:users"))) -> dict:
    with writing() as s:
        user = auth.create_user(s, tenant_id=principal.tenant_id, email=body.email, full_name=body.full_name, role=body.role,
                                password=body.password, actor=principal)  # fmt: skip
        return auth.user_view(user)


@router.patch("/admin/users/{user_id}", tags=["admin"])
def update_user(user_id: int, body: UserUpdate, principal: Principal = Depends(require("admin:users"))) -> dict:
    with writing() as s:
        return auth.user_view(auth.update_user(s, principal, user_id, role=body.role, is_active=body.is_active, password=body.password))


@router.get("/admin/roles", tags=["admin"])
def roles(_: Principal = Depends(authenticated)) -> dict:
    return {"roles": [{"role": r, "permissions": sorted(ROLE_PERMISSIONS[r])} for r in ROLES]}


@router.get("/admin/sessions", tags=["admin"])
def list_sessions(page: int = 1, page_size: int = 50, principal: Principal = Depends(require("admin:sessions"))) -> dict:
    with reading() as s:
        stmt = select(AuthSession).where(AuthSession.tenant_id == principal.tenant_id).order_by(AuthSession.id.desc())
        return paginate(s, stmt, page=page, page_size=page_size)


@router.post("/admin/sessions/{session_id}/revoke", tags=["admin"])
def revoke_session(session_id: int, principal: Principal = Depends(require("admin:sessions"))) -> dict:
    with writing() as s:
        return to_dict(auth.revoke_session(s, principal, session_id))


@router.get("/admin/audit", tags=["admin"])
def list_audit(page: int = 1, page_size: int = 50, action: str | None = None, entity_type: str | None = None,
               principal: Principal = Depends(require("admin:audit"))) -> dict:
    with reading() as s:
        stmt = select(AuditEvent).where(AuditEvent.tenant_id == principal.tenant_id)
        if action:
            stmt = stmt.where(AuditEvent.action.startswith(action, autoescape=True))
        if entity_type:
            stmt = stmt.where(AuditEvent.entity_type == entity_type)
        return paginate(s, stmt.order_by(AuditEvent.seq.desc()), page=page, page_size=page_size)


@router.get("/admin/audit/verify", tags=["admin"])
def verify_audit(principal: Principal = Depends(require("admin:audit"))) -> dict:
    with reading() as s:
        return audit.verify_chain(s, principal.tenant_id)


# ----------------------------------------------------------------------------- jobs
@router.get("/jobs", tags=["jobs"])
def list_jobs(page: int = 1, page_size: int = 50, status: str | None = None, job_type: str | None = None,
              principal: Principal = Depends(require("jobs:read"))) -> dict:
    with reading() as s:
        stmt = select(Job).where(Job.tenant_id == principal.tenant_id)
        if status:
            stmt = stmt.where(Job.status == status)
        if job_type:
            stmt = stmt.where(Job.job_type == job_type)
        return paginate(s, stmt.order_by(Job.id.desc()), page=page, page_size=page_size, serializer=jobs.job_view)


@router.get("/jobs/active", tags=["jobs"])
def active_jobs(principal: Principal = Depends(require("jobs:read"))) -> dict:
    """Work in progress: jobs that are running, and queued jobs that are due within a quarter of an hour (a retry
    waiting for its back-off is work in progress).  Jobs dated further ahead - a campaign step due in three days -
    are counted as ``scheduled``, not listed."""
    soon = utcnow() + timedelta(minutes=15)
    with reading() as s:
        rows = s.execute(select(Job).where(Job.tenant_id == principal.tenant_id, Job.status.in_(("queued", "running")),
                                           or_(Job.status == "running", Job.run_after <= soon))
                         .order_by(Job.id).limit(100)).scalars().all()  # fmt: skip
        scheduled = s.execute(select(func.count()).select_from(Job).where(Job.tenant_id == principal.tenant_id, Job.status == "queued",
                                                                          Job.run_after > soon)).scalar_one()  # fmt: skip
        return {"items": [jobs.job_view(j) for j in rows], "scheduled": scheduled}


@router.get("/jobs/{job_id}", tags=["jobs"])
def get_job(job_id: int, principal: Principal = Depends(require("jobs:read"))) -> dict:
    with reading() as s:
        return jobs.job_view(get_owned(s, Job, principal.tenant_id, job_id, label="Job"))


@router.post("/jobs/{job_id}/cancel", tags=["jobs"])
def cancel_job(job_id: int, principal: Principal = Depends(require("jobs:manage"))) -> dict:
    with writing() as s:
        return jobs.job_view(jobs.request_cancel(s, principal, job_id))


@router.post("/jobs/{job_id}/retry", tags=["jobs"])
def retry_job(job_id: int, principal: Principal = Depends(require("jobs:manage"))) -> dict:
    with writing() as s:
        return jobs.job_view(jobs.retry(s, principal, job_id))


# ----------------------------------------------------------------------------- policies
class PolicyCreate(Body):
    kind: str
    name: str = Field(min_length=1, max_length=120)
    payload: dict[str, Any]
    note: str | None = Field(None, max_length=2000)


class ReviewBody(Body):
    approve: bool
    note: str | None = Field(None, max_length=2000)


@router.get("/policies", tags=["policies"])
def list_policies(kind: str | None = None, status: str | None = None, page: int = 1, page_size: int = 100,
                  principal: Principal = Depends(authenticated)) -> dict:
    with reading() as s:
        stmt = select(Policy).where(Policy.tenant_id == principal.tenant_id)
        if kind:
            stmt = stmt.where(Policy.kind == kind)
        if status:
            stmt = stmt.where(Policy.status == status)
        return paginate(s, stmt.order_by(Policy.kind, Policy.name, Policy.version.desc()), page=page, page_size=page_size,
                        serializer=policies.view)  # fmt: skip


@router.get("/policies/defaults/{kind}", tags=["policies"])
def policy_default(kind: str, _: Principal = Depends(authenticated)) -> dict:
    return {"kind": kind, "payload": policies.default_payload(kind)}


@router.post("/policies", status_code=201, tags=["policies"])
def create_policy(body: PolicyCreate, principal: Principal = Depends(require("policy:write"))) -> dict:
    with writing() as s:
        return policies.view(policies.create(s, principal, kind=body.kind, name=body.name, payload=body.payload, note=body.note))


@router.post("/policies/{policy_id}/submit", tags=["policies"])
def submit_policy(policy_id: int, principal: Principal = Depends(require("policy:write"))) -> dict:
    with writing() as s:
        return policies.view(policies.submit(s, principal, policy_id))


@router.post("/policies/{policy_id}/review", tags=["policies"])
def review_policy(policy_id: int, body: ReviewBody, principal: Principal = Depends(require("policy:approve"))) -> dict:
    with writing() as s:
        return policies.view(policies.review(s, principal, policy_id, approve=body.approve, note=body.note))


# ----------------------------------------------------------------------------- system
@router.get("/system/info", tags=["system"])
def system_info(principal: Principal = Depends(authenticated)) -> dict:
    from ..models import Tenant
    from ..services import training

    settings = get_settings()
    with reading() as s:
        tenant = s.get(Tenant, principal.tenant_id)
        synthetic = s.execute(select(func.count()).select_from(DatasetVersion).where(DatasetVersion.tenant_id == principal.tenant_id,
                                                                                    DatasetVersion.is_synthetic.is_(True))).scalar_one()  # fmt: skip
        info = {"version": __version__, "synthetic_data": synthetic > 0, "environment": settings.env, "tenant": {"id": tenant.id, "slug": tenant.slug, "name": tenant.name},
                "database": "sqlite" if settings.is_sqlite else "postgresql", "self_approval_allowed": settings.allow_self_approval,
                "embedded_worker": settings.embedded_worker, "algorithms": training.algorithm_status(),
                "integrations": {"mlflow_configured": bool(settings.mlflow_tracking_uri), "single_sign_on": "OpenID Connect (authorization code with PKCE); providers are configured per organisation under Administration",
                                 "crm_production_allowed": settings.crm_allow_production}}  # fmt: skip
    return info


__all__ = ["Query", "router"]
