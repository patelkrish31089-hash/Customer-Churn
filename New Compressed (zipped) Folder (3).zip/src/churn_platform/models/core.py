"""Foundation tables: tenants, users, sessions, audit trail, jobs, schedules, governed policies."""

from __future__ import annotations

from sqlalchemy import CheckConstraint, Index, Integer, UniqueConstraint
from sqlalchemy.orm import mapped_column

from .base import Any, Base, Mapped, b, created, datetime, dt, f, fk, i, js, pk, s, tenant_fk, txt

JOB_STATUSES = ("queued", "running", "succeeded", "failed", "cancelled")
POLICY_STATUSES = ("draft", "pending", "approved", "rejected", "retired")
POLICY_KINDS = ("churn_definition", "cost_matrix", "risk_policy", "retention_playbook", "alert_rules", "promotion_gates",
                "activity_definition")  # fmt: skip


class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[int] = pk()
    slug: Mapped[str] = s(64, nullable=False)
    name: Mapped[str] = s(200, nullable=False)
    is_system: Mapped[bool] = b()
    created_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("slug"),)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    email: Mapped[str] = s(320, nullable=False)
    full_name: Mapped[str] = s(200, nullable=False)
    password_hash: Mapped[str | None] = s(400)
    role: Mapped[str] = s(40, nullable=False)
    is_active: Mapped[bool] = b(default=True)
    mfa_enabled: Mapped[bool] = b()
    mfa_secret_enc: Mapped[str | None] = txt()
    mfa_last_counter: Mapped[int | None] = i()
    failed_logins: Mapped[int] = i(nullable=False, default=0)
    locked_until: Mapped[datetime | None] = dt()
    last_login_at: Mapped[datetime | None] = dt()
    password_changed_at: Mapped[datetime | None] = dt()
    created_at: Mapped[datetime] = created()
    # single sign-on (1.1.0): which provider vouches for this account, and under which subject
    identity_provider_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    external_subject: Mapped[str | None] = s(255)
    __table_args__ = (UniqueConstraint("email"),)


class AuthSession(Base):
    __tablename__ = "auth_sessions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    user_id: Mapped[int] = fk("users.id")
    token_hash: Mapped[str] = s(64, nullable=False)
    auth_method: Mapped[str] = s(20, nullable=False, default="password")
    mfa_verified: Mapped[bool] = b()
    ip: Mapped[str | None] = s(64)
    user_agent: Mapped[str | None] = s(300)
    created_at: Mapped[datetime] = created()
    last_seen_at: Mapped[datetime | None] = dt()
    expires_at: Mapped[datetime] = dt(nullable=False)
    revoked_at: Mapped[datetime | None] = dt()
    revoked_reason: Mapped[str | None] = s(100)
    # 1.1.0: token rotation keeps the lineage; a single sign-on session remembers what the provider needs at logout
    rotated_from: Mapped[int | None] = mapped_column(Integer, nullable=True)
    identity_provider_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    id_token_enc: Mapped[str | None] = txt()
    __table_args__ = (UniqueConstraint("token_hash"),)


class AuditEvent(Base):
    """Append-only, hash-chained audit trail (one chain per tenant)."""

    __tablename__ = "audit_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    seq: Mapped[int] = i(nullable=False)
    actor_user_id: Mapped[int | None] = fk("users.id", nullable=True)
    actor_label: Mapped[str] = s(320, nullable=False)
    action: Mapped[str] = s(100, nullable=False, index=True)
    entity_type: Mapped[str | None] = s(60)
    entity_id: Mapped[str | None] = s(100)
    detail: Mapped[Any] = js()
    correlation_id: Mapped[str | None] = s(64)
    created_at: Mapped[datetime] = created()
    prev_hash: Mapped[str] = s(64, nullable=False)
    hash: Mapped[str] = s(64, nullable=False)
    __table_args__ = (
        UniqueConstraint("tenant_id", "seq", name="uq_audit_events_tenant_seq"),
        Index("ix_audit_events_entity", "tenant_id", "entity_type", "entity_id"),
    )


class Job(Base):
    """Durable background job with lease-based ownership."""

    __tablename__ = "jobs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    job_type: Mapped[str] = s(80, nullable=False, index=True)
    payload: Mapped[Any] = js(nullable=False, default=dict)
    status: Mapped[str] = s(20, nullable=False, default="queued")
    priority: Mapped[int] = i(nullable=False, default=0)
    attempts: Mapped[int] = i(nullable=False, default=0)
    max_attempts: Mapped[int] = i(nullable=False, default=3)
    run_after: Mapped[datetime] = dt(nullable=False)
    lease_owner: Mapped[str | None] = s(120)
    lease_expires_at: Mapped[datetime | None] = dt()
    heartbeat_at: Mapped[datetime | None] = dt()
    progress: Mapped[float] = f(nullable=False, default=0.0)
    progress_message: Mapped[str | None] = s(300)
    result: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    idempotency_key: Mapped[str | None] = s(200)
    cancel_requested: Mapped[bool] = b()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    started_at: Mapped[datetime | None] = dt()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "idempotency_key", name="uq_jobs_tenant_idempotency_key"),
        CheckConstraint("status IN ('queued','running','succeeded','failed','cancelled')", name="status_valid"),
        CheckConstraint("progress >= 0 AND progress <= 1", name="progress_range"),
        CheckConstraint("attempts >= 0 AND max_attempts >= 1", name="attempts_valid"),
        Index("ix_jobs_claim", "status", "run_after", "priority"),
    )


class Schedule(Base):
    __tablename__ = "schedules"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    job_type: Mapped[str] = s(80, nullable=False)
    payload: Mapped[Any] = js(nullable=False, default=dict)
    interval_seconds: Mapped[int] = i(nullable=False)
    next_run_at: Mapped[datetime] = dt(nullable=False, index=True)
    last_run_at: Mapped[datetime | None] = dt()
    last_job_id: Mapped[int | None] = i()
    enabled: Mapped[bool] = b(default=True)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_schedules_tenant_name"),
        CheckConstraint("interval_seconds >= 60", name="interval_min"),
    )


class Policy(Base):
    """Versioned business policy that only takes effect after an independent approval.

    kinds: churn_definition, cost_matrix, risk_policy, retention_playbook, alert_rules, promotion_gates,
    activity_definition.
    """

    __tablename__ = "policies"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    kind: Mapped[str] = s(40, nullable=False, index=True)
    name: Mapped[str] = s(120, nullable=False)
    version: Mapped[int] = i(nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    payload: Mapped[Any] = js(nullable=False, default=dict)
    note: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    submitted_at: Mapped[datetime | None] = dt()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "kind", "name", "version", name="uq_policies_identity"),
        CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name="status_valid"),
    )
