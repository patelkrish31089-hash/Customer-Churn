"""Customer signals added in 1.1.0: support sentiment, the governed product-feature catalogue and adoption
facts, the identity mapping behind "daily active users", and the history of slowly changing customer attributes.

Everything here is derived from, or governs the reading of, the canonical tables in ``models.data``; nothing in
this module replaces them.
"""

from __future__ import annotations

from sqlalchemy import CheckConstraint, Index, UniqueConstraint

from .base import Any, Base, Mapped, b, created, d, date, datetime, dt, f, fk, i, js, pk, s, tenant_fk, txt

SENTIMENT_LABELS = ("positive", "negative", "neutral", "mixed", "uncertain")
SENTIMENT_STATES = ("ok", "empty", "too_short", "unsupported_language", "language_undetermined", "error")
ADOPTION_STATES = ("adopted", "not_adopted", "not_eligible", "unknown", "invalid_mapping")
ATTRIBUTE_BASES = ("initial", "effective", "observed", "backfill", "correction")


# ----------------------------------------------------------------------------- sentiment
class SentimentModel(Base):
    """One sentiment model a tenant has scored with: who made it, which exact weights, and whether it is the
    word-list baseline (which is never presented as a trained model)."""

    __tablename__ = "sentiment_models"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    provider: Mapped[str] = s(40, nullable=False)
    model_id: Mapped[str] = s(200, nullable=False)
    model_version: Mapped[str] = s(80, nullable=False)
    tokenizer: Mapped[str | None] = s(200)
    checksum_sha256: Mapped[str] = s(64, nullable=False)
    source: Mapped[str | None] = s(400)
    license: Mapped[str | None] = s(80)
    languages: Mapped[Any] = js(nullable=False, default=list)
    is_baseline: Mapped[bool] = b()
    is_active: Mapped[bool] = b()
    config: Mapped[Any] = js()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "provider", "model_id", "model_version", "checksum_sha256", name="uq_sentiment_models_identity"),
    )


class SentimentRun(Base):
    __tablename__ = "sentiment_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    sentiment_model_id: Mapped[int | None] = fk("sentiment_models.id", nullable=True)
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    status: Mapped[str] = s(20, nullable=False, default="pending")
    trigger: Mapped[str] = s(30, nullable=False, default="manual")
    counts: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (CheckConstraint("status IN ('pending','running','completed','failed')", name="status_valid"),)


class SentimentScore(Base):
    """The sentiment of one support interaction under one model.  ``occurred_at`` is the interaction's own
    timestamp: point-in-time features read the score through it, never through ``scored_at``."""

    __tablename__ = "sentiment_scores"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    interaction_id: Mapped[int] = fk("support_interactions.id")
    customer_id: Mapped[int] = fk("customers.id", index=False)
    sentiment_model_id: Mapped[int] = fk("sentiment_models.id")
    run_id: Mapped[int | None] = fk("sentiment_runs.id", nullable=True, index=False)
    occurred_at: Mapped[datetime] = dt(nullable=False)
    label: Mapped[str] = s(12, nullable=False)
    confidence: Mapped[float | None] = f()
    p_positive: Mapped[float | None] = f()
    p_neutral: Mapped[float | None] = f()
    p_negative: Mapped[float | None] = f()
    score: Mapped[float | None] = f()
    language: Mapped[str | None] = s(12)
    language_confidence: Mapped[float | None] = f()
    state: Mapped[str] = s(30, nullable=False, default="ok")
    error: Mapped[str | None] = txt()
    flags: Mapped[Any] = js()
    text_sha256: Mapped[str | None] = s(64)
    text_chars: Mapped[int | None] = i()
    redactions: Mapped[Any] = js()
    excerpt: Mapped[str | None] = s(300)
    source_record_version: Mapped[int | None] = i()
    source_dataset_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True, index=False)
    scored_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("interaction_id", "sentiment_model_id", name="uq_sentiment_scores_interaction_model"),
        CheckConstraint("label IN ('positive','negative','neutral','mixed','uncertain')", name="label_valid"),
        CheckConstraint("state IN ('ok','empty','too_short','unsupported_language','language_undetermined','error')", name="state_valid"),
        CheckConstraint("confidence IS NULL OR (confidence >= 0 AND confidence <= 1)", name="confidence_range"),
        Index("ix_sentiment_scores_customer_time", "tenant_id", "customer_id", "occurred_at"),
        Index("ix_sentiment_scores_text", "sentiment_model_id", "text_sha256"),
    )


class SentimentEvaluation(Base):
    """Agreement of a sentiment model with a labelled set.  A synthetic set proves the code path and nothing else."""

    __tablename__ = "sentiment_evaluations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    sentiment_model_id: Mapped[int] = fk("sentiment_models.id")
    dataset_name: Mapped[str] = s(200, nullable=False)
    is_synthetic: Mapped[bool] = b()
    rows: Mapped[int] = i(nullable=False, default=0)
    metrics: Mapped[Any] = js()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()


# ----------------------------------------------------------------------------- product-feature catalogue and adoption
class ProductFeature(Base):
    """A governed entry of the product's feature list.  A version only counts once somebody else approved it."""

    __tablename__ = "product_features"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    feature_key: Mapped[str] = s(80, nullable=False)
    version: Mapped[int] = i(nullable=False)
    name: Mapped[str] = s(160, nullable=False)
    description: Mapped[str | None] = txt()
    category: Mapped[str | None] = s(60)
    availability: Mapped[str] = s(20, nullable=False, default="ga")
    required_plan: Mapped[str | None] = s(40)
    release_date: Mapped[date | None] = d()
    retired_date: Mapped[date | None] = d()
    eligibility: Mapped[Any] = js()
    event_mapping: Mapped[Any] = js(nullable=False, default=list)
    adoption_rule: Mapped[Any] = js()
    owner: Mapped[str | None] = s(200)
    is_core: Mapped[bool] = b()
    is_active: Mapped[bool] = b(default=True)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "feature_key", "version", name="uq_product_features_identity"),
        CheckConstraint("availability IN ('ga','beta','limited','deprecated','retired')", name="availability_valid"),
        CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name="status_valid"),
        CheckConstraint("retired_date IS NULL OR release_date IS NULL OR retired_date >= release_date", name="retired_after_release"),
    )


class AdoptionRun(Base):
    __tablename__ = "adoption_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    as_of_date: Mapped[date] = d(nullable=False)
    window_days: Mapped[int] = i(nullable=False, default=30)
    status: Mapped[str] = s(20, nullable=False, default="pending")
    catalog_hash: Mapped[str | None] = s(64)
    result: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        CheckConstraint("status IN ('pending','running','completed','failed')", name="status_valid"),
        CheckConstraint("window_days >= 1 AND window_days <= 365", name="window_range"),
    )


class AdoptionFact(Base):
    """State of one catalogue feature for one customer at the run's as-of date."""

    __tablename__ = "adoption_facts"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    run_id: Mapped[int] = fk("adoption_runs.id")
    customer_id: Mapped[int] = fk("customers.id")
    feature_key: Mapped[str] = s(80, nullable=False)
    state: Mapped[str] = s(20, nullable=False)
    events: Mapped[int] = i(nullable=False, default=0)
    active_days: Mapped[int] = i(nullable=False, default=0)
    users: Mapped[int] = i(nullable=False, default=0)
    first_used_at: Mapped[datetime | None] = dt()
    last_used_at: Mapped[datetime | None] = dt()
    is_new: Mapped[bool] = b()
    is_abandoned: Mapped[bool] = b()
    days_to_first_use: Mapped[float | None] = f()
    __table_args__ = (
        UniqueConstraint("run_id", "customer_id", "feature_key", name="uq_adoption_facts_identity"),
        CheckConstraint("state IN ('adopted','not_adopted','not_eligible','unknown','invalid_mapping')", name="state_valid"),
    )


# ----------------------------------------------------------------------------- identity mapping
class IdentityLink(Base):
    """Maps a user identifier seen in one source to the platform's own key for that person, for a period of time.

    ``user_key`` is what "a user" means everywhere a user is counted (DAU, user-level adoption).  Links in
    quarantine count for nobody until somebody reviewed them.
    """

    __tablename__ = "identity_links"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    user_key: Mapped[str] = s(64, nullable=False)
    source: Mapped[str] = s(60, nullable=False, default="usage_events")
    external_user_id: Mapped[str] = s(200, nullable=False)
    customer_id: Mapped[int | None] = fk("customers.id", nullable=True)
    account_id: Mapped[int | None] = fk("accounts.id", nullable=True, index=False)
    crm_contact_id: Mapped[str | None] = s(120)
    email_hash: Mapped[str | None] = s(64)
    confidence: Mapped[float] = f(nullable=False, default=1.0)
    match_rule: Mapped[str] = s(40, nullable=False, default="source_id")
    status: Mapped[str] = s(20, nullable=False, default="active")
    valid_from: Mapped[datetime | None] = dt()
    valid_to: Mapped[datetime | None] = dt()
    merged_into: Mapped[str | None] = s(64)
    note: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("status IN ('active','quarantined','merged','rejected')", name="status_valid"),
        CheckConstraint("confidence >= 0 AND confidence <= 1", name="confidence_range"),
        CheckConstraint("valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from", name="validity_ordered"),
        Index("ix_identity_links_lookup", "tenant_id", "source", "external_user_id"),
        Index("ix_identity_links_user_key", "tenant_id", "user_key"),
    )


class IdentityMergeCandidate(Base):
    """Two user keys that look like the same person.  Nothing is merged without a decision."""

    __tablename__ = "identity_merge_candidates"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    user_key_a: Mapped[str] = s(64, nullable=False)
    user_key_b: Mapped[str] = s(64, nullable=False)
    reason: Mapped[str] = s(60, nullable=False)
    evidence: Mapped[Any] = js()
    confidence: Mapped[float] = f(nullable=False, default=0.5)
    status: Mapped[str] = s(20, nullable=False, default="open", index=True)
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "user_key_a", "user_key_b", name="uq_identity_merge_candidates_pair"),
        CheckConstraint("status IN ('open','merged','rejected')", name="status_valid"),
    )


class IdentityReconciliation(Base):
    """One pass over the telemetry: links created, conflicts found, and the activity series computed from it."""

    __tablename__ = "identity_reconciliations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    status: Mapped[str] = s(20, nullable=False, default="pending")
    window_days: Mapped[int] = i(nullable=False, default=90)
    result: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (CheckConstraint("status IN ('pending','running','completed','failed')", name="status_valid"),)


# ----------------------------------------------------------------------------- attribute history (SCD type 2)
class CustomerAttributeHistory(Base):
    """One period during which a customer attribute held one value.

    ``valid_from`` / ``valid_to`` say when the value was true in the world (NULL = open on that side);
    ``recorded_at`` says when the platform wrote the row.  A correction never edits a row: it marks it
    superseded and writes the replacement, so what the platform believed at any moment stays answerable.
    """

    __tablename__ = "customer_attribute_history"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    customer_id: Mapped[int] = fk("customers.id")
    attribute: Mapped[str] = s(40, nullable=False)
    value: Mapped[str | None] = s(300)
    valid_from: Mapped[datetime | None] = dt()
    valid_to: Mapped[datetime | None] = dt()
    basis: Mapped[str] = s(20, nullable=False)
    source: Mapped[str] = s(20, nullable=False, default="import")
    dataset_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True, index=False)
    recorded_at: Mapped[datetime] = created()
    recorded_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    superseded_at: Mapped[datetime | None] = dt()
    superseded_by: Mapped[int | None] = i()
    note: Mapped[str | None] = txt()
    __table_args__ = (
        CheckConstraint("basis IN ('initial','effective','observed','backfill','correction')", name="basis_valid"),
        CheckConstraint("valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from", name="validity_ordered"),
        Index("ix_customer_attribute_history_lookup", "tenant_id", "customer_id", "attribute"),
    )


# ----------------------------------------------------------------------------- human annotation of support text
class SentimentAnnotationBatch(Base):
    """A set of support texts handed to people for labelling.

    A batch is *open* while annotators work and *frozen* once it may no longer change: at that point every text has
    two independent labels and every disagreement has been adjudicated.  Only a frozen batch can be exported for
    evaluation, so the numbers `sentiment.evaluate` reports always belong to a set nobody edited afterwards.
    """

    __tablename__ = "sentiment_annotation_batches"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(200, nullable=False)
    description: Mapped[str | None] = txt()
    is_synthetic: Mapped[bool] = b(default=True)  # labels put on generated text are not evidence about real text
    language: Mapped[str | None] = s(12)
    status: Mapped[str] = s(12, nullable=False, default="open")
    rows: Mapped[int] = i(nullable=False, default=0)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    frozen_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_sentiment_annotation_batches_tenant_name"),
        CheckConstraint("status IN ('open','frozen')", name="ck_sentiment_annotation_batches_status"),
    )


class SentimentAnnotationItem(Base):
    """One text of a batch, and the label it ends up with (null until it is agreed or adjudicated)."""

    __tablename__ = "sentiment_annotation_items"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    batch_id: Mapped[int] = fk("sentiment_annotation_batches.id")
    interaction_id: Mapped[int] = fk("support_interactions.id", index=False)
    text_sha256: Mapped[str] = s(64, nullable=False)  # the text is read through the interaction; this fixes what was labelled
    final_label: Mapped[str | None] = s(12)
    decided_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    decided_at: Mapped[datetime | None] = dt()
    __table_args__ = (UniqueConstraint("batch_id", "interaction_id", name="uq_sentiment_annotation_items_batch_interaction"),)


class SentimentAnnotation(Base):
    """One person's label for one text.  A person may change their own mind until the batch is frozen."""

    __tablename__ = "sentiment_annotations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    batch_id: Mapped[int] = fk("sentiment_annotation_batches.id")
    item_id: Mapped[int] = fk("sentiment_annotation_items.id")
    annotator_id: Mapped[int] = fk("users.id")
    label: Mapped[str] = s(12, nullable=False)
    note: Mapped[str | None] = txt()
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("item_id", "annotator_id", name="uq_sentiment_annotations_item_annotator"),
        CheckConstraint("label IN ('positive','negative','neutral','mixed')", name="ck_sentiment_annotations_label"),
    )
