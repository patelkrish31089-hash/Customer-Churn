"""Data catalog, ingestion bookkeeping, canonical (cleaned) entities and data-quality tables.

Raw source files are stored immutably (content-addressed by SHA-256) on disk and described by
``DatasetVersion``; the canonical tables below are the *cleaned* layer and every row carries the
dataset version + source row that last wrote it, with full change history in ``EntityHistory``.
"""

from __future__ import annotations

from sqlalchemy import CheckConstraint, ForeignKey, Index, Integer, UniqueConstraint
from sqlalchemy.orm import mapped_column

from ..db import UTCDateTime, utcnow
from .base import Any, Base, Decimal, Mapped, b, created, d, date, datetime, dt, f, fk, i, js, mon, pk, s, tenant_fk, txt

ENTITY_TYPES = (
    "customers", "accounts", "plans", "subscriptions", "subscription_events", "invoices",
    "payments", "usage_events", "support_interactions", "acquisitions",
)  # fmt: skip


class DataSource(Base):
    __tablename__ = "data_sources"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    entity_type: Mapped[str] = s(40, nullable=False)
    kind: Mapped[str] = s(20, nullable=False, default="file")  # file | rest_api | webhook
    description: Mapped[str | None] = txt()
    config: Mapped[Any] = js(nullable=False, default=dict)
    discovered_schema: Mapped[Any] = js()
    incremental_cursor: Mapped[str | None] = s(200)
    webhook_secret_enc: Mapped[str | None] = txt()
    is_active: Mapped[bool] = b(default=True)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_data_sources_tenant_name"),
        CheckConstraint("kind IN ('file','rest_api','webhook')", name="kind_valid"),
    )


class SourceMapping(Base):
    __tablename__ = "source_mappings"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    source_id: Mapped[int] = fk("data_sources.id")
    version: Mapped[int] = i(nullable=False)
    mapping: Mapped[Any] = js(nullable=False, default=dict)
    is_current: Mapped[bool] = b(default=True)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("source_id", "version", name="uq_source_mappings_source_version"),)


class DatasetVersion(Base):
    """One immutable snapshot of a source's raw data (file upload, REST pull or webhook batch)."""

    __tablename__ = "dataset_versions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    source_id: Mapped[int] = fk("data_sources.id")
    version_no: Mapped[int] = i(nullable=False)
    checksum_sha256: Mapped[str] = s(64, nullable=False)
    file_name: Mapped[str] = s(300, nullable=False)
    file_format: Mapped[str] = s(20, nullable=False)
    size_bytes: Mapped[int] = i(nullable=False)
    row_count: Mapped[int | None] = i()
    schema: Mapped[Any] = js()
    storage_path: Mapped[str] = s(500, nullable=False)
    origin: Mapped[str] = s(20, nullable=False, default="upload")
    is_synthetic: Mapped[bool] = b()
    parent_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "source_id", "checksum_sha256", name="uq_dataset_versions_checksum"),
        UniqueConstraint("source_id", "version_no", name="uq_dataset_versions_source_version"),
    )


class ImportRun(Base):
    __tablename__ = "import_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    source_id: Mapped[int] = fk("data_sources.id")
    dataset_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True)
    mapping_version: Mapped[int | None] = i()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    mode: Mapped[str] = s(20, nullable=False, default="full")
    status: Mapped[str] = s(20, nullable=False, default="pending")
    rows_read: Mapped[int] = i(nullable=False, default=0)
    rows_inserted: Mapped[int] = i(nullable=False, default=0)
    rows_updated: Mapped[int] = i(nullable=False, default=0)
    rows_unchanged: Mapped[int] = i(nullable=False, default=0)
    rows_duplicate: Mapped[int] = i(nullable=False, default=0)
    rows_quarantined: Mapped[int] = i(nullable=False, default=0)
    cursor_before: Mapped[str | None] = s(200)
    cursor_after: Mapped[str | None] = s(200)
    reconciliation: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    started_at: Mapped[datetime | None] = dt()
    finished_at: Mapped[datetime | None] = dt()


class QuarantineRecord(Base):
    __tablename__ = "quarantine_records"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    import_run_id: Mapped[int] = fk("import_runs.id")
    dataset_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True, index=False)
    entity_type: Mapped[str] = s(40, nullable=False)
    row_number: Mapped[int] = i(nullable=False)
    payload: Mapped[Any] = js(nullable=False)
    reasons: Mapped[Any] = js(nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="open", index=True)
    corrected_payload: Mapped[Any] = js()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("status IN ('open','corrected','rejected','reprocessed')", name="status_valid"),
    )


class WebhookEvent(Base):
    __tablename__ = "webhook_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    source_id: Mapped[int | None] = fk("data_sources.id", nullable=True)
    provider: Mapped[str] = s(30, nullable=False, default="generic")
    idempotency_key: Mapped[str] = s(200, nullable=False)
    payload: Mapped[Any] = js(nullable=False)
    signature_valid: Mapped[bool] = b()
    status: Mapped[str] = s(20, nullable=False, default="received")
    error: Mapped[str | None] = txt()
    received_at: Mapped[datetime] = created()
    processed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "provider", "idempotency_key", name="uq_webhook_events_idempotency"),
    )


class ProvenanceMixin:
    """Provenance + versioning carried by every canonical row."""

    dataset_version_id: Mapped[int | None] = mapped_column(ForeignKey("dataset_versions.id"), nullable=True)
    source_row: Mapped[int | None] = mapped_column(Integer, nullable=True)
    record_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, nullable=False, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, nullable=False, default=utcnow)


class Customer(ProvenanceMixin, Base):
    __tablename__ = "customers"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    name: Mapped[str | None] = s(300)
    email: Mapped[str | None] = s(320)
    industry: Mapped[str | None] = s(80)
    company_size: Mapped[str | None] = s(40)
    employee_count: Mapped[int | None] = i()
    country: Mapped[str | None] = s(80)
    region: Mapped[str | None] = s(80)
    acquisition_channel: Mapped[str | None] = s(80)
    acquisition_campaign: Mapped[str | None] = s(120)
    acquired_at: Mapped[datetime | None] = dt()
    consent_marketing: Mapped[bool | None] = b(default=None, nullable=True)
    consent_updated_at: Mapped[datetime | None] = dt()
    # 1.1.0: when the attribute values of this row became true, if the source says so (feeds the attribute history)
    attributes_effective_at: Mapped[datetime | None] = dt()
    # 1.1.0: where text messages go (E.164); empty means the customer cannot be reached by SMS
    phone: Mapped[str | None] = s(40)
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_customers_tenant_external_id"),
        CheckConstraint("employee_count IS NULL OR employee_count >= 0", name="employee_count_non_negative"),
    )


class Account(ProvenanceMixin, Base):
    __tablename__ = "accounts"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    status: Mapped[str | None] = s(30)
    currency: Mapped[str | None] = s(3)
    billing_email: Mapped[str | None] = s(320)
    payment_method_type: Mapped[str | None] = s(40)
    payment_method_expires_on: Mapped[date | None] = d()
    csm_owner: Mapped[str | None] = s(200)
    opened_at: Mapped[datetime | None] = dt()
    closed_at: Mapped[datetime | None] = dt()
    __table_args__ = (UniqueConstraint("tenant_id", "external_id", name="uq_accounts_tenant_external_id"),)


class Plan(ProvenanceMixin, Base):
    __tablename__ = "plans"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    name: Mapped[str | None] = s(200)
    product: Mapped[str | None] = s(120)
    tier: Mapped[str | None] = s(40)
    billing_period: Mapped[str | None] = s(20)
    list_price: Mapped[Decimal | None] = mon()
    currency: Mapped[str | None] = s(3)
    is_active: Mapped[bool] = b(default=True)
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_plans_tenant_external_id"),
        CheckConstraint("list_price IS NULL OR list_price >= 0", name="list_price_non_negative"),
    )


class Subscription(ProvenanceMixin, Base):
    __tablename__ = "subscriptions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    account_id: Mapped[int | None] = fk("accounts.id", nullable=True)
    plan_id: Mapped[int | None] = fk("plans.id", nullable=True)
    status: Mapped[str | None] = s(30)
    billing_period: Mapped[str | None] = s(20)
    started_at: Mapped[datetime] = dt(nullable=False)
    trial_end_at: Mapped[datetime | None] = dt()
    current_period_end: Mapped[datetime | None] = dt()
    cancel_requested_at: Mapped[datetime | None] = dt()
    ended_at: Mapped[datetime | None] = dt()
    end_reason: Mapped[str | None] = s(40)
    mrr: Mapped[Decimal | None] = mon()
    discount_pct: Mapped[float | None] = f()
    auto_renew: Mapped[bool | None] = b(default=None, nullable=True)
    quantity: Mapped[int | None] = i()
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_subscriptions_tenant_external_id"),
        CheckConstraint("ended_at IS NULL OR ended_at >= started_at", name="end_after_start"),
        CheckConstraint("discount_pct IS NULL OR (discount_pct >= 0 AND discount_pct <= 100)", name="discount_range"),
        CheckConstraint("mrr IS NULL OR mrr >= 0", name="mrr_non_negative"),
    )


class SubscriptionEvent(ProvenanceMixin, Base):
    """Lifecycle history used for point-in-time state reconstruction (labels and features)."""

    __tablename__ = "subscription_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    subscription_id: Mapped[int] = fk("subscriptions.id")
    customer_id: Mapped[int] = fk("customers.id")
    event_type: Mapped[str] = s(30, nullable=False)
    occurred_at: Mapped[datetime] = dt(nullable=False, index=True)
    plan_id: Mapped[int | None] = fk("plans.id", nullable=True, index=False)
    mrr: Mapped[Decimal | None] = mon()
    reason: Mapped[str | None] = s(40)
    detail: Mapped[Any] = js()
    is_derived: Mapped[bool] = b()
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_subscription_events_tenant_external_id"),
    )


class Invoice(ProvenanceMixin, Base):
    __tablename__ = "invoices"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    subscription_id: Mapped[int | None] = fk("subscriptions.id", nullable=True)
    issued_at: Mapped[datetime] = dt(nullable=False, index=True)
    due_at: Mapped[datetime | None] = dt()
    paid_at: Mapped[datetime | None] = dt()
    amount: Mapped[Decimal] = mon(nullable=False)
    discount_amount: Mapped[Decimal | None] = mon()
    currency: Mapped[str | None] = s(3)
    status: Mapped[str | None] = s(20)
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_invoices_tenant_external_id"),
        CheckConstraint("amount >= 0", name="amount_non_negative"),
    )


class Payment(ProvenanceMixin, Base):
    __tablename__ = "payments"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    invoice_id: Mapped[int | None] = fk("invoices.id", nullable=True)
    attempted_at: Mapped[datetime] = dt(nullable=False, index=True)
    amount: Mapped[Decimal] = mon(nullable=False)
    status: Mapped[str] = s(20, nullable=False)
    failure_reason: Mapped[str | None] = s(80)
    method: Mapped[str | None] = s(40)
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_payments_tenant_external_id"),
        CheckConstraint("status IN ('succeeded','failed','refunded')", name="status_valid"),
    )


class UsageEvent(ProvenanceMixin, Base):
    __tablename__ = "usage_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id", index=False)
    occurred_at: Mapped[datetime] = dt(nullable=False)
    event_type: Mapped[str] = s(30, nullable=False)
    feature_name: Mapped[str | None] = s(80)
    duration_seconds: Mapped[float | None] = f()
    quantity: Mapped[int] = i(nullable=False, default=1)
    user_ref: Mapped[str | None] = s(120)
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_usage_events_tenant_external_id"),
        # Added by migration 0006 (constraint hardening) - see alembic/versions.
        CheckConstraint("duration_seconds IS NULL OR duration_seconds >= 0", name="duration_non_negative"),
        Index("ix_usage_events_customer_time", "tenant_id", "customer_id", "occurred_at"),
    )


class SupportInteraction(ProvenanceMixin, Base):
    __tablename__ = "support_interactions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    kind: Mapped[str] = s(20, nullable=False, default="ticket")  # ticket | chat | nps_survey
    opened_at: Mapped[datetime] = dt(nullable=False, index=True)
    first_response_at: Mapped[datetime | None] = dt()
    resolved_at: Mapped[datetime | None] = dt()
    priority: Mapped[str | None] = s(20)
    status: Mapped[str | None] = s(20)
    escalated: Mapped[bool] = b()
    category: Mapped[str | None] = s(80)
    channel: Mapped[str | None] = s(40)
    csat: Mapped[float | None] = f()
    nps_score: Mapped[int | None] = i()
    body: Mapped[str | None] = txt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "external_id", name="uq_support_interactions_tenant_external_id"),
        CheckConstraint("nps_score IS NULL OR (nps_score >= 0 AND nps_score <= 10)", name="nps_range"),
        CheckConstraint("resolved_at IS NULL OR resolved_at >= opened_at", name="resolved_after_opened"),
    )


class Acquisition(ProvenanceMixin, Base):
    __tablename__ = "acquisitions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    external_id: Mapped[str] = s(120, nullable=False)
    customer_id: Mapped[int] = fk("customers.id")
    channel: Mapped[str | None] = s(80)
    campaign: Mapped[str | None] = s(120)
    acquired_at: Mapped[datetime | None] = dt()
    cac: Mapped[Decimal | None] = mon()
    __table_args__ = (UniqueConstraint("tenant_id", "external_id", name="uq_acquisitions_tenant_external_id"),)


class EntityHistory(Base):
    """Before/after image of every change to a canonical row (imports, corrections, reprocessing)."""

    __tablename__ = "entity_history"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    entity_type: Mapped[str] = s(40, nullable=False)
    entity_id: Mapped[int] = i(nullable=False)
    record_version: Mapped[int] = i(nullable=False)
    change_source: Mapped[str] = s(20, nullable=False)
    dataset_version_id: Mapped[int | None] = fk("dataset_versions.id", nullable=True, index=False)
    correction_id: Mapped[int | None] = i()
    before: Mapped[Any] = js()
    after: Mapped[Any] = js()
    changed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    changed_at: Mapped[datetime] = created()
    __table_args__ = (Index("ix_entity_history_entity", "tenant_id", "entity_type", "entity_id"),)


class DQRule(Base):
    __tablename__ = "dq_rules"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    version: Mapped[int] = i(nullable=False, default=1)
    entity_type: Mapped[str] = s(40, nullable=False)
    rule_type: Mapped[str] = s(40, nullable=False)
    dimension: Mapped[str] = s(30, nullable=False)
    severity: Mapped[str] = s(20, nullable=False, default="error")
    params: Mapped[Any] = js(nullable=False, default=dict)
    description: Mapped[str | None] = txt()
    is_active: Mapped[bool] = b(default=True)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", "version", name="uq_dq_rules_identity"),
        CheckConstraint("severity IN ('info','warning','error')", name="severity_valid"),
    )


class DQRun(Base):
    __tablename__ = "dq_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    status: Mapped[str] = s(20, nullable=False, default="running")
    scope: Mapped[Any] = js()
    score: Mapped[float | None] = f()
    scorecard: Mapped[Any] = js()
    rules_evaluated: Mapped[int] = i(nullable=False, default=0)
    findings_count: Mapped[int] = i(nullable=False, default=0)
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    started_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()


class DQFinding(Base):
    __tablename__ = "dq_findings"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    run_id: Mapped[int] = fk("dq_runs.id")
    rule_id: Mapped[int] = fk("dq_rules.id")
    rule_name: Mapped[str] = s(120, nullable=False)
    rule_version: Mapped[int] = i(nullable=False)
    entity_type: Mapped[str] = s(40, nullable=False)
    entity_id: Mapped[int | None] = i()
    entity_ref: Mapped[str | None] = s(120)
    severity: Mapped[str] = s(20, nullable=False)
    detail: Mapped[Any] = js()
    status: Mapped[str] = s(20, nullable=False, default="open")


class Correction(Base):
    """A proposed fix to one canonical field; applied only after independent approval."""

    __tablename__ = "corrections"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    entity_type: Mapped[str] = s(40, nullable=False)
    entity_id: Mapped[int] = i(nullable=False)
    field: Mapped[str] = s(80, nullable=False)
    old_value: Mapped[Any] = js()
    new_value: Mapped[Any] = js()
    reason: Mapped[str] = txt(nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="proposed", index=True)
    finding_id: Mapped[int | None] = fk("dq_findings.id", nullable=True, index=False)
    proposed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    proposed_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    applied_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        CheckConstraint("status IN ('proposed','approved','rejected','applied')", name="status_valid"),
    )
