"""Labels, feature store, analytics, ML lifecycle, predictions, retention, CRM and monitoring."""

from __future__ import annotations

from sqlalchemy import Boolean, CheckConstraint, Index, Integer, String, UniqueConstraint, true
from sqlalchemy.orm import mapped_column

from .base import Any, Base, Mapped, b, created, d, date, datetime, dt, f, fk, i, js, pk, s, tenant_fk, txt

LABEL_STATUSES = ("churned", "retained", "immature", "unknown", "ineligible")


# ----------------------------------------------------------------------------- labels
class LabelRun(Base):
    __tablename__ = "label_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    policy_id: Mapped[int] = fk("policies.id")
    as_of_dates: Mapped[Any] = js(nullable=False)
    data_cutoff: Mapped[datetime] = dt(nullable=False)
    counts: Mapped[Any] = js()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()


class ChurnLabel(Base):
    __tablename__ = "churn_labels"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    policy_id: Mapped[int] = fk("policies.id")
    label_run_id: Mapped[int] = fk("label_runs.id")
    customer_id: Mapped[int] = fk("customers.id")
    as_of_date: Mapped[date] = d(nullable=False)
    horizon_days: Mapped[int] = i(nullable=False)
    status: Mapped[str] = s(20, nullable=False)
    label: Mapped[int | None] = i()
    churn_type: Mapped[str | None] = s(20)
    churn_reason: Mapped[str | None] = s(40)
    churn_date: Mapped[date | None] = d()
    detail: Mapped[Any] = js()
    computed_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "policy_id", "customer_id", "as_of_date", name="uq_churn_labels_identity"),
        CheckConstraint("status IN ('churned','retained','immature','unknown','ineligible')", name="status_valid"),
        CheckConstraint(
            "(status = 'churned' AND label = 1) OR (status = 'retained' AND label = 0) "
            "OR (status NOT IN ('churned','retained') AND label IS NULL)",
            name="label_matches_status",
        ),
        Index("ix_churn_labels_asof", "tenant_id", "policy_id", "as_of_date"),
    )


# ----------------------------------------------------------------------------- feature store
class FeatureDefinition(Base):
    """Registry entry mirrored from the code catalog (global; identical for every tenant)."""

    __tablename__ = "feature_definitions"
    id: Mapped[int] = pk()
    name: Mapped[str] = s(80, nullable=False)
    version: Mapped[int] = i(nullable=False)
    group: Mapped[str] = s(40, nullable=False)
    dtype: Mapped[str] = s(20, nullable=False)
    description: Mapped[str] = txt(nullable=False)
    sources: Mapped[Any] = js(nullable=False)
    window_days: Mapped[int | None] = i()
    pit_rule: Mapped[str] = s(200, nullable=False)
    code_hash: Mapped[str] = s(64, nullable=False)
    is_active: Mapped[bool] = b(default=True)
    created_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("name", "version", name="uq_feature_definitions_name_version"),)


class FeatureContract(Base):
    """The approved, ordered feature list that training and inference must both use."""

    __tablename__ = "feature_contracts"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    version: Mapped[int] = i(nullable=False)
    features: Mapped[Any] = js(nullable=False)
    schema_hash: Mapped[str] = s(64, nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", "version", name="uq_feature_contracts_identity"),
        CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name="status_valid"),
    )


class FeatureRun(Base):
    __tablename__ = "feature_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    contract_id: Mapped[int] = fk("feature_contracts.id")
    kind: Mapped[str] = s(20, nullable=False, default="materialize")
    status: Mapped[str] = s(20, nullable=False, default="running")
    as_of_dates: Mapped[Any] = js(nullable=False)
    data_cutoff: Mapped[datetime | None] = dt()
    row_count: Mapped[int] = i(nullable=False, default=0)
    stats: Mapped[Any] = js()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()


class FeatureVector(Base):
    """Offline store: one point-in-time feature vector per customer / as-of date / contract."""

    __tablename__ = "feature_vectors"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    contract_id: Mapped[int] = fk("feature_contracts.id", index=False)
    customer_id: Mapped[int] = fk("customers.id", index=False)
    as_of_date: Mapped[date] = d(nullable=False)
    values: Mapped[Any] = js(nullable=False)
    max_source_ts: Mapped[datetime | None] = dt()
    run_id: Mapped[int] = fk("feature_runs.id")
    computed_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "contract_id", "customer_id", "as_of_date", name="uq_feature_vectors_identity"),
        Index("ix_feature_vectors_asof", "tenant_id", "contract_id", "as_of_date"),
    )


class OnlineFeature(Base):
    """Online store: latest vector per customer for low-latency single predictions."""

    __tablename__ = "online_features"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    contract_id: Mapped[int] = fk("feature_contracts.id", index=False)
    customer_id: Mapped[int] = fk("customers.id", index=False)
    as_of_date: Mapped[date] = d(nullable=False)
    values: Mapped[Any] = js(nullable=False)
    updated_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "contract_id", "customer_id", name="uq_online_features_identity"),
    )


# ----------------------------------------------------------------------------- analytics
class AnalysisReport(Base):
    __tablename__ = "analysis_reports"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    kind: Mapped[str] = s(30, nullable=False, index=True)
    title: Mapped[str] = s(200, nullable=False)
    params: Mapped[Any] = js()
    result: Mapped[Any] = js()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()


# ----------------------------------------------------------------------------- ML lifecycle
class MLDataset(Base):
    __tablename__ = "ml_datasets"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    version: Mapped[int] = i(nullable=False)
    contract_id: Mapped[int] = fk("feature_contracts.id")
    policy_id: Mapped[int] = fk("policies.id")
    config: Mapped[Any] = js(nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="building")
    fingerprint: Mapped[str | None] = s(64)
    row_counts: Mapped[Any] = js()
    class_balance: Mapped[Any] = js()
    leakage_report: Mapped[Any] = js()
    preprocessing: Mapped[Any] = js()
    storage_path: Mapped[str | None] = s(500)
    error: Mapped[str | None] = txt()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("tenant_id", "name", "version", name="uq_ml_datasets_identity"),)


class ModelRun(Base):
    __tablename__ = "model_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    dataset_id: Mapped[int] = fk("ml_datasets.id")
    group_id: Mapped[str] = s(40, nullable=False, index=True)
    algorithm: Mapped[str] = s(40, nullable=False)
    imbalance_strategy: Mapped[str] = s(30, nullable=False)
    is_baseline: Mapped[bool] = b()
    status: Mapped[str] = s(20, nullable=False, default="running")
    params: Mapped[Any] = js()
    search: Mapped[Any] = js()
    cv_metrics: Mapped[Any] = js()
    valid_metrics: Mapped[Any] = js()
    test_metrics: Mapped[Any] = js()
    test_evaluated_at: Mapped[datetime | None] = dt()
    calibration: Mapped[Any] = js()
    artifact_path: Mapped[str | None] = s(500)
    artifact_sha256: Mapped[str | None] = s(64)
    seed: Mapped[int] = i(nullable=False, default=0)
    duration_seconds: Mapped[float | None] = f()
    error: Mapped[str | None] = txt()
    mlflow_run_id: Mapped[str | None] = s(64)
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("status IN ('running','completed','failed','unavailable')", name="status_valid"),
    )


class ModelVersion(Base):
    """Registry entry.  Only ``approval_status='approved'`` + ``stage='production'`` may serve."""

    __tablename__ = "model_versions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    version: Mapped[int] = i(nullable=False)
    model_run_id: Mapped[int] = fk("model_runs.id")
    contract_id: Mapped[int] = fk("feature_contracts.id")
    stage: Mapped[str] = s(20, nullable=False, default="none")
    approval_status: Mapped[str] = s(20, nullable=False, default="pending")
    threshold: Mapped[float | None] = f()
    threshold_basis: Mapped[Any] = js()
    cost_policy_id: Mapped[int | None] = fk("policies.id", nullable=True, index=False)
    mlflow_model_version: Mapped[str | None] = s(40)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    # 1.1.0: the lifecycle state (candidate -> validated -> approved -> staging -> production -> archived) and
    # where the version lives in the MLflow registry when that registry is in use
    lifecycle_state: Mapped[str] = mapped_column(String(20), nullable=False, default="candidate", server_default="candidate")
    validated_at: Mapped[datetime | None] = dt()
    mlflow_registered_name: Mapped[str | None] = s(250)
    mlflow_run_id: Mapped[str | None] = s(64)
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", "version", name="uq_model_versions_identity"),
        CheckConstraint(
            "lifecycle_state IN ('candidate','validated','approved','staging','production','archived','rejected')", name="lifecycle_valid"
        ),
        CheckConstraint("stage IN ('none','staging','production','archived')", name="stage_valid"),
        CheckConstraint("approval_status IN ('pending','approved','rejected')", name="approval_valid"),
        CheckConstraint("stage <> 'production' OR approval_status = 'approved'", name="production_requires_approval"),
        CheckConstraint("threshold IS NULL OR (threshold >= 0 AND threshold <= 1)", name="threshold_range"),
    )


class ModelEvaluation(Base):
    __tablename__ = "model_evaluations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    model_run_id: Mapped[int] = fk("model_runs.id")
    split: Mapped[str] = s(20, nullable=False)
    metrics: Mapped[Any] = js()
    curves: Mapped[Any] = js()
    threshold_analysis: Mapped[Any] = js()
    subgroups: Mapped[Any] = js()
    cost_policy_id: Mapped[int | None] = fk("policies.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (CheckConstraint("split IN ('train','valid','test')", name="split_valid"),)


class PredictionBatch(Base):
    __tablename__ = "prediction_batches"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    model_version_id: Mapped[int] = fk("model_versions.id")
    as_of_date: Mapped[date] = d(nullable=False)
    kind: Mapped[str] = s(20, nullable=False, default="batch")
    status: Mapped[str] = s(20, nullable=False, default="running")
    total: Mapped[int] = i(nullable=False, default=0)
    succeeded: Mapped[int] = i(nullable=False, default=0)
    failed: Mapped[int] = i(nullable=False, default=0)
    decile_cutpoints: Mapped[Any] = js()
    summary: Mapped[Any] = js()
    idempotency_key: Mapped[str] = s(200, nullable=False)
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (UniqueConstraint("tenant_id", "idempotency_key", name="uq_prediction_batches_idempotency"),)


class Prediction(Base):
    __tablename__ = "predictions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    batch_id: Mapped[int] = fk("prediction_batches.id")
    customer_id: Mapped[int] = fk("customers.id")
    model_version_id: Mapped[int] = fk("model_versions.id")
    contract_id: Mapped[int] = fk("feature_contracts.id", index=False)
    as_of_date: Mapped[date] = d(nullable=False)
    horizon_days: Mapped[int] = i(nullable=False, default=30)
    probability: Mapped[float] = f(nullable=False)
    threshold: Mapped[float | None] = f()
    predicted_label: Mapped[int | None] = i()
    risk_tier: Mapped[str | None] = s(20)
    risk_decile: Mapped[int | None] = i()
    top_reasons: Mapped[Any] = js()
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "model_version_id", "customer_id", "as_of_date", name="uq_predictions_identity"),
        CheckConstraint("probability >= 0 AND probability <= 1", name="probability_range"),
        CheckConstraint("risk_decile IS NULL OR (risk_decile >= 1 AND risk_decile <= 10)", name="decile_range"),
    )


class Explanation(Base):
    __tablename__ = "explanations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    scope: Mapped[str] = s(10, nullable=False)  # global | local
    model_run_id: Mapped[int] = fk("model_runs.id")
    model_version_id: Mapped[int | None] = fk("model_versions.id", nullable=True)
    prediction_id: Mapped[int | None] = fk("predictions.id", nullable=True)
    customer_id: Mapped[int | None] = fk("customers.id", nullable=True)
    as_of_date: Mapped[date | None] = d()
    status: Mapped[str] = s(20, nullable=False)  # available | unavailable
    reason: Mapped[str | None] = txt()
    method: Mapped[str | None] = s(60)
    space: Mapped[str | None] = s(20)
    base_value: Mapped[float | None] = f()
    output_value: Mapped[float | None] = f()
    additivity_error: Mapped[float | None] = f()
    contributions: Mapped[Any] = js()
    contract_version: Mapped[str | None] = s(140)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("scope IN ('global','local')", name="scope_valid"),
        CheckConstraint("status IN ('available','unavailable')", name="status_valid"),
    )


# ----------------------------------------------------------------------------- retention
class Campaign(Base):
    __tablename__ = "campaigns"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(160, nullable=False)
    segment: Mapped[str] = s(40, nullable=False)
    action_code: Mapped[str] = s(60, nullable=False)
    channel: Mapped[str] = s(30, nullable=False)
    offer: Mapped[Any] = js()
    requires_consent: Mapped[bool] = b(default=True)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    experiment_id: Mapped[int | None] = i()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    # 1.1.0: ``status`` stays the approval state; ``run_state`` is what the campaign engine is doing with it
    run_state: Mapped[str] = mapped_column(String(20), nullable=False, default="idle", server_default="idle")
    dry_run: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True, server_default=true())
    description: Mapped[str | None] = txt()
    eligibility: Mapped[Any] = js()
    schedule: Mapped[Any] = js()
    cooldown_days: Mapped[int | None] = i()
    frequency_cap: Mapped[Any] = js()
    ab_test: Mapped[Any] = js()
    submitted_at: Mapped[datetime | None] = dt()
    started_at: Mapped[datetime | None] = dt()
    paused_at: Mapped[datetime | None] = dt()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_campaigns_tenant_name"),
        CheckConstraint(
            "status IN ('draft','pending','approved','rejected','running','completed')", name="status_valid"
        ),
        CheckConstraint("run_state IN ('idle','scheduled','running','paused','cancelled','completed')", name="run_state_valid"),
    )


class RetentionRecommendation(Base):
    __tablename__ = "retention_recommendations"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    customer_id: Mapped[int] = fk("customers.id")
    prediction_id: Mapped[int | None] = fk("predictions.id", nullable=True)
    batch_id: Mapped[int | None] = fk("prediction_batches.id", nullable=True)
    playbook_policy_id: Mapped[int | None] = fk("policies.id", nullable=True, index=False)
    campaign_id: Mapped[int | None] = fk("campaigns.id", nullable=True, index=False)
    segment: Mapped[str] = s(40, nullable=False)
    action_code: Mapped[str] = s(60, nullable=False)
    channel: Mapped[str | None] = s(30)
    priority: Mapped[int] = i(nullable=False, default=3)
    rationale: Mapped[Any] = js()
    eligibility: Mapped[Any] = js()
    status: Mapped[str] = s(20, nullable=False, default="proposed", index=True)
    blocked_reason: Mapped[str | None] = s(200)
    assigned_to: Mapped[str | None] = s(200)
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    crm_delivery_id: Mapped[int | None] = i()
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint(
            "status IN ('proposed','approved','dismissed','blocked','executed')", name="status_valid"
        ),
    )


class Intervention(Base):
    """A retention action actually carried out for a customer, and what happened afterwards."""

    __tablename__ = "interventions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    customer_id: Mapped[int] = fk("customers.id")
    recommendation_id: Mapped[int | None] = fk("retention_recommendations.id", nullable=True)
    campaign_id: Mapped[int | None] = fk("campaigns.id", nullable=True, index=False)
    experiment_id: Mapped[int | None] = i()
    action_code: Mapped[str] = s(60, nullable=False)
    channel: Mapped[str | None] = s(30)
    status: Mapped[str] = s(20, nullable=False, default="delivered")
    delivered_at: Mapped[datetime | None] = dt()
    outcome: Mapped[str | None] = s(20)
    outcome_at: Mapped[datetime | None] = dt()
    note: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("outcome IS NULL OR outcome IN ('retained','churned','unknown')", name="outcome_valid"),
    )


class Experiment(Base):
    __tablename__ = "experiments"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(160, nullable=False)
    hypothesis: Mapped[str | None] = txt()
    origin: Mapped[str] = s(20, nullable=False, default="platform")  # platform | imported
    status: Mapped[str] = s(20, nullable=False, default="draft")
    campaign_id: Mapped[int | None] = fk("campaigns.id", nullable=True, index=False)
    treatment_share: Mapped[float] = f(nullable=False, default=0.5)
    alpha: Mapped[float] = f(nullable=False, default=0.05)
    power: Mapped[float] = f(nullable=False, default=0.8)
    baseline_rate: Mapped[float | None] = f()
    min_detectable_effect: Mapped[float | None] = f()
    required_per_arm: Mapped[int | None] = i()
    outcome_window_days: Mapped[int] = i(nullable=False, default=30)
    assignment_salt: Mapped[str] = s(64, nullable=False)
    assigned_at: Mapped[datetime | None] = dt()
    results: Mapped[Any] = js()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_experiments_tenant_name"),
        CheckConstraint("treatment_share > 0 AND treatment_share < 1", name="treatment_share_range"),
        CheckConstraint(
            "status IN ('draft','pending','approved','rejected','running','completed')", name="status_valid"
        ),
    )


class ExperimentAssignment(Base):
    __tablename__ = "experiment_assignments"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    experiment_id: Mapped[int] = fk("experiments.id")
    customer_id: Mapped[int] = fk("customers.id")
    arm: Mapped[str] = s(12, nullable=False)
    assigned_at: Mapped[datetime] = dt(nullable=False)
    delivered: Mapped[bool | None] = b(default=None, nullable=True)
    outcome: Mapped[str | None] = s(20)
    outcome_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("experiment_id", "customer_id", name="uq_experiment_assignments_identity"),
        CheckConstraint("arm IN ('control','treatment')", name="arm_valid"),
        CheckConstraint("outcome IS NULL OR outcome IN ('retained','churned')", name="outcome_valid"),
    )


class UpliftModel(Base):
    __tablename__ = "uplift_models"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    experiment_id: Mapped[int] = fk("experiments.id")
    contract_id: Mapped[int] = fk("feature_contracts.id", index=False)
    method: Mapped[str] = s(40, nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="trained")
    delta: Mapped[float] = f(nullable=False, default=0.02)
    metrics: Mapped[Any] = js()
    validation: Mapped[Any] = js()
    artifact_path: Mapped[str | None] = s(500)
    artifact_sha256: Mapped[str | None] = s(64)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        CheckConstraint(
            "status IN ('trained','validation_failed','validated','approved','rejected')", name="status_valid"
        ),
    )


class UpliftScore(Base):
    __tablename__ = "uplift_scores"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    uplift_model_id: Mapped[int] = fk("uplift_models.id")
    customer_id: Mapped[int] = fk("customers.id")
    as_of_date: Mapped[date] = d(nullable=False)
    p_retain_treated: Mapped[float] = f(nullable=False)
    p_retain_control: Mapped[float] = f(nullable=False)
    uplift: Mapped[float] = f(nullable=False)
    segment: Mapped[str] = s(20, nullable=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("uplift_model_id", "customer_id", "as_of_date", name="uq_uplift_scores_identity"),
        CheckConstraint(
            "segment IN ('persuadable','sure_thing','lost_cause','sleeping_dog')", name="segment_valid"
        ),
    )


# ----------------------------------------------------------------------------- CRM
class CRMConnection(Base):
    __tablename__ = "crm_connections"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    provider: Mapped[str] = s(20, nullable=False)
    name: Mapped[str] = s(120, nullable=False)
    mode: Mapped[str] = s(12, nullable=False, default="TEST_ONLY")
    base_url: Mapped[str] = s(400, nullable=False)
    credentials_enc: Mapped[str | None] = txt()
    field_mapping: Mapped[Any] = js()
    status: Mapped[str] = s(20, nullable=False, default="unverified")
    last_checked_at: Mapped[datetime | None] = dt()
    last_error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    # 1.1.0: OAuth (client, refresh token, expiry, granted scopes), the vendor profile, webhooks, health
    auth_type: Mapped[str] = mapped_column(String(12), nullable=False, default="token", server_default="token")
    profile: Mapped[str | None] = s(40)
    client_id: Mapped[str | None] = s(300)
    client_secret_enc: Mapped[str | None] = txt()
    refresh_token_enc: Mapped[str | None] = txt()
    token_expires_at: Mapped[datetime | None] = dt()
    scopes: Mapped[Any] = js()
    oauth_endpoints: Mapped[Any] = js()
    webhook_secret_enc: Mapped[str | None] = txt()
    health: Mapped[Any] = js()
    disconnected_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_crm_connections_tenant_name"),
        CheckConstraint("auth_type IN ('token','oauth')", name="auth_type_valid"),
        CheckConstraint("provider IN ('salesforce','hubspot','intercom')", name="provider_valid"),
        CheckConstraint("mode IN ('TEST_ONLY','SANDBOX','PRODUCTION')", name="mode_valid"),
    )


class CRMContactLink(Base):
    __tablename__ = "crm_contact_links"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    connection_id: Mapped[int] = fk("crm_connections.id")
    customer_id: Mapped[int] = fk("customers.id")
    external_id: Mapped[str] = s(120, nullable=False)
    matched_by: Mapped[str] = s(30, nullable=False)
    synced_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("connection_id", "customer_id", name="uq_crm_contact_links_identity"),)


class CRMDelivery(Base):
    """Outbox row for one CRM write; delivered by the worker with retries and an idempotency key."""

    __tablename__ = "crm_deliveries"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    connection_id: Mapped[int] = fk("crm_connections.id")
    customer_id: Mapped[int | None] = fk("customers.id", nullable=True)
    kind: Mapped[str] = s(20, nullable=False)
    payload: Mapped[Any] = js(nullable=False)
    idempotency_key: Mapped[str] = s(200, nullable=False)
    status: Mapped[str] = s(12, nullable=False, default="pending", index=True)
    attempts: Mapped[int] = i(nullable=False, default=0)
    next_attempt_at: Mapped[datetime | None] = dt()
    external_id: Mapped[str | None] = s(120)
    last_error: Mapped[str | None] = txt()
    response: Mapped[Any] = js()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    sent_at: Mapped[datetime | None] = dt()
    # 1.1.0: the reverse-ETL run that queued it, and the outcome of reading the record back from the CRM
    sync_run_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    verified_at: Mapped[datetime | None] = dt()
    verification: Mapped[Any] = js()
    __table_args__ = (
        UniqueConstraint("tenant_id", "idempotency_key", name="uq_crm_deliveries_idempotency"),
        CheckConstraint("kind IN ('risk_score','task','note','action')", name="kind_valid"),
        CheckConstraint("status IN ('pending','sent','failed','dead','skipped')", name="status_valid"),
    )


# ----------------------------------------------------------------------------- monitoring
class DriftReport(Base):
    __tablename__ = "drift_reports"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    kind: Mapped[str] = s(20, nullable=False)
    engine: Mapped[str] = s(20, nullable=False, default="native")
    model_version_id: Mapped[int | None] = fk("model_versions.id", nullable=True)
    status: Mapped[str] = s(20, nullable=False)
    reference: Mapped[Any] = js()
    current: Mapped[Any] = js()
    result: Mapped[Any] = js()
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        CheckConstraint("kind IN ('feature','prediction','data_quality','concept')", name="kind_valid"),
        CheckConstraint("status IN ('ok','warning','alert','insufficient_data')", name="status_valid"),
    )


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    kind: Mapped[str] = s(40, nullable=False)
    severity: Mapped[str] = s(20, nullable=False)
    title: Mapped[str] = s(200, nullable=False)
    message: Mapped[str | None] = txt()
    source_type: Mapped[str | None] = s(40)
    source_id: Mapped[int | None] = i()
    detail: Mapped[Any] = js()
    status: Mapped[str] = s(20, nullable=False, default="open", index=True)
    created_at: Mapped[datetime] = created()
    acknowledged_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    acknowledged_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        CheckConstraint("status IN ('open','acknowledged','resolved')", name="status_valid"),
        CheckConstraint("severity IN ('info','warning','critical')", name="severity_valid"),
    )
