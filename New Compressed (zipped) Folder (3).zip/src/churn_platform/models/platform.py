"""Integration and platform tables added in 1.1.0: orchestrator run history, model lifecycle transitions,
CRM OAuth / webhooks / reverse-ETL syncs, notifications and campaigns, single sign-on and the shared rate limiter.
"""

from __future__ import annotations

from sqlalchemy import CheckConstraint, Index, UniqueConstraint

from .base import Any, Base, Mapped, b, created, d, date, datetime, dt, f, fk, i, js, pk, s, tenant_fk, txt

LIFECYCLE_STATES = ("candidate", "validated", "approved", "staging", "production", "archived", "rejected")
NOTIFICATION_CHANNELS = ("email", "sms", "push", "in_app")
NOTIFICATION_STATUSES = ("queued", "dry_run", "sent", "delivered", "bounced", "complained", "failed", "suppressed", "blocked",
                         "cancelled")  # fmt: skip
CAMPAIGN_RUN_STATES = ("idle", "scheduled", "running", "paused", "cancelled", "completed")


# ----------------------------------------------------------------------------- orchestration and model lifecycle
class OrchestratorRun(Base):
    """One execution of one pipeline step, whoever asked for it (Airflow task, platform schedule, operator).

    ``(tenant_id, step, run_key)`` is the idempotency key: an orchestrator that retries a task, or delivers it
    twice, finds the first execution instead of starting a second one.
    """

    __tablename__ = "orchestrator_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    orchestrator: Mapped[str] = s(20, nullable=False)
    step: Mapped[str] = s(40, nullable=False)
    run_key: Mapped[str] = s(250, nullable=False)
    dag_id: Mapped[str | None] = s(120)
    dag_run_id: Mapped[str | None] = s(250)
    task_id: Mapped[str | None] = s(120)
    as_of_date: Mapped[date | None] = d()
    status: Mapped[str] = s(20, nullable=False, default="running", index=True)
    attempts: Mapped[int] = i(nullable=False, default=1)
    job_ids: Mapped[Any] = js()
    detail: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    started_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "step", "run_key", name="uq_orchestrator_runs_idempotency"),
        CheckConstraint("orchestrator IN ('airflow','platform','operator')", name="orchestrator_valid"),
        CheckConstraint("status IN ('running','succeeded','failed','skipped')", name="status_valid"),
    )


class ModelStageTransition(Base):
    """Every attempted move of a model version through its lifecycle, with the gates that were evaluated.
    A blocked attempt is recorded too: it is the evidence that the gate worked."""

    __tablename__ = "model_stage_transitions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    model_version_id: Mapped[int] = fk("model_versions.id")
    from_state: Mapped[str] = s(20, nullable=False)
    to_state: Mapped[str] = s(20, nullable=False)
    decision: Mapped[str] = s(12, nullable=False)
    gates: Mapped[Any] = js()
    registry_info: Mapped[Any] = js()
    note: Mapped[str | None] = txt()
    actor_user_id: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (CheckConstraint("decision IN ('applied','blocked')", name="decision_valid"),)


# ----------------------------------------------------------------------------- CRM: OAuth, webhooks, reverse ETL
class CRMOAuthState(Base):
    """A pending authorisation-code exchange.  Single use, short lived; the PKCE verifier is stored encrypted."""

    __tablename__ = "crm_oauth_states"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    connection_id: Mapped[int] = fk("crm_connections.id")
    state_hash: Mapped[str] = s(64, nullable=False)
    code_verifier_enc: Mapped[str | None] = txt()
    redirect_uri: Mapped[str] = s(400, nullable=False)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    expires_at: Mapped[datetime] = dt(nullable=False)
    used_at: Mapped[datetime | None] = dt()
    __table_args__ = (UniqueConstraint("state_hash", name="uq_crm_oauth_states_state_hash"),)


class CRMWebhookEvent(Base):
    __tablename__ = "crm_webhook_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    connection_id: Mapped[int] = fk("crm_connections.id")
    event_key: Mapped[str] = s(200, nullable=False)
    event_type: Mapped[str | None] = s(80)
    payload: Mapped[Any] = js(nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="received", index=True)
    attempts: Mapped[int] = i(nullable=False, default=0)
    outcome: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    received_at: Mapped[datetime] = created()
    processed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("connection_id", "event_key", name="uq_crm_webhook_events_idempotency"),
        CheckConstraint("status IN ('received','processed','ignored','failed')", name="status_valid"),
    )


class ReverseEtlSync(Base):
    """A provider-neutral definition of what is pushed where: source rows, filter, field mapping, destination.
    It must be approved by somebody other than its author before it may transmit anything."""

    __tablename__ = "reverse_etl_syncs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(160, nullable=False)
    entity: Mapped[str] = s(30, nullable=False, default="risk_scores")
    destination: Mapped[str] = s(20, nullable=False, default="crm")
    connection_id: Mapped[int | None] = fk("crm_connections.id", nullable=True)
    export_format: Mapped[str | None] = s(10)
    field_mapping: Mapped[Any] = js(nullable=False, default=dict)
    filters: Mapped[Any] = js(nullable=False, default=dict)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    updated_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_reverse_etl_syncs_tenant_name"),
        CheckConstraint("entity IN ('risk_scores','recommendations')", name="entity_valid"),
        CheckConstraint("destination IN ('crm','export')", name="destination_valid"),
        CheckConstraint("status IN ('draft','pending','approved','rejected','disabled')", name="status_valid"),
    )


class ReverseEtlRun(Base):
    __tablename__ = "reverse_etl_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    sync_id: Mapped[int] = fk("reverse_etl_syncs.id")
    batch_id: Mapped[int | None] = fk("prediction_batches.id", nullable=True, index=False)
    job_id: Mapped[int | None] = fk("jobs.id", nullable=True, index=False)
    status: Mapped[str] = s(20, nullable=False, default="pending")
    mode: Mapped[str | None] = s(12)
    rows: Mapped[int] = i(nullable=False, default=0)
    counts: Mapped[Any] = js()
    export_path: Mapped[str | None] = s(500)
    export_sha256: Mapped[str | None] = s(64)
    verification: Mapped[Any] = js()
    error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (CheckConstraint("status IN ('pending','running','completed','failed')", name="status_valid"),)


# ----------------------------------------------------------------------------- notifications
class NotificationProvider(Base):
    """A configured delivery provider.  ``DRY_RUN`` (the default) transmits nothing."""

    __tablename__ = "notification_providers"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    channel: Mapped[str] = s(12, nullable=False)
    provider: Mapped[str] = s(20, nullable=False)
    mode: Mapped[str] = s(12, nullable=False, default="DRY_RUN")
    config: Mapped[Any] = js(nullable=False, default=dict)
    credentials_enc: Mapped[str | None] = txt()
    webhook_secret_enc: Mapped[str | None] = txt()
    status: Mapped[str] = s(20, nullable=False, default="unverified")
    last_checked_at: Mapped[datetime | None] = dt()
    last_error: Mapped[str | None] = txt()
    is_default: Mapped[bool] = b()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_notification_providers_tenant_name"),
        CheckConstraint("channel IN ('email','sms','push','in_app')", name="channel_valid"),
        CheckConstraint("provider IN ('ses','sendgrid','smtp','twilio','fcm','apns','inbox')", name="provider_valid"),
        CheckConstraint("mode IN ('DRY_RUN','SANDBOX','LIVE')", name="mode_valid"),
    )


class NotificationTemplate(Base):
    __tablename__ = "notification_templates"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    code: Mapped[str] = s(80, nullable=False)
    version: Mapped[int] = i(nullable=False)
    channel: Mapped[str] = s(12, nullable=False)
    locale: Mapped[str] = s(12, nullable=False, default="en")
    category: Mapped[str] = s(20, nullable=False, default="marketing")
    subject: Mapped[str | None] = s(300)
    body: Mapped[str] = txt(nullable=False)
    variables: Mapped[Any] = js(nullable=False, default=list)
    status: Mapped[str] = s(20, nullable=False, default="draft")
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    reviewed_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    reviewed_at: Mapped[datetime | None] = dt()
    review_note: Mapped[str | None] = txt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "code", "channel", "locale", "version", name="uq_notification_templates_identity"),
        CheckConstraint("channel IN ('email','sms','push','in_app')", name="channel_valid"),
        CheckConstraint("category IN ('marketing','transactional')", name="category_valid"),
        CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name="status_valid"),
    )


class NotificationMessage(Base):
    """One message to one recipient: the outbox row, its delivery state and - for the in-app channel - the inbox
    entry itself.  ``dry_run`` is a final state of its own and is never counted as sent or delivered."""

    __tablename__ = "notification_messages"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    customer_id: Mapped[int | None] = fk("customers.id", nullable=True)
    channel: Mapped[str] = s(12, nullable=False)
    provider_id: Mapped[int | None] = fk("notification_providers.id", nullable=True, index=False)
    template_id: Mapped[int | None] = fk("notification_templates.id", nullable=True, index=False)
    campaign_id: Mapped[int | None] = fk("campaigns.id", nullable=True)
    enrollment_id: Mapped[int | None] = i()
    step_index: Mapped[int | None] = i()
    variant: Mapped[str | None] = s(20)
    category: Mapped[str] = s(20, nullable=False, default="marketing")
    recipient_enc: Mapped[str | None] = txt()
    recipient_hash: Mapped[str | None] = s(64)
    recipient_hint: Mapped[str | None] = s(80)
    subject: Mapped[str | None] = s(300)
    body: Mapped[str | None] = txt()
    status: Mapped[str] = s(20, nullable=False, default="queued", index=True)
    status_reason: Mapped[str | None] = s(200)
    is_dry_run: Mapped[bool] = b()
    provider_message_id: Mapped[str | None] = s(200)
    idempotency_key: Mapped[str] = s(200, nullable=False)
    attempts: Mapped[int] = i(nullable=False, default=0)
    next_attempt_at: Mapped[datetime | None] = dt()
    request: Mapped[Any] = js()
    response: Mapped[Any] = js()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    sent_at: Mapped[datetime | None] = dt()
    delivered_at: Mapped[datetime | None] = dt()
    read_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "idempotency_key", name="uq_notification_messages_idempotency"),
        CheckConstraint("channel IN ('email','sms','push','in_app')", name="channel_valid"),
        CheckConstraint(
            "status IN ('queued','dry_run','sent','delivered','bounced','complained','failed','suppressed','blocked','cancelled')",
            name="status_valid",
        ),
        CheckConstraint("NOT is_dry_run OR status IN ('queued','dry_run','suppressed','blocked','cancelled')", name="dry_run_never_sent"),
        Index("ix_notification_messages_provider_ref", "tenant_id", "provider_message_id"),
        Index("ix_notification_messages_recipient", "tenant_id", "channel", "recipient_hash"),
    )


class NotificationEvent(Base):
    """A delivery event reported by a provider (delivered, bounce, complaint, unsubscribe)."""

    __tablename__ = "notification_events"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    provider_id: Mapped[int | None] = fk("notification_providers.id", nullable=True, index=False)
    message_id: Mapped[int | None] = fk("notification_messages.id", nullable=True)
    event_type: Mapped[str] = s(30, nullable=False)
    event_key: Mapped[str] = s(200, nullable=False)
    payload: Mapped[Any] = js()
    received_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("tenant_id", "provider_id", "event_key", name="uq_notification_events_idempotency"),)


class NotificationSuppression(Base):
    """An address that must not be written to on a channel (bounce, complaint, unsubscribe, manual, invalid)."""

    __tablename__ = "notification_suppressions"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    channel: Mapped[str] = s(12, nullable=False)
    recipient_hash: Mapped[str] = s(64, nullable=False)
    recipient_hint: Mapped[str | None] = s(80)
    customer_id: Mapped[int | None] = fk("customers.id", nullable=True, index=False)
    reason: Mapped[str] = s(30, nullable=False)
    source: Mapped[str | None] = s(60)
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    lifted_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "channel", "recipient_hash", name="uq_notification_suppressions_identity"),
        CheckConstraint("reason IN ('bounce','complaint','unsubscribe','manual','invalid')", name="reason_valid"),
    )


class NotificationPreference(Base):
    """A customer's own choice per channel and message category.  No row means: no stated preference."""

    __tablename__ = "notification_preferences"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    customer_id: Mapped[int] = fk("customers.id")
    channel: Mapped[str] = s(12, nullable=False)
    category: Mapped[str] = s(20, nullable=False, default="marketing")
    allowed: Mapped[bool] = b(default=True)
    source: Mapped[str | None] = s(60)
    updated_at: Mapped[datetime] = created()
    __table_args__ = (UniqueConstraint("customer_id", "channel", "category", name="uq_notification_preferences_identity"),)


class CampaignStep(Base):
    __tablename__ = "campaign_steps"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    campaign_id: Mapped[int] = fk("campaigns.id")
    step_index: Mapped[int] = i(nullable=False)
    variant: Mapped[str] = s(20, nullable=False, default="A")
    delay_hours: Mapped[float] = f(nullable=False, default=0.0)
    channel: Mapped[str] = s(12, nullable=False)
    template_code: Mapped[str] = s(80, nullable=False)
    __table_args__ = (
        UniqueConstraint("campaign_id", "step_index", "variant", name="uq_campaign_steps_identity"),
        CheckConstraint("delay_hours >= 0", name="delay_non_negative"),
        CheckConstraint("channel IN ('email','sms','push','in_app')", name="channel_valid"),
    )


class CampaignEnrollment(Base):
    __tablename__ = "campaign_enrollments"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    campaign_id: Mapped[int] = fk("campaigns.id")
    customer_id: Mapped[int] = fk("customers.id")
    variant: Mapped[str] = s(20, nullable=False, default="A")
    status: Mapped[str] = s(20, nullable=False, default="active", index=True)
    status_reason: Mapped[str | None] = s(200)
    current_step: Mapped[int] = i(nullable=False, default=0)
    next_step_at: Mapped[datetime | None] = dt()
    source: Mapped[Any] = js()
    outcome: Mapped[Any] = js()
    enrolled_at: Mapped[datetime] = created()
    completed_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("campaign_id", "customer_id", name="uq_campaign_enrollments_identity"),
        CheckConstraint("status IN ('active','completed','cancelled','suppressed','ineligible','control')", name="status_valid"),
    )


# ----------------------------------------------------------------------------- single sign-on and rate limiting
class IdentityProvider(Base):
    """An OpenID Connect provider users of this tenant may sign in through."""

    __tablename__ = "identity_providers"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    name: Mapped[str] = s(120, nullable=False)
    protocol: Mapped[str] = s(10, nullable=False, default="oidc")
    issuer: Mapped[str] = s(400, nullable=False)
    client_id: Mapped[str] = s(300, nullable=False)
    client_secret_enc: Mapped[str | None] = txt()
    scopes: Mapped[str] = s(300, nullable=False, default="openid email profile")
    role_claim: Mapped[str] = s(100, nullable=False, default="groups")
    role_mapping: Mapped[Any] = js(nullable=False, default=dict)
    default_role: Mapped[str | None] = s(40)
    allowed_email_domains: Mapped[Any] = js(nullable=False, default=list)
    auto_provision: Mapped[bool] = b()
    trust_idp_mfa: Mapped[bool] = b()
    enabled: Mapped[bool] = b(default=True)
    metadata_cache: Mapped[Any] = js()
    jwks_cache: Mapped[Any] = js()
    cache_fetched_at: Mapped[datetime | None] = dt()
    last_error: Mapped[str | None] = txt()
    created_by: Mapped[int | None] = fk("users.id", nullable=True, index=False)
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("tenant_id", "name", name="uq_identity_providers_tenant_name"),
        CheckConstraint("protocol IN ('oidc')", name="protocol_valid"),
    )


class OidcLoginState(Base):
    """One sign-in attempt in flight: state, nonce and PKCE verifier (hashed or encrypted), bound to the browser
    that started it; afterwards the single-use code the web app exchanges for its session token."""

    __tablename__ = "oidc_login_states"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    provider_id: Mapped[int] = fk("identity_providers.id")
    state_hash: Mapped[str] = s(64, nullable=False)
    nonce_hash: Mapped[str] = s(64, nullable=False)
    code_verifier_enc: Mapped[str] = txt(nullable=False)
    browser_hash: Mapped[str] = s(64, nullable=False)
    redirect_uri: Mapped[str] = s(400, nullable=False)
    exchange_hash: Mapped[str | None] = s(64)
    session_token_enc: Mapped[str | None] = txt()
    created_at: Mapped[datetime] = created()
    expires_at: Mapped[datetime] = dt(nullable=False)
    used_at: Mapped[datetime | None] = dt()
    exchanged_at: Mapped[datetime | None] = dt()
    __table_args__ = (UniqueConstraint("state_hash", name="uq_oidc_login_states_state_hash"),)


class RateLimitCounter(Base):
    """Shared request counters: one row per (bucket, subject, time window), incremented atomically by every
    server process.  Not tenant data; rows of past windows are deleted by the worker's maintenance pass."""

    __tablename__ = "rate_limit_counters"
    id: Mapped[int] = pk()
    bucket: Mapped[str] = s(40, nullable=False)
    subject: Mapped[str] = s(200, nullable=False)
    window_start: Mapped[int] = i(nullable=False)
    hits: Mapped[int] = i(nullable=False, default=0)
    __table_args__ = (
        UniqueConstraint("bucket", "subject", "window_start", name="uq_rate_limit_counters_identity"),
        Index("ix_rate_limit_counters_window", "window_start"),
    )


# ----------------------------------------------------------------------------- the export outbox (1.3.0)
class ExportRun(Base):
    """One delivery run per tenant and destination: what was selected, what was acknowledged, where the watermark stood.

    ``(tenant_id, destination, run_id)`` is unique, so a retried job updates its own row instead of adding a second
    history of the same run.  The row is the checkpoint's parent: the per-record states that decided these numbers are
    in :class:`ExportOutboxRecord` and can be read back, which is what 1.2.0 could not do — its run recorded a count and
    a checksum taken from the *selection*, with nothing to show which records had actually been accepted.
    """

    __tablename__ = "export_runs"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    destination: Mapped[str] = s(40, nullable=False)
    run_id: Mapped[str] = s(64, nullable=False)
    status: Mapped[str] = s(20, nullable=False, default="pending", index=True)
    records_selected: Mapped[int] = i(nullable=False, default=0)
    records_acknowledged: Mapped[int] = i(nullable=False, default=0)
    records_failed: Mapped[int] = i(nullable=False, default=0)
    records_quarantined: Mapped[int] = i(nullable=False, default=0)
    checksum: Mapped[str | None] = s(64)
    watermark: Mapped[datetime | None] = dt()
    verification: Mapped[Any] = js()
    started_at: Mapped[datetime] = created()
    finished_at: Mapped[datetime | None] = dt()
    __table_args__ = (
        UniqueConstraint("tenant_id", "destination", "run_id", name="uq_export_runs_identity"),
        CheckConstraint("status IN ('pending','running','completed','partial','failed')", name="status_valid"),
    )


class ExportOutboxRecord(Base):
    """One row per record per run: its idempotency key, its state, how many attempts, and what went wrong.

    A record that was acknowledged here will not be sent again by :func:`churn_platform.services.export_outbox.resume`;
    a record that failed is the head of the backlog and stops the tenant's watermark, which is the whole point of
    keeping the state per record rather than inferring it from a batch count.
    """

    __tablename__ = "export_outbox"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    export_run_id: Mapped[int] = fk("export_runs.id", index=True)
    destination: Mapped[str] = s(40, nullable=False)
    identity_key: Mapped[str] = s(400, nullable=False)
    idempotency_key: Mapped[str] = s(600, nullable=False)
    payload_checksum: Mapped[str] = s(64, nullable=False)
    prediction_timestamp: Mapped[datetime | None] = dt()
    status: Mapped[str] = s(20, nullable=False, default="PENDING", index=True)
    attempts: Mapped[int] = i(nullable=False, default=0)
    external_reference: Mapped[str | None] = s(200)
    submitted_at: Mapped[datetime | None] = dt()
    acknowledged_at: Mapped[datetime | None] = dt()
    error_code: Mapped[str | None] = s(80)
    error_description: Mapped[str | None] = txt()
    created_at: Mapped[datetime] = created()
    __table_args__ = (
        UniqueConstraint("destination", "idempotency_key", name="uq_export_outbox_idempotency"),
        Index("ix_export_outbox_tenant_status", "tenant_id", "status"),
        CheckConstraint("status IN ('PENDING','ACKNOWLEDGED','FAILED','QUARANTINED')", name="status_valid"),
    )


class ExportCheckpoint(Base):
    """Where each tenant's export stands: the contiguous acknowledged watermark per destination.

    A single row per tenant and destination.  It only ever moves forward: a run that acknowledges an earlier record
    cannot push the watermark back, because a record that is behind the watermark has already been accepted and the
    destination's merge would only rewrite it.  ``last_run_id`` and ``acknowledged_keys`` say which run moved it, so the
    checkpoint can be explained rather than merely trusted.
    """

    __tablename__ = "export_checkpoints"
    id: Mapped[int] = pk()
    tenant_id: Mapped[int] = tenant_fk()
    destination: Mapped[str] = s(40, nullable=False)
    watermark: Mapped[datetime | None] = dt()
    last_run_id: Mapped[str | None] = s(64)
    acknowledged_keys: Mapped[Any] = js()
    updated_at: Mapped[datetime] = dt()
    __table_args__ = (UniqueConstraint("tenant_id", "destination", name="uq_export_checkpoints_identity"),)


__all__ = [
    "CAMPAIGN_RUN_STATES",
    "LIFECYCLE_STATES",
    "NOTIFICATION_CHANNELS",
    "NOTIFICATION_STATUSES",
    "CRMOAuthState",
    "CRMWebhookEvent",
    "CampaignEnrollment",
    "CampaignStep",
    "ExportCheckpoint",
    "ExportOutboxRecord",
    "ExportRun",
    "IdentityProvider",
    "ModelStageTransition",
    "NotificationEvent",
    "NotificationMessage",
    "NotificationPreference",
    "NotificationProvider",
    "NotificationSuppression",
    "NotificationTemplate",
    "OidcLoginState",
    "OrchestratorRun",
    "RateLimitCounter",
    "ReverseEtlRun",
    "ReverseEtlSync",
]  # fmt: skip
