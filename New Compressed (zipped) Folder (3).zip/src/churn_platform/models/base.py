"""Column helpers shared by every model module."""

from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import Boolean, Date, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ..db import Base, JSONType, Money, UTCDateTime, utcnow

__all__ = [
    "Any",
    "Base",
    "Decimal",
    "Mapped",
    "b",
    "created",
    "d",
    "date",
    "datetime",
    "dt",
    "f",
    "fk",
    "i",
    "js",
    "mon",
    "pk",
    "s",
    "tenant_fk",
    "txt",
]  # fmt: skip


def pk() -> Mapped[int]:
    return mapped_column(Integer, primary_key=True, autoincrement=True)


def tenant_fk() -> Mapped[int]:
    return mapped_column(ForeignKey("tenants.id"), nullable=False, index=True)


def fk(target: str, *, nullable: bool = False, index: bool = True) -> Mapped[Any]:
    return mapped_column(ForeignKey(target), nullable=nullable, index=index)


def s(length: int = 255, *, nullable: bool = True, default: Any = None, index: bool = False) -> Mapped[Any]:
    return mapped_column(String(length), nullable=nullable, default=default, index=index)


def txt(*, nullable: bool = True) -> Mapped[Any]:
    return mapped_column(Text, nullable=nullable)


def i(*, nullable: bool = True, default: Any = None) -> Mapped[Any]:
    return mapped_column(Integer, nullable=nullable, default=default)


def f(*, nullable: bool = True, default: Any = None) -> Mapped[Any]:
    return mapped_column(Float, nullable=nullable, default=default)


def b(*, default: bool | None = False, nullable: bool = False) -> Mapped[Any]:
    return mapped_column(Boolean, nullable=nullable, default=default)


def js(*, nullable: bool = True, default: Any = None) -> Mapped[Any]:
    return mapped_column(JSONType, nullable=nullable, default=default)


def dt(*, nullable: bool = True, index: bool = False) -> Mapped[Any]:
    return mapped_column(UTCDateTime, nullable=nullable, index=index)


def d(*, nullable: bool = True, index: bool = False) -> Mapped[Any]:
    return mapped_column(Date, nullable=nullable, index=index)


def created() -> Mapped[datetime]:
    return mapped_column(UTCDateTime, nullable=False, default=utcnow)


def mon(*, nullable: bool = True) -> Mapped[Any]:
    return mapped_column(Money, nullable=nullable)
