"""Structured logging with correlation IDs and secret redaction."""

from __future__ import annotations

import json
import logging
import re
import sys
import uuid
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import Any

correlation_id_var: ContextVar[str | None] = ContextVar("correlation_id", default=None)

_SENSITIVE_KEY = re.compile(
    r"(password|passwd|passphrase|secret|token|authorization|api[_-]?key|credential|cookie|(?:^|[_-])otp(?:$|[_-]))", re.I
)
# Free text: "Authorization: <scheme> <value>", "Bearer <value>", "<name>=<value>" pairs and URL userinfo.
_SENSITIVE_TEXT = re.compile(
    r"(?i)(\bauthorization:\s*(?:(?:bearer|basic|digest|token|apikey)\s+)?|\bbearer\s+"
    r"|(?:password|passwd|pwd|secret|token|api[_-]?key)=)([^\s&,;\"']+)"
)
_URL_USERINFO = re.compile(r"(://[^\s/:@]+:)([^\s/@]+)(?=@)")
_CORRELATION_OK = re.compile(r"^[A-Za-z0-9._-]{8,64}$")
REDACTED = "[REDACTED]"


def new_correlation_id() -> str:
    return uuid.uuid4().hex


def accept_correlation_id(candidate: str | None) -> str:
    """Use a caller-supplied ID only if it is safe to echo into logs and headers."""
    return candidate if candidate and _CORRELATION_OK.match(candidate) else new_correlation_id()


def redact(value: Any, _depth: int = 0) -> Any:
    """Recursively mask secrets in dict keys and in free text."""
    if _depth > 6:
        return value
    if isinstance(value, dict):
        return {k: (REDACTED if _SENSITIVE_KEY.search(str(k)) else redact(v, _depth + 1)) for k, v in value.items()}
    if isinstance(value, list | tuple):
        return [redact(v, _depth + 1) for v in value]
    if isinstance(value, str):
        return _URL_USERINFO.sub(lambda m: m.group(1) + REDACTED, _SENSITIVE_TEXT.sub(lambda m: m.group(1) + REDACTED, value))
    return value


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, UTC).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "message": redact(record.getMessage()),
            "correlation_id": correlation_id_var.get(),
        }
        extra = getattr(record, "ctx", None)
        if isinstance(extra, dict):
            payload.update(redact(extra))
        if record.exc_info:
            payload["exception"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, default=str)


class TextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = f"{self.formatTime(record)} {record.levelname:<7} {record.name} [{correlation_id_var.get() or '-'}] "
        text = base + str(redact(record.getMessage()))
        if record.exc_info:
            text += "\n" + str(redact(self.formatException(record.exc_info)))
        return text


def configure_logging(level: str = "INFO", json_logs: bool = True) -> None:
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(JsonFormatter() if json_logs else TextFormatter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level.upper())
    for noisy in ("uvicorn.access", "httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"churn.{name}")
