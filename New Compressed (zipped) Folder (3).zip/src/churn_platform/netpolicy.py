"""Who is on the other end of a request, when the platform sits behind a reverse proxy.

``X-Forwarded-For`` and ``X-Forwarded-Proto`` are written by whoever sends the request, so they are believed only
when the TCP peer is one of the configured proxies (``CHURN_TRUSTED_PROXIES``, addresses or CIDR ranges).  Release
1.0 believed ``X-Forwarded-Proto`` from anyone.
"""

from __future__ import annotations

import ipaddress
from functools import lru_cache
from typing import Any

from .config import get_settings


@lru_cache(maxsize=8)
def _networks(spec: str) -> tuple[Any, ...]:
    out = []
    for item in (part.strip() for part in spec.split(",")):
        if item:
            out.append(ipaddress.ip_network(item, strict=False))
    return tuple(out)


def is_trusted_proxy(peer: str | None) -> bool:
    if not peer:
        return False
    try:
        address = ipaddress.ip_address(peer)
    except ValueError:
        return False
    return any(address in network for network in _networks(get_settings().trusted_proxies))


def client_address(peer: str | None, forwarded_for: str | None) -> str | None:
    """The client's address: the peer, unless the peer is a trusted proxy - then the right-most address in
    ``X-Forwarded-For`` that is not itself a trusted proxy."""
    if not is_trusted_proxy(peer) or not forwarded_for:
        return peer
    for candidate in reversed([part.strip() for part in forwarded_for.split(",") if part.strip()]):
        try:
            ipaddress.ip_address(candidate)
        except ValueError:
            return peer  # a malformed chain is not believed at all
        if not is_trusted_proxy(candidate):
            return candidate
    return peer


def is_secure(scheme: str, peer: str | None, forwarded_proto: str | None) -> bool:
    """Whether the client reached the platform over TLS."""
    if get_settings().force_https or scheme == "https":
        return True
    return is_trusted_proxy(peer) and (forwarded_proto or "").split(",")[0].strip().lower() == "https"
