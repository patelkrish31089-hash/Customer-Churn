"""SYNTHETIC support messages in several languages, each written to carry one intended sentiment.

Used by the synthetic data generator and as a labelled set that exercises the sentiment evaluation code.  The
labels are the intent of whoever wrote the template, not the judgement of a customer: agreement with them says
that the code path works and says nothing about accuracy on real support text.
"""

from __future__ import annotations

import zlib

LANGUAGES = ("en", "de", "fr", "es", "hi")
UNSUPPORTED_SAMPLE_LANGUAGE = "tr"  # planted so that the "unsupported language" state can be seen

# {feature} is a product area; every template stays grammatical with any of the six synthetic feature names.
TEMPLATES: dict[str, dict[str, tuple[str, ...]]] = {
    "en": {
        "negative": (
            "We are frustrated: {feature} has been broken for days and nobody has given us an answer.",
            "This is unacceptable. {feature} keeps failing and our team has lost hours because of it.",
            "{feature} is slow and unreliable again. We are seriously considering alternatives.",
            "Very disappointed with the service. The problem with {feature} was reported three times and is still not fixed.",
            "The {feature} export fails every single time. This is the worst experience we have had with any vendor.",
            "Terrible. Another outage in {feature} and no communication at all. We want a refund for this month.",
        ),
        "neutral": (
            "How do we configure {feature} for a second team? Please send the steps.",
            "Question about the invoice for last month: where can we download it?",
            "We need help with the setup of {feature}. Is there a guide for administrators?",
            "Could you walk us through {feature}? We would like a short session next week.",
            "Please change the billing contact on our account to the finance team address.",
            "Is it possible to add more seats in the middle of the billing period?",
        ),
        "positive": (
            "Thank you, great support. The issue with {feature} was solved quickly.",
            "Everything works well now. We really appreciate the fast help with {feature}.",
            "We love the new {feature}. It saves our team a lot of time every week.",
            "Excellent service, the walkthrough of {feature} was clear and very helpful.",
            "Thanks a lot, the answer was perfect and {feature} is working great.",
            "Really happy with the product. {feature} is exactly what we needed.",
        ),
        "mixed": (
            "The new {feature} is great and the team loves it, but the export keeps failing and that is really frustrating.",
            "Support was friendly and fast, thank you. Unfortunately {feature} is still broken and we are disappointed.",
        ),
    },
    "de": {
        "negative": (
            "Wir sind sehr verärgert: {feature} ist seit Tagen kaputt und niemand antwortet uns.",
            "Das ist inakzeptabel. {feature} fällt ständig aus und unser Team verliert Stunden.",
            "{feature} ist wieder langsam und unzuverlässig. Wir prüfen ernsthaft Alternativen.",
            "Sehr enttäuscht vom Service. Das Problem mit {feature} wurde dreimal gemeldet und ist immer noch nicht behoben.",
            "Der Export aus {feature} schlägt jedes Mal fehl. Das ist die schlechteste Erfahrung mit einem Anbieter.",
            "Furchtbar. Schon wieder ein Ausfall bei {feature} und keinerlei Information. Wir möchten eine Rückerstattung.",
        ),
        "neutral": (
            "Wie richten wir {feature} für ein zweites Team ein? Bitte senden Sie uns die Schritte.",
            "Frage zur Rechnung vom letzten Monat: Wo können wir sie herunterladen?",
            "Wir brauchen Hilfe bei der Einrichtung von {feature}. Gibt es eine Anleitung für Administratoren?",
            "Können Sie uns {feature} kurz erklären? Wir hätten gern einen Termin nächste Woche.",
            "Bitte ändern Sie den Rechnungskontakt auf die Adresse unserer Buchhaltung.",
            "Ist es möglich, während des Abrechnungszeitraums weitere Lizenzen hinzuzufügen?",
        ),
        "positive": (
            "Vielen Dank, toller Support. Das Problem mit {feature} wurde schnell gelöst.",
            "Jetzt funktioniert alles gut. Wir schätzen die schnelle Hilfe bei {feature} sehr.",
            "Wir lieben das neue {feature}. Es spart unserem Team jede Woche viel Zeit.",
            "Ausgezeichneter Service, die Einführung in {feature} war klar und sehr hilfreich.",
            "Herzlichen Dank, die Antwort war perfekt und {feature} läuft hervorragend.",
            "Sehr zufrieden mit dem Produkt. {feature} ist genau das, was wir gebraucht haben.",
        ),
        "mixed": (
            "Das neue {feature} ist großartig, aber der Export schlägt ständig fehl und das ist wirklich frustrierend.",
        ),
    },
    "fr": {
        "negative": (
            "Nous sommes très mécontents : {feature} est en panne depuis des jours et personne ne nous répond.",
            "C'est inacceptable. {feature} tombe sans cesse en panne et notre équipe perd des heures.",
            "{feature} est de nouveau lent et peu fiable. Nous envisageons sérieusement d'autres solutions.",
            "Très déçus du service. Le problème avec {feature} a été signalé trois fois et n'est toujours pas corrigé.",
            "L'export de {feature} échoue à chaque fois. C'est la pire expérience que nous ayons eue avec un fournisseur.",
            "Horrible. Encore une panne de {feature} et aucune information. Nous voulons un remboursement.",
        ),
        "neutral": (
            "Comment configurer {feature} pour une deuxième équipe ? Merci de nous envoyer les étapes.",
            "Question sur la facture du mois dernier : où pouvons-nous la télécharger ?",
            "Nous avons besoin d'aide pour la mise en place de {feature}. Existe-t-il un guide pour les administrateurs ?",
            "Pouvez-vous nous présenter {feature} ? Nous aimerions une courte session la semaine prochaine.",
            "Merci de remplacer le contact de facturation par l'adresse de notre service comptable.",
            "Est-il possible d'ajouter des licences au milieu de la période de facturation ?",
        ),
        "positive": (
            "Merci beaucoup, excellent support. Le problème avec {feature} a été résolu rapidement.",
            "Tout fonctionne bien maintenant. Nous apprécions vraiment l'aide rapide pour {feature}.",
            "Nous adorons le nouveau {feature}. Il fait gagner beaucoup de temps à notre équipe.",
            "Service excellent, la présentation de {feature} était claire et très utile.",
            "Un grand merci, la réponse était parfaite et {feature} fonctionne très bien.",
            "Très satisfaits du produit. {feature} est exactement ce dont nous avions besoin.",
        ),
        "mixed": (
            "Le nouveau {feature} est super, mais l'export échoue sans cesse et c'est vraiment frustrant.",
        ),
    },
    "es": {
        "negative": (
            "Estamos muy molestos: {feature} lleva días sin funcionar y nadie nos responde.",
            "Esto es inaceptable. {feature} falla constantemente y nuestro equipo pierde horas.",
            "{feature} vuelve a ser lento y poco fiable. Estamos considerando seriamente otras alternativas.",
            "Muy decepcionados con el servicio. El problema con {feature} se reportó tres veces y sigue sin resolverse.",
            "La exportación de {feature} falla siempre. Es la peor experiencia que hemos tenido con un proveedor.",
            "Terrible. Otra caída de {feature} y ninguna comunicación. Queremos un reembolso.",
        ),
        "neutral": (
            "¿Cómo configuramos {feature} para un segundo equipo? Por favor envíen los pasos.",
            "Pregunta sobre la factura del mes pasado: ¿dónde podemos descargarla?",
            "Necesitamos ayuda con la configuración de {feature}. ¿Hay una guía para administradores?",
            "¿Pueden explicarnos {feature}? Nos gustaría una sesión breve la próxima semana.",
            "Por favor cambien el contacto de facturación a la dirección de nuestro equipo de finanzas.",
            "¿Es posible añadir más licencias a mitad del periodo de facturación?",
        ),
        "positive": (
            "Muchas gracias, excelente soporte. El problema con {feature} se resolvió rápidamente.",
            "Ahora todo funciona bien. Agradecemos mucho la ayuda rápida con {feature}.",
            "Nos encanta el nuevo {feature}. Le ahorra mucho tiempo a nuestro equipo cada semana.",
            "Servicio excelente, la explicación de {feature} fue clara y muy útil.",
            "Mil gracias, la respuesta fue perfecta y {feature} funciona muy bien.",
            "Muy contentos con el producto. {feature} es justo lo que necesitábamos.",
        ),
        "mixed": (
            "El nuevo {feature} es genial, pero la exportación falla constantemente y eso es muy frustrante.",
        ),
    },
    "hi": {
        "negative": (
            "हम बहुत परेशान हैं: {feature} कई दिनों से खराब है और कोई जवाब नहीं दे रहा।",
            "यह बिल्कुल अस्वीकार्य है। {feature} बार-बार बंद हो जाता है और हमारी टीम के घंटे बर्बाद हो रहे हैं।",
            "{feature} फिर से धीमा और अविश्वसनीय है। हम दूसरे विकल्पों पर गंभीरता से विचार कर रहे हैं।",
            "सेवा से बहुत निराश हैं। {feature} की समस्या तीन बार बताई गई और अब तक ठीक नहीं हुई।",
            "{feature} का एक्सपोर्ट हर बार विफल होता है। यह अब तक का सबसे खराब अनुभव है।",
            "बहुत बुरा। {feature} फिर बंद हुआ और कोई सूचना नहीं मिली। हमें इस महीने का रिफंड चाहिए।",
        ),
        "neutral": (
            "हम दूसरी टीम के लिए {feature} कैसे सेट करें? कृपया चरण भेजें।",
            "पिछले महीने के बिल के बारे में प्रश्न: हम इसे कहाँ से डाउनलोड कर सकते हैं?",
            "हमें {feature} के सेटअप में मदद चाहिए। क्या एडमिन के लिए कोई गाइड है?",
            "क्या आप हमें {feature} समझा सकते हैं? हम अगले सप्ताह एक छोटा सत्र चाहते हैं।",
            "कृपया हमारे खाते का बिलिंग संपर्क बदलकर वित्त टीम का पता कर दें।",
            "क्या बिलिंग अवधि के बीच में और सीटें जोड़ना संभव है?",
        ),
        "positive": (
            "धन्यवाद, बहुत अच्छा सपोर्ट। {feature} की समस्या जल्दी हल हो गई।",
            "अब सब कुछ ठीक चल रहा है। {feature} में तेज़ मदद के लिए हम आभारी हैं।",
            "हमें नया {feature} बहुत पसंद है। इससे हमारी टीम का हर सप्ताह बहुत समय बचता है।",
            "शानदार सेवा, {feature} की जानकारी स्पष्ट और बहुत उपयोगी थी।",
            "बहुत धन्यवाद, जवाब एकदम सही था और {feature} बढ़िया चल रहा है।",
            "उत्पाद से बहुत खुश हैं। {feature} ठीक वही है जो हमें चाहिए था।",
        ),
        "mixed": (
            "नया {feature} बहुत अच्छा है, लेकिन एक्सपोर्ट बार-बार विफल होता है और यह बहुत निराशाजनक है।",
        ),
    },
    UNSUPPORTED_SAMPLE_LANGUAGE: {
        "negative": ("{feature} günlerdir çalışmıyor ve kimse bize cevap vermiyor. Bu kabul edilemez.",),
        "neutral": ("{feature} ayarlarını ikinci bir ekip için nasıl yapabiliriz? Lütfen adımları gönderin.",),
        "positive": ("Çok teşekkürler, destek harikaydı ve {feature} sorunu hızlıca çözüldü.",),
    },
}

# What the generator's original English phrases meant; they stay the unit of randomness (see synthetic.generate).
INTENT_OF_PHRASE = {
    "frustrated with repeated errors": "negative", "still broken and unacceptable": "negative", "slow and unreliable again": "negative",
    "disappointed, considering alternatives": "negative", "the export keeps failing": "negative",
    "how do I configure this": "neutral", "question about the invoice": "neutral", "need help with setup": "neutral",
    "requesting a feature walkthrough": "neutral",
    "thanks, great support": "positive", "works well now, appreciate the help": "positive", "love the new dashboard": "positive",
}  # fmt: skip
FEATURE_WORDS = {
    "dashboards": {"en": "dashboards", "de": "Dashboards", "fr": "tableaux de bord", "es": "paneles", "hi": "डैशबोर्ड", "tr": "paneller"},
    "reports": {"en": "reports", "de": "Berichte", "fr": "rapports", "es": "informes", "hi": "रिपोर्ट", "tr": "raporlar"},
    "integrations": {"en": "integrations", "de": "Integrationen", "fr": "intégrations", "es": "integraciones", "hi": "इंटीग्रेशन",
                     "tr": "entegrasyonlar"},
    "automation": {"en": "automation", "de": "Automatisierung", "fr": "automatisation", "es": "automatización", "hi": "ऑटोमेशन",
                   "tr": "otomasyon"},
    "exports": {"en": "exports", "de": "Exporte", "fr": "exports", "es": "exportaciones", "hi": "एक्सपोर्ट", "tr": "dışa aktarma"},
    "collaboration": {"en": "collaboration", "de": "Zusammenarbeit", "fr": "collaboration", "es": "colaboración", "hi": "सहयोग",
                      "tr": "iş birliği"},
}  # fmt: skip


def stable(*parts: object) -> int:
    """A hash that is the same on every machine and run (Python's own ``hash`` is salted per process)."""
    return zlib.crc32("|".join(str(p) for p in parts).encode())


def language_for(customer_id: str, country: str) -> str:
    """The language a synthetic customer writes in.  Decided by a stable hash, never by a random draw."""
    roll = stable("lang", customer_id) % 100
    if country == "DE":
        return "de" if roll < 85 else "en"
    if country == "FR":
        return "fr" if roll < 85 else "en"
    if country == "CA":
        return "fr" if roll < 30 else "en"
    if country == "US":
        return "es" if roll < 15 else "en"
    if country == "IN":
        return "hi" if roll < 25 else "en"
    return "en"


def message(intent: str, language: str, feature: str, key: object) -> str:
    """One message with the given intent in the given language; ``key`` picks the template deterministically."""
    options = TEMPLATES[language].get(intent) or TEMPLATES[language]["neutral"]
    template = options[stable("tpl", key) % len(options)]
    text = template.format(feature=FEATURE_WORDS[feature].get(language, FEATURE_WORDS[feature]["en"]))
    return text[:1].upper() + text[1:]


def labelled_set() -> list[dict]:
    """Every template rendered once per product area, with the intent it was written with.  SYNTHETIC."""
    rows = []
    for language, by_intent in TEMPLATES.items():
        for intent, templates in by_intent.items():
            for n, template in enumerate(templates):
                feature = sorted(FEATURE_WORDS)[n % len(FEATURE_WORDS)]
                rows.append({"text": template.format(feature=FEATURE_WORDS[feature].get(language, FEATURE_WORDS[feature]["en"])),
                             "label": intent, "language": language})  # fmt: skip
    return rows
