"""Security primitives: password hashing, session tokens, TOTP (RFC 6238), secret encryption, RBAC."""

from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
import struct
import time
from dataclasses import dataclass, field
from urllib.parse import quote

from cryptography.fernet import Fernet, InvalidToken

from .config import get_settings

# ----------------------------------------------------------------------------- passwords (scrypt)
_SCRYPT_N, _SCRYPT_R, _SCRYPT_P, _SCRYPT_LEN = 2**14, 8, 1, 32
_COMMON_PASSWORDS = {"password", "password1", "password123", "123456789012", "qwertyuiopas", "letmein12345"}


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P, dklen=_SCRYPT_LEN)
    return "$".join(
        ["scrypt", str(_SCRYPT_N), str(_SCRYPT_R), str(_SCRYPT_P), base64.b64encode(salt).decode(), base64.b64encode(dk).decode()]
    )


def verify_password(password: str, stored: str | None) -> bool:
    try:
        scheme, n, r, p, salt_b64, dk_b64 = (stored or "").split("$")
        if scheme != "scrypt":
            return False
        expected = base64.b64decode(dk_b64)
        dk = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt_b64), n=int(n), r=int(r), p=int(p), dklen=len(expected))
        return hmac.compare_digest(dk, expected)
    except (ValueError, TypeError):
        return False


_DUMMY_HASH = hash_password("timing-equaliser-not-a-real-credential")


def burn_password_check(password: str) -> None:
    """Spend the same time as a real verification (unknown-user login must not be faster)."""
    verify_password(password, _DUMMY_HASH)


def password_problems(password: str, min_length: int) -> list[str]:
    problems = []
    if len(password) < min_length:
        problems.append(f"must be at least {min_length} characters")
    if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
        problems.append("must contain letters and digits")
    if password.lower() in _COMMON_PASSWORDS:
        problems.append("is too common")
    return problems


# ----------------------------------------------------------------------------- opaque session tokens
def new_token() -> tuple[str, str]:
    token = secrets.token_urlsafe(32)
    return token, hash_token(token)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ----------------------------------------------------------------------------- TOTP (RFC 6238 / RFC 4226)
def totp_new_secret() -> str:
    return base64.b32encode(os.urandom(20)).decode().rstrip("=")


def _totp_at(secret: str, counter: int, digits: int = 6) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = (struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF) % (10**digits)
    return str(code).zfill(digits)


def totp_code(secret: str, at: float | None = None, step: int = 30) -> str:
    return _totp_at(secret, int((at if at is not None else time.time()) // step))


def totp_verify(secret: str, code: str, *, at: float | None = None, step: int = 30, window: int = 1,
                last_counter: int | None = None) -> int | None:
    """Return the matched time-step counter, or None.  ``last_counter`` blocks code replay."""
    if not code or not code.isdigit():
        return None
    now_counter = int((at if at is not None else time.time()) // step)
    for delta in range(-window, window + 1):
        counter = now_counter + delta
        if last_counter is not None and counter <= last_counter:
            continue
        if hmac.compare_digest(_totp_at(secret, counter), code):
            return counter
    return None


def totp_uri(secret: str, account: str, issuer: str = "Churn Platform") -> str:
    return f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret}&issuer={quote(issuer)}&digits=6&period=30"


# ----------------------------------------------------------------------------- secrets at rest
class SecretBox:
    """Authenticated encryption (Fernet) for credentials stored in the database."""

    def __init__(self, secret_key: str | None = None) -> None:
        key = secret_key if secret_key is not None else get_settings().secret_key.get_secret_value()
        derived = hashlib.sha256(b"churn-platform/secretbox/v1:" + key.encode()).digest()
        self._fernet = Fernet(base64.urlsafe_b64encode(derived))

    def encrypt(self, plaintext: str) -> str:
        return self._fernet.encrypt(plaintext.encode()).decode()

    def decrypt(self, ciphertext: str) -> str:
        try:
            return self._fernet.decrypt(ciphertext.encode()).decode()
        except InvalidToken as exc:
            raise ValueError("stored secret cannot be decrypted with the configured CHURN_SECRET_KEY") from exc


def hmac_sha256_hex(secret: str, body: bytes) -> str:
    return hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())


# ----------------------------------------------------------------------------- RBAC
# 1.1.0 adds: signals (sentiment, feature adoption, identity mapping, attribute history), notify (messages and
# campaigns), crm:approve (a reverse-ETL sync needs a second person) and admin:security (single sign-on, limits).
_READ = {
    "data:read", "quality:read", "labels:read", "features:read", "analytics:read", "ml:read", "predict:read",
    "customers:read", "retention:read", "crm:read", "mlops:read", "jobs:read", "signals:read", "notify:read",
}  # fmt: skip
_ALL = _READ | {
    "admin:users", "admin:audit", "admin:sessions", "admin:security",
    "data:write", "quality:write", "quality:review", "labels:write", "policy:write", "policy:approve",
    "features:write", "features:approve", "analytics:run", "ml:train", "ml:approve", "predict:run",
    "customers:export", "retention:write", "retention:approve", "crm:write", "crm:approve", "mlops:write", "jobs:manage",
    "signals:write", "signals:approve", "signals:annotate", "notify:write", "notify:approve",
}  # fmt: skip

ROLE_PERMISSIONS: dict[str, frozenset[str]] = {
    "admin": frozenset(_ALL),
    "approver": frozenset(_READ | {"policy:approve", "features:approve", "ml:approve", "retention:approve",
                                   "quality:review", "admin:audit", "signals:approve", "notify:approve", "crm:approve",
                                   "signals:annotate"}),
    "data_engineer": frozenset(_READ | {"data:write", "quality:write", "features:write", "analytics:run",
                                        "jobs:manage", "mlops:write", "signals:write", "signals:annotate"}),
    "data_scientist": frozenset(_READ | {"labels:write", "policy:write", "features:write", "analytics:run",
                                         "ml:train", "predict:run", "jobs:manage", "mlops:write",
                                         "retention:write", "signals:write", "notify:write", "signals:annotate"}),
    # 1.2.0: labelling support text is its own permission - it is not "signals:write" (which changes what the
    # product computes) and it is not "signals:approve" (which decides another person's disagreement)
    "analyst": frozenset(_READ | {"analytics:run", "customers:export", "signals:annotate"}),
    "csm": frozenset({"customers:read", "predict:read", "retention:read", "retention:write", "crm:read",
                      "analytics:read", "jobs:read", "signals:read", "notify:read", "signals:annotate"}),
    "auditor": frozenset(_READ | {"admin:audit"}),
    "viewer": frozenset(_READ),
}  # fmt: skip
ROLES = tuple(ROLE_PERMISSIONS)
ALL_PERMISSIONS = frozenset(_ALL)


@dataclass(frozen=True)
class Principal:
    user_id: int
    tenant_id: int
    email: str
    role: str
    session_id: int
    mfa_enrollment_required: bool = False
    permissions: frozenset[str] = field(default_factory=frozenset)

    def can(self, permission: str) -> bool:
        return permission in self.permissions
