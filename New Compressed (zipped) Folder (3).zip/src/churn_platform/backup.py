"""Backup and restore of an installation: the database, the data directory and a manifest that proves both.

A backup is a single ``.tar.gz`` holding:

* ``database`` — a consistent copy of the database (SQLite: ``VACUUM INTO``; PostgreSQL: ``pg_dump`` custom format),
* ``data/`` — the data directory (raw uploads, model artefacts, feature snapshots), when it exists,
* ``manifest.json`` — the schema revision, when it was taken, what each member's SHA-256 is and how big it is.

A restore refuses to touch anything unless every checksum matches, so a truncated or edited archive fails loudly
instead of half-restoring.  After restoring, the database is opened and checked (revision, a real query per table
group), because *a backup that has never been restored is a hope* — the exercise in ``tests/test_backup.py``
restores into an empty directory and compares row counts against the original.

What this is not: a scheduler, encryption or off-site storage.  Those belong to the operator (``pg_dump`` pipes,
object storage with its own retention, a key manager), and the runbook in ``docs/1_2_0_DISASTER_RECOVERY_REPORT.md``
says which parts are ours and which are the owner's.
"""

from __future__ import annotations

import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import tempfile
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

from sqlalchemy import text

from .config import get_settings
from .db import get_engine, utcnow
from .dbadmin import current_revision
from .errors import ValidationFailed

FORMAT = 1
TABLES = ("tenants", "customers", "subscriptions", "usage_events", "support_interactions", "model_versions", "predictions",
          "retention_recommendations", "notification_messages", "crm_connections", "audit_events")  # fmt: skip


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _database_url() -> str:
    return get_settings().database_url


def is_postgres(url: str) -> bool:
    return url.startswith("postgresql")


def libpq_url(url: str) -> str:
    """``postgresql+psycopg://…`` as the client tools understand it.

    SQLAlchemy spells the driver into the scheme; ``pg_dump`` and ``pg_restore`` do not know what ``+psycopg`` is and
    silently fall back to their defaults (a local socket, the operating system's user name), which fails with
    ``role "user" does not exist`` on a server that is running perfectly well.
    """
    scheme, sep, rest = url.partition("://")
    if not sep or not scheme.startswith("postgresql+"):
        return url
    return "postgresql://" + rest


def _sqlite_path(url: str) -> Path:
    prefix = "sqlite:///"
    if not url.startswith(prefix):
        raise ValidationFailed("this command supports sqlite:/// and postgresql+... URLs", details={"field": "database_url"})
    return Path(url[len(prefix):]).resolve()


def _dump_database(url: str, target: Path) -> str:
    """Write a consistent copy of the database to ``target``; return which engine produced it."""
    if is_postgres(url):
        pg_dump = shutil.which("pg_dump")
        if pg_dump is None:
            raise ValidationFailed("pg_dump is not installed, so a PostgreSQL database cannot be backed up from here",
                                   details={"field": "pg_dump"})  # fmt: skip
        result = subprocess.run(  # noqa: S603 - a fixed command built from a list, never a shell string
            [pg_dump, "--format=custom", "--no-owner", "--no-privileges", "--file", str(target), libpq_url(url)],
            capture_output=True, text=True, check=False)
        if result.returncode != 0:
            raise ValidationFailed(f"pg_dump failed: {result.stderr.strip()[:300]}", details={"field": "pg_dump"})
        return "pg_dump"
    path = _sqlite_path(url)
    if not path.exists():
        raise ValidationFailed(f"there is no database at {path}", details={"field": "database_url"})
    # sqlite3 directly: VACUUM cannot run inside a transaction, and SQLAlchemy wraps every statement in one.
    # VACUUM INTO writes a consistent snapshot even while other processes are writing.
    import sqlite3

    connection = sqlite3.connect(str(path), isolation_level=None)
    try:
        connection.execute("VACUUM INTO ?", (str(target),))
    finally:
        connection.close()
    return "sqlite-vacuum-into"


def backup(destination: Path | str, *, data_dir: Path | str | None = None, note: str | None = None) -> dict:
    """Write an archive and return its manifest (also stored inside the archive)."""
    destination = Path(destination).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    url = _database_url()
    data = Path(data_dir).expanduser().resolve() if data_dir else Path(get_settings().data_dir).resolve()
    with tempfile.TemporaryDirectory() as scratch:
        dump = Path(scratch) / "database"
        engine = _dump_database(url, dump)
        manifest: dict[str, Any] = {
            "format": FORMAT, "created_at": utcnow().isoformat(), "database_url_kind": "postgresql" if is_postgres(url) else "sqlite",
            "engine": engine, "revision": current_revision(url), "note": note, "members": [],
        }  # fmt: skip
        manifest["members"].append({"name": "database", "bytes": dump.stat().st_size, "sha256": _sha256(dump)})
        with tarfile.open(destination, "w:gz") as archive:
            archive.add(dump, arcname="database")
            if data.is_dir():
                for path in sorted(data.rglob("*")):
                    if path.is_file():
                        member = PurePosixPath("data", *path.relative_to(data).parts)
                        manifest["members"].append({"name": str(member), "bytes": path.stat().st_size, "sha256": _sha256(path)})
                archive.add(data, arcname="data")
            blob = json.dumps(manifest, indent=1, sort_keys=True).encode()
            info = tarfile.TarInfo("manifest.json")
            info.size, info.mtime = len(blob), int(utcnow().timestamp())
            archive.addfile(info, io.BytesIO(blob))
    manifest["archive"] = {"path": str(destination), "bytes": destination.stat().st_size, "sha256": _sha256(destination)}
    return manifest


def inspect(archive_path: Path | str) -> dict:
    """Read the manifest and say whether the archive matches it, without restoring anything."""
    archive_path = Path(archive_path).expanduser().resolve()
    if not archive_path.exists():
        raise ValidationFailed(f"there is no archive at {archive_path}", details={"field": "archive"})
    with tarfile.open(archive_path, "r:gz") as archive:
        try:
            manifest = json.loads(archive.extractfile("manifest.json").read())
        except KeyError as exc:
            raise ValidationFailed("this archive has no manifest.json", details={"field": "archive"}) from exc
        problems = []
        for member in manifest.get("members", []):
            try:
                handle = archive.extractfile(member["name"])
            except KeyError:
                handle = None  # listed in the manifest, absent from the archive
            if handle is None:
                problems.append(f"{member['name']}: missing")
                continue
            digest = hashlib.sha256(handle.read()).hexdigest()
            if digest != member["sha256"]:
                problems.append(f"{member['name']}: checksum {digest[:12]} does not match {member['sha256'][:12]}")
    return {"archive": str(archive_path), "manifest": manifest, "valid": not problems, "problems": problems}


def _health(url: str) -> dict:
    """Open the database and ask it for the things a restore must get right."""
    engine = get_engine()
    counts: dict[str, int] = {}
    with engine.connect() as connection:
        for table in TABLES:
            # table names come from the constant TABLES tuple above, never from input (B608 is not a risk here)
            counts[table] = int(connection.execute(text(f"select count(*) from {table}")).scalar_one())  # noqa: S608  # nosec B608 - table names come from the constant TABLES tuple, never from input
        newest = connection.execute(text("select max(created_at) from audit_events")).scalar()
    return {"revision": current_revision(url), "counts": counts, "newest_audit_event": str(newest) if newest else None}


def _extract(archive: tarfile.TarFile, member: tarfile.TarInfo, target_dir: Path) -> None:
    """Write one member, refusing a path that escapes the target (an archive is not trusted just because we wrote it)."""
    parts = PurePosixPath(member.name).parts
    if not parts or parts[0] in ("..", "/") or ".." in parts:
        raise ValidationFailed(f"refusing to extract '{member.name}': the path escapes the archive", details={"field": "archive"})
    destination = target_dir.joinpath(*parts)
    if member.isdir():
        destination.mkdir(parents=True, exist_ok=True)
        return
    if not member.isfile():
        return  # devices, links and fifos have no place in a backup
    destination.parent.mkdir(parents=True, exist_ok=True)
    handle = archive.extractfile(member)
    if handle is None:
        raise ValidationFailed(f"'{member.name}' is not readable", details={"field": "archive"})
    with handle, destination.open("wb") as out:
        shutil.copyfileobj(handle, out)


def restore(archive_path: Path | str, *, data_dir: Path | str | None = None, force: bool = False) -> dict:
    """Put an archive back.  Refuses a bad checksum, and refuses to overwrite a database unless ``force``."""
    archive_path = Path(archive_path).expanduser().resolve()
    report = inspect(archive_path)
    if not report["valid"]:
        raise ValidationFailed("this archive does not match its own manifest; nothing was restored",
                               details={"problems": report["problems"][:20]})  # fmt: skip
    url = _database_url()
    data = Path(data_dir).expanduser().resolve() if data_dir else Path(get_settings().data_dir).resolve()
    if not is_postgres(url) and _sqlite_path(url).exists() and not force:
        raise ValidationFailed("a database already exists; pass --force to replace it", details={"field": "database"})
    with tempfile.TemporaryDirectory() as scratch:
        with tarfile.open(archive_path, "r:gz") as archive:
            for member in archive.getmembers():
                if member.name == "database" or member.name == "data" or member.name.startswith("data/"):
                    _extract(archive, member, Path(scratch))
        dump = Path(scratch) / "database"
        if is_postgres(url):
            pg_restore = shutil.which("pg_restore")
            if pg_restore is None:
                raise ValidationFailed("pg_restore is not installed", details={"field": "pg_restore"})
            result = subprocess.run(  # noqa: S603 - a fixed command built from a list, never a shell string
                [pg_restore, "--clean", "--if-exists", "--no-owner", "--dbname", libpq_url(url), str(dump)],
                capture_output=True, text=True, check=False)
            if result.returncode != 0:
                raise ValidationFailed(f"pg_restore failed: {result.stderr.strip()[:300]}", details={"field": "pg_restore"})
        else:
            target = _sqlite_path(url)
            get_engine().dispose()
            target.parent.mkdir(parents=True, exist_ok=True)
            for suffix in ("-wal", "-shm"):
                stale = target.with_name(target.name + suffix)
                if stale.exists():
                    stale.unlink()
            shutil.copyfile(dump, target)
        if (Path(scratch) / "data").is_dir():
            if data.exists() and force:
                shutil.rmtree(data)
            if not data.exists():
                shutil.copytree(Path(scratch) / "data", data)
    health = _health(url)
    expected = report["manifest"].get("revision")
    return {"archive": str(archive_path), "restored": True, "revision_before": expected, "health": health,
            "revision_matches": health["revision"] == expected, "at": datetime.now().isoformat(timespec="seconds")}  # fmt: skip


__all__ = ["TABLES", "backup", "inspect", "is_postgres", "restore"]
