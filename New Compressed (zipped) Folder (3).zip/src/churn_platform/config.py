"""Centralised configuration.

All settings come from ``CHURN_*`` environment variables (or files in ``CHURN_SECRETS_DIR`` for
Docker/Kubernetes secrets).  Nothing secret has a usable default outside ``development``/``test``:
the ``staging`` and ``production`` profiles refuse to start with the development key, with SQLite,
or with self-approval enabled.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Development-only sentinel: the staging and production profiles refuse to start with it (see _validate_profile).
DEV_SECRET = "dev-only-insecure-key-do-not-use-outside-development"  # noqa: S105  # nosec B105
Environment = Literal["development", "test", "staging", "production"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CHURN_", extra="ignore", case_sensitive=False)

    env: Environment = "development"
    database_url: str = "sqlite:///./var/churn.db"
    data_dir: Path = Path("./var/data")
    secret_key: SecretStr = SecretStr(DEV_SECRET)

    # --- authentication / sessions
    session_ttl_minutes: int = 480
    session_idle_minutes: int = 120
    login_max_failures: int = 5
    login_lockout_minutes: int = 15
    password_min_length: int = 12
    mfa_required_roles: str = ""
    allow_self_approval: bool = False

    # --- HTTP
    allow_framing: bool = True
    max_upload_mb: int = 200
    rate_limit_login_per_minute: int = 30

    # --- logging
    log_level: str = "INFO"
    log_json: bool = True

    # --- background worker
    embedded_worker: bool = False
    worker_poll_seconds: float = 1.0
    worker_lease_seconds: int = 60
    worker_heartbeat_seconds: float = 10.0
    worker_shutdown_grace_seconds: int = 30
    job_max_attempts: int = 3
    job_backoff_base_seconds: float = 5.0

    # --- business defaults (overridable only through approved, versioned policies)
    default_horizon_days: int = 30

    # --- integrations
    mlflow_tracking_uri: str | None = None
    mlflow_experiment: str = "churn-platform"
    crm_allow_production: bool = False
    crm_http_timeout_seconds: float = 20.0
    crm_allow_private_hosts: bool = False
    ingest_http_timeout_seconds: float = 30.0
    ingest_allow_private_hosts: bool = False

    # --- public address of this installation (links in messages, OAuth and single-sign-on redirect URIs)
    public_base_url: str | None = None

    # --- sentiment (1.1.0).  "auto": the local transformer when its runtime and weights are installed, otherwise
    # the word-list baseline, which is always labelled as a baseline.  No text ever leaves the machine.
    sentiment_provider: Literal["auto", "onnx_transformer", "lexicon_baseline"] = "auto"
    sentiment_model_dir: Path | None = None
    sentiment_max_chars: int = 4000
    sentiment_min_confidence: float = 0.5
    sentiment_threads: int = 1

    # --- orchestration and model registry (1.1.0).  Exactly one orchestrator fires scheduled pipeline work.
    orchestrator: Literal["platform", "airflow"] = "platform"
    model_registry: Literal["platform", "mlflow"] = "platform"
    mlflow_http_timeout_seconds: float = 20.0

    # --- notifications (1.1.0).  Providers start in DRY_RUN; LIVE delivery needs this switch as well.
    notify_allow_live: bool = False
    notify_http_timeout_seconds: float = 20.0
    notify_allow_private_hosts: bool = False
    # 1.2.0: marketing messages are held, not dropped, outside these hours (installation-wide; empty = off)
    notify_quiet_hours: str = ""  # e.g. "21:00-08:00"
    notify_quiet_timezone: str = "UTC"
    notify_max_per_customer_per_day: int = 2
    notify_max_per_customer_per_week: int = 5

    # --- reverse proxy / TLS (1.1.0).  Forwarded headers are believed only when the peer is one of these addresses.
    trusted_proxies: str = ""
    force_https: bool = False
    hsts_seconds: int = 31536000

    # --- sessions and rate limits (1.1.0).  Limits are per minute and shared by every server process.
    session_rotate_minutes: int = 60
    rate_limit_enabled: bool = True
    rate_limit_login_account_per_minute: int = 10
    rate_limit_api_per_minute: int = 600
    rate_limit_ip_per_minute: int = 300
    rate_limit_export_per_minute: int = 20
    rate_limit_predict_per_minute: int = 60
    rate_limit_sync_per_minute: int = 30
    rate_limit_store_failure: Literal["local", "deny"] = "local"

    # --- destinations (1.3.0).  Where predictions go once they are scored; a warehouse at present.  The driver is
    # imported only when a run actually connects, so an installation without it can still start, export to nothing and
    # say why.  No secret is ever read from a path this application can be tricked into naming: the key file is a
    # deployment decision, and the destination reports only which variables are unset.
    export_batch_size: int = 500
    export_snowflake_account: str | None = None
    export_snowflake_user: str | None = None
    export_snowflake_warehouse: str | None = None
    export_snowflake_database: str | None = None
    export_snowflake_schema: str = "PUBLIC"
    export_snowflake_role: str | None = None
    export_snowflake_authenticator: str = "snowflake_jwt"
    export_snowflake_private_key_file: Path | None = None
    export_postgres_url: str | None = None
    export_postgres_schema: str = "public"

    # --- single sign-on (1.1.0)
    oidc_http_timeout_seconds: float = 10.0
    oidc_allow_insecure_http: bool = False
    oidc_allow_private_hosts: bool = False

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def is_production_like(self) -> bool:
        return self.env in ("staging", "production")

    @property
    def mfa_required_role_set(self) -> set[str]:
        return {r.strip() for r in self.mfa_required_roles.split(",") if r.strip()}

    @property
    def trusted_proxy_list(self) -> list[str]:
        return [p.strip() for p in self.trusted_proxies.split(",") if p.strip()]

    @property
    def sentiment_model_path(self) -> Path:
        return self.sentiment_model_dir or (self.data_dir / "models" / "sentiment")

    @model_validator(mode="after")
    def _validate_profile(self) -> Settings:
        if self.is_production_like:
            problems = []
            key = self.secret_key.get_secret_value()
            if key == DEV_SECRET or len(key) < 32:
                problems.append("CHURN_SECRET_KEY must be a unique value of at least 32 characters")
            if self.is_sqlite:
                problems.append("CHURN_DATABASE_URL must point at PostgreSQL (SQLite is development/test only)")
            if self.allow_self_approval:
                problems.append("CHURN_ALLOW_SELF_APPROVAL must be false (four-eyes approvals are mandatory)")
            if self.embedded_worker:
                problems.append("CHURN_EMBEDDED_WORKER must be false (run the worker as a separate process)")
            if self.env == "production" and self.allow_framing:
                problems.append("CHURN_ALLOW_FRAMING must be false in production")
            if self.oidc_allow_insecure_http:
                problems.append("CHURN_OIDC_ALLOW_INSECURE_HTTP must be false (identity providers are reached over https)")
            if self.public_base_url and not self.public_base_url.startswith("https://"):
                problems.append("CHURN_PUBLIC_BASE_URL must start with https://")
            if self.model_registry == "mlflow" and not self.mlflow_tracking_uri:
                problems.append("CHURN_MODEL_REGISTRY=mlflow needs CHURN_MLFLOW_TRACKING_URI")
            if problems:
                raise ValueError(f"Unsafe {self.env} configuration: " + "; ".join(problems))
        return self

    def ensure_dirs(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if self.is_sqlite and ":memory:" not in self.database_url:
            db_path = Path(self.database_url.split("///", 1)[1])
            db_path.parent.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    secrets_dir = os.environ.get("CHURN_SECRETS_DIR")
    if secrets_dir:
        return Settings(_secrets_dir=secrets_dir)  # type: ignore[call-arg]
    return Settings()


def reset_settings_cache() -> None:
    get_settings.cache_clear()
