"""Database engine, session factory and portable column types (SQLite + PostgreSQL)."""

from __future__ import annotations

import contextlib
from collections.abc import Iterator
from contextvars import ContextVar
from datetime import UTC, datetime
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Any

from sqlalchemy import JSON, DateTime, MetaData, Numeric, create_engine, event
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker
from sqlalchemy.types import TypeDecorator

from .config import Settings, get_settings

# Every constraint is explicitly named so that Alembic (and SQLite batch mode in particular) can
# always address it by name on downgrade.
NAMING_CONVENTION = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}
MONEY_QUANT = Decimal("0.0001")


def utcnow() -> datetime:
    return datetime.now(UTC)


def to_decimal(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if isinstance(value, float):
        return Decimal(repr(value))
    return Decimal(str(value))


def money(value: Any) -> Decimal:
    return to_decimal(value).quantize(MONEY_QUANT, rounding=ROUND_HALF_EVEN)


class UTCDateTime(TypeDecorator):
    """Timezone-aware UTC datetime on every backend (SQLite drops tzinfo; we restore it)."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value: Any, dialect: Any) -> Any:
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    def process_result_value(self, value: Any, dialect: Any) -> Any:
        if value is None:
            return None
        return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


class Money(TypeDecorator):
    """Exact ``Decimal`` money (4 dp).  NUMERIC(18,4) on PostgreSQL.

    SQLite has no decimal storage class, so values are stored as REAL there and re-quantised to
    4 dp on load (exact for magnitudes below 1e11); SQLite is a development/test backend only.
    """

    impl = Numeric(18, 4)
    cache_ok = True

    def load_dialect_impl(self, dialect: Any) -> Any:
        return dialect.type_descriptor(Numeric(18, 4, asdecimal=dialect.name != "sqlite"))

    def process_bind_param(self, value: Any, dialect: Any) -> Any:
        if value is None:
            return None
        quantised = money(value)
        return float(quantised) if dialect.name == "sqlite" else quantised

    def process_result_value(self, value: Any, dialect: Any) -> Any:
        return None if value is None else money(value)


JSONType = JSON().with_variant(JSONB(), "postgresql")


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=NAMING_CONVENTION)


# True (default) => transactions start with BEGIN IMMEDIATE on SQLite so a read-then-write
# transaction can never fail with SQLITE_BUSY_SNAPSHOT.  Read-only request handlers switch it off.
_write_intent: ContextVar[bool] = ContextVar("churn_write_intent", default=True)


@contextlib.contextmanager
def read_only_transactions() -> Iterator[None]:
    token = _write_intent.set(False)
    try:
        yield
    finally:
        _write_intent.reset(token)


def make_engine(url: str, *, echo: bool = False, for_migrations: bool = False, busy_timeout_ms: int = 30000) -> Engine:
    if url.startswith("sqlite"):
        engine = create_engine(url, echo=echo,
                               connect_args={"check_same_thread": False, "timeout": busy_timeout_ms / 1000})  # fmt: skip

        @event.listens_for(engine, "connect")
        def _on_connect(dbapi_conn: Any, _record: Any) -> None:
            dbapi_conn.isolation_level = None  # we emit BEGIN ourselves (see _on_begin)
            cur = dbapi_conn.cursor()
            # Table-rebuild (batch) migrations require FK enforcement to be OFF while they run;
            # Alembic's env.py verifies integrity with PRAGMA foreign_key_check afterwards.
            cur.execute(f"PRAGMA foreign_keys={'OFF' if for_migrations else 'ON'}")
            cur.execute(f"PRAGMA busy_timeout={int(busy_timeout_ms)}")
            if ":memory:" not in url:
                cur.execute("PRAGMA journal_mode=WAL")
                cur.execute("PRAGMA synchronous=NORMAL")
            cur.close()

        @event.listens_for(engine, "begin")
        def _on_begin(conn: Any) -> None:
            conn.exec_driver_sql("BEGIN IMMEDIATE" if _write_intent.get() else "BEGIN")

        return engine
    return create_engine(url, echo=echo, pool_pre_ping=True, pool_size=10, max_overflow=10, pool_recycle=1800)


_engine: Engine | None = None
_control_engine: Engine | None = None
_session_factory: sessionmaker[Session] | None = None


def get_engine(settings: Settings | None = None) -> Engine:
    global _engine, _session_factory
    if _engine is None:
        settings = settings or get_settings()
        settings.ensure_dirs()
        _engine = make_engine(settings.database_url)
        _session_factory = sessionmaker(bind=_engine, expire_on_commit=False, autoflush=True)
    return _engine


def get_session_factory() -> sessionmaker[Session]:
    get_engine()
    if _session_factory is None:
        raise RuntimeError("the database engine could not be initialised")
    return _session_factory


def get_control_engine() -> Engine:
    """Engine for the worker's advisory writes (heartbeats, progress).

    SQLite has a single writer, so these writes use a short lock timeout and are skipped (then
    retried on the next tick) instead of stalling behind a job's own write transaction.
    PostgreSQL locks rows, not the database, so the main engine is used.
    """
    global _control_engine
    engine = get_engine()
    if engine.dialect.name != "sqlite":
        return engine
    if _control_engine is None:
        _control_engine = make_engine(str(engine.url), busy_timeout_ms=750)
    return _control_engine


def dispose_engine() -> None:
    """Drop the cached engines (tests / process shutdown)."""
    global _engine, _session_factory, _control_engine
    for engine in (_engine, _control_engine):
        if engine is not None:
            engine.dispose()
    _engine = _control_engine = None
    _session_factory = None


@contextlib.contextmanager
def session_scope() -> Iterator[Session]:
    """One unit of work: commit on success, roll back on any error, always close."""
    session = get_session_factory()()
    try:
        yield session
        session.commit()
    except BaseException:
        session.rollback()
        raise
    finally:
        session.close()


@contextlib.contextmanager
def read_session() -> Iterator[Session]:
    """A session for a read-only phase: plain ``BEGIN`` on SQLite (never blocks writers), always
    rolled back.  Long-running jobs load their inputs with this, compute with no transaction open,
    and then persist results in a short :func:`session_scope`.

    Rows loaded here are detached *before* the rollback, so their already-loaded columns stay
    readable afterwards as an immutable snapshot (a rollback would otherwise expire them).
    """
    with read_only_transactions():
        session = get_session_factory()()
        try:
            yield session
        finally:
            session.expunge_all()
            session.rollback()
            session.close()
