"""Human labels for support text, so that sentiment accuracy can be measured on something real.

Why this exists: everything the platform says about sentiment quality before this module rests on the synthetic
templates it ships with, and a threshold tuned on templates says nothing about a customer's inbox.  The missing
ingredient was never code — it is a labelled sample — so the work here is to make producing one a procedure rather
than a project:

* **A batch** is a set of support interactions, drawn from the tenant's own data (a plain sample, or a language, or
  an explicit list), declared synthetic or real at creation and never changed afterwards.
* **Two people** label each text independently.  A person may revise their own label while the batch is open; they
  cannot relabel somebody else's.
* **Agreement** is reported before the numbers are: exact agreement per pair of annotators, Cohen's kappa per pair,
  and the list of texts they disagreed on.  A set where people cannot agree with each other is not a benchmark for a
  model, and the report says so.
* **Adjudication** resolves each disagreement to a final label, with the reviewer's identity recorded.
* **Freezing** is the gate: a batch freezes only when every text has two labels and every disagreement is decided.
  After that it cannot change, and only a frozen batch can be exported or evaluated — so a model's accuracy can
  never be computed against a set that was edited after the numbers were seen.
* **Export** produces exactly the rows ``sentiment.evaluate`` reads, and ``evaluate_batch`` runs it, carrying the
  synthetic flag through so the result is never presented as evidence about real text when it is not.

The product does not choose labels and does not score annotators.  Who reviews, how many, and what a disagreement
means is the customer's process; this module only refuses to let the process be skipped.
"""

from __future__ import annotations

import hashlib
import random
from collections import Counter, defaultdict
from collections.abc import Iterable
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import Conflict, NotFound, ValidationFailed
from ..models import SentimentAnnotation, SentimentAnnotationBatch, SentimentAnnotationItem, SentimentScore, SupportInteraction
from ..security import Principal
from . import audit, sentiment
from .common import get_owned, paginate, to_dict

LABELS = ("positive", "negative", "neutral", "mixed")
REVIEWERS = 2  # independent labels a text needs before the batch can freeze
MAX_SAMPLE = 5000


# ----------------------------------------------------------------------------- helpers
def _text_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _item_labels(session: Session, item_id: int) -> dict[int, str]:
    rows = session.execute(select(SentimentAnnotation.annotator_id, SentimentAnnotation.label)
                           .where(SentimentAnnotation.item_id == item_id)).all()  # fmt: skip
    return {row.annotator_id: row.label for row in rows}


def _kappa(pairs: list[tuple[str, str]]) -> float | None:
    """Cohen's kappa for two annotators over the texts both labelled; None when there is nothing to compare."""
    if not pairs:
        return None
    observed = sum(1 for a, b in pairs if a == b) / len(pairs)
    first, second = Counter(a for a, _ in pairs), Counter(b for _, b in pairs)
    expected = sum((first[label] / len(pairs)) * (second[label] / len(pairs)) for label in LABELS)
    if expected >= 1.0:
        return None  # everybody used one label: kappa is undefined, not 1
    return round((observed - expected) / (1 - expected), 4)


def _pairs(labels_by_annotator: dict[int, dict[int, str]]) -> dict[tuple[int, int], list[tuple[str, str]]]:
    by_pair: dict[tuple[int, int], list[tuple[str, str]]] = defaultdict(list)
    annotators = sorted(labels_by_annotator)
    for index, first in enumerate(annotators):
        for second in annotators[index + 1:]:
            for item_id, label in labels_by_annotator[first].items():
                if item_id in labels_by_annotator[second]:
                    by_pair[(first, second)].append((label, labels_by_annotator[second][item_id]))
    return by_pair


# ----------------------------------------------------------------------------- batches
def batch_view(session: Session, batch: SentimentAnnotationBatch) -> dict:
    items = session.execute(select(func.count()).select_from(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)).scalar()
    labels = session.execute(select(func.count()).select_from(SentimentAnnotation).where(SentimentAnnotation.batch_id == batch.id)).scalar()
    with_two = session.execute(
        select(func.count()).select_from(
            select(SentimentAnnotation.item_id).where(SentimentAnnotation.batch_id == batch.id)
            .group_by(SentimentAnnotation.item_id).having(func.count(func.distinct(SentimentAnnotation.annotator_id)) >= REVIEWERS).subquery())
    ).scalar()
    decided = session.execute(select(func.count()).select_from(SentimentAnnotationItem)
                              .where(SentimentAnnotationItem.batch_id == batch.id, SentimentAnnotationItem.final_label.is_not(None))).scalar()  # fmt: skip
    reviews_per_item = round(labels / items, 2) if items else None
    view = to_dict(batch)
    view.update({"items": items, "labels": labels, "items_with_two_reviewers": with_two, "items_decided": decided,
                 "reviews_per_item": reviews_per_item,
                 "can_freeze": bool(items) and with_two == items and decided == items,
                 "reviewers_needed": REVIEWERS})
    return view


def create_batch(session: Session, principal: Principal, *, name: str, description: str | None = None, is_synthetic: bool = True,
                 language: str | None = None, sample: int = 200, interaction_ids: Iterable[int] | None = None) -> SentimentAnnotationBatch:
    """Draw a batch from the tenant's support text.  ``is_synthetic`` must describe where that text came from."""
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("a name is required", details={"field": "name"})
    if not 1 <= sample <= MAX_SAMPLE:
        raise ValidationFailed(f"sample must be between 1 and {MAX_SAMPLE}", details={"field": "sample"})
    if session.execute(select(SentimentAnnotationBatch).where(SentimentAnnotationBatch.tenant_id == principal.tenant_id,
                                                              SentimentAnnotationBatch.name == name)).scalar_one_or_none():  # fmt: skip
        raise Conflict(f"a batch named '{name}' already exists", code="annotation_batch_exists")
    stmt = select(SupportInteraction.id, SupportInteraction.body).where(SupportInteraction.tenant_id == principal.tenant_id,
                                                                      SupportInteraction.body.is_not(None), func.length(SupportInteraction.body) >= 20)  # fmt: skip
    if interaction_ids is not None:
        wanted = [int(i) for i in interaction_ids]
        if not wanted:
            raise ValidationFailed("interaction_ids is empty", details={"field": "interaction_ids"})
        stmt = stmt.where(SupportInteraction.id.in_(wanted))
    rows = session.execute(stmt.order_by(SupportInteraction.opened_at.desc()).limit(sample * 5)).all()
    if not rows:
        raise Conflict("there is no support text to label in this tenant", code="annotation_no_text")
    if interaction_ids is None:
        picked = random.Random(len(rows)).sample(rows, min(sample, len(rows)))
    else:
        picked = rows[:sample]
    batch = SentimentAnnotationBatch(tenant_id=principal.tenant_id, name=name, description=description,
                                     is_synthetic=is_synthetic, language=language, status="open", rows=len(picked),
                                     created_by=principal.user_id)  # fmt: skip
    session.add(batch)
    session.flush()
    for row in picked:
        session.add(SentimentAnnotationItem(tenant_id=principal.tenant_id, batch_id=batch.id, interaction_id=row.id,
                                            text_sha256=_text_hash(row.body)))  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, action="sentiment.annotation_batch_created", actor=principal,
                 entity_type="sentiment_annotation_batch", entity_id=batch.id,
                 detail={"name": name, "items": len(picked), "is_synthetic": is_synthetic})  # fmt: skip
    session.flush()
    return batch


def list_batches(session: Session, tenant_id: int, *, status: str | None = None, page: int = 1, page_size: int = 50) -> dict:
    stmt = select(SentimentAnnotationBatch).where(SentimentAnnotationBatch.tenant_id == tenant_id)
    if status:
        stmt = stmt.where(SentimentAnnotationBatch.status == status)
    return paginate(session, stmt.order_by(SentimentAnnotationBatch.id.desc()), page=page, page_size=page_size,
                    serializer=lambda batch: batch_view(session, batch))  # fmt: skip


def _batch(session: Session, principal: Principal, batch_id: int) -> SentimentAnnotationBatch:
    return get_owned(session, SentimentAnnotationBatch, principal.tenant_id, batch_id, label="Annotation batch")


def _open_batch(session: Session, principal: Principal, batch_id: int) -> SentimentAnnotationBatch:
    batch = _batch(session, principal, batch_id)
    if batch.status != "open":
        raise Conflict("this batch is frozen; labels cannot change after the numbers have been read", code="annotation_batch_frozen")
    return batch


# ----------------------------------------------------------------------------- labelling
def items_of(session: Session, batch: SentimentAnnotationBatch, *, principal: Principal | None = None,
             only_unlabelled_by_me: bool = False, page: int = 1, page_size: int = 50) -> dict:
    stmt = select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)
    mine = {row.item_id for row in session.execute(select(SentimentAnnotation.item_id)
            .where(SentimentAnnotation.batch_id == batch.id, SentimentAnnotation.annotator_id == (principal.user_id if principal else -1))).all()}  # fmt: skip
    if only_unlabelled_by_me and mine:
        stmt = stmt.where(SentimentAnnotationItem.id.not_in(mine))
    page_data = paginate(session, stmt.order_by(SentimentAnnotationItem.id), page=page, page_size=page_size,
                         serializer=lambda item: _item_view(session, item, mine))  # fmt: skip
    return page_data


def _item_view(session: Session, item: SentimentAnnotationItem, mine: set[int]) -> dict:
    interaction = session.get(SupportInteraction, item.interaction_id)
    labels = _item_labels(session, item.id)
    view = to_dict(item)
    view.update({
        "text": interaction.body if interaction else None,
        "opened_at": interaction.opened_at.isoformat() if interaction and interaction.opened_at else None,
        "labels": len(labels),
        "my_label": labels.get(next(iter(mine), -1)),
        "labels_agree": len(set(labels.values())) <= 1 if labels else None,
    })
    return view


def submit(session: Session, principal: Principal, batch_id: int, interaction_id: int, label: str, note: str | None = None) -> dict:
    """Record this person's label for one text.  Their own earlier label is replaced; somebody else's is not."""
    batch = _open_batch(session, principal, batch_id)
    if label not in LABELS:
        raise ValidationFailed(f"label must be one of {', '.join(LABELS)}", details={"field": "label"})
    item = session.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id,
                                                                 SentimentAnnotationItem.interaction_id == interaction_id)).scalar_one_or_none()  # fmt: skip
    if item is None:
        raise NotFound(f"interaction {interaction_id} is not part of batch {batch_id}")
    interaction = session.get(SupportInteraction, item.interaction_id)
    if interaction is None or (interaction.body and _text_hash(interaction.body) != item.text_sha256):
        raise Conflict("the support text changed after it was added to this batch; the batch is no longer usable for it",
                       code="annotation_text_changed")
    existing = session.execute(select(SentimentAnnotation).where(SentimentAnnotation.item_id == item.id,
                                                                SentimentAnnotation.annotator_id == principal.user_id)).scalar_one_or_none()  # fmt: skip
    if existing is None:
        session.add(SentimentAnnotation(tenant_id=principal.tenant_id, batch_id=batch.id, item_id=item.id,
                                        annotator_id=principal.user_id, label=label, note=note))  # fmt: skip
        action = "sentiment.annotation_added"
    else:
        existing.label, existing.note, existing.updated_at = label, note, utcnow()
        action = "sentiment.annotation_changed"
    audit.record(session, tenant_id=principal.tenant_id, action=action, actor=principal,
                 entity_type="sentiment_annotation_item", entity_id=item.id, detail={"label": label})  # fmt: skip
    session.flush()
    return {"batch_id": batch.id, "interaction_id": interaction_id, "label": label, "changed": existing is not None}


def agreement(session: Session, principal: Principal, batch_id: int) -> dict:
    """How far the people labelling this batch agree with each other, before any model is scored against it."""
    batch = _batch(session, principal, batch_id)
    items = session.execute(select(SentimentAnnotationItem.id).where(SentimentAnnotationItem.batch_id == batch.id)).scalars().all()
    by_annotator: dict[int, dict[int, str]] = defaultdict(dict)
    for annotation in session.execute(select(SentimentAnnotation).where(SentimentAnnotation.batch_id == batch.id)).scalars():
        by_annotator[annotation.annotator_id][annotation.item_id] = annotation.label
    pairs = _pairs(by_annotator)
    by_pair = []
    for (first, second), values in sorted(pairs.items()):
        same = sum(1 for a, b in values if a == b)
        by_pair.append({"first": first, "second": second, "together": len(values), "agree": same,
                        "exact_agreement": round(same / len(values), 4) if values else None, "kappa": _kappa(values)})
    disagreements = []
    for item_id in items:
        labels = {annotator: labels_map[item_id] for annotator, labels_map in by_annotator.items() if item_id in labels_map}
        if len(set(labels.values())) > 1:
            interaction = session.execute(select(SentimentAnnotationItem.interaction_id)
                                          .where(SentimentAnnotationItem.id == item_id)).scalar()  # fmt: skip
            disagreements.append({"interaction_id": interaction, "labels": labels})
    annotated = [item for item in items if len([1 for m in by_annotator.values() if item in m]) >= REVIEWERS]
    return {"batch_id": batch.id, "items": len(items), "items_with_two_reviewers": len(annotated),
            "annotators": {str(k): len(v) for k, v in by_annotator.items()}, "pairs": by_pair,
            "disagreements": disagreements,
            "mean_kappa": round(sum(p["kappa"] for p in by_pair if p["kappa"] is not None) /
                                max(1, len([p for p in by_pair if p["kappa"] is not None])), 4) if by_pair else None,
            "note": "agreement between people is measured first: a set they cannot agree on is not a benchmark"}


def adjudicate(session: Session, principal: Principal, batch_id: int, interaction_id: int, label: str, note: str | None = None) -> dict:
    """Decide one text's final label, recording who decided."""
    batch = _open_batch(session, principal, batch_id)
    if label not in LABELS:
        raise ValidationFailed(f"label must be one of {', '.join(LABELS)}", details={"field": "label"})
    item = session.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id,
                                                                 SentimentAnnotationItem.interaction_id == interaction_id)).scalar_one_or_none()  # fmt: skip
    if item is None:
        raise NotFound(f"interaction {interaction_id} is not part of batch {batch_id}")
    item.final_label, item.decided_by, item.decided_at = label, principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, action="sentiment.annotation_adjudicated", actor=principal,
                 entity_type="sentiment_annotation_item", entity_id=item.id,
                 detail={"label": label, "note": note})  # fmt: skip
    session.flush()
    return {"batch_id": batch.id, "interaction_id": interaction_id, "final_label": label}


def freeze(session: Session, principal: Principal, batch_id: int) -> SentimentAnnotationBatch:
    """Close the batch.  Refused while a text lacks a second reviewer or a disagreement is undecided."""
    batch = _open_batch(session, principal, batch_id)
    items = session.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)).scalars().all()
    if not items:
        raise Conflict("this batch has no items", code="annotation_batch_empty")
    problems = []
    for item in items:
        labels = _item_labels(session, item.id)
        if len(labels) < REVIEWERS:
            problems.append({"interaction_id": item.interaction_id, "problem": f"{len(labels)} of {REVIEWERS} labels"})
        elif len(set(labels.values())) > 1 and item.final_label is None:
            problems.append({"interaction_id": item.interaction_id, "problem": "reviewers disagree and no decision is recorded"})
    if problems:
        raise Conflict("this batch cannot be frozen yet", code="annotation_batch_incomplete",
                       details={"problems": problems[:50], "count": len(problems)})  # fmt: skip
    for item in items:
        if item.final_label is None:  # every reviewer said the same thing: that agreement is the final label
            agreed = next(iter(_item_labels(session, item.id).values()))
            item.final_label, item.decided_by, item.decided_at = agreed, principal.user_id, utcnow()
    batch.status, batch.frozen_at = "frozen", utcnow()
    audit.record(session, tenant_id=principal.tenant_id, action="sentiment.annotation_batch_frozen", actor=principal,
                 entity_type="sentiment_annotation_batch", entity_id=batch.id,
                 detail={"items": len(items), "is_synthetic": batch.is_synthetic})  # fmt: skip
    session.flush()
    return batch


# ----------------------------------------------------------------------------- export and evaluation
def export_rows(session: Session, principal: Principal, batch_id: int) -> list[dict[str, Any]]:
    """The labelled set, in exactly the shape ``sentiment.evaluate`` reads.  Frozen batches only."""
    batch = _batch(session, principal, batch_id)
    if batch.status != "frozen":
        raise Conflict("only a frozen batch can be exported: freeze it first, so the numbers cannot be read while the set still moves",
                       code="annotation_batch_open")  # fmt: skip
    rows = []
    for item in session.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)
                                .order_by(SentimentAnnotationItem.id)).scalars():  # fmt: skip
        interaction = session.get(SupportInteraction, item.interaction_id)
        if interaction is None or not interaction.body:
            raise Conflict(f"interaction {item.interaction_id} of this batch no longer has text", code="annotation_text_missing")
        rows.append({"text": interaction.body, "label": item.final_label, "interaction_id": interaction.id, "language": batch.language})
    return rows


def evaluate_batch(session: Session, principal: Principal, batch_id: int, *, dataset_name: str | None = None) -> dict:
    """Score the active sentiment provider against a frozen batch, carrying the batch's synthetic flag through."""
    batch = _batch(session, principal, batch_id)
    rows = export_rows(session, principal, batch_id)
    evaluation = sentiment.evaluate(session, principal, dataset_name=dataset_name or f"annotation batch {batch.name}",
                                    rows=[{"text": row["text"], "label": row["label"]} for row in rows],
                                    is_synthetic=batch.is_synthetic)  # fmt: skip
    return {"evaluation": sentiment.evaluation_view(evaluation), "batch": batch_view(session, batch),
            "is_synthetic": batch.is_synthetic}


def model_disagreements(session: Session, principal: Principal, batch_id: int) -> dict:
    """Where the model and the people differ — the list a reviewer works through next."""
    batch = _batch(session, principal, batch_id)
    if batch.status != "frozen":
        raise Conflict("freeze the batch first", code="annotation_batch_open")
    model = sentiment.active_model(session, principal.tenant_id)
    rows, differing = [], 0
    for item in session.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)).scalars():
        score = session.execute(select(SentimentScore).where(SentimentScore.interaction_id == item.interaction_id,
                                                             SentimentScore.sentiment_model_id == (model.id if model else -1))).scalar_one_or_none()  # fmt: skip
        predicted = score.label if score else None
        differs = bool(predicted) and predicted != item.final_label
        differing += 1 if differs else 0
        rows.append({"interaction_id": item.interaction_id, "human": item.final_label, "model": predicted,
                     "confidence": score.confidence if score else None, "differs": differs})
    return {"batch_id": batch.id, "model": sentiment.model_view(model) if model else None, "rows": rows,
            "differing": differing, "of": len(rows)}
