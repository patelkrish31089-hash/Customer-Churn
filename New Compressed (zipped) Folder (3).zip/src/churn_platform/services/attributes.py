"""History of slowly changing customer attributes (industry, company size, employees, geography, channel).

Every (customer, attribute) has a timeline of periods.  The first value the platform ever saw is assumed to have
held since the customer began (basis ``initial``); every later change opens a new period.  Nothing is edited in
place except closing the open period: a rewrite of known history marks the old rows superseded and writes new
ones, so "what did the platform believe on day T" stays answerable.

Bases
  initial     first value seen; assumed to hold since the beginning (an assumption, shown as such)
  effective   a change whose source said when it took effect
  observed    a change that the platform noticed at import time (effective date = when it was noticed)
  backfill    declared history: trusted for any as-of date inside its period
  correction  a fix of known history: used only for as-of dates after it was recorded

Point-in-time features read these periods through ``feature_engine._attributes_at``.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import exists, func, insert, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import NotFound, ValidationFailed
from ..models import ATTRIBUTE_BASES, Customer, CustomerAttributeHistory, EntityHistory
from ..security import Principal
from . import audit
from .common import json_safe, to_dict

TRACKED = ("industry", "company_size", "employee_count", "region", "country", "acquisition_channel")
History = CustomerAttributeHistory


def as_text(value: Any) -> str | None:
    """Attribute values are stored as text; numbers lose a trailing ``.0`` so that 250 and 250.0 are one value."""
    if value is None or value == "":
        return None
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return str(value)[:300]


def _utc(value: datetime | None) -> datetime | None:
    from datetime import UTC

    if value is None:
        return None
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _lt(a: datetime | None, b: datetime | None, *, a_open: str, b_open: str) -> bool:
    """a < b where None means minus infinity (``start``) or plus infinity (``end``)."""
    if a is None:
        return a_open == "start" and not (b is None and b_open == "start")
    if b is None:
        return b_open == "end"
    return _utc(a) < _utc(b)  # type: ignore[operator]


def current_rows(session: Session, tenant_id: int, customer_id: int, attribute: str) -> list[History]:
    rows = session.execute(select(History).where(History.tenant_id == tenant_id, History.customer_id == customer_id, History.attribute == attribute,
                                                 History.superseded_at.is_(None))).scalars().all()  # fmt: skip
    return sorted(rows, key=lambda r: (r.valid_from is not None, _utc(r.valid_from) or datetime.min, r.id))


def apply(session: Session, tenant_id: int, customer_id: int, attribute: str, value: Any, *, valid_from: datetime | None,
          valid_to: datetime | None = None, basis: str, source: str = "import", dataset_version_id: int | None = None,
          recorded_by: int | None = None, note: str | None = None, now: datetime | None = None) -> History | None:
    """Make ``value`` hold during ``[valid_from, valid_to)``; whatever the timeline said for that period is
    superseded, and the parts of older periods outside it are kept.  Returns the new row (None: nothing changed)."""
    if attribute not in TRACKED:
        raise ValidationFailed(f"attribute must be one of {', '.join(TRACKED)}", details={"field": "attribute"})
    if basis not in ATTRIBUTE_BASES:
        raise ValidationFailed(f"basis must be one of {', '.join(ATTRIBUTE_BASES)}", details={"field": "basis"})
    valid_from, valid_to = _utc(valid_from), _utc(valid_to)
    if valid_from is not None and valid_to is not None and valid_to <= valid_from:
        raise ValidationFailed("the period must end after it starts", details={"field": "valid_to"})
    now, text = now or utcnow(), as_text(value)
    rows = current_rows(session, tenant_id, customer_id, attribute)
    overlapping = [r for r in rows if _lt(r.valid_from, valid_to, a_open="start", b_open="end") and _lt(valid_from, r.valid_to, a_open="start", b_open="end")]
    if overlapping and all(r.value == text for r in overlapping) and len(overlapping) == 1:
        only = overlapping[0]
        covers = not _lt(valid_from, only.valid_from, a_open="start", b_open="start") and not _lt(only.valid_to, valid_to, a_open="end", b_open="end")
        if covers:
            return None  # the timeline already says exactly this
    new = History(tenant_id=tenant_id, customer_id=customer_id, attribute=attribute, value=text, valid_from=valid_from, valid_to=valid_to,
                  basis=basis, source=source, dataset_version_id=dataset_version_id, recorded_at=now, recorded_by=recorded_by, note=note)  # fmt: skip
    session.add(new)
    session.flush()
    for row in overlapping:
        starts_before = _lt(row.valid_from, valid_from, a_open="start", b_open="start")
        ends_after = valid_to is not None and _lt(valid_to, row.valid_to, a_open="end", b_open="end")
        from_now_on = valid_from is not None and valid_from >= now
        if starts_before and not ends_after and row.valid_to is None and (basis in ("effective", "observed") or (basis == "correction" and from_now_on)):
            row.valid_to = valid_from  # the ordinary case: the open period ends where the new one begins
            continue
        row.superseded_at, row.superseded_by = now, new.id
        for start, end, keep in ((row.valid_from, valid_from, starts_before), (valid_to, row.valid_to, ends_after)):
            if keep:
                session.add(History(tenant_id=tenant_id, customer_id=customer_id, attribute=attribute, value=row.value, valid_from=start,
                                    valid_to=end, basis=row.basis, source=row.source, dataset_version_id=row.dataset_version_id,
                                    recorded_at=row.recorded_at, recorded_by=row.recorded_by,
                                    note=f"period re-cut when history row {new.id} was recorded"))  # fmt: skip
    session.flush()
    return new


def any_without_history(session: Session, tenant_id: int) -> bool:
    """Is there a customer who has no attribute timeline yet?  One indexed lookup; safe in a read-only session."""
    return session.execute(select(Customer.id).where(Customer.tenant_id == tenant_id, ~exists(select(History.id).where(History.customer_id == Customer.id)))
                           .limit(1)).first() is not None  # fmt: skip


def ensure_initial(session: Session, tenant_id: int) -> dict:
    """Give every customer that has no history yet a timeline.  Changes the platform already recorded in its
    change log (``entity_history``) are replayed, so an installation upgraded from 1.0 keeps what it knew."""
    without = select(Customer).where(Customer.tenant_id == tenant_id, ~exists(select(History.id).where(History.customer_id == Customer.id)))
    customers = session.execute(without).scalars().all()
    if not customers:
        return {"customers": 0, "rows": 0, "replayed_changes": 0}
    ids = [c.id for c in customers]
    changes: dict[int, list[Any]] = {}
    for start in range(0, len(ids), 500):
        stmt = select(EntityHistory).where(EntityHistory.tenant_id == tenant_id, EntityHistory.entity_type == "customers",
                                           EntityHistory.entity_id.in_(ids[start : start + 500])).order_by(EntityHistory.changed_at, EntityHistory.id)  # fmt: skip
        for change in session.execute(stmt).scalars():
            changes.setdefault(change.entity_id, []).append(change)
    now, rows, replayed = utcnow(), [], 0
    for customer in customers:
        for attribute in TRACKED:
            steps = [(c.changed_at, (c.before or {}).get(attribute), (c.after or {}).get(attribute), c.change_source, c.dataset_version_id)
                     for c in changes.get(customer.id, []) if isinstance(c.before, dict) and attribute in c.before]  # fmt: skip
            first = steps[0][1] if steps else getattr(customer, attribute)
            start: datetime | None = None
            value, basis, known_at, dataset = first, "initial", customer.created_at, customer.dataset_version_id
            for changed_at, _before, after, change_source, change_dataset in steps:
                rows.append(_row(tenant_id, customer.id, attribute, value, start, changed_at, basis, known_at, dataset))
                value, start, basis, known_at, dataset = after, changed_at, "correction" if change_source == "correction" else "observed", changed_at, change_dataset
                replayed += 1
            rows.append(_row(tenant_id, customer.id, attribute, value, start, None, basis, known_at, dataset))
    for start_at in range(0, len(rows), 2000):
        session.execute(insert(History.__table__), rows[start_at : start_at + 2000])
    audit.record(session, tenant_id=tenant_id, action="attributes.history_initialised", entity_type="tenant", entity_id=tenant_id,
                 detail={"customers": len(customers), "rows": len(rows), "replayed_changes": replayed, "at": now.isoformat()})  # fmt: skip
    return {"customers": len(customers), "rows": len(rows), "replayed_changes": replayed}


def _row(tenant_id: int, customer_id: int, attribute: str, value: Any, start: datetime | None, end: datetime | None, basis: str,
         recorded_at: datetime, dataset_version_id: int | None) -> dict:
    return {"tenant_id": tenant_id, "customer_id": customer_id, "attribute": attribute, "value": as_text(value), "valid_from": start,
            "valid_to": end, "basis": basis, "source": "import", "dataset_version_id": dataset_version_id, "recorded_at": recorded_at,
            "recorded_by": None, "superseded_at": None, "superseded_by": None,
            "note": "first value seen; assumed to hold since the customer began" if basis == "initial" else None}  # fmt: skip


def after_customer_load(session: Session, tenant_id: int, changes: list[dict], *, dataset_version_id: int | None, recorded_by: int | None,
                        now: datetime) -> int:
    """Called by the import for customers it inserted or changed.  ``changes``: ``{customer_id, attribute, value,
    effective_at}``; a new customer simply gets its timeline through ``ensure_initial``."""
    ensure_initial(session, tenant_id)
    written = 0
    for change in changes:
        effective = _utc(change.get("effective_at"))
        if effective is not None and effective > now:
            effective = None  # a date in the future cannot be when the platform learned of a value it already holds
        row = apply(session, tenant_id, change["customer_id"], change["attribute"], change["value"], valid_from=effective or now,
                    basis="effective" if effective is not None else "observed", source="import", dataset_version_id=dataset_version_id,
                    recorded_by=recorded_by, now=now)  # fmt: skip
        written += row is not None
    return written


def record(session: Session, principal: Principal, customer_id: int, *, attribute: str, value: Any, valid_from: datetime | None,
           valid_to: datetime | None = None, basis: str = "correction", note: str | None = None) -> History:
    """A person rewrites part of a customer's attribute history (backfill = declared history, correction = a fix)."""
    customer = session.get(Customer, customer_id)
    if customer is None or customer.tenant_id != principal.tenant_id:
        raise NotFound("Customer not found")
    if basis not in ("backfill", "correction"):
        raise ValidationFailed("basis must be 'backfill' or 'correction'", details={"field": "basis"})
    if not (note or "").strip():
        raise ValidationFailed("a note saying why history is rewritten is required", details={"field": "note"})
    row = apply(session, principal.tenant_id, customer_id, attribute, value, valid_from=valid_from, valid_to=valid_to, basis=basis, source="manual",
                recorded_by=principal.user_id, note=note.strip()[:1000])  # type: ignore[union-attr]
    if row is None:
        raise ValidationFailed("the history already says exactly this; nothing was changed")
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="attributes.history_rewritten", entity_type="customer",
                 entity_id=customer_id, detail={"attribute": attribute, "value": as_text(value), "valid_from": json_safe(valid_from),
                                                "valid_to": json_safe(valid_to), "basis": basis, "note": note})  # fmt: skip
    return row


def timeline(session: Session, tenant_id: int, customer_id: int, *, include_superseded: bool = True) -> dict:
    customer = session.get(Customer, customer_id)
    if customer is None or customer.tenant_id != tenant_id:
        raise NotFound("Customer not found")
    stmt = select(History).where(History.tenant_id == tenant_id, History.customer_id == customer_id)
    if not include_superseded:
        stmt = stmt.where(History.superseded_at.is_(None))
    rows = session.execute(stmt.order_by(History.attribute, History.valid_from.is_(None).desc(), History.valid_from, History.id)).scalars().all()
    return {"customer_id": customer_id, "tracked": list(TRACKED),
            "current": {a: as_text(getattr(customer, a)) for a in TRACKED},
            "periods": [to_dict(r, include={"is_current": r.superseded_at is None}) for r in rows]}  # fmt: skip


def value_at(session: Session, tenant_id: int, customer_id: int, attribute: str, at: datetime, *, as_known: bool = True) -> str | None:
    """The value at ``at``: as the platform knew it then (``as_known``), or as it is known today."""
    rows = session.execute(select(History).where(History.tenant_id == tenant_id, History.customer_id == customer_id, History.attribute == attribute)).scalars().all()
    at = _utc(at)  # type: ignore[assignment]
    best = None
    for row in rows:
        valid = (row.valid_from is None or _utc(row.valid_from) < at) and (row.valid_to is None or _utc(row.valid_to) >= at)  # type: ignore[operator]
        if as_known:
            known = row.basis not in ("observed", "correction") or _utc(row.recorded_at) < at  # type: ignore[operator]
            alive = row.superseded_at is None or _utc(row.superseded_at) >= at  # type: ignore[operator]
        else:
            known, alive = True, row.superseded_at is None
        if valid and known and alive:
            key = (row.valid_from is not None, _utc(row.valid_from) or datetime.min.replace(tzinfo=at.tzinfo), row.id)
            if best is None or key > best[0]:
                best = (key, row.value)
    return best[1] if best else None


def summary(session: Session, tenant_id: int) -> dict:
    """How much history there is, and how much of it is assumption."""
    base = (History.tenant_id == tenant_id, History.superseded_at.is_(None))
    by_basis = dict(session.execute(select(History.basis, func.count()).where(*base).group_by(History.basis)).all())
    changed = session.execute(select(History.attribute, func.count(func.distinct(History.customer_id))).where(*base, History.valid_from.is_not(None))
                              .group_by(History.attribute)).all()  # fmt: skip
    customers = session.execute(select(func.count()).select_from(Customer).where(Customer.tenant_id == tenant_id)).scalar_one()
    covered = session.execute(select(func.count(func.distinct(History.customer_id))).where(History.tenant_id == tenant_id)).scalar_one()
    superseded = session.execute(select(func.count()).select_from(History).where(History.tenant_id == tenant_id, History.superseded_at.is_not(None))).scalar_one()
    recent = session.execute(select(History, Customer.external_id, Customer.name).join(Customer, Customer.id == History.customer_id)
                             .where(*base, History.valid_from.is_not(None)).order_by(History.recorded_at.desc(), History.id.desc()).limit(25)).all()  # fmt: skip
    return {"tracked": list(TRACKED), "customers": customers, "customers_with_history": covered, "periods_by_basis": by_basis,
            "customers_with_changes": {row[0]: row[1] for row in changed}, "superseded_rows": superseded,
            "recent_changes": [to_dict(r, include={"customer_external_id": ext, "customer_name": name}) for r, ext, name in recent],
            "note": "Periods with basis 'initial' are an assumption: the first value the platform saw is taken to have held since the "
                    "customer began. Changes that happened before the platform first saw the customer are unknown unless backfilled."}  # fmt: skip
