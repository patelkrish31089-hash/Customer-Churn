"""The governed product-feature catalogue and feature adoption.

*Catalogue.*  Each entry says what a product feature is, which telemetry counts as using it, how much use counts
as adoption, and who can use it when (release and retirement dates, plan tiers).  Entries are versioned; a version
counts only after somebody other than its author approved it.

*Adoption.*  A customer has adopted a feature in a period when its use reaches the entry's rule (events and
distinct days).  Rates always have an explicit denominator - the features the customer could use at that date -
and are missing, never zero, when that denominator is empty.

The arithmetic lives in ``feature_engine.AdoptionGrid`` and is the same for model features and for this report.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, ValidationFailed
from ..models import AdoptionFact, AdoptionRun, Customer, ProductFeature, UsageEvent
from ..security import Principal
from . import audit, feature_engine, jobs, timeline
from .common import get_owned, next_version, parse_date, to_dict
from .schemas import USAGE_EVENT_TYPES

AVAILABILITY = ("ga", "beta", "limited", "deprecated", "retired")
KEY = re.compile(r"^[a-z][a-z0-9_]{0,79}$")
CHUNK = 2000
KEEP_FACTS_OF_RUNS = 3


# ----------------------------------------------------------------------------- catalogue
def feature_view(feature: ProductFeature) -> dict:
    return to_dict(feature)


def _clean(payload: dict) -> dict:
    key = str(payload.get("feature_key") or "").strip().lower()
    if not KEY.match(key):
        raise ValidationFailed("feature_key must start with a letter and contain only lower-case letters, digits and underscores (max 80)",
                               details={"field": "feature_key"})  # fmt: skip
    name = str(payload.get("name") or "").strip()
    if not name:
        raise ValidationFailed("a name is required", details={"field": "name"})
    availability = payload.get("availability") or "ga"
    if availability not in AVAILABILITY:
        raise ValidationFailed(f"availability must be one of {', '.join(AVAILABILITY)}", details={"field": "availability"})
    release, retired = parse_date(payload.get("release_date"), field="release_date"), parse_date(payload.get("retired_date"), field="retired_date")
    if release and retired and retired < release:
        raise ValidationFailed("a feature cannot be retired before it was released", details={"field": "retired_date"})
    mapping = payload.get("event_mapping")
    if not isinstance(mapping, list) or not mapping:
        raise ValidationFailed("event_mapping must list at least one {event_type, feature_name} that counts as using the feature",
                               details={"field": "event_mapping"})  # fmt: skip
    cleaned_mapping, seen = [], set()
    for n, item in enumerate(mapping):
        if not isinstance(item, dict) or not str(item.get("feature_name") or "").strip():
            raise ValidationFailed(f"event_mapping[{n}] needs a feature_name", details={"field": "event_mapping"})
        event_type = item.get("event_type") or "feature_use"
        if event_type not in USAGE_EVENT_TYPES:
            raise ValidationFailed(f"event_mapping[{n}].event_type must be one of {', '.join(USAGE_EVENT_TYPES)}", details={"field": "event_mapping"})
        pair = (event_type, str(item["feature_name"]).strip().casefold())
        if pair not in seen:
            seen.add(pair)
            cleaned_mapping.append({"event_type": pair[0], "feature_name": pair[1]})
    rule = payload.get("adoption_rule") or {}
    if not isinstance(rule, dict) or set(rule) - {"min_events", "min_days"}:
        raise ValidationFailed("adoption_rule may contain min_events and min_days", details={"field": "adoption_rule"})
    min_events, min_days = rule.get("min_events", 1), rule.get("min_days", 1)
    for label, value, top in (("min_events", min_events, 100000), ("min_days", min_days, 365)):
        if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= top:
            raise ValidationFailed(f"adoption_rule.{label} must be a whole number from 1 to {top}", details={"field": "adoption_rule"})
    eligibility = payload.get("eligibility") or {}
    if not isinstance(eligibility, dict) or set(eligibility) - {"plan_tiers"}:
        raise ValidationFailed("eligibility may contain plan_tiers", details={"field": "eligibility"})
    tiers = eligibility.get("plan_tiers")
    if tiers is not None and (not isinstance(tiers, list) or not tiers or any(not isinstance(t, str) or not t.strip() for t in tiers)):
        raise ValidationFailed("eligibility.plan_tiers must be a non-empty list of plan tiers", details={"field": "eligibility"})
    return {
        "feature_key": key, "name": name[:160], "description": (payload.get("description") or None), "category": (payload.get("category") or None),
        "availability": availability, "required_plan": (payload.get("required_plan") or None), "release_date": release, "retired_date": retired,
        "eligibility": {"plan_tiers": [t.strip() for t in tiers]} if tiers else None, "event_mapping": cleaned_mapping,
        "adoption_rule": {"min_events": min_events, "min_days": min_days}, "owner": (payload.get("owner") or None),
        "is_core": bool(payload.get("is_core", False)),
    }  # fmt: skip


def create_feature(session: Session, principal: Principal, payload: dict) -> ProductFeature:
    """A new draft version of a catalogue entry (the first version creates the entry)."""
    values = _clean(payload)
    version = next_version(session, ProductFeature, tenant_id=principal.tenant_id, feature_key=values["feature_key"])
    feature = ProductFeature(tenant_id=principal.tenant_id, version=version, status="draft", is_active=True, created_by=principal.user_id, **values)
    session.add(feature)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="catalog.feature_drafted", entity_type="product_feature",
                 entity_id=feature.id, detail={"feature_key": feature.feature_key, "version": version})  # fmt: skip
    return feature


def submit(session: Session, principal: Principal, feature_id: int) -> ProductFeature:
    feature = get_owned(session, ProductFeature, principal.tenant_id, feature_id, label="Catalogue entry")
    if feature.status != "draft":
        raise Conflict(f"only a draft can be submitted (this version is {feature.status})")
    feature.status = "pending"
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="catalog.feature_submitted", entity_type="product_feature",
                 entity_id=feature.id, detail={"feature_key": feature.feature_key, "version": feature.version})  # fmt: skip
    return feature


def mapping_conflicts(session: Session, tenant_id: int, candidate: ProductFeature | None = None) -> list[dict]:
    """Telemetry that two different catalogue features both claim (after ``candidate`` would be approved)."""
    entries = {f.feature_key: f for f in timeline.approved_catalog(session, tenant_id)}
    if candidate is not None:
        entries[candidate.feature_key] = candidate
    owners: dict[tuple[str, str], list[str]] = {}
    for feature in entries.values():
        for item in feature.event_mapping or []:
            owners.setdefault((item.get("event_type") or "feature_use", str(item.get("feature_name"))), []).append(feature.feature_key)
    return [{"event_type": etype, "feature_name": name, "claimed_by": sorted(keys)} for (etype, name), keys in sorted(owners.items()) if len(keys) > 1]


def review(session: Session, principal: Principal, feature_id: int, *, approve: bool, note: str | None = None) -> ProductFeature:
    feature = get_owned(session, ProductFeature, principal.tenant_id, feature_id, label="Catalogue entry")
    if feature.status != "pending":
        raise Conflict(f"only a submitted version can be reviewed (this version is {feature.status})")
    if feature.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a catalogue entry cannot be reviewed by the person who wrote it", code="self_approval_forbidden")
    if approve:
        conflicts = [c for c in mapping_conflicts(session, principal.tenant_id, feature) if feature.feature_key in c["claimed_by"]]
        if conflicts:
            raise Conflict("this version maps telemetry that another approved feature already claims; one event can count for one feature only",
                           code="mapping_conflict", details=conflicts)  # fmt: skip
    feature.status, feature.reviewed_by, feature.reviewed_at, feature.review_note = "approved" if approve else "rejected", principal.user_id, utcnow(), note
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="catalog.feature_approved" if approve else "catalog.feature_rejected",
                 entity_type="product_feature", entity_id=feature.id, detail={"feature_key": feature.feature_key, "version": feature.version, "note": note})  # fmt: skip
    return feature


def set_active(session: Session, principal: Principal, feature_id: int, active: bool) -> ProductFeature:
    """Switch an approved entry off (or on again) without losing its history."""
    feature = get_owned(session, ProductFeature, principal.tenant_id, feature_id, label="Catalogue entry")
    if feature.status != "approved":
        raise Conflict("only an approved version can be switched on or off")
    feature.is_active = active
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="catalog.feature_activated" if active else "catalog.feature_deactivated",
                 entity_type="product_feature", entity_id=feature.id, detail={"feature_key": feature.feature_key, "version": feature.version})  # fmt: skip
    return feature


def catalog_hash(features: list[ProductFeature]) -> str:
    payload = [[f.feature_key, f.version, f.event_mapping, f.adoption_rule, f.eligibility, f.required_plan, str(f.release_date), str(f.retired_date),
                f.is_core] for f in sorted(features, key=lambda f: f.feature_key)]  # fmt: skip
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str).encode()).hexdigest()


def list_catalog(session: Session, tenant_id: int) -> dict:
    rows = session.execute(select(ProductFeature).where(ProductFeature.tenant_id == tenant_id)
                           .order_by(ProductFeature.feature_key, ProductFeature.version.desc())).scalars().all()  # fmt: skip
    in_force = {f.id for f in timeline.approved_catalog(session, tenant_id)}
    return {"items": [to_dict(f, include={"in_force": f.id in in_force}) for f in rows], "total": len(rows), "in_force": len(in_force),
            "conflicts": mapping_conflicts(session, tenant_id)}  # fmt: skip


def telemetry_names(session: Session, tenant_id: int, limit: int = 200) -> list[dict]:
    """Feature names seen in telemetry, with whether the catalogue in force maps them."""
    mapped = {(m.get("event_type") or "feature_use", str(m.get("feature_name"))): f.feature_key
              for f in timeline.approved_catalog(session, tenant_id) for m in f.event_mapping or []}  # fmt: skip
    rows = session.execute(select(UsageEvent.event_type, UsageEvent.feature_name, func.count(), func.min(UsageEvent.occurred_at), func.max(UsageEvent.occurred_at))
                           .where(UsageEvent.tenant_id == tenant_id, UsageEvent.feature_name.is_not(None))
                           .group_by(UsageEvent.event_type, UsageEvent.feature_name).order_by(func.count().desc()).limit(limit)).all()  # fmt: skip
    return [{"event_type": etype, "feature_name": name, "events": int(n), "first_seen": first, "last_seen": last,
             "mapped_to": mapped.get((etype, str(name).strip().casefold()))} for etype, name, n, first, last in rows]  # fmt: skip


# ----------------------------------------------------------------------------- adoption runs
def start_run(session: Session, principal: Principal, *, as_of: date | None = None, window_days: int = 30) -> tuple[AdoptionRun, Any]:
    if not 1 <= window_days <= 365:
        raise ValidationFailed("window_days must be between 1 and 365", details={"field": "window_days"})
    if not timeline.approved_catalog(session, principal.tenant_id):
        raise Conflict("there is no approved catalogue yet: adoption cannot be measured against an empty feature list", code="no_catalog")
    if as_of is None:
        cutoff = timeline.data_cutoff(session, principal.tenant_id)
        if cutoff is None:
            raise Conflict("there is no data yet", code="no_data")
        as_of = cutoff.date() + timedelta(days=1)  # the first instant after the last observed day, as for scoring
    run = AdoptionRun(tenant_id=principal.tenant_id, as_of_date=as_of, window_days=window_days, status="pending", created_by=principal.user_id)
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="adoption.compute", payload={"adoption_run_id": run.id}, created_by=principal.user_id)
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="adoption.run_started", entity_type="adoption_run", entity_id=run.id,
                 detail={"as_of": as_of.isoformat(), "window_days": window_days})  # fmt: skip
    return run, job


def compute(tenant_id: int, as_of: date, window_days: int, progress: Any = None) -> tuple[list[dict], dict]:
    """Per-customer, per-feature adoption facts at ``as_of`` plus the summary.  Customers = those active at as_of."""
    t0 = timeline.ts(as_of)
    since, previous = t0 - pd.Timedelta(days=window_days), t0 - pd.Timedelta(days=2 * window_days)
    with read_session() as rs:
        entries = timeline.approved_catalog(rs, tenant_id)
        catalog = timeline.catalog_frame(entries, timeline.telemetry_first_seen(rs, tenant_id, entries))
        ids = list(rs.execute(select(Customer.id).where(Customer.tenant_id == tenant_id).order_by(Customer.id)).scalars())
        seen_names = {(etype, str(name).strip().casefold()): int(n) for etype, name, n in rs.execute(
            select(UsageEvent.event_type, UsageEvent.feature_name, func.count()).where(
                UsageEvent.tenant_id == tenant_id, UsageEvent.feature_name.is_not(None), UsageEvent.occurred_at < t0.to_pydatetime())
            .group_by(UsageEvent.event_type, UsageEvent.feature_name))}  # fmt: skip
    m = len(catalog)
    mapped_names = {(etype, name) for names, etypes in zip(catalog["names"], catalog["event_types"], strict=True) for name in names for etype in etypes}
    never_seen = [bool(pd.isna(first) or first >= t0) for first in catalog["first_seen"]]  # no telemetry before the as-of date
    facts: list[dict] = []
    totals = {key: np.zeros(m) for key in ("eligible", "adopted", "new", "abandoned", "unknown", "users")}
    segments: dict[str, dict[str, np.ndarray]] = {}
    days_to_first: list[list[float]] = [[] for _ in range(m)]
    rates: list[float] = []
    customers_measured = customers_unknown = customers_without_denominator = 0
    for n, start in enumerate(range(0, len(ids), CHUNK)):
        chunk = ids[start : start + CHUNK]
        with read_session() as rs:
            frames = timeline.load_frames(rs, tenant_id, customer_ids=chunk)
        vectors = feature_engine.compute_features(frames, [as_of])
        if vectors.empty:
            continue
        cust_ids = vectors["customer_id"].to_numpy()
        usage = frames["usage"]
        usage = usage[usage["occurred_at"] < t0]
        activity = {**feature_engine.DEFAULT_ACTIVITY, **(frames.get("activity") or {})}
        usage = usage.assign(user=feature_engine.resolve_users(usage, frames.get("identity"), activity["exclude_user_patterns"]))
        mapped = feature_engine.map_to_catalog(usage, catalog)
        grid = feature_engine.AdoptionGrid(mapped, catalog, cust_ids, vectors["plan_tier"].astype(object).to_numpy(), t0)
        mapped = grid.feats  # only the customers that are active at the as-of date
        events, days = grid.counts(since)
        adopted_now, adopted_before, ever = grid.adopted(since), grid.adopted(previous, since), grid.adopted()
        has_telemetry = np.isin(cust_ids, usage["customer_id"].unique())
        first = mapped.groupby(["customer_id", "k"])["occurred_at"].agg(["min", "max"]).reset_index() if len(mapped) else pd.DataFrame(columns=["customer_id", "k", "min", "max"])
        first_at, last_at = np.full((len(cust_ids), m), np.datetime64("NaT"), dtype="datetime64[ns]"), np.full((len(cust_ids), m), np.datetime64("NaT"), dtype="datetime64[ns]")
        if len(first):
            r, c = grid.pos.reindex(first["customer_id"]).to_numpy().astype(int), first["k"].to_numpy().astype(int)
            first_at[r, c], last_at[r, c] = first["min"].to_numpy(dtype="datetime64[ns]"), first["max"].to_numpy(dtype="datetime64[ns]")
        recent = mapped[mapped["occurred_at"] >= since]
        users = np.zeros((len(cust_ids), m))
        if len(recent) and recent["user"].notna().any():
            people = recent[recent["user"].notna()].groupby(["customer_id", "k"])["user"].nunique().reset_index()
            users[grid.pos.reindex(people["customer_id"]).to_numpy().astype(int), people["k"].to_numpy().astype(int)] = people["user"].to_numpy()
        tenure = vectors["tenure_days"].to_numpy(dtype="float64")
        started = t0.to_datetime64() - (tenure * 86400e9).astype("timedelta64[ns]")
        released = catalog["release_date"].to_numpy(dtype="datetime64[ns]")
        is_new = adopted_now & (first_at >= since.to_datetime64())
        abandoned = adopted_before & ~adopted_now & grid.eligible
        rate = grid.rate(adopted_now)
        rates += [float(v) for v in rate[~np.isnan(rate) & has_telemetry]]
        customers_measured += int((~np.isnan(rate) & has_telemetry).sum())
        customers_unknown += int((~has_telemetry).sum())
        customers_without_denominator += int((np.isnan(rate) & has_telemetry).sum())
        tier = vectors["plan_tier"].astype(object).where(vectors["plan_tier"].notna(), "unknown").to_numpy()
        band = np.where(tenure < 90, "first 90 days", np.where(tenure < 365, "90 days to 1 year", "over 1 year"))
        for label, values in (("plan_tier", tier), ("tenure", band)):
            for value in pd.unique(values):
                rows_in = (values == value) & has_telemetry
                bucket = segments.setdefault(f"{label}:{value}", {"eligible": np.zeros(m), "adopted": np.zeros(m), "customers": np.zeros(1)})
                bucket["eligible"] += grid.eligible[rows_in].sum(axis=0)
                bucket["adopted"] += adopted_now[rows_in].sum(axis=0)
                bucket["customers"] += rows_in.sum()
        known = has_telemetry[:, None]
        totals["eligible"] += (grid.eligible & known).sum(axis=0)
        totals["adopted"] += (adopted_now & known).sum(axis=0)
        totals["new"] += (is_new & known).sum(axis=0)
        totals["abandoned"] += (abandoned & known).sum(axis=0)
        totals["unknown"] += (grid.eligible & ~known).sum(axis=0)
        totals["users"] += (users * (adopted_now & known)).sum(axis=0)
        for row, customer_id in enumerate(cust_ids):
            for k in range(m):
                used = not np.isnat(first_at[row, k])
                base = max(started[row], released[k]) if not np.isnat(released[k]) else started[row]
                to_first = float((first_at[row, k] - base) / np.timedelta64(1, "D")) if used else None
                if never_seen[k]:
                    state = "invalid_mapping"
                elif not grid.eligible[row, k]:
                    state = "not_eligible"
                elif not has_telemetry[row]:
                    state = "unknown"
                else:
                    state = "adopted" if adopted_now[row, k] else "not_adopted"
                if to_first is not None and state == "adopted" and ever[row, k]:
                    days_to_first[k].append(max(to_first, 0.0))
                facts.append({"tenant_id": tenant_id, "customer_id": int(customer_id), "feature_key": catalog["feature_key"][k], "state": state,
                              "events": int(events[row, k]), "active_days": int(days[row, k]), "users": int(users[row, k]),
                              "first_used_at": pd.Timestamp(first_at[row, k]).to_pydatetime() if used else None,
                              "last_used_at": pd.Timestamp(last_at[row, k]).to_pydatetime() if used else None,
                              "is_new": bool(is_new[row, k]), "is_abandoned": bool(abandoned[row, k]),
                              "days_to_first_use": None if to_first is None else round(max(to_first, 0.0), 2)})  # fmt: skip
        if progress is not None:
            progress(min(0.9, 0.05 + 0.85 * (n + 1) / max(1, -(-len(ids) // CHUNK))), f"{min(start + CHUNK, len(ids)):,} customers")

    def share(numerator: float, denominator: float) -> float | None:
        return round(float(numerator) / float(denominator), 4) if denominator > 0 else None

    per_feature = []
    for k in range(m):
        per_feature.append({
            "feature_key": catalog["feature_key"][k], "name": catalog["name"][k], "is_core": bool(catalog["is_core"][k]),
            "eligible_customers": int(totals["eligible"][k]), "adopted_customers": int(totals["adopted"][k]),
            "adoption_rate": share(totals["adopted"][k], totals["eligible"][k]),
            "new_adopters": int(totals["new"][k]), "abandoned": int(totals["abandoned"][k]), "unknown_customers": int(totals["unknown"][k]),
            "users_per_adopting_customer": share(totals["users"][k], totals["adopted"][k]),
            "median_days_to_first_use": round(float(np.median(days_to_first[k])), 1) if days_to_first[k] else None,
            "mapping_state": "never_seen_in_telemetry" if never_seen[k] else "ok",
        })  # fmt: skip
    unmapped = sorted(({"event_type": etype, "feature_name": name, "events": count} for (etype, name), count in seen_names.items()
                       if (etype, name) not in mapped_names), key=lambda item: -item["events"])  # fmt: skip
    summary = {
        "as_of_date": as_of.isoformat(), "window_days": window_days, "catalog_hash": catalog_hash(entries), "features": per_feature,
        "catalog_features": m, "customers_measured": customers_measured, "customers_without_telemetry": customers_unknown,
        "customers_without_eligible_features": customers_without_denominator,
        "mean_adoption_rate": round(float(np.mean(rates)), 4) if rates else None,
        "median_adoption_rate": round(float(np.median(rates)), 4) if rates else None,
        "segments": [{"segment": key, "customers": int(v["customers"][0]),
                      "adoption_rate": share(v["adopted"].sum(), v["eligible"].sum()),
                      "by_feature": {catalog["feature_key"][k]: share(v["adopted"][k], v["eligible"][k]) for k in range(m)}}
                     for key, v in sorted(segments.items())],
        "unmapped_telemetry": unmapped[:50], "unmapped_events": int(sum(item["events"] for item in unmapped)),
        "definitions": {
            "adopted": "use in the window reaches the feature's rule (events and distinct days)",
            "denominator": "features released before the as-of date, not retired by it, included in the customer's plan tier at that date, "
                           "and whose telemetry had been seen at least once by then",
            "unknown": "the customer has no usage telemetry at all before the as-of date, so non-use cannot be told from missing data",
            "invalid_mapping": "none of the events the entry maps had been seen in telemetry by the as-of date; the feature is in nobody's denominator",
            "new": "adopted in the window and first used inside it", "abandoned": "adopted in the window before this one and not in this one",
        },
    }  # fmt: skip
    return facts, summary


def run(run_id: int, ctx: Any = None) -> dict:
    with session_scope() as ws:
        entry = ws.get(AdoptionRun, run_id)
        if entry is None:
            raise jobs.PermanentJobError(f"adoption run {run_id} does not exist")
        entry.status = "running"
        tenant_id, as_of, window = entry.tenant_id, entry.as_of_date, entry.window_days
    try:
        facts, summary = compute(tenant_id, as_of, window, progress=ctx.progress if ctx is not None else None)
    except Exception as exc:
        with session_scope() as ws:
            entry = ws.get(AdoptionRun, run_id)
            entry.status, entry.error, entry.finished_at = "failed", f"{type(exc).__name__}: {exc}"[:1000], utcnow()
        raise
    with session_scope() as ws:
        ws.execute(delete(AdoptionFact).where(AdoptionFact.run_id == run_id))
        for start in range(0, len(facts), 5000):
            ws.execute(AdoptionFact.__table__.insert(), [{**fact, "run_id": run_id} for fact in facts[start : start + 5000]])
        entry = ws.get(AdoptionRun, run_id)
        entry.status, entry.result, entry.catalog_hash, entry.finished_at = "completed", summary, summary["catalog_hash"], utcnow()
        # facts of older runs are dropped (their summaries stay): the table would otherwise grow by customers x features per run
        keep = ws.execute(select(AdoptionRun.id).where(AdoptionRun.tenant_id == tenant_id, AdoptionRun.status == "completed")
                          .order_by(AdoptionRun.id.desc()).limit(KEEP_FACTS_OF_RUNS)).scalars().all()  # fmt: skip
        ws.execute(delete(AdoptionFact).where(AdoptionFact.tenant_id == tenant_id, AdoptionFact.run_id.not_in([*keep, run_id])))
        audit.record(ws, tenant_id=tenant_id, action="adoption.run_completed", entity_type="adoption_run", entity_id=run_id,
                     detail={"as_of": as_of.isoformat(), "window_days": window, "facts": len(facts), "mean_adoption_rate": summary["mean_adoption_rate"]})  # fmt: skip
    return {"adoption_run_id": run_id, "facts": len(facts), "mean_adoption_rate": summary["mean_adoption_rate"],
            "customers_measured": summary["customers_measured"]}  # fmt: skip


def run_view(entry: AdoptionRun, *, with_result: bool = True) -> dict:
    return to_dict(entry, exclude=set() if with_result else {"result"})


def latest_run(session: Session, tenant_id: int) -> AdoptionRun | None:
    return session.execute(select(AdoptionRun).where(AdoptionRun.tenant_id == tenant_id, AdoptionRun.status == "completed")
                           .order_by(AdoptionRun.as_of_date.desc(), AdoptionRun.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip


def trend(session: Session, tenant_id: int, limit: int = 24) -> list[dict]:
    """Mean adoption rate of the completed runs, one point per as-of date (the newest run of each date)."""
    rows = session.execute(select(AdoptionRun).where(AdoptionRun.tenant_id == tenant_id, AdoptionRun.status == "completed")
                           .order_by(AdoptionRun.as_of_date.desc(), AdoptionRun.id.desc()).limit(limit * 3)).scalars().all()  # fmt: skip
    points: dict[tuple, dict] = {}
    for entry in rows:
        result = entry.result or {}
        points.setdefault((entry.as_of_date, entry.window_days), {
            "as_of_date": entry.as_of_date.isoformat(), "window_days": entry.window_days, "run_id": entry.id,
            "mean_adoption_rate": result.get("mean_adoption_rate"), "customers_measured": result.get("customers_measured"),
            "by_feature": {f["feature_key"]: f["adoption_rate"] for f in result.get("features", [])}})  # fmt: skip
    return sorted(points.values(), key=lambda p: (p["as_of_date"], p["window_days"]))[-limit:]


def facts_query(tenant_id: int, run_id: int, *, feature_key: str | None = None, state: str | None = None, customer_id: int | None = None,
                q: str | None = None):  # type: ignore[no-untyped-def]
    stmt = (select(AdoptionFact, Customer.external_id, Customer.name).join(Customer, Customer.id == AdoptionFact.customer_id)
            .where(AdoptionFact.tenant_id == tenant_id, AdoptionFact.run_id == run_id))  # fmt: skip
    if feature_key:
        stmt = stmt.where(AdoptionFact.feature_key == feature_key)
    if state:
        stmt = stmt.where(AdoptionFact.state == state)
    if customer_id:
        stmt = stmt.where(AdoptionFact.customer_id == customer_id)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Customer.external_id.ilike(like) | Customer.name.ilike(like))
    return stmt.order_by(AdoptionFact.customer_id, AdoptionFact.feature_key)


def fact_view(row: Any) -> dict:
    fact, external_id, name = row
    return to_dict(fact, include={"customer_external_id": external_id, "customer_name": name})
