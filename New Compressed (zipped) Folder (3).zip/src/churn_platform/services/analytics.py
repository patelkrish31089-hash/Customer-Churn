"""Exploratory analytics: portfolio overview, cohort retention heatmap, Kaplan-Meier survival and
churn-rate profiles.  Everything here is descriptive: associations, never causal claims."""

from __future__ import annotations

from datetime import date
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope
from ..errors import ValidationFailed
from ..models import AnalysisReport, ChurnLabel, Customer, DQRun, FeatureContract
from ..security import Principal
from . import audit, feature_engine, features, jobs, policies, timeline
from .common import json_safe, to_dict

KINDS = ("overview", "cohort", "survival", "profile")
SEGMENTS = ("company_size", "region", "industry", "acquisition_channel", "plan_tier", "billing_period")
DESCRIPTIVE = "Descriptive statistics of observed history. Differences between groups are associations, not causal effects."


def _customer_blocks(frames: dict[str, pd.DataFrame], defn: policies.ChurnDefinition, cutoff: pd.Timestamp) -> pd.DataFrame:
    """One row per customer and uninterrupted paid period: start, end (NaT = still subscribed), end_reason."""
    intervals = timeline.build_intervals(frames, defn.grace_period_days, cutoff)
    paid = timeline.paid_intervals(intervals, defn.include_trials)
    return timeline.merge_blocks(paid, "customer_id", defn.reactivation_window_days)


def _segment_values(frames: dict[str, pd.DataFrame], segment: str) -> pd.Series:
    customers = frames["customers"].set_index("id")
    if segment in customers.columns:
        return customers[segment]
    subs = frames["subscriptions"].sort_values("started_at").drop_duplicates("customer_id").set_index("customer_id")
    if segment == "billing_period":
        return subs["billing_period"]
    return subs["plan_id"].map(frames["plans"].set_index("id")["tier"])  # plan_tier of the first subscription


def overview(frames: dict[str, pd.DataFrame], defn: policies.ChurnDefinition, cutoff: pd.Timestamp) -> dict:
    blocks = _customer_blocks(frames, defn, cutoff)
    now_active = timeline.active_at(blocks, cutoff)
    subs = frames["subscriptions"]
    intervals = timeline.build_intervals(frames, defn.grace_period_days, cutoff)
    active_subs = timeline.active_at(timeline.paid_intervals(intervals, defn.include_trials), cutoff, "paid_start")["subscription_id"]
    mrr = float(subs[subs["id"].isin(active_subs)]["mrr"].fillna(0).sum())
    ended = blocks[blocks["end"].notna()]
    by_reason = ended["end_reason"].fillna("unknown").value_counts()
    # Endings for a reason the churn definition excludes (for example an expired trial) are not churn:
    # they are reported in their own column and never enter the churn rate.
    is_excluded = ended["end_reason"].isin(defn.excluded_reasons)
    churn, set_aside = ended[~is_excluded], ended[is_excluded]
    months = pd.period_range(blocks["start"].min().to_period("M"), cutoff.to_period("M"), freq="M") if len(blocks) else []
    series = []
    for month in months:
        start, end = month.start_time, (month + 1).start_time
        at_start = int(len(timeline.active_at(blocks, start)))
        lost = churn[(churn["end"] >= start) & (churn["end"] < end)]
        new = int(((blocks["start"] >= start) & (blocks["start"] < end)).sum())
        kinds = lost["end_reason"].map(lambda r: _reason_kind(defn, r)).value_counts()
        series.append({"month": str(month), "active_at_start": at_start, "new": new, "churned": int(len(lost)),
                       "voluntary": int(kinds.get("voluntary", 0)), "involuntary": int(kinds.get("involuntary", 0)),
                       "excluded": int(((set_aside["end"] >= start) & (set_aside["end"] < end)).sum()),
                       "churn_rate": round(len(lost) / at_start, 6) if at_start else None,
                       "complete": bool(end <= cutoff + pd.Timedelta(seconds=1))})  # fmt: skip
    return {
        "data_cutoff": cutoff.isoformat(), "customers": int(len(frames["customers"])), "active_customers": int(now_active["customer_id"].nunique()),
        "active_mrr": round(mrr, 2), "ever_subscribed": int(blocks["customer_id"].nunique()), "ended_periods": int(len(ended)),
        "churned_periods": int(len(churn)), "excluded_periods": int(len(set_aside)),
        "ended_by_reason": {str(k): int(v) for k, v in by_reason.items()},
        "ended_by_kind": {k: int(v) for k, v in ended["end_reason"].map(lambda r: _reason_kind(defn, r)).value_counts().items()},
        "monthly": series, "note": DESCRIPTIVE,
        "definitions": {"churn_rate": "paid periods ending in the month for a reason that counts as churn / customers subscribed "
                                      "at the start of the month",
                        "excluded": "paid periods that ended for a reason the churn definition excludes; never counted as churn",
                        "complete": "false for the month containing the data cutoff (partial month)"},
    }  # fmt: skip


def _reason_kind(defn: policies.ChurnDefinition, reason: Any) -> str:
    if reason in defn.voluntary_reasons:
        return "voluntary"
    if reason in defn.involuntary_reasons:
        return "involuntary"
    return "excluded" if reason in defn.excluded_reasons else "unknown"


def cohort_retention(frames: dict[str, pd.DataFrame], defn: policies.ChurnDefinition, cutoff: pd.Timestamp, max_periods: int = 24) -> dict:
    """Signup-month cohorts x months since first paid day (30-day steps).  A cell is the share of the
    cohort still subscribed, computed only over customers whose anniversary is already observable."""
    blocks = _customer_blocks(frames, defn, cutoff)
    if blocks.empty:
        return {"cohorts": [], "periods": [], "note": DESCRIPTIVE}
    first = blocks.groupby("customer_id")["start"].min()
    cohort = first.dt.to_period("M")
    periods = list(range(0, min(max_periods, int((cutoff - first.min()).days // 30)) + 1))
    far = np.datetime64(pd.Timestamp.max.floor("D"))
    by_customer = {}
    for cid, grp in blocks.sort_values("start").groupby("customer_id"):
        ends = grp["end"].to_numpy()
        by_customer[cid] = (grp["start"].to_numpy(), np.where(np.isnat(ends), far, ends), grp["end_reason"].isin(defn.excluded_reasons).to_numpy())
    rows = []
    for month, members in first.groupby(cohort):
        cells = []
        for k in periods:
            observable = retained = 0
            for cid, start in members.items():
                moment = start + pd.Timedelta(days=30 * k)
                if moment > cutoff:
                    continue
                at = np.datetime64(moment)
                starts, ends, left_excluded = by_customer[cid]
                subscribed = bool(((starts <= at) & (ends > at)).any())
                if not subscribed:
                    over = np.flatnonzero(ends <= at)
                    if len(over) and left_excluded[over[-1]]:
                        continue  # left for an excluded reason: out of the population, not a lost customer
                observable += 1
                retained += subscribed
            cells.append({"period": k, "observable": observable, "retained": retained,
                          "rate": round(retained / observable, 6) if observable else None})  # fmt: skip
        rows.append({"cohort": str(month), "size": int(len(members)), "cells": cells})
    return {"cohorts": rows, "periods": periods, "period_days": 30, "data_cutoff": cutoff.isoformat(), "note": DESCRIPTIVE,
            "definitions": {"rate": "customers still subscribed 30 x k days after their first paid day / customers "
                                    "for whom that day is on or before the data cutoff (customers who left for a "
                                    "reason the churn definition excludes are removed from both)"}}  # fmt: skip


def survival(frames: dict[str, pd.DataFrame], defn: policies.ChurnDefinition, cutoff: pd.Timestamp, segment: str | None = None) -> dict:
    """Kaplan-Meier survival of the first paid period; still-subscribed customers are right-censored."""
    from lifelines import KaplanMeierFitter
    from lifelines.statistics import multivariate_logrank_test

    if segment is not None and segment not in SEGMENTS:
        raise ValidationFailed(f"segment must be one of {', '.join(SEGMENTS)}", details={"field": "segment"})
    blocks = _customer_blocks(frames, defn, cutoff)
    first = blocks.sort_values("start").drop_duplicates("customer_id").set_index("customer_id")
    excluded = first["end"].notna() & first["end_reason"].isin(defn.excluded_reasons)
    first = first[~excluded]
    if first.empty:
        return {"groups": [], "note": DESCRIPTIVE}
    event = first["end"].notna() & (first["end"] <= cutoff)
    duration = ((first["end"].where(event, cutoff) - first["start"]).dt.total_seconds() / 86400.0).clip(lower=0.0)
    group = _segment_values(frames, segment).reindex(first.index).fillna("(missing)").astype(str) if segment else pd.Series("all customers", index=first.index)
    out = []
    for name, idx in sorted(group.groupby(group).groups.items(), key=lambda kv: -len(kv[1])):
        d, e = duration.loc[idx], event.loc[idx]
        if len(d) < 5:
            out.append({"group": name, "n": int(len(d)), "events": int(e.sum()), "insufficient_data": True, "curve": []})
            continue
        kmf = KaplanMeierFitter().fit(d, event_observed=e, label=name)
        curve = kmf.survival_function_.iloc[:, 0]
        ci = kmf.confidence_interval_survival_function_
        step = max(1, len(curve) // 120)
        points = [{"day": float(t), "survival": float(sv), "lower": float(lo), "upper": float(hi)}
                  for t, sv, lo, hi in zip(curve.index[::step], curve.to_numpy()[::step], ci.iloc[::step, 0], ci.iloc[::step, 1], strict=True)]  # fmt: skip
        median = kmf.median_survival_time_
        marks = {str(day): float(kmf.predict(day)) for day in (30, 90, 180, 365) if day <= float(d.max())}
        out.append({"group": name, "n": int(len(d)), "events": int(e.sum()), "censored": int((~e).sum()),
                    "median_survival_days": None if not np.isfinite(median) else float(median), "survival_at": marks, "curve": points})  # fmt: skip
    test = None
    usable = group.isin([g["group"] for g in out if not g.get("insufficient_data")])
    if segment and group[usable].nunique() > 1:
        res = multivariate_logrank_test(duration[usable], group[usable], event[usable])
        test = {"test": "log-rank", "statistic": float(res.test_statistic), "p_value": float(res.p_value),
                "degrees_of_freedom": int(group[usable].nunique() - 1)}  # fmt: skip
    return {"segment": segment, "groups": out, "logrank": test, "data_cutoff": cutoff.isoformat(),
            "n": int(len(first)), "events": int(event.sum()), "note": DESCRIPTIVE,
            "definitions": {"event": "the first paid period ended (excluded reasons removed)",
                            "censored": "still subscribed at the data cutoff; contributes time at risk but no event",
                            "median_survival_days": "null when fewer than half of the group has churned within the observed time"}}  # fmt: skip


def churn_profile(data: pd.DataFrame, feature_names: list[str], bins: int = 5) -> dict:
    """Observed churn rate by feature bin over mature labels (EDA: where churn concentrates)."""
    base = float(data["label"].mean()) if len(data) else None
    rows = []
    for name in feature_names:
        spec = feature_engine.SPECS[name]
        col = data[name]
        if spec.dtype == "category" or spec.dtype == "bool":
            keys = col.astype(object).where(col.notna(), "(missing)").astype(str)
            order = None
        else:
            values = pd.to_numeric(col, errors="coerce")
            if values.nunique(dropna=True) < 2:
                continue
            try:
                cut = pd.qcut(values, q=bins, duplicates="drop")
            except ValueError:
                continue
            keys = cut.astype(object).where(values.notna(), "(missing)").astype(str)
            order = [str(c) for c in cut.cat.categories] + ["(missing)"]
        grouped = data.groupby(keys)["label"].agg(["size", "sum"])
        if order:
            grouped = grouped.reindex([k for k in order if k in grouped.index])
        cells = [{"bin": str(k), "n": int(r["size"]), "churned": int(r["sum"]), "churn_rate": float(r["sum"] / r["size"])}
                 for k, r in grouped.iterrows() if r["size"] > 0]  # fmt: skip
        if len(cells) < 2:
            continue
        rates = [c["churn_rate"] for c in cells if c["n"] >= 20] or [c["churn_rate"] for c in cells]
        rows.append({"feature": name, "label": spec.label, "group": spec.group, "bins": cells, "spread": float(max(rates) - min(rates))})
    rows.sort(key=lambda r: -r["spread"])
    return {"base_rate": base, "rows": int(len(data)), "features": rows, "note": DESCRIPTIVE,
            "definitions": {"spread": "highest minus lowest churn rate across bins with at least 20 observations"}}  # fmt: skip


# ----------------------------------------------------------------------------- jobs / persistence
def start(session: Session, principal: Principal, kind: str, params: dict | None = None) -> tuple[AnalysisReport, Any]:
    if kind not in KINDS:
        raise ValidationFailed(f"kind must be one of {', '.join(KINDS)}", details={"field": "kind"})
    params = dict(params or {})
    if kind == "survival" and params.get("segment") not in (None, *SEGMENTS):
        raise ValidationFailed(f"segment must be one of {', '.join(SEGMENTS)}", details={"field": "segment"})
    titles = {"overview": "Portfolio overview", "cohort": "Cohort retention", "profile": "Churn-rate profile",
              "survival": "Survival analysis" + (f" by {params['segment'].replace('_', ' ')}" if params.get("segment") else "")}  # fmt: skip
    report = AnalysisReport(tenant_id=principal.tenant_id, kind=kind, title=titles[kind], params=params, created_by=principal.user_id)
    session.add(report)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="analytics.run", payload={"report_id": report.id},
                       created_by=principal.user_id)  # fmt: skip
    report.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="analytics.started", entity_type="analysis_report",
                 entity_id=report.id, detail={"kind": kind, "params": params})  # fmt: skip
    return report, job


def compute(tenant_id: int, kind: str, params: dict) -> dict:
    with read_session() as rs:
        cutoff = timeline.data_cutoff(rs, tenant_id)
        if cutoff is None:
            raise jobs.PermanentJobError("no data has been ingested yet")
        policy = policies.get_active(rs, tenant_id, "churn_definition", required=False)
        defn = policies.parse(policy) if policy else policies.ChurnDefinition()
        basis = {"churn_definition": f"{policy.name} v{policy.version}" if policy else "structural default (no approved definition)"}
        if kind == "profile":
            contract = rs.execute(select(FeatureContract).where(FeatureContract.tenant_id == tenant_id, FeatureContract.status == "approved")
                                  .order_by(FeatureContract.id.desc())).scalars().first()  # fmt: skip
            if contract is None or policy is None:
                raise jobs.PermanentJobError("a churn-rate profile needs an approved churn definition, labels and materialised features")
            rows = rs.execute(select(ChurnLabel.customer_id, ChurnLabel.as_of_date, ChurnLabel.label).where(
                ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.status.in_(("churned", "retained")))).all()  # fmt: skip
            labels = pd.DataFrame(rows, columns=["customer_id", "as_of_date", "label"])
            feats = features.offline_frame(rs, tenant_id, contract, dates=sorted(labels["as_of_date"].unique())) if len(labels) else pd.DataFrame()
            if labels.empty or feats.empty:
                raise jobs.PermanentJobError("no mature labels with materialised features exist yet")
            data = labels.merge(feats, on=["customer_id", "as_of_date"])
            return {**churn_profile(data, list(contract.features)), **basis}
        frames = timeline.load_frames(rs, tenant_id, tables=("customers", "subscriptions", "sub_events", "payments", "plans"))
    stamp = timeline.ts(cutoff)
    if kind == "overview":
        return {**overview(frames, defn, stamp), **basis}
    if kind == "cohort":
        return {**cohort_retention(frames, defn, stamp), **basis}
    return {**survival(frames, defn, stamp, params.get("segment")), **basis}


def run(report_id: int, ctx: Any = None) -> dict:
    with read_session() as rs:
        report = rs.get(AnalysisReport, report_id)
        if report is None:
            raise jobs.PermanentJobError(f"analysis report {report_id} does not exist")
        tenant_id, kind, params = report.tenant_id, report.kind, dict(report.params or {})
    result = json_safe(compute(tenant_id, kind, params))
    with session_scope() as ws:
        ws.get(AnalysisReport, report_id).result = result
    return {"report_id": report_id, "kind": kind}


def latest(session: Session, tenant_id: int, kind: str, segment: str | None = None) -> dict | None:
    stmt = select(AnalysisReport).where(AnalysisReport.tenant_id == tenant_id, AnalysisReport.kind == kind,
                                        AnalysisReport.result.is_not(None)).order_by(AnalysisReport.id.desc()).limit(25)  # fmt: skip
    for report in session.execute(stmt).scalars():
        if kind != "survival" or (report.params or {}).get("segment") == segment:
            return to_dict(report)
    return None


def headline(session: Session, tenant_id: int) -> dict:
    """Cheap counters for the dashboard header (no heavy computation)."""
    customers = session.execute(select(func.count()).select_from(Customer).where(Customer.tenant_id == tenant_id)).scalar_one()
    dq = session.execute(select(DQRun).where(DQRun.tenant_id == tenant_id, DQRun.status == "completed").order_by(DQRun.id.desc()).limit(1)).scalar_one_or_none()
    cutoff = timeline.data_cutoff(session, tenant_id)
    return {"customers": customers, "data_cutoff": cutoff.isoformat() if cutoff else None,
            "dq_score": dq.score if dq else None, "dq_run_id": dq.id if dq else None, "today": date.today().isoformat()}  # fmt: skip
