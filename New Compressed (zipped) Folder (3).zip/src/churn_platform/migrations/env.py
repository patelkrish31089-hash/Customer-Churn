"""Alembic environment.  Run through ``churn-platform migrate`` (see ``churn_platform.dbadmin``)."""

from __future__ import annotations

from typing import Any

from alembic import context
from sqlalchemy import text

from churn_platform import models  # noqa: F401 - registers every table on Base.metadata
from churn_platform.config import get_settings
from churn_platform.db import Base, Money, UTCDateTime, make_engine

target_metadata = Base.metadata


def render_item(type_: str, obj: Any, autogen_context: Any) -> Any:
    """Render the portable column types as plain SQLAlchemy types so that migration files are
    self-contained and never change meaning when application code changes."""
    if type_ == "type":
        if isinstance(obj, UTCDateTime):
            return "sa.DateTime(timezone=True)"
        if isinstance(obj, Money):
            return "sa.Numeric(precision=18, scale=4)"
    return False


def run_migrations_online() -> None:
    url = context.config.get_main_option("sqlalchemy.url") or get_settings().database_url
    engine = make_engine(url, for_migrations=True)
    sqlite = engine.dialect.name == "sqlite"
    try:
        with engine.connect() as connection:
            context.configure(connection=connection, target_metadata=target_metadata, render_as_batch=sqlite,
                              compare_type=True, render_item=render_item)  # fmt: skip
            with context.begin_transaction():
                context.run_migrations()
            if sqlite:  # FK enforcement is off while batch migrations rebuild tables: verify integrity afterwards
                violations = connection.execute(text("PRAGMA foreign_key_check")).fetchall()
                if violations:
                    raise RuntimeError(f"foreign-key violations after migration: {violations[:5]}")
            connection.commit()
    finally:
        engine.dispose()


if context.is_offline_mode():
    raise RuntimeError("offline (SQL script) mode is not supported; run migrations against a database")
run_migrations_online()
