"""1.3.0: the export outbox, so a delivery run can be resumed instead of guessed at.

Three tables and no changes to any existing one — the migration is additive, and its ``downgrade`` drops exactly what
it created.

``export_runs``
    one row per (tenant, destination, run): what was selected, what the destination acknowledged, what failed, what was
    quarantined, the checksum of the acknowledged set, and the watermark at the end.  ``(tenant_id, destination,
    run_id)`` is unique, so a retried job updates its own row rather than adding a second history of the same run.

``export_outbox``
    one row per record per run: the identity, the idempotency key, the payload digest, the per-record state
    (``PENDING`` / ``ACKNOWLEDGED`` / ``FAILED`` / ``QUARANTINED``), the attempts, and the error.  ``(destination,
    idempotency_key)`` is unique: a retry of the same statement cannot create a second row, and a corrected statement
    about the same customer-day is a different key and must.

``export_checkpoints``
    one row per (tenant, destination): the contiguous acknowledged watermark, the run that moved it, and the keys that
    run acknowledged.  The watermark only moves forward.

Why a table and not the run's counters: 1.2.0 recorded ``rows`` and a checksum taken from the *selection*.  Nothing in
the database said which records the destination had accepted, so after a crash a resuming process could only re-send the
whole window or skip it.  With the outbox, "what still has to be sent" is a query, and the watermark is derived from
acknowledgements rather than from a count.

Revision ID: 0005
Revises: 0004
Create Date: 2026-11-13
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

JSON = sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), "postgresql")

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "export_runs",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("destination", sa.String(40), nullable=False),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending", index=True),
        sa.Column("records_selected", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("records_acknowledged", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("records_failed", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("records_quarantined", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("checksum", sa.String(64), nullable=True),
        sa.Column("watermark", sa.DateTime(timezone=True), nullable=True),
        sa.Column("verification", JSON, nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("tenant_id", "destination", "run_id", name="uq_export_runs_identity"),
        sa.CheckConstraint("status IN ('pending','running','completed','partial','failed')", name="status_valid"),
    )
    op.create_table(
        "export_outbox",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("export_run_id", sa.Integer(), sa.ForeignKey("export_runs.id"), nullable=False, index=True),
        sa.Column("destination", sa.String(40), nullable=False),
        sa.Column("identity_key", sa.String(400), nullable=False),
        sa.Column("idempotency_key", sa.String(600), nullable=False),
        sa.Column("payload_checksum", sa.String(64), nullable=False),
        sa.Column("prediction_timestamp", sa.DateTime(timezone=True), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="PENDING", index=True),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("external_reference", sa.String(200), nullable=True),
        sa.Column("submitted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("acknowledged_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("error_code", sa.String(80), nullable=True),
        sa.Column("error_description", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("destination", "idempotency_key", name="uq_export_outbox_idempotency"),
        sa.CheckConstraint("status IN ('PENDING','ACKNOWLEDGED','FAILED','QUARANTINED')", name="status_valid"),
    )
    op.create_index("ix_export_outbox_tenant_status", "export_outbox", ["tenant_id", "status"])
    op.create_table(
        "export_checkpoints",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("destination", sa.String(40), nullable=False),
        sa.Column("watermark", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_run_id", sa.String(64), nullable=True),
        sa.Column("acknowledged_keys", JSON, nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("tenant_id", "destination", name="uq_export_checkpoints_identity"),
    )


def downgrade() -> None:
    op.drop_index("ix_export_outbox_tenant_status", table_name="export_outbox")
    op.drop_table("export_checkpoints")
    op.drop_table("export_outbox")
    op.drop_table("export_runs")
