"""Baseline schema of the clean-room rebuild (1.0.0): all 56 tables.

Generated once from the ORM metadata and then frozen; later schema changes get their own revision.

Revision ID: 0001
Revises: (none)
Create Date: 2026-11-10 09:16:54.462759
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = '0001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('feature_definitions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('name', sa.String(length=80), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('group', sa.String(length=40), nullable=False),
    sa.Column('dtype', sa.String(length=20), nullable=False),
    sa.Column('description', sa.Text(), nullable=False),
    sa.Column('sources', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('window_days', sa.Integer(), nullable=True),
    sa.Column('pit_rule', sa.String(length=200), nullable=False),
    sa.Column('code_hash', sa.String(length=64), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_feature_definitions')),
    sa.UniqueConstraint('name', 'version', name='uq_feature_definitions_name_version')
    )
    op.create_table('tenants',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('slug', sa.String(length=64), nullable=False),
    sa.Column('name', sa.String(length=200), nullable=False),
    sa.Column('is_system', sa.Boolean(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_tenants')),
    sa.UniqueConstraint('slug', name=op.f('uq_tenants_slug'))
    )
    op.create_table('users',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('email', sa.String(length=320), nullable=False),
    sa.Column('full_name', sa.String(length=200), nullable=False),
    sa.Column('password_hash', sa.String(length=400), nullable=True),
    sa.Column('role', sa.String(length=40), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('mfa_enabled', sa.Boolean(), nullable=False),
    sa.Column('mfa_secret_enc', sa.Text(), nullable=True),
    sa.Column('mfa_last_counter', sa.Integer(), nullable=True),
    sa.Column('failed_logins', sa.Integer(), nullable=False),
    sa.Column('locked_until', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_login_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('password_changed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_users_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_users')),
    sa.UniqueConstraint('email', name=op.f('uq_users_email'))
    )
    with op.batch_alter_table('users', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_users_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('alerts',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=40), nullable=False),
    sa.Column('severity', sa.String(length=20), nullable=False),
    sa.Column('title', sa.String(length=200), nullable=False),
    sa.Column('message', sa.Text(), nullable=True),
    sa.Column('source_type', sa.String(length=40), nullable=True),
    sa.Column('source_id', sa.Integer(), nullable=True),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('acknowledged_by', sa.Integer(), nullable=True),
    sa.Column('acknowledged_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("severity IN ('info','warning','critical')", name=op.f('ck_alerts_severity_valid')),
    sa.CheckConstraint("status IN ('open','acknowledged','resolved')", name=op.f('ck_alerts_status_valid')),
    sa.ForeignKeyConstraint(['acknowledged_by'], ['users.id'], name=op.f('fk_alerts_acknowledged_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_alerts_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_alerts'))
    )
    with op.batch_alter_table('alerts', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_alerts_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_alerts_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('audit_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('seq', sa.Integer(), nullable=False),
    sa.Column('actor_user_id', sa.Integer(), nullable=True),
    sa.Column('actor_label', sa.String(length=320), nullable=False),
    sa.Column('action', sa.String(length=100), nullable=False),
    sa.Column('entity_type', sa.String(length=60), nullable=True),
    sa.Column('entity_id', sa.String(length=100), nullable=True),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('correlation_id', sa.String(length=64), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('prev_hash', sa.String(length=64), nullable=False),
    sa.Column('hash', sa.String(length=64), nullable=False),
    sa.ForeignKeyConstraint(['actor_user_id'], ['users.id'], name=op.f('fk_audit_events_actor_user_id_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_audit_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_audit_events')),
    sa.UniqueConstraint('tenant_id', 'seq', name='uq_audit_events_tenant_seq')
    )
    with op.batch_alter_table('audit_events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_audit_events_action'), ['action'], unique=False)
        batch_op.create_index(batch_op.f('ix_audit_events_actor_user_id'), ['actor_user_id'], unique=False)
        batch_op.create_index('ix_audit_events_entity', ['tenant_id', 'entity_type', 'entity_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_audit_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('auth_sessions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('user_id', sa.Integer(), nullable=False),
    sa.Column('token_hash', sa.String(length=64), nullable=False),
    sa.Column('auth_method', sa.String(length=20), nullable=False),
    sa.Column('mfa_verified', sa.Boolean(), nullable=False),
    sa.Column('ip', sa.String(length=64), nullable=True),
    sa.Column('user_agent', sa.String(length=300), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('last_seen_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('revoked_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('revoked_reason', sa.String(length=100), nullable=True),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_auth_sessions_tenant_id_tenants')),
    sa.ForeignKeyConstraint(['user_id'], ['users.id'], name=op.f('fk_auth_sessions_user_id_users')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_auth_sessions')),
    sa.UniqueConstraint('token_hash', name=op.f('uq_auth_sessions_token_hash'))
    )
    with op.batch_alter_table('auth_sessions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_auth_sessions_tenant_id'), ['tenant_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_auth_sessions_user_id'), ['user_id'], unique=False)

    op.create_table('campaigns',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=160), nullable=False),
    sa.Column('segment', sa.String(length=40), nullable=False),
    sa.Column('action_code', sa.String(length=60), nullable=False),
    sa.Column('channel', sa.String(length=30), nullable=False),
    sa.Column('offer', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('requires_consent', sa.Boolean(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('experiment_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','running','completed')", name=op.f('ck_campaigns_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_campaigns_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_campaigns_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_campaigns_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_campaigns')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_campaigns_tenant_name')
    )
    with op.batch_alter_table('campaigns', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_campaigns_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('crm_connections',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('provider', sa.String(length=20), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('mode', sa.String(length=12), nullable=False),
    sa.Column('base_url', sa.String(length=400), nullable=False),
    sa.Column('credentials_enc', sa.Text(), nullable=True),
    sa.Column('field_mapping', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('last_checked_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("mode IN ('TEST_ONLY','SANDBOX','PRODUCTION')", name=op.f('ck_crm_connections_mode_valid')),
    sa.CheckConstraint("provider IN ('salesforce','hubspot','intercom')", name=op.f('ck_crm_connections_provider_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_crm_connections_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_crm_connections_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_crm_connections')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_crm_connections_tenant_name')
    )
    with op.batch_alter_table('crm_connections', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_crm_connections_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('data_sources',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('description', sa.Text(), nullable=True),
    sa.Column('config', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('discovered_schema', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('incremental_cursor', sa.String(length=200), nullable=True),
    sa.Column('webhook_secret_enc', sa.Text(), nullable=True),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("kind IN ('file','rest_api','webhook')", name=op.f('ck_data_sources_kind_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_data_sources_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_data_sources_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_data_sources')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_data_sources_tenant_name')
    )
    with op.batch_alter_table('data_sources', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_data_sources_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('dq_rules',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('rule_type', sa.String(length=40), nullable=False),
    sa.Column('dimension', sa.String(length=30), nullable=False),
    sa.Column('severity', sa.String(length=20), nullable=False),
    sa.Column('params', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('description', sa.Text(), nullable=True),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("severity IN ('info','warning','error')", name=op.f('ck_dq_rules_severity_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_dq_rules_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_dq_rules_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_dq_rules')),
    sa.UniqueConstraint('tenant_id', 'name', 'version', name='uq_dq_rules_identity')
    )
    with op.batch_alter_table('dq_rules', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_dq_rules_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('feature_contracts',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('features', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('schema_hash', sa.String(length=64), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name=op.f('ck_feature_contracts_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_feature_contracts_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_feature_contracts_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_feature_contracts_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_feature_contracts')),
    sa.UniqueConstraint('tenant_id', 'name', 'version', name='uq_feature_contracts_identity')
    )
    with op.batch_alter_table('feature_contracts', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_feature_contracts_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('jobs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('job_type', sa.String(length=80), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('priority', sa.Integer(), nullable=False),
    sa.Column('attempts', sa.Integer(), nullable=False),
    sa.Column('max_attempts', sa.Integer(), nullable=False),
    sa.Column('run_after', sa.DateTime(timezone=True), nullable=False),
    sa.Column('lease_owner', sa.String(length=120), nullable=True),
    sa.Column('lease_expires_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('heartbeat_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('progress', sa.Float(), nullable=False),
    sa.Column('progress_message', sa.String(length=300), nullable=True),
    sa.Column('result', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('idempotency_key', sa.String(length=200), nullable=True),
    sa.Column('cancel_requested', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('queued','running','succeeded','failed','cancelled')", name=op.f('ck_jobs_status_valid')),
    sa.CheckConstraint('attempts >= 0 AND max_attempts >= 1', name=op.f('ck_jobs_attempts_valid')),
    sa.CheckConstraint('progress >= 0 AND progress <= 1', name=op.f('ck_jobs_progress_range')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_jobs_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_jobs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_jobs')),
    sa.UniqueConstraint('tenant_id', 'idempotency_key', name='uq_jobs_tenant_idempotency_key')
    )
    with op.batch_alter_table('jobs', schema=None) as batch_op:
        batch_op.create_index('ix_jobs_claim', ['status', 'run_after', 'priority'], unique=False)
        batch_op.create_index(batch_op.f('ix_jobs_job_type'), ['job_type'], unique=False)
        batch_op.create_index(batch_op.f('ix_jobs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('policies',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=40), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('note', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('submitted_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name=op.f('ck_policies_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_policies_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_policies_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_policies_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_policies')),
    sa.UniqueConstraint('tenant_id', 'kind', 'name', 'version', name='uq_policies_identity')
    )
    with op.batch_alter_table('policies', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_policies_kind'), ['kind'], unique=False)
        batch_op.create_index(batch_op.f('ix_policies_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('schedules',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('job_type', sa.String(length=80), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('interval_seconds', sa.Integer(), nullable=False),
    sa.Column('next_run_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('last_run_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_job_id', sa.Integer(), nullable=True),
    sa.Column('enabled', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('interval_seconds >= 60', name=op.f('ck_schedules_interval_min')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_schedules_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_schedules_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_schedules')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_schedules_tenant_name')
    )
    with op.batch_alter_table('schedules', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_schedules_next_run_at'), ['next_run_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_schedules_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('analysis_reports',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=30), nullable=False),
    sa.Column('title', sa.String(length=200), nullable=False),
    sa.Column('params', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('result', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_analysis_reports_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_analysis_reports_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_analysis_reports_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_analysis_reports'))
    )
    with op.batch_alter_table('analysis_reports', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_analysis_reports_kind'), ['kind'], unique=False)
        batch_op.create_index(batch_op.f('ix_analysis_reports_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('dataset_versions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('source_id', sa.Integer(), nullable=False),
    sa.Column('version_no', sa.Integer(), nullable=False),
    sa.Column('checksum_sha256', sa.String(length=64), nullable=False),
    sa.Column('file_name', sa.String(length=300), nullable=False),
    sa.Column('file_format', sa.String(length=20), nullable=False),
    sa.Column('size_bytes', sa.Integer(), nullable=False),
    sa.Column('row_count', sa.Integer(), nullable=True),
    sa.Column('schema', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('storage_path', sa.String(length=500), nullable=False),
    sa.Column('origin', sa.String(length=20), nullable=False),
    sa.Column('is_synthetic', sa.Boolean(), nullable=False),
    sa.Column('parent_version_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_dataset_versions_created_by_users')),
    sa.ForeignKeyConstraint(['parent_version_id'], ['dataset_versions.id'], name=op.f('fk_dataset_versions_parent_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['source_id'], ['data_sources.id'], name=op.f('fk_dataset_versions_source_id_data_sources')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_dataset_versions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_dataset_versions')),
    sa.UniqueConstraint('source_id', 'version_no', name='uq_dataset_versions_source_version'),
    sa.UniqueConstraint('tenant_id', 'source_id', 'checksum_sha256', name='uq_dataset_versions_checksum')
    )
    with op.batch_alter_table('dataset_versions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_dataset_versions_source_id'), ['source_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_dataset_versions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('dq_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('scope', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('score', sa.Float(), nullable=True),
    sa.Column('scorecard', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('rules_evaluated', sa.Integer(), nullable=False),
    sa.Column('findings_count', sa.Integer(), nullable=False),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_dq_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_dq_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_dq_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_dq_runs'))
    )
    with op.batch_alter_table('dq_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_dq_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('experiments',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=160), nullable=False),
    sa.Column('hypothesis', sa.Text(), nullable=True),
    sa.Column('origin', sa.String(length=20), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('campaign_id', sa.Integer(), nullable=True),
    sa.Column('treatment_share', sa.Float(), nullable=False),
    sa.Column('alpha', sa.Float(), nullable=False),
    sa.Column('power', sa.Float(), nullable=False),
    sa.Column('baseline_rate', sa.Float(), nullable=True),
    sa.Column('min_detectable_effect', sa.Float(), nullable=True),
    sa.Column('required_per_arm', sa.Integer(), nullable=True),
    sa.Column('outcome_window_days', sa.Integer(), nullable=False),
    sa.Column('assignment_salt', sa.String(length=64), nullable=False),
    sa.Column('assigned_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('results', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','running','completed')", name=op.f('ck_experiments_status_valid')),
    sa.CheckConstraint('treatment_share > 0 AND treatment_share < 1', name=op.f('ck_experiments_treatment_share_range')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_experiments_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_experiments_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_experiments_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_experiments_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_experiments')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_experiments_tenant_name')
    )
    with op.batch_alter_table('experiments', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_experiments_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('feature_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('as_of_dates', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('data_cutoff', sa.DateTime(timezone=True), nullable=True),
    sa.Column('row_count', sa.Integer(), nullable=False),
    sa.Column('stats', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_feature_runs_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_feature_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_feature_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_feature_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_feature_runs'))
    )
    with op.batch_alter_table('feature_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_feature_runs_contract_id'), ['contract_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_feature_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('label_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('policy_id', sa.Integer(), nullable=False),
    sa.Column('as_of_dates', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('data_cutoff', sa.DateTime(timezone=True), nullable=False),
    sa.Column('counts', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_label_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_label_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['policy_id'], ['policies.id'], name=op.f('fk_label_runs_policy_id_policies')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_label_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_label_runs'))
    )
    with op.batch_alter_table('label_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_label_runs_policy_id'), ['policy_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_label_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('ml_datasets',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('policy_id', sa.Integer(), nullable=False),
    sa.Column('config', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('fingerprint', sa.String(length=64), nullable=True),
    sa.Column('row_counts', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('class_balance', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('leakage_report', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('preprocessing', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('storage_path', sa.String(length=500), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_ml_datasets_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_ml_datasets_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_ml_datasets_job_id_jobs')),
    sa.ForeignKeyConstraint(['policy_id'], ['policies.id'], name=op.f('fk_ml_datasets_policy_id_policies')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_ml_datasets_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_ml_datasets')),
    sa.UniqueConstraint('tenant_id', 'name', 'version', name='uq_ml_datasets_identity')
    )
    with op.batch_alter_table('ml_datasets', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_ml_datasets_contract_id'), ['contract_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_ml_datasets_policy_id'), ['policy_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_ml_datasets_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('source_mappings',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('source_id', sa.Integer(), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('mapping', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('is_current', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_source_mappings_created_by_users')),
    sa.ForeignKeyConstraint(['source_id'], ['data_sources.id'], name=op.f('fk_source_mappings_source_id_data_sources')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_source_mappings_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_source_mappings')),
    sa.UniqueConstraint('source_id', 'version', name='uq_source_mappings_source_version')
    )
    with op.batch_alter_table('source_mappings', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_source_mappings_source_id'), ['source_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_source_mappings_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('webhook_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('source_id', sa.Integer(), nullable=True),
    sa.Column('provider', sa.String(length=30), nullable=False),
    sa.Column('idempotency_key', sa.String(length=200), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('signature_valid', sa.Boolean(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('received_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('processed_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['source_id'], ['data_sources.id'], name=op.f('fk_webhook_events_source_id_data_sources')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_webhook_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_webhook_events')),
    sa.UniqueConstraint('tenant_id', 'provider', 'idempotency_key', name='uq_webhook_events_idempotency')
    )
    with op.batch_alter_table('webhook_events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_webhook_events_source_id'), ['source_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_webhook_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('customers',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('name', sa.String(length=300), nullable=True),
    sa.Column('email', sa.String(length=320), nullable=True),
    sa.Column('industry', sa.String(length=80), nullable=True),
    sa.Column('company_size', sa.String(length=40), nullable=True),
    sa.Column('employee_count', sa.Integer(), nullable=True),
    sa.Column('country', sa.String(length=80), nullable=True),
    sa.Column('region', sa.String(length=80), nullable=True),
    sa.Column('acquisition_channel', sa.String(length=80), nullable=True),
    sa.Column('acquisition_campaign', sa.String(length=120), nullable=True),
    sa.Column('acquired_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('consent_marketing', sa.Boolean(), nullable=True),
    sa.Column('consent_updated_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('employee_count IS NULL OR employee_count >= 0', name=op.f('ck_customers_employee_count_non_negative')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_customers_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_customers_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_customers')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_customers_tenant_external_id')
    )
    with op.batch_alter_table('customers', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_customers_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('dq_findings',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('run_id', sa.Integer(), nullable=False),
    sa.Column('rule_id', sa.Integer(), nullable=False),
    sa.Column('rule_name', sa.String(length=120), nullable=False),
    sa.Column('rule_version', sa.Integer(), nullable=False),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('entity_id', sa.Integer(), nullable=True),
    sa.Column('entity_ref', sa.String(length=120), nullable=True),
    sa.Column('severity', sa.String(length=20), nullable=False),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.ForeignKeyConstraint(['rule_id'], ['dq_rules.id'], name=op.f('fk_dq_findings_rule_id_dq_rules')),
    sa.ForeignKeyConstraint(['run_id'], ['dq_runs.id'], name=op.f('fk_dq_findings_run_id_dq_runs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_dq_findings_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_dq_findings'))
    )
    with op.batch_alter_table('dq_findings', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_dq_findings_rule_id'), ['rule_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_dq_findings_run_id'), ['run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_dq_findings_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('entity_history',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('entity_id', sa.Integer(), nullable=False),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('change_source', sa.String(length=20), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('correction_id', sa.Integer(), nullable=True),
    sa.Column('before', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('after', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('changed_by', sa.Integer(), nullable=True),
    sa.Column('changed_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['changed_by'], ['users.id'], name=op.f('fk_entity_history_changed_by_users')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_entity_history_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_entity_history_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_entity_history'))
    )
    with op.batch_alter_table('entity_history', schema=None) as batch_op:
        batch_op.create_index('ix_entity_history_entity', ['tenant_id', 'entity_type', 'entity_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_entity_history_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('import_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('source_id', sa.Integer(), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('mapping_version', sa.Integer(), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('mode', sa.String(length=20), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('rows_read', sa.Integer(), nullable=False),
    sa.Column('rows_inserted', sa.Integer(), nullable=False),
    sa.Column('rows_updated', sa.Integer(), nullable=False),
    sa.Column('rows_unchanged', sa.Integer(), nullable=False),
    sa.Column('rows_duplicate', sa.Integer(), nullable=False),
    sa.Column('rows_quarantined', sa.Integer(), nullable=False),
    sa.Column('cursor_before', sa.String(length=200), nullable=True),
    sa.Column('cursor_after', sa.String(length=200), nullable=True),
    sa.Column('reconciliation', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_import_runs_created_by_users')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_import_runs_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_import_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['source_id'], ['data_sources.id'], name=op.f('fk_import_runs_source_id_data_sources')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_import_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_import_runs'))
    )
    with op.batch_alter_table('import_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_import_runs_dataset_version_id'), ['dataset_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_import_runs_source_id'), ['source_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_import_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('model_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('dataset_id', sa.Integer(), nullable=False),
    sa.Column('group_id', sa.String(length=40), nullable=False),
    sa.Column('algorithm', sa.String(length=40), nullable=False),
    sa.Column('imbalance_strategy', sa.String(length=30), nullable=False),
    sa.Column('is_baseline', sa.Boolean(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('params', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('search', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('cv_metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('valid_metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('test_metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('test_evaluated_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('calibration', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('artifact_path', sa.String(length=500), nullable=True),
    sa.Column('artifact_sha256', sa.String(length=64), nullable=True),
    sa.Column('seed', sa.Integer(), nullable=False),
    sa.Column('duration_seconds', sa.Float(), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('mlflow_run_id', sa.String(length=64), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('running','completed','failed','unavailable')", name=op.f('ck_model_runs_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_model_runs_created_by_users')),
    sa.ForeignKeyConstraint(['dataset_id'], ['ml_datasets.id'], name=op.f('fk_model_runs_dataset_id_ml_datasets')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_model_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_model_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_model_runs'))
    )
    with op.batch_alter_table('model_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_model_runs_dataset_id'), ['dataset_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_runs_group_id'), ['group_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('plans',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('name', sa.String(length=200), nullable=True),
    sa.Column('product', sa.String(length=120), nullable=True),
    sa.Column('tier', sa.String(length=40), nullable=True),
    sa.Column('billing_period', sa.String(length=20), nullable=True),
    sa.Column('list_price', sa.Numeric(precision=18, scale=4), nullable=True),
    sa.Column('currency', sa.String(length=3), nullable=True),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('list_price IS NULL OR list_price >= 0', name=op.f('ck_plans_list_price_non_negative')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_plans_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_plans_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_plans')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_plans_tenant_external_id')
    )
    with op.batch_alter_table('plans', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_plans_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('uplift_models',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('experiment_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('method', sa.String(length=40), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('delta', sa.Float(), nullable=False),
    sa.Column('metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('validation', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('artifact_path', sa.String(length=500), nullable=True),
    sa.Column('artifact_sha256', sa.String(length=64), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('trained','validation_failed','validated','approved','rejected')", name=op.f('ck_uplift_models_status_valid')),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_uplift_models_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_uplift_models_created_by_users')),
    sa.ForeignKeyConstraint(['experiment_id'], ['experiments.id'], name=op.f('fk_uplift_models_experiment_id_experiments')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_uplift_models_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_uplift_models_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_uplift_models'))
    )
    with op.batch_alter_table('uplift_models', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_uplift_models_experiment_id'), ['experiment_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_uplift_models_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('accounts',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=30), nullable=True),
    sa.Column('currency', sa.String(length=3), nullable=True),
    sa.Column('billing_email', sa.String(length=320), nullable=True),
    sa.Column('payment_method_type', sa.String(length=40), nullable=True),
    sa.Column('payment_method_expires_on', sa.Date(), nullable=True),
    sa.Column('csm_owner', sa.String(length=200), nullable=True),
    sa.Column('opened_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('closed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_accounts_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_accounts_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_accounts_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_accounts')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_accounts_tenant_external_id')
    )
    with op.batch_alter_table('accounts', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_accounts_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_accounts_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('acquisitions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('channel', sa.String(length=80), nullable=True),
    sa.Column('campaign', sa.String(length=120), nullable=True),
    sa.Column('acquired_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('cac', sa.Numeric(precision=18, scale=4), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_acquisitions_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_acquisitions_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_acquisitions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_acquisitions')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_acquisitions_tenant_external_id')
    )
    with op.batch_alter_table('acquisitions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_acquisitions_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_acquisitions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('churn_labels',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('policy_id', sa.Integer(), nullable=False),
    sa.Column('label_run_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('horizon_days', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('label', sa.Integer(), nullable=True),
    sa.Column('churn_type', sa.String(length=20), nullable=True),
    sa.Column('churn_reason', sa.String(length=40), nullable=True),
    sa.Column('churn_date', sa.Date(), nullable=True),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('computed_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("(status = 'churned' AND label = 1) OR (status = 'retained' AND label = 0) OR (status NOT IN ('churned','retained') AND label IS NULL)", name=op.f('ck_churn_labels_label_matches_status')),
    sa.CheckConstraint("status IN ('churned','retained','immature','unknown','ineligible')", name=op.f('ck_churn_labels_status_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_churn_labels_customer_id_customers')),
    sa.ForeignKeyConstraint(['label_run_id'], ['label_runs.id'], name=op.f('fk_churn_labels_label_run_id_label_runs')),
    sa.ForeignKeyConstraint(['policy_id'], ['policies.id'], name=op.f('fk_churn_labels_policy_id_policies')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_churn_labels_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_churn_labels')),
    sa.UniqueConstraint('tenant_id', 'policy_id', 'customer_id', 'as_of_date', name='uq_churn_labels_identity')
    )
    with op.batch_alter_table('churn_labels', schema=None) as batch_op:
        batch_op.create_index('ix_churn_labels_asof', ['tenant_id', 'policy_id', 'as_of_date'], unique=False)
        batch_op.create_index(batch_op.f('ix_churn_labels_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_churn_labels_label_run_id'), ['label_run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_churn_labels_policy_id'), ['policy_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_churn_labels_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('corrections',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('entity_id', sa.Integer(), nullable=False),
    sa.Column('field', sa.String(length=80), nullable=False),
    sa.Column('old_value', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('new_value', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('reason', sa.Text(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('finding_id', sa.Integer(), nullable=True),
    sa.Column('proposed_by', sa.Integer(), nullable=True),
    sa.Column('proposed_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.Column('applied_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('proposed','approved','rejected','applied')", name=op.f('ck_corrections_status_valid')),
    sa.ForeignKeyConstraint(['finding_id'], ['dq_findings.id'], name=op.f('fk_corrections_finding_id_dq_findings')),
    sa.ForeignKeyConstraint(['proposed_by'], ['users.id'], name=op.f('fk_corrections_proposed_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_corrections_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_corrections_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_corrections'))
    )
    with op.batch_alter_table('corrections', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_corrections_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_corrections_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('crm_contact_links',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('connection_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('matched_by', sa.String(length=30), nullable=False),
    sa.Column('synced_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['connection_id'], ['crm_connections.id'], name=op.f('fk_crm_contact_links_connection_id_crm_connections')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_crm_contact_links_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_crm_contact_links_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_crm_contact_links')),
    sa.UniqueConstraint('connection_id', 'customer_id', name='uq_crm_contact_links_identity')
    )
    with op.batch_alter_table('crm_contact_links', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_crm_contact_links_connection_id'), ['connection_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_contact_links_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_contact_links_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('crm_deliveries',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('connection_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=True),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('idempotency_key', sa.String(length=200), nullable=False),
    sa.Column('status', sa.String(length=12), nullable=False),
    sa.Column('attempts', sa.Integer(), nullable=False),
    sa.Column('next_attempt_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('external_id', sa.String(length=120), nullable=True),
    sa.Column('last_error', sa.Text(), nullable=True),
    sa.Column('response', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('sent_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("kind IN ('risk_score','task','note','action')", name=op.f('ck_crm_deliveries_kind_valid')),
    sa.CheckConstraint("status IN ('pending','sent','failed','dead','skipped')", name=op.f('ck_crm_deliveries_status_valid')),
    sa.ForeignKeyConstraint(['connection_id'], ['crm_connections.id'], name=op.f('fk_crm_deliveries_connection_id_crm_connections')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_crm_deliveries_created_by_users')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_crm_deliveries_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_crm_deliveries_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_crm_deliveries')),
    sa.UniqueConstraint('tenant_id', 'idempotency_key', name='uq_crm_deliveries_idempotency')
    )
    with op.batch_alter_table('crm_deliveries', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_crm_deliveries_connection_id'), ['connection_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_deliveries_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_deliveries_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_deliveries_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('experiment_assignments',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('experiment_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('arm', sa.String(length=12), nullable=False),
    sa.Column('assigned_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('delivered', sa.Boolean(), nullable=True),
    sa.Column('outcome', sa.String(length=20), nullable=True),
    sa.Column('outcome_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("arm IN ('control','treatment')", name=op.f('ck_experiment_assignments_arm_valid')),
    sa.CheckConstraint("outcome IS NULL OR outcome IN ('retained','churned')", name=op.f('ck_experiment_assignments_outcome_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_experiment_assignments_customer_id_customers')),
    sa.ForeignKeyConstraint(['experiment_id'], ['experiments.id'], name=op.f('fk_experiment_assignments_experiment_id_experiments')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_experiment_assignments_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_experiment_assignments')),
    sa.UniqueConstraint('experiment_id', 'customer_id', name='uq_experiment_assignments_identity')
    )
    with op.batch_alter_table('experiment_assignments', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_experiment_assignments_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_experiment_assignments_experiment_id'), ['experiment_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_experiment_assignments_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('feature_vectors',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('values', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('max_source_ts', sa.DateTime(timezone=True), nullable=True),
    sa.Column('run_id', sa.Integer(), nullable=False),
    sa.Column('computed_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_feature_vectors_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_feature_vectors_customer_id_customers')),
    sa.ForeignKeyConstraint(['run_id'], ['feature_runs.id'], name=op.f('fk_feature_vectors_run_id_feature_runs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_feature_vectors_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_feature_vectors')),
    sa.UniqueConstraint('tenant_id', 'contract_id', 'customer_id', 'as_of_date', name='uq_feature_vectors_identity')
    )
    with op.batch_alter_table('feature_vectors', schema=None) as batch_op:
        batch_op.create_index('ix_feature_vectors_asof', ['tenant_id', 'contract_id', 'as_of_date'], unique=False)
        batch_op.create_index(batch_op.f('ix_feature_vectors_run_id'), ['run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_feature_vectors_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('model_evaluations',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('model_run_id', sa.Integer(), nullable=False),
    sa.Column('split', sa.String(length=20), nullable=False),
    sa.Column('metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('curves', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('threshold_analysis', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('subgroups', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('cost_policy_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("split IN ('train','valid','test')", name=op.f('ck_model_evaluations_split_valid')),
    sa.ForeignKeyConstraint(['cost_policy_id'], ['policies.id'], name=op.f('fk_model_evaluations_cost_policy_id_policies')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_model_evaluations_created_by_users')),
    sa.ForeignKeyConstraint(['model_run_id'], ['model_runs.id'], name=op.f('fk_model_evaluations_model_run_id_model_runs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_model_evaluations_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_model_evaluations'))
    )
    with op.batch_alter_table('model_evaluations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_model_evaluations_model_run_id'), ['model_run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_evaluations_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('model_versions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('model_run_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('stage', sa.String(length=20), nullable=False),
    sa.Column('approval_status', sa.String(length=20), nullable=False),
    sa.Column('threshold', sa.Float(), nullable=True),
    sa.Column('threshold_basis', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('cost_policy_id', sa.Integer(), nullable=True),
    sa.Column('mlflow_model_version', sa.String(length=40), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("approval_status IN ('pending','approved','rejected')", name=op.f('ck_model_versions_approval_valid')),
    sa.CheckConstraint("stage <> 'production' OR approval_status = 'approved'", name=op.f('ck_model_versions_production_requires_approval')),
    sa.CheckConstraint("stage IN ('none','staging','production','archived')", name=op.f('ck_model_versions_stage_valid')),
    sa.CheckConstraint('threshold IS NULL OR (threshold >= 0 AND threshold <= 1)', name=op.f('ck_model_versions_threshold_range')),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_model_versions_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['cost_policy_id'], ['policies.id'], name=op.f('fk_model_versions_cost_policy_id_policies')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_model_versions_created_by_users')),
    sa.ForeignKeyConstraint(['model_run_id'], ['model_runs.id'], name=op.f('fk_model_versions_model_run_id_model_runs')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_model_versions_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_model_versions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_model_versions')),
    sa.UniqueConstraint('tenant_id', 'name', 'version', name='uq_model_versions_identity')
    )
    with op.batch_alter_table('model_versions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_model_versions_contract_id'), ['contract_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_versions_model_run_id'), ['model_run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_versions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('online_features',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('values', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_online_features_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_online_features_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_online_features_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_online_features')),
    sa.UniqueConstraint('tenant_id', 'contract_id', 'customer_id', name='uq_online_features_identity')
    )
    with op.batch_alter_table('online_features', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_online_features_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('quarantine_records',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('import_run_id', sa.Integer(), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('entity_type', sa.String(length=40), nullable=False),
    sa.Column('row_number', sa.Integer(), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('reasons', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('corrected_payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('open','corrected','rejected','reprocessed')", name=op.f('ck_quarantine_records_status_valid')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_quarantine_records_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['import_run_id'], ['import_runs.id'], name=op.f('fk_quarantine_records_import_run_id_import_runs')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_quarantine_records_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_quarantine_records_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_quarantine_records'))
    )
    with op.batch_alter_table('quarantine_records', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_quarantine_records_import_run_id'), ['import_run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_quarantine_records_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_quarantine_records_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('support_interactions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('opened_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('first_response_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('resolved_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('priority', sa.String(length=20), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=True),
    sa.Column('escalated', sa.Boolean(), nullable=False),
    sa.Column('category', sa.String(length=80), nullable=True),
    sa.Column('channel', sa.String(length=40), nullable=True),
    sa.Column('csat', sa.Float(), nullable=True),
    sa.Column('nps_score', sa.Integer(), nullable=True),
    sa.Column('body', sa.Text(), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('nps_score IS NULL OR (nps_score >= 0 AND nps_score <= 10)', name=op.f('ck_support_interactions_nps_range')),
    sa.CheckConstraint('resolved_at IS NULL OR resolved_at >= opened_at', name=op.f('ck_support_interactions_resolved_after_opened')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_support_interactions_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_support_interactions_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_support_interactions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_support_interactions')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_support_interactions_tenant_external_id')
    )
    with op.batch_alter_table('support_interactions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_support_interactions_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_support_interactions_opened_at'), ['opened_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_support_interactions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('uplift_scores',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('uplift_model_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('p_retain_treated', sa.Float(), nullable=False),
    sa.Column('p_retain_control', sa.Float(), nullable=False),
    sa.Column('uplift', sa.Float(), nullable=False),
    sa.Column('segment', sa.String(length=20), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("segment IN ('persuadable','sure_thing','lost_cause','sleeping_dog')", name=op.f('ck_uplift_scores_segment_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_uplift_scores_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_uplift_scores_tenant_id_tenants')),
    sa.ForeignKeyConstraint(['uplift_model_id'], ['uplift_models.id'], name=op.f('fk_uplift_scores_uplift_model_id_uplift_models')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_uplift_scores')),
    sa.UniqueConstraint('uplift_model_id', 'customer_id', 'as_of_date', name='uq_uplift_scores_identity')
    )
    with op.batch_alter_table('uplift_scores', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_uplift_scores_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_uplift_scores_tenant_id'), ['tenant_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_uplift_scores_uplift_model_id'), ['uplift_model_id'], unique=False)

    op.create_table('usage_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('occurred_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('event_type', sa.String(length=30), nullable=False),
    sa.Column('feature_name', sa.String(length=80), nullable=True),
    sa.Column('duration_seconds', sa.Float(), nullable=True),
    sa.Column('quantity', sa.Integer(), nullable=False),
    sa.Column('user_ref', sa.String(length=120), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('duration_seconds IS NULL OR duration_seconds >= 0', name=op.f('ck_usage_events_duration_non_negative')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_usage_events_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_usage_events_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_usage_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_usage_events')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_usage_events_tenant_external_id')
    )
    with op.batch_alter_table('usage_events', schema=None) as batch_op:
        batch_op.create_index('ix_usage_events_customer_time', ['tenant_id', 'customer_id', 'occurred_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_usage_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('drift_reports',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('engine', sa.String(length=20), nullable=False),
    sa.Column('model_version_id', sa.Integer(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('reference', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('current', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('result', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("kind IN ('feature','prediction','data_quality','concept')", name=op.f('ck_drift_reports_kind_valid')),
    sa.CheckConstraint("status IN ('ok','warning','alert','insufficient_data')", name=op.f('ck_drift_reports_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_drift_reports_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_drift_reports_job_id_jobs')),
    sa.ForeignKeyConstraint(['model_version_id'], ['model_versions.id'], name=op.f('fk_drift_reports_model_version_id_model_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_drift_reports_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_drift_reports'))
    )
    with op.batch_alter_table('drift_reports', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_drift_reports_model_version_id'), ['model_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_drift_reports_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('prediction_batches',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('model_version_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('kind', sa.String(length=20), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('total', sa.Integer(), nullable=False),
    sa.Column('succeeded', sa.Integer(), nullable=False),
    sa.Column('failed', sa.Integer(), nullable=False),
    sa.Column('decile_cutpoints', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('summary', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('idempotency_key', sa.String(length=200), nullable=False),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_prediction_batches_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_prediction_batches_job_id_jobs')),
    sa.ForeignKeyConstraint(['model_version_id'], ['model_versions.id'], name=op.f('fk_prediction_batches_model_version_id_model_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_prediction_batches_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_prediction_batches')),
    sa.UniqueConstraint('tenant_id', 'idempotency_key', name='uq_prediction_batches_idempotency')
    )
    with op.batch_alter_table('prediction_batches', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_prediction_batches_model_version_id'), ['model_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_prediction_batches_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('subscriptions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('account_id', sa.Integer(), nullable=True),
    sa.Column('plan_id', sa.Integer(), nullable=True),
    sa.Column('status', sa.String(length=30), nullable=True),
    sa.Column('billing_period', sa.String(length=20), nullable=True),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('trial_end_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('current_period_end', sa.DateTime(timezone=True), nullable=True),
    sa.Column('cancel_requested_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('ended_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('end_reason', sa.String(length=40), nullable=True),
    sa.Column('mrr', sa.Numeric(precision=18, scale=4), nullable=True),
    sa.Column('discount_pct', sa.Float(), nullable=True),
    sa.Column('auto_renew', sa.Boolean(), nullable=True),
    sa.Column('quantity', sa.Integer(), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('discount_pct IS NULL OR (discount_pct >= 0 AND discount_pct <= 100)', name=op.f('ck_subscriptions_discount_range')),
    sa.CheckConstraint('ended_at IS NULL OR ended_at >= started_at', name=op.f('ck_subscriptions_end_after_start')),
    sa.CheckConstraint('mrr IS NULL OR mrr >= 0', name=op.f('ck_subscriptions_mrr_non_negative')),
    sa.ForeignKeyConstraint(['account_id'], ['accounts.id'], name=op.f('fk_subscriptions_account_id_accounts')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_subscriptions_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_subscriptions_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], name=op.f('fk_subscriptions_plan_id_plans')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_subscriptions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_subscriptions')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_subscriptions_tenant_external_id')
    )
    with op.batch_alter_table('subscriptions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_subscriptions_account_id'), ['account_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscriptions_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscriptions_plan_id'), ['plan_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscriptions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('invoices',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('subscription_id', sa.Integer(), nullable=True),
    sa.Column('issued_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('due_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('paid_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('amount', sa.Numeric(precision=18, scale=4), nullable=False),
    sa.Column('discount_amount', sa.Numeric(precision=18, scale=4), nullable=True),
    sa.Column('currency', sa.String(length=3), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('amount >= 0', name=op.f('ck_invoices_amount_non_negative')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_invoices_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_invoices_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['subscription_id'], ['subscriptions.id'], name=op.f('fk_invoices_subscription_id_subscriptions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_invoices_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_invoices')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_invoices_tenant_external_id')
    )
    with op.batch_alter_table('invoices', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_invoices_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_invoices_issued_at'), ['issued_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_invoices_subscription_id'), ['subscription_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_invoices_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('predictions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('batch_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('model_version_id', sa.Integer(), nullable=False),
    sa.Column('contract_id', sa.Integer(), nullable=False),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('horizon_days', sa.Integer(), nullable=False),
    sa.Column('probability', sa.Float(), nullable=False),
    sa.Column('threshold', sa.Float(), nullable=True),
    sa.Column('predicted_label', sa.Integer(), nullable=True),
    sa.Column('risk_tier', sa.String(length=20), nullable=True),
    sa.Column('risk_decile', sa.Integer(), nullable=True),
    sa.Column('top_reasons', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint('probability >= 0 AND probability <= 1', name=op.f('ck_predictions_probability_range')),
    sa.CheckConstraint('risk_decile IS NULL OR (risk_decile >= 1 AND risk_decile <= 10)', name=op.f('ck_predictions_decile_range')),
    sa.ForeignKeyConstraint(['batch_id'], ['prediction_batches.id'], name=op.f('fk_predictions_batch_id_prediction_batches')),
    sa.ForeignKeyConstraint(['contract_id'], ['feature_contracts.id'], name=op.f('fk_predictions_contract_id_feature_contracts')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_predictions_customer_id_customers')),
    sa.ForeignKeyConstraint(['model_version_id'], ['model_versions.id'], name=op.f('fk_predictions_model_version_id_model_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_predictions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_predictions')),
    sa.UniqueConstraint('tenant_id', 'model_version_id', 'customer_id', 'as_of_date', name='uq_predictions_identity')
    )
    with op.batch_alter_table('predictions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_predictions_batch_id'), ['batch_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_predictions_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_predictions_model_version_id'), ['model_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_predictions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('subscription_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('subscription_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('event_type', sa.String(length=30), nullable=False),
    sa.Column('occurred_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('plan_id', sa.Integer(), nullable=True),
    sa.Column('mrr', sa.Numeric(precision=18, scale=4), nullable=True),
    sa.Column('reason', sa.String(length=40), nullable=True),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('is_derived', sa.Boolean(), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_subscription_events_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_subscription_events_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['plan_id'], ['plans.id'], name=op.f('fk_subscription_events_plan_id_plans')),
    sa.ForeignKeyConstraint(['subscription_id'], ['subscriptions.id'], name=op.f('fk_subscription_events_subscription_id_subscriptions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_subscription_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_subscription_events')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_subscription_events_tenant_external_id')
    )
    with op.batch_alter_table('subscription_events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_subscription_events_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscription_events_occurred_at'), ['occurred_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscription_events_subscription_id'), ['subscription_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_subscription_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('explanations',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('scope', sa.String(length=10), nullable=False),
    sa.Column('model_run_id', sa.Integer(), nullable=False),
    sa.Column('model_version_id', sa.Integer(), nullable=True),
    sa.Column('prediction_id', sa.Integer(), nullable=True),
    sa.Column('customer_id', sa.Integer(), nullable=True),
    sa.Column('as_of_date', sa.Date(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('reason', sa.Text(), nullable=True),
    sa.Column('method', sa.String(length=60), nullable=True),
    sa.Column('space', sa.String(length=20), nullable=True),
    sa.Column('base_value', sa.Float(), nullable=True),
    sa.Column('output_value', sa.Float(), nullable=True),
    sa.Column('additivity_error', sa.Float(), nullable=True),
    sa.Column('contributions', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('contract_version', sa.String(length=140), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("scope IN ('global','local')", name=op.f('ck_explanations_scope_valid')),
    sa.CheckConstraint("status IN ('available','unavailable')", name=op.f('ck_explanations_status_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_explanations_customer_id_customers')),
    sa.ForeignKeyConstraint(['model_run_id'], ['model_runs.id'], name=op.f('fk_explanations_model_run_id_model_runs')),
    sa.ForeignKeyConstraint(['model_version_id'], ['model_versions.id'], name=op.f('fk_explanations_model_version_id_model_versions')),
    sa.ForeignKeyConstraint(['prediction_id'], ['predictions.id'], name=op.f('fk_explanations_prediction_id_predictions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_explanations_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_explanations'))
    )
    with op.batch_alter_table('explanations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_explanations_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_explanations_model_run_id'), ['model_run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_explanations_model_version_id'), ['model_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_explanations_prediction_id'), ['prediction_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_explanations_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('payments',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('external_id', sa.String(length=120), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('invoice_id', sa.Integer(), nullable=True),
    sa.Column('attempted_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('amount', sa.Numeric(precision=18, scale=4), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('failure_reason', sa.String(length=80), nullable=True),
    sa.Column('method', sa.String(length=40), nullable=True),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('source_row', sa.Integer(), nullable=True),
    sa.Column('record_version', sa.Integer(), nullable=False),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('succeeded','failed','refunded')", name=op.f('ck_payments_status_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_payments_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_payments_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['invoice_id'], ['invoices.id'], name=op.f('fk_payments_invoice_id_invoices')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_payments_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_payments')),
    sa.UniqueConstraint('tenant_id', 'external_id', name='uq_payments_tenant_external_id')
    )
    with op.batch_alter_table('payments', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_payments_attempted_at'), ['attempted_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_payments_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_payments_invoice_id'), ['invoice_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_payments_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('retention_recommendations',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('prediction_id', sa.Integer(), nullable=True),
    sa.Column('batch_id', sa.Integer(), nullable=True),
    sa.Column('playbook_policy_id', sa.Integer(), nullable=True),
    sa.Column('campaign_id', sa.Integer(), nullable=True),
    sa.Column('segment', sa.String(length=40), nullable=False),
    sa.Column('action_code', sa.String(length=60), nullable=False),
    sa.Column('channel', sa.String(length=30), nullable=True),
    sa.Column('priority', sa.Integer(), nullable=False),
    sa.Column('rationale', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('eligibility', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('blocked_reason', sa.String(length=200), nullable=True),
    sa.Column('assigned_to', sa.String(length=200), nullable=True),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('crm_delivery_id', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('proposed','approved','dismissed','blocked','executed')", name=op.f('ck_retention_recommendations_status_valid')),
    sa.ForeignKeyConstraint(['batch_id'], ['prediction_batches.id'], name=op.f('fk_retention_recommendations_batch_id_prediction_batches')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_retention_recommendations_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_retention_recommendations_customer_id_customers')),
    sa.ForeignKeyConstraint(['playbook_policy_id'], ['policies.id'], name=op.f('fk_retention_recommendations_playbook_policy_id_policies')),
    sa.ForeignKeyConstraint(['prediction_id'], ['predictions.id'], name=op.f('fk_retention_recommendations_prediction_id_predictions')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_retention_recommendations_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_retention_recommendations_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_retention_recommendations'))
    )
    with op.batch_alter_table('retention_recommendations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_retention_recommendations_batch_id'), ['batch_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retention_recommendations_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retention_recommendations_prediction_id'), ['prediction_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_retention_recommendations_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_retention_recommendations_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('interventions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('recommendation_id', sa.Integer(), nullable=True),
    sa.Column('campaign_id', sa.Integer(), nullable=True),
    sa.Column('experiment_id', sa.Integer(), nullable=True),
    sa.Column('action_code', sa.String(length=60), nullable=False),
    sa.Column('channel', sa.String(length=30), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('delivered_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('outcome', sa.String(length=20), nullable=True),
    sa.Column('outcome_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('note', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("outcome IS NULL OR outcome IN ('retained','churned','unknown')", name=op.f('ck_interventions_outcome_valid')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_interventions_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_interventions_created_by_users')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_interventions_customer_id_customers')),
    sa.ForeignKeyConstraint(['recommendation_id'], ['retention_recommendations.id'], name=op.f('fk_interventions_recommendation_id_retention_recommendations')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_interventions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_interventions'))
    )
    with op.batch_alter_table('interventions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_interventions_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_interventions_recommendation_id'), ['recommendation_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_interventions_tenant_id'), ['tenant_id'], unique=False)



def downgrade() -> None:
    with op.batch_alter_table('interventions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_interventions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_interventions_recommendation_id'))
        batch_op.drop_index(batch_op.f('ix_interventions_customer_id'))

    op.drop_table('interventions')
    with op.batch_alter_table('retention_recommendations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_retention_recommendations_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_retention_recommendations_status'))
        batch_op.drop_index(batch_op.f('ix_retention_recommendations_prediction_id'))
        batch_op.drop_index(batch_op.f('ix_retention_recommendations_customer_id'))
        batch_op.drop_index(batch_op.f('ix_retention_recommendations_batch_id'))

    op.drop_table('retention_recommendations')
    with op.batch_alter_table('payments', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_payments_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_payments_invoice_id'))
        batch_op.drop_index(batch_op.f('ix_payments_customer_id'))
        batch_op.drop_index(batch_op.f('ix_payments_attempted_at'))

    op.drop_table('payments')
    with op.batch_alter_table('explanations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_explanations_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_explanations_prediction_id'))
        batch_op.drop_index(batch_op.f('ix_explanations_model_version_id'))
        batch_op.drop_index(batch_op.f('ix_explanations_model_run_id'))
        batch_op.drop_index(batch_op.f('ix_explanations_customer_id'))

    op.drop_table('explanations')
    with op.batch_alter_table('subscription_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_subscription_events_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_subscription_events_subscription_id'))
        batch_op.drop_index(batch_op.f('ix_subscription_events_occurred_at'))
        batch_op.drop_index(batch_op.f('ix_subscription_events_customer_id'))

    op.drop_table('subscription_events')
    with op.batch_alter_table('predictions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_predictions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_predictions_model_version_id'))
        batch_op.drop_index(batch_op.f('ix_predictions_customer_id'))
        batch_op.drop_index(batch_op.f('ix_predictions_batch_id'))

    op.drop_table('predictions')
    with op.batch_alter_table('invoices', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_invoices_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_invoices_subscription_id'))
        batch_op.drop_index(batch_op.f('ix_invoices_issued_at'))
        batch_op.drop_index(batch_op.f('ix_invoices_customer_id'))

    op.drop_table('invoices')
    with op.batch_alter_table('subscriptions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_subscriptions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_subscriptions_plan_id'))
        batch_op.drop_index(batch_op.f('ix_subscriptions_customer_id'))
        batch_op.drop_index(batch_op.f('ix_subscriptions_account_id'))

    op.drop_table('subscriptions')
    with op.batch_alter_table('prediction_batches', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_prediction_batches_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_prediction_batches_model_version_id'))

    op.drop_table('prediction_batches')
    with op.batch_alter_table('drift_reports', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_drift_reports_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_drift_reports_model_version_id'))

    op.drop_table('drift_reports')
    with op.batch_alter_table('usage_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_usage_events_tenant_id'))
        batch_op.drop_index('ix_usage_events_customer_time')

    op.drop_table('usage_events')
    with op.batch_alter_table('uplift_scores', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_uplift_scores_uplift_model_id'))
        batch_op.drop_index(batch_op.f('ix_uplift_scores_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_uplift_scores_customer_id'))

    op.drop_table('uplift_scores')
    with op.batch_alter_table('support_interactions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_support_interactions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_support_interactions_opened_at'))
        batch_op.drop_index(batch_op.f('ix_support_interactions_customer_id'))

    op.drop_table('support_interactions')
    with op.batch_alter_table('quarantine_records', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_quarantine_records_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_quarantine_records_status'))
        batch_op.drop_index(batch_op.f('ix_quarantine_records_import_run_id'))

    op.drop_table('quarantine_records')
    with op.batch_alter_table('online_features', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_online_features_tenant_id'))

    op.drop_table('online_features')
    with op.batch_alter_table('model_versions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_model_versions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_model_versions_model_run_id'))
        batch_op.drop_index(batch_op.f('ix_model_versions_contract_id'))

    op.drop_table('model_versions')
    with op.batch_alter_table('model_evaluations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_model_evaluations_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_model_evaluations_model_run_id'))

    op.drop_table('model_evaluations')
    with op.batch_alter_table('feature_vectors', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_feature_vectors_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_feature_vectors_run_id'))
        batch_op.drop_index('ix_feature_vectors_asof')

    op.drop_table('feature_vectors')
    with op.batch_alter_table('experiment_assignments', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_experiment_assignments_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_experiment_assignments_experiment_id'))
        batch_op.drop_index(batch_op.f('ix_experiment_assignments_customer_id'))

    op.drop_table('experiment_assignments')
    with op.batch_alter_table('crm_deliveries', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_deliveries_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_crm_deliveries_status'))
        batch_op.drop_index(batch_op.f('ix_crm_deliveries_customer_id'))
        batch_op.drop_index(batch_op.f('ix_crm_deliveries_connection_id'))

    op.drop_table('crm_deliveries')
    with op.batch_alter_table('crm_contact_links', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_contact_links_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_crm_contact_links_customer_id'))
        batch_op.drop_index(batch_op.f('ix_crm_contact_links_connection_id'))

    op.drop_table('crm_contact_links')
    with op.batch_alter_table('corrections', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_corrections_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_corrections_status'))

    op.drop_table('corrections')
    with op.batch_alter_table('churn_labels', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_churn_labels_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_churn_labels_policy_id'))
        batch_op.drop_index(batch_op.f('ix_churn_labels_label_run_id'))
        batch_op.drop_index(batch_op.f('ix_churn_labels_customer_id'))
        batch_op.drop_index('ix_churn_labels_asof')

    op.drop_table('churn_labels')
    with op.batch_alter_table('acquisitions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_acquisitions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_acquisitions_customer_id'))

    op.drop_table('acquisitions')
    with op.batch_alter_table('accounts', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_accounts_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_accounts_customer_id'))

    op.drop_table('accounts')
    with op.batch_alter_table('uplift_models', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_uplift_models_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_uplift_models_experiment_id'))

    op.drop_table('uplift_models')
    with op.batch_alter_table('plans', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_plans_tenant_id'))

    op.drop_table('plans')
    with op.batch_alter_table('model_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_model_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_model_runs_group_id'))
        batch_op.drop_index(batch_op.f('ix_model_runs_dataset_id'))

    op.drop_table('model_runs')
    with op.batch_alter_table('import_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_import_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_import_runs_source_id'))
        batch_op.drop_index(batch_op.f('ix_import_runs_dataset_version_id'))

    op.drop_table('import_runs')
    with op.batch_alter_table('entity_history', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_entity_history_tenant_id'))
        batch_op.drop_index('ix_entity_history_entity')

    op.drop_table('entity_history')
    with op.batch_alter_table('dq_findings', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_dq_findings_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_dq_findings_run_id'))
        batch_op.drop_index(batch_op.f('ix_dq_findings_rule_id'))

    op.drop_table('dq_findings')
    with op.batch_alter_table('customers', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_customers_tenant_id'))

    op.drop_table('customers')
    with op.batch_alter_table('webhook_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_webhook_events_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_webhook_events_source_id'))

    op.drop_table('webhook_events')
    with op.batch_alter_table('source_mappings', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_source_mappings_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_source_mappings_source_id'))

    op.drop_table('source_mappings')
    with op.batch_alter_table('ml_datasets', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_ml_datasets_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_ml_datasets_policy_id'))
        batch_op.drop_index(batch_op.f('ix_ml_datasets_contract_id'))

    op.drop_table('ml_datasets')
    with op.batch_alter_table('label_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_label_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_label_runs_policy_id'))

    op.drop_table('label_runs')
    with op.batch_alter_table('feature_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_feature_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_feature_runs_contract_id'))

    op.drop_table('feature_runs')
    with op.batch_alter_table('experiments', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_experiments_tenant_id'))

    op.drop_table('experiments')
    with op.batch_alter_table('dq_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_dq_runs_tenant_id'))

    op.drop_table('dq_runs')
    with op.batch_alter_table('dataset_versions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_dataset_versions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_dataset_versions_source_id'))

    op.drop_table('dataset_versions')
    with op.batch_alter_table('analysis_reports', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_analysis_reports_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_analysis_reports_kind'))

    op.drop_table('analysis_reports')
    with op.batch_alter_table('schedules', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_schedules_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_schedules_next_run_at'))

    op.drop_table('schedules')
    with op.batch_alter_table('policies', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_policies_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_policies_kind'))

    op.drop_table('policies')
    with op.batch_alter_table('jobs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_jobs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_jobs_job_type'))
        batch_op.drop_index('ix_jobs_claim')

    op.drop_table('jobs')
    with op.batch_alter_table('feature_contracts', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_feature_contracts_tenant_id'))

    op.drop_table('feature_contracts')
    with op.batch_alter_table('dq_rules', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_dq_rules_tenant_id'))

    op.drop_table('dq_rules')
    with op.batch_alter_table('data_sources', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_data_sources_tenant_id'))

    op.drop_table('data_sources')
    with op.batch_alter_table('crm_connections', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_connections_tenant_id'))

    op.drop_table('crm_connections')
    with op.batch_alter_table('campaigns', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_campaigns_tenant_id'))

    op.drop_table('campaigns')
    with op.batch_alter_table('auth_sessions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_auth_sessions_user_id'))
        batch_op.drop_index(batch_op.f('ix_auth_sessions_tenant_id'))

    op.drop_table('auth_sessions')
    with op.batch_alter_table('audit_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_audit_events_tenant_id'))
        batch_op.drop_index('ix_audit_events_entity')
        batch_op.drop_index(batch_op.f('ix_audit_events_actor_user_id'))
        batch_op.drop_index(batch_op.f('ix_audit_events_action'))

    op.drop_table('audit_events')
    with op.batch_alter_table('alerts', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_alerts_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_alerts_status'))

    op.drop_table('alerts')
    with op.batch_alter_table('users', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_users_tenant_id'))

    op.drop_table('users')
    op.drop_table('tenants')
    op.drop_table('feature_definitions')
