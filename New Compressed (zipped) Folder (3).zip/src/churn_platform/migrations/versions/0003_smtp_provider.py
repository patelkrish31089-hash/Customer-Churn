"""1.1.1: the e-mail channel can be delivered through an SMTP server.

Widens the check constraint on ``notification_providers.provider`` so that ``smtp`` is allowed next to the
vendors' HTTP APIs.  No column or table changes: the provider list is the only thing that moves.

A downgrade fails loudly if an SMTP provider exists, because the old constraint has no value for it; turn such
a provider off (or delete it) before going back.

Revision ID: 0003
Revises: 0002
Create Date: 2026-11-12
"""

from __future__ import annotations

from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

NEW = "provider IN ('ses','sendgrid','smtp','twilio','fcm','apns','inbox')"
OLD = "provider IN ('ses','sendgrid','twilio','fcm','apns','inbox')"


def upgrade() -> None:
    with op.batch_alter_table("notification_providers", schema=None) as batch_op:
        batch_op.drop_constraint(batch_op.f("ck_notification_providers_provider_valid"), type_="check")
        batch_op.create_check_constraint(op.f("ck_notification_providers_provider_valid"), NEW)


def downgrade() -> None:
    with op.batch_alter_table("notification_providers", schema=None) as batch_op:
        batch_op.drop_constraint(batch_op.f("ck_notification_providers_provider_valid"), type_="check")
        batch_op.create_check_constraint(op.f("ck_notification_providers_provider_valid"), OLD)
