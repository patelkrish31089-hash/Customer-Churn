"""1.1.0: customer signals and platform integrations.

Adds 28 tables (sentiment, product-feature catalogue and adoption, identity mapping, customer attribute history,
orchestrator runs, model stage transitions, CRM OAuth / webhooks / reverse ETL, notifications and campaigns,
single sign-on, shared rate-limit counters) and new columns on users, auth_sessions, customers, model_versions,
campaigns, crm_connections and crm_deliveries.  Additive only: no existing column or table is changed or removed.

Existing model versions get their lifecycle state from the stage and approval they already have.

Generated from the ORM metadata and then frozen.

Revision ID: 0002
Revises: 0001
Create Date: 2026-11-11
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('rate_limit_counters',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('bucket', sa.String(length=40), nullable=False),
    sa.Column('subject', sa.String(length=200), nullable=False),
    sa.Column('window_start', sa.Integer(), nullable=False),
    sa.Column('hits', sa.Integer(), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_rate_limit_counters')),
    sa.UniqueConstraint('bucket', 'subject', 'window_start', name='uq_rate_limit_counters_identity')
    )
    with op.batch_alter_table('rate_limit_counters', schema=None) as batch_op:
        batch_op.create_index('ix_rate_limit_counters_window', ['window_start'], unique=False)

    op.create_table('orchestrator_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('orchestrator', sa.String(length=20), nullable=False),
    sa.Column('step', sa.String(length=40), nullable=False),
    sa.Column('run_key', sa.String(length=250), nullable=False),
    sa.Column('dag_id', sa.String(length=120), nullable=True),
    sa.Column('dag_run_id', sa.String(length=250), nullable=True),
    sa.Column('task_id', sa.String(length=120), nullable=True),
    sa.Column('as_of_date', sa.Date(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('attempts', sa.Integer(), nullable=False),
    sa.Column('job_ids', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('detail', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('started_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("orchestrator IN ('airflow','platform','operator')", name=op.f('ck_orchestrator_runs_orchestrator_valid')),
    sa.CheckConstraint("status IN ('running','succeeded','failed','skipped')", name=op.f('ck_orchestrator_runs_status_valid')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_orchestrator_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_orchestrator_runs')),
    sa.UniqueConstraint('tenant_id', 'step', 'run_key', name='uq_orchestrator_runs_idempotency')
    )
    with op.batch_alter_table('orchestrator_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_orchestrator_runs_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_orchestrator_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('identity_merge_candidates',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('user_key_a', sa.String(length=64), nullable=False),
    sa.Column('user_key_b', sa.String(length=64), nullable=False),
    sa.Column('reason', sa.String(length=60), nullable=False),
    sa.Column('evidence', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('confidence', sa.Float(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('open','merged','rejected')", name=op.f('ck_identity_merge_candidates_status_valid')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_identity_merge_candidates_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_identity_merge_candidates_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_identity_merge_candidates')),
    sa.UniqueConstraint('tenant_id', 'user_key_a', 'user_key_b', name='uq_identity_merge_candidates_pair')
    )
    with op.batch_alter_table('identity_merge_candidates', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_identity_merge_candidates_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_identity_merge_candidates_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('identity_providers',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('protocol', sa.String(length=10), nullable=False),
    sa.Column('issuer', sa.String(length=400), nullable=False),
    sa.Column('client_id', sa.String(length=300), nullable=False),
    sa.Column('client_secret_enc', sa.Text(), nullable=True),
    sa.Column('scopes', sa.String(length=300), nullable=False),
    sa.Column('role_claim', sa.String(length=100), nullable=False),
    sa.Column('role_mapping', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('default_role', sa.String(length=40), nullable=True),
    sa.Column('allowed_email_domains', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('auto_provision', sa.Boolean(), nullable=False),
    sa.Column('trust_idp_mfa', sa.Boolean(), nullable=False),
    sa.Column('enabled', sa.Boolean(), nullable=False),
    sa.Column('metadata_cache', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('jwks_cache', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('cache_fetched_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("protocol IN ('oidc')", name=op.f('ck_identity_providers_protocol_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_identity_providers_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_identity_providers_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_identity_providers')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_identity_providers_tenant_name')
    )
    with op.batch_alter_table('identity_providers', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_identity_providers_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_providers',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=120), nullable=False),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('provider', sa.String(length=20), nullable=False),
    sa.Column('mode', sa.String(length=12), nullable=False),
    sa.Column('config', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('credentials_enc', sa.Text(), nullable=True),
    sa.Column('webhook_secret_enc', sa.Text(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('last_checked_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_error', sa.Text(), nullable=True),
    sa.Column('is_default', sa.Boolean(), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("channel IN ('email','sms','push','in_app')", name=op.f('ck_notification_providers_channel_valid')),
    sa.CheckConstraint("mode IN ('DRY_RUN','SANDBOX','LIVE')", name=op.f('ck_notification_providers_mode_valid')),
    sa.CheckConstraint("provider IN ('ses','sendgrid','twilio','fcm','apns','inbox')", name=op.f('ck_notification_providers_provider_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_notification_providers_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_providers_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_providers')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_notification_providers_tenant_name')
    )
    with op.batch_alter_table('notification_providers', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_providers_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_templates',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('code', sa.String(length=80), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('locale', sa.String(length=12), nullable=False),
    sa.Column('category', sa.String(length=20), nullable=False),
    sa.Column('subject', sa.String(length=300), nullable=True),
    sa.Column('body', sa.Text(), nullable=False),
    sa.Column('variables', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("category IN ('marketing','transactional')", name=op.f('ck_notification_templates_category_valid')),
    sa.CheckConstraint("channel IN ('email','sms','push','in_app')", name=op.f('ck_notification_templates_channel_valid')),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name=op.f('ck_notification_templates_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_notification_templates_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_notification_templates_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_templates_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_templates')),
    sa.UniqueConstraint('tenant_id', 'code', 'channel', 'locale', 'version', name='uq_notification_templates_identity')
    )
    with op.batch_alter_table('notification_templates', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_templates_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('product_features',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('feature_key', sa.String(length=80), nullable=False),
    sa.Column('version', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=160), nullable=False),
    sa.Column('description', sa.Text(), nullable=True),
    sa.Column('category', sa.String(length=60), nullable=True),
    sa.Column('availability', sa.String(length=20), nullable=False),
    sa.Column('required_plan', sa.String(length=40), nullable=True),
    sa.Column('release_date', sa.Date(), nullable=True),
    sa.Column('retired_date', sa.Date(), nullable=True),
    sa.Column('eligibility', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('event_mapping', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('adoption_rule', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('owner', sa.String(length=200), nullable=True),
    sa.Column('is_core', sa.Boolean(), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("availability IN ('ga','beta','limited','deprecated','retired')", name=op.f('ck_product_features_availability_valid')),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','retired')", name=op.f('ck_product_features_status_valid')),
    sa.CheckConstraint('retired_date IS NULL OR release_date IS NULL OR retired_date >= release_date', name=op.f('ck_product_features_retired_after_release')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_product_features_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_product_features_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_product_features_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_product_features')),
    sa.UniqueConstraint('tenant_id', 'feature_key', 'version', name='uq_product_features_identity')
    )
    with op.batch_alter_table('product_features', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_product_features_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('sentiment_models',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('provider', sa.String(length=40), nullable=False),
    sa.Column('model_id', sa.String(length=200), nullable=False),
    sa.Column('model_version', sa.String(length=80), nullable=False),
    sa.Column('tokenizer', sa.String(length=200), nullable=True),
    sa.Column('checksum_sha256', sa.String(length=64), nullable=False),
    sa.Column('source', sa.String(length=400), nullable=True),
    sa.Column('license', sa.String(length=80), nullable=True),
    sa.Column('languages', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('is_baseline', sa.Boolean(), nullable=False),
    sa.Column('is_active', sa.Boolean(), nullable=False),
    sa.Column('config', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_sentiment_models_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_sentiment_models_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_sentiment_models')),
    sa.UniqueConstraint('tenant_id', 'provider', 'model_id', 'model_version', 'checksum_sha256', name='uq_sentiment_models_identity')
    )
    with op.batch_alter_table('sentiment_models', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_sentiment_models_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('adoption_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('as_of_date', sa.Date(), nullable=False),
    sa.Column('window_days', sa.Integer(), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('catalog_hash', sa.String(length=64), nullable=True),
    sa.Column('result', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('pending','running','completed','failed')", name=op.f('ck_adoption_runs_status_valid')),
    sa.CheckConstraint('window_days >= 1 AND window_days <= 365', name=op.f('ck_adoption_runs_window_range')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_adoption_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_adoption_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_adoption_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_adoption_runs'))
    )
    with op.batch_alter_table('adoption_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_adoption_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('campaign_steps',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('campaign_id', sa.Integer(), nullable=False),
    sa.Column('step_index', sa.Integer(), nullable=False),
    sa.Column('variant', sa.String(length=20), nullable=False),
    sa.Column('delay_hours', sa.Float(), nullable=False),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('template_code', sa.String(length=80), nullable=False),
    sa.CheckConstraint("channel IN ('email','sms','push','in_app')", name=op.f('ck_campaign_steps_channel_valid')),
    sa.CheckConstraint('delay_hours >= 0', name=op.f('ck_campaign_steps_delay_non_negative')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_campaign_steps_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_campaign_steps_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_campaign_steps')),
    sa.UniqueConstraint('campaign_id', 'step_index', 'variant', name='uq_campaign_steps_identity')
    )
    with op.batch_alter_table('campaign_steps', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_campaign_steps_campaign_id'), ['campaign_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_campaign_steps_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('crm_oauth_states',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('connection_id', sa.Integer(), nullable=False),
    sa.Column('state_hash', sa.String(length=64), nullable=False),
    sa.Column('code_verifier_enc', sa.Text(), nullable=True),
    sa.Column('redirect_uri', sa.String(length=400), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('used_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['connection_id'], ['crm_connections.id'], name=op.f('fk_crm_oauth_states_connection_id_crm_connections')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_crm_oauth_states_created_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_crm_oauth_states_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_crm_oauth_states')),
    sa.UniqueConstraint('state_hash', name='uq_crm_oauth_states_state_hash')
    )
    with op.batch_alter_table('crm_oauth_states', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_crm_oauth_states_connection_id'), ['connection_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_oauth_states_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('crm_webhook_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('connection_id', sa.Integer(), nullable=False),
    sa.Column('event_key', sa.String(length=200), nullable=False),
    sa.Column('event_type', sa.String(length=80), nullable=True),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('attempts', sa.Integer(), nullable=False),
    sa.Column('outcome', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('received_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('processed_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('received','processed','ignored','failed')", name=op.f('ck_crm_webhook_events_status_valid')),
    sa.ForeignKeyConstraint(['connection_id'], ['crm_connections.id'], name=op.f('fk_crm_webhook_events_connection_id_crm_connections')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_crm_webhook_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_crm_webhook_events')),
    sa.UniqueConstraint('connection_id', 'event_key', name='uq_crm_webhook_events_idempotency')
    )
    with op.batch_alter_table('crm_webhook_events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_crm_webhook_events_connection_id'), ['connection_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_webhook_events_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_crm_webhook_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('identity_reconciliations',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('window_days', sa.Integer(), nullable=False),
    sa.Column('result', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('pending','running','completed','failed')", name=op.f('ck_identity_reconciliations_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_identity_reconciliations_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_identity_reconciliations_job_id_jobs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_identity_reconciliations_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_identity_reconciliations'))
    )
    with op.batch_alter_table('identity_reconciliations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_identity_reconciliations_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('oidc_login_states',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('provider_id', sa.Integer(), nullable=False),
    sa.Column('state_hash', sa.String(length=64), nullable=False),
    sa.Column('nonce_hash', sa.String(length=64), nullable=False),
    sa.Column('code_verifier_enc', sa.Text(), nullable=False),
    sa.Column('browser_hash', sa.String(length=64), nullable=False),
    sa.Column('redirect_uri', sa.String(length=400), nullable=False),
    sa.Column('exchange_hash', sa.String(length=64), nullable=True),
    sa.Column('session_token_enc', sa.Text(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('used_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('exchanged_at', sa.DateTime(timezone=True), nullable=True),
    sa.ForeignKeyConstraint(['provider_id'], ['identity_providers.id'], name=op.f('fk_oidc_login_states_provider_id_identity_providers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_oidc_login_states_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_oidc_login_states')),
    sa.UniqueConstraint('state_hash', name='uq_oidc_login_states_state_hash')
    )
    with op.batch_alter_table('oidc_login_states', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_oidc_login_states_provider_id'), ['provider_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_oidc_login_states_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('reverse_etl_syncs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('name', sa.String(length=160), nullable=False),
    sa.Column('entity', sa.String(length=30), nullable=False),
    sa.Column('destination', sa.String(length=20), nullable=False),
    sa.Column('connection_id', sa.Integer(), nullable=True),
    sa.Column('export_format', sa.String(length=10), nullable=True),
    sa.Column('field_mapping', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('filters', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('reviewed_by', sa.Integer(), nullable=True),
    sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('review_note', sa.Text(), nullable=True),
    sa.CheckConstraint("destination IN ('crm','export')", name=op.f('ck_reverse_etl_syncs_destination_valid')),
    sa.CheckConstraint("entity IN ('risk_scores','recommendations')", name=op.f('ck_reverse_etl_syncs_entity_valid')),
    sa.CheckConstraint("status IN ('draft','pending','approved','rejected','disabled')", name=op.f('ck_reverse_etl_syncs_status_valid')),
    sa.ForeignKeyConstraint(['connection_id'], ['crm_connections.id'], name=op.f('fk_reverse_etl_syncs_connection_id_crm_connections')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_reverse_etl_syncs_created_by_users')),
    sa.ForeignKeyConstraint(['reviewed_by'], ['users.id'], name=op.f('fk_reverse_etl_syncs_reviewed_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_reverse_etl_syncs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_reverse_etl_syncs')),
    sa.UniqueConstraint('tenant_id', 'name', name='uq_reverse_etl_syncs_tenant_name')
    )
    with op.batch_alter_table('reverse_etl_syncs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_reverse_etl_syncs_connection_id'), ['connection_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_reverse_etl_syncs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('sentiment_evaluations',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('sentiment_model_id', sa.Integer(), nullable=False),
    sa.Column('dataset_name', sa.String(length=200), nullable=False),
    sa.Column('is_synthetic', sa.Boolean(), nullable=False),
    sa.Column('rows', sa.Integer(), nullable=False),
    sa.Column('metrics', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_sentiment_evaluations_created_by_users')),
    sa.ForeignKeyConstraint(['sentiment_model_id'], ['sentiment_models.id'], name=op.f('fk_sentiment_evaluations_sentiment_model_id_sentiment_models')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_sentiment_evaluations_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_sentiment_evaluations'))
    )
    with op.batch_alter_table('sentiment_evaluations', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_sentiment_evaluations_sentiment_model_id'), ['sentiment_model_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sentiment_evaluations_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('sentiment_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('sentiment_model_id', sa.Integer(), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('trigger', sa.String(length=30), nullable=False),
    sa.Column('counts', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('pending','running','completed','failed')", name=op.f('ck_sentiment_runs_status_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_sentiment_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_sentiment_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['sentiment_model_id'], ['sentiment_models.id'], name=op.f('fk_sentiment_runs_sentiment_model_id_sentiment_models')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_sentiment_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_sentiment_runs'))
    )
    with op.batch_alter_table('sentiment_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_sentiment_runs_sentiment_model_id'), ['sentiment_model_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sentiment_runs_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('adoption_facts',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('run_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('feature_key', sa.String(length=80), nullable=False),
    sa.Column('state', sa.String(length=20), nullable=False),
    sa.Column('events', sa.Integer(), nullable=False),
    sa.Column('active_days', sa.Integer(), nullable=False),
    sa.Column('users', sa.Integer(), nullable=False),
    sa.Column('first_used_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('last_used_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('is_new', sa.Boolean(), nullable=False),
    sa.Column('is_abandoned', sa.Boolean(), nullable=False),
    sa.Column('days_to_first_use', sa.Float(), nullable=True),
    sa.CheckConstraint("state IN ('adopted','not_adopted','not_eligible','unknown','invalid_mapping')", name=op.f('ck_adoption_facts_state_valid')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_adoption_facts_customer_id_customers')),
    sa.ForeignKeyConstraint(['run_id'], ['adoption_runs.id'], name=op.f('fk_adoption_facts_run_id_adoption_runs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_adoption_facts_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_adoption_facts')),
    sa.UniqueConstraint('run_id', 'customer_id', 'feature_key', name='uq_adoption_facts_identity')
    )
    with op.batch_alter_table('adoption_facts', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_adoption_facts_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_adoption_facts_run_id'), ['run_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_adoption_facts_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('campaign_enrollments',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('campaign_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('variant', sa.String(length=20), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('status_reason', sa.String(length=200), nullable=True),
    sa.Column('current_step', sa.Integer(), nullable=False),
    sa.Column('next_step_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('source', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('outcome', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('enrolled_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('active','completed','cancelled','suppressed','ineligible','control')", name=op.f('ck_campaign_enrollments_status_valid')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_campaign_enrollments_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_campaign_enrollments_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_campaign_enrollments_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_campaign_enrollments')),
    sa.UniqueConstraint('campaign_id', 'customer_id', name='uq_campaign_enrollments_identity')
    )
    with op.batch_alter_table('campaign_enrollments', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_campaign_enrollments_campaign_id'), ['campaign_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_campaign_enrollments_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_campaign_enrollments_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_campaign_enrollments_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('customer_attribute_history',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('attribute', sa.String(length=40), nullable=False),
    sa.Column('value', sa.String(length=300), nullable=True),
    sa.Column('valid_from', sa.DateTime(timezone=True), nullable=True),
    sa.Column('valid_to', sa.DateTime(timezone=True), nullable=True),
    sa.Column('basis', sa.String(length=20), nullable=False),
    sa.Column('source', sa.String(length=20), nullable=False),
    sa.Column('dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('recorded_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('recorded_by', sa.Integer(), nullable=True),
    sa.Column('superseded_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('superseded_by', sa.Integer(), nullable=True),
    sa.Column('note', sa.Text(), nullable=True),
    sa.CheckConstraint("basis IN ('initial','effective','observed','backfill','correction')", name=op.f('ck_customer_attribute_history_basis_valid')),
    sa.CheckConstraint('valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from', name=op.f('ck_customer_attribute_history_validity_ordered')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_customer_attribute_history_customer_id_customers')),
    sa.ForeignKeyConstraint(['dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_customer_attribute_history_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['recorded_by'], ['users.id'], name=op.f('fk_customer_attribute_history_recorded_by_users')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_customer_attribute_history_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_customer_attribute_history'))
    )
    with op.batch_alter_table('customer_attribute_history', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_customer_attribute_history_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index('ix_customer_attribute_history_lookup', ['tenant_id', 'customer_id', 'attribute'], unique=False)
        batch_op.create_index(batch_op.f('ix_customer_attribute_history_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_messages',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=True),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('provider_id', sa.Integer(), nullable=True),
    sa.Column('template_id', sa.Integer(), nullable=True),
    sa.Column('campaign_id', sa.Integer(), nullable=True),
    sa.Column('enrollment_id', sa.Integer(), nullable=True),
    sa.Column('step_index', sa.Integer(), nullable=True),
    sa.Column('variant', sa.String(length=20), nullable=True),
    sa.Column('category', sa.String(length=20), nullable=False),
    sa.Column('recipient_enc', sa.Text(), nullable=True),
    sa.Column('recipient_hash', sa.String(length=64), nullable=True),
    sa.Column('recipient_hint', sa.String(length=80), nullable=True),
    sa.Column('subject', sa.String(length=300), nullable=True),
    sa.Column('body', sa.Text(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('status_reason', sa.String(length=200), nullable=True),
    sa.Column('is_dry_run', sa.Boolean(), nullable=False),
    sa.Column('provider_message_id', sa.String(length=200), nullable=True),
    sa.Column('idempotency_key', sa.String(length=200), nullable=False),
    sa.Column('attempts', sa.Integer(), nullable=False),
    sa.Column('next_attempt_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('request', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('response', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('sent_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('delivered_at', sa.DateTime(timezone=True), nullable=True),
    sa.Column('read_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("NOT is_dry_run OR status IN ('queued','dry_run','suppressed','blocked','cancelled')", name=op.f('ck_notification_messages_dry_run_never_sent')),
    sa.CheckConstraint("channel IN ('email','sms','push','in_app')", name=op.f('ck_notification_messages_channel_valid')),
    sa.CheckConstraint("status IN ('queued','dry_run','sent','delivered','bounced','complained','failed','suppressed','blocked','cancelled')", name=op.f('ck_notification_messages_status_valid')),
    sa.ForeignKeyConstraint(['campaign_id'], ['campaigns.id'], name=op.f('fk_notification_messages_campaign_id_campaigns')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_notification_messages_created_by_users')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_notification_messages_customer_id_customers')),
    sa.ForeignKeyConstraint(['provider_id'], ['notification_providers.id'], name=op.f('fk_notification_messages_provider_id_notification_providers')),
    sa.ForeignKeyConstraint(['template_id'], ['notification_templates.id'], name=op.f('fk_notification_messages_template_id_notification_templates')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_messages_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_messages')),
    sa.UniqueConstraint('tenant_id', 'idempotency_key', name='uq_notification_messages_idempotency')
    )
    with op.batch_alter_table('notification_messages', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_messages_campaign_id'), ['campaign_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_notification_messages_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index('ix_notification_messages_provider_ref', ['tenant_id', 'provider_message_id'], unique=False)
        batch_op.create_index('ix_notification_messages_recipient', ['tenant_id', 'channel', 'recipient_hash'], unique=False)
        batch_op.create_index(batch_op.f('ix_notification_messages_status'), ['status'], unique=False)
        batch_op.create_index(batch_op.f('ix_notification_messages_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_preferences',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('category', sa.String(length=20), nullable=False),
    sa.Column('allowed', sa.Boolean(), nullable=False),
    sa.Column('source', sa.String(length=60), nullable=True),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_notification_preferences_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_preferences_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_preferences')),
    sa.UniqueConstraint('customer_id', 'channel', 'category', name='uq_notification_preferences_identity')
    )
    with op.batch_alter_table('notification_preferences', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_preferences_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_notification_preferences_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_suppressions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('channel', sa.String(length=12), nullable=False),
    sa.Column('recipient_hash', sa.String(length=64), nullable=False),
    sa.Column('recipient_hint', sa.String(length=80), nullable=True),
    sa.Column('customer_id', sa.Integer(), nullable=True),
    sa.Column('reason', sa.String(length=30), nullable=False),
    sa.Column('source', sa.String(length=60), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('lifted_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("reason IN ('bounce','complaint','unsubscribe','manual','invalid')", name=op.f('ck_notification_suppressions_reason_valid')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_notification_suppressions_created_by_users')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_notification_suppressions_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_suppressions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_suppressions')),
    sa.UniqueConstraint('tenant_id', 'channel', 'recipient_hash', name='uq_notification_suppressions_identity')
    )
    with op.batch_alter_table('notification_suppressions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_suppressions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('identity_links',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('user_key', sa.String(length=64), nullable=False),
    sa.Column('source', sa.String(length=60), nullable=False),
    sa.Column('external_user_id', sa.String(length=200), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=True),
    sa.Column('account_id', sa.Integer(), nullable=True),
    sa.Column('crm_contact_id', sa.String(length=120), nullable=True),
    sa.Column('email_hash', sa.String(length=64), nullable=True),
    sa.Column('confidence', sa.Float(), nullable=False),
    sa.Column('match_rule', sa.String(length=40), nullable=False),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('valid_from', sa.DateTime(timezone=True), nullable=True),
    sa.Column('valid_to', sa.DateTime(timezone=True), nullable=True),
    sa.Column('merged_into', sa.String(length=64), nullable=True),
    sa.Column('note', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("status IN ('active','quarantined','merged','rejected')", name=op.f('ck_identity_links_status_valid')),
    sa.CheckConstraint('confidence >= 0 AND confidence <= 1', name=op.f('ck_identity_links_confidence_range')),
    sa.CheckConstraint('valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from', name=op.f('ck_identity_links_validity_ordered')),
    sa.ForeignKeyConstraint(['account_id'], ['accounts.id'], name=op.f('fk_identity_links_account_id_accounts')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_identity_links_created_by_users')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_identity_links_customer_id_customers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_identity_links_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_identity_links'))
    )
    with op.batch_alter_table('identity_links', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_identity_links_customer_id'), ['customer_id'], unique=False)
        batch_op.create_index('ix_identity_links_lookup', ['tenant_id', 'source', 'external_user_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_identity_links_tenant_id'), ['tenant_id'], unique=False)
        batch_op.create_index('ix_identity_links_user_key', ['tenant_id', 'user_key'], unique=False)

    op.create_table('model_stage_transitions',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('model_version_id', sa.Integer(), nullable=False),
    sa.Column('from_state', sa.String(length=20), nullable=False),
    sa.Column('to_state', sa.String(length=20), nullable=False),
    sa.Column('decision', sa.String(length=12), nullable=False),
    sa.Column('gates', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('registry_info', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('note', sa.Text(), nullable=True),
    sa.Column('actor_user_id', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("decision IN ('applied','blocked')", name=op.f('ck_model_stage_transitions_decision_valid')),
    sa.ForeignKeyConstraint(['actor_user_id'], ['users.id'], name=op.f('fk_model_stage_transitions_actor_user_id_users')),
    sa.ForeignKeyConstraint(['model_version_id'], ['model_versions.id'], name=op.f('fk_model_stage_transitions_model_version_id_model_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_model_stage_transitions_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_model_stage_transitions'))
    )
    with op.batch_alter_table('model_stage_transitions', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_model_stage_transitions_model_version_id'), ['model_version_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_model_stage_transitions_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('notification_events',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('provider_id', sa.Integer(), nullable=True),
    sa.Column('message_id', sa.Integer(), nullable=True),
    sa.Column('event_type', sa.String(length=30), nullable=False),
    sa.Column('event_key', sa.String(length=200), nullable=False),
    sa.Column('payload', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('received_at', sa.DateTime(timezone=True), nullable=False),
    sa.ForeignKeyConstraint(['message_id'], ['notification_messages.id'], name=op.f('fk_notification_events_message_id_notification_messages')),
    sa.ForeignKeyConstraint(['provider_id'], ['notification_providers.id'], name=op.f('fk_notification_events_provider_id_notification_providers')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_notification_events_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_notification_events')),
    sa.UniqueConstraint('tenant_id', 'provider_id', 'event_key', name='uq_notification_events_idempotency')
    )
    with op.batch_alter_table('notification_events', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_notification_events_message_id'), ['message_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_notification_events_tenant_id'), ['tenant_id'], unique=False)

    op.create_table('sentiment_scores',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('interaction_id', sa.Integer(), nullable=False),
    sa.Column('customer_id', sa.Integer(), nullable=False),
    sa.Column('sentiment_model_id', sa.Integer(), nullable=False),
    sa.Column('run_id', sa.Integer(), nullable=True),
    sa.Column('occurred_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('label', sa.String(length=12), nullable=False),
    sa.Column('confidence', sa.Float(), nullable=True),
    sa.Column('p_positive', sa.Float(), nullable=True),
    sa.Column('p_neutral', sa.Float(), nullable=True),
    sa.Column('p_negative', sa.Float(), nullable=True),
    sa.Column('score', sa.Float(), nullable=True),
    sa.Column('language', sa.String(length=12), nullable=True),
    sa.Column('language_confidence', sa.Float(), nullable=True),
    sa.Column('state', sa.String(length=30), nullable=False),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('flags', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('text_sha256', sa.String(length=64), nullable=True),
    sa.Column('text_chars', sa.Integer(), nullable=True),
    sa.Column('redactions', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('excerpt', sa.String(length=300), nullable=True),
    sa.Column('source_record_version', sa.Integer(), nullable=True),
    sa.Column('source_dataset_version_id', sa.Integer(), nullable=True),
    sa.Column('scored_at', sa.DateTime(timezone=True), nullable=False),
    sa.CheckConstraint("label IN ('positive','negative','neutral','mixed','uncertain')", name=op.f('ck_sentiment_scores_label_valid')),
    sa.CheckConstraint("state IN ('ok','empty','too_short','unsupported_language','language_undetermined','error')", name=op.f('ck_sentiment_scores_state_valid')),
    sa.CheckConstraint('confidence IS NULL OR (confidence >= 0 AND confidence <= 1)', name=op.f('ck_sentiment_scores_confidence_range')),
    sa.ForeignKeyConstraint(['customer_id'], ['customers.id'], name=op.f('fk_sentiment_scores_customer_id_customers')),
    sa.ForeignKeyConstraint(['interaction_id'], ['support_interactions.id'], name=op.f('fk_sentiment_scores_interaction_id_support_interactions')),
    sa.ForeignKeyConstraint(['run_id'], ['sentiment_runs.id'], name=op.f('fk_sentiment_scores_run_id_sentiment_runs')),
    sa.ForeignKeyConstraint(['sentiment_model_id'], ['sentiment_models.id'], name=op.f('fk_sentiment_scores_sentiment_model_id_sentiment_models')),
    sa.ForeignKeyConstraint(['source_dataset_version_id'], ['dataset_versions.id'], name=op.f('fk_sentiment_scores_source_dataset_version_id_dataset_versions')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_sentiment_scores_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_sentiment_scores')),
    sa.UniqueConstraint('interaction_id', 'sentiment_model_id', name='uq_sentiment_scores_interaction_model')
    )
    with op.batch_alter_table('sentiment_scores', schema=None) as batch_op:
        batch_op.create_index('ix_sentiment_scores_customer_time', ['tenant_id', 'customer_id', 'occurred_at'], unique=False)
        batch_op.create_index(batch_op.f('ix_sentiment_scores_interaction_id'), ['interaction_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sentiment_scores_sentiment_model_id'), ['sentiment_model_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sentiment_scores_tenant_id'), ['tenant_id'], unique=False)
        batch_op.create_index('ix_sentiment_scores_text', ['sentiment_model_id', 'text_sha256'], unique=False)

    op.create_table('reverse_etl_runs',
    sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
    sa.Column('tenant_id', sa.Integer(), nullable=False),
    sa.Column('sync_id', sa.Integer(), nullable=False),
    sa.Column('batch_id', sa.Integer(), nullable=True),
    sa.Column('job_id', sa.Integer(), nullable=True),
    sa.Column('status', sa.String(length=20), nullable=False),
    sa.Column('mode', sa.String(length=12), nullable=True),
    sa.Column('rows', sa.Integer(), nullable=False),
    sa.Column('counts', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('export_path', sa.String(length=500), nullable=True),
    sa.Column('export_sha256', sa.String(length=64), nullable=True),
    sa.Column('verification', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True),
    sa.Column('error', sa.Text(), nullable=True),
    sa.Column('created_by', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(timezone=True), nullable=False),
    sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
    sa.CheckConstraint("status IN ('pending','running','completed','failed')", name=op.f('ck_reverse_etl_runs_status_valid')),
    sa.ForeignKeyConstraint(['batch_id'], ['prediction_batches.id'], name=op.f('fk_reverse_etl_runs_batch_id_prediction_batches')),
    sa.ForeignKeyConstraint(['created_by'], ['users.id'], name=op.f('fk_reverse_etl_runs_created_by_users')),
    sa.ForeignKeyConstraint(['job_id'], ['jobs.id'], name=op.f('fk_reverse_etl_runs_job_id_jobs')),
    sa.ForeignKeyConstraint(['sync_id'], ['reverse_etl_syncs.id'], name=op.f('fk_reverse_etl_runs_sync_id_reverse_etl_syncs')),
    sa.ForeignKeyConstraint(['tenant_id'], ['tenants.id'], name=op.f('fk_reverse_etl_runs_tenant_id_tenants')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_reverse_etl_runs'))
    )
    with op.batch_alter_table('reverse_etl_runs', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_reverse_etl_runs_sync_id'), ['sync_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_reverse_etl_runs_tenant_id'), ['tenant_id'], unique=False)

    with op.batch_alter_table('auth_sessions', schema=None) as batch_op:
        batch_op.add_column(sa.Column('rotated_from', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('identity_provider_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('id_token_enc', sa.Text(), nullable=True))

    with op.batch_alter_table('campaigns', schema=None) as batch_op:
        batch_op.add_column(sa.Column('run_state', sa.String(length=20), server_default='idle', nullable=False))
        batch_op.add_column(sa.Column('dry_run', sa.Boolean(), server_default=sa.true(), nullable=False))
        batch_op.add_column(sa.Column('description', sa.Text(), nullable=True))
        batch_op.add_column(sa.Column('eligibility', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('schedule', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('cooldown_days', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('frequency_cap', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('ab_test', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('submitted_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('started_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('paused_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.create_check_constraint(batch_op.f('ck_campaigns_run_state_valid'), "run_state IN ('idle','scheduled','running','paused','cancelled','completed')")

    with op.batch_alter_table('crm_connections', schema=None) as batch_op:
        batch_op.add_column(sa.Column('auth_type', sa.String(length=12), server_default='token', nullable=False))
        batch_op.add_column(sa.Column('profile', sa.String(length=40), nullable=True))
        batch_op.add_column(sa.Column('client_id', sa.String(length=300), nullable=True))
        batch_op.add_column(sa.Column('client_secret_enc', sa.Text(), nullable=True))
        batch_op.add_column(sa.Column('refresh_token_enc', sa.Text(), nullable=True))
        batch_op.add_column(sa.Column('token_expires_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('scopes', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('oauth_endpoints', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('webhook_secret_enc', sa.Text(), nullable=True))
        batch_op.add_column(sa.Column('health', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.add_column(sa.Column('disconnected_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.create_check_constraint(batch_op.f('ck_crm_connections_auth_type_valid'), "auth_type IN ('token','oauth')")

    with op.batch_alter_table('crm_deliveries', schema=None) as batch_op:
        batch_op.add_column(sa.Column('sync_run_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('verified_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('verification', sa.JSON().with_variant(postgresql.JSONB(astext_type=sa.Text()), 'postgresql'), nullable=True))
        batch_op.create_index(batch_op.f('ix_crm_deliveries_sync_run_id'), ['sync_run_id'], unique=False)

    with op.batch_alter_table('customers', schema=None) as batch_op:
        batch_op.add_column(sa.Column('attributes_effective_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('phone', sa.String(length=40), nullable=True))

    with op.batch_alter_table('model_versions', schema=None) as batch_op:
        batch_op.add_column(sa.Column('lifecycle_state', sa.String(length=20), server_default='candidate', nullable=False))
        batch_op.add_column(sa.Column('validated_at', sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column('mlflow_registered_name', sa.String(length=250), nullable=True))
        batch_op.add_column(sa.Column('mlflow_run_id', sa.String(length=64), nullable=True))
        batch_op.create_check_constraint(batch_op.f('ck_model_versions_lifecycle_valid'), "lifecycle_state IN ('candidate','validated','approved','staging','production','archived','rejected')")

    with op.batch_alter_table('users', schema=None) as batch_op:
        batch_op.add_column(sa.Column('identity_provider_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('external_subject', sa.String(length=255), nullable=True))

    # Existing registry entries: the lifecycle state follows the stage and approval they already have.
    model_versions = sa.table("model_versions", sa.column("stage", sa.String), sa.column("approval_status", sa.String),
                              sa.column("lifecycle_state", sa.String))
    op.execute(model_versions.update().values(lifecycle_state=sa.case(
        (model_versions.c.stage == "production", "production"),
        (model_versions.c.stage == "staging", "staging"),
        (model_versions.c.stage == "archived", "archived"),
        (model_versions.c.approval_status == "rejected", "rejected"),
        (model_versions.c.approval_status == "approved", "approved"),
        else_="candidate")))


def downgrade() -> None:
    with op.batch_alter_table('users', schema=None) as batch_op:
        batch_op.drop_column('external_subject')
        batch_op.drop_column('identity_provider_id')

    with op.batch_alter_table('model_versions', schema=None) as batch_op:
        batch_op.drop_constraint(batch_op.f('ck_model_versions_lifecycle_valid'), type_='check')
        batch_op.drop_column('mlflow_run_id')
        batch_op.drop_column('mlflow_registered_name')
        batch_op.drop_column('validated_at')
        batch_op.drop_column('lifecycle_state')

    with op.batch_alter_table('customers', schema=None) as batch_op:
        batch_op.drop_column('phone')
        batch_op.drop_column('attributes_effective_at')

    with op.batch_alter_table('crm_deliveries', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_deliveries_sync_run_id'))
        batch_op.drop_column('verification')
        batch_op.drop_column('verified_at')
        batch_op.drop_column('sync_run_id')

    with op.batch_alter_table('crm_connections', schema=None) as batch_op:
        batch_op.drop_constraint(batch_op.f('ck_crm_connections_auth_type_valid'), type_='check')
        batch_op.drop_column('disconnected_at')
        batch_op.drop_column('health')
        batch_op.drop_column('webhook_secret_enc')
        batch_op.drop_column('oauth_endpoints')
        batch_op.drop_column('scopes')
        batch_op.drop_column('token_expires_at')
        batch_op.drop_column('refresh_token_enc')
        batch_op.drop_column('client_secret_enc')
        batch_op.drop_column('client_id')
        batch_op.drop_column('profile')
        batch_op.drop_column('auth_type')

    with op.batch_alter_table('campaigns', schema=None) as batch_op:
        batch_op.drop_constraint(batch_op.f('ck_campaigns_run_state_valid'), type_='check')
        batch_op.drop_column('finished_at')
        batch_op.drop_column('paused_at')
        batch_op.drop_column('started_at')
        batch_op.drop_column('submitted_at')
        batch_op.drop_column('ab_test')
        batch_op.drop_column('frequency_cap')
        batch_op.drop_column('cooldown_days')
        batch_op.drop_column('schedule')
        batch_op.drop_column('eligibility')
        batch_op.drop_column('description')
        batch_op.drop_column('dry_run')
        batch_op.drop_column('run_state')

    with op.batch_alter_table('auth_sessions', schema=None) as batch_op:
        batch_op.drop_column('id_token_enc')
        batch_op.drop_column('identity_provider_id')
        batch_op.drop_column('rotated_from')

    with op.batch_alter_table('reverse_etl_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_reverse_etl_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_reverse_etl_runs_sync_id'))

    op.drop_table('reverse_etl_runs')
    with op.batch_alter_table('sentiment_scores', schema=None) as batch_op:
        batch_op.drop_index('ix_sentiment_scores_text')
        batch_op.drop_index(batch_op.f('ix_sentiment_scores_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_sentiment_scores_sentiment_model_id'))
        batch_op.drop_index(batch_op.f('ix_sentiment_scores_interaction_id'))
        batch_op.drop_index('ix_sentiment_scores_customer_time')

    op.drop_table('sentiment_scores')
    with op.batch_alter_table('notification_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_events_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_notification_events_message_id'))

    op.drop_table('notification_events')
    with op.batch_alter_table('model_stage_transitions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_model_stage_transitions_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_model_stage_transitions_model_version_id'))

    op.drop_table('model_stage_transitions')
    with op.batch_alter_table('identity_links', schema=None) as batch_op:
        batch_op.drop_index('ix_identity_links_user_key')
        batch_op.drop_index(batch_op.f('ix_identity_links_tenant_id'))
        batch_op.drop_index('ix_identity_links_lookup')
        batch_op.drop_index(batch_op.f('ix_identity_links_customer_id'))

    op.drop_table('identity_links')
    with op.batch_alter_table('notification_suppressions', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_suppressions_tenant_id'))

    op.drop_table('notification_suppressions')
    with op.batch_alter_table('notification_preferences', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_preferences_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_notification_preferences_customer_id'))

    op.drop_table('notification_preferences')
    with op.batch_alter_table('notification_messages', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_messages_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_notification_messages_status'))
        batch_op.drop_index('ix_notification_messages_recipient')
        batch_op.drop_index('ix_notification_messages_provider_ref')
        batch_op.drop_index(batch_op.f('ix_notification_messages_customer_id'))
        batch_op.drop_index(batch_op.f('ix_notification_messages_campaign_id'))

    op.drop_table('notification_messages')
    with op.batch_alter_table('customer_attribute_history', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_customer_attribute_history_tenant_id'))
        batch_op.drop_index('ix_customer_attribute_history_lookup')
        batch_op.drop_index(batch_op.f('ix_customer_attribute_history_customer_id'))

    op.drop_table('customer_attribute_history')
    with op.batch_alter_table('campaign_enrollments', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_campaign_enrollments_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_campaign_enrollments_status'))
        batch_op.drop_index(batch_op.f('ix_campaign_enrollments_customer_id'))
        batch_op.drop_index(batch_op.f('ix_campaign_enrollments_campaign_id'))

    op.drop_table('campaign_enrollments')
    with op.batch_alter_table('adoption_facts', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_adoption_facts_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_adoption_facts_run_id'))
        batch_op.drop_index(batch_op.f('ix_adoption_facts_customer_id'))

    op.drop_table('adoption_facts')
    with op.batch_alter_table('sentiment_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_sentiment_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_sentiment_runs_sentiment_model_id'))

    op.drop_table('sentiment_runs')
    with op.batch_alter_table('sentiment_evaluations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_sentiment_evaluations_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_sentiment_evaluations_sentiment_model_id'))

    op.drop_table('sentiment_evaluations')
    with op.batch_alter_table('reverse_etl_syncs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_reverse_etl_syncs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_reverse_etl_syncs_connection_id'))

    op.drop_table('reverse_etl_syncs')
    with op.batch_alter_table('oidc_login_states', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_oidc_login_states_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_oidc_login_states_provider_id'))

    op.drop_table('oidc_login_states')
    with op.batch_alter_table('identity_reconciliations', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_identity_reconciliations_tenant_id'))

    op.drop_table('identity_reconciliations')
    with op.batch_alter_table('crm_webhook_events', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_webhook_events_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_crm_webhook_events_status'))
        batch_op.drop_index(batch_op.f('ix_crm_webhook_events_connection_id'))

    op.drop_table('crm_webhook_events')
    with op.batch_alter_table('crm_oauth_states', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_crm_oauth_states_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_crm_oauth_states_connection_id'))

    op.drop_table('crm_oauth_states')
    with op.batch_alter_table('campaign_steps', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_campaign_steps_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_campaign_steps_campaign_id'))

    op.drop_table('campaign_steps')
    with op.batch_alter_table('adoption_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_adoption_runs_tenant_id'))

    op.drop_table('adoption_runs')
    with op.batch_alter_table('sentiment_models', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_sentiment_models_tenant_id'))

    op.drop_table('sentiment_models')
    with op.batch_alter_table('product_features', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_product_features_tenant_id'))

    op.drop_table('product_features')
    with op.batch_alter_table('notification_templates', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_templates_tenant_id'))

    op.drop_table('notification_templates')
    with op.batch_alter_table('notification_providers', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_notification_providers_tenant_id'))

    op.drop_table('notification_providers')
    with op.batch_alter_table('identity_providers', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_identity_providers_tenant_id'))

    op.drop_table('identity_providers')
    with op.batch_alter_table('identity_merge_candidates', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_identity_merge_candidates_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_identity_merge_candidates_status'))

    op.drop_table('identity_merge_candidates')
    with op.batch_alter_table('orchestrator_runs', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_orchestrator_runs_tenant_id'))
        batch_op.drop_index(batch_op.f('ix_orchestrator_runs_status'))

    op.drop_table('orchestrator_runs')
    with op.batch_alter_table('rate_limit_counters', schema=None) as batch_op:
        batch_op.drop_index('ix_rate_limit_counters_window')

    op.drop_table('rate_limit_counters')
