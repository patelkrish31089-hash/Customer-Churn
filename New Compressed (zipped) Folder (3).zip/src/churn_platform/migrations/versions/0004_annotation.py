"""1.2.0: people label support text, so that sentiment accuracy can be measured on something other than templates.

Three tables: a batch of support interactions handed out for labelling, one row per text in the batch, and one row
per label.  A batch freezes once every text carries two independent labels and every disagreement has been
adjudicated; only a frozen batch may be exported for evaluation, so the accuracy `sentiment.evaluate` reports
cannot belong to a set that was edited after the numbers were seen.

Revision ID: 0004
Revises: 0003
Create Date: 2026-11-12
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "sentiment_annotation_batches",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("is_synthetic", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("language", sa.String(12), nullable=True),
        sa.Column("status", sa.String(12), nullable=False, server_default="open"),
        sa.Column("rows", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("frozen_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("tenant_id", "name", name="uq_sentiment_annotation_batches_tenant_name"),
        sa.CheckConstraint("status IN ('open','frozen')", name="ck_sentiment_annotation_batches_status"),
    )
    op.create_table(
        "sentiment_annotation_items",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("batch_id", sa.Integer(), sa.ForeignKey("sentiment_annotation_batches.id"), nullable=False, index=True),
        sa.Column("interaction_id", sa.Integer(), sa.ForeignKey("support_interactions.id"), nullable=False),
        sa.Column("text_sha256", sa.String(64), nullable=False),
        sa.Column("final_label", sa.String(12), nullable=True),
        sa.Column("decided_by", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("decided_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("batch_id", "interaction_id", name="uq_sentiment_annotation_items_batch_interaction"),
    )
    op.create_table(
        "sentiment_annotations",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.Integer(), sa.ForeignKey("tenants.id"), nullable=False, index=True),
        sa.Column("batch_id", sa.Integer(), sa.ForeignKey("sentiment_annotation_batches.id"), nullable=False, index=True),
        sa.Column("item_id", sa.Integer(), sa.ForeignKey("sentiment_annotation_items.id"), nullable=False, index=True),
        sa.Column("annotator_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False, index=True),
        sa.Column("label", sa.String(12), nullable=False),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.UniqueConstraint("item_id", "annotator_id", name="uq_sentiment_annotations_item_annotator"),
        sa.CheckConstraint("label IN ('positive','negative','neutral','mixed')", name="ck_sentiment_annotations_label"),
    )


def downgrade() -> None:
    op.drop_table("sentiment_annotations")
    op.drop_table("sentiment_annotation_items")
    op.drop_table("sentiment_annotation_batches")
