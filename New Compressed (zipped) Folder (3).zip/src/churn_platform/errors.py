"""Application errors: every failure reaches the client as one consistent JSON envelope."""

from __future__ import annotations

from typing import Any


class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, *, details: Any = None, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details
        if code:
            self.code = code


class BadRequest(AppError):
    status_code, code = 400, "bad_request"


class Unauthorized(AppError):
    status_code, code = 401, "unauthorized"


class Forbidden(AppError):
    status_code, code = 403, "forbidden"


class NotFound(AppError):
    status_code, code = 404, "not_found"


class Conflict(AppError):
    status_code, code = 409, "conflict"


class PayloadTooLarge(AppError):
    status_code, code = 413, "payload_too_large"


class ValidationFailed(AppError):
    status_code, code = 422, "validation_failed"


class RateLimited(AppError):
    status_code, code = 429, "rate_limited"


class ExternalServiceError(AppError):
    status_code, code = 502, "external_service_error"


class ServiceUnavailable(AppError):
    status_code, code = 503, "service_unavailable"
