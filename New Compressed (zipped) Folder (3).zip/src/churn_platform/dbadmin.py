"""Schema administration: Alembic migrations and a drift check, usable from an installed package."""

from __future__ import annotations

from importlib import resources
from typing import Any

from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from alembic.script import ScriptDirectory

from .config import get_settings
from .db import Base, make_engine


def alembic_config(url: str | None = None) -> Config:
    cfg = Config()
    cfg.set_main_option("script_location", str(resources.files("churn_platform") / "migrations"))
    cfg.set_main_option("sqlalchemy.url", (url or get_settings().database_url).replace("%", "%%"))
    return cfg


def upgrade(revision: str = "head", url: str | None = None) -> None:
    get_settings().ensure_dirs()
    command.upgrade(alembic_config(url), revision)


def downgrade(revision: str, url: str | None = None) -> None:
    command.downgrade(alembic_config(url), revision)


def _database(url: str | None) -> str:
    """The database to look at.  For the configured one its directory is created first: SQLite cannot open a file in a
    directory that does not exist, and the first command in a fresh checkout (``seed-demo``, ``db-status``) asks for
    the revision before anything else has created ``./var``."""
    if url is not None:
        return url
    settings = get_settings()
    settings.ensure_dirs()
    return settings.database_url


def current_revision(url: str | None = None) -> str | None:
    engine = make_engine(_database(url))
    try:
        with engine.connect() as conn:
            return MigrationContext.configure(conn).get_current_revision()
    finally:
        engine.dispose()


def head_revision() -> str | None:
    return ScriptDirectory.from_config(alembic_config()).get_current_head()


def schema_drift(url: str | None = None) -> list[Any]:
    """Differences between the migrated database and the ORM models (empty list = in sync)."""
    from . import models  # noqa: F401

    engine = make_engine(_database(url))
    try:
        with engine.connect() as conn:
            ctx = MigrationContext.configure(conn, opts={"compare_type": True, "render_as_batch": engine.dialect.name == "sqlite"})
            return list(compare_metadata(ctx, Base.metadata))
    finally:
        engine.dispose()


def status(url: str | None = None) -> dict:
    current, head = current_revision(url), head_revision()
    return {"current": current, "head": head, "up_to_date": current == head and head is not None}
