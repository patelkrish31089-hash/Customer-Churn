"""Outbound HTTP guard against server-side request forgery (SSRF).

Tenant administrators configure the URLs the platform calls (REST sources, CRM connections), so
every outbound request is vetted: only absolute http(s) URLs without embedded credentials whose
host resolves exclusively to globally routable addresses are allowed.

Checking a name and then letting the HTTP client resolve it again would leave a gap (DNS
rebinding: public address during the check, internal address for the request).  ``vet`` therefore
returns a ``Target`` pinned to the address it has just checked: the request is sent to that IP
while the ``Host`` header and the TLS server name (certificate check) keep the original host.
"""

from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass, field
from urllib.parse import urlsplit, urlunsplit

from .config import get_settings
from .errors import ValidationFailed


@dataclass(frozen=True)
class Target:
    """How to send one vetted request: pass ``url``, merge ``headers`` last, pass ``extensions``."""

    url: str
    host: str
    headers: dict[str, str] = field(default_factory=dict)
    extensions: dict[str, str] = field(default_factory=dict)
    address: str | None = None  # the vetted IP the request is pinned to (None: not pinned)


def _refuse(message: str, field_name: str, reason: str) -> ValidationFailed:
    return ValidationFailed(message, details={"field": field_name, "reason": reason})


def is_public(address: str) -> bool:
    """True only for globally routable unicast addresses (no private, loopback, link-local, CGNAT ...)."""
    ip = ipaddress.ip_address(address.split("%", 1)[0])
    if ip.version == 6 and ip.ipv4_mapped is not None:
        ip = ip.ipv4_mapped  # ::ffff:127.0.0.1 is 127.0.0.1
    return bool(ip.is_global and not ip.is_multicast)


def vet_host(host: str, port: int | None, *, allow_private: bool = False, field_name: str = "host") -> tuple[str, str]:
    """Check a bare host (no URL) the way ``vet`` checks a URL: every address must be public.

    Used by the mail-server provider, whose protocol has no URL.  Returns the host to connect to
    and the address the name resolved to; with ``allow_private`` the name is returned unchecked,
    which is what a relay on the same machine needs.
    """
    if not host or any(ch in host for ch in " /\\@"):
        raise _refuse("the host must be a plain host name or IP address", field_name, "invalid")
    if allow_private:
        return host, host
    try:
        infos = socket.getaddrinfo(host, port or 25, type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError) as exc:
        raise _refuse(f"cannot resolve host '{host}'", field_name, "unresolvable") from exc
    addresses = list(dict.fromkeys(info[4][0] for info in infos))
    if not addresses:
        raise _refuse(f"cannot resolve host '{host}'", field_name, "unresolvable")
    if not all(is_public(address) for address in addresses):
        raise _refuse("the mail server resolves to a non-public address, which is not allowed", field_name, "non_public")
    return host, addresses[0].split("%", 1)[0]


def vet(url: str, *, allow_private: bool = False, field_name: str = "url", resolve: bool = True) -> Target:
    """Validate ``url`` and return the pinned request target.

    ``allow_private`` (development / explicitly trusted networks) skips the address check and the
    pinning; ``resolve=False`` checks the syntax only (for URLs that are stored but never called).
    """
    try:
        parts = urlsplit(url)
        host, port = parts.hostname, parts.port
    except ValueError as exc:
        raise _refuse("URL must be an absolute http(s) URL", field_name, "invalid") from exc
    if parts.scheme not in ("http", "https") or not host:
        raise _refuse("URL must be an absolute http(s) URL", field_name, "invalid")
    if parts.username is not None or parts.password is not None:
        raise _refuse("URL must not contain credentials; configure them as a secret instead", field_name, "invalid")
    if get_settings().is_production_like and parts.scheme != "https":
        raise _refuse("only https URLs are allowed in this environment", field_name, "invalid")
    if allow_private or not resolve:
        return Target(url=url, host=host)
    try:
        infos = socket.getaddrinfo(host, port or (443 if parts.scheme == "https" else 80), type=socket.SOCK_STREAM)
    except (socket.gaierror, UnicodeError) as exc:
        raise _refuse(f"cannot resolve host '{host}'", field_name, "unresolvable") from exc
    addresses = list(dict.fromkeys(info[4][0] for info in infos))
    if not addresses:
        raise _refuse(f"cannot resolve host '{host}'", field_name, "unresolvable")
    if not all(is_public(address) for address in addresses):
        raise _refuse("URL resolves to a non-public address, which is not allowed", field_name, "non_public")
    address = addresses[0].split("%", 1)[0]
    try:
        ipaddress.ip_address(host)
        return Target(url=url, host=host, address=address)  # already an IP literal: nothing to pin
    except ValueError:
        pass
    literal = f"[{address}]" if ":" in address else address
    suffix = f":{port}" if port else ""
    pinned = urlunsplit((parts.scheme, literal + suffix, parts.path, parts.query, parts.fragment))
    server_name = host.encode("idna").decode("ascii")
    return Target(url=pinned, host=host, headers={"Host": server_name + suffix}, extensions={"sni_hostname": server_name}, address=address)
