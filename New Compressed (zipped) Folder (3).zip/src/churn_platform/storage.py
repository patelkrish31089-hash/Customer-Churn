"""Locations of files the platform owns (raw imports, datasets, model artefacts).

Paths are stored in the database RELATIVE to ``CHURN_DATA_DIR`` so that the data directory can be
moved, restored from a backup or mounted at a different place without rewriting rows.
"""

from __future__ import annotations

from pathlib import Path

from .config import get_settings


def data_root() -> Path:
    return get_settings().data_dir.resolve()


def to_stored(path: Path | str) -> str:
    """The value to persist for a file or directory inside the data directory."""
    absolute = Path(path).resolve()
    try:
        return absolute.relative_to(data_root()).as_posix()
    except ValueError as exc:
        raise ValueError(f"{absolute} is outside the data directory {data_root()}") from exc


def resolve(stored: str | None) -> Path:
    """Absolute location of a stored path; refuses anything that escapes the data directory."""
    if not stored:
        raise FileNotFoundError("no storage location recorded")
    root = data_root()
    candidate = (root / stored).resolve()
    if candidate != root and root not in candidate.parents:
        raise ValueError("stored path escapes the data directory")
    return candidate
