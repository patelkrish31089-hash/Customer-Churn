"""Deterministic SYNTHETIC subscription-business data generator.

Everything produced here is artificial.  It exists so the platform can be installed, demonstrated
and tested end to end without any real customer data; results obtained on it say nothing about a
real business.  The generator plants realistic structure (usage decay before voluntary churn,
payment failures before involuntary churn, noisy false alarms, reactivations) and a small, exactly
known number of data defects so that quarantine and data-quality features can be verified.
"""

from __future__ import annotations

import csv
import json
import zlib
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np

from . import synthetic_text

INDUSTRIES = ["software", "retail", "healthcare", "finance", "education", "manufacturing"]
CHANNELS = ["organic", "paid_search", "partner", "outbound", "referral"]
COUNTRIES = [("US", "amer"), ("CA", "amer"), ("GB", "emea"), ("DE", "emea"), ("FR", "emea"), ("IN", "apac"), ("AU", "apac")]
FEATURES = ["dashboards", "reports", "integrations", "automation", "exports", "collaboration"]
TICKET_CATEGORIES = ["billing", "bug", "how_to", "performance", "integration"]
PLANS = [
    ("basic_monthly", "Basic", "basic", "monthly", 49), ("basic_annual", "Basic", "basic", "annual", 490),
    ("pro_monthly", "Pro", "pro", "monthly", 149), ("pro_annual", "Pro", "pro", "annual", 1490),
    ("ent_monthly", "Enterprise", "enterprise", "monthly", 499), ("ent_annual", "Enterprise", "enterprise", "annual", 4990),
]  # fmt: skip
_NEG = ["frustrated with repeated errors", "still broken and unacceptable", "slow and unreliable again",
        "disappointed, considering alternatives", "the export keeps failing"]  # fmt: skip
_NEU = ["how do I configure this", "question about the invoice", "need help with setup", "requesting a feature walkthrough"]
_POS = ["thanks, great support", "works well now, appreciate the help", "love the new dashboard"]

# file name, format and column mapping (canonical field -> source column) for every entity
FILES: dict[str, tuple[str, dict[str, str]]] = {
    "customers": ("customers.csv", {"external_id": "customer_id", "name": "company", "email": "email", "industry": "industry",
                                    "company_size": "segment", "employee_count": "employees", "country": "country",
                                    "region": "region", "acquisition_channel": "channel", "acquisition_campaign": "campaign",
                                    "acquired_at": "signup_date", "consent_marketing": "marketing_opt_in", "phone": "phone"}),
    "plans": ("plans.tsv", {"external_id": "plan_code", "name": "plan_name", "product": "product", "tier": "tier",
                            "billing_period": "billing_period", "list_price": "list_price", "currency": "currency"}),
    "accounts": ("accounts.json", {"external_id": "account_id", "customer_external_id": "customer_id", "status": "status",
                                   "currency": "currency", "billing_email": "billing_email",
                                   "payment_method_type": "payment_method", "payment_method_expires_on": "card_expiry",
                                   "csm_owner": "csm", "opened_at": "opened_at"}),
    "subscriptions": ("subscriptions.xlsx", {"external_id": "subscription_id", "customer_external_id": "customer_id",
                                             "account_external_id": "account_id", "plan_external_id": "plan_code",
                                             "status": "status", "billing_period": "billing_period", "started_at": "start_date",
                                             "trial_end_at": "trial_end", "current_period_end": "period_end",
                                             "cancel_requested_at": "cancel_requested", "ended_at": "end_date",
                                             "end_reason": "end_reason", "mrr": "mrr", "discount_pct": "discount_pct",
                                             "auto_renew": "auto_renew", "quantity": "seats"}),
    "subscription_events": ("subscription_events.jsonl", {"external_id": "event_id", "subscription_external_id": "subscription_id",
                                                          "event_type": "event", "occurred_at": "timestamp",
                                                          "plan_external_id": "plan_code", "mrr": "mrr", "reason": "reason"}),
    "invoices": ("invoices.parquet", {"external_id": "invoice_id", "customer_external_id": "customer_id",
                                      "subscription_external_id": "subscription_id", "issued_at": "invoice_date",
                                      "due_at": "due_date", "paid_at": "paid_date", "amount": "amount",
                                      "discount_amount": "discount", "currency": "currency", "status": "status"}),
    "payments": ("payments.csv", {"external_id": "payment_id", "customer_external_id": "customer_id",
                                  "invoice_external_id": "invoice_id", "attempted_at": "payment_date", "amount": "amount",
                                  "status": "status", "failure_reason": "failure_reason", "method": "method"}),
    "usage_events": ("usage_events.parquet", {"customer_external_id": "customer_id", "occurred_at": "timestamp",
                                              "event_type": "event", "feature_name": "feature",
                                              "duration_seconds": "duration_seconds", "quantity": "count", "user_ref": "user"}),
    "support_interactions": ("support_tickets.txt", {"external_id": "ticket_id", "customer_external_id": "customer_id",
                                                     "kind": "kind", "opened_at": "created_at",
                                                     "first_response_at": "first_response_at", "resolved_at": "resolved_at",
                                                     "priority": "priority", "status": "status", "escalated": "escalated",
                                                     "category": "category", "channel": "channel", "csat": "csat",
                                                     "nps_score": "nps", "body": "message"}),
    "acquisitions": ("acquisitions.csv", {"external_id": "acquisition_id", "customer_external_id": "customer_id",
                                          "channel": "channel", "campaign": "campaign", "acquired_at": "acquired_at", "cac": "cac"}),
}  # fmt: skip


# A second file for the customers entity: later values of slowly changing attributes, with the date they took effect.
CHANGE_FILE: tuple[str, dict[str, str]] = ("customer_changes.csv", {"external_id": "customer_id", "company_size": "segment",
                                                                    "employee_count": "employees", "attributes_effective_at": "effective_date"})  # fmt: skip
# Product features only some plan tiers include, the feature that was released part-way through the history, the
# old telemetry name that no catalogue entry maps, and the staff domain whose users are not customers' people.
TIER_GATED = {"automation": ("pro", "enterprise"), "integrations": ("pro", "enterprise")}
LATE_FEATURE, LATE_FEATURE_AT = "collaboration", 0.4
LEGACY_NAME = "legacy_export"
STAFF_DOMAIN = "synthetic-vendor.example"

FUTURE_DAY = date(2099, 12, 31)  # the planted "timestamp in the future" row (always in the future, on any run date)


@dataclass
class SyntheticData:
    tables: dict[str, list[dict]]
    cutoff: datetime
    expected: dict[str, Any] = field(default_factory=dict)  # exactly-known planted defects and outcome counts


def _iso(ts: datetime | None) -> str | None:
    return None if ts is None else ts.strftime("%Y-%m-%dT%H:%M:%SZ")


def _user(customer: str, when: datetime, what: str, pool: int) -> str | None:
    """One of the customer's end users, picked by a stable hash: no random draw, so the seeded stream stays as it was.

    The identifiers deliberately show what real telemetry shows (each case decided by a stable hash of the customer
    or the event): some customers name users by e-mail address, some of those sometimes send only the local part,
    upper-case variants occur, a few customers send no user at all or only for a minority of events, and a few
    events were made by the vendor's own staff.
    """
    roll = zlib.crc32(f"{customer}|{when.isoformat()}|{what}".encode())
    kind = zlib.crc32(f"{customer}|identity".encode()) % 100
    if kind < 6 or (kind < 12 and roll % 10 < 7):  # no user identifiers at all / only on a minority of events
        return None
    number = roll % pool + 1
    if (roll >> 8) % 41 == 0:
        return f"staff.{number % 3 + 1}@{STAFF_DOMAIN}"
    if kind >= 70:  # e-mail identifiers, sometimes only the local part
        ref = f"user{number:02d}" if (roll >> 4) % 6 == 0 else f"user{number:02d}@{customer.lower()}.example"
    else:
        ref = f"u{number:02d}"
    return ref.upper() if (roll >> 12) % 9 == 0 else ref


def _at(day: date, seconds: int) -> datetime:
    return datetime(day.year, day.month, day.day, tzinfo=UTC) + timedelta(seconds=int(seconds))


def generate(n_customers: int = 1200, months: int = 15, seed: int = 42, end_date: date | None = None,
             inject_issues: bool = True, usage_density: float = 1.0) -> SyntheticData:
    """Simulate ``n_customers`` subscription customers over ``months`` months ending at ``end_date``."""
    rng = np.random.default_rng(seed)
    end_day = end_date or datetime.now(UTC).date() - timedelta(days=1)
    start_day = end_day - timedelta(days=int(months * 30.4))
    cutoff = _at(end_day, 86399)
    horizon_days = (end_day - start_day).days
    t: dict[str, list[dict]] = {k: [] for k in FILES}
    t["customer_changes"] = []
    late_feature_day = start_day + timedelta(days=int(horizon_days * LATE_FEATURE_AT))
    stats = {"voluntary_churn": 0, "involuntary_churn": 0, "trial_expired": 0, "reactivated": 0}
    for code, name, tier, period, price in PLANS:
        t["plans"].append({"plan_code": code, "plan_name": f"{name} ({period})", "product": "Platform", "tier": tier,
                           "billing_period": period, "list_price": f"{price:.2f}", "currency": "USD"})  # fmt: skip
    ev_seq = inv_seq = pay_seq = tic_seq = 0

    for n in range(1, n_customers + 1):
        cid = f"C{n:06d}"
        signup_offset = int(rng.integers(0, max(1, horizon_days - 25)))
        signup = start_day + timedelta(days=signup_offset)
        size = rng.choice(["smb", "mid_market", "enterprise"], p=[0.6, 0.3, 0.1])
        tier = {"smb": rng.choice(["basic", "pro"], p=[0.7, 0.3]), "mid_market": rng.choice(["basic", "pro", "enterprise"], p=[0.2, 0.6, 0.2]),
                "enterprise": rng.choice(["pro", "enterprise"], p=[0.3, 0.7])}[size]  # fmt: skip
        annual = rng.random() < {"basic": 0.2, "pro": 0.4, "enterprise": 0.6}[tier]
        plan = next(p for p in PLANS if p[2] == tier and p[3] == ("annual" if annual else "monthly"))
        channel = str(rng.choice(CHANNELS, p=[0.3, 0.25, 0.15, 0.15, 0.15]))
        country, region = COUNTRIES[int(rng.integers(0, len(COUNTRIES)))]
        eng = float(rng.beta(2.2, 2.0))
        employees = int({"smb": rng.integers(3, 50), "mid_market": rng.integers(50, 500), "enterprise": rng.integers(500, 8000)}[size])
        seats = max(1, int(employees * rng.uniform(0.05, 0.3)))
        discount = float(rng.choice([0, 0, 0, 10, 15, 20]))
        monthly_price = plan[4] / (12 if annual else 1)
        mrr = round(monthly_price * (1 - discount / 100), 2)
        sub_id, acc_id = f"S{n:06d}", f"A{n:06d}"
        has_trial = rng.random() < 0.2
        trial_end = signup + timedelta(days=14) if has_trial else None
        tenure_days = (end_day - signup).days

        # ---- outcome: when (if ever) does the subscription end, and why?
        end_day_c: date | None = None
        reason = None
        if has_trial and rng.random() < 0.15 and tenure_days > 14:
            end_day_c, reason = trial_end, "trial_expired"
        paid_start = trial_end if has_trial else signup
        card_expiry = signup + timedelta(days=int(rng.integers(40, 900)))
        card_expiry = date(card_expiry.year, card_expiry.month, 28)
        billing_days: list[date] = []
        d = paid_start
        while d <= end_day:
            billing_days.append(d)
            d = d + timedelta(days=365 if annual else 30)
        vol_logit = -4.35 + 1.5 * (1 - eng) + (0.45 if tier == "basic" else 0.0) - (0.5 if annual else 0.0) \
            + (0.35 if channel == "paid_search" else 0.0) + float(rng.normal(0, 0.35))  # fmt: skip
        monthly_hazard = 1 / (1 + np.exp(-vol_logit))
        failed_cycle: date | None = None
        if reason is None:
            month = 1
            while paid_start + timedelta(days=30 * month) <= end_day:
                if rng.random() < monthly_hazard * (1.6 if month <= 3 else 1.0):
                    end_day_c = paid_start + timedelta(days=30 * month - int(rng.integers(0, 30)))
                    reason = "cancellation" if rng.random() < 0.75 else "non_renewal"
                    break
                month += 1
            for bday in billing_days[1:]:
                if end_day_c is not None and bday >= end_day_c:
                    break
                p_fail = 0.5 if bday > card_expiry and bday - card_expiry < timedelta(days=45) else 0.012
                if rng.random() < p_fail and rng.random() < 0.45:  # failure that is never recovered
                    if bday + timedelta(days=14) <= end_day:
                        end_day_c, reason, failed_cycle = bday + timedelta(days=14), "payment_failure", bday
                    break
        if end_day_c is not None and end_day_c <= signup:
            end_day_c = signup + timedelta(days=1)
        if end_day_c is not None and end_day_c > end_day:
            end_day_c, reason, failed_cycle = None, None, None
        reactivate_day: date | None = None
        if end_day_c is not None and reason in ("cancellation", "non_renewal") and rng.random() < 0.1:
            candidate = end_day_c + timedelta(days=int(rng.integers(12, 80)))
            if candidate < end_day - timedelta(days=5):
                reactivate_day = candidate
                stats["reactivated"] += 1
        if reason in ("cancellation", "non_renewal"):
            stats["voluntary_churn"] += 1
        elif reason == "payment_failure":
            stats["involuntary_churn"] += 1
        elif reason == "trial_expired":
            stats["trial_expired"] += 1

        # ---- behavioural multipliers by day (decay before voluntary churn, dips that recover)
        n_days = tenure_days + 1
        mult = np.ones(n_days)
        friction = np.zeros(n_days)
        if reason in ("cancellation", "non_renewal") and rng.random() < 0.82:
            decline = int(rng.integers(20, 76))
            e = (end_day_c - signup).days
            s0 = max(0, e - decline)
            floor = float(rng.uniform(0.05, 0.3))
            mult[s0 : e + 1] = np.linspace(1.0, floor, e + 1 - s0)
            friction[s0 : e + 1] = 1.0
        elif reason is None and rng.random() < 0.18 and n_days > 60:  # false alarm: temporary dip
            s0 = int(rng.integers(20, n_days - 35))
            mult[s0 : s0 + 30] = float(rng.uniform(0.3, 0.6))
            friction[s0 : s0 + 30] = float(rng.random() < 0.4)
        active_until = (end_day_c - signup).days if end_day_c is not None else n_days - 1
        active_mask = np.zeros(n_days, dtype=bool)
        active_mask[: active_until + 1] = True
        if reactivate_day is not None:
            active_mask[(reactivate_day - signup).days :] = True
            mult[(reactivate_day - signup).days :] = 1.0

        # ---- usage (each row names one of up to a dozen end users of the account)
        user_pool = max(1, min(seats, 12))
        weekday = np.array([(signup + timedelta(days=int(k))).weekday() < 5 for k in range(n_days)])
        p_day = np.clip((0.12 + 0.75 * eng) * mult * np.where(weekday, 1.0, 0.35), 0, 0.97)
        is_active = (rng.random(n_days) < p_day) & active_mask
        for k in np.flatnonzero(is_active):
            day = signup + timedelta(days=int(k))
            logins = 1 + int(rng.poisson(1.2 * eng * mult[k] * max(1, min(seats, 20)) ** 0.4 * usage_density))
            minutes = float(rng.gamma(2.0, 9.0 * (0.5 + eng))) * logins
            ts = _at(day, int(rng.integers(6 * 3600, 20 * 3600)))
            t["usage_events"].append({"customer_id": cid, "timestamp": ts, "event": "login", "feature": None,
                                      "duration_seconds": round(minutes * 60, 1), "count": logins,
                                      "user": _user(cid, ts, "login", user_pool)})  # fmt: skip
            n_feat = int(min(len(FEATURES), rng.poisson(1.1 * (0.4 + eng) * mult[k] * usage_density)))
            for feat in rng.choice(FEATURES, size=n_feat, replace=False):
                row = {"customer_id": cid, "timestamp": ts + timedelta(minutes=int(rng.integers(1, 50))),
                       "event": "feature_use", "feature": str(feat), "duration_seconds": None,
                       "count": 1 + int(rng.poisson(1.5)), "user": _user(cid, ts, str(feat), user_pool)}  # fmt: skip
                # the draws above always happen (the seeded stream is unchanged); what the product could not have
                # recorded is dropped: a feature outside the plan tier, or one that had not been released yet
                if tier not in TIER_GATED.get(str(feat), (tier,)) or (feat == LATE_FEATURE and day < late_feature_day):
                    continue
                if feat == "exports" and zlib.crc32(f"{cid}|{ts.isoformat()}|legacy".encode()) % 30 == 0:
                    row["feature"] = LEGACY_NAME  # telemetry under an old name that no catalogue entry maps
                t["usage_events"].append(row)
            if rng.random() < 0.22 * mult[k]:
                t["usage_events"].append({"customer_id": cid, "timestamp": ts + timedelta(minutes=55), "event": "key_action",
                                          "feature": "workflow_completed", "duration_seconds": None, "count": 1,
                                          "user": _user(cid, ts, "key_action", user_pool)})  # fmt: skip

        # ---- support tickets and NPS surveys
        base_rate = 0.012 * (1.3 - eng)
        for k in np.flatnonzero((rng.random(n_days) < base_rate * (1 + 3.0 * friction)) & active_mask):
            tic_seq += 1
            day = signup + timedelta(days=int(k))
            opened = _at(day, int(rng.integers(7 * 3600, 19 * 3600)))
            stressed = friction[k] > 0
            hours = float(rng.lognormal(2.2 + (0.9 if stressed else 0.0), 0.8))
            resolved = opened + timedelta(hours=hours)
            first_resp = opened + timedelta(hours=min(hours, float(rng.lognormal(0.3, 0.7))))
            is_open = resolved > cutoff
            mood = rng.random()
            body = str(rng.choice(_NEG if mood < (0.65 if stressed else 0.2) else _POS if mood > 0.9 else _NEU))
            body = _message(body, cid, country, tic_seq)
            t["support_interactions"].append({
                "ticket_id": f"T{tic_seq:07d}", "customer_id": cid, "kind": "ticket", "created_at": _iso(opened),
                "first_response_at": _iso(first_resp if first_resp <= cutoff else None),
                "resolved_at": None if is_open else _iso(resolved), "priority": str(rng.choice(["low", "normal", "high", "urgent"], p=[0.3, 0.45, 0.2, 0.05])),
                "status": "open" if is_open else "solved", "escalated": bool(rng.random() < (0.3 if stressed else 0.06)),
                "category": str(rng.choice(TICKET_CATEGORIES)), "channel": str(rng.choice(["email", "chat", "phone"])),
                "csat": None if is_open or rng.random() < 0.5 else round(float(np.clip(rng.normal(2.4 if stressed else 4.2, 0.8), 1, 5)), 1),
                "nps": None, "message": body,
            })  # fmt: skip
        for k in range(75, n_days, 90):
            if active_mask[k] and rng.random() < 0.45:
                tic_seq += 1
                score = int(np.clip(round(rng.normal(4.5 + 4.5 * eng - 3.0 * (1 - mult[k]), 1.6)), 0, 10))
                ts = _iso(_at(signup + timedelta(days=k), 12 * 3600))
                t["support_interactions"].append({
                    "ticket_id": f"T{tic_seq:07d}", "customer_id": cid, "kind": "nps_survey", "created_at": ts,
                    "first_response_at": None, "resolved_at": ts, "priority": None, "status": "solved", "escalated": False,
                    "category": "survey", "channel": "email", "csat": None, "nps": score, "message": None,
                })  # fmt: skip

        # ---- subscription events
        def emit(kind: str, when: datetime, why: str | None = None, plan_code: str | None = None, amount: float | None = None,
                 *, subscription: str = sub_id) -> None:
            nonlocal ev_seq
            ev_seq += 1
            t["subscription_events"].append({"event_id": f"E{ev_seq:07d}", "subscription_id": subscription, "event": kind,
                                             "timestamp": _iso(when), "plan_code": plan_code, "mrr": amount, "reason": why})  # fmt: skip

        emit("started", _at(signup, 9 * 3600), plan_code=plan[0], amount=0.0 if has_trial else mrr)
        if has_trial and reason != "trial_expired" and trial_end <= end_day:
            emit("trial_converted", _at(trial_end, 9 * 3600), plan_code=plan[0], amount=mrr)
        cancel_requested = None
        if reason == "cancellation":
            cancel_requested = max(_at(signup, 10 * 3600), _at(end_day_c, 8 * 3600) - timedelta(days=int(rng.integers(0, 26))))
            emit("cancel_requested", cancel_requested, "cancellation")
        if failed_cycle is not None:
            emit("payment_failed", _at(failed_cycle, 3 * 3600), "payment_failure")
            emit("suspended", _at(failed_cycle + timedelta(days=7), 3 * 3600), "payment_failure")
        if end_day_c is not None:
            emit("ended", _at(end_day_c, 23 * 3600), reason)
        if reactivate_day is not None:
            emit("reactivated", _at(reactivate_day, 10 * 3600), plan_code=plan[0], amount=mrr)
        currently_ended = end_day_c is not None and reactivate_day is None
        status = "ended" if currently_ended else "trialing" if has_trial and trial_end > end_day else "active"

        # ---- invoices and payments
        last_paid_period_end = None
        for bday in billing_days:
            if end_day_c is not None and bday >= end_day_c and (reactivate_day is None or bday < reactivate_day):
                continue
            inv_seq += 1
            amount = round(mrr * (12 if annual else 1), 2)
            issued, due = _at(bday, 2 * 3600), _at(bday + timedelta(days=14), 2 * 3600)
            inv_id = f"I{inv_seq:07d}"
            unrecovered = failed_cycle == bday
            attempts: list[tuple[datetime, str, str | None]] = []
            if unrecovered:
                attempts = [(_at(bday + timedelta(days=x), 3 * 3600), "failed", "card_declined") for x in (0, 3, 7) if bday + timedelta(days=x) <= end_day]
            elif rng.random() < 0.03 and bday + timedelta(days=3) <= end_day:
                attempts = [(_at(bday, 3 * 3600), "failed", "insufficient_funds"), (_at(bday + timedelta(days=3), 3 * 3600), "succeeded", None)]
            else:
                late = int(rng.integers(0, 12)) if rng.random() < 0.12 else 0
                if bday + timedelta(days=late) <= end_day:
                    attempts = [(_at(bday + timedelta(days=late), 3 * 3600), "succeeded", None)]
            paid = next((a[0] for a in attempts if a[1] == "succeeded"), None)
            t["invoices"].append({"invoice_id": inv_id, "customer_id": cid, "subscription_id": sub_id, "invoice_date": issued,
                                  "due_date": due, "paid_date": paid, "amount": amount,
                                  "discount": round(monthly_price * (12 if annual else 1) * discount / 100, 2), "currency": "USD",
                                  "status": "paid" if paid else "uncollectible" if unrecovered else "open"})  # fmt: skip
            for when, pay_status, why in attempts:
                pay_seq += 1
                t["payments"].append({"payment_id": f"P{pay_seq:07d}", "customer_id": cid, "invoice_id": inv_id,
                                      "payment_date": _iso(when), "amount": f"{amount:.2f}", "status": pay_status,
                                      "failure_reason": why, "method": "card"})  # fmt: skip
            if paid:
                last_paid_period_end = bday + timedelta(days=365 if annual else 30)

        change = zlib.crc32(f"{cid}|attribute-change".encode())
        if n > 10 and change % 12 == 0 and n_days > 90 and size != "enterprise":
            # the company grew: a later file reports the new size, and the date from which it applies
            effective = signup + timedelta(days=30 + (change >> 8) % (n_days - 60))
            t["customer_changes"].append({"customer_id": cid, "segment": "mid_market" if size == "smb" else "enterprise",
                                          "employees": int(employees * 2.5) + 10, "effective_date": effective.isoformat()})  # fmt: skip
        t["customers"].append({
            "customer_id": cid, "company": f"Synthetic Co {n:05d}", "email": f"contact{n}@synthetic-{n}.example",
            "industry": str(rng.choice(INDUSTRIES)), "segment": str(size), "employees": employees, "country": country,
            "region": region, "channel": channel, "campaign": f"{channel}-{signup.year}q{(signup.month - 1) // 3 + 1}",
            "signup_date": signup.isoformat(), "marketing_opt_in": "yes" if rng.random() < 0.8 else "no",
            # fictional numbers (the 555-01xx range is reserved for fiction); one customer in seven has none on record
            "phone": None if zlib.crc32(f"{cid}|phone".encode()) % 7 == 0 else f"+1415555{100 + n % 100:04d}",
        })  # fmt: skip
        t["accounts"].append({
            "account_id": acc_id, "customer_id": cid, "status": "closed" if currently_ended else "active", "currency": "USD",
            "billing_email": f"billing{n}@synthetic-{n}.example", "payment_method": "card", "card_expiry": card_expiry.isoformat(),
            "csm": f"csm{int(rng.integers(1, 6))}@synthetic-vendor.example" if size != "smb" else None, "opened_at": _iso(_at(signup, 9 * 3600)),
        })  # fmt: skip
        t["subscriptions"].append({
            "subscription_id": sub_id, "customer_id": cid, "account_id": acc_id, "plan_code": plan[0], "status": status,
            "billing_period": plan[3], "start_date": _at(signup, 9 * 3600), "trial_end": _at(trial_end, 9 * 3600) if trial_end else None,
            "period_end": _at(last_paid_period_end, 0) if last_paid_period_end and not currently_ended else None,
            "cancel_requested": cancel_requested if currently_ended else None,
            "end_date": _at(end_day_c, 23 * 3600) if currently_ended else None, "end_reason": reason if currently_ended else None,
            "mrr": mrr, "discount_pct": discount, "auto_renew": not (reason == "non_renewal" and currently_ended), "seats": seats,
        })  # fmt: skip
        t["acquisitions"].append({
            "acquisition_id": f"Q{n:06d}", "customer_id": cid, "channel": channel,
            "campaign": f"{channel}-{signup.year}q{(signup.month - 1) // 3 + 1}", "acquired_at": signup.isoformat(),
            "cac": f"{float(rng.gamma(4, 60 if channel in ('paid_search', 'outbound') else 25)):.2f}",
        })  # fmt: skip

    expected: dict[str, Any] = {"customers": n_customers, **stats, "quarantine": {}, "duplicates": {}, "dq": {},
                                "attribute_changes": len(t["customer_changes"]), "late_feature_day": late_feature_day.isoformat()}  # fmt: skip
    if inject_issues and n_customers >= 20:
        usage, pays, subs, cust, tix = t["usage_events"], t["payments"], t["subscriptions"], t["customers"], t["support_interactions"]
        for row in usage[5:5 + 3 * 7:7]:  # 3 usage rows with an impossible negative duration
            row["event"], row["duration_seconds"] = "login", -30.0
        usage.extend({"customer_id": f"GHOST{k}", "timestamp": _at(end_day, 3600), "event": "login", "feature": None,
                      "duration_seconds": 60.0, "count": 1, "user": "u01"} for k in range(2))  # fmt: skip
        # a usage row dated in the future.  A fixed far-away date, not "end + 30 days": that would stop being in the
        # future a month after the end date and silently change what the same file imports (and the data cutoff with it)
        usage.append({"customer_id": "C000001", "timestamp": _at(FUTURE_DAY, 0), "event": "login", "feature": None,
                      "duration_seconds": 60.0, "count": 1, "user": "u01"})  # fmt: skip
        expected["quarantine"]["usage_events"] = 6
        for row in pays[:2]:
            row["status"] = "pending??"
        expected["quarantine"]["payments"] = 2
        bad = subs[-1]
        bad["end_date"], bad["end_reason"], bad["status"] = bad["start_date"] - timedelta(days=3), "cancellation", "ended"
        expected["quarantine"]["subscriptions"] = 1
        expected["quarantine_cascade_customer"] = bad["customer_id"]
        for row in cust[1:4]:
            row["email"] = "not-an-email"
        cust[4]["industry"] = None
        expected["dq"] = {"customer_email_format": 3, "customer_industry_present": 1}
        tix.extend(dict(row) for row in tix[:4])
        expected["duplicates"]["support_interactions"] = 4
    return SyntheticData(tables=t, cutoff=cutoff, expected=expected)


def _message(phrase: str, customer: str, country: str, ticket: int) -> str | None:
    """The support message for a drawn phrase: same intent, written out in the customer's language.  A few tickets
    (picked by a stable hash) are empty, carry contact details, voice two opinions at once, or are in a language
    the sentiment model does not cover - the states a real support export contains."""
    intent = synthetic_text.INTENT_OF_PHRASE[phrase]
    roll = synthetic_text.stable("ticket", customer, ticket)
    if roll % 61 == 0:
        return None
    language = synthetic_text.language_for(customer, country)
    if synthetic_text.stable("lang", customer) % 53 == 0:
        language = synthetic_text.UNSUPPORTED_SAMPLE_LANGUAGE
    if intent == "negative" and roll % 9 == 0 and "mixed" in synthetic_text.TEMPLATES[language]:
        intent = "mixed"
    feature = FEATURES[roll % len(FEATURES)]
    text = synthetic_text.message(intent, language, feature, roll)
    if roll % 37 == 0:
        text += f" Contact: support.user{roll % 90 + 10}@{customer.lower()}.example, +1 415 555 01{roll % 90 + 10}."
    return text


def demo_catalog(expected: dict) -> list[dict]:
    """The product-feature catalogue that matches the synthetic telemetry (SYNTHETIC, like the data)."""
    labels = {"dashboards": "Dashboards", "reports": "Reports", "integrations": "Integrations", "automation": "Automation",
              "exports": "Exports", "collaboration": "Collaboration"}  # fmt: skip
    entries = []
    for key in FEATURES:
        entries.append({
            "feature_key": key, "name": labels[key], "category": "core" if key in ("dashboards", "reports") else "advanced",
            "description": f"SYNTHETIC catalogue entry for the '{key}' telemetry of the demo data.", "availability": "ga",
            "release_date": expected["late_feature_day"] if key == LATE_FEATURE else None,
            "eligibility": {"plan_tiers": list(TIER_GATED[key])} if key in TIER_GATED else None,
            "event_mapping": [{"event_type": "feature_use", "feature_name": key}],
            "adoption_rule": {"min_events": 3, "min_days": 2}, "owner": "product@synthetic-vendor.example",
            "is_core": key in ("dashboards", "reports"),
        })  # fmt: skip
    entries.append({"feature_key": "workflows", "name": "Workflow completion", "category": "core", "availability": "ga", "is_core": True,
                    "description": "SYNTHETIC: the key action of the demo product.", "event_mapping": [{"event_type": "key_action", "feature_name": "workflow_completed"}],
                    "adoption_rule": {"min_events": 1, "min_days": 1}, "owner": "product@synthetic-vendor.example"})  # fmt: skip
    entries.append({"feature_key": "api_access", "name": "API access", "category": "advanced", "availability": "beta",
                    "description": "SYNTHETIC: an entry whose telemetry never arrives, to show the 'never seen' state.",
                    "eligibility": {"plan_tiers": ["enterprise"]}, "event_mapping": [{"event_type": "feature_use", "feature_name": "api_call"}],
                    "adoption_rule": {"min_events": 1, "min_days": 1}, "owner": "product@synthetic-vendor.example"})  # fmt: skip
    return entries


def _plain(value: Any) -> Any:
    if isinstance(value, datetime):
        return _iso(value)
    return value


def write_files(data: SyntheticData, out_dir: str | Path) -> dict[str, Path]:
    """Write one file per entity, deliberately covering every supported format."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    from openpyxl import Workbook

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}
    for entity, (file_name, _mapping) in FILES.items():
        rows = data.tables[entity]
        path = out / file_name
        columns = list(rows[0].keys()) if rows else []
        suffix = path.suffix
        if suffix in (".csv", ".tsv", ".txt"):
            delimiter = {".csv": ",", ".tsv": "\t", ".txt": "|"}[suffix]
            with open(path, "w", newline="", encoding="utf-8") as fh:
                writer = csv.writer(fh, delimiter=delimiter)
                writer.writerow(columns)
                writer.writerows([["" if (v := _plain(r[c])) is None else v for c in columns] for r in rows])
        elif suffix == ".json":
            path.write_text(json.dumps({"data": [{k: _plain(v) for k, v in r.items()} for r in rows]}), encoding="utf-8")
        elif suffix == ".jsonl":
            with open(path, "w", encoding="utf-8") as fh:
                fh.writelines(json.dumps({k: _plain(v) for k, v in r.items()}) + "\n" for r in rows)
        elif suffix == ".xlsx":
            wb = Workbook(write_only=True)
            ws = wb.create_sheet("subscriptions")
            ws.append(columns)
            for r in rows:
                ws.append([v.replace(tzinfo=None) if isinstance(v, datetime) else v for v in r.values()])
            wb.save(path)
        elif suffix == ".parquet":
            pq.write_table(pa.Table.from_pylist(rows), path)
        paths[entity] = path
    changes = out / CHANGE_FILE[0]
    with open(changes, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["customer_id", "segment", "employees", "effective_date"])
        writer.writerows([[r["customer_id"], r["segment"], r["employees"], r["effective_date"]] for r in data.tables["customer_changes"]])
    paths["customer_changes"] = changes
    (out / "SYNTHETIC_DATA_NOTICE.txt").write_text(
        "All files in this directory are SYNTHETIC, generated by churn_platform.synthetic.\n"
        "They contain no real customer, billing or usage data and must not be used to draw business conclusions.\n"
        f"cutoff={data.cutoff.isoformat()}\nexpected={json.dumps(data.expected, sort_keys=True)}\n", encoding="utf-8")  # fmt: skip
    return paths
