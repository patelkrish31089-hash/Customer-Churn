# Security baseline and limitations

## Implemented controls

- Explicit administrator creation; no default administrator or password.
- PBKDF2-HMAC-SHA256 password hashing with unique random salt.
- Opaque random sessions with expiry and logout revocation; session token digests use HMAC-SHA256 when a staging/production secret is configured.
- Backend role enforcement for data import, training, model approval/rollback, quality review, retention approval and CRM execution.
- Viewer role is read-only; customer and operational APIs require authentication.
- Liveness/readiness endpoints disclose limited status.
- CSV/XLSX/JSON imports use supported parsers, generated filenames, file-size checks, row quarantine and import provenance.
- SQLAlchemy parameterized operations; no direct frontend database access.
- REST source connector requires HTTPS and an exact hostname allowlist, rejects URL-embedded credentials and non-public IP literals, checks resolved DNS answers on the production request path, disables redirects, streams the body and enforces a 25 MB response ceiling. Tests cover private DNS answers and oversized streams.
- Data quality corrections are field-allowlisted, role-protected and audited.
- Secrets are read from environment references; provider tokens are not stored in the repository or source registry.
- Salesforce instance URLs are restricted to `*.salesforce.com` or exact `SALESFORCE_ALLOWED_HOSTS` entries. Provider calls reject redirects, and Intercom contact IDs are URL-encoded.
- CRM action flow requires approved recommendation, explicit customer consent, external identity mapping and idempotency. Unknown delivery is not blindly retried.
- Model training produces candidates; prediction requires an approved/pinned release.
- Financial persistence uses decimal database types; feature aggregations do not sum across currency codes.

## Important limitations before production

- The REST hostname check is not DNS pinning. A DNS answer can change between validation and connection; enforce outbound egress restrictions at the network/container layer and consider a pinned-connection transport for untrusted multi-tenant source configuration.
- Salesforce/HubSpot/Intercom tokens are environment-backed. There is no encrypted OAuth credential vault, refresh-token lifecycle, KMS integration, per-provider OAuth installation flow, webhook signature verification or token-rotation workflow. Adapters have mocked HTTP contract tests only; no provider account is connected.
- No tenant/organization model or proven row-level tenant isolation. Do not deploy to multiple customer organizations until this is designed and tested.
- MFA, SSO/OIDC, password reset, account lockout/rate limiting, CSP, complete security headers, reverse-proxy/TLS policy and deployment-specific CSRF review need completion.
- No independent penetration test, full SAST/DAST, container scan, dependency CVE report or privacy impact assessment has been completed. The static credential pattern scan is not a full secret scanner.
- Docker Compose and PostgreSQL schemas compile/static-validate locally, but the container image and actual PostgreSQL runtime were not run in this workspace. The CI workflow is configured for remote runtime verification but has not yet supplied a passing CI artifact.
- Customer-data encryption at rest, managed database access controls, retention/deletion and legal basis must be provided by the deployment owner.
- File upload antivirus scanning, archive-bomb defenses and malware scanning are not implemented.

## Privacy and governance

Use only data with an approved legal basis and specific purpose. Minimize imported columns. Use synthetic or authorized anonymized data for development. Hashing identifiers is not equivalent to anonymization. Restrict database, uploads, model artifacts and audit access. Do not send ticket text or customer details to a third party unless explicitly authorized. Consent and playbook settings require review by the data controller and legal/privacy owner.

## Reporting

Automated tests are evidence for the paths that ran; they are not a security certification. Production approval remains blocked until deployment-specific controls are implemented and independently assessed.
