# Architecture decision records

## ADR-001 — Modular monolith for local-first delivery

- Status: Accepted.
- Context: The application is an individual project without company infrastructure or credentials.
- Decision: Use FastAPI + SQLAlchemy + SQLite for local operation, keeping service boundaries modular.
- Alternatives: Microservices, Kubernetes, Kafka and multiple specialized databases.
- Rationale: The prompt requires maintainability and reproducibility, not a distributed architecture for its own sake.
- Consequences: Easier setup and end-to-end local testing; horizontal scale and distributed job processing are not provided.

## ADR-002 — Existing prompt only; no repository was supplied

- Status: Accepted.
- Context: Only the large requirements prompt was uploaded; no source repository ZIP was attached.
- Decision: Create a coherent new implementation under one root, and document this scope rather than pretending to modify an existing application.
- Consequences: This project is not a compatibility-preserving patch to an unseen codebase. The initial migration is suitable only for a new database.

## ADR-003 — Customer and subscription label scopes are distinct

- Status: Accepted.
- Context: Ending one of several subscriptions is not automatically customer churn.
- Decision: Store entity scope/reference separately, and calculate customer churn only when all cutoff-active subscriptions terminate in the horizon with no replacement started by the final termination date.
- Consequences: More accurate target semantics; company-specific relationship boundaries still require approval.

## ADR-004 — Historical feature snapshots are immutable

- Status: Accepted.
- Context: Historical training examples must remain reproducible and point-in-time correct.
- Decision: A customer/cutoff/feature-version snapshot is unique and not overwritten by recalculation.
- Consequences: Corrections must use an explicit feature version/reprocessing decision; automated overwrite is forbidden.

## ADR-005 — Chronological train/validation/test split

- Status: Accepted.
- Context: Random row splits can leak temporal information in a churn problem.
- Decision: Split on unique chronological cutoff dates; select candidate by validation PR-AUC; evaluate test only after selection.
- Consequences: Training fails early when there are too few dates, too few observations or one-class partitions; this is preferable to reporting an invalid metric.

## ADR-006 — Model approval required before inference

- Status: Accepted.
- Context: Training completion must not silently deploy a candidate model.
- Decision: New model releases are candidates; admin approval promotes to approved; older approved release is superseded; admin can roll back to a retained prior artifact.
- Consequences: Human governance step required before prediction serving.

## ADR-007 — No live CRM actions by default

- Status: Accepted.
- Context: The prompt requires credentials, permissions, approval and contact consent; none were provided.
- Decision: Expose only a local sandbox action that clearly marks itself simulated, requires an approved recommendation and consent, and is idempotent.
- Consequences: Salesforce/HubSpot/Intercom workflows remain blocked until real provider adapters, OAuth, webhooks and sandbox tests are configured.

## ADR-008 — Optional external MLOps services

- Status: Accepted.
- Context: MLflow, Airflow and Evidently servers/accounts are absent.
- Decision: Implement local registry, local PSI reports and readiness checks; expose explicit tool status instead of fake live services.
- Consequences: Scheduling, central experiment tracking and production monitoring remain not configured.
