# V8 remaining gate closure plan

The current report has ten blocked acceptance gates. They are not code defects that can be closed by changing a status field. Each gate requires the stated runtime, external authority, data, or third-party evidence.

| Gate | Owner / responsible party | Required evidence to close | Safe execution path |
|---|---|---|---|
| `postgresql_runtime` | Platform engineer | Live PostgreSQL migration round trip, CRUD, FK/unique constraints, Numeric precision, rollback, readiness, login/logout and session revocation | Run `backend-postgresql` GitHub Actions job; retain `postgresql_runtime_evidence.json` and JUnit artifact. |
| `docker_runtime` | DevOps engineer | Compose build/start, app readiness, authenticated API, restart persistence, `pg_dump`, restore into a second DB, row verification and teardown | Run `docker-compose-runtime` GitHub Actions job; retain Docker runtime evidence and failure logs. |
| `clean_virtual_environment_install` | Python/build engineer | New isolated environment, declared dependency installation, `pip check`, compilation, regression suite and UI syntax | Run the hosted Python matrix from a clean runner; retain pip install log, `pip check`, Python/pip versions and JUnit. |
| `mlops_runtime` | ML platform engineer | MLflow parameter/metric/artifact read-back and Evidently structured drift report | Run `mlops-adapter-runtime`; retain `mlops_runtime_evidence.json`. |
| `quality_and_security_toolchain` | Application security engineer | Ruff, Bandit and pip-audit versions, command output, findings and remediation/acceptance decisions | Run scanner steps in `backend-postgresql`; review every high/critical finding. An empty scan report alone is not a penetration test. |
| `live_crm_provider_sandbox` | CRM/provider administrator | Authorized Salesforce, HubSpot or Intercom sandbox identity; least-privilege OAuth; create/read-back/reconciliation; webhook signature test; cleanup | Configure provider secrets in the hosting/CI secret manager, never in source or chat; run provider-specific acceptance tests. |
| `hosted_staging_deployment` | Deployment owner | Authorized hosting environment, TLS, secret store, isolated persistent PostgreSQL, migrations, health/readiness, RBAC, backup/restore and rollback | Deploy only after the owner grants access; attach sanitized deployment and recovery logs. |
| `real_company_model_validation` | Data owner + ML lead | Governed authorized dataset with matured churn labels; temporal holdout; calibration, subgroup, threshold, SHAP stability and model utility review | Store only approved data in controlled infrastructure; keep it out of this source ZIP and generic CI artifacts. |
| `business_churn_policy_signoff` | Business/product owner | Signed policy version covering effective churn date, target horizon, pause/grace rules, cancellations, reactivations, involuntary churn and censoring | Approve `docs` policy artifact through the organization's normal change-control/sign-off process. |
| `independent_penetration_test` | Independent security assessor | Written scope/authorization, independent findings report, severity, remediation references and retest result | Commission a qualified independent assessor. Internal tests or Bandit output cannot substitute. |

## Why the blocker count cannot be reduced further here

This workspace has no PostgreSQL server/driver runtime, no Docker CLI/daemon, no package-index DNS, no MLflow/Airflow/Evidently installations, and no Ruff/Bandit/pip-audit installations. It also has no provider, hosting or GitHub execution credentials. No authorized company dataset, business-policy signatory or independent assessor evidence was supplied.

A local SQLite test cannot be called PostgreSQL runtime. Compose parsing cannot be called Docker runtime. A mocked CRM adapter cannot be called a live provider connection. Synthetic model metrics cannot be called real-company validation. Internal security tests cannot be called an independent penetration test.

## Evidence hygiene

- Never paste API tokens, OAuth refresh tokens, webhook secrets, database passwords or customer personal data into source code, ZIPs, CI logs or chat.
- Use CI/hosting secret managers and least-privilege, revocable credentials.
- Record workflow run ID, commit SHA, runner image and artifact name for external test runs.
- Preserve failures and remediate them; do not edit a generated report to force a PASS.
