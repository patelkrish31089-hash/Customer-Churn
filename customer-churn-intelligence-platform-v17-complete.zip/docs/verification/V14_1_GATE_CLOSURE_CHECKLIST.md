# V14.1 production gate closure checklist

## Current verified scope

The fresh report in `reports/verification.json` records **14 PASS / 0 FAIL / 10 BLOCKED across 24 unique production acceptance checks**. The strict suite records **115 passed / 0 failed / 0 skipped**. The separately scoped local-demo report records **14/14 PASS** and excludes the ten production gates from its denominator. These are different scopes and must not be combined.

## Five technical/runtime gates

| Gate | Evidence required to change BLOCKED to PASS | Supported execution path |
|---|---|---|
| Clean isolated install | Supported Python 3.11/3.12; new disposable venv; all required dependency groups installed; `pip check`; strict tests; complete logs | Windows: `scripts/run_acceptance.ps1`; hosted: `clean-install-acceptance` job in `.github/workflows/ci.yml` |
| Quality/security toolchain | Ruff, Bandit and pip-audit actually execute; findings remediated or formally accepted; tool versions and logs captured | `scripts/quality_security_acceptance.py`; hosted `quality-security-toolchain` job |
| PostgreSQL runtime | PostgreSQL 16 server; psycopg driver; Alembic migration; CRUD, foreign-key/unique constraints, Numeric precision, transaction rollback, authentication and persistence smoke | `scripts/postgres_runtime_smoke.py`; Windows runner `-WithContainers`; hosted `backend-postgresql` job |
| Docker runtime | Docker Compose build/up, health, restart persistence, backup and restore verified against a Docker daemon | `scripts/docker_runtime_smoke.sh`; Windows runner `-WithContainers`; hosted `docker-compose-runtime` job |
| MLOps runtime | MLflow tracking and artifact read-back; Evidently report generation; Airflow DAG parse and execution with persisted batch/retry evidence | `scripts/mlops_adapter_smoke.py`; `scripts/airflow_dag_runtime_smoke.sh`; hosted `mlops-adapter-runtime` and `airflow-dag-runtime` jobs |

Run in a real supported environment after installing required tools and obtaining package-index access:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Reviewer ID" -WithContainers -WithMLOps
```

The native browser-origin/axe-core audit is a separate optional check via `-WithBrowserNative`; the local Chromium bridge proves the UI and real API journey using a host-side transport, not native browser CORS. The Windows runner does not install Airflow; the hosted Airflow job is the declared runtime path.

After reviewing actual logs, `scripts/merge_local_evidence.py --reviewed-by "Reviewer ID"` can close only the technical gates for which complete evidence files exist and validate against the current source-tree digest. `scripts/verify.py --stage report` then recomputes the aggregate. A source/config edit invalidates the local evidence review.

## Five company/independent-owner gates

| Gate | Required owner | Required evidence |
|---|---|---|
| Live CRM provider sandbox | Company CRM administrator / integration owner | Authorized sandbox tenant, least-privilege OAuth grants, webhook secrets/signature config, real create/read-back/reconciliation and idempotency evidence |
| Hosted staging deployment | Company platform/DevOps owner | Approved cloud account, DNS/domain, TLS, secret manager, isolated persistent database, deployment, health, backup/restore and rollback evidence |
| Real-company model validation | Data owner, privacy/governance and ML owner | Authorized governed extract; mature outcome period; temporal holdout; leakage audit; model discrimination/calibration; subgroup/fairness review; drift and prospective monitoring plan |
| Business churn-policy sign-off | Subscription business/product/finance owner | Versioned approval of effective cancellation date, horizon, pause/grace period, reactivation, involuntary churn, competing outcomes and censoring policy |
| Independent penetration test | Authorized independent assessor and security owner | Written test authorization/scope, report with severity and evidence, remediation references and independent retest |

These five gates cannot be closed by synthetic data, application code, unit tests, local mocks, generated reports or a self-review. Keep credentials and company data out of this source ZIP; use the organization's approved secret manager and governed data environment.

## Release decision

V14.1 is locally regression-tested and suitable for a controlled synthetic-data demonstration. It is **not approved for production** until all ten blocked gates have valid, reviewed evidence and the remaining partial feature requirements in `docs/ROADMAP_COVERAGE.md` are accepted by their owners.
