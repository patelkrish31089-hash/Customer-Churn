# V14 release notes — reporting, administration and model fairness review

## Delivered

1. Added `app/services/reporting.py` as the single report data/export service.
2. Added permission-filtered CSV/JSON exports for overview, customers, predictions, model registry, retention worklist, data-quality findings, import batches, cohort retention, survival analysis and audit events.
3. Customer exports omit email addresses. Spreadsheet formula prefixes are neutralized for untrusted CSV string cells; numeric negative values remain numeric.
4. Added administrator-only user listing and account activation/deactivation endpoints. Password hashes are never returned. Self-deactivation is rejected; user state changes create audit events.
5. Added administrator-only audit-event listing.
6. Added a Reports dashboard page and an Administration dashboard page. Browser E2E now visits both pages, downloads a JSON report and creates a user from the UI.
7. Added a model group fairness review using exact mature, uncensored customer/cutoff/horizon joins; outputs include group counts, selection rates, Wilson intervals for selection rate, precision, recall/TPR, FPR, and small-sample warnings.
8. Added exact online feature-snapshot retrieval by customer ID, cutoff timestamp and feature contract version.
9. Added eight API/service regression tests for export permissions, invalid export requests, CSV injection, user administration, audit history, fairness calculation and feature-snapshot retrieval.
10. Updated application version to 1.4.0.

## Verification

- Strict pytest suite: 112 tests, warnings treated as errors.
- Frontend JavaScript syntax: checked with Node.
- Chromium browser bridge: login; all nine application sections; report JSON download; admin user creation and audit readback; CSV upload; customer readback; Customer 360; logout.
- Semantic accessibility smoke: visible controls checked for accessible names, images for alt attributes, and main/nav landmarks.
- Browser bridge uses a real local FastAPI process but a host-side API transport bridge. It does not verify native browser CORS/navigation or a complete axe-core WCAG audit.
- The production acceptance report remains the authoritative production gate record. This workspace does not have PostgreSQL server runtime, Docker daemon, package-index DNS, MLflow/Airflow/Evidently runtimes or Ruff/Bandit/pip-audit. CRM, hosted staging, real business data, policy sign-off and independent penetration test evidence are also absent.

## Scope boundary

V14 materially improves the local product and its regression coverage. It does not claim all fine-grained items across the 20 phases are complete, and it does not convert infrastructure, business-owner or independent-assessor requirements into passes.


## V14.1 extension — reproducible dataset readiness and leakage review

- Added a role-protected dataset audit endpoint and Models-page panel.
- Audit reports exact label/snapshot joins, mature-horizon and event-window consistency, exclusions, chronological partition sizes/class balance, per-feature missingness, a stable dataset fingerprint, and repeat-customer overlap warnings.
- Tightened the training dataset assembler to exclude labels whose horizon is not mature as of the real current time, positive events outside `(cutoff, maturity]`, negative labels with event dates, maturity-date mismatches, missing snapshots and malformed feature payloads.
- Browser E2E now asserts the dataset-audit API response and rendered readiness panel.
- Fresh strict suite: 115 passed, 0 failed, 0 skipped.
- This audit improves leakage controls but cannot reconstruct raw source timestamps from a source fingerprint or certify company-data correctness.


The V14.1 security extension additionally revokes existing session tokens on account deactivation. Reactivating an account does not revive prior tokens; a fresh login is required.
