# Release readiness — V11 acceptance-pipeline hardening

**Decision: controlled local development and synthetic demonstration only. Not approved for staging or production.**

## V11 pipeline changes

- The clean-install gate now has a fresh `venv` harness that disables system site packages and captures every install/test step in `reports/clean_install_acceptance.json` when run in hosted CI.
- Ruff, Bandit, pip-audit and the supplemental AST scanner now run in their own job, independent of PostgreSQL availability. Results are captured in `reports/quality_security_acceptance.json` when that job runs.
- The local workflow-contract check now verifies both jobs, their required dependency groups, Python version matrix and artifact uploads. That static check does not execute remote jobs.

## Current evidence

- Fresh aggregate: **14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance checks**, plus one unrelated `NOT_APPLICABLE` host diagnostic.
- Regression: **93 tests passed** with warnings treated as errors. Pytest-asyncio fixture loop scope is explicitly configured and regression-tested.
- Core: Python compilation, app import, frontend JS syntax, strict regression, limited secret-pattern scan and supplemental first-party AST security smoke passed. The AST scanner found zero selected unsafe patterns; it does not replace Ruff, Bandit, pip-audit or penetration testing.
- Runtime: real local Uvicorn startup, liveness/readiness, dashboard, login, authenticated identity, logout revocation and graceful shutdown passed.
- HTTP smoke: 40 authenticated requests at concurrency 10 returned HTTP 200. This is a small smoke, not production capacity evidence.
- SQLite: fresh Alembic upgrade → downgrade → re-upgrade passed; schema has 30 tables and no foreign-key violations.
- PostgreSQL: dialect DDL compilation and offline Alembic SQL generation passed. **No PostgreSQL server was connected.**
- Compose: static configuration validation passed. **No Docker daemon/runtime was available.**
- CI contract: PostgreSQL, Docker, browser/accessibility, MLflow/Evidently and Airflow acceptance jobs were statically validated. **No remote GitHub Actions run was observed.**
- Synthetic workflow: 120 synthetic customers, 120 predictions and 26 recommendations; one sandbox action was simulated. No company records or real CRM were contacted.
- Browser: Chromium bridge E2E passed: login, all seven dashboard sections, CSV upload, customer read-back, Customer 360 and logout. Semantic accessibility smoke scanned 10 views and 131 visible controls without unnamed controls or missing image alternatives. The native browser-origin transport/CORS path and full axe-core/WCAG audit remain unverified locally.
- Clean install: a new Python 3.13 virtual environment was created, but dependency installation was blocked because the package-index hostname could not be resolved. See `reports/v10_clean_install_attempt.txt` and `.json`.

## Ten unique blocked gates

| Gate | Required closure evidence |
|---|---|
| PostgreSQL runtime | Real PostgreSQL service, psycopg driver, migrations, CRUD, constraints, exact money precision, rollback and API auth evidence. |
| Docker runtime/recovery | Docker Compose build/up, health, persistence, restart and backup/restore on a Docker-enabled runner. |
| Clean isolated install | Fresh supported Python install of all required groups, `pip check`, strict tests and version/log evidence. |
| MLOps runtime | MLflow write/read-back, Evidently drift report, Airflow scoring DAG execution, persisted batch and retry evidence. |
| Quality/security toolchain | Ruff, Bandit and pip-audit executions with findings resolved or formally accepted. |
| Live CRM provider sandbox | Authorized provider tenant/OAuth scopes, real create/read-back/reconciliation and webhook evidence. |
| Hosted staging deployment | Authorized host, domain/TLS, secret manager, persistent database, migration, health and rollback evidence. |
| Real-company model validation | Authorized governed data with matured outcomes and leakage-safe temporal holdout, subgroup, calibration and explanation review. |
| Business churn-policy sign-off | Signed/versioned policy for cancellation, reactivation, pauses, grace periods, involuntary churn and censoring. |
| Independent penetration test | Written authorization, independent assessment, severity-rated report, remediation and independent retest. |

The first five require tools/services or package access unavailable on this runner. The other five require provider/company authority, data, hosting authorization or independent review. These cannot be made PASS by modifying application code or reports.

## Release boundary

The detailed roadmap still marks several requirements in Phases 2–17 as Partial. Phase 18 live CRM, Phase 19 operational MLOps/deployment and Phase 20 independent production acceptance are not fully accepted.

**V11 is verified for controlled local development, synthetic demonstration, local API/authentication, SQLite migration lifecycle, PostgreSQL offline DDL compilation and the tested Chromium bridge journey. Full 20-phase acceptance and production readiness are NOT APPROVED.**

For the stepwise hosted closure sequence, see `V11_GATE_REMEDIATION.md`; for external approvals, see `EXTERNAL_SIGNOFF_TEMPLATES.md`.
