# Requirement traceability matrix (selected executable coverage)

This matrix records a representative set of requirements, their implementation and verification. It is not an assertion that every fine-grained requirement in each phase has been accepted. The phase-wide status and residual blockers live in `docs/ROADMAP_COVERAGE.md`.

| ID | Requirement | Implementation | Verification | Result |
|---|---|---|---|---|
| P1-001 | Application foundation/config/auth | `app/config.py`, `app/security.py`, `app/main.py` | config/auth/RBAC tests; real Uvicorn smoke | Local pass |
| P1-010 | Safe schema migrations | `alembic/versions/*` | fresh SQLite upgrade/downgrade/re-upgrade | SQLite pass |
| P2-001 | Six source datasets, XLSX/JSON/CSV | `app/services/data.py`, imports API | format + API tests | Local pass; data policy partial |
| P2-REST | Authorized REST ingestion boundary | `app/integrations/sources.py` | allowlist/mapping/API tests | Local contract pass; external source blocked |
| P3-001 | Idempotent row-accounted ingestion | `ImportBatch`, `DataIssue`, data services | valid/invalid rows, duplicate and partial failure tests | Local pass; orchestration partial |
| P4-001 | Configurable quality rules/scorecards/review | `app/services/quality.py`, models/routes | rule, scorecard, correction and API tests | Local pass; comprehensive semantic coverage partial |
| P5-001 | Scoped churn labels and censoring | `generate_labels`, `ChurnLabel` | boundary, maturity, subscription/customer scope tests | Local pass; policy approval pending |
| P6-001 | Point-in-time features v2.1 | `build_features` | feature cutoff, mutation, currency and version tests | Local pass; full business taxonomy partial |
| P7-001 | Immutable historical feature snapshots | `FeatureSnapshot` | uniqueness and immutable snapshot tests | Local pass; online store absent |
| P8-001 | EDA diagnostics | `app/services/analytics.py` | EDA service/API tests | Partial/local pass |
| P9-001 | Cohort retention curves | `cohort_retention` | monthly cohort tests; API test | Partial/local pass; cell CIs/report export absent |
| P10-001 | Kaplan-Meier survival analysis | `survival_curve` | censoring/interval/survival tests | Partial/local pass; competing-risk sophistication absent |
| P11-001 | Leakage-safe chronological dataset | `assemble_dataset`, `train_models` | partition and cutoff tests + smoke | Partial/local pass |
| P12-001 | Four-family model comparison | `train_models` | LR/RF/XGBoost/LightGBM available-family test | Local pass; expanded search/fairness review partial |
| P13-001 | Metrics/calibration/threshold/cost analysis | `app/services/ml.py` | metric, training-only calibration, cost-threshold tests | Partial/local pass; financial costs must be supplied |
| P14-001 | Local/global SHAP explanations | `explain_prediction` | optional SHAP tests/additivity path | Partial; requires explanation governance |
| P15-001 | Single/batch approved inference | `predict_customer`, batch services/API | batch idempotency, partial retry, approved-release tests | Partial/local pass; durable worker/scheduler blocked |
| P16-001 | Customer 360 and timeline | `customer_360`, profile API | multi-source, normalized timestamp, currency tests | Partial/local pass; full identity survivorship and UI masking absent |
| P17-001 | Playbooks, assignments, experiments | `retention_governance.py` | policy/cooldown/randomization/maturity tests | Partial/local pass; causal validity needs design and real sample size |
| P18-001 | CRM provider adapters | `app/integrations/crm.py` | mocked HTTP contract and consent/idempotency guard tests | Adapter tests pass; live provider BLOCKED |
| P19-001 | MLflow/Airflow/Evidently/deployment | integration adapters, DAG, compose | import/status tests and Compose static validation | Partial; runtime BLOCKED |
| P20-001 | Full verification | `scripts/verify.py`, `reports/` | 93 pytest tests (`-W error`) plus supplemental AST security smoke + independent runtime, migration, PostgreSQL offline DDL, load, CI workflow contract and synthetic smoke gates | Partial; V11 aggregate 14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance gates; native browser-origin/axe-core, security-toolchain and production gates remain blocked or limited |

## Test suite index

- `tests/test_platform.py`: foundational auth, data import, labels, features, model lifecycle, retention, APIs, backup and integration flows.
- `tests/test_advanced_features.py`: import formats, quality rules/review, sources, analytics, model-family comparison/calibration/batch/SHAP, Customer 360, CRM adapters, experiments and MLOps boundaries.
- `scripts/runtime_http_smoke.py`: live local server/auth lifecycle.
- `scripts/http_load_smoke.py`: 40-request local concurrency smoke, not a capacity benchmark.
- `scripts/deployment_config_check.py`: static Docker Compose structure validation, not a Docker runtime test.
- `scripts/migration_lifecycle_smoke.py`: SQLite Alembic upgrade/downgrade/re-upgrade lifecycle.
- `scripts/postgres_migration_compile.py`: PostgreSQL offline migration SQL generation; does not connect to PostgreSQL.
- `scripts/browser_bridge_e2e.py`: Chromium UI E2E against a real local FastAPI process via host-side API bridge; covers login, seven screens, CSV import, Customer 360 and logout. Native origin/CORS navigation and axe-core remain outside local coverage.
