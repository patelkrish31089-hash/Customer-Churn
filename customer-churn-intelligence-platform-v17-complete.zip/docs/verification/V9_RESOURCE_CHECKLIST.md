# V9 resource checklist for final acceptance

The project team can close the remaining gates only when the following resources and approvals exist.

- [ ] GitHub repository with permission to run Actions and download job artifacts.
- [ ] Runner with package-index access and supported Python versions.
- [ ] PostgreSQL 16 service and compatible psycopg installation.
- [ ] Docker Engine/Compose runtime.
- [ ] MLflow tracking service, Evidently package, and Airflow runtime with its supported constraints.
- [ ] Ruff, Bandit and pip-audit installed and executable.
- [ ] Salesforce, HubSpot or Intercom sandbox account, least-privilege credentials, webhook configuration and approved test records.
- [ ] Staging account, DNS/domain, TLS and secret management.
- [ ] Authorized company data with matured churn outcomes and documented provenance.
- [ ] Signed churn-policy decision from the business owner.
- [ ] Independent penetration-test authorization, report and retest.

Do not paste secrets into this checklist. Record only where a secret is managed and who owns it.
