# V17 release notes

Generated 2026-11-07. V17 is a local-demo and development acceptance release, not a production certificate.

## Product changes

- Governed Feature Store registry derived from the model feature contract.
- Snapshot coverage and per-feature missingness summary.
- Point-in-time online feature lookup that selects only snapshots at or before the requested timestamp.
- Per-customer feature history and bounded CSV export.
- Queued feature materialization through the durable background-job service.
- Bulk data-quality review for accepted-risk and false-positive dispositions, with selection validation before mutation and a per-finding audit event.
- Feature Store navigation and view in the dashboard.
- New isolated API/service product smoke and browser navigation check.
- Product workflow test included in the local, PowerShell and GitHub Actions acceptance flows.

## Current verification

- Strict automated tests: 147 passed, 0 failed, 0 skipped (`python -m pytest -q -W error`).
- Production acceptance: 16 PASS / 0 FAIL / 10 BLOCKED (26 unique checks).
- Local-demo acceptance: 15/15 PASS. The profile excludes the ten production gates; it does not certify production readiness.
- Fresh product evidence: `reports/feature_store_quality_evidence.json`.
- Current aggregate: `reports/verification.json`.

## Ten production gates that remain open

Five technical/runtime gates remain: live PostgreSQL, Docker/Compose runtime and recovery, isolated dependency installation on a network-enabled supported Python runner, MLflow/Evidently/Airflow runtime, and Ruff/Bandit/pip-audit. Five external gates remain: an authorized live CRM sandbox, company-owned hosted staging, real company churn data with mature outcomes, written business-policy approval, and an independent authorized penetration test with retest evidence.

These cannot be resolved by changing status fields or substituting local SQLite/synthetic tests. The detailed closure procedures and owners are in `V17_GATE_CLOSURE_CHECKLIST.md`.
