# V11 acceptance-pipeline hardening and gate remediation

## What changed from V10

V10's local evidence remains the baseline: **14 PASS / 0 FAIL / 10 BLOCKED**. The ten blockers are still not eligible to be declared passed because this workspace has no PostgreSQL server, Docker daemon, package-index connectivity, installed MLOps scanner stack, authorized company integrations, hosted staging credentials, governed company data, business sign-off or independent penetration-test report.

V11 makes the technical gates separately executable and evidence-producing in hosted CI:

1. `clean-install-acceptance` runs on Python 3.11 and 3.12. `scripts/clean_install_acceptance.py` creates a new virtual environment with `system_site_packages=False`, installs all three declared dependency groups, runs `pip check`, compiles the project, runs pytest with warnings as errors, checks frontend JavaScript syntax and captures a package inventory plus per-step logs.
2. `quality-security-toolchain` runs independently of PostgreSQL. `scripts/quality_security_acceptance.py` captures `pip check`, Ruff, Bandit, pip-audit and the supplemental first-party AST scanner. It writes a machine-readable report and per-tool logs even when one scanner fails.
3. PostgreSQL and Docker jobs remain backed by real service containers/runtime commands. They are not replaced by SQLite or Compose YAML-only checks.
4. Each hosted job uploads its own evidence with `if: always()`. A failing job should still provide logs explaining the blocker.
5. The Docker runtime job runs independently of the separate PostgreSQL matrix because it provisions its own PostgreSQL service. `scripts/ci_workflow_check.py` verifies the jobs, supported Python matrix, required scripts, dependency groups and evidence uploads.

## Required next run

1. Put this exact project revision in the authorized private GitHub repository.
2. Push the branch or run **Actions → full-platform-acceptance → Run workflow**.
3. Review these artifacts independently:
   - `clean-install-python-3.11` and `clean-install-python-3.12`;
   - `quality-security-toolchain-evidence`;
   - `backend-postgresql-python-3.11` and `backend-postgresql-python-3.12`;
   - `docker-compose-runtime-evidence`;
   - `mlops-adapter-runtime-evidence` and `airflow-dag-runtime-evidence`.
4. For every failed job, fix the actual log finding and rerun the affected job. Do not infer a pass from the static workflow-contract check.
5. Download the artifacts from that one workflow run. Extract every artifact into its own folder under `reports/hosted-artifacts/`, retaining the exact artifact folder names.
6. Run the evidence importer after reviewing the logs and scanner findings:

   ```bash
   python scripts/merge_hosted_evidence.py \
     --artifact-root reports/hosted-artifacts \
     --run-id YOUR_GITHUB_RUN_ID \
     --run-attempt YOUR_GITHUB_RUN_ATTEMPT \
     --commit-sha YOUR_FULL_40_CHARACTER_COMMIT_SHA \
     --reviewed-by YOUR_REVIEWER_ID
   python scripts/verify.py --stage report
   ```

   The importer verifies that all required artifacts belong to one workflow run, attempt, repository and commit, checks each job's success and validates its evidence payload. It writes `reports/hosted_gate_closure.json`; the aggregate verifier uses only the technical gates that pass this check. Missing, failed, mixed-run, mixed-attempt, mixed-repository or incomplete artifacts stay `BLOCKED`.
7. Attach the workflow run ID, commit SHA, runner image, artifact names and review date to the release record.

## Remaining external acceptance gates

| Gate | What the repository can provide | What the authorized owner must still provide |
|---|---|---|
| Live CRM provider sandbox | Provider adapters, mocked contract tests, secret-safe configuration and approval/idempotency controls | Sandbox tenant, least-privilege credentials, external test identity, provider-specific create/read-back evidence and cleanup |
| Hosted staging deployment | Docker Compose baseline, health/readiness endpoints, migrations and backup/restore smoke | Hosting account/project, domain/TLS, secret manager, isolated persistent database, deployment approval and rollback evidence |
| Real-company model validation | Feature/label pipeline, synthetic benchmark and evaluation utilities | Governed real data, approved outcome definition, mature labels, chronological holdout and ML/business review |
| Business churn-policy sign-off | Policy fields and 30-day target implementation documented in the source specification | Named product/business owner approval of cancellation, pause, grace, reactivation, involuntary churn and censoring semantics |
| Independent penetration test | Security controls, source scans and deployment hardening evidence | Written authorization, independent assessor, scope, report, remediation and independent retest |

## Gate status rule

The local environment cannot create company-owned accounts, company data, hosting resources, signatures or independent assessor evidence. Those five business/external gates remain `BLOCKED` until the required evidence exists. The five technical gates also remain `BLOCKED` in the local report until the hosted acceptance jobs have actually completed and their artifacts have been reviewed. A code change or a green static check is not a substitute for that run.
