# V12 blocked-gate closure runbook

V12 does not mark external approvals or unavailable services as passed. It adds a supported Windows acceptance runner and a local-evidence importer so technical gates can be closed on a machine where the required services and tools actually run.

## A. Run the project locally on Windows

Requirements: Windows 10/11, Python 3.11 or 3.12, Git Bash (for the Docker smoke), Node.js 22 (required for the clean-install frontend syntax check; also used by the browser/axe option), and Docker Desktop with its Linux engine started when container checks are selected.

Open PowerShell in the project root and run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Your reviewer ID"
```

The default run creates `.venv-v12`, installs the declared application/test/ML/explainability requirements, runs a separate clean-install acceptance in a disposable virtual environment, runs the five local verification stages, and executes Ruff, Bandit and pip-audit. It then creates `reports/local_gate_closure.json` and refreshes the consolidated verification report.

To include the Docker Compose plus live PostgreSQL CRUD/constraints/authentication and backup/restore exercises:

```powershell
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Your reviewer ID" -WithContainers
```

To include MLflow and Evidently adapter runtime validation:

```powershell
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Your reviewer ID" -WithMLOps
```

To include a browser-native Playwright journey with axe-core:

```powershell
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Your reviewer ID" -WithBrowserNative
```

For a second run after dependencies are already installed, add `-SkipInstall`. Do not use the project `.venv-v12` for production credentials or real customer data. The container option uses a throwaway random PostgreSQL password and removes its Compose containers/volumes when finished.

The script does not install or run Apache Airflow on native Windows. The hosted GitHub Actions workflow provisions Airflow on Ubuntu using the versioned constraints file. Airflow evidence must come from a successful `airflow-dag-runtime` CI job or an authorized POSIX test environment.

## B. How local evidence closes technical gates

The script writes machine evidence files under `reports/`. Run the importer directly after manually reviewing the logs if you need to repeat the review:

```powershell
.\.venv-v12\Scripts\python.exe scripts/merge_local_evidence.py --reviewed-by "Your reviewer ID"
.\.venv-v12\Scripts\python.exe scripts/verify.py --stage report
```

The importer validates the schema and required result fields of each evidence file and binds the review to a SHA-256 digest of the current source/config tree. A source/config change invalidates the local closure report. The local importer can close only the technical gates for which all required evidence is present and passing:

| Technical gate | Required evidence |
|---|---|
| Clean virtual environment install | Disposable isolated venv, all declared groups installed, `pip check`, compile, strict pytest, frontend syntax and package inventory |
| Quality/security toolchain | `pip check`, Ruff, Bandit, pip-audit and the supplemental first-party AST check |
| PostgreSQL runtime | Live PostgreSQL server version, migrations, CRUD, numeric precision, uniqueness, FK, rollback, persistence, API auth and cleanup |
| Docker runtime | Compose build/start, service health, auth, restart persistence, `pg_dump`, restore to a separate database and row verification |
| MLOps runtime | MLflow log/read-back, Evidently drift report, and Airflow DAG task/batch success |

A local closure is explicitly labelled `reviewed_local`; it is not a GitHub-hosted CI attestation. The hosted importer remains available for a single-run/single-attempt/single-commit GitHub Actions evidence bundle. Missing evidence stays `BLOCKED`.

## C. Five gates that cannot be solved by code or synthetic fixtures

| Gate | Who must provide the missing input | Evidence required to close it |
|---|---|---|
| Live CRM provider sandbox | Company CRM administrator | Salesforce/HubSpot/Intercom sandbox, approved scopes and credentials in a secret manager, test identity mapping, successful create/read-back, webhook verification and cleanup |
| Hosted staging deployment | Company infrastructure owner | Authorized hosting project, domain/TLS, secret storage, deployed app/database, health/readiness, login/RBAC, backup/restore, rollback and retention evidence |
| Real-company model validation | Data owner and ML/business reviewer | Authorized historical data with mature churn outcomes, approved label definition, chronological holdout, leakage audit, subgroup/calibration analysis and signed metric review |
| Business churn-policy sign-off | Product/finance/business owner | Written approval of cancellation/effective termination, pause, grace period, failed payments, reactivation, customer/subscription aggregation and right-censoring rules |
| Independent penetration test | Authorized security owner and independent assessor | Written scope/authorization, independent report, severity-ranked findings, remediation commits and independent retest evidence |

Do not upload company secrets or data to the ZIP, source control or this chat. Use an approved secret manager and company-approved secure data transfer.

## D. Hosted acceptance path

1. Push this exact source revision into the authorized private GitHub repository.
2. Enable Actions and run `full-platform-acceptance`.
3. Require all clean-install, quality/security, PostgreSQL, Docker, browser/axe, MLflow/Evidently and Airflow jobs to complete successfully.
4. Download every required artifact from the same workflow run and attempt. Extract each into its exact artifact-name directory under `reports/hosted-artifacts/`.
5. Review logs/findings, then run `scripts/merge_hosted_evidence.py` using the real run ID, attempt, full commit SHA and reviewer ID.
6. Run `python scripts/verify.py --stage report` and retain the report plus the GitHub run URL in the release record.

## E. Release rule

The application is locally verified only to the extent shown by current reports. Production acceptance requires all technical gates and all five company/independent-owner gates. Synthetic demo results are not real-company accuracy evidence. A successful test-only CRM adapter is not a live CRM connection. A local Docker container is not hosted staging. Internal source scans are not an independent penetration test.
