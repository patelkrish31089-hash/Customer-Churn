# Acceptance matrix — advanced local build

**Evidence basis (V15):** 122 passing automated tests (`-W error`); local Uvicorn/authentication/revoked-session smoke; SQLite migration upgrade/downgrade/re-upgrade; isolated SQLite background-job worker E2E; PostgreSQL offline SQL compilation (not server runtime); synthetic training/scoring/retention workflow; 40-request local concurrency smoke; static Compose and CI workflow validation. Current V15 staged acceptance: 15 PASS / 0 FAIL / 10 BLOCKED across 25 unique checks; one shared-interpreter diagnostic is NOT_APPLICABLE. Chromium UI/API bridge and semantic accessibility smoke pass; native browser-origin transport/CORS and full axe-core WCAG certification remain limited. External production controls remain blocked.

| Area | Acceptance item | Result | Evidence / limitation |
|---|---|---|---|
| Foundation | FastAPI import, compile, config and RBAC | PASS | pytest + compile/import + runtime HTTP smoke |
| Database | Fresh SQLite upgrade/downgrade/re-upgrade | PASS | isolated SQLite migration lifecycle |
| Ingestion | CSV/XLSX/JSON through canonical contracts | PASS (local) | import service/API tests; only supported fields/datasets |
| REST source | HTTPS host allowlist, mapping and import path | PASS (contract) | mocked/source unit/API tests; no live third-party source |
| Data quality | Configurable rules, scorecard, finding review/correction | PASS (local) | service/API tests; rule semantics need real-source approval |
| Churn labels | Customer/subscription scope, 30-day maturity/censoring | PASS (local logic) | boundary and censoring tests; policy still needs business sign-off |
| Features | Cutoff-bound v2.1 and currency separation | PASS (local logic) | tests; online feature store not implemented |
| EDA/cohort/survival | Descriptive EDA, cohort curves, KM/Greenwood CI | PARTIAL | tests; advanced slices, cell intervals, competing risks remain |
| ML training | LR/RF/XGBoost/LightGBM when available, calibration | PASS (local pipeline) | 4-family availability test; optional dependencies vary by environment |
| Evaluation | Threshold, metrics, cost and uncertainty outputs | PARTIAL | costs user-supplied; small synthetic data not generalization evidence |
| SHAP | Local/global explanation path | PARTIAL | optional SHAP path; stability/governance not certified |
| Prediction | Single and batch idempotent/partial retry | PASS (local path) | tests; scheduled distributed scoring not operational |
| Customer 360 | Multi-source timeline and currency separation | PARTIAL | service/API tests; identity survivorship and full UI masking remain |
| Retention | Playbooks, assignments, experiment and outcome maturity | PARTIAL | service/API tests; no causal uplift claim |
| CRM | Provider-specific Salesforce/HubSpot/Intercom adapters | BLOCKED live | mocked contract tests only; no account/OAuth grant/webhook |
| MLOps | MLflow/Airflow/Evidently adapters and PSI | PARTIAL/BLOCKED | source and status checks; no tracking server/scheduler runtime |
| Deployment | PostgreSQL Compose definition | PARTIAL | YAML static validation passed; Docker/Postgres runtime not tested |
| Browser | Chromium login/navigation/upload/customer 360/logout + semantic accessibility smoke | PASS (qualified local bridge) | `reports/browser_bridge_e2e_evidence.json`; native browser-origin HTTP/CORS and full axe-core scan not covered |
| Load | 40 requests / concurrency 10 | PASS (smoke only) | local container timing; not production capacity evidence |
| Security | Authentication/RBAC/secret-pattern tests | PARTIAL | no independent audit, SAST/DAST, pip-audit or penetration test |
| Recovery | SQLite backup and restore | PASS (SQLite) | tests; PostgreSQL recovery drill absent |
| Final release | All 20 phases fully accepted | NOT MET | 122 tests; 15 PASS / 0 FAIL / 10 BLOCKED across 25 unique gates; phase coverage remains partial, and external dependencies and policy approval remain open |


## V14 additions

| Area | New implementation | Evidence | Limitation |
|---|---|---|---|
| Reports | Permission-filtered CSV/JSON export for platform, customer, prediction, model, retention, quality, import, cohort, survival and audit datasets | `tests/test_v14_reports_admin.py`; browser bridge export journey | Current persisted local records only; not a BI warehouse or scheduled report service |
| Administration | Admin-only user listing, create/deactivate/reactivate, self-deactivation guard, audit event listing | API tests and browser UI create/audit flow | No SSO/OIDC, MFA, tenant isolation or enterprise identity lifecycle |
| Fairness review | Exact mature-label join and descriptive group selection/precision/recall/FPR metrics with Wilson selection-rate interval and small-group status | Unit/API regression tests | Requires authorized data and qualified policy review; not a legal certification |
| Feature store | Read immutable snapshot by exact customer/cutoff/feature version | API regression test | No online cache, distributed store or high-volume materialization scheduler |


## V14.1 additions

| Area | New implementation | Evidence | Limitation |
|---|---|---|---|
| ML dataset preparation | Readiness audit of exact mature uncensored label-to-snapshot joins; horizon/event-date consistency; chronological train/validation/test partitions; per-feature missingness; stable dataset fingerprint; PII-free result | `app/services/dataset_audit.py`; `tests/test_v14_reports_admin.py`; `reports/browser_bridge_e2e_evidence.json` | Source-level event timestamps cannot be reconstructed from opaque historical fingerprints; company extract lineage still requires source evidence |
| Training safety | Training dataset assembler now excludes labels with future maturity dates, incorrect maturity windows, positive events outside the event horizon, negative labels with event dates, missing snapshots or malformed feature payloads | `app/services/ml.py`; strict regression suite | Dataset readiness is not real-world performance, causal impact, fairness certification or business approval |


## V15 additions — durable background jobs

| Area | New implementation | Evidence | Limitation |
|---|---|---|---|
| Job persistence | Database-backed job records, idempotency key/payload hash, priority, attempt count, lease owner/expiry, progress, result and error metadata | Alembic migration `20261107_jobs`; `tests/test_background_jobs.py` | PostgreSQL multi-process locking is not runtime-certified in this workspace |
| Worker lifecycle | Separate worker process, claim/lease, heartbeat, expired-lease recovery, bounded retry/backoff, lease fencing and safe import cleanup | `app/worker.py`; isolated SQLite end-to-end evidence in `reports/sqlite_worker_queue_evidence.json` | SQLite evidence is single-worker only; production multi-worker proof requires live PostgreSQL and Docker |
| Dashboard workflows | Queue imports, labels, feature builds, quality audits, model training, batch scoring, retention generation and REST source sync; Jobs screen shows status, progress and retry/cancel controls | Browser bridge E2E and API/service tests | Provider credentials, high-volume production load and real source-system contracts remain outside local scope |
| Evidence | Runtime stage includes isolated real SQLite worker execution; Docker/PostgreSQL evidence importer requires persisted job and worker-survival checks | `reports/verification_runtime.json`, `reports/verification.json` | A local queue pass cannot close PostgreSQL or Docker production gates |

Fresh V15 aggregate: **15 PASS / 0 FAIL / 10 BLOCKED across 25 unique checks**; strict pytest: **122 passed / 0 failed / 0 skipped**. The 10 production blockers and their evidence owners are listed in `docs/verification/V15_GATE_CLOSURE_CHECKLIST.md`.
