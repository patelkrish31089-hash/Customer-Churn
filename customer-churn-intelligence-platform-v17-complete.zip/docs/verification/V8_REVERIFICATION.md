# V8 re-verification record

Generated: 2026-11-07 (UTC; exact timestamp is recorded in `reports/verification.json`).

## Result

**13 PASS / 0 FAIL / 10 BLOCKED across 23 unique acceptance checks**, plus one unrelated `NOT_APPLICABLE` host diagnostic. The regression suite passed **83 tests** with warnings treated as errors.

## Freshly executed stages

| Stage | Checks passed | Failed | Blocked | Evidence |
|---|---:|---:|---:|---|
| Core | 5 | 0 | 0 | `reports/verification_core.json`, `reports/junit.xml` |
| Runtime | 2 | 0 | 0 | `reports/verification_runtime.json`, `reports/runtime_http_evidence.json`, `reports/performance_smoke.json` |
| Database/deployment static | 4 | 0 | 0 | `reports/verification_migrations.json`, SQLite migration and PostgreSQL offline SQL evidence |
| Synthetic workflow | 1 | 0 | 0 | `reports/verification_synthetic.json`, `reports/synthetic_workflow_evidence.json` |
| Chromium browser | 1 | 0 | 0 | `reports/verification_browser.json`, `reports/browser_bridge_e2e_evidence.json` |
| **Total local acceptance gates** | **13** | **0** | **0** | `reports/verification.md` and `reports/verification.json` |

The separately evaluated external/environment gates remain **10 BLOCKED**. The report deduplicates by acceptance gate; missing packages are listed under their parent gate rather than counted separately.

## Regression and runtime evidence

- `python -m pytest -q -W error --junitxml=reports/junit.xml`: **83 passed**.
- Python compilation, FastAPI import and frontend JavaScript syntax checks passed.
- Local Uvicorn startup, health/readiness, authentication, identity, logout revocation and graceful shutdown passed.
- 40 authenticated HTTP requests at concurrency 10 returned HTTP 200. This small smoke is not a production capacity or SLA benchmark.
- Fresh SQLite Alembic upgrade → downgrade → re-upgrade passed; 30 tables and foreign-key integrity were checked.
- PostgreSQL dialect DDL and Alembic offline migration SQL compilation passed. No PostgreSQL server transaction or driver connection was performed.
- Docker Compose static validation passed. No Docker daemon was available.
- The CI workflow contract test passed; the workflow itself has not been executed on a remote GitHub Actions runner from this workspace.
- Synthetic workflow generated 120 demo customers, trained/approved a candidate, generated 120 predictions and 26 retention recommendations. These are pipeline-execution checks only, not real-world predictive or causal evidence.
- Chromium E2E through an in-memory document and host-side API bridge passed: login, all seven dashboard sections, CSV upload, customer read-back, Customer 360 and logout. Semantic accessibility smoke scanned 10 views and 131 visible controls without unnamed controls or missing image alternatives. Native browser-origin CORS/network behavior and full axe-core/WCAG audit were not established by this bridge run.

## Remaining 10 blocked gates

Five technical gates require services or tools unavailable on this workspace: PostgreSQL runtime, Docker runtime/recovery, clean isolated installation, MLflow/Airflow/Evidently runtime, and Ruff/Bandit/pip-audit execution. Five additional gates require external authority or independent evidence: live CRM sandbox, hosted staging, authorized real-company outcome data, business churn-policy sign-off, and independent penetration testing.

The host inventory in `reports/host_environment_inventory.json` records the actual constraints at this run, including absent PostgreSQL server tools, Docker CLI/daemon, optional MLOps and scanner packages, package-index DNS unavailability and absence of configured provider/hosting credentials. Secret values are never read or reported.

## Release decision

**V8 passes for controlled local development, synthetic demonstration and the tested Chromium UI workflow. It is not full 20-phase acceptance and is not approved for staging or production.** Do not mark any blocked gate PASS without the named evidence in `docs/verification/GATE_CLOSURE_CHECKLIST.md`.
