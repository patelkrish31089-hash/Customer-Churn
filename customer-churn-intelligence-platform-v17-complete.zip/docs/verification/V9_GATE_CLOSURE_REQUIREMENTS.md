# V9 — exact closure requirements for the ten blocked gates

Do not change a gate to PASS until its specific evidence exists, is reviewed and identifies the tested source revision, date and environment.

| Gate | Exact evidence required | Who must provide or execute it |
|---|---|---|
| PostgreSQL runtime | Connect using the declared psycopg driver; run Alembic head → base → head; CRUD; foreign-key/unique constraint failures; Numeric(18,2) precision; transaction rollback; readiness; login/logout/session revocation; attach sanitized logs and JUnit | Platform engineer on a PostgreSQL-enabled runner |
| Docker runtime | `docker compose build/up`; health/readiness; authenticated API; restart persistence; `pg_dump`; restore into a second database; verify restored rows; teardown; retain logs | DevOps engineer on a Docker-enabled runner |
| Clean virtual-environment installation | Fresh supported Python environment; install every required dependency group from declared manifests; `pip check`; compile/import; 83+ regression tests; frontend syntax; record exact versions and install logs | Build engineer with package-index access |
| MLOps runtime | Install supported MLflow/Evidently/Airflow versions; MLflow parameter/metric/artifact write and read-back; Evidently drift report; execute Airflow scoring DAG; persisted batch state, retry and idempotency checks | ML platform engineer on a runner with package access and required services |
| Quality/security toolchain | Ruff lint; Bandit scan; pip-audit against current advisory data; archive full logs; remediate or formally accept findings; rerun regression tests | Application security engineer with package/advisory access |
| Live CRM provider sandbox | Provider-specific test tenant; least-privilege OAuth; map a test identity; create/read-back/reconcile one task/note; validate webhook signature; cleanup; retain sanitized provider evidence | CRM administrator; secrets only in a secret manager |
| Hosted staging deployment | Authorized host/project/domain/TLS; isolated persistent PostgreSQL; secret store; migrations; liveness/readiness; RBAC; restore/rollback; deployment logs and URL | Deployment owner with explicit authorization |
| Real-company model validation | Governed authorized data; data provenance and approval; matured churn outcomes; temporal holdout; calibration, subgroup, threshold and SHAP stability review; model utility approval | Data owner and ML lead |
| Business churn-policy sign-off | Signed/versioned policy for effective cancellation event, horizon, pauses, grace periods, reactivations, involuntary churn, competing events and censoring | Product/business owner |
| Independent penetration test | Written test scope and authorization; independent assessment; severity-rated findings; remediation references; independent retest statement | Qualified independent security assessor |

## Current workspace findings

The host has no Docker CLI/daemon, PostgreSQL server tools or psycopg module; no MLflow, Airflow, Evidently, Ruff, Bandit or pip-audit modules; no package-index DNS; no GitHub CLI/token; and no provider, database or staging credentials. The clean-install attempt was run in a newly created virtual environment and failed because no package versions were reachable from the index. The exact output is retained in `reports/clean_install_attempt.txt`.

The project already contains hosted GitHub Actions jobs for PostgreSQL, Docker, browser/accessibility, MLOps and Airflow. A static check of the workflow contract passes, but no remote workflow run has been performed from this workspace. Workflow configuration is not runtime evidence.

## Security and data handling

Never put credentials, refresh tokens, webhook signing secrets, private company data or personal customer data in the ZIP, source control, chat, or CI logs. Use least-privilege, revocable credentials in the provider/hosting secret manager. Real company model evidence must be retained in the organization's approved data environment, not generic build artifacts.
