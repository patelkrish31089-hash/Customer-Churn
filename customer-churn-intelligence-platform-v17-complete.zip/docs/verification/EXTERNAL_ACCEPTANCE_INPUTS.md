# External acceptance inputs

Do not place secrets in source control, issue comments, project ZIPs or chat. Supply them through an approved secret manager or protected CI environment.

## CRM provider sandbox

Provider adapter configuration is read at runtime:

| Provider | Required configuration | Additional acceptance |
|---|---|---|
| Salesforce | `SALESFORCE_INSTANCE_URL`, `SALESFORCE_ACCESS_TOKEN`, `SALESFORCE_API_VERSION` | Approved OAuth integration/user, exact public instance host, Task permissions, and `ExternalIdentity` mapping to a Salesforce Contact/Lead ID. `SALESFORCE_ALLOWED_HOSTS` is only for an explicitly approved exact host. |
| HubSpot | `HUBSPOT_PRIVATE_APP_TOKEN`, `HUBSPOT_CONTACT_ASSOCIATION_TYPE_ID` | Approved private app scopes and a real test contact mapping. `HUBSPOT_API_VERSION` defaults in the adapter and must be confirmed against the portal's current API version. |
| Intercom | `INTERCOM_ACCESS_TOKEN` | Approved app scopes and a real test contact mapping. `INTERCOM_API_VERSION` defaults in the adapter and must be confirmed against the workspace's supported version. |

For every provider, record the sandbox tenant, test record IDs, API request/response metadata with secrets redacted, create/read-back result, webhook verification and cleanup. Do not claim the provider is connected merely because a token environment variable is set.

## Churn policy and governed model data

The source specification defines a 30-day forward target and requires both customer-level and subscription-level labels; it also distinguishes voluntary, involuntary, other/unknown, positive, negative and censored outcomes. A company owner must still approve the operational interpretation for pauses, grace periods, effective termination, late payment, reactivation and parent-customer aggregation.

Required datasets should include authorized customer, subscription, invoice, payment, product usage and support history, source IDs, event timestamps and data availability/ingestion timestamps. Label outcomes must have a fully observed 30-day horizon. Do not train or report real-company metrics from synthetic or unapproved data.

## Hosted staging and independent security

The owner must choose the hosting provider and authorize the deployment. Required evidence includes the environment identity, domain/TLS, secret-store references, PostgreSQL version, migration run, health/readiness, login/RBAC, logs, backup and restore, rollback and data-retention procedure.

An independent assessor must receive written authorization and a defined test scope. Record findings, severity, remediation commit, retest outcome and report provenance. Internal Bandit, dependency audit or test results are not a penetration test.

## Running the acceptance workflow

1. Put this project into the authorized private Git repository.
2. Enable GitHub Actions and ensure the repository allows the workflow's read-only `contents` permission and artifact uploads.
3. Run **Actions → full-platform-acceptance → Run workflow** (or push a branch / open a pull request).
4. Wait for each job to complete, then download its artifact bundle. A green workflow is required for PostgreSQL, Docker, browser, MLOps and Airflow execution claims.
5. Add the separately authorized CRM, company-data, business-policy, staging and independent-assessor evidence to the release review. Never use placeholder credentials or test-only adapters to close those gates.
