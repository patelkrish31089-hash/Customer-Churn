# Gate closure checklist — V10

V10 has **10 unique blocked acceptance gates**. The local browser UI workflow gate is now PASS using Chromium with a test-only host-side API bridge to the real local FastAPI process. That browser run covers login, all seven dashboard views, CSV import, customer read-back, Customer 360 and logout, plus a semantic accessibility smoke over 10 views and 131 visible controls. Native browser-origin HTTP/CORS and axe-core/full WCAG scanning remain limitations, not a reported pass.

A gate may be changed to PASS only after its named evidence exists, has been reviewed, and identifies the tested commit/environment. Do not mark workflow configuration, a unit mock, synthetic dataset or provider logo as live integration evidence.

## Hosted technical execution

- [ ] PostgreSQL runtime — migration round-trip, CRUD, foreign-key/unique constraints, Numeric(18,2) precision, transaction rollback, persistence, readiness, login/logout and revocation against PostgreSQL.
- [ ] Docker runtime/recovery — Compose build/start, readiness, authenticated API, restart persistence, `pg_dump`, restore into a separate DB, restored-row verification and teardown.
- [ ] Clean isolated installation — supported Python version, fresh virtual environment, install all required extras, `pip check`, regression suite and frontend syntax check.
- [ ] MLOps runtime — MLflow artifact/parameter read-back, Evidently report generation, Airflow DAG task execution, persisted `PredictionBatch`, retry/idempotency evidence.
- [ ] Quality/security scanner toolchain — Ruff, Bandit and pip-audit execution logs; each critical/high finding resolved or formally accepted by the security owner.

## External business/provider acceptance

- [ ] Live CRM — authorized sandbox tenant, least-privilege OAuth, real test identity mapping, create/read-back/reconciliation, webhook signature validation and cleanup. Never put secrets in Git or this ZIP.
- [ ] Hosted staging — authorized project, domain/TLS, secret store, isolated PostgreSQL, migration, health/readiness, authentication/RBAC, backup/restore and rollback evidence.
- [ ] Real-company model validation — authorized and governed customer, subscription, invoice, payment, usage and support history; mature outcomes; temporal holdout; calibration, subgroup and SHAP stability review.
- [ ] Churn-policy sign-off — business owner approves effective event date, 30-day horizon, pause/grace periods, cancellations, reactivations, involuntary churn and censoring semantics.
- [ ] Independent penetration test — written scope and authorization, independent report, severity assessment, remediation references and retest evidence.

## Evidence intake rules

1. Record workflow run ID, commit SHA, timestamp, runner image and artifact name for hosted checks.
2. Redact access tokens, webhook secrets, personal data and private URLs from shared logs.
3. Keep synthetic and real-company evidence in separate folders and identify provenance.
4. Do not use generated demo metrics to close the real-company validation gate.
5. Do not use internal tests to close the independent penetration-test gate.
6. Re-run affected regression tests after every remediation.


See `V10_GATE_CLOSURE_PLAN.md` for accountable owners, exact closure evidence and safe execution steps.


## V10 supplemental updates

V10 fixes explicit pytest-asyncio fixture-loop configuration and now records 87 strict regression tests. The new first-party AST security smoke reports zero findings and runs in hosted CI in addition to Ruff, Bandit and pip-audit. It does not close the full quality/security gate. See `V10_REVERIFICATION.md` and `V10_GATE_CLOSURE_PLAN.md`.
