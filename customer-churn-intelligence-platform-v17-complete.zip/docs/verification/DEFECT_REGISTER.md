# Defect register and repair evidence

| ID | Severity | Finding | Root cause | Repair / current behavior | Evidence | Status |
|---|---|---|---|---|---|---|
| DEF-001 | High | One bad CSV row could roll back other accepted rows. | Batch rollback applied after row errors. | Per-row nested transactions/savepoints and explicit issues. | import quarantine/API tests | Fixed |
| DEF-002 | High | Naive SQLite datetimes could conflict with UTC-aware values. | SQLite timezone metadata round-trip. | Normalize stored timestamps at service boundary. | labels/features/Customer 360 tests | Fixed |
| DEF-003 | High | Different currencies could be summed in an analytical feature. | Unscoped numeric aggregation. | Currency-specific totals and scalar aggregates only when single-currency. | feature and Customer 360 currency tests | Fixed in tested paths |
| DEF-004 | High | Customer and subscription labels could collide semantically. | Label key lacked an explicit scope. | Distinct entity scope/ref and scope-aware uniqueness. | label scope tests | Fixed |
| DEF-005 | Medium | Held-out test partition could influence model selection. | Validation/test separation insufficiently explicit. | Candidate and threshold selection use validation; final test used after selection. | chronological model training tests | Fixed in implemented path |
| DEF-006 | Medium | Unapproved candidate could be used in inference. | Candidate/active release boundary was not enforced. | Approval state required for inference; admin rollback supported. | release guard/rollback tests | Fixed in local path |
| DEF-007 | Medium | Global importance could be mistaken for individual SHAP or causality. | Fallback explanation label was ambiguous. | Explanation method/status and limitations are explicit; SHAP optional. | SHAP/fallback tests | Improved; governance partial |
| DEF-008 | Medium | CRM sandbox execution could lack customer consent or idempotency. | Side-effect guard incomplete. | Requires approval, consent, idempotency; sandbox explicitly simulated. | sandbox tests | Fixed in sandbox path |
| DEF-009 | Low | Migration behavior was not reproducibly evidenced. | No lifecycle gate. | Fresh SQLite upgrade/downgrade/re-upgrade verification. | Alembic migration checks | Fixed for SQLite |
| DEF-010 | High | Production session digest did not use configured secret. | Secret setting not cryptographically applied. | HMAC-SHA256 session digest in staging/production; missing secret rejected. | config/session tests | Fixed locally; key rotation invalidates sessions |
| DEF-011 | Medium | Frontend dashboard JavaScript had a syntax error. | Nested template-literal change. | Renderer simplified; syntax check gate added. | `node --check` | Fixed |
| DEF-012 | High | Feature aggregations were not sufficiently currency-safe and lacked key invoice/payment recency/frequency. | Earlier feature contract omitted these dimensions. | Feature v2.1 adds invoice/payment RFM fields and currency-specific aggregates; cohort current month checkpoints use observed month-end. | feature version, currency, cohort boundary tests | Fixed in current implementation; full taxonomy partial |
| DEF-013 | Medium | A monolithic verification invocation did not complete reliably in the shared execution environment. | Long ML and subprocess chains interfered with runner time limits. | Verifier split into isolated, time-bounded stages; each stage writes timestamped JSON evidence and final aggregator labels missing stages BLOCKED. | `reports/verification_*.json`, `reports/verification.json` | Mitigated; stages passed independently |
| DEF-014 | Medium | LightGBM received inconsistent feature-name containers during preprocessing. | Transformer outputs changed between pandas and ndarray. | Preprocessing pipeline uses stable pandas output names for the estimator contract. | strict-warning ML regression tests | Fixed locally |
| DEF-015 | High | REST source fetch could trust private DNS answers or read an unbounded body. | URL allowlist alone did not constrain resolved address or response size. | Non-public DNS answers rejected in production-created source client; redirects/proxy env trust disabled; streamed response capped at 25 MiB. Network egress policy and DNS pinning remain deployment controls. | `tests/test_advanced_features.py` REST security tests | Hardened locally; network layer remains |
| DEF-016 | High | CRM provider requests could accept redirect behavior or unsafe Salesforce instance origins. | Provider URL validation/redirect behavior was insufficiently explicit. | HTTPS origin and hostname restrictions; provider redirects rejected; Intercom path IDs encoded. OAuth/webhook/token-vault security still requires live integration review. | `tests/test_advanced_features.py` CRM security tests | Hardened locally; live verification blocked |

## Environment / external blockers

| ID | Severity | Blocker | Required action | Status |
|---|---|---|---|---|
| ENV-001 | Medium | Shared Python environment conflict: moviepy 2.2.1 expects Pillow <12; host contains 12.3.0. | Create clean project virtual environment; do not alter unrelated global dependencies. | Blocked (host only) |
| ENV-002 | High | Docker CLI/daemon unavailable. | Run Compose build/start/health on Docker host. | Blocked |
| ENV-003 | High | CRM credentials/accounts/scopes/webhooks unavailable. | Install and test provider OAuth/sandbox contracts and external action reconciliation. | Blocked live |
| ENV-004 | High | MLflow/Airflow/Evidently services not installed/configured. | Provision pinned compatible services, run end-to-end orchestration and tracking. | Blocked runtime |
| ENV-005 | High | Chromium admin policy prevents local navigation. | Run browser E2E in an authorized desktop/CI browser runner. | Blocked |
| ENV-006 | High | No authorized real-company customer data or mature outcome labels. | Obtain governed dataset and execute independent temporal holdout/prospective evaluation. | Blocked |
| ENV-007 | High | PostgreSQL driver/server runtime unavailable. | Provision PostgreSQL and run migrations, transaction isolation, backup/restore and API tests. | Blocked |
