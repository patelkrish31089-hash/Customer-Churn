# V11 re-verification record

Generated: 2026-11-07. Machine-readable timestamps, commands and outputs are recorded in `reports/verification*.json` and the evidence files they reference.

## Result

**14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance gates**, plus one unrelated `NOT_APPLICABLE` shared-interpreter diagnostic.

The strict regression suite completed **93 passed, 0 failed, 0 errors, 0 skipped** with warnings treated as errors. The local verification sequence completed all five stages: core, runtime, migrations/deployment, synthetic workflow and Chromium UI bridge.

## Work completed in V11

1. Added `scripts/clean_install_acceptance.py`. It creates a new Python virtual environment with system site packages disabled, installs the complete declared dependency groups, runs `pip check`, compiles application/tests/scripts, executes strict pytest and checks the frontend JavaScript. It stores step logs and a JSON acceptance report. The hosted workflow runs it separately on Python 3.11 and 3.12.
2. Added `scripts/quality_security_acceptance.py`. It independently executes `pip check`, Ruff, Bandit, pip-audit and the supplemental AST source scanner, retaining individual tool logs and a structured report.
3. Updated `.github/workflows/ci.yml`. Clean installation and quality/security checks are now independent of PostgreSQL availability. The workflow has seven acceptance jobs and uploads evidence with `if: always()`.
4. Expanded `scripts/ci_workflow_check.py` to verify both new jobs, the Python matrix, dependency groups, test harnesses and per-job evidence uploads.
5. Added a provenance-checked hosted evidence importer that rejects mixed workflow attempts, repositories, commits, failed jobs and incomplete payloads before it can close technical gates.
6. Made the Docker runtime job independent of the PostgreSQL matrix and added regression tests for clean-install inventory capture and hosted-evidence provenance.
7. Added `V11_GATE_REMEDIATION.md` and `EXTERNAL_SIGNOFF_TEMPLATES.md` with execution steps and business/CRM/staging/data/security approval records.

## Fresh local stage evidence

| Stage | Result | Evidence |
|---|---:|---|
| Core | 6 PASS, 0 FAIL, 1 not-applicable host diagnostic | `reports/verification_core.json`, `reports/junit.xml`, `reports/source_security_smoke.json` |
| Runtime | 2 PASS, 0 FAIL | `reports/verification_runtime.json`, `reports/runtime_http_evidence.json`, `reports/performance_smoke.json` |
| Migrations and CI contract | 4 PASS, 0 FAIL | `reports/verification_migrations.json`, `reports/migration_lifecycle_evidence.json`, `reports/postgresql_offline_migration_evidence.json`, `reports/deployment_compose_check.json`, `reports/ci_workflow_contract_evidence.json` |
| Synthetic workflow | 1 PASS, 0 FAIL | `reports/verification_synthetic.json`, `reports/synthetic_workflow_evidence.json` |
| Chromium UI/API bridge | 1 PASS, 0 FAIL | `reports/verification_browser.json`, `reports/browser_bridge_e2e_evidence.json` |
| **Total local gates** | **14 PASS, 0 FAIL, 10 BLOCKED** | `reports/verification.json`, `reports/verification.md` |

The local API smoke verified liveness/readiness, dashboard response, login, authenticated identity, logout, revoked-session rejection and graceful shutdown. The HTTP smoke completed 40 authenticated requests at concurrency 10 with HTTP 200. SQLite migrations upgraded, downgraded and re-upgraded with 30 tables and zero foreign-key violations. The synthetic pipeline created 120 synthetic customers and exercised labels, features, training, prediction and retention. Synthetic model metrics are not real-company performance claims.

Chromium tested login, all seven dashboard views, CSV upload, customer read-back, Customer 360 and logout. The semantic accessibility smoke covered 10 views and 131 visible controls. This was a host-side API bridge: native browser-origin CORS/navigation and a full axe-core/WCAG audit were not tested locally.

## Ten blocked gates remain unchanged

The current environment lacks the runtimes/toolchains or external authority needed to produce the missing evidence:

1. **PostgreSQL runtime** — PostgreSQL server tools and psycopg runtime driver are absent. Only PostgreSQL offline DDL generation has passed.
2. **Docker runtime** — Docker CLI/daemon are absent. Compose static validation is not a runtime pass.
3. **Clean isolated install** — package-index DNS is unavailable in this workspace. The new fresh-venv harness is ready for hosted execution but has not been completed here.
4. **MLOps runtime** — MLflow, Evidently and Airflow are not installed/configured locally. Their hosted runtime jobs have not yet executed.
5. **Quality/security toolchain** — Ruff, Bandit and pip-audit are not installed locally. The AST smoke is supplemental only; the independent hosted scanner job has not run.
6. **Live CRM provider sandbox** — no authorized Salesforce, HubSpot or Intercom sandbox credentials/scopes were provided.
7. **Hosted staging deployment** — no hosting project, domain/TLS, secret manager or deployment authorization was provided.
8. **Real-company model validation** — no authorized company dataset with mature churn outcomes was provided.
9. **Business churn-policy sign-off** — the relevant product/business owner has not signed off effective cancellation, reactivation, pauses, grace periods, involuntary churn and censoring semantics.
10. **Independent penetration test** — no independently authorized assessor report, remediation and retest evidence was supplied.

## Remote acceptance procedure

Use `docs/verification/V11_GATE_REMEDIATION.md` after this exact project revision is pushed to the authorized private repository. Run **Actions → full-platform-acceptance → Run workflow**, review the artifacts and logs, extract artifacts from one run, then execute `scripts/merge_hosted_evidence.py` followed by `python scripts/verify.py --stage report`. Only a complete, same-run, same-attempt, same-commit, same-repository, reviewer-attributed artifact set can update the five technical gates from `BLOCKED` to `PASS`.

Use `docs/verification/EXTERNAL_SIGNOFF_TEMPLATES.md` for the five owner/assessor records. CRM, staging, real-data, business-policy and independent penetration gates cannot be self-certified by local code or synthetic tests.

## Release decision

V11 improves verification readiness and evidence capture. It does not certify all 20 roadmap phases or production readiness. The current project is suitable for controlled local development and synthetic demonstration; staging and production remain **NOT APPROVED** until all required technical and external acceptance evidence is reviewed.
