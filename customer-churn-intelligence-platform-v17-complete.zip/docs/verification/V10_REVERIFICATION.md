# V10 re-verification record

Generated: 2026-11-07 (UTC). The exact timestamp and per-check durations are recorded in `reports/verification.json`.

## Result

**14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance checks**, plus one `NOT_APPLICABLE` shared-host diagnostic.

The strict automated regression suite records **87 passed, 0 failed, 0 errors, 0 skipped** with warnings treated as errors. The exact command is:

```bash
PYTHONWARNINGS=error python -m pytest -q -W error --junitxml=reports/junit.xml
```

## Defect fixed in V10

A direct fresh invocation of V9's strict test command initially failed before test collection because `pytest-asyncio` had no configured default fixture event-loop scope. V10 sets the following in `pyproject.toml`:

```toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
asyncio_default_fixture_loop_scope = "function"
```

A regression test asserts both settings so a future dependency upgrade cannot silently reintroduce this startup failure. The strict suite then passed with warnings treated as errors.

## New supplemental source-security check

V10 adds `scripts/source_security_smoke.py`, a standard-library AST scan of first-party Python source. It checks for selected high-risk constructs including `eval`/`exec`, `os.system`, `subprocess` with `shell=True`, unsafe pickle/dill loads, `tempfile.mktemp`, TLS verification bypass and unsafe `yaml.load` calls. The scanner itself is tested with intentionally unsafe fixtures. The first-party app scan found **zero findings**.

This scanner is supplemental only. It is not a replacement for Ruff, Bandit, pip-audit, a complete secrets scanner, code review or penetration testing. The CI workflow now runs this scan alongside the external toolchain when executed on a hosted runner.

## Fresh stage evidence

| Stage | Result | Evidence |
|---|---:|---|
| Core | 6 PASS, 0 FAIL, 1 not-applicable diagnostic | `reports/verification_core.json`, `reports/junit.xml`, `reports/source_security_smoke.json` |
| Runtime | 2 PASS, 0 FAIL | `reports/verification_runtime.json`, `reports/runtime_http_evidence.json`, `reports/performance_smoke.json` |
| Migrations/deployment static checks | 4 PASS, 0 FAIL | `reports/verification_migrations.json`, `reports/migration_lifecycle_evidence.json`, `reports/postgresql_offline_migration_evidence.json`, `reports/deployment_compose_check.json`, `reports/ci_workflow_contract_evidence.json` |
| Synthetic E2E | 1 PASS, 0 FAIL | `reports/verification_synthetic.json`, `reports/synthetic_workflow_evidence.json` |
| Chromium UI bridge | 1 PASS, 0 FAIL | `reports/verification_browser.json`, `reports/browser_bridge_e2e_evidence.json` |
| **Total** | **14 PASS, 0 FAIL, 10 BLOCKED** | `reports/verification.json`, `reports/verification.md` |

## Ten blocked gates and exact status

1. **PostgreSQL runtime** — Offline PostgreSQL SQL generation passes; no PostgreSQL server binaries/service and no `psycopg` driver are present. A real server connection, migration lifecycle, constraints, transactions, money precision, API auth and readiness must still execute on a PostgreSQL runner.
2. **Docker runtime** — Compose static validation passes; no Docker CLI, daemon socket or container runtime is available. Build/up, health, persistence across restart, backup, restore and teardown remain unexecuted.
3. **Clean virtual-environment install** — A new Python 3.13 virtual environment was created. Installing `requirements-dev.txt`, `requirements-advanced-ml.txt` and `requirements-explainability.txt` failed because the configured package index could not resolve/reach its host. Exact fresh V10 output is in `reports/v10_clean_install_attempt.txt`; structured record is `reports/v10_clean_install_attempt.json`.
4. **MLOps runtime** — MLflow, Airflow and Evidently runtime packages/services are not installed in this workspace. The authored adapters and CI runtime jobs are not proof of executed runtime behavior.
5. **Quality/security toolchain** — The local AST security smoke and ordinary regression/static checks pass, but Ruff, Bandit and pip-audit are not installed; current vulnerability advisory data could not be fetched. The combined full toolchain gate remains blocked.
6. **Live CRM provider sandbox** — No authorized Salesforce, HubSpot or Intercom sandbox, OAuth tokens/scopes or webhook secrets are configured. Local adapter contract tests do not constitute provider acceptance.
7. **Hosted staging deployment** — No hosting account, domain/TLS, secret manager or deployment authorization was supplied.
8. **Real-company model validation** — No governed company dataset with sufficiently matured churn outcomes was supplied. Synthetic data only proves pipeline execution.
9. **Business churn-policy sign-off** — Effective cancellation, reactivation, pauses, grace periods, involuntary churn and censoring must be approved by the business owner.
10. **Independent penetration test** — Requires an independently authorized assessor, a defined test scope, findings, remediation and independent retest evidence.

## Reproduction

Execute from the project root. Run each stage separately so timeouts and failures remain visible:

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```

The hosted workflow `.github/workflows/ci.yml` contains PostgreSQL, Docker, browser/accessibility, MLflow/Evidently and Airflow jobs. `python scripts/ci_workflow_check.py` validates the workflow contract locally; this is not evidence that GitHub Actions has run. Remote execution must be triggered in an authorized repository and its artifacts reviewed before changing any blocked status.

## Release decision

V10 is verified for controlled local development, synthetic demonstration, local Uvicorn/authentication, the tested Chromium UI/API bridge, SQLite migration lifecycle and PostgreSQL offline DDL generation. It is **not** full 20-phase acceptance or production approval. Several requirements in Phases 2–17 remain marked Partial in `docs/ROADMAP_COVERAGE.md`.
