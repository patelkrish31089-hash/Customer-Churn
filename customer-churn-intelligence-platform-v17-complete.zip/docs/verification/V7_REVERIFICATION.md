# V7 re-verification record

Generated: 2026-11-07 (UTC; see `reports/verification.json` for exact timestamp)

## Result

**13 PASS / 0 FAIL / 10 BLOCKED across 23 unique acceptance checks**, plus one unrelated `NOT_APPLICABLE` host diagnostic. Regression suite: **83 passed** with warnings treated as errors.

## V7 code corrections discovered by browser execution

1. The Analytics page used an undefined JavaScript identifier (`s`) in its Kaplan–Meier rendering expression. API responses and JavaScript syntax checks were valid, so prior automated API and syntax gates did not detect the runtime page failure. The view now uses the actual `sur` response variable.
2. The dynamic customer search input had no programmatic accessible name. It now has an explicit `aria-label`.
3. Dynamically rendered inputs, selects and textareas now receive an accessible name from their local field label (or placeholder fallback) when no explicit label association or ARIA name exists.
4. A browser-level contract test now checks the Analytics response variable and dashboard accessible-name behavior.

## Browser evidence

`reports/browser_bridge_e2e_evidence.json` records an actual Chromium run against the real FastAPI process using an in-memory document and a host-side API transport bridge. It exercised:

- Login and overview.
- Data hub, customers, analytics, models, retention and operations pages.
- CSV customer import through the dashboard.
- Customer directory read-back of the imported row.
- Customer 360 profile and unified timeline.
- Logout and return to the sign-in view.
- Semantic accessibility smoke over 10 views and 131 visible controls, with no unnamed controls and no images missing `alt` attributes.

Limitations: Chromium native navigation to localhost is restricted by the managed host URL policy. The bridge therefore sends the actual UI's API requests through the test runner, not through browser-origin fetch; native CORS/network behavior is not verified by this run. axe-core is not installed in this workspace, so this is not a full WCAG/axe audit. The hosted CI job is configured to run the native Playwright journey and axe-core scan.

## Other local evidence

- `reports/verification_core.json`: compile, import, JavaScript syntax, 83 regression tests, secret-pattern scan and host diagnostic.
- `reports/verification_runtime.json`: Uvicorn/auth/session lifecycle and 40-request concurrency smoke.
- `reports/verification_migrations.json`: SQLite migration round-trip, PostgreSQL offline DDL compile, Compose static validation and hosted workflow contract.
- `reports/verification_synthetic.json`: seeded synthetic training, approval, batch prediction and retention workflow.
- `reports/verification_browser.json`: Chromium UI/API bridge run.

## Ten remaining gates

Five technical gates require services/tools unavailable on this workspace: PostgreSQL runtime, Docker runtime/recovery, clean isolated installation, MLflow/Airflow/Evidently runtime, and Ruff/Bandit/pip-audit. Five external gates require an authorized CRM sandbox, hosted staging access, governed real-company data with mature churn labels, business-owner churn-policy approval, and independent penetration-test evidence.

## Release decision

V7 is verified for controlled local development, synthetic demonstration and the tested Chromium UI workflow. It is not full 20-phase acceptance or production approval. Read `RELEASE_READINESS.md`, `GATE_CLOSURE_CHECKLIST.md`, `ACCEPTANCE_MATRIX.md`, and `ROADMAP_COVERAGE.md` together.
