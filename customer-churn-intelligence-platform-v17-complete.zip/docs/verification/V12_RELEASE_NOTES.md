# V12 release notes

## Changes from V11

- Added `scripts/run_acceptance.ps1` as a Windows entry point for clean-install, local regression, quality/security, optional native-browser, optional MLOps and optional Docker/PostgreSQL acceptance.
- Added `scripts/merge_local_evidence.py` to validate real machine-local evidence and close only technical gates whose complete evidence is present and passing.
- Added source-tree SHA-256 binding and named reviewer attribution to local gate closure. Any source/config edit invalidates the prior local evidence review.
- Updated `scripts/verify.py` to consume reviewed local evidence without misrepresenting it as hosted CI evidence. Reviewed hosted artifacts take precedence when they are available.
- Added a detailed Windows and external-owner closure runbook.

## Boundaries

- Local evidence does not close live CRM, hosted staging, real-company model validation, business-policy sign-off or independent penetration testing.
- Local Windows acceptance does not install Airflow; the Ubuntu hosted workflow remains the supported Airflow verification path.
- No blocked gate is marked passed merely because a script, mock, static configuration check or remediation plan exists.
