# V10 — step-by-step closure plan for the ten blocked acceptance gates

This plan is intentionally evidence-driven. A gate changes to `PASS` only after its specific acceptance test has executed against the named environment and the resulting sanitized evidence has been reviewed. Static configuration, local mocks, adapter code and synthetic data do not substitute for live acceptance.

## Execution order

### Step 1 — Run hosted technical acceptance jobs

Use an authorized GitHub repository containing this project and run the manually dispatched workflow:

- Workflow: `.github/workflows/ci.yml`
- Name: `full-platform-acceptance`
- Trigger: `workflow_dispatch`

The workflow has explicit jobs for PostgreSQL, Docker Compose, browser/accessibility, MLflow/Evidently and Airflow. Each job uploads evidence with `if: always()`. Inspect all job results and download their artifacts. A green static workflow-contract check does not prove the workflow ran.

### Step 2 — Close PostgreSQL runtime

Run the `backend-postgresql` hosted job. It must provision its `postgres:16-alpine` service and use `postgresql+psycopg://` in `DATABASE_URL`, not SQLite. Required evidence:

- psycopg driver import and real connection;
- Alembic head → base → head on a fresh PostgreSQL database;
- CRUD and relationship operations;
- expected unique/foreign-key constraint failures;
- `Numeric(18,2)` exact-money persistence;
- transaction rollback;
- FastAPI readiness, login, logout and session revocation;
- sanitized logs and JUnit report.

Fix the actual failure indicated by the job logs and rerun the complete job.

### Step 3 — Close Docker runtime and recovery

Run `docker-compose-runtime` on a Docker-enabled GitHub runner or an authorized deployment runner. It must execute `scripts/docker_runtime_smoke.sh` and prove:

- image build and Compose startup;
- DB and app health/readiness;
- authenticated API request;
- persistent customer data after application restart;
- PostgreSQL `pg_dump`;
- restore to a second database;
- comparison of restored data;
- safe teardown and evidence upload.

Compose YAML validation alone is not this gate.

### Step 4 — Close clean installation

On a supported clean Python 3.11/3.12 runner, install all dependency groups exactly as declared by the workflow:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt -r requirements-advanced-ml.txt -r requirements-explainability.txt
python -m pip check
python -m compileall -q app tests scripts
python -m pytest -q -W error --junitxml=reports/junit.xml
node --check app/static/app.js
```

Retain interpreter/package versions and install logs. Do not use `--system-site-packages` as a substitute for a clean installation.

### Step 5 — Close MLOps runtime

Run both `mlops-adapter-runtime` and `airflow-dag-runtime`. Required evidence:

- MLflow experiment, parameter, metric and artifact write/read-back;
- Evidently drift report generated from explicitly synthetic reference/current frames;
- Airflow DAG parsing and actual scoring-task execution;
- persisted prediction batch and idempotent rerun behavior;
- retries/failure handling;
- version and service configuration recorded.

A local PSI calculation or an authored DAG file alone does not pass this gate.

### Step 6 — Close quality/security toolchain

Run the hosted job with current package advisory access:

```bash
ruff check app tests scripts
bandit -q -r app -ll
pip-audit -r requirements-dev.txt -r requirements-advanced-ml.txt -r requirements-explainability.txt
python scripts/source_security_smoke.py
```

Review all findings, remediate them or record a formally accepted exception with owner and expiry, then rerun the strict regression suite. V10's AST scanner is supplemental, not a substitute for the three listed tools.

### Step 7 — Close live CRM sandbox

For at least one provider at a time, an administrator must supply an authorized sandbox tenant and configure least-privilege credentials in the CI/provider secret manager (never in this ZIP, chat or Git). Execute a provider-specific test that maps a synthetic test contact, creates a task/note, reads it back, reconciles external IDs, validates webhook signatures where enabled, and removes test artifacts. Record provider version/scopes and sanitized request/response evidence. Repeat for each provider claimed as supported.

### Step 8 — Close hosted staging

A deployment owner must select and authorize the actual host/project/domain, TLS, secret manager and isolated persistent PostgreSQL. Deploy the exact tested release, apply migrations, run readiness and RBAC checks, exercise backup/restore and rollback, and record deployment URL, commit/release digest and logs. No hosting provider has been assumed by this project.

### Step 9 — Close real-company model validation

The data owner must approve data use and provide a governed dataset inside the organization's approved data environment. The ML lead must establish the approved churn target and matured outcome window, preserve source lineage, produce a leakage-safe chronological holdout, and review calibration, subgroup performance, threshold/cost assumptions, confidence intervals and SHAP stability. Synthetic benchmark results cannot close this gate.

### Step 10 — Close policy and independent security approvals

The product/business owner signs and versions the churn policy, including effective cancellation semantics, reactivation, pauses, grace periods, involuntary churn and censoring. Separately, an independent security assessor receives written authorization and scope, performs a penetration test, rates findings, verifies remediation and issues an independent retest statement. These approvals cannot be self-certified by the developer or generated by automated tests.

## Gate status policy

| Gate | V10 status | Closure trigger |
|---|---|---|
| PostgreSQL runtime | BLOCKED | Successful actual PostgreSQL hosted job and evidence review |
| Docker runtime | BLOCKED | Successful Compose runtime and backup/restore evidence |
| Clean installation | BLOCKED | Fresh supported Python install from declared dependencies and test pass |
| MLOps runtime | BLOCKED | MLflow/Evidently and Airflow jobs pass with read-back evidence |
| Quality/security tools | BLOCKED | Ruff, Bandit and pip-audit execute and findings are resolved/accepted |
| Live CRM sandbox | BLOCKED | Provider sandbox round-trip and authorization evidence |
| Hosted staging | BLOCKED | Authorized hosted deployment and recovery acceptance |
| Real-company model validation | BLOCKED | Approved data, matured holdout and ML/business review |
| Business churn policy | BLOCKED | Signed/versioned policy approval |
| Independent penetration test | BLOCKED | Independent report, remediation and retest evidence |

No secrets, refresh tokens, customer data or penetration-test details should be added to the source ZIP or public CI artifacts. Use protected secret stores and approved data repositories.
