# V9 re-verification record

Generated: 2026-11-07 (UTC). The exact run timestamp is in `reports/verification.json`.

## Verified result

**13 PASS / 0 FAIL / 10 BLOCKED across 23 unique acceptance checks**, plus one `NOT_APPLICABLE` shared-host diagnostic. The local regression suite reports **83 passed** with warnings treated as errors.

This is a fresh rerun of the staged local checks, not a claim that all 20 project phases are complete or production-approved.

## Fresh stage evidence

| Stage | Result | Evidence |
|---|---|---|
| Core | 5 pass, 0 fail | `reports/verification_core.json`, `reports/junit.xml` |
| Runtime | 2 pass, 0 fail | `reports/verification_runtime.json`, `reports/runtime_http_evidence.json`, `reports/performance_smoke.json` |
| Database / deployment static checks | 4 pass, 0 fail | `reports/verification_migrations.json`, `reports/migration_lifecycle_evidence.json`, `reports/postgresql_offline_migration_evidence.json`, `reports/deployment_compose_check.json` |
| Synthetic workflow | 1 pass, 0 fail | `reports/verification_synthetic.json`, `reports/synthetic_workflow_evidence.json` |
| Chromium browser bridge | 1 pass, 0 fail | `reports/verification_browser.json`, `reports/browser_bridge_e2e_evidence.json` |
| **Total local acceptance checks** | **13 pass, 0 fail** | `reports/verification.json`, `reports/verification.md` |

The pytest JUnit report records **83 tests, 0 failures, 0 errors and 0 skipped**. The Chromium bridge journey covered login, seven dashboard sections, CSV upload, customer read-back, Customer 360 and logout. It uses an in-memory page with a host-side API bridge to the actual local FastAPI server; it does not establish native browser-origin CORS or a full axe-core/WCAG audit.

The direct local HTTP smoke verified application startup, health/readiness, authentication, logout revocation and shutdown. The concurrency smoke completed 40 authenticated requests at concurrency 10. SQLite Alembic upgrade/downgrade/re-upgrade passed. PostgreSQL SQL compilation passed but **no PostgreSQL server was connected**. Compose static validation passed but **no Docker daemon was available**. Synthetic workflow is pipeline-execution evidence only.

## Ten blocked acceptance gates

The ten remain distinct and are supported by the host inventory in `reports/host_environment_inventory.json`:

1. `postgresql_runtime` — no PostgreSQL server/client runtime or psycopg driver was available.
2. `docker_runtime` — no Docker CLI, daemon socket, or alternative container runtime was available.
3. `clean_virtual_environment_install` — package-index DNS was unavailable. A real fresh-venv install was attempted; see `reports/clean_install_attempt.txt`.
4. `mlops_runtime` — MLflow, Airflow and Evidently are not installed/configured in the runner.
5. `quality_and_security_toolchain` — Ruff, Bandit and pip-audit are not installed and package-index DNS prevents installation.
6. `live_crm_provider_sandbox` — no authorized provider sandbox, OAuth grant or webhook secret was supplied.
7. `hosted_staging_deployment` — no hosting account, domain/TLS or deployment authorization was supplied.
8. `real_company_model_validation` — no authorized company dataset with sufficiently mature outcomes was supplied.
9. `business_churn_policy_signoff` — no authorized product/business owner has approved the label policy.
10. `independent_penetration_test` — no independent assessor report and retest evidence were supplied.

These conditions are not software defects that can be resolved by editing status fields. See `V9_GATE_CLOSURE_REQUIREMENTS.md` for exact closure evidence.

## Reproduction commands

Run from the project root:

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```

## Release decision

**Approved scope:** controlled local development, synthetic demonstration, local HTTP/authentication workflow, SQLite migration lifecycle, PostgreSQL offline DDL compilation, and the tested Chromium bridge journey.

**Not approved:** full 20-phase acceptance, PostgreSQL production compatibility, Docker deployment, live provider connectivity, real-company model performance, hosted staging, or production release.
