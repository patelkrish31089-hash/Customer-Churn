# V6 re-verification record

**Run date:** 2026-11-06 (UTC evidence timestamps are in `reports/verification.json` and the per-stage reports)

## Result

The five local stages were freshly executed in this workspace. The aggregate reports **12 PASS / 0 FAIL / 11 BLOCKED across 23 unique acceptance checks**, plus one `NOT_APPLICABLE` shared-host diagnostic. The regression suite reports **80 passed**, with warnings treated as errors.

This is a current re-verification of the V5 codebase and its evidence; it is not a claim that missing external dependencies have been supplied or that all 20 roadmap phases are now fully implemented.

## Freshly executed stages

| Stage | Result | Evidence |
|---|---|---|
| Core | 5 PASS, 0 FAIL; 1 host diagnostic | `reports/verification_core.json`, `reports/junit.xml` |
| Runtime | 2 PASS | `reports/verification_runtime.json`, `reports/runtime_http_evidence.json`, `reports/performance_smoke.json` |
| Migrations/deployment/CI contract | 4 PASS | `reports/verification_migrations.json`, `reports/migration_lifecycle_evidence.json`, `reports/postgresql_offline_migration_evidence.json`, `reports/deployment_compose_check.json`, `reports/ci_workflow_contract_evidence.json` |
| Synthetic workflow | 1 PASS | `reports/verification_synthetic.json`, `reports/synthetic_workflow_evidence.json` |
| Browser | 1 BLOCKED | `reports/verification_browser.json`, `reports/browser_e2e_evidence.json` |
| Aggregate | 12 PASS, 0 FAIL, 11 BLOCKED | `reports/verification.json`, `reports/verification.md` |

The local regression suite includes **80 tests**. The runtime smoke proves the app starts, health/readiness work, login and identity work, logout revokes the session, and shutdown is graceful. The concurrency smoke is only 40 authenticated requests at concurrency 10; it is not a production load test.

SQLite Alembic upgrade → downgrade → re-upgrade passed. PostgreSQL dialect DDL and offline migration SQL compilation passed, but no PostgreSQL server was contacted. Compose static validation and the GitHub Actions workflow contract check passed, but no Docker daemon or remote GitHub Actions run was available.

The synthetic workflow used 120 generated customers, 120 predictions and 26 retention recommendations. These records and resulting metrics are not real-company evidence. The synthetic sandbox action did not call a real CRM.

## The 11 unique blocked gates

| Gate | Why it remains blocked in this run | Evidence required to close |
|---|---|---|
| Browser E2E and accessibility | Managed Chromium policy has `URLBlocklist: ["*"]` and rejects local app navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. | Successful Playwright browser journey and axe-core results from an authorized runner. |
| Live CRM provider sandbox | No authorized Salesforce, HubSpot or Intercom tenant, OAuth grant, contact mapping or webhook secret. | Provider sandbox create/read-back/reconciliation and webhook-verification evidence. |
| Hosted staging deployment | No hosting project, domain, TLS, secret store or deployment authorization. | Authorized deployment, health, rollback, backup and restore evidence. |
| Real-company model validation | No authorized company dataset with mature target outcomes. | Leakage-safe temporal holdout, calibration, subgroup and explanation-stability review on approved company data. |
| Independent penetration test | No independent assessor or written test authorization/report. | Signed independent assessment and retest evidence for critical/high findings. |
| Business churn-policy sign-off | Operational definitions for pauses, grace periods, effective cancellation, reactivation and censoring are not approved by a business owner. | Documented approval from the authorized business owner. |
| PostgreSQL runtime | `psycopg` and server binaries are absent; no PostgreSQL service is running. | Run `scripts/postgres_runtime_smoke.py` against the PostgreSQL CI service and retain passing evidence. |
| Docker runtime/recovery | Docker CLI and daemon are absent. | Run `scripts/docker_runtime_smoke.sh` on a Docker-enabled runner; verify health, restart persistence and pg_dump restore. |
| Clean isolated install | Package-index DNS fails in this workspace, preventing dependency installation in a fresh virtual environment. | Install from `requirements-dev.txt`, advanced ML and explainability requirements in a clean supported Python environment; run `pip check`. |
| MLOps runtime | MLflow, Airflow and Evidently are not installed/configured. | Successful MLflow/Evidently adapter smoke and Airflow DAG execution with persisted prediction batch evidence. |
| Quality/security scanner toolchain | Ruff, Bandit and pip-audit are absent; no package index is available for installation. | Clean CI lint, SAST and dependency-audit reports, reviewed and remediated. |

## Why these cannot honestly be turned into PASS here

Six gates require a different execution environment or toolchain (browser, PostgreSQL, Docker, clean installation, MLOps services and scanner tools). Five require real external authority or evidence (CRM tenant, hosting authorization, company data, business policy approval and an independent assessor). No application code change can substitute for those resources or attestations.

The workflow `.github/workflows/ci.yml` is configured to execute hosted PostgreSQL, Docker recovery, browser/accessibility, MLflow/Evidently and Airflow checks. `reports/ci_workflow_contract_evidence.json` proves only the workflow structure; it does **not** prove that GitHub Actions has run. Run the workflow in the authorized repository, then review its uploaded artifacts before changing any corresponding gate to PASS.

## Release decision

**Controlled local development and synthetic demonstration: PASS.**

**Full 20-phase acceptance, staging approval and production release: NOT APPROVED.** The roadmap remains partially implemented in several phases; see `docs/ROADMAP_COVERAGE.md` and `docs/verification/ACCEPTANCE_MATRIX.md`.
