# V15 production gate closure checklist

Generated from the V15 project state on 2026-11-07. The current staged report records **15 PASS / 0 FAIL / 10 BLOCKED across 25 unique acceptance checks**. The strict automated regression suite records **122 passed / 0 failed / 0 skipped**. These are local development/acceptance results, not a production approval.

A gate changes from BLOCKED to PASS only when its named acceptance procedure succeeds and the verifier accepts the corresponding evidence for the same source revision. Do not create placeholder evidence, mark a mock/simulator as a live provider, or treat synthetic-data performance as company model accuracy.

## A. Technical runtime and toolchain gates

| Gate | Current state | Closure evidence required | Primary runner / report |
|---|---|---|---|
| PostgreSQL runtime | BLOCKED | Connect to a disposable PostgreSQL 16 instance; apply all migrations; execute CRUD, FK/unique constraints, auth/session checks and an actual worker job. The queue evidence must report `database_dialect=postgresql`. | `scripts/postgres_runtime_smoke.py`, `scripts/worker_queue_smoke.py`; `reports/postgresql_runtime_evidence.json`, `reports/worker_queue_runtime_evidence.json` |
| Docker runtime | BLOCKED | Build and start the actual Compose stack; verify PostgreSQL/API/worker health; enqueue and complete a job; restart API/worker; confirm persisted job result survives restart; exercise backup and restore. | `bash scripts/docker_runtime_smoke.sh`; `reports/docker_runtime_evidence.json` |
| Clean isolated install | BLOCKED | Install the declared dependencies into a new disposable venv on a supported Python 3.11 or 3.12 interpreter with package-index access; run compatibility/import/test steps with logs. Shared global Python `pip check` is not a substitute. | `scripts/clean_install_acceptance.py`; `reports/clean_install_acceptance.json` |
| MLOps runtime | BLOCKED | Start a real MLflow tracking service and Evidently report path; execute Airflow DAG parse and a scheduler/task run; persist run IDs and evidence. | `scripts/mlops_adapter_smoke.py`, `scripts/airflow_dag_runtime_smoke.sh`; `reports/mlops_runtime_evidence.json`, `reports/airflow_runtime_evidence.json` |
| Quality/security toolchain | BLOCKED | Run Ruff, Bandit and pip-audit against the isolated project environment; resolve or document each finding with policy-approved disposition. Supplemental AST/secret-pattern smoke is not a replacement. | `scripts/quality_security_acceptance.py`; `reports/quality_security_acceptance.json` |

### Reproduce the technical acceptance on Windows

Use Python 3.11 or 3.12 and a network-enabled machine. From PowerShell at the project root:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Reviewer Identifier"
```

The standard run creates/uses an isolated project venv, performs a disposable clean-install acceptance, reruns all local stages, and runs the quality/security toolchain. Add `-WithContainers` to execute Docker/PostgreSQL deployment, migration, worker and recovery checks. Add `-WithMLOps` to execute MLflow/Evidently and save runtime evidence. Add `-WithBrowserNative` to perform the browser-native Playwright/axe-core run (requires npm/network access).

On macOS/Linux, use the same Python scripts directly after creating a dedicated venv and installing the declared requirements. For the Compose path, install Docker Engine/Compose and run `bash scripts/docker_runtime_smoke.sh`.

After all evidence exists and a human reviewer has inspected it, run:

```powershell
python scripts/merge_local_evidence.py --reviewed-by "Reviewer Identifier"
python scripts/verify.py --stage report
python scripts/build_manifest.py
```

The local evidence importer checks the current source-tree digest and required report structure. A human reviewer identifier is an audit field, not a substitute for reviewing actual logs. PostgreSQL evidence must come from PostgreSQL, not SQLite. Docker evidence must come from Docker, not Compose YAML parsing.

## B. Company and independent-owner gates

| Gate | Current state | Closure evidence required | Accountable owner |
|---|---|---|---|
| Live CRM provider sandbox | BLOCKED | A company-authorized Salesforce, HubSpot or Intercom sandbox, approved app scopes/OAuth grant, secret-store configuration, test contact mapping, create/read-back/webhook and cleanup evidence with secrets redacted. | CRM administrator / integration owner |
| Hosted staging deployment | BLOCKED | Authorized hosting account/project, deployed immutable commit, domain/TLS, secret-store references, database migration, health/readiness, RBAC/audit, backup/restore, rollback and retention evidence. | Infrastructure / release owner |
| Real company model validation | BLOCKED | Authorized, governed historical data with mature 30-day outcomes and source lineage; frozen temporal holdout; leakage, calibration, subgroup and uncertainty review; approved model card and aggregate-only evidence. | Data owner / ML lead |
| Business churn-policy sign-off | BLOCKED | Written approval of voluntary/involuntary churn, cancellation-effective timestamp, grace periods, pauses, reactivation, parent/subscription scope and censoring rules. | Product / finance / business owner |
| Independent penetration test | BLOCKED | Written test authorization and scope, independent assessor report, severity summary, remediation references and retest outcome. Internal unit tests or static scans cannot satisfy this gate. | Independent assessor / security owner |

Use `docs/verification/EXTERNAL_ACCEPTANCE_INPUTS.md` and `docs/verification/EXTERNAL_SIGNOFF_TEMPLATES.md` for required inputs and sign-off fields. Do not add credentials, raw company data, customer PII or penetration-test details to the ZIP or public CI artifacts.

## C. V15 local evidence already passed

- 122 strict regression tests (`-W error`), with zero failures and zero skips.
- Local HTTP startup, authentication, logout and revoked-session behavior.
- 40-request / concurrency-10 local HTTP smoke (not production capacity evidence).
- Actual SQLite queue migration, enqueue, worker claim, handler execution, result persistence and lease release.
- SQLite migration upgrade/downgrade/re-upgrade.
- PostgreSQL offline migration SQL generation (not a live PostgreSQL runtime check).
- Compose static validation and CI workflow contract validation (not container execution or hosted CI execution).
- Synthetic end-to-end model training, approval, scoring and retention execution (not real-company model accuracy).
- Chromium UI/API bridge including Jobs, enqueue/cancel and async import (not native browser-origin network proof or full WCAG certification).

The full stage evidence and exact limitations are in `reports/verification.json` and `reports/verification.md`.
