# V16 release notes

## Added and changed

- Corrected Salesforce default-client DNS validation so internally created production HTTP clients reject private/non-public DNS resolutions before connecting.
- Added a binary retention-experiment sample-size planner with baseline rate, minimum detectable effect, treatment allocation, alpha and power inputs.
- Added immutable standard experiment outcome capture and an admin-only correction route that requires a reason and records previous/new values, actor and timestamp in the audit trail.
- Improved experiment reports to disclose matured assignments, missing/nonbinary outcomes and binary coverage, and to identify estimates as complete-case rather than strict intent-to-treat.
- Added same-run GitHub Actions artifact aggregation with run/attempt/commit/repository provenance checks.
- Prevented an unreviewed aggregation from leaving a stale previously-reviewed closure file that could promote old evidence.
- Added regression tests for each of these changes.

## Fresh verification

- Strict regression suite: **136 passed, 0 failed, 0 skipped** (`pytest -q -W error`).
- Core stage: 6 PASS, 0 FAIL; shared-host `pip check` diagnostic is not applicable and excluded.
- Runtime stage: 3 PASS, 0 FAIL.
- Migration/deployment/CI-contract stage: 4 PASS, 0 FAIL.
- Synthetic ML workflow: 1 PASS, 0 FAIL.
- Chromium UI/API bridge: 1 PASS, 0 FAIL.
- Production gate matrix: **15 PASS / 0 FAIL / 10 BLOCKED across 25 unique checks**.

## Limitations

V16 is a locally verified development/controlled-demo release, not production-accepted. The blocked gates require actual PostgreSQL, Docker, a fresh network-enabled isolated install, MLOps/security toolchains, an authorized CRM sandbox, staging infrastructure, real company data, business policy approval and independent penetration testing. Synthetic model metrics are not real-company accuracy. The browser semantic smoke is not full WCAG certification.
