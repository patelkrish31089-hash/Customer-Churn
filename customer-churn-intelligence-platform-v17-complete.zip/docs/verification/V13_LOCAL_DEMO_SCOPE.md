# V13 local-demo scope and production acceptance boundary

## Why two acceptance profiles exist

The V12 verification report combines two different purposes: (1) a self-contained local development/synthetic demonstration and (2) company production acceptance. A local-only project can execute the first without CRM credentials, a hosted domain, company data or an independent penetration tester. It cannot honestly satisfy the second.

V13 keeps `reports/verification.json` as the production acceptance record. Its ten production gates remain `BLOCKED` until real evidence is reviewed. V13 adds a separate `reports/local_demo_acceptance.json` profile that evaluates the 14 checks the application can execute in this local workspace. It must not be used as a production release approval.

## One-command local demo on Windows

Open PowerShell in the extracted project folder:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_local_demo.ps1
```

The script uses Python 3.11 or 3.12, creates `.venv-local`, installs the application's required runtime dependencies, applies Alembic migrations to SQLite, adds a clearly labelled synthetic population, prompts for an administrator password without putting it in shell history, and starts the dashboard on `http://127.0.0.1:8000`.

To run it without reinstalling dependencies after the first successful installation:

```powershell
.\scripts\run_local_demo.ps1 -SkipInstall
```

To change population size or port:

```powershell
.\scripts\run_local_demo.ps1 -Customers 300 -Port 8010
```

## Verify the local-demo profile

Run all local verification stages and produce the local-demo report with one command:

```powershell
.\scripts\verify_local_demo.ps1 -ReviewedBy 'Your reviewer ID'
```

macOS/Linux:

```bash
REVIEWED_BY='Your reviewer ID' bash scripts/verify_local_demo.sh
```

The local demo profile passes only when every one of its 14 declared local checks is freshly marked PASS. Missing or failed local checks keep the profile blocked. The report records both the SHA-256 hash of `reports/verification.json` and the first-party source/config tree SHA-256 used to make the decision. Regenerate it after any source or test changes.

## Production gates remain separate

The ten production-only gates remain outside the local-demo profile: live CRM, hosted staging, real-company model validation, independent penetration test, business-policy approval, PostgreSQL runtime, Docker runtime, disposable clean-install proof, full MLflow/Evidently/Airflow runtime and the Ruff/Bandit/pip-audit toolchain. These are not labelled PASS or N/A in the production report. They are explicitly listed as `NOT_IN_SCOPE_LOCAL_DEMO` only in the local-demo report.

## Evidence interpretation

- Synthetic data proves the workflow executes, not real-world churn accuracy.
- SQLite proves the local-demo database path, not PostgreSQL transaction behavior.
- Local model registry/PSI checks are not equivalent to a running MLflow server, Evidently runtime and Airflow scheduler.
- Provider mock tests are not a live CRM connection.
- Source scans are not an independent penetration test.
- A local demo is not hosted staging.

For a production release, close every entry in the production `reports/verification.json` using the evidence specified in `docs/verification/V12_BLOCKED_GATE_CLOSURE_RUNBOOK.md`.
