# V14.1 release notes — reproducible dataset readiness

## Delivered

1. Added `app/services/dataset_audit.py` for training dataset readiness and leakage review.
2. Added `GET /api/v1/ml/dataset-audit` for admin/analyst roles.
3. Added a Models-page data-readiness panel with chronological partition counts, class balance, fingerprint, exclusion counts, missingness and caveats.
4. Added checks for exact customer/cutoff/horizon labels, uncensored binary targets, horizon maturity, event dates inside the positive event window, no event date on negative labels, exact feature version, and malformed/missing feature snapshots.
5. Tightened `assemble_dataset` so model training excludes future-maturity and inconsistent labels rather than trusting a previously supplied future `as_of`.
6. Added strict API/service tests and extended the browser bridge to check the endpoint and visible panel.
7. Administrator deactivation now permanently revokes all existing sessions; reactivation requires a fresh login and cannot resurrect a prior bearer token.

## Verification

- `python -m pytest -q -W error`: 115 passed, 0 failed, 0 skipped.
- Fresh `core`, `runtime`, `migrations`, `synthetic`, and `browser` stages passed.
- Browser bridge verified all dashboard pages, report export, administrator user/audit workflow, dataset readiness audit, file import, Customer 360 and logout.
- Aggregate production acceptance: 14 PASS / 0 FAIL / 10 BLOCKED across 24 unique gates.

## Limitations

The audit does not reconstruct raw event timestamps from an opaque snapshot fingerprint, nor does it prove that a company extract was authorized or complete. A structurally ready dataset is not proof of real-company model performance, fairness, business value or production approval.
