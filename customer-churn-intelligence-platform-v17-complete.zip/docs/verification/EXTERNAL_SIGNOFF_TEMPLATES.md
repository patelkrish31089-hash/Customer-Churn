# External acceptance sign-off templates

Use these templates in the company's approved document-management or ticketing system. Do not place credentials, raw customer records, private keys or sensitive penetration-test details in this repository.

## 1. Business churn-policy approval

- Policy ID / version:
- Effective date:
- Product/business owner:
- Data/analytics owner:
- Approved target horizon: 30 days (confirm or replace):
- Churn event timestamp rule (cancellation requested vs. effective termination):
- Voluntary churn rule:
- Involuntary churn / failed-payment rule:
- Grace-period rule:
- Subscription pause / suspension rule:
- Reactivation rule:
- Parent customer vs. subscription-level aggregation rule:
- Censoring and immature-outcome rule:
- Exclusions and edge cases:
- Approval decision: APPROVED / REJECTED / NEEDS REVISION
- Owner signature / approval record link / date:

A business approval must state the exact label semantics. Do not treat the synthetic demo policy or code defaults as company policy.

## 2. Real-company model validation approval

- Data owner and approved processing environment:
- Dataset version / immutable snapshot ID:
- Approved purpose and retention period:
- Source systems and lineage:
- Outcome maturity rule and observation end date:
- Churn-policy ID/version used for labels:
- Temporal train/validation/test cutoffs:
- Leakage review owner and result:
- Customer/subscription counts and exclusions (aggregate only):
- Calibration and threshold review:
- Subgroup performance and minimum sample-size review:
- Confidence intervals / uncertainty review:
- Explanation stability review:
- Model card / evaluation artifact location:
- Data owner approval / ML lead approval / date:

Do not copy actual customer rows or PII into a release ZIP or CI artifact. Evaluate within the approved company environment and export only sanitized aggregate evidence.

## 3. Hosted staging acceptance

- Hosting provider / project / environment identifier:
- Release commit SHA / artifact digest:
- Public/private staging URL (record only in approved internal system):
- TLS certificate and renewal owner:
- Secret-store references (names only; never values):
- PostgreSQL version and backup schedule:
- Migration result and revision:
- Health/readiness result:
- Authentication and role/permission test result:
- Audit/logging test result:
- Backup and restore test result:
- Rollback test result:
- Data-retention and deletion test result:
- Deployment owner approval / date:

## 4. CRM sandbox acceptance

- Provider and API version:
- Sandbox tenant identifier:
- Approved integration user/app and scopes:
- Secret-store reference names (never secret values):
- Synthetic external test contact ID:
- Local-to-external identity mapping verified:
- Create operation result and external action ID:
- Read-back/reconciliation result:
- Webhook signature result (if configured):
- Test artifact cleanup result:
- Sanitized request/response evidence link:
- CRM administrator approval / date:

Do not use a production customer or production tenant for this acceptance test unless separately authorized in writing.

## 5. Independent penetration-test acceptance

- Independent assessor organization and named lead:
- Written authorization reference:
- Scope, exclusions, target environment and test window:
- Rules of engagement and emergency contact:
- Report ID/date and secure storage reference:
- Finding IDs and severity summary:
- Remediation commit references:
- Retest date and outcome:
- Residual risk accepted by (if applicable):
- Independent assessor sign-off / date:

Internal static analysis, automated tests or a developer-authored statement cannot satisfy this independent assessment.
