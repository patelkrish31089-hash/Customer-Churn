# V13 release notes — local demo onboarding and scope-separated acceptance

## Delivered

1. `scripts/run_local_demo.ps1` and `scripts/run_local_demo.sh` provide a single-command local launch path for Python 3.11/3.12, SQLite migrations, synthetic demo seeding, password-prompted admin bootstrap and Uvicorn startup.
2. `scripts/bootstrap_admin.py` creates an administrator interactively. Passwords are not passed as command-line arguments or written to shell history. Passwords remain one-way PBKDF2 hashes in the database.
3. `scripts/verify_local_demo.ps1` and `scripts/verify_local_demo.sh` run all local verification stages and generate a local-demo acceptance report.
4. `scripts/local_demo_acceptance.py` reports the 14 local checks separately from ten production-only acceptance requirements. It will not promote a missing or failed local check to PASS, and production-only gates remain `NOT_ACCEPTED`.
5. Added regression coverage for local-demo scope handling and administrator creation/duplicate/weak-password cases.
6. Updated API default version to 1.3.0 and refreshed package SHA-256 inventory.

## Fresh verification evidence

- 103 pytest test cases: PASS, 0 failures, 0 errors, 0 skips; warnings treated as errors.
- Core stage: PASS.
- Local API startup/login/authentication/session revocation/graceful shutdown: PASS.
- 40-request concurrency smoke (10 concurrent): PASS; this is not a production load benchmark.
- SQLite migration upgrade/downgrade/re-upgrade: PASS.
- PostgreSQL offline migration SQL compilation: PASS; no PostgreSQL server connection was made.
- Compose static validation and CI acceptance contract: PASS; no Docker runtime was available.
- Synthetic end-to-end training, approval, prediction and retention: PASS; data are generated and not real business evidence.
- Chromium dashboard/UI/API bridge workflow and semantic accessibility smoke: PASS; full axe-core/WCAG audit remains unverified.

Production acceptance remains 14 PASS / 0 FAIL / 10 BLOCKED across 24 unique checks. The 10 production gates are not closed by the local-demo report.

## Release boundary

V13 is suitable for a reproducible local synthetic demonstration and development. It is not a production-certified release, it does not claim all detailed requirements across the twenty phases are complete, and it does not claim real-world churn accuracy. See `docs/ROADMAP_COVERAGE.md` for phase-level implementation limits.
