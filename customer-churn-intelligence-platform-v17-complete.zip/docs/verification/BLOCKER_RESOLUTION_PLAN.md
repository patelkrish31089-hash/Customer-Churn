# Remaining acceptance gates and exact closure requirements

This document separates code defects from environment, data, authorization and independent-review dependencies. The verifier counts unique gates only; missing packages are listed inside their functional gate and are not counted a second time.

| Gate | Current disposition | Required evidence to close |
|---|---|---|
| Browser E2E and accessibility | Blocked by this runner's Chromium localhost policy | Run `.github/workflows/ci.yml` browser job on an authorized runner; Playwright must complete the login/navigation/upload/read-back journey and axe-core must report no violations. |
| PostgreSQL runtime | Blocked: no server or psycopg driver in this workspace | Run CI's PostgreSQL 16 service job; require upgrade/downgrade/re-upgrade, transaction, constraint, persistence and API integration tests against PostgreSQL. |
| Docker runtime | Blocked: no Docker daemon/CLI in this workspace | Run CI's Compose runtime job; require successful image build, health/readiness, authenticated API, persistent-volume, shutdown and restore evidence. |
| MLOps runtime | Blocked: MLflow/Airflow/Evidently services absent | Run the MLflow/Evidently adapter CI smoke; deploy an Airflow scheduler with supported constraints, parse and execute the daily scoring DAG, and verify retries/idempotency. |
| Quality/security scanner toolchain | Blocked: Ruff, pip-audit and Bandit absent locally | CI installs the declared developer toolchain and runs lint, Bandit and dependency audit; review and remediate all findings. |
| Clean isolated install | Blocked: package-index DNS/network unavailable | Run dependency installation from requirements-dev.txt in a fresh supported Python 3.11/3.12 virtual environment with index access; record `pip check` in that isolated environment. |
| Live CRM provider sandbox | External authorization required | Configure provider sandbox app, OAuth grant, least-privilege scopes, webhook signing secret and test tenant; validate create/readback/reconciliation with real provider IDs. Never paste credentials into source control or chat. |
| Hosted staging | External authorization required | Supply an approved hosting project, domain/TLS, secret store and deployment authorization; run post-deploy health, rollback and restore checks. |
| Real-company model validation | Authorized business data required | Provide appropriately governed customer/subscription/billing/usage/support history with mature churn outcomes and temporal holdout; execute data quality, calibration, subgroup and SHAP stability review. |
| Business churn-policy sign-off | Business owner decision required | Approve effective churn event date, cancellations, pauses, grace periods, reactivations, censoring, target horizon and customer-vs-subscription label semantics. |
| Independent penetration test | Independent assessor required | Commission authorized independent penetration test and resolve critical/high findings; attach signed scope and evidence. |

## Shared-interpreter diagnostic

The host `pip check` reports a conflict between globally installed MoviePy and Pillow. MoviePy is not declared by this project. This diagnostic is preserved in `reports/verification.json` as `NOT_APPLICABLE`, not counted as an application acceptance failure. The project dependency installation still requires an isolated clean-environment run.

## No false closure

A configured workflow is not a passed workflow. A mocked CRM contract test is not a live CRM test. PostgreSQL offline DDL compilation is not a PostgreSQL runtime test. Synthetic model metrics are not company validation. Independent security and business sign-off cannot be self-certified by the application author.
