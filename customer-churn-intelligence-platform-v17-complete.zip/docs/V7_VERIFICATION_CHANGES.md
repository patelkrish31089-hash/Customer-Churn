# V7 verification and UI hardening

V7 extends the existing V6 codebase in place. It does not create a competing application or represent unavailable external services as operational.

## Defects fixed

- Corrected the Analytics page's undefined `s` identifier to use the `sur` survival response. This defect was detected by executing the page in Chromium, not by syntax-only checks.
- Added an accessible name to the customer search input.
- Added a reusable accessible-name association for dynamically rendered form controls.
- Added frontend contract tests protecting the Analytics variable and dynamic accessible-name behavior.

## New browser verification

`scripts/browser_bridge_e2e.py` starts a disposable local FastAPI instance and drives the actual dashboard JavaScript in Chromium. Because this host's managed policy blocks localhost navigation, the document is loaded in memory and API calls are bridged by the host-side test runner to the real API process. The test covers login, seven primary dashboard sections, CSV import, customer read-back, Customer 360 and logout. Semantic accessibility checks cover 10 views and 131 visible controls.

The test explicitly does not claim browser-native HTTP/CORS navigation or a complete axe-core/WCAG audit. The hosted CI browser job remains configured to perform those checks on an authorized runner.

## Verification result

- 83 automated tests passed with `-W error`.
- Latest aggregate: 13 passed, 0 failed, 10 blocked across 23 unique acceptance checks.
- Browser UI/API bridge stage passed.
- Remaining ten blocked gates are listed in `docs/verification/GATE_CLOSURE_CHECKLIST.md`.

## Release boundary

V7 is suitable for controlled local development and synthetic demonstration. It is not yet fully accepted across all 20 phases or approved for staging/production. Real company data, policy approval, provider credentials, external runtimes, hosted CI evidence and independent security assessment remain required.
