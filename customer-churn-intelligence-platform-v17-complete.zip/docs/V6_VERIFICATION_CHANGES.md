# V6 verification refresh

V6 is an evidence refresh of the existing platform, not a claim that unavailable external gates were somehow made to pass.

- Re-ran `core`, `runtime`, `migrations`, `synthetic`, `browser` and `report` verification stages independently.
- Latest strict regression result: 80 passed, 0 failed, warnings treated as errors.
- Latest aggregate: 12 passed, 0 failed, 11 blocked across 23 unique acceptance checks, plus one `NOT_APPLICABLE` global MoviePy/Pillow host diagnostic.
- Added a current run record and a gate-by-gate closure checklist.
- Updated README, test strategy, acceptance matrix and release-readiness documentation to remove stale V4/V5 headlines.

The eleven blocked gates are unchanged because no external CRM, staging, company dataset, business sign-off, independent assessor, PostgreSQL/Docker runtime, package-index network or hosted CI result was available during this run. See `docs/verification/V6_REVERIFICATION.md` for exact evidence and explanations.
