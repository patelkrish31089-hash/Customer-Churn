# V4 verification changes

> Historical release note: V4 is superseded by V5. Current acceptance results are in `reports/verification.md` and `docs/verification/RELEASE_READINESS.md`.

V4 closes a reporting-quality defect in V3: the previous report counted missing tools separately from the parent acceptance gate that already depended on those tools. Examples included psycopg plus PostgreSQL runtime, Docker CLI plus Docker runtime, and MLflow/Airflow/Evidently package absence plus the combined MLOps runtime gate.

V4 now reports unique acceptance gates and lists missing tools in a diagnostic inventory. The aggregate was regenerated after each current stage executed independently.

## Latest result

- 78 regression tests passed with warnings treated as errors.
- 11 local acceptance checks passed.
- 0 acceptance checks failed.
- 11 unique acceptance gates remain blocked.
- One unrelated shared-host MoviePy/Pillow dependency conflict is recorded as NOT_APPLICABLE, not as an application acceptance failure.

## Verification runner changes

- Distinguishes shared-host package diagnostics from project acceptance checks.
- Deduplicates missing optional packages under PostgreSQL, Docker, MLOps and quality/security gates.
- Keeps exact tool availability in `reports/verification.json`.
- Uses Playwright-managed Chromium when available, with optional system Chromium override.
- Adds axe-core scan support when the CI browser job installs `node_modules/axe-core`.
- Adds CI jobs for Playwright/axe and MLflow/Evidently adapter runtime checks.
- Adds CI commands for Ruff, Bandit and pip-audit.
- Documents the exact external evidence required to close every remaining gate.

## Important limitation

V4 does not convert unavailable services or missing permissions into passes. Live CRM, hosted staging, real company model validation, business-policy sign-off and independent penetration testing cannot be performed truthfully without the relevant accounts, data, approvals and independent parties.
