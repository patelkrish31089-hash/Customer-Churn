# V3 hardening and verification delta

This document records hardening applied on top of the V2 local application. It does not claim all 20 phases or production gates are complete. See `ROADMAP_COVERAGE.md`, `verification/RELEASE_READINESS.md` and timestamped files in `reports/` for authoritative status.

## Changes in this iteration

- Preprocessing returns stable named pandas columns to model estimators, eliminating feature-name warnings under strict test mode.
- REST source retrieval rejects non-public resolved addresses in the production-created client path, disables environment proxy trust and redirects, and caps streamed responses at 25 MiB. DNS pinning and network egress firewalling remain infrastructure responsibilities.
- Salesforce instance validation requires an HTTPS origin and approved Salesforce host suffix or exact host allowlist; provider redirects are rejected. Intercom contact identifiers are path-encoded.
- SQLAlchemy declarative metadata is isolated in `app/base.py`, allowing PostgreSQL dialect DDL and Alembic offline SQL compilation without opening a PostgreSQL connection.
- Added PostgreSQL offline migration compiler/evidence and a reproducible SQLite upgrade/downgrade/re-upgrade lifecycle script.
- Replaced the unreliable monolithic verifier with independent, time-bounded stages and a report aggregator.
- Added strict-warning regression tests for ML preprocessing, REST response/DNS protections, CRM URL/redirect protections and PostgreSQL DDL compilation.
- Added GitHub Actions jobs for PostgreSQL 16 migration/runtime tests and Docker Compose runtime. The workflow is configured but has not yet been executed remotely; it is not counted as a pass.

## Current evidence

- 75 automated tests pass with warnings treated as errors.
- The current staged report records 11 passed, 0 failed and 21 blocked checks.
- SQLite migration lifecycle, PostgreSQL offline SQL generation, local server/authentication smoke, local HTTP concurrency smoke and synthetic workflow smoke pass.
- Chromium, Docker runtime, PostgreSQL server runtime, clean dependency reinstall, live provider sandboxes, external MLOps services, hosted staging, real-company validation, independent penetration testing and accessibility certification remain blocked or unverified.


## Superseded by V4

The V3 aggregate reported 21 blocked rows because optional package absence and its parent runtime gate were counted more than once. V4 changes the report to unique acceptance gates, preserves each underlying tool in a separate inventory, and classifies the unrelated global MoviePy/Pillow conflict as a not-applicable host diagnostic. V3 results above are historical and should not be used as the current release status.
