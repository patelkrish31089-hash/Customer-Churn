# Data dictionary

Canonical import dataset names are `customers`, `subscriptions`, `invoices`, `payments`, `usage`, and `support`. Upload formats are CSV, XLSX and JSON. The actual schema validators in `app/services/data.py` remain authoritative if this summary differs from code.

| Entity/table | Main fields / relationships | Notes |
|---|---|---|
| User | username, password hash/salt, role, active | No default account; created through CLI/admin API. |
| SessionToken | user FK, digest, expiry, revoked | Raw token is only returned at login; only keyed digest persisted in configured secure environments. |
| Customer | internal ID, external ID, name, email, segment, country, acquisition date, consent | Canonical customer. Email is not the universal identity key. |
| Subscription | customer FK, external ID, plan, status, lifecycle dates, churn reason, MRR/currency | One customer can have many subscriptions. |
| Invoice | customer/subscription FKs, invoice date, amount, currency, status, source ID | Exact monetary values use database numeric type. |
| Payment | customer/invoice FKs, payment date, amount, currency, status, source ID | Payment failure is not itself a churn label. |
| UsageEvent | customer/subscription FKs, event timestamp/type, quantity, source ID | Feature calculations filter events by historical cutoff. |
| SupportTicket | customer FK, created/resolved timestamps, status, priority/category, source ID | Ticket body text is excluded from current import contract. |
| ImportBatch | dataset type, file/source hash, source, counts, status, timestamps | Completed duplicate uploads are idempotently recognized. |
| DataIssue | batch FK, row number, issue code/message, raw row | Raw rejected-row data is sensitive; restrict DB and review API. |
| DataSourceConnection | name/type, allowlisted host, URL/path, mapping, token env reference, active | No token value stored; REST source only. |
| DataQualityRule | code, title, severity, enabled, parameters | Persistent configurable rules. |
| DataQualityRun | scope, status, counts, quality score, timestamps | One execution record/scorecard. |
| DataQualityFinding | run/rule/entity references, severity, issue, review state, correction audit | Corrections use field allowlist and review authorization. |
| ChurnLabel | entity scope/ref, customer/subscription, cutoff/horizon, target, churn reason/event, maturity/censor, policy version | Customer and subscription targets are distinct. A negative label requires mature observation. |
| FeatureSnapshot | customer, cutoff, feature version, JSON features, source fingerprint | Unique by customer/cutoff/version; v2.1 includes usage/billing recency/frequency and currency-safe fields. |
| TrainingRun | run ID, algorithm, dataset fingerprint, feature version, metrics, artifact path | Local training lineage. |
| ModelRelease | artifact, training run, status, feature/horizon, metrics, approver | Candidate→approved/superseded; explicit rollback. |
| PredictionBatch | pinned model release/cutoff/horizon, request key, status, totals | Supports idempotency, partial failures and failed-ID retry. |
| Prediction | customer, release, cutoff, horizon, probability/risk, feature snapshot, explanation | Repeat exact scoring reuses same record. |
| RetentionRecommendation | customer/prediction, category, rationale/evidence, status, approver, outcome | Human review required. |
| RetentionPlaybook | key/version, eligibility, channel, roles, cooldown/contact caps | Internal policy template. |
| RetentionAssignment | customer/recommendation, owner, state/due date | Operational workload assignment. |
| RetentionExperiment | hypothesis, cohort/policy, randomization config, status | Deterministic treatment/control allocation; no claim of causal effect by default. |
| RetentionExperimentAssignment | experiment/customer/arm, assigned and matured outcome timestamps | Outcome reporting excludes immature follow-up. |
| ExternalIdentity | customer/provider/external reference | Explicit customer-provider mapping. |
| CRMAction | recommendation, provider, idempotency key, action status/result | Sandbox simulation or consent-gated provider action; unknown delivery isn't auto-retried. |
| AuditEvent | actor/action/entity/correlation ID/metadata/timestamp | Avoid secrets and unnecessary PII in metadata. |
| DriftReport | release, feature PSI, threshold, status, details | Feature drift, not prediction accuracy. |

## Temporal conventions

Timestamps should be interpreted as UTC. SQLite drivers may return naive timestamps; service code normalizes these to UTC. The standard churn window is `(prediction_cutoff_at, prediction_cutoff_at + 30 days]`. Incomplete windows are right-censored, not automatically labeled retained. Features may only use facts available at or before cutoff; snapshots are immutable.

## Currency convention

Never add different currency values. Currency-specific dictionaries/fields remain separate. Scalar monetary features are only computed if the relevant aggregation contains one currency. Financial impact scenario outputs require explicitly supplied assumptions and are not forecasts of realized company savings.

## Provenance convention

Every import is associated with a source/import batch; synthetic rows are labeled `synthetic_demo`. Never represent synthetic, test, public or unverified data as real customer information.
