# V5 verification and acceptance changes

V5 strengthens the external acceptance evidence without claiming that unavailable services have passed.

## Latest local evidence

- 80 automated regression tests passed with warnings treated as errors.
- Python compile and application import passed.
- Frontend JavaScript syntax check passed.
- Local Uvicorn startup, readiness, authentication, logout revocation and shutdown passed.
- 40 authenticated HTTP requests at concurrency 10 returned HTTP 200.
- SQLite Alembic upgrade → downgrade → re-upgrade passed.
- PostgreSQL offline SQL and PostgreSQL dialect DDL compilation passed; no live PostgreSQL connection was made.
- Docker Compose static validation passed; no Docker daemon was available.
- CI workflow contract validation passed for five hosted acceptance jobs and evidence uploads.
- Synthetic 120-customer training → approval → prediction → retention workflow passed. All data is synthetic and not business-performance evidence.

The current aggregate is **12 PASS / 0 FAIL / 11 BLOCKED across 23 unique acceptance checks**, plus one `NOT_APPLICABLE` shared-host diagnostic. Detailed stage output and exact commands are in `reports/verification_*.json`, `reports/verification.md`, and `reports/junit.xml`.

## New hosted acceptance tests

- `scripts/postgres_runtime_smoke.py` refuses SQLite and checks PostgreSQL CRUD, money precision, uniqueness, foreign keys, rollback, persistence and API authentication/session revocation.
- `scripts/docker_runtime_smoke.sh` exercises Compose build/start, authenticated readiness, app restart persistence and PostgreSQL dump/restore.
- `scripts/airflow_dag_runtime_smoke.sh` executes the scoring DAG task against a seeded synthetic app database and verifies persisted batch output.
- `scripts/ci_workflow_check.py` validates the hosted workflow contract and evidence uploads.
- `.github/workflows/ci.yml` provisions the required hosted runners/services, installs the advanced-model and SHAP extras in the backend matrix, gives each job a bounded timeout, and uploads evidence even when a job fails. The static checker asserts a real PostgreSQL service and PostgreSQL DSN, all five jobs, their scripts, timeouts and artifact uploads.

These scripts and workflows are configured; their remote execution remains unverified until a GitHub Actions run completes and its evidence artifacts are reviewed.

## Why 11 gates remain blocked

The remaining gates require a managed browser runner, PostgreSQL/Docker runtimes, isolated network installation, MLflow/Airflow/Evidently services, hosted security scanners, real CRM sandboxes, a staging account, authorized company churn data, an approved churn policy and an independent penetration tester. These are different resource/authorization requirements, not 11 application code defects. The exact closure evidence and setup requirements are in `docs/verification/BLOCKER_RESOLUTION_PLAN.md` and `docs/verification/EXTERNAL_ACCEPTANCE_INPUTS.md`.

## Release statement

V5 is locally verified for controlled development and synthetic demonstration. It is not fully accepted across all twenty phases and is not approved for staging or production. A configured CI job is not a passed CI result; external checks become PASS only after their execution artifacts are available and reviewed.
