# Architecture

## Architectural style

The product is a modular monolith for local and initial deployment. FastAPI owns HTTP/API boundaries, SQLAlchemy owns persistence, Alembic owns schema evolution, service modules contain domain/application workflows, and the same-origin dashboard uses authenticated JSON APIs. SQLite is the tested local database. PostgreSQL is the intended deployment database option and has a Compose configuration, but PostgreSQL runtime/migration tests remain unverified.

```mermaid
flowchart TB
  User[Analyst / Success manager / Admin] --> UI[Same-origin dashboard]
  UI --> API[FastAPI v1 API]
  API --> Auth[Session authentication + RBAC]
  API --> Services[Application services]
  Services --> Ingest[CSV / XLSX / JSON / allowlisted REST]
  Ingest --> Quality[Rules / scorecards / findings / review]
  Quality --> Canonical[(Customer, subscription, billing, usage, support)]
  Canonical --> Labels[Customer + subscription labels / censoring]
  Canonical --> Features[Feature contract v2.1 / point-in-time snapshots]
  Labels --> Dataset[Chronological supervised dataset]
  Features --> Dataset
  Dataset --> Train[LR / RF / optional XGBoost / optional LightGBM]
  Train --> Eval[Validation selection / calibration / test evaluation]
  Eval --> Registry[Local candidate registry]
  Registry --> Approval[Admin approval / rollback]
  Approval --> Predict[Single + batch inference]
  Predict --> C360[Customer 360 / timeline]
  Predict --> Retention[Playbooks / review / assignments / experiments]
  Retention --> CRM[Sandbox or provider-specific adapters]
  Train --> MLflow[Optional MLflow adapter]
  Predict --> Airflow[Authored Airflow DAG]
  Features --> Drift[PSI / optional Evidently]
  Services --> DB[(SQLite tested / PostgreSQL configured)]
  Services --> Files[(Uploads / model artifacts / reports)]
```

## Data flow

```mermaid
flowchart LR
  Input[CSV / XLSX / JSON / allowlisted HTTPS JSON] --> Import[Canonical import / provenance / idempotency]
  Import --> Reject[Rejected/quarantined rows]
  Import --> DQ[Configurable quality rules + audited corrections]
  DQ --> Entity[(Canonical business entities)]
  Entity --> Label[Churn target + maturity/censoring]
  Entity --> Feature[Point-in-time RFM / usage / subscription / support features]
  Label --> Dataset[Cutoff-exact chronological dataset]
  Feature --> Dataset
  Dataset --> Models[LR / RF / XGBoost / LightGBM]
  Models --> Cal[Training-only calibration + validation threshold selection]
  Cal --> Heldout[Chronological held-out test metrics]
  Heldout --> Candidate[Versioned candidate artifact]
  Candidate --> Gate[Admin approval]
  Gate --> Batch[Single / batch prediction]
  Batch --> Profile[Customer 360 / retention experiment]
  Profile --> Actions[Approved and consent-gated action]
  Actions --> Provider[Sandbox / Salesforce / HubSpot / Intercom adapter]
```

## Dependency rules

1. Frontend communicates with `/api/v1` only; no direct database access.
2. API endpoints validate requests, authenticate and authorize server-side, then call services.
3. Domain calculations stay in services and analytics/ML modules.
4. Database models and migrations are authoritative in `app/models.py` and `alembic/`.
5. Feature computation is cutoff-bounded and versioned; snapshots are immutable.
6. Label and feature records must match entity scope, customer/subscription, cutoff, horizon and feature version.
7. Candidate model selection and thresholds use validation data; held-out test is not a tuning dataset.
8. Model approval is explicit; prediction records pin release, horizon and feature snapshot.
9. Retention recommendations are not external actions. Human review, consent, identity mapping and idempotency are required before provider calls.
10. Money is kept in currency-specific aggregates; no cross-currency addition.

## Main runtime modules

- `app/main.py`: route declarations, auth dependencies, request/response boundaries.
- `app/services/data.py`: canonical import, label generation, feature snapshots and dataset assembly.
- `app/services/quality.py`: rule execution, scorecards, findings and correction review.
- `app/services/analytics.py`: EDA, cohort retention, Kaplan-Meier/Greenwood intervals and group comparison.
- `app/services/ml.py`: model candidate training/comparison, calibration, metrics, registry, inference and explanations.
- `app/services/retention.py`: recommendation and action workflow.
- `app/services/retention_governance.py`: playbooks, assignment and experiment lifecycle.
- `app/services/mlops.py`: drift and matured-outcome monitoring/readiness.
- `app/integrations/sources.py`: allowlisted REST JSON source connector.
- `app/integrations/crm.py`: Salesforce, HubSpot and Intercom HTTP adapters.
- `app/integrations/mlflow_tracking.py`: optional MLflow tracking adapter.
- `dags/customer_churn_daily_scoring.py`: authored Airflow DAG; scheduler execution not verified.

## Persistence

See `DATA_DICTIONARY.md` for models and current semantics. Important entities include canonical customer/billing/activity records, import batches/issues, data quality runs/findings/rules/sources, scoped churn labels, feature snapshots, model training/releases, prediction batches/predictions, Customer 360 audit, retention playbooks/assignments/experiments, CRM identities/actions and drift reports.

## Model families and optional integrations

Logistic Regression and Random Forest are core. XGBoost and LightGBM are available via `requirements-advanced-ml.txt`; SHAP via `requirements-explainability.txt`; MLflow and Evidently via `requirements-mlops-optional.txt`. Airflow must be installed with version-specific official constraints. Optional integration modules report unavailable/not configured rather than simulating a live service.

## Deployment boundary

The Dockerfile/Compose configuration describe FastAPI plus PostgreSQL 16 with persistent database, uploads and artifacts, service health checks and environment-backed database password. Compose YAML passed static validation only; Docker build/run, PostgreSQL migration/transaction/backup and hosted staging remain unverified. TLS reverse proxy, managed secrets, KMS, tenant isolation, monitoring/alerts and provider credentials are external deployment prerequisites.
