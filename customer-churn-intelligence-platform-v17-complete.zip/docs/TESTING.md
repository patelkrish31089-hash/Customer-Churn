# Test and verification strategy

## Current workspace evidence (2026-11-07, V10 re-verification)

The latest V11 staged verification report records **14 passed / 0 failed / 10 blocked / 24 unique acceptance checks**, plus one `NOT_APPLICABLE` diagnostic for an unrelated globally installed MoviePy/Pillow conflict. The strict automated regression suite contains **93 tests and passes with warnings treated as errors**. A blocked result means the required runtime, external authorization, governed data or independent evidence was unavailable; it is not a software test failure and is never converted into PASS.

| Gate | Result | Evidence |
|---|---|---|
| Python compile/import | PASS | `python -m compileall -q app tests scripts`; import `app.main:app` |
| Frontend JavaScript syntax | PASS | `node --check app/static/app.js` |
| Unit/service/API regression | PASS | 93 tests, `python -m pytest -q -W error --junitxml reports/junit.xml` |
| Supplemental AST security smoke | PASS (limited) | `python scripts/source_security_smoke.py`; zero first-party AST findings; not Bandit/pip-audit |
| Local API runtime | PASS | Real Uvicorn start, health, dashboard, login, identity, logout revocation and shutdown |
| HTTP concurrency smoke | PASS (small smoke only) | 40/40 authenticated requests HTTP 200, concurrency 10; not production load testing |
| SQLite migration lifecycle | PASS | Fresh DB upgrade head → downgrade base → upgrade head; 30 tables, no FK violations |
| PostgreSQL migration generation | PASS (offline only) | Alembic offline SQL compilation and PostgreSQL dialect DDL compilation; no server connection |
| Docker Compose manifest | PASS (static only) | YAML/service/dependency/volume/healthcheck validation |
| CI workflow contract | PASS (static only) | Five hosted acceptance jobs and evidence-upload steps verified; no remote workflow run observed |
| Synthetic end-to-end workflow | PASS (synthetic only) | 120 synthetic customers, model training/approval, 120 predictions, 26 recommendations, sandbox task |
| Chromium browser E2E/semantic accessibility smoke | PASS (qualified) | `scripts/browser_bridge_e2e.py`; real Chromium UI, real local FastAPI API through host-side bridge, 10 views, 131 controls; native origin/CORS and full axe-core scan not covered |
| Live CRM provider sandbox | BLOCKED | No Salesforce, HubSpot or Intercom sandbox credentials, OAuth grants or webhook secrets |
| Hosted staging deployment | BLOCKED | No hosting account, domain, TLS certificate or deployment authorization |
| Real-company model validation | BLOCKED | No authorized company dataset with mature churn outcomes |
| Business churn-policy sign-off | BLOCKED | No authorized business owner has approved churn/censoring semantics |
| Independent penetration test | BLOCKED | Independent assessor and authorized test scope/evidence not supplied |
| PostgreSQL runtime | BLOCKED locally; CI configured | No PostgreSQL server/driver runtime here. Hosted job now runs real PostgreSQL migrations, constraints, precision, rollback and API session tests. |
| Docker runtime/recovery | BLOCKED locally; CI configured | No Docker daemon here. Hosted job builds/starts services, verifies persistence and pg_dump/restore. |
| Clean isolated installation | BLOCKED locally; CI configured | Package-index DNS unavailable here. Hosted jobs perform fresh installs and `pip check`. |
| MLflow/Airflow/Evidently runtime | BLOCKED locally; CI configured | Services/packages absent here. CI has adapter read-back/report generation and Airflow DAG task execution checks. |
| Quality/security scanner runtime | BLOCKED locally; CI configured | Ruff, Bandit and pip-audit are absent here; hosted CI installs and runs them. Independent penetration testing remains separate. |

## Reproduce by isolated stages

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```

Individual local commands:

```bash
python -m pytest -q -W error --junitxml reports/junit.xml
python -m compileall -q app tests scripts
node --check app/static/app.js
python scripts/runtime_http_smoke.py
python scripts/http_load_smoke.py
python scripts/migration_lifecycle_smoke.py
python scripts/postgres_migration_compile.py
python scripts/deployment_config_check.py
python scripts/ci_workflow_check.py
python scripts/source_security_smoke.py
python scripts/smoke_demo.py
python scripts/browser_bridge_e2e.py  # local in-memory Chromium + real API bridge
# scripts/browser_e2e.py runs with native browser networking in the hosted CI job
```

The external acceptance scripts are intended for hosted CI where the required services exist:

```bash
python scripts/postgres_runtime_smoke.py
bash scripts/docker_runtime_smoke.sh
python scripts/mlops_adapter_smoke.py
bash scripts/airflow_dag_runtime_smoke.sh
```

Do not run the PostgreSQL or Docker scripts against SQLite or pretend local substitutes; they intentionally fail if the required runtime is absent. See `docs/verification/EXTERNAL_ACCEPTANCE_INPUTS.md` for credentials and approval prerequisites.

## CI verification (V11)

`.github/workflows/ci.yml` includes seven independent hosted jobs: fresh isolated installs on Python 3.11 and 3.12, the independent Ruff/Bandit/pip-audit toolchain, PostgreSQL runtime, Docker runtime/recovery, native Chromium/axe-core accessibility, MLflow/Evidently, and Airflow DAG execution. Each job uploads run/commit provenance and logs/evidence even on failure. `scripts/ci_workflow_check.py` verifies workflow structure only. **The workflow is configured, not remotely verified** until a GitHub Actions run succeeds and its artifacts are reviewed. See `docs/verification/V11_GATE_REMEDIATION.md` for the evidence-merging process.

## ML/data validity controls covered by tests

1. Customer and subscription labels have distinct scope; label maturity and right-censoring are explicit.
2. Features use only data available at/before the prediction cutoff; persisted snapshots are immutable.
3. Currency-specific aggregates are not combined into a false scalar monetary feature.
4. Chronological train/validation/test partitions are disjoint by cutoff; calibration is training-only and candidate/threshold selection uses validation.
5. Candidate releases require approval; inference pins release, feature version and horizon.
6. Batch idempotency and retry of failed customer IDs are checked.
7. SHAP output is distinguished from fallback model importance; neither is causal evidence.
8. PSI drift is not treated as predictive performance; outcomes require matured labels.
9. CRM execution guardrails require approval, identity mapping, consent and idempotency.
10. Synthetic records and model metrics carry explicit synthetic provenance.

## Known verification limits

The 91-test suite is not a replacement for PostgreSQL and Docker runtime jobs, native browser-origin/CORS and full axe-core accessibility checks, external CRM sandboxes, authorized company data, policy sign-off, hosted staging or an independent penetration test. Multiple detailed requirements in Phases 2–17 remain partial; see `docs/ROADMAP_COVERAGE.md`. Production readiness is not approved.

See `verification/V11_REVERIFICATION.md` and `verification/V11_GATE_REMEDIATION.md` for the latest run and closure requirements.


## V10 strict test configuration

`pyproject.toml` explicitly sets `asyncio_mode = "auto"` and `asyncio_default_fixture_loop_scope = "function"` so pytest-asyncio does not emit a startup deprecation warning under `-W error`. The regression suite includes a test that protects this configuration. `scripts/source_security_smoke.py` adds a dependency-free AST check for selected unsafe Python patterns; it is a supplemental heuristic only.
