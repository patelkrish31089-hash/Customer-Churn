# 20-phase roadmap coverage — implementation and verification status

**Status definitions**

- **Implemented and locally verified**: the stated workflow exists in the repository and has executable local test evidence. It does not certify production use.
- **Partial**: useful, connected functionality exists, but one or more detailed requirements remain incomplete.
- **Adapter implemented / live verification blocked**: provider-specific code and local contract tests exist, but no real provider account, OAuth grant, webhook or sandbox result was available.
- **Blocked**: the requested environment, credentials, approved data or external service was not supplied, so the corresponding live check cannot truthfully pass.
- **Not implemented**: no working implementation is claimed.

| Phase | Scope from supplied prompt | Current status | Implemented code and local evidence | Remaining gap / acceptance blocker |
|---:|---|---|---|---|
| 1 | Project foundation | Implemented (local) | FastAPI modular monolith, SQLAlchemy models, Alembic migrations, centralized settings, PBKDF2 password hashing, opaque revocable sessions, RBAC, audit events, docs, CI workflow, local runtime smoke. | The prompt was supplied without an existing source repository ZIP; this application was built as a new codebase. SSO/OIDC, MFA, tenant isolation, production key management and PostgreSQL runtime tests are not complete. |
| 2 | Dataset collection | Partial | Six canonical datasets; CSV/XLSX/JSON parser; SHA-256 idempotent import; source provenance; import batches and row issue accounting; HTTPS JSON REST source registry with field mapping, env-referenced bearer token and server-side host allowlist. | Provider-specific data-source adapters, SFTP/object storage, email attachment ingestion, pagination/cursor sync, incremental watermarks, source scheduling and schema-evolution approval remain. The hardened production-created HTTP client rejects non-public DNS answers, disables environment proxy trust and redirects, and caps streamed responses at 25 MiB; DNS pinning and network egress firewalling remain deployment controls. |
| 3 | Data ingestion | Partial / asynchronous execution added | File upload API, canonical parser, row savepoints/quarantine, source registry/sync route, partial batch preservation, import reports, durable queued imports with checksum validation, retry and worker execution. | Large-file streaming/chunking, dead-letter UI, webhook ingestion, multi-file orchestration and source cursor/pagination remain. |
| 4 | Data validation and cleaning | Partial / materially expanded | Twelve configurable rule definitions, enabled/severity/parameter persistence, IQR outlier checks within currency groups, relationship/date/email checks, scorecard run, findings, reviewer decisions, allowlisted field corrections and audit records. | Rules do not yet cover all source-specific semantics; suggested normalization/corrections, rule-pack version migration, per-source scorecards, bulk review and full data-quality UI workflows need more work. |
| 5 | Churn label engineering | Partial | Customer and subscription target scopes; explicit 30-day horizon and `(cutoff, cutoff+horizon]` event window; voluntary/involuntary/other/unknown/none reasons; maturity and right-censoring; tests for scope and boundary conditions. | Company approval is required for cancellation request vs effective date, reactivation, pauses, grace periods, multiple subscriptions, competing risks and complete lifecycle event reconstruction. |
| 6 | Feature engineering | Partial / expanded contract v2.1 | Cutoff-bounded usage, subscription, payment, invoice and support features; recency/frequency/monetary and usage velocity/inactivity trends; currency-separated amounts; scalar money values only for one currency; source fingerprints; immutable snapshots. | Rich plan/contract attributes, line-item semantics, source-completeness policy, event-stream replay and full point-in-time mutation test matrix remain. |
| 7 | Feature store | Partial | Persistent snapshots unique on customer/cutoff/feature version; version v2.1; historical source fingerprint; exact cutoff join during ML dataset assembly; existing snapshots are not overwritten. | No online feature retrieval service, scheduled materialization, feature registry UI, large-scale backfill orchestration or distributed offline store. |
| 8 | Exploratory data analysis | Partial / expanded | Numeric distributions, histograms, missingness, outlier review, correlation matrix, class balance, API endpoint and dashboard view. | Statistical hypothesis testing, multiple-comparison control, richer categorical diagnostics, report export, interactive drill-down and formal analyst sign-off remain. |
| 9 | Cohort analysis and retention intelligence | Partial / expanded | Acquisition-month cohorts with separate customer, subscription and engagement retention curves/heatmap values; month-end observation checkpoint corrected; active-rate summaries. | Confidence intervals by cohort cell, acquisition-channel/plan slices, survival-adjusted retention, downloadable report and source-completeness weights remain. |
| 10 | Survival and time-to-churn | Partial / expanded | Kaplan–Meier product-limit estimator; right-censoring; Greenwood pointwise 95% intervals; two-group log-rank approximation when exactly two segments exist; caveats shown in output. | Competing risks, recurrent events/reactivation, multi-state transitions, robust stratified comparisons and approved business definitions remain. |
| 11 | ML dataset preparation | Partial (expanded V14.1) | Exact customer/cutoff/horizon labels joined to matching feature snapshot; mature-horizon/event-window checks; chronological train/validation/test readiness audit; per-feature missingness; stable dataset fingerprint; repeat-customer overlap warning; point-in-time feature API. | Raw source timestamps are not reconstructed from opaque fingerprints; dataset artifact export, repeated-customer policy decision, provenance approval and large historical reproducibility remain. |
| 12 | Model training | Partial / expanded | Logistic Regression, Random Forest, optional XGBoost and LightGBM; bounded hyperparameter candidates; validation PR-AUC selection; training-only cross-validated sigmoid calibration; saved artifact and model lineage. | Broad tuning, Bayesian/parallel search, large-data training, model fairness review, distributed training and MLflow-backed remote registry remain. Optional boosted-tree packages are separate dependencies. |
| 13 | Evaluation and financial impact | Partial / expanded | PR-AUC, ROC-AUC, precision, recall, specificity, balanced accuracy, F1, Brier, log-loss, confusion matrix; validation threshold curve; optional finance-supplied false-positive/false-negative cost threshold; test reliability bins; customer-cluster bootstrap intervals; scenario-only financial impact. | Realized contribution margin, unit-economics approval, subgroup confidence intervals, prospective validation and a finance-approved model utility decision are not available without company data. |
| 14 | SHAP explainability | Partial / expanded | Optional global mean-absolute SHAP summary for feature snapshots and local prediction explanations; additivity check; explicit unavailable status if SHAP cannot run; explanations are stored on prediction records. | SHAP is an optional extra; version-specific explainer validation, stability tests, subgroup explanation review, UI drill-down and formal explanation governance need more work. |
| 15 | Prediction engine | Partial / durable queue added | Approved-release inference; per-customer prediction history; model/feature/horizon pinning; queued batch scoring with stable idempotency, partial failure reporting, failed-ID retry and persisted worker jobs; Airflow daily-scoring DAG authored. | PostgreSQL multi-worker contention, Airflow DAG runtime/scheduler, backpressure, scale and latency SLOs still require real runtime evidence. |
| 16 | Customer 360 | Partial / expanded | Searchable profile combining customer, subscription, invoice, payment, currency-separated financial summary, usage, support, predictions, SHAP payloads, retention actions, audit events, source provenance and normalized chronological timeline. | Full identity merge/survivorship interface, source-level record drill-down screens, role-specific field masking, timeline export and very-large-customer performance remain. |
| 17 | Retention intelligence | Partial / governance expanded | Versioned playbooks, role/channel controls, cooldown/contact caps, assignments, approval/rejection, consent gates, stable randomized treatment/control assignment, experiment power/sample-size planning, immutable audited outcome recording and per-arm missing-outcome coverage. | Pre-specified missing-outcome sensitivity analysis, cluster-aware designs, holdout contamination controls, campaign delivery telemetry, CRM outcomes and business-approved intervention impact remain. The built-in complete-case comparison is descriptive and not a strict ITT/causal claim. |
| 18 | CRM and campaign automation | Adapter implemented / live verification blocked | Salesforce Task, HubSpot associated Task and Intercom contact timeline Note adapters; token lookup from environment only; local HTTP contract tests; restricted Salesforce host validation including pre-request public DNS resolution for the default client, HTTPS-only origin policy, redirects rejected, encoded Intercom contact IDs, remote identity mapping, review approval, explicit consent and idempotency before external execution; unknown delivery is not auto-retried. | Provider OAuth install/refresh, least-privilege scope verification, encrypted token vault/rotation, webhook signature verification, account sandbox tests, sync/reconciliation, campaign orchestration and real delivery evidence are not supplied. No provider is claimed connected. |
| 19 | MLOps and production deployment | Partial / externally blocked | Local model registry/approval/rollback; MLflow tracking adapter for params/metrics/artifact; Airflow DAG source; PSI monitor; optional Evidently report adapter; PostgreSQL 16 Docker Compose with health checks and persistent volumes; static Compose validation. | MLflow server/tracking execution, Airflow scheduler/DAG runtime, Evidently report execution, retraining approval pipeline, canary promotion, hosted deployment, PostgreSQL migrations/transactions/backup and Docker runtime were not executed. |
| 20 | Complete verification | Partial (stronger local evidence) | 93 automated tests with warnings treated as errors; Python compile/import; JS syntax; limited secret-pattern scan plus dependency-free first-party AST security smoke (zero findings); local Uvicorn start/login/auth/logout/shutdown; 40-request/10-concurrent HTTP smoke; SQLite migration upgrade/downgrade/re-upgrade (30 tables, zero FK violations); PostgreSQL offline migration SQL compilation (580 lines) and dialect DDL compilation; synthetic 120-customer workflow; Compose static validation; Chromium UI E2E via in-memory page + host-side API bridge covering login, all seven dashboard sections, CSV upload, customer read-back, Customer 360 and logout; semantic accessibility smoke across 10 views and 131 controls. | V11 report: 14 passed / 0 failed / 10 blocked across 24 unique acceptance checks, plus one not-applicable host diagnostic. Native browser-origin HTTP/CORS and full axe-core/WCAG scan remain unverified; PostgreSQL/Docker runtime, clean isolated installation, scanner toolchain, MLOps runtime, live CRM, hosted staging, authorized real-company holdout, churn-policy approval and independent penetration test remain blocked. See `reports/verification.md`, `reports/verification_*.json`, and `docs/verification/GATE_CLOSURE_CHECKLIST.md`. |

## End-to-end local workflow currently connected

```mermaid
flowchart LR
  Files[CSV / XLSX / JSON] --> Import[Canonical import + provenance + quarantine]
  REST[Allowlisted HTTPS JSON source] --> Import
  Import --> Quality[Configurable data-quality rules + review]
  Quality --> Tables[(Customer / subscription / billing / usage / support)]
  Tables --> Labels[Customer and subscription labels + censoring]
  Tables --> Features[Point-in-time feature v2.1]
  Labels --> Dataset[Chronological dataset]
  Features --> Dataset
  Dataset --> Train[LR / RF / XGBoost / LightGBM]
  Train --> Evaluate[Validation selection / calibration / held-out test]
  Evaluate --> Registry[Candidate artifact + local registry]
  Registry --> Approval[Administrator approval]
  Approval --> Score[Single / batch predictions]
  Score --> C360[Customer 360 + timeline + explanations]
  Score --> Retention[Playbooks / reviewed recommendations]
  Retention --> Experiment[Randomized holdout / matured outcome analysis]
  Retention --> CRM[Sandbox or consent-gated provider adapter]
  Train --> MLflow[Optional MLflow tracking]
  Score --> Airflow[Authored Airflow schedule]
  Features --> Drift[PSI / optional Evidently]
```

## Release decision

**V8: verified local development, synthetic demonstration and Chromium UI workflow build. Not a fully complete 20-phase production system.** The local browser UI and API workflow is now executed in Chromium through a test-only transport bridge; native browser networking/CORS and full axe-core accessibility auditing still require the hosted browser job. Other phases retain documented partial implementations and external acceptance requirements. A passing local test does not promote an external/production blocker to PASS.


## V8 current verification record

The current fresh run is documented in `reports/verification.md` and `docs/verification/V8_REVERIFICATION.md`: **13 PASS / 0 FAIL / 10 BLOCKED**. The ten blocked gates are detailed in `docs/verification/V8_REMAINING_GATES.md`; no missing external evidence is treated as passed.


## V9 re-verification addendum — 2026-11-07 (historical)

The current fresh staged run records **13 PASS / 0 FAIL / 10 BLOCKED across 23 unique acceptance checks**, plus one `NOT_APPLICABLE` host diagnostic. The local regression suite records **83 passed** with warnings treated as errors. See `reports/verification.md`, `reports/verification.json`, and `docs/verification/V9_REVERIFICATION.md`.

The 10 blocked gates are genuine external/runtime acceptance requirements: PostgreSQL runtime, Docker runtime, clean isolated installation, MLOps runtime, quality/security scanners, live CRM sandbox, hosted staging, real-company model validation, business churn-policy sign-off and independent penetration testing. These do not change the fact that several feature requirements across Phases 2–17 remain explicitly **Partial** in the table above. Passing all locally available tests is not full 20-phase completion or production approval.


## V10 re-verification addendum — 2026-11-07

The latest V11 staged run records **14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance checks**, plus one `NOT_APPLICABLE` shared-host diagnostic. The strict regression suite records **93 passed** with warnings treated as errors. V11 retains V10’s pytest-asyncio's explicit fixture-loop configuration and adds a self-tested dependency-free AST security smoke for first-party Python code (zero findings). The scanner is supplemental; it does not replace Ruff, Bandit, pip-audit, a full secrets scanner or an independent penetration test.

The ten blocked gates remain PostgreSQL runtime, Docker runtime, clean isolated installation, MLOps runtime, full quality/security toolchain, live CRM sandbox, hosted staging, real-company model validation, business churn-policy sign-off and independent penetration testing. The fresh package-index attempt failed because DNS could not resolve the package index. All five local stages passed independently. Multiple requirements in Phases 2–17 are still classified as Partial; see the phase table. V10 is not full 20-phase acceptance or production approval.

## V13 release addendum — 2026-11-07

V13 adds a one-command local-demo startup flow, secure interactive administrator bootstrap, and a separate local-demo acceptance profile. The fresh V13 run records **103 passed / 0 failed / 0 skipped** regression tests, and all 14 locally executable acceptance checks pass. The production acceptance report continues to record **14 PASS / 0 FAIL / 10 BLOCKED** across 24 unique checks. The ten production gates remain open because they require actual PostgreSQL/Docker/toolchain runtime, hosted deployment, CRM credentials, authorized real-company churn data, business approval or an independent assessor. The local-demo profile explicitly lists these as `NOT_IN_SCOPE_LOCAL_DEMO`; it does not count them as passed.

The local demo is run with SQLite and synthetic data. It is a repeatable development and demonstration profile, not a substitute for PostgreSQL production behavior, live CRM integration, real-data model validation, security certification or the remaining partial items in phases 2–20. See `docs/verification/V13_LOCAL_DEMO_SCOPE.md`, `docs/verification/V13_RELEASE_NOTES.md`, `reports/local_demo_acceptance.json` and `reports/verification.md`.

## V14 release addendum — 2026-11-07

V14 expands the dashboard and API with permission-filtered CSV/JSON report exports, an administrator user-management and audit-history area, a group fairness review for model predictions, and exact point-in-time feature snapshot retrieval. Reports include overview, customers (email omitted), predictions, models, retention worklist, quality findings, imports, cohorts, survival points and administrator audit events. CSV exports neutralize formula-like untrusted text cells. The fairness review joins predictions to exact mature, uncensored customer/cutoff/horizon labels, surfaces group sample sizes and small-sample warnings, and is explicitly descriptive rather than a fairness certification.

The updated browser bridge exercises Reports and Administration, downloads a report, creates a user, verifies audit history, and opens the training dataset readiness/leakage panel before continuing the upload / Customer 360 / logout flow. The V14 base suite had 111 tests; V14.1 expands this to 115. V14 does not close the ten production-only gates or complete every remaining partial requirement in phases 2–20. The verified working scope is expanded, but a production approval still requires actual PostgreSQL/Docker/toolchain/MLOps evidence, hosted deployment and CRM credentials, authorized company churn data, business-policy approval and an independent penetration test. See `docs/verification/V14_RELEASE_NOTES.md` and the fresh V14 reports.


## V14.1 release addendum — 2026-11-07

V14.1 adds a role-protected ML dataset readiness and leakage review endpoint and a connected Models-page panel. The audit reports exact mature label-to-feature joins, future/unmatured label exclusions, event-window consistency, feature missingness, chronological train/validation/test sizes and class balance, repeated-customer partition overlap, and a reproducible dataset fingerprint. Training now excludes future-maturity labels, invalid event dates, mismatched maturity windows, missing feature snapshots and malformed feature records before fitting. The browser bridge verifies the new panel and API response. The strict suite now records **115 passed / 0 failed / 0 skipped**. These controls strengthen Phase 11 and the integrity of training, but they do not certify raw source-timestamp lineage or company-data correctness. The overall production acceptance remains **14 PASS / 0 FAIL / 10 BLOCKED** because the missing runtime, hosted and external approvals are unchanged.


## V15 release addendum — durable asynchronous execution

V15 adds a persisted `background_jobs` table and a separate worker process. Jobs carry validated typed payloads, idempotency key and payload digest, priority, attempt limits, progress, lease metadata, result and error state. The worker claims work with dialect-aware locking (`FOR UPDATE SKIP LOCKED` on PostgreSQL), renews leases, recovers expired claims, applies bounded retry/backoff, fences stale workers from overwriting newer claims and removes queued import files only after successful persisted completion.

The dashboard now submits long-running imports, label generation, feature construction, data-quality audits, training, batch scoring, retention generation and REST source sync to the queue. The Jobs & activity screen exposes status/progress and retry/cancel actions. SQLite local demo is explicitly single-worker; PostgreSQL is the intended multi-worker runtime. The new isolated SQLite integration smoke migrates an empty temporary DB, enqueues a quality-audit job, runs a worker, and checks claim, handler, persisted result and released lease. This does **not** establish PostgreSQL row-lock behavior, multi-worker correctness, Docker orchestration or production throughput.

Fresh V15 verification: **122 strict regression tests passed**; staged evidence records **15 PASS / 0 FAIL / 10 BLOCKED across 25 unique acceptance checks**. Core, runtime (including the SQLite worker), migrations/Compose/CI static contract, synthetic ML workflow and Chromium UI/API stages all passed. The ten production gates remain open for five technical runtime/toolchain requirements and five company/independent-owner requirements. See `docs/BACKGROUND_JOBS_V15.md`, `docs/verification/V15_GATE_CLOSURE_CHECKLIST.md` and `reports/verification.md`.


## V16 release addendum — experiment governance, outbound safety and CI closure automation

V16 fixes a concrete Salesforce adapter safety defect: DNS validation of the Salesforce instance host now executes for the production-created HTTP client before request dispatch. Regression coverage verifies rejection when the configured public-looking Salesforce host resolves to a private IP. Test-injected transports remain available for deterministic contract tests and do not represent live provider validation.

V16 adds a retention-experiment sample-size planner for two independent binary proportions with adjustable baseline retention, minimum detectable lift, treatment allocation, alpha and target power. The planner exposes assumptions and attrition/clustering caveats and is connected to the Retention UI. Recorded experiment outcomes are now immutable through the normal endpoint and produce actor-attributed audit events. Reports separate assigned, matured, binary-observed and missing/nonbinary counts per arm, and explicitly label the built-in comparison as complete-case rather than strict intent-to-treat.

The GitHub Actions workflow now has a final aggregation job. It downloads artifacts from the current run, checks exact repository, run ID, attempt, commit SHA, job status and required report payloads, and writes an unreviewed `hosted_evidence_aggregate.json`. Automated aggregation cannot impersonate a human release reviewer; only a separate reviewed import may write `hosted_gate_closure.json`.

V16 current-source strict pytest and all local verification stages are recorded in `reports/verification.json` and `reports/verification_*.json`. PostgreSQL, Docker, clean-install, MLOps, quality/security toolchain and five company/independent-owner gates remain blocked until their specified actual evidence is executed and reviewed.


## V17 release addendum — governed Feature Store and atomic quality review

V17 adds a first-class Feature Store workflow on top of the immutable point-in-time `FeatureSnapshot` records. The feature registry is derived from the model feature contract rather than a second hard-coded list. The API exposes registry metadata, record/customer coverage and per-feature missingness, point-in-time online retrieval (latest eligible snapshot at or before the requested as-of timestamp), per-customer history and bounded CSV export. Feature materialization is submitted to the durable background queue using the existing `build_features` handler and idempotency contract. The dashboard has a dedicated Feature Store page for coverage, registry, online lookup, export and job submission.

Data Quality now supports bulk decisions for open findings (`accepted_risk` or `false_positive`). The service validates unique IDs, selection size, allowed decision and the existence/open status of every finding before it mutates any record. The operation is all-or-nothing and writes one actor-attributed audit event per finding. It deliberately does not offer bulk field correction, avoiding unsafe broad changes to customer data.

A new isolated product workflow smoke exercises login, registry, summary/coverage, as-of lookup, history, export, queued materialization, persisted job idempotency, atomic bulk review and per-finding audit events. The browser bridge visits the Feature Store panel. Local Windows/POSIX acceptance runners, the production aggregate and the hosted CI workflow include this new stage. The product workflow adds one current production-acceptance pass and one local-demo check; it does not close any of the ten external/production runtime gates.

Fresh V17 evidence: **147 strict regression tests passed, 0 failed, 0 skipped; 16 PASS / 0 FAIL / 10 BLOCKED across 26 unique production acceptance checks; local-demo scope 15/15 PASS.** Feature Store and bulk-review runtime proof uses an isolated SQLite database. PostgreSQL concurrency, Docker deployment, live CRM, hosted staging, real-company feature freshness/model quality, business sign-off and independent penetration testing remain open and must be supported by their own evidence.
