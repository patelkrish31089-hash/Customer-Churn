# Source-prompt reconciliation notes

The uploaded master prompt is the implementation source of truth. Its phase headers are not perfectly normalized:

1. It contains two Phase 2 prompts: `Dataset Collection` and `Advanced Dataset Collection & Integration`. They are treated as two levels of the same data-collection phase, not two separate roadmap phases.
2. It contains two Phase 4 prompts: `Data Validation, Cleaning & Standardization` and `Advanced Data Quality & Validation Engine`. They are treated as a base and expanded specification for Phase 4.
3. A Phase 3 section appears as `Data Cleaning, Preparation & EDA` in the roadmap bridge and as data ingestion in the later phase dependency descriptions. The implementation maps row-level CSV ingestion/validation here, but it does not invent an additional advanced pipeline beyond the source text.
4. The Phase 18 heading is embedded as `Phase 18 — CRM & Campaign Automation Integration` within the long prompt text rather than as a top-level `# Phase 18` heading. The section is present and included in the roadmap.
5. The Phase 17 text refers to the Phase 18 CRM handoff. The implementation keeps them separate: Phase 17 creates and approves internal recommendations; Phase 18 is the separate external provider boundary.

The supplied prompt does not contain a source-code repository or existing project ZIP. It contains implementation requirements only. This codebase was therefore created as a new local-first implementation rather than modifying a prior repository. Do not use its initial migration on an existing company database without a reviewed migration plan.

No company-approved data dictionary, churn policy, source completeness agreement, currency policy beyond standard separation, customer identity mapping, retention policy, real churn outcomes, provider credentials or deployment environment were provided. These are explicitly treated as configuration/input dependencies rather than invented business facts.
