# Local setup and operator guide

## Scope

This is an advanced local-first Customer Churn Prediction & Retention Intelligence application. It contains a modular FastAPI backend, same-origin dashboard, SQLAlchemy/Alembic persistence, six canonical data families, data-quality review, churn labels, point-in-time feature snapshots v2.1, analytics, local ML comparison/evaluation, approved-model inference, Customer 360, retention governance, provider adapters, drift tooling and test evidence.

The supplied material was a specification prompt, not the previous source repository. This codebase therefore extends the local reference application produced from that prompt; it is not a patch against an unavailable company repository. The V10 implementation is **not** a fully production-ready completion of all 20 phases. See `ROADMAP_COVERAGE.md` and `verification/RELEASE_READINESS.md`.

## Prerequisites and installation

- Python 3.11+ (workspace verification used Python 3.13.5).
- pip.
- Optional Docker Engine and Compose plugin for the authored PostgreSQL Compose stack.

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
# Optional boosted-tree model families:
python -m pip install -r requirements-advanced-ml.txt
# Optional SHAP explanation support:
python -m pip install -r requirements-explainability.txt
# Optional MLflow/Evidently tracking and drift tools:
python -m pip install -r requirements-mlops-optional.txt
# Airflow is intentionally installed separately using the official constraints for the chosen Python version.
```

Create `.env` from `.env.example`. Do not commit secrets. SQLite is the default. The included PostgreSQL compose file is a configuration artifact; this workspace did not execute a Docker or PostgreSQL runtime test.

## Initialize and create an administrator

```bash
python -m app.cli init-db
python -m app.cli create-admin --username admin --password "Use-A-Unique-Long-Password!"
```

No default credentials are provisioned. Passwords use PBKDF2-HMAC-SHA256 with per-user random salt. Staging/production session token digests use the configured HMAC secret; rotation invalidates sessions.

## Seed optional synthetic data

```bash
python -m app.cli seed-demo --customers 180 --seed 29
```

Synthetic records use `synthetic_demo` provenance and `.invalid` email addresses. They are for functional tests only. Do not cite their metrics as real customer churn performance, retention lift or savings.

## Start

```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

- Dashboard: `http://127.0.0.1:8000/`
- OpenAPI: `http://127.0.0.1:8000/docs`
- Liveness: `/api/v1/health/live`
- Readiness: `/api/v1/health/ready`

## Main local workflow

1. Create an administrator and sign in.
2. Import customers and subscriptions before dependent invoices, payments, usage and support data.
3. Import CSV, XLSX or JSON through `/api/v1/imports/{dataset_type}`. Valid rows are persisted; invalid rows are quarantined with source batch and row diagnostics. Original files are stored under the configured upload directory with generated names.
4. Create or inspect configurable data-quality rules, execute a quality audit, review findings and record corrections. Corrections are authorized, field-allowlisted and audited; review does not silently change unrelated source fields.
5. Optionally configure an allowlisted HTTPS JSON REST source. The connector maps a JSON array/path into the canonical import path. It is not a generic arbitrary-URL fetcher; provider-specific authentication, DNS egress firewalling and source contractual validation remain deployment concerns.
6. Generate customer or subscription churn labels at a defined cutoff. The current default target is a 30-day horizon, with maturity/right-censoring. The company must approve lifecycle, cancellation and reactivation definitions before production use.
7. Build feature snapshots using version `2.1` at matching prediction cutoffs. Snapshots are immutable. Money is not summed across currency codes; scalar money features are emitted only when a feature's scope has one currency.
8. Review EDA, acquisition cohorts and Kaplan-Meier survival curves. Outputs are descriptive; confidence intervals are pointwise/approximate where documented and do not imply causal findings.
9. Train chronological candidate model families. Logistic Regression and Random Forest are part of core dependencies; XGBoost and LightGBM are optional extras. Validation data selects candidates and threshold; held-out test data is scored after selection. Optional false-positive and false-negative costs must be supplied in the same business unit/currency by the user; the app does not invent costs.
10. Approve a model candidate as an administrator. Candidate training does not automatically activate an artifact.
11. Score one customer or a batch against a pinned approved release. Batch records support partial failures and retry of failed customer IDs.
12. Review Customer 360, SHAP explanation availability, customer lifecycle timeline and source freshness.
13. Generate and review retention recommendations, assign playbooks, and run controlled experiments. Only mature outcomes are included in reported experiment results.
14. CRM provider execution uses explicit approval, consent, identity mapping and idempotency. No CRM account is configured in this package. The sandbox endpoint remains simulated and does not send messages.
15. Review drift/integration capability status. PSI is feature drift, not model accuracy.

## Supported import contracts

Six dataset types: `customers`, `subscriptions`, `invoices`, `payments`, `usage`, `support`. Canonical field requirements are documented in `DATA_DICTIONARY.md`; the API upload supports CSV, XLSX and JSON. Use ISO 8601 timestamps and three-letter currency codes. Monetary amounts are represented using decimal database types. Import parents before child records. Do not upload unnecessary sensitive attributes.

## Key API groups

| Group | Representative routes |
|---|---|
| Auth/admin | `/api/v1/auth/*`, `/api/v1/admin/users`, `/api/v1/admin/backup` |
| Imports/sources | `/api/v1/imports/*`, `/api/v1/sources`, `/api/v1/sources/{key}/sync` |
| Customers | `/api/v1/customers`, `/api/v1/customers/{id}` |
| Analytics | `/api/v1/analytics/labels`, `/features`, `/eda`, `/cohorts`, `/survival`, `/financial-impact` |
| Quality | `/api/v1/quality/rules`, `/audit`, `/findings`, `/runs` |
| ML | `/api/v1/ml/train`, `/models`, `/predict/{id}`, `/predict/batch`, batch retry and SHAP global summary |
| Retention | recommendations, playbooks, assignments and experiment lifecycle under `/api/v1/retention/*` |
| CRM | identity mapping, provider execute, sandbox execute and action history under `/api/v1/crm/*` |
| Ops | `/api/v1/ops/integrations`, `/drift`, `/performance`, `/retraining-readiness` |

## Verification commands

Run the gates independently, in this order, then aggregate the evidence:

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```

The core stage runs `python -m pytest -q -W error`. Each stage records the exact command, exit code, duration and output under `reports/verification_<stage>.json`; the final aggregate is `reports/verification.json` and `reports/verification.md`. A blocked stage is not a pass. PostgreSQL offline migration compilation verifies SQL generation only, not an actual PostgreSQL server.

## PostgreSQL Compose

```bash
# Set POSTGRES_PASSWORD in .env first.
docker compose up --build
```

The Compose file defines PostgreSQL 16, app service, health checks, persistent DB/upload/artifact volumes and non-root app execution. Static YAML/config validation passed in the workspace; Docker CLI/daemon was unavailable, so container build/start/readiness and PostgreSQL migration tests remain unverified.

## Backup and recovery

The admin-only SQLite backup endpoint uses SQLite backup and integrity verification. It returns `501` for non-SQLite databases. PostgreSQL deployment requires `pg_dump`/`pg_restore` or managed backup tooling, restore drills and documented RPO/RTO. Do not restore over a running DB; preserve a separate backup before recovery.

## Production gates

Real approved data; business-approved churn/censor definitions; source completeness and identity policies; PostgreSQL runtime tests; DNS/egress protection for REST sync; encrypted OAuth token vault/refresh/webhook verification; real CRM sandbox tests; MLflow/Airflow/Evidently runtime; model fairness and external validation; tenant isolation; secrets/TLS/rate limiting; vulnerability, accessibility, browser E2E and disaster-recovery tests; hosted staging; business and security sign-off. None can be replaced by synthetic demos.


V10 strict verification command:

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```
