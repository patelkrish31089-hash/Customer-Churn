# V15 durable background jobs

## Purpose

Long-running data imports, label generation, feature builds, data-quality audits, model training, batch scoring, retention recommendation generation, and configured REST source synchronization are submitted to a database-backed queue. The API returns `202 Accepted`; a separately managed worker performs the operation. The dashboard's **Jobs & activity** screen shows state, progress, attempt count, error/result, and allows a queued job to be cancelled or a failed job to be retried.

## Components

- `background_jobs` Alembic migration: durable queue records, unique idempotency key, scheduling fields, lease fields, result and error state.
- `app/services/jobs.py`: strict allowlisted payload schemas, role matrix, payload digests, idempotent enqueue and job handlers.
- `app/worker.py`: priority-based claim, PostgreSQL `FOR UPDATE SKIP LOCKED`, lease heartbeat, lease recovery and bounded exponential retry.
- `app/main.py`: authenticated queue, list, status, cancel, retry and upload endpoints under `/api/v1/jobs`. Non-admin users only see their own jobs.
- `app/static/app.js`: Jobs & activity, async import, labels/features, quality, model training, batch scoring and source sync controls.
- `docker-compose.yml`: dedicated worker service using the same database and upload/artifact volumes as the API.

## Start locally (SQLite)

Start one worker process in a second terminal. The local demo launchers already start one worker and stop it when the API process exits. SQLite is supported for a single local worker; do not run concurrent worker replicas against SQLite.

```bash
python -m app.cli init-db
python -m app.worker run --poll-interval 2 --lease-seconds 900
```

In another terminal run the API: `uvicorn app.main:app --host 127.0.0.1 --port 8000`.

## Start with Docker Compose

Set a strong `POSTGRES_PASSWORD` in `.env`, then run `docker compose up --build`. Compose starts PostgreSQL, the API and the worker. The worker depends on API/database readiness and shares persistent upload/artifact volumes.

## API contract

- `POST /api/v1/jobs` — create one allowlisted job, `202 Accepted`, requires an idempotency key.
- `POST /api/v1/jobs/imports/{dataset_type}` — bounded multipart upload and queue an import, requires `Idempotency-Key`.
- `GET /api/v1/jobs` and `GET /api/v1/jobs/summary` — list and status counts.
- `GET /api/v1/jobs/{job_id}` — job detail.
- `POST /api/v1/jobs/{job_id}/cancel` — cancel queued/retry-wait jobs.
- `POST /api/v1/jobs/{job_id}/retry` — reset a failed job for a fresh attempt.

Job payloads use strict schemas; arbitrary code, shell commands or arbitrary handler names cannot be submitted. The role matrix is enforced both at the API and job-type allowlist. Uploaded files receive server-generated names and a SHA-256 digest. Workers validate the content checksum and resolve the path under the configured `uploads/queued` directory before processing. Files are retained on failure for retry/investigation and removed only after successful completion is persisted.

## Delivery semantics and operational notes

The queue is **at-least-once**, not exactly-once. A worker may be interrupted after a handler commits its domain transaction but before marking the job successful; handlers must therefore be idempotent or use a stable downstream idempotency key. Batch scoring derives a stable key from the job's idempotency key. Imports deduplicate completed batches by dataset type and content checksum.

Workers renew their lease while a handler executes. If a worker dies, the job becomes claimable again after the lease expires. Retry attempts use bounded exponential delay and stop after `max_attempts`; an administrator or original submitter can inspect and manually retry a failed job. Job errors are truncated before persistence to avoid unbounded database growth.

For SQLite run a single worker. PostgreSQL supports multiple workers through row-level `SKIP LOCKED`, but multi-worker contention, process kill/recovery, high-volume throughput, connection pool sizing and retention of completed job rows still require deployment-specific load and operations tests. The worker queue does not send CRM messages or payments; external campaign execution remains guarded by explicit human approval and provider credentials.

## Verification evidence

- `tests/test_background_jobs.py`: strict payload allowlist, RBAC, idempotency, worker execution, leases, retry/cancel and secure asynchronous import/checksum tests.
- `scripts/worker_queue_smoke.py`: runs an actual job against the configured database and writes `reports/worker_queue_runtime_evidence.json`. A production PostgreSQL pass requires `database_dialect=postgresql`.
- `scripts/docker_runtime_smoke.sh`: enqueues a job in Compose, waits for the worker to complete it, restarts the API, reads the persisted job status again, and checks PostgreSQL backup/restore.

Static Compose validation or a SQLite worker smoke does not count as proof of Docker or PostgreSQL runtime acceptance.
