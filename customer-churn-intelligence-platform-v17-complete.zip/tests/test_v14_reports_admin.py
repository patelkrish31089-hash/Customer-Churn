from __future__ import annotations

from datetime import datetime, timezone

from app.models import ChurnLabel, Customer, FeatureSnapshot, Prediction
from app.services.reporting import build_report, to_csv
from app.utils import json_dumps


def login(client, username: str, password: str) -> dict[str, str]:
    response = client.post("/api/v1/auth/login", json={"username": username, "password": password})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_report_catalog_and_download_permissions(client, users):
    admin = login(client, "admin", "a-strong-password-123")
    viewer = login(client, "viewer", "viewer-password-12345")

    catalog = client.get("/api/v1/reports/catalog", headers=admin)
    assert catalog.status_code == 200
    keys = {item["key"] for item in catalog.json()["reports"]}
    assert {"customers", "predictions", "models", "retention", "quality", "audit"} <= keys

    csv_response = client.get("/api/v1/reports/customers/export?format=csv", headers=admin)
    assert csv_response.status_code == 200
    assert "text/csv" in csv_response.headers["content-type"]
    assert "attachment" in csv_response.headers["content-disposition"]
    assert "external_id" in csv_response.text

    json_response = client.get("/api/v1/reports/overview/export?format=json", headers=viewer)
    assert json_response.status_code == 200
    assert json_response.json()["report_key"] == "overview"

    forbidden = client.get("/api/v1/reports/customers/export?format=csv", headers=viewer)
    assert forbidden.status_code == 403
    audit_forbidden = client.get("/api/v1/reports/audit/export?format=json", headers=viewer)
    assert audit_forbidden.status_code == 403


def test_report_export_rejects_unknown_report_and_format(client, users, auth_headers):
    unknown = client.get("/api/v1/reports/not-a-report/export", headers=auth_headers)
    assert unknown.status_code == 404
    invalid_format = client.get("/api/v1/reports/customers/export?format=xlsx", headers=auth_headers)
    assert invalid_format.status_code == 422


def test_csv_export_neutralizes_spreadsheet_formula_injection():
    report = {
        "columns": ["name", "comment", "balance"],
        "rows": [{"name": "=HYPERLINK(\"https://attacker.invalid\")", "comment": "+cmd|' /C calc'!A0", "balance": -12.5}],
    }
    csv_text = to_csv(report)
    assert "'=HYPERLINK" in csv_text
    assert "'+cmd" in csv_text
    assert "-12.5" in csv_text


def test_admin_user_management_and_audit_are_role_protected(client, users, auth_headers):
    created = client.post("/api/v1/admin/users", headers=auth_headers,
                          json={"username": "new.analyst", "password": "new-analyst-password-456", "role": "analyst"})
    assert created.status_code == 201, created.text
    user_id = created.json()["id"]

    listed = client.get("/api/v1/admin/users", headers=auth_headers)
    assert listed.status_code == 200
    assert any(row["id"] == user_id for row in listed.json())
    assert all("password_hash" not in row for row in listed.json())

    deactivated = client.patch(f"/api/v1/admin/users/{user_id}/status", headers=auth_headers,
                               json={"is_active": False})
    assert deactivated.status_code == 200
    assert deactivated.json()["is_active"] is False

    events = client.get("/api/v1/admin/audit-events?limit=20", headers=auth_headers)
    assert events.status_code == 200
    assert any(row["action"] == "user_deactivated" and row["entity_id"] == str(user_id) for row in events.json())

    viewer_headers = login(client, "viewer", "viewer-password-12345")
    assert client.get("/api/v1/admin/users", headers=viewer_headers).status_code == 403
    assert client.get("/api/v1/admin/audit-events", headers=viewer_headers).status_code == 403


def test_admin_cannot_disable_self_but_can_disable_another_admin(client, auth_headers, users):
    self_disable = client.patch(f"/api/v1/admin/users/{users['admin'].id}/status", headers=auth_headers,
                                json={"is_active": False})
    assert self_disable.status_code == 409

    second = client.post("/api/v1/admin/users", headers=auth_headers,
                         json={"username": "second.admin", "password": "second-admin-password-456", "role": "admin"})
    assert second.status_code == 201
    response = client.patch(f"/api/v1/admin/users/{second.json()['id']}/status", headers=auth_headers,
                            json={"is_active": False})
    assert response.status_code == 200
    assert response.json()["is_active"] is False


def test_fairness_audit_uses_exact_mature_prediction_label_join(db_session):
    cutoff = datetime(2025, 1, 1, tzinfo=timezone.utc)
    for segment in ("smb", "enterprise"):
        for index in range(10):
            actual = 1 if index < 5 else 0
            customer = Customer(
                external_id=f"{segment}-{index}", name=f"{segment.title()} {index}",
                segment=segment, country="IN", consent_to_contact=False,
            )
            db_session.add(customer)
            db_session.flush()
            snapshot = FeatureSnapshot(customer_id=customer.id, cutoff_date=cutoff,
                                       feature_version="2.1", features_json=json_dumps({"usage": 3.0}),
                                       source_fingerprint=f"fingerprint-{segment}-{index}")
            db_session.add(snapshot)
            db_session.flush()
            db_session.add(ChurnLabel(customer_id=customer.id, entity_scope="customer",
                                      entity_ref=customer.external_id, cutoff_date=cutoff,
                                      horizon_days=30, churn_30d=actual, churn_type="VOLUNTARY" if actual else "NONE",
                                      maturity_date=cutoff, is_censored=False, policy_version="test"))
            db_session.add(Prediction(customer_id=customer.id, release_id="release-test",
                                      cutoff_date=cutoff, horizon_days=30,
                                      probability=0.8 if actual else 0.2,
                                      risk_band="high" if actual else "low",
                                      feature_snapshot_id=snapshot.id, explanation_json="{}"))
    db_session.commit()

    from app.services.analytics import fairness_audit
    result = fairness_audit(db_session, "release-test", threshold=0.5,
                            group_by="segment", min_group_size=10)
    assert result["matched_mature_predictions"] == 20
    assert result["eligible_group_count"] == 2
    assert result["status"] == "reviewable"
    assert result["descriptive_disparities"]["selection_rate_gap"] == 0.0
    assert result["descriptive_disparities"]["recall_tpr_gap"] == 0.0
    assert result["groups"]["smb"]["sample_count"] == 10


def test_fairness_endpoint_requires_analyst_or_admin(client, users):
    viewer = login(client, "viewer", "viewer-password-12345")
    response = client.get("/api/v1/analytics/fairness?release_id=missing", headers=viewer)
    assert response.status_code == 403


def test_feature_snapshot_endpoint_returns_exact_version_and_cutoff(client, db_session, auth_headers, users):
    cutoff = datetime(2025, 3, 1, tzinfo=timezone.utc)
    customer = Customer(external_id="feature-customer", name="Feature Customer", consent_to_contact=False)
    db_session.add(customer)
    db_session.flush()
    snapshot = FeatureSnapshot(customer_id=customer.id, cutoff_date=cutoff, feature_version="2.1",
                               features_json=json_dumps({"usage_events_30d": 4}),
                               source_fingerprint="f" * 64)
    db_session.add(snapshot)
    db_session.commit()

    response = client.get("/api/v1/analytics/features/customer/1",
                          params={"cutoff_at": cutoff.isoformat(), "feature_version": "2.1"},
                          headers=auth_headers)
    assert response.status_code == 200, response.text
    assert response.json()["features"]["usage_events_30d"] == 4
    assert response.json()["immutable"] is True

    missing = client.get("/api/v1/analytics/features/customer/1",
                         params={"cutoff_at": cutoff.isoformat(), "feature_version": "9.9"},
                         headers=auth_headers)
    assert missing.status_code == 404


def test_deactivated_user_sessions_are_rejected_immediately(client, users, auth_headers):
    created = client.post(
        "/api/v1/admin/users",
        headers=auth_headers,
        json={"username": "session.revoked", "password": "revoked-session-password-456", "role": "analyst"},
    )
    assert created.status_code == 201, created.text
    user_headers = login(client, "session.revoked", "revoked-session-password-456")
    assert client.get("/api/v1/auth/me", headers=user_headers).status_code == 200

    deactivated = client.patch(
        f"/api/v1/admin/users/{created.json()['id']}/status",
        headers=auth_headers,
        json={"is_active": False},
    )
    assert deactivated.status_code == 200
    rejected = client.get("/api/v1/auth/me", headers=user_headers)
    assert rejected.status_code == 401

    reactivated = client.patch(
        f"/api/v1/admin/users/{created.json()['id']}/status",
        headers=auth_headers,
        json={"is_active": True},
    )
    assert reactivated.status_code == 200
    old_token_after_reactivation = client.get("/api/v1/auth/me", headers=user_headers)
    assert old_token_after_reactivation.status_code == 401
    fresh_headers = login(client, "session.revoked", "revoked-session-password-456")
    assert client.get("/api/v1/auth/me", headers=fresh_headers).status_code == 200


def test_training_dataset_audit_reports_chronological_partitions_and_fingerprint(db_session):
    from app.demo import seed_demo
    from app.services.dataset_audit import audit_training_dataset

    seeded = seed_demo(db_session, customers=120, seed=772)
    assert seeded["not_real_company_data"]
    report = audit_training_dataset(db_session, feature_version="2.1", horizon_days=30)
    assert report["status"] == "ready_for_training"
    assert report["dataset"]["rows"] >= 30
    assert len(report["dataset"]["fingerprint"]) == 64
    assert set(report["partitions"]) == {"train", "validation", "test"}
    assert all(part["rows"] >= 10 and part["has_both_classes"] for part in report["partitions"].values())
    assert report["readiness_checks"]["feature_contract_has_no_target_like_names"] is True
    assert any("not evidence" in warning.lower() for warning in report["warnings"])


def test_training_dataset_audit_excludes_immature_and_invalid_event_labels(db_session):
    from datetime import timedelta
    from app.services.dataset_audit import audit_training_dataset

    now = datetime.now(timezone.utc)
    future_cutoff = now + timedelta(days=1)
    future_customer = Customer(external_id="future-label-customer", name="Future Label", consent_to_contact=False)
    db_session.add(future_customer)
    db_session.flush()
    db_session.add(FeatureSnapshot(customer_id=future_customer.id, cutoff_date=future_cutoff,
                                   feature_version="2.1", features_json=json_dumps({"usage_events_30d": 3}),
                                   source_fingerprint="a" * 64))
    db_session.add(ChurnLabel(customer_id=future_customer.id, entity_scope="customer",
                              entity_ref=future_customer.external_id, cutoff_date=future_cutoff,
                              horizon_days=30, churn_30d=0, churn_type="NONE", event_date=None,
                              maturity_date=future_cutoff + timedelta(days=30), is_censored=False,
                              policy_version="test"))

    past_cutoff = now - timedelta(days=100)
    invalid_customer = Customer(external_id="invalid-event-customer", name="Invalid Event", consent_to_contact=False)
    db_session.add(invalid_customer)
    db_session.flush()
    maturity = past_cutoff + timedelta(days=30)
    db_session.add(FeatureSnapshot(customer_id=invalid_customer.id, cutoff_date=past_cutoff,
                                   feature_version="2.1", features_json=json_dumps({"usage_events_30d": 3}),
                                   source_fingerprint="b" * 64))
    db_session.add(ChurnLabel(customer_id=invalid_customer.id, entity_scope="customer",
                              entity_ref=invalid_customer.external_id, cutoff_date=past_cutoff,
                              horizon_days=30, churn_30d=1, churn_type="VOLUNTARY",
                              event_date=maturity + timedelta(days=1), maturity_date=maturity,
                              is_censored=False, policy_version="test"))
    db_session.commit()

    report = audit_training_dataset(db_session, feature_version="2.1", horizon_days=30, as_of=now)
    assert report["dataset"]["rows"] == 0
    assert report["exclusions"]["label_horizon_not_yet_mature"] == 1
    assert report["exclusions"]["positive_event_outside_horizon"] == 1
    assert report["status"] == "insufficient_or_blocked"


def test_dataset_audit_api_is_role_protected_and_validates_horizon(client, users, auth_headers):
    allowed = client.get("/api/v1/ml/dataset-audit?feature_version=2.1&horizon_days=30", headers=auth_headers)
    assert allowed.status_code == 200
    assert "readiness_checks" in allowed.json()
    invalid = client.get("/api/v1/ml/dataset-audit?horizon_days=400", headers=auth_headers)
    assert invalid.status_code == 422
    viewer_headers = login(client, "viewer", "viewer-password-12345")
    forbidden = client.get("/api/v1/ml/dataset-audit", headers=viewer_headers)
    assert forbidden.status_code == 403
