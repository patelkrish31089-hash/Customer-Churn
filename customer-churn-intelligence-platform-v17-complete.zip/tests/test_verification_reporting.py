from __future__ import annotations

from scripts import verify


def test_shared_interpreter_dependency_check_is_not_project_acceptance(monkeypatch):
    def unexpected_run(*args, **kwargs):
        raise AssertionError("shared interpreter pip check must not run as a project acceptance check")

    monkeypatch.setattr(verify, "run_check", unexpected_run)
    result = verify.host_environment_diagnostic()
    assert result["status"] == "NOT_APPLICABLE"
    assert result["exit_code"] is None
    assert "clean virtual-environment acceptance gate" in result["output"]
    assert "clean-install production gate remains blocked" in result["note"]


def test_missing_tools_are_grouped_once_by_functional_gate():
    inventory = {
        "mlflow": "not_installed", "airflow": "not_installed", "evidently": "not_installed",
        "psycopg": "not_installed", "postgres_server_tools": "not_installed",
        "docker_cli": "not_installed", "pip_audit": "not_installed", "bandit": "not_installed",
        "ruff": "not_installed",
    }
    groups = verify.unavailable_tool_groups(inventory)
    assert set(groups) == {
        "mlops_runtime", "postgresql_runtime", "docker_runtime", "quality_and_security_toolchain"
    }
    assert groups["mlops_runtime"] == ["mlflow", "airflow", "evidently"]
    assert groups["postgresql_runtime"] == ["psycopg", "postgres_server_tools"]
    assert groups["docker_runtime"] == ["docker_cli"]
    assert groups["quality_and_security_toolchain"] == ["pip_audit", "bandit", "ruff"]


def test_ci_workflow_contract_contains_external_acceptance_jobs():
    from scripts import ci_workflow_check

    assert ci_workflow_check.main() == 0


def test_postgres_runtime_smoke_refuses_sqlite_as_postgres(monkeypatch, capsys):
    from scripts import postgres_runtime_smoke

    monkeypatch.setenv("DATABASE_URL", "sqlite:///:memory:")
    assert postgres_runtime_smoke.main() == 2
    assert '"status": "blocked"' in capsys.readouterr().out
