from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db import Base, get_db
import app.models  # noqa
from app.main import app
from app.models import User
from app.security import hash_password


@pytest.fixture()
def db_engine():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    from sqlalchemy import event
    @event.listens_for(engine, "connect")
    def fk_on(conn, _):
        conn.execute("PRAGMA foreign_keys=ON")
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture()
def db_session(db_engine):
    Factory = sessionmaker(bind=db_engine, autoflush=False, autocommit=False, expire_on_commit=False)
    db = Factory()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture()
def client(db_engine, db_session):
    Factory = sessionmaker(bind=db_engine, autoflush=False, autocommit=False, expire_on_commit=False)
    def override_db():
        db = Factory()
        try:
            yield db
        finally:
            db.close()
    app.dependency_overrides[get_db] = override_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture()
def users(db_session):
    admin = User(username="admin", password_hash=hash_password("a-strong-password-123"), role="admin")
    analyst = User(username="analyst", password_hash=hash_password("another-strong-password-123"), role="analyst")
    manager = User(username="manager", password_hash=hash_password("retention-password-12345"), role="retention_manager")
    viewer = User(username="viewer", password_hash=hash_password("viewer-password-12345"), role="viewer")
    db_session.add_all([admin, analyst, manager, viewer]); db_session.commit()
    return {"admin":admin,"analyst":analyst,"manager":manager,"viewer":viewer}


@pytest.fixture()
def auth_headers(client, users):
    r = client.post("/api/v1/auth/login", json={"username":"admin","password":"a-strong-password-123"})
    assert r.status_code == 200, r.text
    return {"Authorization":f"Bearer {r.json()['access_token']}"}
