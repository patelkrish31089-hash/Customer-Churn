from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from app.models import AuditEvent, Customer, DataQualityFinding, DataQualityRun, FeatureSnapshot
from app.services.feature_store import (customer_feature_history, feature_registry,
                                        feature_store_summary, latest_online_features)
from app.services.quality import bulk_review_findings
from app.utils import json_dumps


def _login(client, username="admin", secret_value="a-strong-password-123"):
    response = client.post("/api/v1/auth/login", json={"username": username, "password": secret_value})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def _customer_with_snapshots(db_session):
    customer = Customer(external_id="FEATURE-STORE-CUSTOMER", name="Feature Store Customer",
                        segment="smb", consent_to_contact=False)
    db_session.add(customer)
    db_session.flush()
    first = datetime(2026, 1, 1, tzinfo=timezone.utc)
    second = first + timedelta(days=10)
    db_session.add_all([
        FeatureSnapshot(customer_id=customer.id, cutoff_date=first, feature_version="2.1",
                       features_json=json_dumps({"tenure_days": 100, "usage_events_30d": 8}),
                       source_fingerprint="a" * 64),
        FeatureSnapshot(customer_id=customer.id, cutoff_date=second, feature_version="2.1",
                       features_json=json_dumps({"tenure_days": 110, "usage_events_30d": 12}),
                       source_fingerprint="b" * 64),
    ])
    db_session.commit()
    return customer, first, second


def test_feature_registry_is_versioned_and_matches_training_contract():
    from app.services.ml import NUMERIC_FEATURES

    registry = feature_registry("2.1")
    names = [item["name"] for item in registry["features"]]
    assert names == NUMERIC_FEATURES
    assert len(names) == len(set(names))
    assert registry["feature_count"] == len(NUMERIC_FEATURES)
    assert all(item["point_in_time"] and item["nullable"] for item in registry["features"])
    assert registry["currency_policy"].startswith("Monetary values")
    with pytest.raises(ValueError, match="Unsupported"):
        feature_registry("99.0")


def test_feature_store_summary_reports_missingness_without_inventing_values(db_session):
    customer, _, _ = _customer_with_snapshots(db_session)
    result = feature_store_summary(db_session, "2.1")
    assert result["snapshot_count"] == 2
    assert result["unique_customers"] == 1
    assert result["feature_count"] == len(feature_registry()["features"])
    assert result["missingness"]["tenure_days"]["missing_count"] == 0
    assert result["missingness"]["usage_events_30d"]["missing_count"] == 0
    assert result["missingness"]["payment_failures_90d"]["missing_count"] == 2
    assert len(result["immutability_key"]) == 3


def test_online_feature_retrieval_never_uses_a_future_snapshot(db_session):
    customer, first, second = _customer_with_snapshots(db_session)
    as_of = first + timedelta(days=3)
    result = latest_online_features(db_session, customer.id, as_of, freshness_days=7)
    assert result is not None
    assert result["cutoff_at"] == first
    assert result["features"]["usage_events_30d"] == 8
    assert result["fresh"] is True
    assert result["stale"] is False
    later = latest_online_features(db_session, customer.id, second + timedelta(days=2), freshness_days=7)
    assert later["cutoff_at"] == second
    assert later["features"]["usage_events_30d"] == 12


def test_online_feature_retrieval_flags_stale_snapshots_and_validates_freshness(db_session):
    customer, first, _ = _customer_with_snapshots(db_session)
    result = latest_online_features(db_session, customer.id, first + timedelta(days=40), freshness_days=7)
    assert result["stale"] is True
    assert result["fresh"] is False
    with pytest.raises(ValueError, match="freshness_days"):
        latest_online_features(db_session, customer.id, first, freshness_days=-1)


def test_feature_history_and_export_are_sorted_and_have_contract_columns(db_session):
    customer, first, second = _customer_with_snapshots(db_session)
    history = customer_feature_history(db_session, customer.id, limit=10)
    assert [item["cutoff_at"] for item in history] == [second, first]
    from app.services.feature_store import export_feature_snapshots
    csv_text = export_feature_snapshots(db_session, limit=10)
    lines = csv_text.splitlines()
    assert lines[0].startswith("snapshot_id,customer_id,cutoff_at,feature_version,source_fingerprint")
    assert len(lines) == 3


def test_feature_store_api_is_role_protected_and_online_as_of_correct(client, db_session, users):
    customer, first, _ = _customer_with_snapshots(db_session)
    viewer = _login(client, "viewer", "viewer-password-12345")
    registry = client.get("/api/v1/feature-store/registry", headers=viewer)
    assert registry.status_code == 200
    denied = client.get(f"/api/v1/feature-store/customers/{customer.id}/online",
                        params={"as_of": first.isoformat()}, headers=viewer)
    assert denied.status_code == 403

    admin = _login(client)
    online = client.get(f"/api/v1/feature-store/customers/{customer.id}/online",
                        params={"as_of": (first + timedelta(days=2)).isoformat()}, headers=admin)
    assert online.status_code == 200, online.text
    assert online.json()["cutoff_at"].startswith("2026-01-01")
    history = client.get(f"/api/v1/feature-store/customers/{customer.id}/history", headers=admin)
    assert history.status_code == 200 and len(history.json()) == 2
    exported = client.get("/api/v1/feature-store/export", headers=admin)
    assert exported.status_code == 200
    assert "text/csv" in exported.headers["content-type"]
    assert "source_fingerprint" in exported.text


def test_feature_store_materialization_enqueues_existing_worker_job(client, db_session, auth_headers, users):
    from app.models import BackgroundJob

    cutoff = datetime(2026, 2, 1, tzinfo=timezone.utc)
    response = client.post("/api/v1/feature-store/materialize",
                           headers={**auth_headers, "Idempotency-Key": "feature-materialize-001"},
                           json={"cutoff_at": cutoff.isoformat(), "feature_version": "2.1", "customer_ids": [1, 2]})
    assert response.status_code == 202, response.text
    assert response.json()["job_type"] == "build_features"
    assert response.json()["status"] == "queued"
    assert db_session.query(BackgroundJob).filter_by(idempotency_key="feature-materialize-001").count() == 1

    reused = client.post("/api/v1/feature-store/materialize",
                         headers={**auth_headers, "Idempotency-Key": "feature-materialize-001"},
                         json={"cutoff_at": cutoff.isoformat(), "feature_version": "2.1", "customer_ids": [1, 2]})
    assert reused.status_code == 202
    assert reused.json()["id"] == response.json()["id"]
    assert reused.json()["idempotent_reuse"] is True


def test_feature_store_materialization_rejects_invalid_ids_and_versions(client, auth_headers):
    cutoff = datetime(2026, 2, 1, tzinfo=timezone.utc)
    bad_ids = client.post("/api/v1/feature-store/materialize",
                          headers={**auth_headers, "Idempotency-Key": "feature-materialize-bad"},
                          json={"cutoff_at": cutoff.isoformat(), "customer_ids": [1, 1]})
    assert bad_ids.status_code == 422
    bad_version = client.post("/api/v1/feature-store/materialize",
                               headers={**auth_headers, "Idempotency-Key": "feature-materialize-v99"},
                               json={"cutoff_at": cutoff.isoformat(), "feature_version": "99.0"})
    assert bad_version.status_code == 422


def _quality_findings(db_session, count=3):
    run = DataQualityRun(run_id="v17-quality-run", scope="customer", records_scanned=10,
                         finding_count=count, quality_score=90.0, summary_json="{}")
    db_session.add(run)
    db_session.flush()
    rows = [DataQualityFinding(run_id=run.run_id, entity_type="customer", entity_id=index + 1,
                               field_name="email", rule_code="customer_missing_email",
                               severity="warning", status="open", message="Email needs review")
            for index in range(count)]
    db_session.add_all(rows)
    db_session.commit()
    return rows


def test_bulk_quality_review_is_atomic_and_audited(db_session, users):
    rows = _quality_findings(db_session, 3)
    result = bulk_review_findings(db_session, [rows[0].id, rows[1].id], "accepted_risk",
                                  users["analyst"].id, "Reviewed against approved data policy")
    assert result["reviewed_count"] == 2 and result["atomic"] is True
    assert result["decision"] == "accepted_risk"
    assert db_session.get(DataQualityFinding, rows[0].id).status == "accepted_risk"
    assert db_session.get(DataQualityFinding, rows[1].id).status == "accepted_risk"
    assert db_session.get(DataQualityFinding, rows[2].id).status == "open"
    events = db_session.query(AuditEvent).filter_by(action="quality_finding_accepted_risk").all()
    assert len(events) == 2
    assert all('"bulk_review":true' in event.metadata_json for event in events)


def test_bulk_quality_review_rejects_partial_or_unsafe_changes_without_mutation(db_session, users):
    rows = _quality_findings(db_session, 3)
    bulk_review_findings(db_session, [rows[0].id], "false_positive", users["admin"].id)
    with pytest.raises(ValueError, match="already reviewed"):
        bulk_review_findings(db_session, [rows[0].id, rows[1].id], "accepted_risk", users["admin"].id)
    db_session.expire_all()
    assert db_session.get(DataQualityFinding, rows[1].id).status == "open"
    with pytest.raises(ValueError, match="Duplicate"):
        bulk_review_findings(db_session, [rows[1].id, rows[1].id], "accepted_risk", users["admin"].id)
    with pytest.raises(ValueError, match="Bulk decision"):
        bulk_review_findings(db_session, [rows[1].id], "correct", users["admin"].id)
    with pytest.raises(ValueError, match="not found"):
        bulk_review_findings(db_session, [9999], "accepted_risk", users["admin"].id)


def test_bulk_quality_review_endpoint_is_role_protected_and_validates_payload(client, auth_headers):
    viewer = _login(client, "viewer", "viewer-password-12345")
    denied = client.post("/api/v1/quality/findings/bulk-review", headers=viewer,
                         json={"finding_ids": [1], "decision": "accepted_risk"})
    assert denied.status_code == 403
    invalid = client.post("/api/v1/quality/findings/bulk-review", headers=auth_headers,
                          json={"finding_ids": [], "decision": "accepted_risk"})
    assert invalid.status_code == 422
