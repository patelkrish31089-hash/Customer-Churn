from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import sessionmaker

from app.models import BackgroundJob
from app.services.jobs import enqueue_job
from app.worker import claim_next_job, process_one_job


def test_job_api_requires_allowed_role_and_is_idempotent(client, users, auth_headers):
    created = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "quality_audit", "payload": {"scope": "customer"},
        "idempotency_key": "quality-audit-0001", "priority": 200,
    })
    assert created.status_code == 202, created.text
    assert created.json()["status"] == "queued"
    assert created.json()["worker_required"] is True

    repeated = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "quality_audit", "payload": {"scope": "customer"},
        "idempotency_key": "quality-audit-0001", "priority": 100,
    })
    assert repeated.status_code == 202
    assert repeated.json()["id"] == created.json()["id"]
    assert repeated.json()["idempotent_reuse"] is True

    mismatch = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "quality_audit", "payload": {"scope": "all"},
        "idempotency_key": "quality-audit-0001",
    })
    assert mismatch.status_code == 422

    viewer = client.post("/api/v1/auth/login", json={
        "username": "viewer", "password": "viewer-password-12345",
    }).json()
    viewer_headers = {"Authorization": f"Bearer {viewer['access_token']}"}
    forbidden = client.post("/api/v1/jobs", headers=viewer_headers, json={
        "job_type": "quality_audit", "payload": {}, "idempotency_key": "viewer-job-0001",
    })
    assert forbidden.status_code == 403


def test_job_payload_validation_and_unknown_type(client, auth_headers):
    unknown = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "run_arbitrary_code", "payload": {}, "idempotency_key": "unknown-job-0001",
    })
    assert unknown.status_code == 422
    extra = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "quality_audit", "payload": {"scope": "all", "command": "rm -rf /"},
        "idempotency_key": "bad-payload-0001",
    })
    assert extra.status_code == 422
    bad_scope = client.post("/api/v1/jobs", headers=auth_headers, json={
        "job_type": "quality_audit", "payload": {"scope": "secrets"},
        "idempotency_key": "bad-scope-0001",
    })
    assert bad_scope.status_code == 422


def test_worker_executes_queued_quality_audit_and_persists_result(db_session, users):
    job, reused = enqueue_job(db_session, "quality_audit", {"scope": "all"},
                              "worker-quality-0001", users["admin"].id)
    assert not reused
    factory = sessionmaker(bind=db_session.get_bind(), expire_on_commit=False)
    result = process_one_job(factory, worker_id="test-worker", lease_seconds=90)
    assert result is not None
    assert result["job_id"] == job.id
    assert result["status"] == "succeeded"
    db_session.expire_all()
    saved = db_session.get(BackgroundJob, job.id)
    assert saved.status == "succeeded"
    assert saved.progress_pct == 100
    assert saved.attempts == 1
    assert saved.locked_by is None


def test_job_claim_respects_priority_and_recovers_expired_lease(db_session, users):
    lower, _ = enqueue_job(db_session, "quality_audit", {"scope": "all"},
                           "worker-priority-low-0001", users["admin"].id, priority=10)
    higher, _ = enqueue_job(db_session, "quality_audit", {"scope": "customer"},
                            "worker-priority-hi-0001", users["admin"].id, priority=500)
    factory = sessionmaker(bind=db_session.get_bind(), expire_on_commit=False)
    worker_id = "priority-worker"
    claimed = claim_next_job(factory(), worker_id, lease_seconds=90)
    assert claimed == higher.id

    # Simulate a process crash after claiming the job; the expired lease is claimable again.
    db_session.expire_all()
    running = db_session.get(BackgroundJob, higher.id)
    running.locked_until = datetime.now(timezone.utc) - timedelta(seconds=1)
    db_session.commit()
    next_claim = claim_next_job(factory(), "replacement-worker", lease_seconds=90)
    assert next_claim == higher.id
    db_session.expire_all()
    assert db_session.get(BackgroundJob, higher.id).attempts == 2


def test_job_list_is_scoped_and_cancel_retry_are_state_guarded(client, auth_headers, users, db_session):
    from app.services.jobs import enqueue_job

    analyst_job, _ = enqueue_job(db_session, "quality_audit", {}, "analyst-job-00001",
                                 users["analyst"].id)
    admin_job, _ = enqueue_job(db_session, "quality_audit", {}, "admin-job-000001",
                               users["admin"].id)
    analyst_login = client.post("/api/v1/auth/login", json={
        "username": "analyst", "password": "another-strong-password-123",
    }).json()
    analyst_headers = {"Authorization": f"Bearer {analyst_login['access_token']}"}
    visible = client.get("/api/v1/jobs", headers=analyst_headers)
    assert visible.status_code == 200
    assert {x["id"] for x in visible.json()} == {analyst_job.id}
    hidden = client.get(f"/api/v1/jobs/{admin_job.id}", headers=analyst_headers)
    assert hidden.status_code == 404

    cancelled = client.post(f"/api/v1/jobs/{analyst_job.id}/cancel", headers=analyst_headers)
    assert cancelled.status_code == 200
    assert cancelled.json()["status"] == "cancelled"
    invalid_retry = client.post(f"/api/v1/jobs/{analyst_job.id}/retry", headers=analyst_headers)
    assert invalid_retry.status_code == 409

    failed, _ = enqueue_job(db_session, "quality_audit", {}, "failed-job-000001",
                            users["analyst"].id)
    failed.status = "failed"
    failed.attempts = failed.max_attempts
    db_session.commit()
    retried = client.post(f"/api/v1/jobs/{failed.id}/retry", headers=analyst_headers)
    assert retried.status_code == 200
    assert retried.json()["status"] == "queued"
    assert retried.json()["attempts"] == 0


def test_worker_empty_queue_returns_none(db_session):
    factory = sessionmaker(bind=db_session.get_bind(), expire_on_commit=False)
    assert process_one_job(factory, worker_id="empty-worker") is None


def test_queued_import_is_checksum_verified_processed_and_file_cleaned(
    client, db_engine, auth_headers, users, tmp_path
):
    from pathlib import Path
    from sqlalchemy.orm import sessionmaker
    from app.config import settings
    from app.models import Customer, ImportBatch
    from app.worker import process_one_job

    original_upload_dir = settings.upload_dir
    object.__setattr__(settings, "upload_dir", Path(tmp_path))
    try:
        content = (
            b"customer_id,name,email\n"
            b"ASYNC-IMPORT-1,Async Imported Customer,async@example.invalid\n"
        )
        response = client.post(
            "/api/v1/jobs/imports/customers",
            headers={**auth_headers, "Idempotency-Key": "async-import-customer-001"},
            data={"source_name": "async_test"},
            files={"file": ("customers.csv", content, "text/csv")},
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["job_type"] == "import_file"
        assert body["status"] == "queued"
        job_id = body["id"]
        stored_name = body["payload"]["stored_name"]
        queued_path = Path(tmp_path) / "queued" / stored_name
        assert queued_path.read_bytes() == content

        # Repeated upload with same key/content returns the same durable job.
        repeated = client.post(
            "/api/v1/jobs/imports/customers",
            headers={**auth_headers, "Idempotency-Key": "async-import-customer-001"},
            data={"source_name": "async_test"},
            files={"file": ("customers.csv", content, "text/csv")},
        )
        assert repeated.status_code == 202
        assert repeated.json()["id"] == job_id
        assert repeated.json()["idempotent_reuse"] is True

        factory = sessionmaker(bind=db_engine, expire_on_commit=False)
        result = process_one_job(factory, worker_id="async-import-test-worker", lease_seconds=90)
        assert result["job_id"] == job_id
        assert result["status"] == "succeeded"
        with factory() as db:
            customer = db.query(Customer).filter_by(external_id="ASYNC-IMPORT-1").one()
            batch = db.query(ImportBatch).filter_by(source_name="async_test").one()
            assert customer.name == "Async Imported Customer"
            assert batch.records_accepted == 1
            assert batch.records_rejected == 0
        assert not queued_path.exists()
    finally:
        object.__setattr__(settings, "upload_dir", original_upload_dir)


def test_queued_import_rejects_checksum_tampering(client, db_engine, auth_headers, tmp_path):
    from pathlib import Path
    from sqlalchemy.orm import sessionmaker
    from app.config import settings
    from app.models import BackgroundJob
    from app.worker import process_one_job

    original_upload_dir = settings.upload_dir
    object.__setattr__(settings, "upload_dir", Path(tmp_path))
    try:
        content = b"customer_id,name\nASYNC-TAMPER-1,Tamper Test\n"
        response = client.post(
            "/api/v1/jobs/imports/customers",
            headers={**auth_headers, "Idempotency-Key": "async-import-tamper-001"},
            data={"source_name": "tamper_test"},
            files={"file": ("customers.csv", content, "text/csv")},
        )
        assert response.status_code == 202, response.text
        stored_path = Path(tmp_path) / "queued" / response.json()["payload"]["stored_name"]
        stored_path.write_bytes(b"customer_id,name\nTAMPERED,Payload\n")

        factory = sessionmaker(bind=db_engine, expire_on_commit=False)
        outcome = process_one_job(factory, worker_id="tamper-test-worker", lease_seconds=90)
        assert outcome["status"] == "retry_wait"
        with factory() as db:
            job = db.get(BackgroundJob, response.json()["id"])
            assert job.status == "retry_wait"
            assert "checksum" in job.error_message.lower()
        assert stored_path.exists(), "Failed import file must be retained for retry/investigation"
    finally:
        object.__setattr__(settings, "upload_dir", original_upload_dir)
