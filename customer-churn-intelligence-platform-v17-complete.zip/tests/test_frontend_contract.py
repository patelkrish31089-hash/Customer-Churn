from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_analytics_page_uses_the_survival_response_variable():
    source = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    analytics = source.split("async function renderAnalytics()", 1)[1].split("async function renderModels()", 1)[0]
    assert "escapeHtml(sur.method" in analytics
    assert "sur.points.slice" in analytics
    assert "s.method" not in analytics
    assert "s.points" not in analytics


def test_dynamic_form_controls_get_accessible_names():
    source = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    assert "function ensureAccessibleNames" in source
    assert "getAttribute('aria-label')" in source
    assert "getAttribute('aria-labelledby')" in source
    assert "accessibleNameObserver.observe($('appView')" in source


def test_customer_search_has_an_explicit_accessible_name():
    source = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
    assert 'id="customerSearch" aria-label="Search customers by name or identifier"' in source
