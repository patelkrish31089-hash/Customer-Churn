from __future__ import annotations

from datetime import datetime, timedelta, timezone

import httpx
import pytest

from app.models import AuditEvent, Customer, RetentionExperiment, RetentionExperimentAssignment
from app.security import hash_password
from app.services.experiment_design import calculate_binary_experiment_sample_size
from app.services.retention_governance import (record_experiment_outcome, experiment_report,
                                                correct_experiment_outcome)


def _login(client, username="admin", passphrase="a-strong-password-123"):
    response = client.post("/api/v1/auth/login", json={"username": username, "password": passphrase})
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def test_experiment_sample_size_planner_is_reproducible_and_respects_unequal_allocation():
    balanced = calculate_binary_experiment_sample_size(
        baseline_retention=0.75, minimum_detectable_effect=0.05,
        treatment_pct=50, alpha=0.05, power=0.80,
    )
    skewed = calculate_binary_experiment_sample_size(
        baseline_retention=0.75, minimum_detectable_effect=0.05,
        treatment_pct=70, alpha=0.05, power=0.80,
    )
    assert balanced["required_total_n"] > 0
    assert balanced["required_treatment_n"] == balanced["required_control_n"]
    assert skewed["required_treatment_n"] > skewed["required_control_n"]
    assert balanced["method"].startswith("two-sided normal approximation")
    assert "attrition" in balanced["warning"]


@pytest.mark.parametrize("kwargs", [
    {"baseline_retention": 0.0, "minimum_detectable_effect": 0.05},
    {"baseline_retention": 0.98, "minimum_detectable_effect": 0.05},
    {"baseline_retention": 0.75, "minimum_detectable_effect": 0.001},
    {"baseline_retention": 0.75, "minimum_detectable_effect": 0.05, "treatment_pct": 5},
    {"baseline_retention": 0.75, "minimum_detectable_effect": 0.05, "power": 0.6},
])
def test_experiment_sample_size_planner_rejects_invalid_design(kwargs):
    params = {"baseline_retention": 0.75, "minimum_detectable_effect": 0.05}
    params.update(kwargs)
    with pytest.raises(ValueError):
        calculate_binary_experiment_sample_size(**params)


def test_experiment_sample_size_endpoint_is_role_protected_and_validated(client, users):
    viewer = _login(client, "viewer", "viewer-password-12345")
    denied = client.post("/api/v1/retention/experiments/sample-size", headers=viewer,
                         json={"baseline_retention": 0.75, "minimum_detectable_effect": 0.05})
    assert denied.status_code == 403

    admin = _login(client)
    allowed = client.post("/api/v1/retention/experiments/sample-size", headers=admin,
                          json={"baseline_retention": 0.75, "minimum_detectable_effect": 0.05,
                                "treatment_pct": 60, "alpha": 0.05, "power": 0.8})
    assert allowed.status_code == 200, allowed.text
    payload = allowed.json()
    assert payload["required_total_n"] == payload["required_treatment_n"] + payload["required_control_n"]
    invalid = client.post("/api/v1/retention/experiments/sample-size", headers=admin,
                          json={"baseline_retention": 0.98, "minimum_detectable_effect": 0.05})
    assert invalid.status_code == 422


def test_experiment_outcomes_are_immutable_and_audited(db_session, users):
    customer = Customer(external_id="EXP-AUDIT-1", name="Experiment Audit Customer", consent_to_contact=True)
    db_session.add(customer)
    db_session.flush()
    experiment = RetentionExperiment(
        experiment_key="exp-audit-immutable", name="Immutable outcome test",
        hypothesis="Outcome values must be auditable and immutable.",
        allocation_treatment_pct=50, followup_days=7, status="active", created_by=users["admin"].id,
    )
    db_session.add(experiment)
    db_session.flush()
    assignment = RetentionExperimentAssignment(
        experiment_id=experiment.id, customer_id=customer.id, arm="treatment",
        assigned_at=datetime.now(timezone.utc) - timedelta(days=14),
    )
    db_session.add(assignment)
    db_session.commit()

    result = record_experiment_outcome(db_session, assignment.id, "retained", users["admin"].id)
    assert result.outcome == "retained"
    event = db_session.query(AuditEvent).filter_by(
        action="retention_experiment_outcome_recorded", entity_id=str(assignment.id)
    ).one()
    assert event.actor_id == users["admin"].id
    assert '"outcome":"retained"' in event.metadata_json

    with pytest.raises(ValueError, match="immutable"):
        record_experiment_outcome(db_session, assignment.id, "churned", users["admin"].id)
    db_session.refresh(assignment)
    assert assignment.outcome == "retained"


def test_experiment_report_discloses_missing_outcomes_and_does_not_claim_itt(db_session, users):
    experiment = RetentionExperiment(
        experiment_key="exp-report-missing", name="Missing outcome report",
        hypothesis="Missing outcome reporting must be explicit.",
        allocation_treatment_pct=50, followup_days=7, status="active", created_by=users["admin"].id,
    )
    db_session.add(experiment)
    db_session.flush()
    for arm, outcome in (("treatment", "retained"), ("treatment", "no_response"),
                         ("control", "churned"), ("control", None)):
        customer = Customer(external_id=f"EXP-{arm}-{outcome}-{len(db_session.new)}", name="Experiment Customer")
        db_session.add(customer)
        db_session.flush()
        db_session.add(RetentionExperimentAssignment(
            experiment_id=experiment.id, customer_id=customer.id, arm=arm,
            outcome=outcome, outcome_at=(datetime.now(timezone.utc) if outcome else None),
            assigned_at=datetime.now(timezone.utc) - timedelta(days=14),
        ))
    db_session.commit()

    report = experiment_report(db_session, experiment.id)
    assert report["arms"]["treatment"]["matured_assignments"] == 2
    assert report["arms"]["treatment"]["missing_or_nonbinary_outcomes"] == 1
    assert report["arms"]["control"]["missing_or_nonbinary_outcomes"] == 1
    assert report["inference"]["strict_intent_to_treat"] is False
    assert report["inference"]["estimand"] == "complete_case_risk_difference"


def test_salesforce_default_client_rejects_private_dns_resolution(monkeypatch):
    import socket
    from app.integrations.crm import ProviderConfigurationError, execute_provider_action

    monkeypatch.setenv("SALESFORCE_INSTANCE_URL", "https://tenant.my.salesforce.com")
    monkeypatch.setenv("SALESFORCE_ACCESS_TOKEN", "test-token")
    monkeypatch.setenv("SALESFORCE_API_VERSION", "67.0")
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args, **kwargs: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.0.0.8", 443)),
    ])
    with pytest.raises(ProviderConfigurationError, match="non-public address"):
        execute_provider_action("salesforce", remote_customer_id="003001", title="Task",
                                body="Review account", priority="low")


def test_admin_can_correct_experiment_outcome_with_reason_and_full_audit(client, db_session, users):
    customer = Customer(external_id="EXP-CORRECT-1", name="Correction Test Customer")
    db_session.add(customer)
    db_session.flush()
    experiment = RetentionExperiment(
        experiment_key="exp-correction", name="Outcome correction test",
        hypothesis="Admin corrections must preserve a full immutable audit trail.",
        allocation_treatment_pct=50, followup_days=7, status="active", created_by=users["admin"].id,
    )
    db_session.add(experiment)
    db_session.flush()
    assignment = RetentionExperimentAssignment(
        experiment_id=experiment.id, customer_id=customer.id, arm="treatment",
        assigned_at=datetime.now(timezone.utc) - timedelta(days=14),
        outcome="retained", outcome_at=datetime.now(timezone.utc) - timedelta(days=1),
    )
    db_session.add(assignment)
    db_session.commit()

    viewer = _login(client, "viewer", "viewer-password-12345")
    denied = client.post(
        f"/api/v1/retention/experiments/assignments/{assignment.id}/outcome/correction",
        headers=viewer, json={"outcome": "churned", "reason": "Correcting a verified source error"},
    )
    assert denied.status_code == 403

    admin = _login(client)
    missing_reason = client.post(
        f"/api/v1/retention/experiments/assignments/{assignment.id}/outcome/correction",
        headers=admin, json={"outcome": "churned", "reason": "short"},
    )
    assert missing_reason.status_code == 422

    corrected = client.post(
        f"/api/v1/retention/experiments/assignments/{assignment.id}/outcome/correction",
        headers=admin, json={"outcome": "churned", "reason": "Verified against the subscription ledger"},
    )
    assert corrected.status_code == 200, corrected.text
    assert corrected.json()["corrected"] is True
    db_session.refresh(assignment)
    assert assignment.outcome == "churned"
    event = db_session.query(AuditEvent).filter_by(
        action="retention_experiment_outcome_corrected", entity_id=str(assignment.id)
    ).one()
    assert event.actor_id == users["admin"].id
    assert '"previous_outcome":"retained"' in event.metadata_json
    assert '"corrected_outcome":"churned"' in event.metadata_json
    assert '"reason":"Verified against the subscription ledger"' in event.metadata_json


def test_correction_service_rejects_missing_or_same_outcome(db_session, users):
    customer = Customer(external_id="EXP-CORRECT-2", name="Correction Service Customer")
    db_session.add(customer)
    db_session.flush()
    experiment = RetentionExperiment(
        experiment_key="exp-correction-service", name="Outcome correction service",
        hypothesis="Corrections require a previous value and a new value.",
        allocation_treatment_pct=50, followup_days=7, status="closed", created_by=users["admin"].id,
    )
    db_session.add(experiment)
    db_session.flush()
    assignment = RetentionExperimentAssignment(
        experiment_id=experiment.id, customer_id=customer.id, arm="control",
        assigned_at=datetime.now(timezone.utc) - timedelta(days=14), outcome="retained",
        outcome_at=datetime.now(timezone.utc) - timedelta(days=1),
    )
    db_session.add(assignment)
    db_session.commit()
    with pytest.raises(ValueError, match="differ"):
        correct_experiment_outcome(db_session, assignment.id, "retained", users["admin"].id,
                                   "No actual change to the value")
    with pytest.raises(ValueError, match="reason"):
        correct_experiment_outcome(db_session, assignment.id, "churned", users["admin"].id, "bad")
    # Corrections remain possible after experiment closure, but only through the admin-only route.
    result = correct_experiment_outcome(db_session, assignment.id, "churned", users["admin"].id,
                                        "Correction from verified source record")
    assert result.outcome == "churned"
