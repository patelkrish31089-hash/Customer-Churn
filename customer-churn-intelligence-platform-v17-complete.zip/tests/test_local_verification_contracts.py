from __future__ import annotations

import tomllib
from pathlib import Path

from scripts.source_security_smoke import analyze_source, scan_tree

ROOT = Path(__file__).resolve().parents[1]


def test_pytest_asyncio_fixture_scope_is_explicit() -> None:
    config = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    pytest_config = config["tool"]["pytest"].get("ini_options", {})
    assert pytest_config.get("asyncio_mode") == "auto"
    assert pytest_config.get("asyncio_default_fixture_loop_scope") == "function"


def test_ast_security_smoke_detects_dangerous_patterns() -> None:
    source = """
import os
import subprocess
value = eval(user_input)
os.system('echo unsafe')
subprocess.run('echo unsafe', shell=True)
"""
    findings = analyze_source(source, "unsafe_fixture.py")
    assert {item.rule for item in findings} >= {"PYSEC001", "PYSEC002", "PYSEC003"}


def test_ast_security_smoke_detects_unsafe_deserialization_and_tls() -> None:
    source = """
import pickle
import ssl
obj = pickle.loads(payload)
ctx = ssl._create_unverified_context()
"""
    findings = analyze_source(source, "unsafe_fixture.py")
    assert {item.rule for item in findings} >= {"PYSEC004", "PYSEC006"}


def test_first_party_app_has_no_ast_smoke_findings() -> None:
    assert scan_tree(ROOT / "app") == []


def test_clean_install_harness_records_package_inventory_as_a_required_step(tmp_path, monkeypatch):
    import json
    import subprocess
    from scripts import clean_install_acceptance

    root = tmp_path / "project"
    reports = root / "reports"
    reports.mkdir(parents=True)
    monkeypatch.setattr(clean_install_acceptance, "ROOT", root)
    monkeypatch.setattr(clean_install_acceptance, "REPORTS", reports)

    class FakeEnvBuilder:
        def __init__(self, *, with_pip, clear, system_site_packages):
            assert with_pip is True
            assert clear is True
            assert system_site_packages is False

        def create(self, path):
            executable = Path(path) / "bin" / "python"
            executable.parent.mkdir(parents=True)
            executable.write_text("isolated interpreter placeholder", encoding="utf-8")

    monkeypatch.setattr(clean_install_acceptance.venv, "EnvBuilder", FakeEnvBuilder)
    monkeypatch.setattr(clean_install_acceptance.shutil, "which", lambda name: "/usr/bin/node")

    def successful_run(command, **kwargs):
        return subprocess.CompletedProcess(command, 0, stdout="mocked success")

    monkeypatch.setattr(clean_install_acceptance.subprocess, "run", successful_run)
    assert clean_install_acceptance.main() == 0
    report = json.loads((reports / "clean_install_acceptance.json").read_text(encoding="utf-8"))
    step_names = [step["name"] for step in report["steps"]]
    assert report["status"] == "PASS"
    assert report["isolated_prefix_verified"] is True
    assert step_names[-1] == "installed_package_inventory"
    assert all(step["status"] == "PASS" for step in report["steps"])


def _make_hosted_artifacts(
    root: Path, commit_sha: str = "a" * 40, run_attempt: str = "1",
    repository: str = "example-org/churn-platform",
) -> None:
    import json
    from scripts.merge_hosted_evidence import REQUIRED_ARTIFACTS

    for artifact_name, (evidence_name, kind, matrix_version) in REQUIRED_ARTIFACTS.items():
        folder = root / artifact_name
        folder.mkdir(parents=True)
        metadata = {
            "schema_version": 1,
            "workflow": "full-platform-acceptance",
            "repository": repository,
            "run_id": "987654321",
            "run_attempt": run_attempt,
            "commit_sha": commit_sha,
            "job_id": artifact_name,
            "job_status": "success",
            "artifact_name": artifact_name,
            "matrix_python_version": matrix_version,
        }
        (folder / "ci_run_metadata.json").write_text(json.dumps(metadata), encoding="utf-8")

        if kind == "clean_install":
            names = ["isolated_venv_check", "upgrade_pip", "install_all_declared_groups",
                     "pip_check", "python_compile", "strict_pytest", "frontend_javascript_syntax",
                     "installed_package_inventory"]
            payload = {
                "status": "PASS", "isolated_environment": True, "system_site_packages": False,
                "steps": [{"name": name, "status": "PASS"} for name in names],
            }
        elif kind == "quality_security":
            names = ["pip_check", "ruff", "bandit", "pip_audit", "first_party_ast_security"]
            payload = {"status": "PASS", "checks": [{"name": name, "status": "PASS"} for name in names]}
        elif kind == "postgresql":
            required_checks = ["migrated_schema_present", "customer_subscription_invoice_payment_crud",
                               "numeric_18_2_precision", "unique_constraint", "foreign_key_constraint",
                               "transaction_rollback", "committed_data_persistence", "api_readiness",
                               "authentication", "session_revocation", "fixture_cleanup"]
            payload = {"status": "passed", "database_engine": "postgresql", "server_version": "PostgreSQL 16",
                       "checks": {name: True for name in required_checks}}
        elif kind == "docker":
            checks = ["compose_build_and_start", "postgres_and_application_health", "authenticated_api",
                      "application_restart_and_database_persistence", "worker_process_and_durable_job_execution",
                      "job_state_survives_api_restart", "worker_remains_running_after_api_restart",
                      "pg_dump_backup", "restore_into_separate_database", "restored_rows_verified"]
            payload = {"status": "passed", "checks": {name: True for name in checks}}
        elif kind == "mlops":
            payload = {"status": "passed", "mlflow_tracking": "logged_and_read_back",
                       "evidently_report": "generated"}
        elif kind == "airflow":
            payload = {"status": "passed", "task_state": "success", "batch_status": "completed", "failed": 0}
        else:
            raise AssertionError(kind)
        (folder / evidence_name).write_text(json.dumps(payload), encoding="utf-8")
        if kind == "postgresql":
            worker_checks = ["queue_table_migrated", "enqueue_persisted", "worker_claimed_job",
                             "quality_audit_handler_executed", "result_persisted", "lease_released",
                             "at_least_once_semantics_documented"]
            worker_evidence = {"status": "passed", "database_dialect": "postgresql",
                               "checks": {name: True for name in worker_checks}}
            (folder / "worker_queue_runtime_evidence.json").write_text(
                json.dumps(worker_evidence), encoding="utf-8")


def test_hosted_evidence_importer_closes_only_complete_same_run_artifacts(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_hosted_evidence

    artifact_root = tmp_path / "artifacts"
    artifact_root.mkdir()
    project_root = tmp_path / "project"
    (project_root / "reports").mkdir(parents=True)
    _make_hosted_artifacts(artifact_root)
    monkeypatch.setattr(merge_hosted_evidence, "ROOT", project_root)
    monkeypatch.setattr(sys, "argv", [
        "merge_hosted_evidence", "--artifact-root", str(artifact_root), "--run-id", "987654321",
        "--run-attempt", "1", "--commit-sha", "a" * 40,
        "--expected-repository", "example-org/churn-platform", "--reviewed-by", "test-reviewer",
    ])
    assert merge_hosted_evidence.main() == 0
    report = json.loads((project_root / "reports" / "hosted_gate_closure.json").read_text())
    assert report["overall_status"] == "PASS"
    assert report["technical_gates_passed"] == 5
    assert report["run_attempt"] == "1"
    assert report["repository"] == "example-org/churn-platform"


def test_hosted_evidence_importer_rejects_artifacts_from_another_commit(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_hosted_evidence

    artifact_root = tmp_path / "artifacts"
    artifact_root.mkdir()
    project_root = tmp_path / "project"
    (project_root / "reports").mkdir(parents=True)
    _make_hosted_artifacts(artifact_root, commit_sha="b" * 40)
    monkeypatch.setattr(merge_hosted_evidence, "ROOT", project_root)
    monkeypatch.setattr(sys, "argv", [
        "merge_hosted_evidence", "--artifact-root", str(artifact_root), "--run-id", "987654321",
        "--run-attempt", "1", "--commit-sha", "a" * 40,
        "--expected-repository", "example-org/churn-platform", "--reviewed-by", "test-reviewer",
    ])
    assert merge_hosted_evidence.main() == 1
    report = json.loads((project_root / "reports" / "hosted_gate_closure.json").read_text())
    assert report["overall_status"] == "BLOCKED"
    assert report["checks"]["postgresql_runtime"]["status"] == "BLOCKED"


def test_hosted_evidence_importer_rejects_mixed_run_attempts(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_hosted_evidence

    artifact_root = tmp_path / "artifacts"
    artifact_root.mkdir()
    project_root = tmp_path / "project"
    (project_root / "reports").mkdir(parents=True)
    _make_hosted_artifacts(artifact_root)
    changed = artifact_root / "clean-install-python-3.12" / "ci_run_metadata.json"
    metadata = json.loads(changed.read_text(encoding="utf-8"))
    metadata["run_attempt"] = "2"
    changed.write_text(json.dumps(metadata), encoding="utf-8")
    monkeypatch.setattr(merge_hosted_evidence, "ROOT", project_root)
    monkeypatch.setattr(sys, "argv", [
        "merge_hosted_evidence", "--artifact-root", str(artifact_root), "--run-id", "987654321",
        "--run-attempt", "1", "--commit-sha", "a" * 40,
        "--expected-repository", "example-org/churn-platform", "--reviewed-by", "test-reviewer",
    ])
    assert merge_hosted_evidence.main() == 1
    report = json.loads((project_root / "reports" / "hosted_gate_closure.json").read_text())
    assert report["artifact_results"]["clean-install-python-3.12"]["errors"] == ["wrong_run_attempt"]
    assert report["checks"]["clean_virtual_environment_install"]["status"] == "BLOCKED"


def test_verification_ignores_unreviewed_or_wrong_workflow_hosted_report(tmp_path, monkeypatch):
    import json
    from scripts import verify

    reports = tmp_path / "reports"
    reports.mkdir()
    monkeypatch.setattr(verify, "REPORTS", reports)
    invalid = {
        "schema_version": 1, "workflow": "not-the-acceptance-workflow", "run_id": "123",
        "commit_sha": "a" * 40, "reviewed_by": "reviewer", "checks": {"docker_runtime": {"status": "PASS"}},
    }
    (reports / "hosted_gate_closure.json").write_text(json.dumps(invalid), encoding="utf-8")
    assert verify.load_hosted_gate_closure() == {}


def test_verification_accepts_only_reviewed_same_workflow_hosted_closure(tmp_path, monkeypatch):
    import json
    from scripts import verify

    reports = tmp_path / "reports"
    reports.mkdir()
    monkeypatch.setattr(verify, "REPORTS", reports)
    valid = {
        "schema_version": 1, "workflow": "full-platform-acceptance", "run_id": "123456",
        "run_attempt": "1", "repository": "example-org/churn-platform",
        "commit_sha": "c" * 40, "reviewed_by": "release-reviewer",
        "checks": {"docker_runtime": {"status": "PASS"}},
    }
    (reports / "hosted_gate_closure.json").write_text(json.dumps(valid), encoding="utf-8")
    assert verify.load_hosted_gate_closure() == valid


def test_local_evidence_importer_accepts_only_present_complete_technical_gates(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_local_evidence

    root = tmp_path / "project"
    reports = root / "reports"
    reports.mkdir(parents=True)
    # A complete clean-install and quality/security payload can close only those
    # two gates; absent runtime evidence must remain blocked.
    clean_steps = [
        "isolated_venv_check", "upgrade_pip", "install_all_declared_groups",
        "pip_check", "python_compile", "strict_pytest",
        "frontend_javascript_syntax", "installed_package_inventory",
    ]
    (reports / "clean_install_acceptance.json").write_text(json.dumps({
        "status": "PASS", "isolated_environment": True, "system_site_packages": False,
        "steps": [{"name": name, "status": "PASS"} for name in clean_steps],
    }), encoding="utf-8")
    quality_checks = ["pip_check", "ruff", "bandit", "pip_audit", "first_party_ast_security"]
    (reports / "quality_security_acceptance.json").write_text(json.dumps({
        "status": "PASS", "checks": [{"name": name, "status": "PASS"} for name in quality_checks],
    }), encoding="utf-8")

    monkeypatch.setattr(merge_local_evidence, "ROOT", root)
    monkeypatch.setattr(merge_local_evidence, "REPORTS", reports)
    monkeypatch.setattr(sys, "argv", ["merge_local_evidence", "--reviewed-by", "test-reviewer"])
    assert merge_local_evidence.main() == 1
    report = json.loads((reports / "local_gate_closure.json").read_text(encoding="utf-8"))
    assert report["checks"]["clean_virtual_environment_install"]["status"] == "PASS"
    assert report["checks"]["quality_and_security_toolchain"]["status"] == "PASS"
    assert report["checks"]["postgresql_runtime"]["status"] == "BLOCKED"
    assert report["checks"]["mlops_runtime"]["status"] == "BLOCKED"


def test_local_gate_closure_is_invalidated_when_source_tree_changes(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_local_evidence, verify

    root = tmp_path / "project"
    reports = root / "reports"
    reports.mkdir(parents=True)
    source = root / "app.py"
    source.write_text("VALUE = 1\n", encoding="utf-8")
    clean_steps = [
        "isolated_venv_check", "upgrade_pip", "install_all_declared_groups",
        "pip_check", "python_compile", "strict_pytest",
        "frontend_javascript_syntax", "installed_package_inventory",
    ]
    (reports / "clean_install_acceptance.json").write_text(json.dumps({
        "status": "PASS", "isolated_environment": True, "system_site_packages": False,
        "steps": [{"name": name, "status": "PASS"} for name in clean_steps],
    }), encoding="utf-8")
    monkeypatch.setattr(merge_local_evidence, "ROOT", root)
    monkeypatch.setattr(merge_local_evidence, "REPORTS", reports)
    monkeypatch.setattr(sys, "argv", ["merge_local_evidence", "--reviewed-by", "release-reviewer"])
    assert merge_local_evidence.main() == 1

    monkeypatch.setattr(verify, "ROOT", root)
    monkeypatch.setattr(verify, "REPORTS", reports)
    closure = json.loads((reports / "local_gate_closure.json").read_text(encoding="utf-8"))
    assert verify.load_local_gate_closure() == closure

    # Altering an evidence file invalidates the review even when its PASS status remains.
    evidence_path = reports / "clean_install_acceptance.json"
    original_evidence = evidence_path.read_text(encoding="utf-8")
    tampered = json.loads(original_evidence)
    tampered["review_note"] = "tampered after review"
    evidence_path.write_text(json.dumps(tampered), encoding="utf-8")
    assert verify.load_local_gate_closure() == {}

    # Restoring the exact reviewed evidence restores validity; changing application source does not.
    evidence_path.write_text(original_evidence, encoding="utf-8")
    assert verify.load_local_gate_closure() == closure
    source.write_text("VALUE = 2\n", encoding="utf-8")
    assert verify.load_local_gate_closure() == {}


def test_windows_acceptance_runner_documents_optional_real_runtime_checks():
    runner = (ROOT / "scripts" / "run_acceptance.ps1").read_text(encoding="utf-8")
    for marker in (
        "ValidateSet('3.11', '3.12')", "clean_install_acceptance.py",
        "quality_security_acceptance.py", "WithContainers", "WithMLOps",
        "WithBrowserNative", "merge_local_evidence.py", "verify.py",
        "docker_runtime_smoke.sh", "postgres_runtime_smoke.py",
    ):
        assert marker in runner
    assert "Remove-Item Env:\\POSTGRES_PASSWORD" in runner


def test_local_evidence_importer_closes_all_technical_gates_with_complete_evidence(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_local_evidence

    root = tmp_path / "project"
    reports = root / "reports"
    reports.mkdir(parents=True)

    clean_steps = [
        "isolated_venv_check", "upgrade_pip", "install_all_declared_groups",
        "pip_check", "python_compile", "strict_pytest",
        "frontend_javascript_syntax", "installed_package_inventory",
    ]
    (reports / "clean_install_acceptance.json").write_text(json.dumps({
        "status": "PASS", "isolated_environment": True, "system_site_packages": False,
        "steps": [{"name": name, "status": "PASS"} for name in clean_steps],
    }), encoding="utf-8")
    quality_checks = ["pip_check", "ruff", "bandit", "pip_audit", "first_party_ast_security"]
    (reports / "quality_security_acceptance.json").write_text(json.dumps({
        "status": "PASS", "checks": [{"name": name, "status": "PASS"} for name in quality_checks],
    }), encoding="utf-8")
    pg_checks = [
        "migrated_schema_present", "customer_subscription_invoice_payment_crud", "numeric_18_2_precision",
        "unique_constraint", "foreign_key_constraint", "transaction_rollback", "committed_data_persistence",
        "api_readiness", "authentication", "session_revocation", "fixture_cleanup",
    ]
    (reports / "postgresql_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "database_engine": "postgresql", "server_version": "PostgreSQL 16",
        "checks": {name: True for name in pg_checks},
    }), encoding="utf-8")
    worker_checks = ["queue_table_migrated", "enqueue_persisted", "worker_claimed_job",
                     "quality_audit_handler_executed", "result_persisted", "lease_released",
                     "at_least_once_semantics_documented"]
    (reports / "worker_queue_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "database_dialect": "postgresql",
        "checks": {name: True for name in worker_checks},
    }), encoding="utf-8")
    docker_checks = [
        "compose_build_and_start", "postgres_and_application_health", "authenticated_api",
        "application_restart_and_database_persistence", "worker_process_and_durable_job_execution",
        "job_state_survives_api_restart", "worker_remains_running_after_api_restart",
        "pg_dump_backup", "restore_into_separate_database", "restored_rows_verified",
    ]
    (reports / "docker_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "checks": {name: True for name in docker_checks},
    }), encoding="utf-8")
    (reports / "mlops_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "mlflow_tracking": "logged_and_read_back", "evidently_report": "generated",
    }), encoding="utf-8")
    (reports / "airflow_dag_evidence.json").write_text(json.dumps({
        "status": "passed", "task_state": "success", "batch_status": "completed", "failed": 0,
    }), encoding="utf-8")

    monkeypatch.setattr(merge_local_evidence, "ROOT", root)
    monkeypatch.setattr(merge_local_evidence, "REPORTS", reports)
    monkeypatch.setattr(sys, "argv", ["merge_local_evidence", "--reviewed-by", "test-reviewer"])
    assert merge_local_evidence.main() == 0
    report = json.loads((reports / "local_gate_closure.json").read_text(encoding="utf-8"))
    assert report["overall_status"] == "PASS"
    assert report["technical_gates_passed"] == 5
    assert all(item["status"] == "PASS" for item in report["checks"].values())


def test_final_report_uses_reviewed_local_technical_evidence_but_keeps_external_gates_blocked(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import verify, environment_gate_inventory, merge_local_evidence

    root = tmp_path / "project"
    reports = root / "reports"
    reports.mkdir(parents=True)
    (root / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
    for stage in ("core", "runtime", "migrations", "product", "synthetic", "browser"):
        (reports / f"verification_{stage}.json").write_text(json.dumps({"checks": []}), encoding="utf-8")

    clean_steps = [
        "isolated_venv_check", "upgrade_pip", "install_all_declared_groups",
        "pip_check", "python_compile", "strict_pytest",
        "frontend_javascript_syntax", "installed_package_inventory",
    ]
    (reports / "clean_install_acceptance.json").write_text(json.dumps({
        "status": "PASS", "isolated_environment": True, "system_site_packages": False,
        "steps": [{"name": name, "status": "PASS"} for name in clean_steps],
    }), encoding="utf-8")
    quality_checks = ["pip_check", "ruff", "bandit", "pip_audit", "first_party_ast_security"]
    (reports / "quality_security_acceptance.json").write_text(json.dumps({
        "status": "PASS", "checks": [{"name": name, "status": "PASS"} for name in quality_checks],
    }), encoding="utf-8")
    pg_checks = [
        "migrated_schema_present", "customer_subscription_invoice_payment_crud", "numeric_18_2_precision",
        "unique_constraint", "foreign_key_constraint", "transaction_rollback", "committed_data_persistence",
        "api_readiness", "authentication", "session_revocation", "fixture_cleanup",
    ]
    (reports / "postgresql_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "database_engine": "postgresql", "server_version": "PostgreSQL 16",
        "checks": {name: True for name in pg_checks},
    }), encoding="utf-8")
    worker_checks = ["queue_table_migrated", "enqueue_persisted", "worker_claimed_job",
                     "quality_audit_handler_executed", "result_persisted", "lease_released",
                     "at_least_once_semantics_documented"]
    (reports / "worker_queue_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "database_dialect": "postgresql",
        "checks": {name: True for name in worker_checks},
    }), encoding="utf-8")
    docker_checks = [
        "compose_build_and_start", "postgres_and_application_health", "authenticated_api",
        "application_restart_and_database_persistence", "worker_process_and_durable_job_execution",
        "job_state_survives_api_restart", "worker_remains_running_after_api_restart",
        "pg_dump_backup", "restore_into_separate_database", "restored_rows_verified",
    ]
    (reports / "docker_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "checks": {name: True for name in docker_checks},
    }), encoding="utf-8")
    (reports / "mlops_runtime_evidence.json").write_text(json.dumps({
        "status": "passed", "mlflow_tracking": "logged_and_read_back", "evidently_report": "generated",
    }), encoding="utf-8")
    (reports / "airflow_dag_evidence.json").write_text(json.dumps({
        "status": "passed", "task_state": "success", "batch_status": "completed", "failed": 0,
    }), encoding="utf-8")

    monkeypatch.setattr(merge_local_evidence, "ROOT", root)
    monkeypatch.setattr(merge_local_evidence, "REPORTS", reports)
    monkeypatch.setattr(sys, "argv", ["merge_local_evidence", "--reviewed-by", "test-reviewer"])
    assert merge_local_evidence.main() == 0
    monkeypatch.setattr(verify, "ROOT", root)
    monkeypatch.setattr(verify, "REPORTS", reports)
    monkeypatch.setattr(verify, "project_tool_inventory", lambda: {})
    monkeypatch.setattr(environment_gate_inventory, "collect", lambda: {"scope": "test fixture"})

    assert verify.stage_report() == 0
    result = json.loads((reports / "verification.json").read_text(encoding="utf-8"))
    by_name = {item["name"]: item for item in result["checks"]}
    names = [
        "clean_virtual_environment_install", "quality_and_security_toolchain", "postgresql_runtime",
        "docker_runtime", "mlops_runtime",
    ]
    assert all(by_name[name]["status"] == "PASS" and by_name[name]["evidence_source"] == "reviewed_local"
               for name in names)
    external = [
        "live_crm_provider_sandbox", "hosted_staging_deployment", "real_company_model_validation",
        "independent_penetration_test", "business_churn_policy_signoff",
    ]
    assert all(by_name[name]["status"] == "BLOCKED" for name in external)
    assert result["summary"]["passed"] == 5
    assert result["summary"]["blocked"] == 5



def test_hosted_evidence_automatic_aggregate_is_not_human_gate_closure(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_hosted_evidence, verify

    artifact_root = tmp_path / "artifacts"
    artifact_root.mkdir()
    project_root = tmp_path / "project"
    reports = project_root / "reports"
    reports.mkdir(parents=True)
    _make_hosted_artifacts(artifact_root)
    # An automatic, unreviewed run must remove any stale previous reviewer closure.
    (reports / "hosted_gate_closure.json").write_text(json.dumps({"reviewed_by": "old-reviewer"}))
    monkeypatch.setattr(merge_hosted_evidence, "ROOT", project_root)
    monkeypatch.setattr(verify, "REPORTS", reports)
    monkeypatch.setattr(sys, "argv", [
        "merge_hosted_evidence", "--artifact-root", str(artifact_root), "--run-id", "987654321",
        "--run-attempt", "1", "--commit-sha", "a" * 40,
        "--expected-repository", "example-org/churn-platform", "--recorded-by", "workflow-actor",
    ])
    assert merge_hosted_evidence.main() == 0
    aggregate = json.loads((reports / "hosted_evidence_aggregate.json").read_text())
    assert aggregate["overall_status"] == "PASS"
    assert aggregate["review_status"] == "not_reviewed"
    assert aggregate["reviewed_by"] is None
    assert not (reports / "hosted_gate_closure.json").exists()
    assert verify.load_hosted_gate_closure() == {}



def test_hosted_evidence_importer_rejects_repository_mismatch(tmp_path, monkeypatch):
    import json
    import sys
    from scripts import merge_hosted_evidence

    artifact_root = tmp_path / "artifacts"
    artifact_root.mkdir()
    project_root = tmp_path / "project"
    (project_root / "reports").mkdir(parents=True)
    _make_hosted_artifacts(artifact_root)
    changed = artifact_root / "docker-compose-runtime-evidence" / "ci_run_metadata.json"
    metadata = json.loads(changed.read_text(encoding="utf-8"))
    metadata["repository"] = "attacker/other-repository"
    changed.write_text(json.dumps(metadata), encoding="utf-8")
    monkeypatch.setattr(merge_hosted_evidence, "ROOT", project_root)
    monkeypatch.setattr(sys, "argv", [
        "merge_hosted_evidence", "--artifact-root", str(artifact_root), "--run-id", "987654321",
        "--run-attempt", "1", "--commit-sha", "a" * 40,
        "--expected-repository", "example-org/churn-platform", "--reviewed-by", "reviewer",
    ])
    assert merge_hosted_evidence.main() == 1
    report = json.loads((project_root / "reports" / "hosted_gate_closure.json").read_text())
    assert report["artifact_results"]["docker-compose-runtime-evidence"]["errors"] == ["repository_mismatch"]
    assert report["checks"]["docker_runtime"]["status"] == "BLOCKED"
