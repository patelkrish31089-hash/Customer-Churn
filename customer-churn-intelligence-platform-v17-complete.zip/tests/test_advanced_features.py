from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from decimal import Decimal

import httpx
import pytest
from sqlalchemy.orm import Session

from app.demo import seed_demo
from app.models import (CRMAction, Customer, DataQualityFinding, DataSourceConnection, ExternalIdentity,
                        Invoice, Payment, RetentionRecommendation, Subscription, SupportTicket, UsageEvent, User)
from app.security import hash_password
from app.services.analytics import eda_report, cohort_retention, survival_curve
from app.services.data import import_tabular_file
from app.services.ml import (train_models, approve_release, score_customer_batch,
                             retry_failed_prediction_batch, global_shap_summary, customer_360)
from app.services.quality import list_rules, run_quality_audit, review_finding, update_rule
from app.services.retention import execute_live_crm_action
from app.integrations.sources import sync_rest_source
from app.integrations.crm import execute_provider_action

NOW = datetime(2026, 11, 5, tzinfo=timezone.utc)


def make_customer(db: Session, key="C-ADV", email=None, consent=True):
    row = Customer(external_id=key, name=f"Customer {key}", email=email, segment="SMB", country="IN",
                   acquisition_date=NOW-timedelta(days=210), consent_to_contact=consent, source_name="test_source")
    db.add(row); db.flush()
    return row


def test_json_tabular_import_uses_canonical_validator(db_session):
    payload = [{"customer_id": "J-1", "name": "JSON Customer", "email": "j@example.invalid"},
               {"customer_id": "", "name": "Rejected"}]
    result = import_tabular_file(db_session, "customers", "customers.json",
                                 json.dumps({"records": payload}).encode(), "json_source")
    assert result["records_received"] == 2
    assert result["records_accepted"] == 1 and result["records_rejected"] == 1


def test_xlsx_tabular_import_uses_canonical_validator(db_session):
    openpyxl = pytest.importorskip("openpyxl")
    from io import BytesIO
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["customer_id", "name", "email"])
    sheet.append(["X-1", "Excel Customer", "x@example.invalid"])
    buffer = BytesIO(); workbook.save(buffer)
    result = import_tabular_file(db_session, "customers", "customers.xlsx", buffer.getvalue(), "excel_source")
    assert result["records_accepted"] == 1
    assert db_session.query(Customer).filter_by(external_id="X-1").one().source_name == "excel_source"


def test_rest_source_allowlist_and_json_sync(db_session, monkeypatch):
    monkeypatch.setenv("DATA_SOURCE_ALLOWED_HOSTS", "api.example.invalid")
    c = DataSourceConnection(connection_key="customer_api", name="Customer API", dataset_type="customers",
        endpoint_url="https://api.example.invalid/customers", record_path="data.records",
        field_mapping_json=json.dumps({"id": "customer_id"}), enabled=True)
    db_session.add(c); db_session.commit()
    def handler(request):
        assert request.url.host == "api.example.invalid"
        return httpx.Response(200, json={"data": {"records": [{"id": "REST-1", "name": "REST Customer"}]}})
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        result = sync_rest_source(db_session, c, client)
    assert result["status"] == "completed"
    assert db_session.query(Customer).filter_by(external_id="REST-1").one()


def test_rest_source_rejects_unallowlisted_host(monkeypatch):
    from app.integrations.sources import validate_source_url
    monkeypatch.setenv("DATA_SOURCE_ALLOWED_HOSTS", "api.safe.invalid")
    with pytest.raises(ValueError, match="allowlist"):
        validate_source_url("https://evil.invalid/data")
    with pytest.raises(ValueError, match="HTTPS"):
        validate_source_url("http://api.safe.invalid/data")


def test_rest_source_rejects_hostname_resolving_to_private_ip(monkeypatch):
    import socket
    from app.integrations.sources import validate_source_url
    monkeypatch.setenv("DATA_SOURCE_ALLOWED_HOSTS", "api.partner.example")
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args, **kwargs: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("10.10.0.12", 443))
    ])
    with pytest.raises(ValueError, match="private or non-routable"):
        validate_source_url("https://api.partner.example/customers", resolve_dns=True)


def test_rest_source_enforces_streamed_response_size_limit(db_session, monkeypatch):
    import app.integrations.sources as source_module
    monkeypatch.setenv("DATA_SOURCE_ALLOWED_HOSTS", "api.example.invalid")
    monkeypatch.setattr(source_module, "MAX_REST_RESPONSE_BYTES", 48)
    connection = DataSourceConnection(connection_key="oversized_api", name="Oversized API",
        dataset_type="customers", endpoint_url="https://api.example.invalid/customers",
        record_path=None, field_mapping_json="{}", enabled=True)
    db_session.add(connection); db_session.commit()
    with httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(200, content=b"x" * 128)
    )) as client:
        with pytest.raises(ValueError, match="25 MB import limit"):
            sync_rest_source(db_session, connection, client)


def test_quality_scorecard_rule_configuration_and_audited_correction(db_session):
    reviewer = User(username="quality-reviewer", password_hash=hash_password("quality-reviewer-password"), role="analyst")
    db_session.add(reviewer); db_session.flush()
    c = make_customer(db_session, "Q-1", email=None)
    before = run_quality_audit(db_session, "customer")
    finding = db_session.query(DataQualityFinding).filter_by(rule_code="customer_missing_email").one()
    assert before["records_scanned"] == 1 and before["finding_count"] == 1
    assert 0 <= before["quality_score"] <= 100
    corrected = review_finding(db_session, finding.id, "correct", reviewer_id=reviewer.id,
                               corrected_value="corrected@example.invalid", note="Verified from approved data source")
    assert corrected.status == "corrected"
    assert c.email == "corrected@example.invalid"
    assert db_session.query(DataQualityFinding).filter_by(id=finding.id).one().reviewer_id == reviewer.id


def test_quality_rule_configuration_persists(db_session):
    actor = User(username="rule-admin", password_hash=hash_password("rule-admin-password"), role="admin")
    db_session.add(actor); db_session.flush()
    code = list_rules(db_session)[0]["rule_code"]
    updated = update_rule(db_session, code, False, "critical", {}, actor_id=actor.id)
    assert updated["enabled"] is False and updated["severity"] == "critical"
    assert next(x for x in list_rules(db_session) if x["rule_code"] == code)["enabled"] is False


def test_customer_360_contains_lifecycle_and_source_lineage(db_session):
    c = make_customer(db_session, "360-1", "360@example.invalid")
    sub = Subscription(external_id="SUB-360", customer_id=c.id, plan="Growth", status="active",
                       start_date=NOW-timedelta(days=60), mrr=Decimal("49.00"), currency="USD", source_name="billing_api")
    db_session.add(sub); db_session.flush()
    inv = Invoice(external_id="INV-360", customer_id=c.id, subscription_id=sub.id,
                  invoice_date=NOW-timedelta(days=30), amount=Decimal("49.00"), currency="USD", status="open", source_name="billing_api")
    db_session.add(inv); db_session.flush()
    db_session.add_all([
        Payment(external_id="PAY-360", customer_id=c.id, invoice_id=inv.id, payment_date=NOW-timedelta(days=29),
                amount=Decimal("49.00"), currency="USD", status="succeeded", source_name="billing_api"),
        UsageEvent(external_id="EVT-360", customer_id=c.id, subscription_id=sub.id, event_time=NOW-timedelta(days=2),
                   event_type="login", quantity=2, source_name="product_telemetry"),
        SupportTicket(external_id="TKT-360", customer_id=c.id, created_at=NOW-timedelta(days=1),
                      status="open", priority="high", category="billing", source_name="support_platform"),
    ])
    db_session.commit()
    profile = customer_360(db_session, c.id)
    types = {x["type"] for x in profile["timeline"]}
    assert {"subscription_started", "invoice", "payment", "usage", "support_ticket"}.issubset(types)
    assert profile["financials_by_currency"]["USD"]["open_invoice_count"] == 1
    assert profile["data_provenance"]["usage_sources"] == ["product_telemetry"]


def test_eda_and_cohort_outputs_are_explicit(db_session):
    c = make_customer(db_session, "EDA-1")
    db_session.add(Subscription(external_id="EDA-S1", customer_id=c.id, plan="Basic", status="active",
                                start_date=NOW-timedelta(days=90), mrr=Decimal("10"), currency="USD"))
    db_session.add(UsageEvent(external_id="EDA-U1", customer_id=c.id, event_time=NOW-timedelta(days=1), event_type="login"))
    db_session.commit()
    assert "correlation_matrix" in eda_report(db_session)
    assert "heatmaps" in cohort_retention(db_session)
    assert "ci_lower" in survival_curve(db_session)["points"][0]


def test_crm_provider_adapters_use_documented_http_contracts(monkeypatch):
    calls = []
    def handler(request):
        calls.append(request)
        return httpx.Response(201, json={"id": "REMOTE-123"})
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        monkeypatch.setenv("SALESFORCE_INSTANCE_URL", "https://tenant.my.salesforce.com")
        monkeypatch.setenv("SALESFORCE_ACCESS_TOKEN", "test-salesforce-token")
        monkeypatch.setenv("SALESFORCE_API_VERSION", "67.0")
        sf = execute_provider_action("salesforce", remote_customer_id="003000000000001", title="Follow up", body="Review account", priority="high", client=client)
        assert calls[-1].url.path.endswith("/services/data/v67.0/sobjects/Task/")
        assert calls[-1].headers["Authorization"] == "Bearer test-salesforce-token"
        assert sf["external_id"] == "REMOTE-123"

        monkeypatch.setenv("HUBSPOT_PRIVATE_APP_TOKEN", "test-hubspot-token")
        monkeypatch.setenv("HUBSPOT_CONTACT_ASSOCIATION_TYPE_ID", "1")
        hs = execute_provider_action("hubspot", remote_customer_id="12345", title="Follow up", body="Review account", priority="medium", client=client)
        assert calls[-1].url.path == "/crm/objects/2026-09/tasks"
        assert calls[-1].headers["Authorization"] == "Bearer test-hubspot-token"
        assert hs["external_id"] == "REMOTE-123"

        monkeypatch.setenv("INTERCOM_ACCESS_TOKEN", "test-intercom-token")
        ic = execute_provider_action("intercom", remote_customer_id="contact-1", title="Follow up", body="Review account", priority="low", client=client)
        assert calls[-1].url.path == "/contacts/contact-1/notes"
        assert calls[-1].headers["Intercom-Version"] == "2.17"
        assert ic["external_id"] == "REMOTE-123"

        execute_provider_action("intercom", remote_customer_id="contact/with?path", title="Follow up",
                                body="Review account", priority="low", client=client)
        assert calls[-1].url.raw_path == b"/contacts/contact%2Fwith%3Fpath/notes"


def test_crm_rejects_untrusted_salesforce_host_and_redirect(monkeypatch):
    from app.integrations.crm import ProviderConfigurationError, ProviderRequestError
    monkeypatch.setenv("SALESFORCE_INSTANCE_URL", "https://attacker.example")
    monkeypatch.setenv("SALESFORCE_ACCESS_TOKEN", "secret-test-token")
    monkeypatch.setenv("SALESFORCE_API_VERSION", "67.0")
    with httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(201, json={"id": "x"})
    )) as client:
        with pytest.raises(ProviderConfigurationError, match="Salesforce instance host"):
            execute_provider_action("salesforce", remote_customer_id="003001", title="Task", body="Review",
                                    priority="low", client=client)

    from app.integrations.crm import _send
    with httpx.Client(transport=httpx.MockTransport(
        lambda request: httpx.Response(302, headers={"Location": "https://attacker.example/collect"})
    )) as client:
        with pytest.raises(ProviderRequestError, match="redirect_refused"):
            _send(client, "salesforce", "https://tenant.my.salesforce.com/task", {}, {})


def test_live_crm_execution_requires_review_consent_identity_and_is_idempotent(db_session, monkeypatch):
    c = make_customer(db_session, "CRM-1", "crm@example.invalid", consent=True)
    rec = RetentionRecommendation(customer_id=c.id, category="relationship_review", title="Follow up",
                                  rationale="Review account health", priority="medium", status="approved")
    db_session.add(rec); db_session.flush()
    db_session.add(ExternalIdentity(provider="salesforce", entity_type="customer", local_entity_id=c.id, remote_entity_id="003001"))
    db_session.commit()
    monkeypatch.setenv("SALESFORCE_INSTANCE_URL", "https://tenant.my.salesforce.com")
    monkeypatch.setenv("SALESFORCE_ACCESS_TOKEN", "test-token")
    monkeypatch.setenv("SALESFORCE_API_VERSION", "67.0")
    def handler(request): return httpx.Response(201, json={"id": "TASK-99"})
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        sent = execute_live_crm_action(db_session, rec.id, "salesforce", "crm-idempotency-001", client)
        again = execute_live_crm_action(db_session, rec.id, "salesforce", "crm-idempotency-001", client)
    assert sent["status"] == "sent" and sent["external_reference"] == "TASK-99"
    assert again["idempotent_reuse"] is True
    assert db_session.query(CRMAction).count() == 1


def test_mlflow_and_optional_integration_capabilities_fail_truthfully(monkeypatch):
    from app.integrations.mlflow_tracking import track_training_run
    monkeypatch.delenv("MLFLOW_TRACKING_URI", raising=False)
    result = track_training_run("run-1", "logistic_regression", {}, {}, None, dataset_fingerprint="abc")
    assert result["status"] in {"not_configured", "not_installed"}


def test_advanced_model_calibration_batch_retry_and_global_shap(db_session, monkeypatch, tmp_path):
    from dataclasses import replace
    import app.services.ml as ml_module
    import app.services.data as data_module
    from app.services.ml import ModelRelease

    monkeypatch.setattr(ml_module, "settings", replace(ml_module.settings, artifact_dir=tmp_path))
    seeded = seed_demo(db_session, customers=120, seed=117)
    assert seeded["not_real_company_data"]
    trained = train_models(db_session, feature_version="2.1", horizon_days=30)
    assert trained["metrics"]["candidate_comparison"]
    assert "test" in trained["metrics"] and "test_confidence_intervals" in trained["metrics"]
    assert "probability_calibration" in trained["metrics"]
    admin = User(username="adv-admin", password_hash=hash_password("advanced-admin-password-123"), role="admin")
    db_session.add(admin); db_session.commit()
    release = approve_release(db_session, trained["release_id"], admin.id)

    ids = [x.id for x in db_session.query(Customer).order_by(Customer.id).all()]
    cutoff = datetime.now(timezone.utc) + timedelta(minutes=1)
    original = data_module.build_features
    failed_id = ids[-1]
    def build_except_one(db, at, version="2.0", customer_ids=None):
        return original(db, at, version, [x for x in (customer_ids or []) if x != failed_id])
    monkeypatch.setattr(data_module, "build_features", build_except_one)
    partial = score_customer_batch(db_session, cutoff, "batch-advanced-001", ids, release.release_id)
    assert partial["status"] == "partial" and partial["failed"] == 1
    monkeypatch.setattr(data_module, "build_features", original)
    retried = retry_failed_prediction_batch(db_session, partial["batch_id"], "batch-advanced-retry-001")
    assert retried["status"] == "completed" and retried["succeeded"] == 1
    repeated = score_customer_batch(db_session, cutoff, "batch-advanced-001", ids, release.release_id)
    assert repeated["idempotent_reuse"] is True
    shap = global_shap_summary(db_session, release.release_id, 100)
    assert "available" in shap and shap["sample_count"] >= 10
    import importlib.util
    if importlib.util.find_spec("shap"):
        assert shap["available"] is True, shap


def test_airflow_dag_is_syntactically_valid():
    import ast
    from pathlib import Path
    dag = Path(__file__).resolve().parents[1] / "dags" / "customer_churn_daily_scoring.py"
    ast.parse(dag.read_text(encoding="utf-8"))


def test_api_supports_json_upload_and_quality_review(client, auth_headers, db_session):
    from app.config import settings
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    payload = json.dumps([{"customer_id": "API-JSON-1", "name": "API JSON Customer",
                           "email": "api-json@example.invalid"}]).encode()
    response = client.post("/api/v1/imports/customers", headers=auth_headers,
                           data={"source_name": "api_json_test"},
                           files={"file": ("customers.json", payload, "application/json")})
    assert response.status_code == 201, response.text
    assert response.json()["records_accepted"] == 1
    stored = settings.upload_dir / response.json()["stored_file"]
    assert stored.exists()
    stored.unlink(missing_ok=True)

    missing = make_customer(db_session, "API-QUALITY-1", email=None)
    db_session.commit()
    audited = client.post("/api/v1/quality/audit?scope=customer", headers=auth_headers)
    assert audited.status_code == 201, audited.text
    findings = client.get("/api/v1/quality/findings?status=open", headers=auth_headers)
    assert findings.status_code == 200
    finding = next(x for x in findings.json() if x["entity_id"] == missing.id and x["rule_code"] == "customer_missing_email")
    reviewed = client.post(f"/api/v1/quality/findings/{finding['id']}/review", headers=auth_headers,
                           json={"decision": "correct", "corrected_value": "verified@example.invalid",
                                 "note": "Verified in an authorized source"})
    assert reviewed.status_code == 200, reviewed.text
    db_session.refresh(missing)
    assert missing.email == "verified@example.invalid"


def test_api_data_source_registry_and_retention_experiment_lifecycle(client, auth_headers, users, db_session, monkeypatch):
    monkeypatch.setenv("DATA_SOURCE_ALLOWED_HOSTS", "api.partner.example")
    configured = client.post("/api/v1/sources", headers=auth_headers, json={
        "connection_key": "api-partner", "name": "Partner API", "dataset_type": "customers",
        "endpoint_url": "https://api.partner.example/v1/customers", "record_path": "data.records",
        "field_mapping": {"id": "customer_id"}
    })
    assert configured.status_code == 201, configured.text
    source_list = client.get("/api/v1/sources", headers=auth_headers)
    assert source_list.status_code == 200 and source_list.json()[0]["connection_key"] == "api-partner"

    customer = make_customer(db_session, "API-EXP-1", email="experiment@example.invalid")
    db_session.commit()
    created = client.post("/api/v1/retention/experiments", headers=auth_headers, json={
        "name": "API retention experiment", "hypothesis": "A tailored follow-up may improve observed retention.",
        "treatment_pct": 50, "followup_days": 30
    })
    assert created.status_code == 201, created.text
    experiment_id = created.json()["id"]
    started = client.post(f"/api/v1/retention/experiments/{experiment_id}/start", headers=auth_headers)
    assert started.status_code == 200 and started.json()["status"] == "active"
    enrolled = client.post(f"/api/v1/retention/experiments/{experiment_id}/enroll", headers=auth_headers,
                           json={"customer_ids": [customer.id]})
    assert enrolled.status_code == 200 and enrolled.json()["enrolled"] == 1
    report = client.get(f"/api/v1/retention/experiments/{experiment_id}/report", headers=auth_headers)
    assert report.status_code == 200
    assert report.json()["arms"]["treatment"]["assigned"] + report.json()["arms"]["control"]["assigned"] == 1
    listing = client.get("/api/v1/retention/experiments", headers=auth_headers)
    assert any(x["id"] == experiment_id for x in listing.json())


def test_crm_routes_are_unambiguous_and_integration_capabilities_are_reported(client, auth_headers):
    paths = {route.path for route in client.app.routes}
    assert "/api/v1/crm/sandbox/{recommendation_id}/execute" in paths
    assert "/api/v1/crm/providers/{provider}/recommendations/{recommendation_id}/execute" in paths
    integrations = client.get("/api/v1/ops/integrations", headers=auth_headers)
    assert integrations.status_code == 200
    payload = integrations.json()
    assert set(payload["crm_providers"]) == {"salesforce", "hubspot", "intercom"}
    assert "mlflow" in payload["platform"] and "airflow" in payload["platform"]


def test_feature_v21_contains_rfm_and_never_averages_mixed_currencies(db_session):
    from app.services.data import build_features
    from app.utils import json_loads
    c = make_customer(db_session, "RFM-21", "rfm@example.invalid")
    db_session.add_all([
        Subscription(external_id="RFM-S-USD", customer_id=c.id, plan="USD Plan", status="active",
                     start_date=NOW-timedelta(days=120), mrr=Decimal("20.00"), currency="USD"),
        Subscription(external_id="RFM-S-INR", customer_id=c.id, plan="INR Plan", status="active",
                     start_date=NOW-timedelta(days=90), mrr=Decimal("1500.00"), currency="INR"),
        Invoice(external_id="RFM-I-USD", customer_id=c.id, invoice_date=NOW-timedelta(days=10),
                amount=Decimal("20.00"), currency="USD", status="open"),
        Invoice(external_id="RFM-I-INR", customer_id=c.id, invoice_date=NOW-timedelta(days=5),
                amount=Decimal("1500.00"), currency="INR", status="open"),
    ])
    db_session.commit()
    build_features(db_session, NOW, "2.1", customer_ids=[c.id])
    snapshot = db_session.query(__import__("app.models", fromlist=["FeatureSnapshot"]).FeatureSnapshot).filter_by(
        customer_id=c.id, feature_version="2.1").one()
    features = json_loads(snapshot.features_json)
    assert features["mrr_by_currency"] == {"INR": 1500.0, "USD": 20.0}
    assert features["average_active_subscription_mrr_single_currency"] is None
    assert "invoice_single_currency_90d" not in features
    assert features["invoice_frequency_90d"] == 2
    assert features["invoice_recency_days"] == 5
    assert features["payment_recency_days"] is None


def test_current_month_cohort_checkpoint_includes_customers_acquired_later_in_month(db_session):
    from app.services.analytics import cohort_retention
    acquired = datetime.now(timezone.utc).replace(day=min(25, datetime.now(timezone.utc).day), hour=0, minute=0, second=0, microsecond=0)
    customer = Customer(external_id="COHORT-LATE-MONTH", name="Late cohort member", acquisition_date=acquired,
                        source_name="test")
    db_session.add(customer); db_session.flush()
    db_session.add(Subscription(external_id="COHORT-LATE-SUB", customer_id=customer.id, plan="Base",
                                status="active", start_date=acquired, mrr=Decimal("1.00"), currency="USD"))
    db_session.commit()
    cohort = cohort_retention(db_session)
    row = next(x for x in cohort["rows"] if x["cohort"] == acquired.strftime("%Y-%m"))
    assert row["current_active_rate"] == 1.0
    assert "age_months_observed" in row and "age_months_median" not in row


def test_training_compares_all_available_model_families(db_session, tmp_path, monkeypatch):
    import importlib.util
    from dataclasses import replace
    import app.services.ml as ml_module
    monkeypatch.setattr(ml_module, "settings", replace(ml_module.settings, artifact_dir=tmp_path))
    seed_demo(db_session, customers=120, seed=228)
    trained = train_models(db_session, feature_version="2.1", horizon_days=30,
                           false_positive_cost=5.0, false_negative_cost=250.0, cost_unit="USD")
    names = {x["algorithm"] for x in trained["metrics"]["candidate_comparison"]}
    assert {"logistic_regression", "random_forest"}.issubset(names)
    if importlib.util.find_spec("xgboost"):
        assert "xgboost" in names
    if importlib.util.find_spec("lightgbm"):
        assert "lightgbm" in names
    threshold_policy = trained["metrics"]["threshold_analysis"]
    assert threshold_policy["selection_metric"] == "minimum_validation_expected_decision_cost"
    assert threshold_policy["cost_unit"] == "USD"
    assert len(threshold_policy["points"]) == 17
    assert trained["metrics"]["test_calibration"]["bins"]
