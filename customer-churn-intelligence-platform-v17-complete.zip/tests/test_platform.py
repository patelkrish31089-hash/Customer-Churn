from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.config import Settings
from app.db import Base
from app.models import (AuditEvent, ChurnLabel, CRMAction, Customer, FeatureSnapshot, ImportBatch,
                        Invoice, ModelRelease, Payment, Prediction, RetentionRecommendation,
                        Subscription, SupportTicket, UsageEvent, User)
from app.security import hash_password, verify_password, token_digest
from app.services.data import import_csv, generate_labels, build_features, classify_churn_reason
from app.services.analytics import overview, survival_curve
from app.services.ml import train_models, approve_release, predict_customer, assemble_dataset, _metrics
from app.services.retention import review_recommendation, execute_sandbox_action, generate_recommendations
from app.services.mlops import calculate_psi
from app.utils import parse_datetime, to_decimal, safe_filename, finite_probability, risk_band

NOW = datetime(2026, 11, 5, tzinfo=timezone.utc)


def add_customer(db, external_id="C-1", consent=True):
    c = Customer(external_id=external_id, name=f"Customer {external_id}", email=f"{external_id}@example.invalid",
                 segment="SMB", country="IN", acquisition_date=NOW-timedelta(days=300),
                 consent_to_contact=consent, source_name="test")
    db.add(c); db.flush(); return c


def test_password_hash_is_salted_and_verifiable():
    a = hash_password("correct-horse-battery-1")
    b = hash_password("correct-horse-battery-1")
    assert a != b
    assert verify_password("correct-horse-battery-1", a)
    assert not verify_password("wrong-password", a)


def test_password_policy_rejects_short_password():
    with pytest.raises(ValueError): hash_password("short")


def test_config_rejects_unknown_environment():
    s = Settings(environment="qa")
    with pytest.raises(ValueError): s.validate()


def test_config_rejects_unsafe_production(monkeypatch):
    monkeypatch.setenv("SECRET_KEY", "test-only-long-secret-for-config-validation")
    s = Settings(environment="production", database_url="sqlite:///prod.db", cors_origins=("*",))
    with pytest.raises(ValueError): s.validate()


def test_config_requires_production_secret(monkeypatch):
    monkeypatch.delenv("SECRET_KEY", raising=False)
    s = Settings(environment="production", database_url="postgresql://user:pass@localhost/app",
                 cors_origins=("https://app.example.com",))
    with pytest.raises(ValueError, match="SECRET_KEY"):
        s.validate()


def test_staging_requires_secret(monkeypatch):
    monkeypatch.delenv("SECRET_KEY", raising=False)
    s = Settings(environment="staging", database_url="postgresql://user:pass@localhost/app")
    with pytest.raises(ValueError, match="SECRET_KEY"):
        s.validate()


def test_session_token_digest_is_keyed_when_secret_is_configured(monkeypatch):
    monkeypatch.setenv("SECRET_KEY", "unit-test-secret-material-123456")
    keyed = token_digest("sample-session-token")
    monkeypatch.setenv("SECRET_KEY", "different-secret-material-654321")
    assert keyed != token_digest("sample-session-token")


def test_datetime_and_money_parsers_are_strict():
    assert parse_datetime("2026-11-05T12:00:00Z").utcoffset() == timedelta(0)
    assert to_decimal("10.25") == Decimal("10.25")
    with pytest.raises(ValueError): to_decimal("nan")
    with pytest.raises(ValueError): parse_datetime("not-a-date")


def test_filename_is_path_safe():
    assert safe_filename("../../evil.csv") == "evil.csv"


def test_risk_bands_boundary():
    assert risk_band(0.34) == "low"
    assert risk_band(0.35) == "medium"
    assert risk_band(0.70) == "high"


def test_probability_validation_rejects_nan():
    with pytest.raises(ValueError): finite_probability(float("nan"))
    with pytest.raises(ValueError): finite_probability(1.2)


def test_csv_import_customer_and_provenance(db_session):
    content=b"customer_id,name,email,segment,country,consent_to_contact\nC1,Alice,a@example.invalid,SMB,IN,true\n"
    result=import_csv(db_session,"customers","customers.csv",content,"crm_export")
    assert result["records_accepted"] == 1
    c=db_session.query(Customer).filter_by(external_id="C1").one()
    assert c.source_name == "crm_export" and c.consent_to_contact


def test_csv_import_is_idempotent(db_session):
    content=b"customer_id,name\nC1,Alice\n"
    first=import_csv(db_session,"customers","c.csv",content)
    second=import_csv(db_session,"customers","c.csv",content)
    assert first["batch_id"] == second["batch_id"]
    assert second["status"] == "duplicate"
    assert db_session.query(Customer).count() == 1


def test_csv_import_quarantines_invalid_rows_without_losing_valid_rows(db_session):
    content=b"customer_id,name\nC1,Alice\n,Missing ID\nC2,Bob\n"
    result=import_csv(db_session,"customers","c.csv",content)
    assert result["records_received"] == 3
    assert result["records_accepted"] == 2
    assert result["records_rejected"] == 1
    assert db_session.query(Customer).count() == 2
    assert result["status"] == "completed_with_errors"


def test_import_rejects_missing_columns(db_session):
    with pytest.raises(ValueError, match="Missing required columns"):
        import_csv(db_session,"customers","x.csv",b"name\nAlice\n")


def test_subscription_import_requires_customer(db_session):
    content=b"subscription_id,customer_id,start_date\nS1,missing,2026-01-01\n"
    result=import_csv(db_session,"subscriptions","s.csv",content)
    assert result["records_rejected"] == 1


def test_import_relationships_and_decimal_money(db_session):
    add_customer(db_session)
    s=import_csv(db_session,"subscriptions","s.csv",b"subscription_id,customer_id,start_date,mrr,currency\nS1,C-1,2025-01-01,12.34,USD\n")
    assert s["records_accepted"] == 1
    assert db_session.query(Subscription).one().mrr == Decimal("12.34")


def test_churn_reason_classification_is_not_overconfident():
    assert classify_churn_reason("customer_request") == "VOLUNTARY"
    assert classify_churn_reason("non_payment") == "INVOLUNTARY"
    assert classify_churn_reason("product_sunset") == "OTHER"
    assert classify_churn_reason("unknown") == "UNKNOWN"
    assert classify_churn_reason(None) == "UNKNOWN"


def test_customer_churn_positive_only_when_all_subscriptions_end(db_session):
    c=add_customer(db_session)
    db_session.add_all([
        Subscription(external_id="S1",customer_id=c.id,plan="p",status="cancelled",start_date=NOW-timedelta(days=100),end_date=NOW+timedelta(days=10),cancellation_date=NOW+timedelta(days=10),churn_reason="customer_request",mrr=Decimal("10"),currency="USD"),
        Subscription(external_id="S2",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=50),mrr=Decimal("10"),currency="USD"),
    ]);db_session.commit()
    r=generate_labels(db_session,NOW,NOW+timedelta(days=31),30,"customer")
    label=db_session.query(ChurnLabel).filter_by(entity_scope="customer",entity_ref="C-1").one()
    assert label.churn_30d == 0 and label.churn_type == "NONE"


def test_subscription_label_is_separate_scope(db_session):
    c=add_customer(db_session)
    s=Subscription(external_id="S1",customer_id=c.id,plan="p",status="cancelled",start_date=NOW-timedelta(days=100),end_date=NOW+timedelta(days=10),cancellation_date=NOW+timedelta(days=10),churn_reason="customer_request",mrr=Decimal("10"),currency="USD")
    db_session.add(s);db_session.commit()
    r=generate_labels(db_session,NOW,NOW+timedelta(days=31),30,"subscription")
    label=db_session.query(ChurnLabel).filter_by(entity_scope="subscription",entity_ref="S1").one()
    assert label.churn_30d == 1 and label.churn_type == "VOLUNTARY"
    assert db_session.query(ChurnLabel).filter_by(entity_scope="customer").count() == 0


def test_incomplete_observation_is_censored_not_negative(db_session):
    c=add_customer(db_session)
    db_session.add(Subscription(external_id="S1",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=100),mrr=Decimal("1"),currency="USD"));db_session.commit()
    generate_labels(db_session,NOW,NOW+timedelta(days=12),30,"customer")
    label=db_session.query(ChurnLabel).one()
    assert label.churn_30d is None and label.is_censored is True


def test_mature_observation_with_no_event_is_negative(db_session):
    c=add_customer(db_session)
    db_session.add(Subscription(external_id="S1",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=100),mrr=Decimal("1"),currency="USD"));db_session.commit()
    generate_labels(db_session,NOW,NOW+timedelta(days=31),30,"customer")
    label=db_session.query(ChurnLabel).one()
    assert label.churn_30d == 0 and label.churn_type == "NONE"


def test_feature_snapshot_excludes_future_usage_and_is_immutable(db_session):
    c=add_customer(db_session)
    s=Subscription(external_id="S1",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=100),mrr=Decimal("9"),currency="USD")
    db_session.add(s);db_session.flush()
    db_session.add_all([
        UsageEvent(external_id="U1",customer_id=c.id,subscription_id=s.id,event_time=NOW-timedelta(days=2),event_type="login",quantity=1,source_name="test"),
        UsageEvent(external_id="U2",customer_id=c.id,subscription_id=s.id,event_time=NOW+timedelta(days=2),event_type="login",quantity=1,source_name="test"),
    ]);db_session.commit()
    r=build_features(db_session,NOW,"1.0")
    snap=db_session.query(FeatureSnapshot).one()
    data=json.loads(snap.features_json)
    assert data["usage_events_7d"] == 1
    db_session.add(UsageEvent(external_id="U3",customer_id=c.id,subscription_id=s.id,event_time=NOW-timedelta(days=1),event_type="login",quantity=1,source_name="test"));db_session.commit()
    again=build_features(db_session,NOW,"1.0")
    assert again["created"] == 0 and again["already_exists"] == 1
    assert json.loads(snap.features_json)["usage_events_7d"] == 1


def test_feature_currency_groups_are_not_added_together(db_session):
    c=add_customer(db_session)
    db_session.add_all([
        Subscription(external_id="S1",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=100),mrr=Decimal("10"),currency="USD"),
        Subscription(external_id="S2",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=90),mrr=Decimal("1000"),currency="INR"),
    ]);db_session.commit()
    build_features(db_session,NOW)
    data=json.loads(db_session.query(FeatureSnapshot).one().features_json)
    assert data["mrr_by_currency"] == {"USD":10.0,"INR":1000.0}
    assert "mrr_single_currency" not in data


def test_customer_360_financials_separate_currency(db_session):
    from app.services.ml import customer_360
    c=add_customer(db_session)
    db_session.add_all([
        Subscription(external_id="S1",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=100),mrr=Decimal("10"),currency="USD"),
        Subscription(external_id="S2",customer_id=c.id,plan="p",status="active",start_date=NOW-timedelta(days=90),mrr=Decimal("1000"),currency="INR"),
    ]);db_session.commit()
    profile=customer_360(db_session,c.id)
    assert profile["financials_by_currency"]["USD"]["mrr"] == 10
    assert profile["financials_by_currency"]["INR"]["mrr"] == 1000


def test_metrics_handle_single_class_without_roc_auc():
    m=_metrics([0,0,0],[.1,.2,.3])
    assert m["roc_auc"] is None and m["sample_count"] == 3


def test_train_demo_model_and_candidate_approval(db_session, monkeypatch, tmp_path):
    from app.demo import seed_demo
    from dataclasses import replace
    import app.services.ml as ml_module
    monkeypatch.setattr(ml_module, "settings", replace(ml_module.settings, artifact_dir=tmp_path))
    result=seed_demo(db_session,customers=120,seed=31)
    assert result["provenance"] == "synthetic_demo"
    dataset=assemble_dataset(db_session)
    assert len(dataset) >= 100
    trained=train_models(db_session)
    assert trained["status"] == "candidate_requires_approval"
    release=db_session.query(ModelRelease).filter_by(release_id=trained["release_id"]).one()
    assert release.status == "candidate"
    admin=User(username="admin2",password_hash=hash_password("admin-password-12345"),role="admin")
    db_session.add(admin);db_session.commit()
    approved=approve_release(db_session,release.release_id,admin.id)
    assert approved.status == "approved"


def test_prediction_requires_approved_model(db_session):
    c=add_customer(db_session)
    with pytest.raises(ValueError,match="No approved model"):
        predict_customer(db_session,c.id,NOW)


def test_model_release_approval_requires_artifact(db_session):
    u=User(username="a",password_hash=hash_password("long-password-1234"),role="admin");db_session.add(u);db_session.flush()
    r=ModelRelease(release_id="r1",training_run_id="t1",model_name="lr",artifact_path="/missing/model",status="candidate",feature_version="1.0",horizon_days=30,metrics_json="{}")
    db_session.add(r);db_session.commit()
    with pytest.raises(ValueError,match="artifact is missing"): approve_release(db_session,"r1",u.id)


def test_recommendation_requires_prediction_context(db_session):
    c=add_customer(db_session)
    result=generate_recommendations(db_session)
    assert result["created"] == 0


def test_crm_sandbox_requires_approved_recommendation(db_session):
    c=add_customer(db_session)
    r=RetentionRecommendation(customer_id=c.id,category="review",title="Review",rationale="evidence",status="pending_approval",evidence_json="{}")
    db_session.add(r);db_session.commit()
    with pytest.raises(ValueError,match="approved recommendation"): execute_sandbox_action(db_session,r.id,"key-12345678")


def test_crm_sandbox_requires_contact_consent(db_session):
    c=add_customer(db_session,consent=False)
    r=RetentionRecommendation(customer_id=c.id,category="review",title="Review",rationale="evidence",status="approved",evidence_json="{}")
    db_session.add(r);db_session.commit()
    with pytest.raises(ValueError,match="consent"): execute_sandbox_action(db_session,r.id,"key-12345678")


def test_crm_sandbox_idempotency(db_session):
    c=add_customer(db_session,consent=True)
    r=RetentionRecommendation(customer_id=c.id,category="review",title="Review",rationale="evidence",status="approved",evidence_json="{}")
    db_session.add(r);db_session.commit()
    a=execute_sandbox_action(db_session,r.id,"key-12345678")
    b=execute_sandbox_action(db_session,r.id,"key-12345678")
    assert a["action_id"] == b["action_id"] and b["idempotent_reuse"]
    assert b["status"] == "sandbox_completed"


def test_review_workflow_only_pending(db_session):
    c=add_customer(db_session)
    r=RetentionRecommendation(customer_id=c.id,category="review",title="Review",rationale="evidence",status="pending_approval",evidence_json="{}")
    u=User(username="retmgr",password_hash=hash_password("long-password-1234"),role="retention_manager")
    db_session.add_all([r,u]);db_session.commit()
    review_recommendation(db_session,r.id,"approved",u.id)
    assert r.status == "approved"
    with pytest.raises(ValueError,match="Only pending"): review_recommendation(db_session,r.id,"rejected",u.id)


def test_psi_low_and_high_drift():
    assert calculate_psi([1,2,3,4,5,6],[1,2,3,4,5,6]) < 0.01
    assert calculate_psi([1,2,3,4,5,6],[100,110,120,130,140,150]) > 0.2


def test_psi_requires_minimum_values():
    with pytest.raises(ValueError): calculate_psi([1],[2])


def test_overview_is_empty_and_truthful(db_session):
    result=overview(db_session)
    assert result["customers"] == 0 and result["labeled_churn_rate"] is None


def test_survival_curve_empty(db_session):
    assert survival_curve(db_session)["sample_count"] == 0


def test_api_health_and_correlation(client):
    r=client.get("/api/v1/health/live",headers={"X-Correlation-ID":"test-corr-1"})
    assert r.status_code == 200 and r.headers["X-Correlation-ID"] == "test-corr-1"
    assert client.get("/api/v1/health/ready").status_code == 200


def test_api_login_logout_and_auth(client, users):
    r=client.post("/api/v1/auth/login",json={"username":"admin","password":"a-strong-password-123"})
    assert r.status_code == 200
    h={"Authorization":f"Bearer {r.json()['access_token']}"}
    assert client.get("/api/v1/auth/me",headers=h).status_code == 200
    assert client.post("/api/v1/auth/logout",headers=h).status_code == 200
    assert client.get("/api/v1/auth/me",headers=h).status_code == 401


def test_api_rejects_bad_login(client, users):
    assert client.post("/api/v1/auth/login",json={"username":"admin","password":"bad"}).status_code == 401


def test_api_requires_auth_for_customer_data(client):
    assert client.get("/api/v1/customers").status_code == 401


def test_api_rbac_admin_user_creation(client, auth_headers):
    r=client.post("/api/v1/admin/users",headers=auth_headers,json={"username":"newuser","password":"new-user-long-password","role":"analyst"})
    assert r.status_code == 201
    assert client.post("/api/v1/admin/users",headers=auth_headers,json={"username":"newuser","password":"new-user-long-password","role":"analyst"}).status_code == 409


def test_api_viewer_cannot_upload(client, users):
    login=client.post("/api/v1/auth/login",json={"username":"viewer","password":"viewer-password-12345"}).json()
    h={"Authorization":f"Bearer {login['access_token']}"}
    r=client.post("/api/v1/imports/customers",headers=h,files={"file":("a.csv",b"customer_id,name\n1,A")})
    assert r.status_code == 403


def test_api_customer_search_and_not_found(client, auth_headers, db_session):
    c=add_customer(db_session)
    r=client.get("/api/v1/customers?q=C-1",headers=auth_headers)
    assert r.status_code == 200 and r.json()["total"] == 1
    assert client.get("/api/v1/customers/99999",headers=auth_headers).status_code == 404


def test_api_upload_and_batch_report(client, auth_headers):
    r=client.post("/api/v1/imports/customers",headers=auth_headers,files={"file":("c.csv",b"customer_id,name\nC1,Alice\n,C")})
    assert r.status_code == 201
    data=r.json(); assert data["records_accepted"] == 1 and data["records_rejected"] == 1
    report=client.get(f"/api/v1/imports/{data['batch_id']}",headers=auth_headers)
    assert report.status_code == 200 and len(report.json()["issues"]) == 1


def test_api_frontend_is_served(client):
    r=client.get("/")
    assert r.status_code == 200 and "Churn Intelligence" in r.text
    assert client.get("/static/app.js").status_code == 200


def test_api_ready_and_unauthenticated_boundary(client):
    assert client.get("/api/v1/ops/integrations").status_code == 401


def test_backup_and_restore_sqlite_round_trip(tmp_path):
    source=tmp_path/"source.sqlite"; backup=tmp_path/"backup.sqlite"
    conn=sqlite3.connect(source);conn.execute("CREATE TABLE evidence(id INTEGER PRIMARY KEY, value TEXT)");conn.execute("INSERT INTO evidence(value) VALUES ('ok')");conn.commit()
    dest=sqlite3.connect(backup);conn.backup(dest);dest.close();conn.close()
    check=sqlite3.connect(backup)
    assert check.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    assert check.execute("SELECT value FROM evidence").fetchone()[0] == "ok"
    check.close()


def test_currency_monetary_model_uses_decimal_columns():
    assert "NUMERIC(18, 2)" in str(Subscription.__table__.c.mrr.type).upper()
    assert "NUMERIC(18, 2)" in str(Invoice.__table__.c.amount.type).upper()
    assert "NUMERIC(18, 2)" in str(Payment.__table__.c.amount.type).upper()


def test_end_to_end_synthetic_training_prediction_and_retention(db_session, monkeypatch, tmp_path):
    from dataclasses import replace
    import app.services.ml as ml_module
    from app.demo import seed_demo
    monkeypatch.setattr(ml_module, "settings", replace(ml_module.settings, artifact_dir=tmp_path))
    seeded=seed_demo(db_session,customers=120,seed=51)
    assert seeded["not_real_company_data"]
    trained=train_models(db_session)
    admin=User(username="e2e-admin",password_hash=hash_password("e2e-admin-password-12345"),role="admin")
    db_session.add(admin);db_session.commit()
    release=approve_release(db_session,trained["release_id"],admin.id)
    c=db_session.query(Customer).filter_by(external_id="SYN-CUST-00001").one()
    prediction_cutoff=datetime.now(timezone.utc)
    scored=predict_customer(db_session,c.id,prediction_cutoff)
    assert 0 <= scored["probability"] <= 1
    repeated=predict_customer(db_session,c.id,prediction_cutoff)
    assert repeated["idempotent_reuse"] is True
    generated=generate_recommendations(db_session)
    assert generated["status"] == "recommendations_require_human_approval"
    assert release.status == "approved"


def test_release_rollback_preserves_previous_release(db_session, tmp_path):
    from dataclasses import replace
    from app.services.ml import rollback_release
    import joblib
    from app.models import ModelRelease
    path1=tmp_path/"m1.joblib";path2=tmp_path/"m2.joblib"
    joblib.dump({"x":1},path1);joblib.dump({"x":2},path2)
    r1=ModelRelease(release_id="old-release",training_run_id="t1",model_name="a",artifact_path=str(path1),status="superseded",feature_version="1.0",horizon_days=30,metrics_json="{}")
    r2=ModelRelease(release_id="new-release",training_run_id="t2",model_name="b",artifact_path=str(path2),status="approved",feature_version="1.0",horizon_days=30,metrics_json="{}")
    db_session.add_all([r1,r2]);db_session.commit()
    rolled=rollback_release(db_session,"old-release")
    assert rolled.status == "approved"
    assert db_session.query(ModelRelease).filter_by(release_id="new-release").one().status == "superseded"
