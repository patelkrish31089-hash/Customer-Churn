from __future__ import annotations

import pytest

from scripts.local_demo_acceptance import LOCAL_REQUIRED, PRODUCTION_ONLY, build_report


def make_verification(status: str = "PASS"):
    return {
        "generated_at": "2026-11-07T00:00:00+00:00",
        "checks": [{"name": name, "status": status} for name in LOCAL_REQUIRED]
        + [{"name": name, "status": "BLOCKED"} for name in PRODUCTION_ONLY],
    }


def test_local_demo_profile_passes_only_declared_local_scope():
    result = build_report(make_verification(), "test-reviewer")
    assert result["profile"] == "local_demo"
    assert result["local_scope"]["status"] == "PASS"
    assert result["local_scope"]["passed"] == len(LOCAL_REQUIRED) == 15
    assert result["production_only_gates"]["status"] == "NOT_ACCEPTED"
    assert result["production_only_gates"]["excluded_from_local_demo_count"] == len(PRODUCTION_ONLY) == 10
    assert all(x["status"] == "NOT_IN_SCOPE_LOCAL_DEMO" for x in result["production_only_gates"]["checks"])


def test_local_demo_profile_does_not_hide_a_local_failure():
    verification = make_verification()
    verification["checks"][0]["status"] = "FAIL"
    result = build_report(verification, "test-reviewer")
    assert result["local_scope"]["status"] == "BLOCKED"
    assert result["local_scope"]["failed_or_blocked"] == 1


def test_local_demo_profile_requires_all_local_evidence():
    verification = make_verification()
    verification["checks"] = [x for x in verification["checks"] if x["name"] != "browser_e2e_and_semantic_accessibility_smoke"]
    with pytest.raises(ValueError, match="missing checks"):
        build_report(verification, "test-reviewer")


def test_interactive_admin_bootstrap_creates_admin_without_default_account(db_session):
    from scripts.bootstrap_admin import create_admin

    user = create_admin(db_session, "demo.admin", "a-secure-local-password-123")
    assert user.username == "demo.admin"
    assert user.role == "admin"
    assert user.is_active is True
    assert user.password_hash != "a-secure-local-password-123"


def test_interactive_admin_bootstrap_rejects_duplicate_and_weak_values(db_session):
    from scripts.bootstrap_admin import create_admin

    create_admin(db_session, "demo.admin", "a-secure-local-password-123")
    with pytest.raises(ValueError, match="already exists"):
        create_admin(db_session, "demo.admin", "another-secure-password-456")
    with pytest.raises(ValueError, match="12 characters"):
        create_admin(db_session, "other.admin", "short")
    with pytest.raises(ValueError, match="Username must be"):
        create_admin(db_session, "x", "a-secure-local-password-123")
