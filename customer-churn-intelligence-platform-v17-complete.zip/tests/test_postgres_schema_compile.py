from sqlalchemy import create_mock_engine

from app.models import Base


def test_all_declared_tables_compile_with_postgresql_dialect():
    statements: list[str] = []
    engine = create_mock_engine("postgresql://", lambda sql, *a, **k: statements.append(
        str(sql.compile(dialect=engine.dialect))))
    Base.metadata.create_all(engine)
    ddl = "\n".join(statements)
    assert len(Base.metadata.tables) >= 25
    assert "CREATE TABLE customers" in ddl
    assert "CREATE TABLE feature_snapshots" in ddl
    assert "FOREIGN KEY" in ddl
    assert "AUTOINCREMENT" not in ddl.upper()
    assert "PRAGMA" not in ddl.upper()
