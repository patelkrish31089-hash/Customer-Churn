# Customer Churn Intelligence Platform — V17

> V17 adds a governed Feature Store user workflow and atomic bulk data-quality review to the V16 application. The release also wires the new product acceptance smoke into local, Windows and hosted CI verification. It remains a controlled development/local-demo build until every production gate has genuine runtime or external-owner evidence.

A local-first customer churn intelligence platform built from the supplied 20-phase specification. The repository contains a FastAPI backend, SQLAlchemy/Alembic persistence, authenticated dashboard, multi-format ingestion, data-quality review, point-in-time labels and features, analytical services, model training/evaluation, approved prediction serving, Customer 360, retention workflows, CRM provider adapters and MLOps integration boundaries.

> **V17 current evidence:** **16 PASS / 0 FAIL / 10 BLOCKED across 26 production acceptance checks**. The strict regression suite has **147 tests passing, 0 failures and 0 skips**. The separate local-demo profile is **15/15 PASS**. These are local acceptance results, not production certification. Ten production gates still require live PostgreSQL, Docker, a network-enabled isolated install, MLOps/security runtimes, company CRM/staging/data/policy evidence and an independent penetration test.

## Quick start (SQLite local demo)

Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_local_demo.ps1
```

macOS/Linux:

```bash
bash scripts/run_local_demo.sh
```

The launcher creates a project virtual environment, initializes the local SQLite database, seeds clearly marked synthetic demo records, and prompts for the first administrator. Open http://127.0.0.1:8000. No default administrator is created. Synthetic records use `synthetic_demo` provenance and `.invalid` email addresses; they are not company data.

## Main application workflows

1. Import customer, subscription, invoice, payment, usage and support records from CSV, XLSX or JSON. The generic REST source connector accepts HTTPS JSON only from exact allowlisted hostnames, validates public DNS answers on the default request path, disables redirects and bounds response size.
2. Inspect import batches, row-level quarantine, source provenance and configurable data-quality findings. Corrections are restricted to approved fields and audited. Bulk review supports accept-risk or false-positive decisions only, validates the entire selection before mutation, and records one audit event per finding.
3. Generate customer- and subscription-level churn labels with explicit cutoff, horizon, maturity and right-censoring behavior. Business approval of churn semantics remains required.
4. Build immutable point-in-time feature snapshots (contract `2.1`) with currency-separated monetary data.
5. Use the V17 Feature Store to inspect the feature registry, snapshot coverage and null rates, retrieve the latest eligible snapshot as-of a timestamp, inspect per-customer history, export snapshots to CSV, and enqueue feature materialization as a durable background job.
6. Inspect EDA, cohort-retention views and Kaplan–Meier survival estimates with confidence bounds.
7. Train Logistic Regression, Random Forest and available XGBoost/LightGBM candidates. Candidate selection uses chronological validation; calibration is fitted on training data; final chronological test data is held out.
8. Optionally supply finance-approved false-positive/false-negative costs to select a threshold by validation cost. No business cost is invented.
9. Approve a model release before inference. Single and batch scoring pin the approved release; retries only reprocess failed customer IDs.
10. Review Customer 360 and retention recommendations. Human approval and contact consent are required before any external action.
11. Salesforce, HubSpot and Intercom adapters have local mocked HTTP contract tests and guardrails. No live CRM account is claimed connected.
12. Long-running imports, label generation, feature builds, quality audits, model training, batch scoring, retention generation and REST source sync can be submitted to the durable database-backed job queue. A separate worker uses leases, bounded retries, priority and idempotency keys. Run one worker for SQLite; PostgreSQL is the intended multi-worker runtime.

## Optional model and MLOps capabilities

```bash
python -m pip install -r requirements-advanced-ml.txt
python -m pip install -r requirements-explainability.txt
python -m pip install -r requirements-mlops-optional.txt
```

The application has local model registry and drift-monitoring paths. MLflow/Evidently adapters and an Airflow scoring DAG are provided, but those optional services are not runtime-verified in this workspace. Apache Airflow must be installed using its official constraints file for the selected Python version.

## Verification

Run the acceptance stages independently from the project virtual environment:

```bash
python -m pytest -q -W error
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage product
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
python scripts/local_demo_acceptance.py --reviewed-by "Reviewer Identifier"
```

The core stage writes JUnit evidence to `reports/junit-v17.xml`. The new `product` stage runs `scripts/product_workflow_smoke.py` against an isolated SQLite API test client and verifies feature catalog/coverage/as-of lookup/history/export/materialization plus atomic bulk quality review/audit persistence. The browser bridge visits the Feature Store screen and checks semantic control names. The local-demo report counts only its declared 15 local checks; its ten excluded production-only gates are not marked passed.

Current evidence is in `reports/verification_*.json`, `reports/verification.json`, `reports/verification.md`, `reports/local_demo_acceptance.json` and `reports/feature_store_quality_evidence.json`. The shared global Python `pip check` diagnostic is `NOT_APPLICABLE`; it is not an application pass or failure. A fresh isolated install remains a separate production gate.

## Production gates that remain open

| Gate | What closes it |
|---|---|
| PostgreSQL runtime | Execute migrations, CRUD/constraints/auth/session and worker concurrency against a real PostgreSQL server. |
| Docker runtime | Build and run the Compose stack; verify health, restart persistence, worker execution, backup and restore. |
| Clean isolated install | Complete a fresh Python 3.11/3.12 install from the declared dependency groups with package-index access. |
| MLOps runtime | Run MLflow tracking, Evidently reports and Airflow scheduler/task execution. |
| Quality/security toolchain | Run Ruff, Bandit and pip-audit in the isolated environment and resolve findings. |
| Live CRM sandbox | Obtain an authorized Salesforce/HubSpot/Intercom tenant, OAuth scopes and credentials; verify create/read-back/webhooks. |
| Hosted staging | Deploy an immutable commit to an authorized hosting account with domain/TLS, secrets, backups and rollback. |
| Real-company model validation | Validate on authorized company records with mature outcomes, temporal holdout, leakage/calibration/subgroup review. |
| Business-policy sign-off | Obtain written approval for cancellation, pause, grace period, reactivation, censoring and churn scope. |
| Independent penetration test | Obtain an authorized independent report, remediation references and retest. |

These ten gates cannot be responsibly closed by synthetic fixtures, static configuration checks or local substitutes. Do not mark a simulator as live CRM, SQLite as PostgreSQL, a Compose YAML check as Docker runtime, or synthetic metrics as company model accuracy.

## PostgreSQL, Docker and hosted CI

The repository includes a PostgreSQL 16 Compose configuration with persistent volumes and health checks. This execution workspace has no Docker daemon, PostgreSQL server/runtime, package-index DNS, MLOps/security tools, CRM credentials, hosting account, authorized company dataset or independent assessor. PostgreSQL offline migration compilation and Compose static validation pass; neither is a live runtime pass.

```bash
cp .env.example .env
# Set POSTGRES_PASSWORD to a unique value in .env.
docker compose up --build
```

The Compose stack starts PostgreSQL, API and a dedicated worker; app startup applies Alembic migrations. Create an administrator with:

```bash
docker compose exec app python -m app.cli create-admin --username admin --password "Use-A-Unique-Long-Password!"
```

The GitHub Actions workflow `full-platform-acceptance` runs clean-install checks on Python 3.11/3.12, the Ruff/Bandit/pip-audit toolchain, PostgreSQL runtime and worker tests, Feature Store/bulk-quality product smoke, Docker recovery, browser/accessibility, MLOps and Airflow jobs. A static workflow-contract pass is not remote execution evidence. After a real hosted run, inspect its artifacts and logs and explicitly review the same-run evidence with `scripts/merge_hosted_evidence.py`; mixed run/attempt/repository/commit artifacts are rejected.

## Windows acceptance runner

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_acceptance.ps1 -PythonVersion 3.12 -ReviewedBy "Reviewer Identifier"
```

Optional switches `-WithContainers`, `-WithMLOps` and `-WithBrowserNative` run the corresponding services when installed and authorized. Detailed acceptance and external-owner handoffs are in [`docs/verification/V17_GATE_CLOSURE_CHECKLIST.md`](docs/verification/V17_GATE_CLOSURE_CHECKLIST.md).

## Release evidence and limitations

V17 fresh evidence records **16 PASS / 0 FAIL / 10 BLOCKED**. The 16 passes include strict regression, local HTTP/authentication/concurrency, SQLite worker queue, SQLite migration lifecycle, PostgreSQL offline migration compilation, Compose/CI static validation, Feature Store/bulk-review API workflow, synthetic train/approve/score/retention and Chromium UI/API navigation. The test count is 147, not 98. Accessibility evidence is a semantic smoke, not full WCAG/axe certification. Synthetic ML metrics prove pipeline execution only.

The 20-phase roadmap is not fully accepted. Phase implementation details and partial scope are tracked in [`docs/ROADMAP_COVERAGE.md`](docs/ROADMAP_COVERAGE.md). Older V10–V16 reports remain historical evidence; `reports/verification.json` is the current V17 aggregate.
