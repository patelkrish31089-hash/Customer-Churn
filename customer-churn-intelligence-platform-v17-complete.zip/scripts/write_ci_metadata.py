from __future__ import annotations

"""Write non-secret GitHub Actions provenance alongside each acceptance artifact."""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    artifact_name = os.getenv("CI_ARTIFACT_NAME", "").strip()
    if not artifact_name:
        raise SystemExit("CI_ARTIFACT_NAME is required; use the exact upload-artifact name")
    metadata = {
        "schema_version": 1,
        "workflow": os.getenv("GITHUB_WORKFLOW", ""),
        "repository": os.getenv("GITHUB_REPOSITORY", ""),
        "run_id": os.getenv("GITHUB_RUN_ID", ""),
        "run_attempt": os.getenv("GITHUB_RUN_ATTEMPT", ""),
        "commit_sha": os.getenv("GITHUB_SHA", ""),
        "ref": os.getenv("GITHUB_REF", ""),
        "job_id": os.getenv("GITHUB_JOB", ""),
        "job_status": os.getenv("CI_JOB_STATUS", "unknown").lower(),
        "artifact_name": artifact_name,
        "matrix_python_version": os.getenv("MATRIX_PYTHON_VERSION", ""),
        "runner_os": os.getenv("RUNNER_OS", ""),
        "python_version": sys.version.split()[0],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "secret_values_included": False,
    }
    path = ROOT / "reports" / "ci_run_metadata.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "written", "artifact_name": artifact_name,
                      "run_id_present": bool(metadata["run_id"]),
                      "commit_sha_present": bool(metadata["commit_sha"]),
                      "metadata_file": "reports/ci_run_metadata.json"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
