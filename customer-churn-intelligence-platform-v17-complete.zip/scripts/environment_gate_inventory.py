from __future__ import annotations

import importlib.util
import json
import os
import shutil
import socket
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def collect() -> dict:
    modules = ("psycopg", "mlflow", "airflow", "evidently", "ruff", "bandit", "pip_audit",
               "playwright", "openpyxl", "xgboost", "lightgbm", "shap", "yaml")
    availability = {name: bool(importlib.util.find_spec(name)) for name in modules}
    commands = ("docker", "postgres", "initdb", "pg_ctl", "psql", "pg_config", "gh", "act", "ruff", "bandit", "pip-audit")
    binaries = {name: shutil.which(name) for name in commands}

    policy_path = Path("/etc/chromium/policies/managed/000_policy_merge.json")
    browser_policy: dict = {"path": str(policy_path), "readable": False}
    if policy_path.is_file():
        try:
            policy = json.loads(policy_path.read_text(encoding="utf-8"))
            browser_policy = {"path": str(policy_path), "readable": True,
                             "url_blocklist_all": "*" in policy.get("URLBlocklist", []),
                             "url_blocklist_entries": policy.get("URLBlocklist", [])}
        except (OSError, json.JSONDecodeError) as exc:
            browser_policy["error_type"] = type(exc).__name__

    try:
        socket.getaddrinfo("pypi.org", 443, type=socket.SOCK_STREAM)
        package_index_dns = "resolves"
    except OSError as exc:
        package_index_dns = f"unavailable:{type(exc).__name__}"

    credential_names = (
        "GITHUB_TOKEN", "GH_TOKEN", "SALESFORCE_INSTANCE_URL", "SALESFORCE_ACCESS_TOKEN",
        "HUBSPOT_PRIVATE_APP_TOKEN", "INTERCOM_ACCESS_TOKEN", "MLFLOW_TRACKING_URI",
        "POSTGRES_URL", "DATABASE_URL",
    )
    credentials_present = {name: bool(os.getenv(name, "").strip()) for name in credential_names}

    try:
        chromium_version = subprocess.run(["chromium", "--version"], capture_output=True, text=True,
                                          timeout=3, check=False).stdout.strip() or None
    except (OSError, subprocess.TimeoutExpired):
        chromium_version = None

    return {
        "scope": "read-only host capability inventory; secret values are never read or emitted",
        "python": __import__("sys").version.split()[0],
        "modules": availability,
        "binaries": binaries,
        "docker_daemon_socket_present": Path("/var/run/docker.sock").exists(),
        "postgres_server_toolchain_present": all(binaries.get(x) for x in ("postgres", "initdb", "pg_ctl")),
        "package_index_dns": package_index_dns,
        "browser": {"chromium_version": chromium_version, "managed_policy": browser_policy},
        "credential_configuration_presence_only": credentials_present,
        "remote_repository_execution": {"gh_cli_available": bool(binaries.get("gh")),
                                         "github_token_present": credentials_present["GITHUB_TOKEN"] or credentials_present["GH_TOKEN"],
                                         "status": "not_configured_in_this_workspace"},
    }


def main() -> int:
    result = collect()
    report = ROOT / "reports" / "host_environment_inventory.json"
    report.parent.mkdir(exist_ok=True)
    report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
