from __future__ import annotations

"""Generate a truthful acceptance report for the self-contained local-demo scope.

Production-only gates are listed as excluded from this profile, not passed.
The production report in reports/verification.json remains authoritative for release.
"""

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.merge_local_evidence import source_tree_sha256

REPORTS = ROOT / "reports"
LOCAL_REQUIRED = {
    "python_compile",
    "application_import",
    "frontend_javascript_syntax",
    "pytest_regression_warnings_as_errors",
    "static_secret_pattern_scan",
    "first_party_ast_security_smoke",
    "runtime_http_startup_auth_shutdown",
    "http_concurrency_smoke",
    "sqlite_migration_upgrade_downgrade_reupgrade",
    "postgresql_offline_migration_compile",
    "deployment_compose_static_validation",
    "ci_workflow_acceptance_contract",
    "synthetic_end_to_end_training_prediction_retention",
    "feature_store_and_quality_review_api_end_to_end",
    "browser_e2e_and_semantic_accessibility_smoke",
}
PRODUCTION_ONLY = {
    "live_crm_provider_sandbox": "Requires a real authorized CRM tenant and credentials; local adapter tests do not prove provider connectivity.",
    "hosted_staging_deployment": "A local process is not a company-owned hosted environment with domain, TLS, secrets, backup and rollback.",
    "real_company_model_validation": "Synthetic customers are not an authorized company dataset with mature outcomes.",
    "independent_penetration_test": "A source scan or local smoke cannot replace an independent authorized assessment and retest.",
    "business_churn_policy_signoff": "Cancellation, pause, grace-period, reactivation and censoring semantics require the business owner's approval.",
    "postgresql_runtime": "SQLite is the supported self-contained local-demo database; live PostgreSQL acceptance is a production deployment gate.",
    "docker_runtime": "The local-demo launcher does not require containers; Docker deployment/restore remains a separate production gate.",
    "clean_virtual_environment_install": "The local demo uses a normal isolated project venv, but a disposable full-dependency reinstall is not evidenced unless that dedicated acceptance command passes.",
    "mlops_runtime": "The local demo uses the in-process model registry and PSI drift service; MLflow, Evidently and Airflow runtime are optional production integrations.",
    "quality_and_security_toolchain": "The local demo includes first-party smoke checks; Ruff, Bandit and pip-audit must run in the dedicated hosted/toolchain job before production release.",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def build_report(verification: dict[str, Any], reviewed_by: str) -> dict[str, Any]:
    checks = verification.get("checks")
    if not isinstance(checks, list):
        raise ValueError("Production verification report has no checks list")
    indexed = {str(c.get("name")): c for c in checks if isinstance(c, dict)}
    missing = sorted(LOCAL_REQUIRED - indexed.keys())
    if missing:
        raise ValueError(f"Local demo evidence is missing checks: {', '.join(missing)}")
    local = [{"name": name, "status": indexed[name].get("status"),
              "evidence_file": indexed[name].get("evidence_file"),
              "scope_note": "Local executable acceptance only"}
             for name in sorted(LOCAL_REQUIRED)]
    failed = [x["name"] for x in local if x["status"] != "PASS"]
    excluded = [{"name": name, "status": "NOT_IN_SCOPE_LOCAL_DEMO", "reason": reason}
                for name, reason in sorted(PRODUCTION_ONLY.items())]
    return {
        "schema_version": 1,
        "profile": "local_demo",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "reviewed_by": reviewed_by,
        "source_verification_generated_at": verification.get("generated_at"),
        "source_tree_sha256": source_tree_sha256(ROOT),
        "local_scope": {
            "status": "PASS" if not failed else "BLOCKED",
            "passed": sum(x["status"] == "PASS" for x in local),
            "failed_or_blocked": len(failed),
            "total": len(local),
            "checks": local,
            "unpassed_checks": failed,
        },
        "production_only_gates": {
            "status": "NOT_ACCEPTED",
            "excluded_from_local_demo_count": len(excluded),
            "checks": excluded,
        },
        "important_boundary": (
            "A PASS applies only to the declared local-demo profile. Production readiness, real-company model quality,"
            " live CRM delivery, hosted deployment, external business approval and independent security testing are not certified."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a local-demo acceptance report from the fresh production verification report")
    parser.add_argument("--reviewed-by", required=True)
    args = parser.parse_args()
    reviewer = args.reviewed_by.strip()
    if not reviewer:
        parser.error("--reviewed-by cannot be blank")
    source = REPORTS / "verification.json"
    if not source.is_file():
        parser.error("reports/verification.json is missing; run all verification stages and --stage report first")
    verification = json.loads(source.read_text(encoding="utf-8"))
    report = build_report(verification, reviewer)
    report["source_verification_sha256"] = sha256(source)
    REPORTS.mkdir(parents=True, exist_ok=True)
    output = REPORTS / "local_demo_acceptance.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "profile": report["profile"],
        "local_scope": report["local_scope"]["status"],
        "local_checks_passed": report["local_scope"]["passed"],
        "local_checks_total": report["local_scope"]["total"],
        "production_only_gates_not_accepted": report["production_only_gates"]["excluded_from_local_demo_count"],
        "report": str(output.relative_to(ROOT)),
    }, indent=2))
    return 0 if report["local_scope"]["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
