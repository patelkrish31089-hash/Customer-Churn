from __future__ import annotations

import json
import os
import uuid
from sqlalchemy import inspect, text

from app.db import SessionLocal, engine
from app.models import BackgroundJob
from app.services.jobs import enqueue_job
from app.worker import process_one_job


def main() -> int:
    tables = set(inspect(engine).get_table_names())
    if "background_jobs" not in tables:
        print(json.dumps({"status": "failed", "reason": "background_jobs_table_missing"}))
        return 1
    with engine.connect() as connection:
        migration_head = connection.execute(text("select version_num from alembic_version")).scalar_one_or_none()
    key = "worker-smoke-" + uuid.uuid4().hex
    db = SessionLocal()
    try:
        job, reused = enqueue_job(db, "quality_audit", {"scope": "all"}, key, None)
        if reused:
            raise AssertionError("Unexpected idempotency reuse for a fresh smoke key")
        job_id = job.id
    finally:
        db.close()

    worker_id = "acceptance-worker-" + uuid.uuid4().hex[:8]
    result = process_one_job(SessionLocal, worker_id=worker_id, lease_seconds=120)
    if result is None or result.get("job_id") != job_id or result.get("status") != "succeeded":
        raise AssertionError(f"Worker did not successfully execute the queued job: {result}")

    verify = SessionLocal()
    try:
        saved = verify.get(BackgroundJob, job_id)
        if saved is None or saved.status != "succeeded" or saved.progress_pct != 100:
            raise AssertionError("Job completion was not durably persisted")
        if saved.attempts != 1 or saved.locked_by is not None or saved.locked_until is not None:
            raise AssertionError("Worker lease/attempt accounting is inconsistent")
        evidence = {
            "status": "passed",
            "database_dialect": engine.dialect.name,
            "alembic_revision": migration_head,
            "job_id": job_id,
            "job_type": saved.job_type,
            "attempts": saved.attempts,
            "result": json.loads(saved.result_json or "{}"),
            "checks": {
                "queue_table_migrated": True,
                "enqueue_persisted": True,
                "worker_claimed_job": True,
                "quality_audit_handler_executed": True,
                "result_persisted": True,
                "lease_released": True,
                "at_least_once_semantics_documented": True,
            },
            "evidence_boundary": "Runtime worker/database smoke only; production scale, multi-worker contention and crash recovery require deployment-specific load testing.",
        }
    finally:
        verify.close()

    output_dir = os.getenv("REPORTS_DIR", "reports")
    from pathlib import Path
    path = Path(output_dir) / "worker_queue_runtime_evidence.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(evidence, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
