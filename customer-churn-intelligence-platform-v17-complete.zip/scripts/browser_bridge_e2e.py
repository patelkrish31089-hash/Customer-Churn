from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def multipart_body(parts: list[dict]) -> tuple[bytes, str]:
    boundary = "----ChurnBridge" + uuid.uuid4().hex
    chunks: list[bytes] = []
    for item in parts:
        name = str(item.get("name", "field"))
        chunks.extend([f"--{boundary}\r\n".encode(),
                       f'Content-Disposition: form-data; name="{name}"'.encode()])
        if "filename" in item:
            filename = str(item.get("filename", "upload.bin")).replace('"', "")
            content_type = str(item.get("content_type", "application/octet-stream"))
            chunks.extend([f'; filename="{filename}"\r\n'.encode(),
                           f"Content-Type: {content_type}\r\n\r\n".encode(),
                           bytes(item.get("data", [])), b"\r\n"])
        else:
            chunks.extend([b"\r\n\r\n", str(item.get("value", "")).encode(), b"\r\n"])
    chunks.append(f"--{boundary}--\r\n".encode())
    return b"".join(chunks), f"multipart/form-data; boundary={boundary}"


def main() -> int:
    configured_browser_path = os.getenv("CHROMIUM_EXECUTABLE")
    if configured_browser_path and not Path(configured_browser_path).exists():
        print(json.dumps({"status": "blocked", "reason": "chromium_binary_missing", "path": configured_browser_path}))
        return 2

    with tempfile.TemporaryDirectory(prefix="churn-browser-bridge-") as temp:
        temp_path = Path(temp)
        env = os.environ.copy()
        env.update({"APP_ENV": "test", "DATABASE_URL": f"sqlite:///{temp_path / 'browser.sqlite'}",
                    "UPLOAD_DIR": str(temp_path / "uploads"), "ARTIFACT_DIR": str(temp_path / "artifacts"),
                    "LOG_LEVEL": "WARNING", "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"})
        subprocess.run([sys.executable, "-m", "app.cli", "init-db"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        subprocess.run([sys.executable, "-m", "app.cli", "create-admin", "--username", "browser-admin",
                        "--password", "browser-e2e-password-123"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        port = free_port()
        base = f"http://127.0.0.1:{port}"
        server = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                                   "--port", str(port), "--log-level", "warning"], cwd=ROOT, env=env,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

        bridge_log: list[dict] = []
        def bridge(payload: dict) -> dict:
            target = str(payload.get("url", ""))
            if not target.startswith("/api/v1/"):
                return {"status": 400, "content_type": "application/json", "body": '{"detail":"Invalid test bridge route"}'}
            method = str(payload.get("method", "GET")).upper()
            headers = {str(k): str(v) for k, v in (payload.get("headers") or {}).items()}
            body = payload.get("body")
            parts = payload.get("multipart")
            if parts is not None:
                body, content_type = multipart_body(parts)
                headers["Content-Type"] = content_type
            elif isinstance(body, str):
                body = body.encode("utf-8")
            else:
                body = None
            headers.setdefault("Accept", "application/json")
            req = urllib.request.Request(base + target, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=10) as response:
                    raw = response.read()
                    record = {"status": response.status,
                              "content_type": response.headers.get("Content-Type", "application/json"),
                              "body": raw.decode("utf-8", errors="replace")}
                    bridge_log.append({"url": target, "status": record["status"], "body": "[REDACTED]" if target.endswith("/auth/login") else record["body"][:1000]})
                    return record
            except urllib.error.HTTPError as exc:
                record = {"status": exc.code, "content_type": exc.headers.get("Content-Type", "application/json"),
                          "body": exc.read().decode("utf-8", errors="replace")}
                bridge_log.append({"url": target, "status": record["status"], "body": "[REDACTED]" if target.endswith("/auth/login") else record["body"][:1000]})
                return record

        try:
            deadline = time.time() + 20
            while time.time() < deadline:
                if server.poll() is not None:
                    raise RuntimeError("Uvicorn exited before browser bridge startup")
                try:
                    with urllib.request.urlopen(base + "/api/v1/health/ready", timeout=1) as response:
                        if response.status == 200:
                            break
                except Exception:
                    time.sleep(.2)
            else:
                raise RuntimeError("Local API did not become ready")

            html = (ROOT / "app/static/index.html").read_text(encoding="utf-8")
            html = html.replace('<link rel="stylesheet" href="/static/styles.css">', "")
            html = html.replace('<script src="/static/app.js" defer></script>', "")
            css = (ROOT / "app/static/styles.css").read_text(encoding="utf-8")
            js = (ROOT / "app/static/app.js").read_text(encoding="utf-8")
            html = html.replace("</head>", f"<style>{css}</style></head>")

            errors: list[str] = []
            pages: list[str] = []
            a11y_results: list[dict] = []
            bridge_calls = 0
            with sync_playwright() as playwright:
                browser_path = configured_browser_path or ("/usr/bin/chromium" if Path("/usr/bin/chromium").exists() else playwright.chromium.executable_path)
                if not Path(browser_path).exists():
                    print(json.dumps({"status": "blocked", "reason": "chromium_binary_missing", "path": browser_path}))
                    return 2
                browser = playwright.chromium.launch(executable_path=browser_path, headless=True,
                    args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--no-proxy-server"])
                page = browser.new_page(viewport={"width": 1440, "height": 1000})
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.on("console", lambda msg: errors.append(f"console.{msg.type}: {msg.text}") if msg.type == "error" else None)
                page.expose_function("__churnHostFetch", bridge)
                page.set_content(html, wait_until="domcontentloaded")
                page.add_script_tag(content="""
                  (() => {
                    window.fetch = async (input, init={}) => {
                      const url = typeof input === 'string' ? input : input.url;
                      let multipart = null, body = init.body ?? null;
                      if (body instanceof FormData) {
                        multipart = [];
                        for (const [name, value] of body.entries()) {
                          if (value instanceof File) {
                            multipart.push({name, filename: value.name, content_type: value.type || 'application/octet-stream', data: Array.from(new Uint8Array(await value.arrayBuffer()))});
                          } else multipart.push({name, value: String(value)});
                        }
                        body = null;
                      }
                      const result = await window.__churnHostFetch({url, method: init.method || 'GET', headers: init.headers || {}, body, multipart});
                      const payload = result.status === 204 ? null : (result.body ?? '');
                      return new Response(payload, {status: result.status, headers: {'Content-Type': result.content_type || 'application/json'}});
                    };
                  })();
                """)
                page.add_script_tag(content=js)

                def scan_accessibility(view_name: str) -> dict:
                    result = page.evaluate(r"""() => {
                      const visible = el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
                      const controls = [...document.querySelectorAll('button,input,select,textarea,a')].filter(visible);
                      const nameOf = el => {
                        if (el.getAttribute('aria-label')?.trim()) return el.getAttribute('aria-label').trim();
                        const ids = (el.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean);
                        if (ids.some(id => document.getElementById(id)?.textContent.trim())) return ids.map(id => document.getElementById(id)?.textContent.trim() || '').join(' ').trim();
                        if (el.labels?.length) return [...el.labels].map(x => x.textContent.trim()).join(' ').trim();
                        if (el.closest('label')) return el.closest('label').textContent.trim();
                        return (el.innerText || el.value || el.getAttribute('title') || '').trim();
                      };
                      const unnamed = controls.filter(el => !nameOf(el)).map(el => ({tag:el.tagName,id:el.id,type:el.type||null}));
                      const imagesWithoutAlt = [...document.images].filter(img => !img.hasAttribute('alt')).length;
                      const landmarks = {main:document.querySelectorAll('main').length, nav:document.querySelectorAll('nav').length};
                      const headings = [...document.querySelectorAll('h1')].filter(visible).length;
                      return {controls:controls.length, unnamed_controls:unnamed, images_without_alt:imagesWithoutAlt, landmarks, visible_h1_count:headings};
                    }""")
                    result["view"] = view_name
                    a11y_results.append(result)
                    if result["unnamed_controls"] or result["images_without_alt"] or result["landmarks"]["main"] < 1 or result["landmarks"]["nav"] < 1:
                        errors.append("Accessibility smoke issues on " + view_name + ": " + json.dumps(result))
                    return result

                if not page.locator("#loginForm").is_visible():
                    raise AssertionError("Login form did not render in Chromium")
                pages.append("login")
                scan_accessibility("login")
                page.locator("#username").fill("browser-admin")
                page.locator("#password").fill("browser-e2e-password-123")
                page.locator('#loginForm button[type="submit"]').click()
                page.locator("#appView").wait_for(state="visible", timeout=10000)
                page.locator("#page-overview .stat-value").first.wait_for(state="visible", timeout=10000)
                pages.append("overview")
                scan_accessibility("overview")

                expected = {
                    "data": "Import customer data", "customers": "Customer directory",
                    "analytics": "Acquisition cohort retention heatmap", "models": "Model training",
                    "retention": "Retention worklist", "operations": "ML platform capabilities",
                    "jobs": "Submit background work", "reports": "Report library", "administration": "Create user",
                    "feature-store": "Feature contract v2.1",
                }
                for key, heading in expected.items():
                    page.locator(f'[data-page="{key}"]').click()
                    try:
                        page.get_by_text(heading, exact=True).first.wait_for(state="visible", timeout=10000)
                    except Exception:
                        print(json.dumps({"debug_page": key, "title": page.locator("#pageTitle").inner_text(),
                                          "notice": page.locator("#notice").inner_text(),
                                          "page_html": page.locator(f"#page-{key}").inner_text()[:1500],
                                          "errors": errors, "bridge_log": bridge_log}, indent=2))
                        raise
                    pages.append(key)
                    scan_accessibility(key)
                    if key == "models":
                        page.get_by_text("Training dataset readiness & leakage review", exact=True).wait_for(state="visible", timeout=10000)
                        audit_calls = [item for item in bridge_log if item.get("url", "").startswith("/api/v1/ml/dataset-audit")]
                        if not audit_calls or audit_calls[-1].get("status") != 200:
                            raise AssertionError("Training dataset readiness audit did not return HTTP 200")
                        pages.append("dataset-readiness-audit")
                    if key == "jobs":
                        page.locator("#jobForm").wait_for(state="visible")
                        page.locator('#jobForm button[type="submit"]').click()
                        # renderJobs() re-renders the form after enqueue; assert the
                        # persisted queue row, not the transient submit-message node.
                        cancel = page.locator("[data-job-cancel]").first
                        try:
                            cancel.wait_for(state="visible", timeout=10000)
                        except Exception:
                            print(json.dumps({"debug_job_submit": page.locator("#jobSubmitResult").inner_text(),
                                              "debug_notice": page.locator("#notice").inner_text(),
                                              "debug_job_page": page.locator("#page-jobs").inner_text()[:2000],
                                              "errors": errors, "bridge_log": bridge_log[-12:]}, indent=2))
                            raise
                        cancel.click()
                        page.get_by_text("Queued job cancelled.", exact=False).wait_for(state="visible", timeout=10000)
                        pages.append("background-job-enqueue-and-cancel")

                page.locator('[data-page="reports"]').click()
                page.locator('[data-export-report="overview"][data-export-format="json"]').click()
                page.get_by_text("overview report downloaded.", exact=False).wait_for(state="visible", timeout=10000)
                pages.append("report-export")
                scan_accessibility("reports")

                page.locator('[data-page="administration"]').click()
                page.locator("#adminCreateUser").wait_for(state="visible")
                page.locator("#adminNewUsername").fill("browser-analyst")
                page.locator("#adminNewPassword").fill("browser-analyst-password-456")
                page.locator("#adminNewRole").select_option("analyst")
                page.locator('#adminCreateUser button[type="submit"]').click()
                page.get_by_text("Created browser-analyst", exact=False).wait_for(state="visible", timeout=10000)
                page.get_by_text("browser-analyst", exact=True).wait_for(state="visible", timeout=10000)
                pages.append("admin-user-create-audit")
                scan_accessibility("administration")

                page.locator('[data-page="data"]').click()
                page.locator("#uploadForm").wait_for(state="visible")
                customer_csv = temp_path / "browser-customer.csv"
                customer_csv.write_text("customer_id,name,email\nBROWSER-E2E-1,Browser E2E Customer,browser@example.invalid\n", encoding="utf-8")
                page.locator("#datasetType").select_option("customers")
                page.locator("#importFile").set_input_files(str(customer_csv))
                page.locator('#uploadForm button[type="submit"]').click()
                page.get_by_text("Import completed.", exact=False).wait_for(state="visible", timeout=10000)
                pages.append("import-upload")
                scan_accessibility("data_after_upload")

                # Exercise the large-file path: upload is staged with a checksum,
                # a durable job is shown in the UI, and the pending job can be cancelled.
                queued_csv = temp_path / "browser-customer-queued.csv"
                queued_csv.write_text("customer_id,name\nBROWSER-QUEUE-1,Queued Import Customer\n", encoding="utf-8")
                page.locator("#importFile").set_input_files(str(queued_csv))
                page.locator("#queueUploadBtn").click()
                page.locator("[data-page='jobs']").wait_for(state="visible")
                queued_cancel = page.locator("[data-job-cancel]").first
                queued_cancel.wait_for(state="visible", timeout=10000)
                queued_cancel.click()
                page.get_by_text("Queued job cancelled.", exact=False).wait_for(state="visible", timeout=10000)
                pages.append("async-import-enqueue-and-cancel")
                scan_accessibility("jobs_after_async_import")
                page.locator('[data-page="customers"]').click()
                page.get_by_text("Browser E2E Customer", exact=False).wait_for(state="visible", timeout=10000)
                pages.append("customer-readback")

                page.locator('[data-open-customer]').first.click()
                page.get_by_text("CUSTOMER 360", exact=True).wait_for(state="visible", timeout=10000)
                page.get_by_text("Unified customer timeline", exact=False).wait_for(state="visible", timeout=10000)
                pages.append("customer-360")
                scan_accessibility("customer_360")
                accessibility = {
                    "status": "passed" if not any(x["unnamed_controls"] or x["images_without_alt"] for x in a11y_results) else "failed",
                    "scanned_views": a11y_results,
                    "total_visible_controls": sum(x["controls"] for x in a11y_results),
                    "unnamed_controls": [c for x in a11y_results for c in x["unnamed_controls"]],
                    "images_without_alt": sum(x["images_without_alt"] for x in a11y_results),
                    "scope": "semantic smoke for accessible names, image alternatives and landmarks; not a full WCAG audit",
                }
                if accessibility["status"] != "passed":
                    errors.append("Accessibility smoke issues: " + json.dumps(accessibility))

                # Logout and verify that the UI returns to the login screen.
                page.locator("#logoutBtn").click()
                page.locator("#loginView").wait_for(state="visible", timeout=5000)
                pages.append("logout")
                browser.close()

            result = {
                "status": "passed" if not errors else "failed",
                "browser": "Chromium",
                "mode": "in-memory document plus host-side API transport bridge",
                "native_browser_navigation": "not tested; host managed URL policy blocks localhost navigation",
                "pages_and_flows": pages,
                "api_transport": "real FastAPI process; HTTP requests made by Python bridge, not browser fetch/CORS",
                "accessibility_smoke": accessibility,
                "axe_core": "not installed; this is a limited semantic accessibility smoke, not a WCAG audit",
                "console_or_page_errors": errors,
                "server_shutdown": "graceful",
            }
            print(json.dumps(result, indent=2))
            return 0 if not errors else 1
        finally:
            server.terminate()
            try:
                server.wait(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait(timeout=5)
            if server.stdout:
                server.stdout.close()


if __name__ == "__main__":
    raise SystemExit(main())
