from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.db import Base
from app.demo import seed_demo
from app.models import User, Customer, ModelRelease, Subscription
from app.security import hash_password
from app.services.ml import train_models, approve_release, predict_customer
from app.services.retention import generate_recommendations, review_recommendation, execute_sandbox_action


def main() -> int:
    db_url = os.environ["DATABASE_URL"]
    engine = create_engine(db_url, connect_args={"check_same_thread":False} if db_url.startswith("sqlite") else {})
    Base.metadata.create_all(engine)
    Factory = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    db = Factory()
    try:
        seeded = seed_demo(db, int(os.getenv("DEMO_CUSTOMERS", "120")), int(os.getenv("DEMO_SEED", "31")))
        trained = train_models(db)
        admin = User(username="verification-admin", password_hash=hash_password("verification-admin-strong-password"), role="admin")
        db.add(admin); db.commit()
        release = approve_release(db, trained["release_id"], admin.id)
        # Score each customer at the same historical cutoff used by its synthetic label
        # and feature snapshot. This keeps the smoke workflow distribution-aligned.
        scored = []
        for customer in db.query(Customer).order_by(Customer.id).all():
            subscription = db.query(Subscription).filter_by(customer_id=customer.id).order_by(Subscription.id).first()
            start_at = subscription.start_date
            if start_at.tzinfo is None:
                start_at = start_at.replace(tzinfo=timezone.utc)
            cutoff = start_at + timedelta(days=60)
            scored.append(predict_customer(db, customer.id, cutoff, include_explanation=False))
        prediction = max(scored, key=lambda item: item["probability"])
        retention = generate_recommendations(db)
        from app.models import RetentionRecommendation
        from app.models import Customer as CustomerModel
        eligible_rec = None
        for rec in db.query(RetentionRecommendation).filter_by(status="pending_approval").all():
            if db.get(CustomerModel, rec.customer_id).consent_to_contact:
                eligible_rec = rec
                break
        sandbox_action = None
        if eligible_rec:
            review_recommendation(db, eligible_rec.id, "approved", admin.id)
            sandbox_action = execute_sandbox_action(db, eligible_rec.id, f"verify-sandbox-{eligible_rec.id}-key")
        output = {"synthetic_seed":seeded,"training":{"run_id":trained["run_id"],"release_id":trained["release_id"],
                  "algorithm":trained["algorithm"],"status":trained["status"],"metrics":trained["metrics"]},
                  "approval":{"release_id":release.release_id,"status":release.status},
                  "prediction":{"scored_customers":len(scored),"highest_risk_example":prediction},
                  "retention_generation":retention,"sandbox_action":sandbox_action,
                  "evidence_boundary":"Synthetic demo only. No real-company performance claim. Sandbox task is simulated; no external CRM was called."}
        print(json.dumps(output, indent=2, default=str))
        return 0
    finally:
        db.close(); engine.dispose()

if __name__ == "__main__":
    raise SystemExit(main())
