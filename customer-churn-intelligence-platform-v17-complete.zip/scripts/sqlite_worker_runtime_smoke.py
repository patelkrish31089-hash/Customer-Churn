from __future__ import annotations

"""Run a real isolated SQLite queue/worker integration smoke without changing project data."""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="churn-worker-smoke-") as temp:
        temp_path = Path(temp)
        reports = temp_path / "reports"
        env = os.environ.copy()
        env.update({
            "APP_ENV": "test",
            "DATABASE_URL": f"sqlite:///{temp_path / 'worker.sqlite'}",
            "UPLOAD_DIR": str(temp_path / "uploads"),
            "ARTIFACT_DIR": str(temp_path / "artifacts"),
            "REPORTS_DIR": str(reports),
            "OMP_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "PYTHONPATH": str(ROOT) + os.pathsep + os.environ.get("PYTHONPATH", ""),
        })
        init = subprocess.run(
            [sys.executable, "-m", "app.cli", "init-db"], cwd=ROOT, env=env,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45,
        )
        if init.returncode:
            raise RuntimeError(f"SQLite migration setup failed: {init.stdout[-3000:]}")
        smoke = subprocess.run(
            [sys.executable, "scripts/worker_queue_smoke.py"], cwd=ROOT, env=env,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45,
        )
        if smoke.returncode:
            raise RuntimeError(f"Worker queue runtime smoke failed: {smoke.stdout[-3000:]}")
        evidence_path = reports / "worker_queue_runtime_evidence.json"
        evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
        if evidence.get("status") != "passed" or evidence.get("database_dialect") != "sqlite":
            raise AssertionError("Expected a successful isolated SQLite worker queue run")
        output = {
            "status": "passed",
            "database_dialect": "sqlite",
            "alembic_revision": evidence.get("alembic_revision"),
            "job_type": evidence.get("job_type"),
            "checks": evidence.get("checks", {}),
            "job_result": evidence.get("result", {}),
            "evidence_boundary": (
                "Actual isolated SQLite queue/worker integration only. It does not prove PostgreSQL "
                "SKIP LOCKED behavior, Docker orchestration, multi-worker concurrency or production throughput."
            ),
        }
        print(json.dumps(output, indent=2))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
