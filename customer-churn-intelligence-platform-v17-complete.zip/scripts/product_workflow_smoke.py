from __future__ import annotations

import json
import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import create_engine, event  # noqa: E402
from sqlalchemy.orm import sessionmaker  # noqa: E402
from sqlalchemy.pool import StaticPool  # noqa: E402

from app.db import Base, get_db  # noqa: E402
import app.models  # noqa: F401,E402
from app.main import app  # noqa: E402
from app.models import (AuditEvent, BackgroundJob, Customer, DataQualityFinding,
                        DataQualityRun, FeatureSnapshot, User)  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.utils import json_dumps  # noqa: E402


def main() -> int:
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)

    @event.listens_for(engine, "connect")
    def enable_foreign_keys(connection, _record):
        connection.execute("PRAGMA foreign_keys=ON")

    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)

    def override_db():
        db = factory()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_db
    try:
        db = factory()
        admin = User(username="v17-product-admin", password_hash=hash_password("v17-product-admin-password"), role="admin")
        db.add(admin)
        db.flush()
        customer = Customer(external_id="V17-PRODUCT-CUSTOMER", name="Feature Store Smoke Customer",
                            segment="smb", consent_to_contact=False)
        db.add(customer)
        db.flush()
        cutoff = datetime.now(timezone.utc) - timedelta(days=1)
        snapshot = FeatureSnapshot(customer_id=customer.id, cutoff_date=cutoff, feature_version="2.1",
                                  features_json=json_dumps({"tenure_days": 80.0, "usage_events_30d": 9.0}),
                                  source_fingerprint="c" * 64)
        db.add(snapshot)
        run = DataQualityRun(run_id="v17-product-quality-run", scope="customer", records_scanned=1,
                              finding_count=2, quality_score=80.0, summary_json="{}")
        db.add(run)
        db.flush()
        findings = [DataQualityFinding(run_id=run.run_id, entity_type="customer", entity_id=customer.id,
                                       field_name="email", rule_code="customer_missing_email",
                                       severity="info", status="open", message="Missing optional email")
                    for _ in range(2)]
        db.add_all(findings)
        db.commit()
        customer_id = customer.id
        finding_ids = [row.id for row in findings]
        db.close()

        with TestClient(app) as client:
            login = client.post("/api/v1/auth/login", json={
                "username": "v17-product-admin", "password": "v17-product-admin-password"})
            assert login.status_code == 200, login.text
            headers = {"Authorization": f"Bearer {login.json()['access_token']}"}

            registry = client.get("/api/v1/feature-store/registry", headers=headers)
            assert registry.status_code == 200 and registry.json()["feature_count"] >= 30, registry.text
            summary = client.get("/api/v1/feature-store/summary", headers=headers)
            assert summary.status_code == 200 and summary.json()["snapshot_count"] == 1, summary.text
            online = client.get(f"/api/v1/feature-store/customers/{customer_id}/online",
                                params={"as_of": datetime.now(timezone.utc).isoformat()}, headers=headers)
            assert online.status_code == 200 and online.json()["features"]["usage_events_30d"] == 9.0, online.text
            history = client.get(f"/api/v1/feature-store/customers/{customer_id}/history", headers=headers)
            assert history.status_code == 200 and len(history.json()) == 1, history.text
            export = client.get("/api/v1/feature-store/export", headers=headers)
            assert export.status_code == 200 and "source_fingerprint" in export.text, export.text

            materialized = client.post("/api/v1/feature-store/materialize",
                                       headers={**headers, "Idempotency-Key": "v17-feature-smoke-job-001"},
                                       json={"cutoff_at": datetime.now(timezone.utc).isoformat(),
                                             "feature_version": "2.1", "customer_ids": [customer_id]})
            assert materialized.status_code == 202 and materialized.json()["job_type"] == "build_features", materialized.text

            reviewed = client.post("/api/v1/quality/findings/bulk-review", headers=headers,
                                   json={"finding_ids": finding_ids, "decision": "accepted_risk",
                                         "note": "Reviewed by isolated product smoke."})
            assert reviewed.status_code == 200 and reviewed.json()["reviewed_count"] == 2, reviewed.text

        verify_db = factory()
        jobs = verify_db.query(BackgroundJob).filter_by(idempotency_key="v17-feature-smoke-job-001").count()
        reviewed_rows = verify_db.query(DataQualityFinding).filter(
            DataQualityFinding.id.in_(finding_ids), DataQualityFinding.status == "accepted_risk").count()
        audits = verify_db.query(AuditEvent).filter_by(action="quality_finding_accepted_risk").count()
        verify_db.close()
        assert jobs == 1 and reviewed_rows == 2 and audits == 2
        print(json.dumps({
            "status": "passed",
            "scope": "isolated SQLite API integration for Feature Store and bulk data-quality review",
            "checks": {
                "feature_registry_matches_contract": True,
                "feature_coverage_api": True,
                "as_of_online_lookup": True,
                "customer_feature_history": True,
                "feature_csv_export": True,
                "feature_materialization_queued": True,
                "materialization_job_persisted": jobs == 1,
                "bulk_quality_review_completed": reviewed_rows == 2,
                "per_finding_audit_events_persisted": audits == 2,
            },
            "database_dialect": "sqlite",
            "evidence_boundary": "This is an actual local SQLite API/service integration. It does not prove PostgreSQL concurrency, production feature freshness, company source completeness or hosted deployment.",
        }, indent=2, default=str))
        return 0
    finally:
        app.dependency_overrides.clear()
        Base.metadata.drop_all(engine)
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
