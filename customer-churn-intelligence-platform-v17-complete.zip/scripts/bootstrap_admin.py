from __future__ import annotations

"""Create the first local administrator without putting a password in shell history."""

import getpass
import re
import sys
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import User
from app.security import hash_password


def create_admin(db: Session, username: str, password: str) -> User:
    username = username.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,80}", username):
        raise ValueError("Username must be 3-80 characters using letters, digits, dot, underscore, @ or hyphen")
    if db.query(User).filter_by(username=username).first():
        raise ValueError("That username already exists; use the existing account or choose another username")
    password_hash = hash_password(password)
    user = User(username=username, password_hash=password_hash, role="admin", is_active=True)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def main() -> int:
    print("Create your local Churn Intelligence administrator")
    username = input("Administrator username: ").strip()
    password = getpass.getpass("Password (minimum 12 characters): ")
    confirmation = getpass.getpass("Confirm password: ")
    if password != confirmation:
        print("Passwords do not match.", file=sys.stderr)
        return 2
    db = SessionLocal()
    try:
        user = create_admin(db, username, password)
        print(f"Administrator created: {user.username}")
        return 0
    except ValueError as exc:
        db.rollback()
        print(str(exc), file=sys.stderr)
        return 2
    finally:
        db.close()


if __name__ == "__main__":
    raise SystemExit(main())
