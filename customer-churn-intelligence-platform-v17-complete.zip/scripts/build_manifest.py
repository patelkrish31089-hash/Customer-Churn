from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_PARTS = {".git", ".venv", ".venv-v12", ".venv-v14", ".venv-v15", ".venv-v16", ".venv-v17", ".venv-local", "__pycache__", ".pytest_cache", ".ruff_cache", "node_modules"}
EXCLUDED_NAMES = {".env", "package_manifest.json", "package_verification.json"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".db", ".sqlite", ".sqlite3", ".log"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    files = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if relative.parts[:2] == ("data", "uploads") and path.name != ".gitkeep":
            continue
        if relative.parts[0] == "reports" and relative.parts[-1] in {"runtime_http_evidence.json", "performance_smoke.json"}:
            # Kept as evidence; this branch intentionally does not exclude them.
            pass
        files.append({"path": relative.as_posix(), "size_bytes": path.stat().st_size, "sha256": sha256(path)})

    report_path = ROOT / "reports" / "verification.json"
    verification = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
    payload = {
        "package": "Customer Churn Prediction & Retention Intelligence",
        "release": "v17 governed feature store, bulk data-quality review, and async product workflows",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "file_count": len(files),
        "verification_summary": verification.get("summary", {}),
        "manifest_note": "This manifest and the package verification report are excluded to avoid recursive hashing. SHA-256 is per included project/evidence file.",
        "files": files,
    }
    out = ROOT / "reports" / "package_manifest.json"
    out.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"manifest": str(out.relative_to(ROOT)), "file_count": len(files),
                      "verification_summary": payload["verification_summary"]}, indent=2))


if __name__ == "__main__":
    main()
