from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)
BASE_ENV = {"APP_ENV": "test", "DATABASE_URL": "sqlite:///:memory:",
            "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1"}


def run_check(name: str, command: list[str], env: dict[str, str] | None = None,
              timeout_seconds: int = 120, blocked_exit_codes: set[int] | None = None) -> dict:
    started = time.time()
    merged = os.environ.copy()
    merged.update(BASE_ENV)
    if env:
        merged.update(env)
    print(f"RUN  {name}", flush=True)
    with tempfile.TemporaryFile(mode="w+b") as output_file:
        proc = subprocess.Popen(command, cwd=ROOT, env=merged, text=False,
                                stdout=output_file, stderr=subprocess.STDOUT,
                                start_new_session=True)
        try:
            exit_code = proc.wait(timeout=timeout_seconds)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            proc.wait(timeout=10)
            exit_code = None
        output_file.seek(0)
        output_text = output_file.read().decode("utf-8", errors="replace")[-16000:]
    blocked = blocked_exit_codes or set()
    status = ("PASS" if exit_code == 0 else
              "BLOCKED" if exit_code is None or exit_code in blocked else "FAIL")
    result = {"name": name, "command": " ".join(command), "status": status,
              "exit_code": exit_code, "duration_seconds": round(time.time() - started, 3),
              "output": output_text}
    if name == "host_environment_pip_check" and exit_code:
        result["note"] = "Shared interpreter conflict: moviepy 2.2.1 requires Pillow<12 while Pillow 12.3.0 is installed; moviepy is not a project dependency."
    print(f"{status} {name} ({result['duration_seconds']}s)", flush=True)
    return result


def parse_output(check: dict) -> dict | None:
    try:
        return json.loads(check.get("output", ""))
    except (json.JSONDecodeError, TypeError):
        return None


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str) + "\n", encoding="utf-8")


def secret_pattern_check() -> dict:
    suspicious = []
    patterns = [re.compile(r"(?i)(password|secret|api[_-]?key)\s*=\s*['\"][^'\"]{12,}['\"]")]
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in {".git", ".venv", "__pycache__", ".pytest_cache"} for part in path.parts):
            continue
        if path.suffix in {".py", ".yml", ".yaml", ".toml", ".ini", ".env"} and path.name != ".env.example":
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if any(pattern.search(content) for pattern in patterns):
                suspicious.append(str(path.relative_to(ROOT)))
    return {"name": "static_secret_pattern_scan", "command": "verify.py pattern scan",
            "status": "PASS" if not suspicious else "FAIL", "exit_code": 0 if not suspicious else 1,
            "output": {"matches": suspicious},
            "limitation": "Pattern-based scan only; not a full secrets scanner or independent security assessment."}


def save_stage(name: str, checks: list[dict], extra: dict | None = None) -> int:
    result = {"stage": name, "generated_at": datetime.now(timezone.utc).isoformat(),
              "checks": checks, "summary": {"passed": sum(x["status"] == "PASS" for x in checks),
              "failed": sum(x["status"] == "FAIL" for x in checks),
              "blocked": sum(x["status"] == "BLOCKED" for x in checks),
              "not_applicable": sum(x["status"] == "NOT_APPLICABLE" for x in checks),
              "total": len(checks)}}
    if extra:
        result.update(extra)
    write_json(REPORTS / f"verification_{name}.json", result)
    print(json.dumps(result["summary"], indent=2))
    return 1 if result["summary"]["failed"] else 0



def host_environment_diagnostic() -> dict:
    """Do not treat the shared agent interpreter as the project's dependency environment."""
    return {
        "name": "host_environment_pip_check",
        "command": "not run: shared interpreter is not an isolated project environment",
        "status": "NOT_APPLICABLE",
        "exit_code": None,
        "duration_seconds": 0,
        "output": "Dependency compatibility must be established by the clean virtual-environment acceptance gate, not by unrelated packages preinstalled in the shared runner.",
        "note": "Excluded from application acceptance totals. The clean-install production gate remains blocked until package-index access and an isolated install are available.",
    }


def project_tool_inventory() -> dict:
    """Diagnostic inventory; missing integrations are counted once by their acceptance gate."""
    modules = ("mlflow", "airflow", "evidently", "pip_audit", "playwright", "shap", "ruff",
               "xgboost", "lightgbm", "openpyxl", "psycopg", "yaml", "bandit")
    optional = {name: ("installed" if importlib.util.find_spec(name) else "not_installed") for name in modules}
    optional["docker_cli"] = "installed" if shutil.which("docker") else "not_installed"
    optional["postgres_server_tools"] = ("installed" if all(shutil.which(x) for x in ("postgres", "initdb", "pg_ctl"))
                                           else "not_installed")
    return optional

def unavailable_tool_groups(optional: dict[str, str]) -> dict[str, list[str]]:
    """Group package/tool absences under one functional acceptance gate each."""
    unavailable: dict[str, list[str]] = {}
    for tool in ("mlflow", "airflow", "evidently"):
        if optional.get(tool) == "not_installed":
            unavailable.setdefault("mlops_runtime", []).append(tool)
    for tool in ("psycopg", "postgres_server_tools"):
        if optional.get(tool) == "not_installed":
            unavailable.setdefault("postgresql_runtime", []).append(tool)
    if optional.get("docker_cli") == "not_installed":
        unavailable.setdefault("docker_runtime", []).append("docker_cli")
    for tool in ("pip_audit", "bandit", "ruff"):
        if optional.get(tool) == "not_installed":
            unavailable.setdefault("quality_and_security_toolchain", []).append(tool)
    return unavailable


def stage_core() -> int:
    checks = [run_check("python_compile", [sys.executable, "-m", "compileall", "-q", "app", "tests", "scripts"]),
              run_check("application_import", [sys.executable, "-c", "from app.main import app; print(app.title)"]),
              run_check("frontend_javascript_syntax", [shutil.which("node") or "node", "--check", "app/static/app.js"])
              if shutil.which("node") else {"name": "frontend_javascript_syntax", "status": "BLOCKED", "exit_code": None, "output": "Node.js not installed"}]
    # Execute pytest in-process. The test suite has its own subprocess/browser
    # fixtures; nesting it in another Popen intermittently leaves a runner child
    # alive after the JUnit report is complete on some CI hosts.
    import pytest
    pytest_command = ["-q", "-W", "error", "--junitxml=reports/junit-v17.xml"]
    started = time.time()
    try:
        pytest_exit = int(pytest.main(pytest_command))
        pytest_status = "PASS" if pytest_exit == 0 else "FAIL"
        pytest_output = "Strict pytest suite completed in-process; JUnit evidence: reports/junit-v17.xml."
    except Exception as exc:
        pytest_exit = 1
        pytest_status = "FAIL"
        pytest_output = f"Strict pytest runner raised {type(exc).__name__}: {exc}"
    checks.append({"name": "pytest_regression_warnings_as_errors", "command": "python -m pytest " + " ".join(pytest_command),
                   "status": pytest_status, "exit_code": pytest_exit,
                   "duration_seconds": round(time.time() - started, 3), "output": pytest_output,
                   "evidence_file": "reports/junit-v17.xml" if pytest_exit == 0 else None})
    checks.extend([secret_pattern_check(),
                   run_check("first_party_ast_security_smoke", [sys.executable, "scripts/source_security_smoke.py"], timeout_seconds=30),
                   host_environment_diagnostic()])
    for check, filename in ((checks[-2], "source_security_smoke.json"),):
        payload = parse_output(check)
        if payload is not None and check["status"] == "PASS":
            write_json(REPORTS / filename, payload)
            check["evidence_file"] = f"reports/{filename}"
    return save_stage("core", checks, {"test_command": "python -m pytest -q -W error --junitxml=reports/junit-v17.xml"})


def stage_runtime() -> int:
    checks = [run_check("runtime_http_startup_auth_shutdown", [sys.executable, "scripts/runtime_http_smoke.py"], timeout_seconds=50),
              run_check("http_concurrency_smoke", [sys.executable, "scripts/http_load_smoke.py"], timeout_seconds=60),
              run_check("sqlite_background_worker_queue_end_to_end", [sys.executable, "scripts/sqlite_worker_runtime_smoke.py"], timeout_seconds=60)]
    for check, filename in zip(checks, ("runtime_http_evidence.json", "performance_smoke.json", "sqlite_worker_queue_evidence.json")):
        payload = parse_output(check)
        if payload is not None and check["status"] == "PASS":
            write_json(REPORTS / filename, payload)
            check["evidence_file"] = f"reports/{filename}"
    return save_stage("runtime", checks)


def stage_migrations() -> int:
    checks = [run_check("sqlite_migration_upgrade_downgrade_reupgrade",
                        [sys.executable, "scripts/migration_lifecycle_smoke.py"], timeout_seconds=60),
              run_check("postgresql_offline_migration_compile",
                        [sys.executable, "scripts/postgres_migration_compile.py"], timeout_seconds=60),
              run_check("deployment_compose_static_validation",
                        [sys.executable, "scripts/deployment_config_check.py"], timeout_seconds=30, blocked_exit_codes={2}),
              run_check("ci_workflow_acceptance_contract",
                        [sys.executable, "scripts/ci_workflow_check.py"], timeout_seconds=30)]
    checks[0]["evidence_file"] = "reports/migration_lifecycle_evidence.json" if checks[0]["status"] == "PASS" else None
    checks[1]["evidence_file"] = "reports/postgresql_offline_migration_evidence.json" if checks[1]["status"] == "PASS" else None
    payload = parse_output(checks[2])
    if payload is not None and checks[2]["status"] == "PASS":
        write_json(REPORTS / "deployment_compose_check.json", payload)
        checks[2]["evidence_file"] = "reports/deployment_compose_check.json"
    checks[3]["evidence_file"] = "reports/ci_workflow_contract_evidence.json" if checks[3]["status"] == "PASS" else None
    return save_stage("migrations", checks)


def stage_product() -> int:
    check = run_check("feature_store_and_quality_review_api_end_to_end",
                      [sys.executable, "scripts/product_workflow_smoke.py"], timeout_seconds=60)
    payload = parse_output(check)
    if check["status"] == "PASS" and payload is not None:
        if payload.get("status") != "passed" or not all(payload.get("checks", {}).values()):
            check["status"] = "FAIL"
            check["exit_code"] = 1
            check["output"] += "\nProduct workflow evidence missing required successful checks."
        else:
            write_json(REPORTS / "feature_store_quality_evidence.json", payload)
            check["evidence_file"] = "reports/feature_store_quality_evidence.json"
    return save_stage("product", [check])


def stage_synthetic() -> int:
    # Run the deterministic synthetic end-to-end scenario in-process so the
    # verifier can always close its temporary SQLite engine before returning.
    import contextlib
    import io
    import os
    from tempfile import TemporaryDirectory
    from scripts.smoke_demo import main as synthetic_demo_main

    check = {"name": "synthetic_end_to_end_training_prediction_retention", "command": "scripts.smoke_demo.main() in isolated temporary SQLite database"}
    started = time.time()
    keys = ("DATABASE_URL", "ARTIFACT_DIR", "UPLOAD_DIR", "DEMO_CUSTOMERS", "DEMO_SEED", "APP_ENV")
    prior = {key: os.environ.get(key) for key in keys}
    try:
        with TemporaryDirectory(prefix="churn-verify-demo-") as temp:
            temp_path = Path(temp)
            (temp_path / "artifacts").mkdir()
            (temp_path / "uploads").mkdir()
            os.environ.update({"APP_ENV": "test", "DATABASE_URL": f"sqlite:///{temp_path / 'demo.sqlite'}",
                               "ARTIFACT_DIR": str(temp_path / "artifacts"), "UPLOAD_DIR": str(temp_path / "uploads"),
                               "DEMO_CUSTOMERS": "120", "DEMO_SEED": "31"})
            captured = io.StringIO()
            with contextlib.redirect_stdout(captured):
                exit_code = synthetic_demo_main()
            payload = json.loads(captured.getvalue())
        if exit_code != 0 or not payload.get("synthetic_seed", {}).get("not_real_company_data") or \
                "No real-company" not in payload.get("evidence_boundary", ""):
            check.update({"status": "FAIL", "exit_code": 1, "output": "Synthetic workflow did not satisfy its declared evidence boundary."})
        else:
            write_json(REPORTS / "synthetic_workflow_evidence.json", payload)
            check.update({"status": "PASS", "exit_code": 0, "evidence_file": "reports/synthetic_workflow_evidence.json",
                          "output": "Synthetic seed, model train/approve, batch score and retention workflow completed; data is explicitly synthetic."})
    except Exception as exc:
        check.update({"status": "FAIL", "exit_code": 1, "output": f"{type(exc).__name__}: {exc}"})
    finally:
        for key, value in prior.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
    check["duration_seconds"] = round(time.time() - started, 3)
    return save_stage("synthetic", [check])


def stage_browser() -> int:
    # Chromium navigation is restricted by this host's managed URL policy. The
    # bridge harness still runs the real dashboard JavaScript in Chromium and
    # sends its API requests to a real local FastAPI process from the host test
    # runner. It explicitly does not claim browser-native CORS/navigation coverage.
    check = run_check("browser_chromium_ui_api_bridge", [sys.executable, "scripts/browser_bridge_e2e.py"],
                      timeout_seconds=60, blocked_exit_codes={2})
    payload = parse_output(check)
    if payload is not None and check["status"] == "PASS":
        if payload.get("status") != "passed" or not payload.get("pages_and_flows"):
            check["status"] = "FAIL"
            check["exit_code"] = 1
        write_json(REPORTS / "browser_bridge_e2e_evidence.json", payload)
        check["evidence_file"] = "reports/browser_bridge_e2e_evidence.json"
        check["limitation"] = payload.get("native_browser_navigation")
        check["accessibility_scope"] = payload.get("accessibility_smoke", {}).get("scope")
    return save_stage("browser", [check])

def load_hosted_gate_closure() -> dict:
    """Load only a schema-checked, reviewer-attributed hosted artifact review."""
    path = REPORTS / "hosted_gate_closure.json"
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict) or payload.get("schema_version") != 1:
        return {}
    if payload.get("workflow") != "full-platform-acceptance":
        return {}
    if not payload.get("run_id") or not str(payload.get("run_attempt", "")).isdigit():
        return {}
    if not str(payload.get("repository", "")).strip():
        return {}
    if not re.fullmatch(r"[0-9a-fA-F]{40}", str(payload.get("commit_sha", ""))):
        return {}
    if not str(payload.get("reviewed_by", "")).strip():
        return {}
    checks = payload.get("checks")
    if not isinstance(checks, dict):
        return {}
    return payload


def load_local_gate_closure() -> dict:
    """Load self-reviewed local technical evidence only for the exact current source tree."""
    path = REPORTS / "local_gate_closure.json"
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        from scripts.merge_local_evidence import LOCAL_EVIDENCE, source_tree_sha256, validate_local_gate
        current_digest = source_tree_sha256(ROOT)
    except (OSError, json.JSONDecodeError, RuntimeError, ImportError):
        return {}
    if not isinstance(payload, dict) or payload.get("schema_version") != 1:
        return {}
    if payload.get("evidence_type") != "reviewed_local_acceptance":
        return {}
    if not str(payload.get("reviewed_by", "")).strip():
        return {}
    if payload.get("source_tree_sha256") != current_digest:
        return {}
    checks = payload.get("checks")
    if not isinstance(checks, dict) or set(checks) != set(LOCAL_EVIDENCE):
        return {}
    # Re-validate every underlying report and file digest when loading the closure.
    # This prevents a stale PASS from surviving if evidence is deleted or edited.
    for name, required_files in LOCAL_EVIDENCE.items():
        recorded = checks.get(name)
        if not isinstance(recorded, dict) or recorded.get("status") not in {"PASS", "BLOCKED"}:
            return {}
        current = validate_local_gate(name, REPORTS)
        if current.get("status") != recorded.get("status"):
            return {}
        recorded_evidence = recorded.get("evidence")
        current_evidence = current.get("evidence")
        if not isinstance(recorded_evidence, list) or recorded_evidence != current_evidence:
            return {}
        if recorded.get("required_evidence") != [filename for filename, _ in required_files]:
            return {}
        expected_files = {filename for filename, _ in required_files}
        observed_files = {item.get("file") for item in recorded_evidence if isinstance(item, dict)}
        if observed_files != expected_files:
            return {}
    return payload


def stage_report() -> int:
    checks: list[dict] = []
    diagnostics: list[dict] = []
    missing = []
    for stage in ("core", "runtime", "migrations", "product", "synthetic", "browser"):
        path = REPORTS / f"verification_{stage}.json"
        if path.exists():
            payload = json.loads(path.read_text(encoding="utf-8"))
            for item in payload.get("checks", []):
                if item.get("name") == "host_environment_pip_check":
                    diagnostics.append(item)
                elif item.get("name") == "browser_chromium_ui_api_bridge":
                    item = {**item, "name": "browser_e2e_and_semantic_accessibility_smoke",
                            "acceptance_scope": "Chromium login, navigation, upload, customer read-back, Customer 360 and semantic accessibility smoke with a host-side API bridge",
                            "limitations": ["Native browser HTTP/CORS navigation is not tested because of the host URL policy.",
                                            "axe-core/full WCAG audit is not available in this workspace; this run checks accessible names, image alternatives and landmarks."]}
                    checks.append(item)
                else:
                    checks.append(item)
        else:
            missing.append(stage)
            checks.append({"name": f"stage_{stage}", "command": f"python scripts/verify.py --stage {stage}",
                           "status": "BLOCKED", "exit_code": None, "output": "Stage was not executed in this workspace."})

    optional = project_tool_inventory()
    from scripts.environment_gate_inventory import collect as collect_environment_inventory
    host_inventory = collect_environment_inventory()
    write_json(REPORTS / "host_environment_inventory.json", host_inventory)
    # These are diagnostic capabilities, not separate acceptance checks. Their absence is
    # represented once by the corresponding functional gate below, avoiding double counting.
    unavailable = unavailable_tool_groups(optional)
    hosted_closure = load_hosted_gate_closure()
    hosted_checks = hosted_closure.get("checks", {}) if hosted_closure else {}
    local_closure = load_local_gate_closure()
    local_checks = local_closure.get("checks", {}) if local_closure else {}

    boundaries = {
        "live_crm_provider_sandbox": "No authorized CRM sandbox accounts, OAuth grants, scopes or webhook secrets were supplied.",
        "hosted_staging_deployment": "No hosting account, domain, TLS certificate or deployment authorization was supplied.",
        "real_company_model_validation": "No authorized company dataset with mature churn outcomes was supplied.",
        "independent_penetration_test": "An independent assessor and test authorization/evidence are required.",
        "business_churn_policy_signoff": "The company must approve cancellation, reactivation, pause, grace-period and censoring semantics.",
        "postgresql_runtime": "No PostgreSQL server/driver runtime is available; PostgreSQL offline DDL compilation passed. Missing tools: " + ", ".join(unavailable.get("postgresql_runtime", [])),
        "docker_runtime": "No Docker daemon/CLI is available; Compose static validation passed. Missing tools: " + ", ".join(unavailable.get("docker_runtime", [])),
        "clean_virtual_environment_install": "Package-index DNS/network access is unavailable, preventing a fresh dependency install in an isolated environment.",
        "mlops_runtime": "MLflow tracking, Airflow scheduling and Evidently runtime services are not installed/configured. Missing tools: " + ", ".join(unavailable.get("mlops_runtime", [])),
        "quality_and_security_toolchain": "Ruff, pip-audit and Bandit are not installed in this workspace; compile/tests and the limited secret-pattern scan are not substitutes for these tools. Missing tools: " + ", ".join(unavailable.get("quality_and_security_toolchain", [])),
    }
    for name, reason in boundaries.items():
        reviewed_gate = hosted_checks.get(name, {}) if isinstance(hosted_checks, dict) else {}
        local_gate = local_checks.get(name, {}) if isinstance(local_checks, dict) else {}
        if isinstance(reviewed_gate, dict) and reviewed_gate.get("status") == "PASS":
            checks.append({
                "name": name,
                "command": "reviewed GitHub Actions artifact evidence",
                "status": "PASS",
                "exit_code": 0,
                "output": (f"Validated hosted evidence for run {hosted_closure.get('run_id')} "
                           f"and commit {hosted_closure.get('commit_sha')}; reviewer: "
                           f"{hosted_closure.get('reviewed_by')}"),
                "evidence_file": "reports/hosted_gate_closure.json",
                "evidence_source": "hosted_ci",
            })
        elif isinstance(local_gate, dict) and local_gate.get("status") == "PASS":
            checks.append({
                "name": name,
                "command": "reviewed local acceptance evidence",
                "status": "PASS",
                "exit_code": 0,
                "output": (f"Validated local evidence against source tree SHA-256 "
                           f"{local_closure.get('source_tree_sha256')}; reviewer: "
                           f"{local_closure.get('reviewed_by')}. This is not a hosted CI attestation."),
                "evidence_file": "reports/local_gate_closure.json",
                "evidence_source": "reviewed_local",
            })
        else:
            checks.append({"name": name, "command": "environment or external acceptance requirement", "status": "BLOCKED",
                           "exit_code": None, "output": reason, "underlying_tool_inventory": unavailable.get(name, []),
                           "local_evidence_errors": (local_gate.get("errors", []) if isinstance(local_gate, dict) else [])})

    summary = {"passed": sum(x["status"] == "PASS" for x in checks),
               "failed": sum(x["status"] == "FAIL" for x in checks),
               "blocked": sum(x["status"] == "BLOCKED" for x in checks),
               "not_applicable_diagnostics": len(diagnostics),
               "total_acceptance_checks": len(checks)}
    result = {"generated_at": datetime.now(timezone.utc).isoformat(), "python": sys.version.split()[0],
              "evidence_stages_missing": missing, "tool_inventory": optional,
              "environment_diagnostics": diagnostics, "host_environment_inventory": host_inventory,
              "unavailable_tool_groups": unavailable, "hosted_gate_closure_review": ({
                  "run_id": hosted_closure.get("run_id"), "run_attempt": hosted_closure.get("run_attempt"),
                  "repository": hosted_closure.get("repository"), "commit_sha": hosted_closure.get("commit_sha"),
                  "reviewed_by": hosted_closure.get("reviewed_by"),
                  "technical_gates_passed": hosted_closure.get("technical_gates_passed"),
                  "technical_gates_total": hosted_closure.get("technical_gates_total"),
                  "status": hosted_closure.get("overall_status"),
              } if hosted_closure else None),
              "local_gate_closure_review": ({
                  "reviewed_by": local_closure.get("reviewed_by"),
                  "source_tree_sha256": local_closure.get("source_tree_sha256"),
                  "technical_gates_passed": local_closure.get("technical_gates_passed"),
                  "technical_gates_total": local_closure.get("technical_gates_total"),
                  "status": local_closure.get("overall_status"),
              } if local_closure else None), "checks": checks, "summary": summary,
              "release_boundary": {
                  "local_verification": "Executed by independent stages; see reports/verification_*.json.",
                  "production_readiness": "not approved",
                  "all_20_phases": "not fully accepted; see docs/ROADMAP_COVERAGE.md",
                  "counting_policy": "Unique acceptance gates only. Missing packages are reported inside the corresponding functional gate, not counted again as separate blockers.",
                  "local_evidence_policy": "Local technical gates can be closed only by a named reviewer, validated machine evidence and a source-tree digest match; local evidence is not represented as hosted CI evidence."}}
    write_json(REPORTS / "verification.json", result)
    lines = ["# Verification report", "", f"Generated: {result['generated_at']}", "",
             f"**Result: {summary['passed']} passed / {summary['failed']} failed / {summary['blocked']} blocked / "
             f"{summary['total_acceptance_checks']} unique acceptance checks.**",
             f"**Not-applicable environment diagnostics: {summary['not_applicable_diagnostics']}.**", "",
             "Blocker counts are deduplicated by acceptance gate. Missing tools appear once in the gate they affect; they are also listed in the tool inventory below.", "",
             "| Check | Status | Exit code | Duration |", "|---|---:|---:|---:|"]
    for check in checks:
        lines.append(f"| {check['name']} | {check['status']} | {check.get('exit_code', '—')} | {check.get('duration_seconds', '—')}s |")
    lines += ["", "## Environment diagnostics", ""]
    for item in diagnostics:
        lines.append(f"- **{item['name']} — {item['status']}:** {item.get('note', item.get('output', 'No additional detail.'))}")
    lines += ["", "## Tool inventory (informational; not additional blocker rows)", "", "| Tool | Availability |", "|---|---|"]
    for name, value in optional.items():
        lines.append(f"| {name} | {value} |")
    lines += ["", "## Host environment inventory", "",
              "A read-only capability inventory (including browser management policy and tool availability) is saved in `reports/host_environment_inventory.json`. It records credential presence only, never secret values.",
              "", "## External and production boundaries", "",
              "A blocked gate means the required environment, external authorization, data, tool or independent evidence was unavailable in this run. It is not silently converted to PASS.", "",
              "Synthetic model metrics are pipeline-execution evidence only, not real-world performance or causal retention evidence.", "",
              "## Reproduction", "",
              "Run `python scripts/verify.py --stage core`, then `runtime`, `migrations`, `product`, `synthetic`, `browser`, and finally `report`."]
    (REPORTS / "verification.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 1 if summary["failed"] else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Run isolated Churn Intelligence verification stages.")
    parser.add_argument("--stage", choices=("core", "runtime", "migrations", "product", "synthetic", "browser", "report"),
                        default="core", help="Run one independent gate group; run report last to aggregate evidence.")
    stage = parser.parse_args().stage
    return {"core": stage_core, "runtime": stage_runtime, "migrations": stage_migrations,
            "product": stage_product, "synthetic": stage_synthetic, "browser": stage_browser, "report": stage_report}[stage]()


if __name__ == "__main__":
    raise SystemExit(main())
