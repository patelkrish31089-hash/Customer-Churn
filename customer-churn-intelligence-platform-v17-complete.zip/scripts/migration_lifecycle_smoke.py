from __future__ import annotations

import json
import os
import sqlite3
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="churn-migration-lifecycle-") as temp:
        database = Path(temp) / "migration.sqlite"
        env = os.environ.copy()
        env.update({"APP_ENV": "test", "DATABASE_URL": f"sqlite:///{database}",
                    "UPLOAD_DIR": str(Path(temp) / "uploads"),
                    "ARTIFACT_DIR": str(Path(temp) / "artifacts")})
        steps = []
        for command in ([sys.executable, "-m", "alembic", "upgrade", "head"],
                        [sys.executable, "-m", "alembic", "downgrade", "base"],
                        [sys.executable, "-m", "alembic", "upgrade", "head"]):
            proc = subprocess.run(command, cwd=ROOT, env=env, text=True,
                                  stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=45)
            steps.append({"command": " ".join(command), "exit_code": proc.returncode,
                          "output_tail": proc.stdout[-3000:]})
            if proc.returncode:
                result = {"status": "failed", "steps": steps}
                (REPORTS / "migration_lifecycle_evidence.json").write_text(
                    json.dumps(result, indent=2) + "\n", encoding="utf-8")
                print(json.dumps(result, indent=2))
                return 1
        with sqlite3.connect(database) as conn:
            version = conn.execute("SELECT version_num FROM alembic_version").fetchone()[0]
            tables = sorted(row[0] for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
            fk_violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        result = {"status": "passed" if not fk_violations and len(tables) >= 25 else "failed",
                  "steps": steps, "final_revision": version, "table_count": len(tables),
                  "tables": tables, "foreign_key_violations": fk_violations,
                  "generated_at": datetime.now(timezone.utc).isoformat(),
                  "method": "fresh isolated SQLite database; upgrade head -> downgrade base -> upgrade head"}
        (REPORTS / "migration_lifecycle_evidence.json").write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
