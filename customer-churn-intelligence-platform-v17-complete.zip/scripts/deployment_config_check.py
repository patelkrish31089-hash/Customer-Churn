from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    try:
        import yaml
    except ImportError:
        print(json.dumps({"status": "blocked", "reason": "PyYAML unavailable"}))
        return 2
    compose_path = ROOT / "docker-compose.yml"
    dockerfile_path = ROOT / "Dockerfile"
    compose = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    services = compose.get("services", {})
    required = {"db", "app", "worker"}
    if not required.issubset(services):
        raise AssertionError(f"Compose is missing services: {sorted(required-set(services))}")
    db, app, worker = services["db"], services["app"], services["worker"]
    if not str(db.get("image", "")).startswith("postgres:"):
        raise AssertionError("Database service is not a PostgreSQL image")
    if "healthcheck" not in db or "healthcheck" not in app:
        raise AssertionError("PostgreSQL and application health checks are required")
    condition = app.get("depends_on", {}).get("db", {}).get("condition")
    if condition != "service_healthy":
        raise AssertionError("Application must wait for healthy PostgreSQL")
    if not compose.get("volumes"):
        raise AssertionError("Persistent volumes are required")
    worker_command = " ".join(worker.get("command", [])) if isinstance(worker.get("command"), list) else str(worker.get("command", ""))
    if "app.worker" not in worker_command:
        raise AssertionError("A dedicated background worker service is required")
    if worker.get("depends_on", {}).get("app", {}).get("condition") != "service_healthy":
        raise AssertionError("The worker must wait for the application/database readiness gate")
    if worker.get("environment", {}).get("DATABASE_URL") != app.get("environment", {}).get("DATABASE_URL"):
        raise AssertionError("The worker and API must use the same database URL")
    if set(worker.get("volumes", [])) != set(app.get("volumes", [])):
        raise AssertionError("The worker and API must share upload and model artifact volumes")
    if "POSTGRES_PASSWORD" not in str(db.get("environment", {})):
        raise AssertionError("PostgreSQL password must be environment supplied")
    if not dockerfile_path.exists():
        raise AssertionError("Dockerfile is missing")
    result = {"status": "passed", "compose_services": sorted(services),
              "postgres_image": db["image"], "persistent_volumes": sorted(compose["volumes"]),
              "healthchecks": {"db": True, "app": True},
              "app_waits_for_database_health": True,
              "dedicated_worker": True,
              "worker_shares_database_and_artifact_volumes": True,
              "runtime_execution": "not_performed_by_this_static_manifest_check"}
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
