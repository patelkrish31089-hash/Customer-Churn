from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


def main() -> int:
    import mlflow
    import pandas as pd
    from evidently import Report
    from evidently.presets import DataDriftPreset

    with tempfile.TemporaryDirectory(prefix="churn-mlops-smoke-") as directory:
        root = Path(directory)
        tracking_uri = (root / "mlruns").as_uri()
        os.environ["MLFLOW_TRACKING_URI"] = tracking_uri
        os.environ["MLFLOW_EXPERIMENT_NAME"] = "churn-mlops-smoke"

        from app.integrations.mlflow_tracking import track_training_run, tracking_status

        if tracking_status().get("status") != "configured":
            raise RuntimeError("MLflow tracking adapter did not report configured")
        artifact = root / "model-artifact.txt"
        artifact.write_text("local adapter verification artifact\n", encoding="utf-8")
        tracked = track_training_run(
            run_id="mlops-smoke-run", algorithm="logistic_regression",
            parameters={"seed": 17, "feature_version": "2.1"},
            metrics={"validation": {"pr_auc": 0.72}, "test": {"pr_auc": 0.68}},
            artifact_path=artifact, dataset_fingerprint="synthetic-smoke-only",
        )
        if tracked.get("status") != "logged":
            raise RuntimeError(f"MLflow adapter failed: {tracked}")
        client = mlflow.tracking.MlflowClient(tracking_uri=tracking_uri)
        run = client.get_run(tracked["run_id"])
        if run.data.params.get("algorithm") != "logistic_regression":
            raise RuntimeError("MLflow run did not retain the algorithm parameter")

        reference = pd.DataFrame({"usage_30d": [1, 2, 3, 4, 5], "support_tickets_30d": [0, 0, 1, 0, 1]})
        current = pd.DataFrame({"usage_30d": [10, 11, 12, 13, 14], "support_tickets_30d": [1, 2, 1, 2, 3]})
        report = Report(metrics=[DataDriftPreset()])
        result = report.run(reference_data=reference, current_data=current)
        rendered = result.json()
        parsed = json.loads(rendered)
        if not isinstance(parsed, (dict, list)):
            raise RuntimeError("Evidently did not produce structured report output")

        print(json.dumps({
            "status": "passed",
            "mlflow_tracking": "logged_and_read_back",
            "evidently_report": "generated",
            "tracking_uri": "temporary_local_file_store",
            "data_provenance": "synthetic_smoke_only",
            "external_server": False,
        }, indent=2))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
