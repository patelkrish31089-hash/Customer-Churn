from __future__ import annotations

import asyncio
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def reserve_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


async def main_async(base: str, token: str) -> dict:
    import httpx
    limits = httpx.Limits(max_connections=20, max_keepalive_connections=10)
    timeout = httpx.Timeout(8.0, connect=3.0)
    headers = {"Authorization": f"Bearer {token}"}
    latencies = []
    statuses = []
    async with httpx.AsyncClient(base_url=base, headers=headers, timeout=timeout, limits=limits) as client:
        semaphore = asyncio.Semaphore(10)
        async def one(index: int):
            async with semaphore:
                started = time.perf_counter()
                response = await client.get("/api/v1/customers", params={"limit": 25, "offset": index % 3})
                latencies.append((time.perf_counter() - started) * 1000)
                statuses.append(response.status_code)
                if response.status_code == 200:
                    payload = response.json()
                    if not isinstance(payload.get("items"), list):
                        raise AssertionError("Customer API returned an unexpected response contract")
        await asyncio.gather(*(one(i) for i in range(40)))
    ordered = sorted(latencies)
    p95 = ordered[min(len(ordered)-1, int(len(ordered)*.95))]
    return {"requests": len(statuses), "concurrency_limit": 10,
            "http_status_counts": {str(code): statuses.count(code) for code in sorted(set(statuses))},
            "latency_ms": {"min": round(min(ordered), 2), "median": round(ordered[len(ordered)//2], 2),
                           "p95": round(p95, 2), "max": round(max(ordered), 2)},
            "result": "passed" if len(statuses) == 40 and all(x == 200 for x in statuses) else "failed",
            "scope": "small local concurrency smoke; not a production capacity/load benchmark"}


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="churn-load-smoke-") as temp:
        tmp = Path(temp)
        env = os.environ.copy()
        env.update({"APP_ENV": "test", "DATABASE_URL": f"sqlite:///{tmp / 'load.sqlite'}",
                    "UPLOAD_DIR": str(tmp / "uploads"), "ARTIFACT_DIR": str(tmp / "artifacts"),
                    "LOG_LEVEL": "WARNING"})
        subprocess.run([sys.executable, "-m", "app.cli", "init-db"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        subprocess.run([sys.executable, "-m", "app.cli", "create-admin", "--username", "load-admin",
                        "--password", "load-smoke-password-123"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        port = reserve_port()
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                                    "--port", str(port), "--log-level", "warning"], cwd=ROOT, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        base = f"http://127.0.0.1:{port}"
        try:
            deadline = time.time() + 20
            ready = False
            while time.time() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("Uvicorn exited before load smoke startup")
                try:
                    with urllib.request.urlopen(base + "/api/v1/health/ready", timeout=1) as response:
                        ready = response.status == 200
                    if ready:
                        break
                except Exception:
                    time.sleep(.2)
            if not ready:
                raise RuntimeError("Application did not become ready for load smoke")
            request = urllib.request.Request(base + "/api/v1/auth/login", data=json.dumps({
                "username": "load-admin", "password": "load-smoke-password-123"}).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(request, timeout=3) as response:
                token = json.loads(response.read())["access_token"]
            result = asyncio.run(main_async(base, token))
            print(json.dumps(result, indent=2))
            return 0 if result["result"] == "passed" else 1
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)
            if process.stdout:
                process.stdout.close()


if __name__ == "__main__":
    raise SystemExit(main())
