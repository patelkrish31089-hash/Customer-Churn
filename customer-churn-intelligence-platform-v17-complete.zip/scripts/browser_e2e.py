from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def main() -> int:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print(json.dumps({"status": "blocked", "reason": "playwright_package_missing"}))
        return 2

    browser_path = os.getenv("CHROMIUM_EXECUTABLE")
    if not browser_path and Path("/usr/bin/chromium").exists():
        browser_path = "/usr/bin/chromium"
    if browser_path and not Path(browser_path).exists():
        print(json.dumps({"status": "blocked", "reason": "chromium_binary_missing", "path": browser_path}))
        return 2

    with tempfile.TemporaryDirectory(prefix="churn-browser-e2e-") as temp:
        tmp = Path(temp)
        env = os.environ.copy()
        env.update({"APP_ENV": "test", "DATABASE_URL": f"sqlite:///{tmp / 'browser.sqlite'}",
                    "UPLOAD_DIR": str(tmp / "uploads"), "ARTIFACT_DIR": str(tmp / "artifacts"),
                    "LOG_LEVEL": "WARNING"})
        subprocess.run([sys.executable, "-m", "app.cli", "init-db"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        subprocess.run([sys.executable, "-m", "app.cli", "create-admin", "--username", "browser-admin",
                        "--password", "browser-e2e-password-123"], cwd=ROOT, env=env,
                       check=True, timeout=30, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        port = free_port()
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0",
                                    "--port", str(port), "--log-level", "warning"], cwd=ROOT, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        base = f"http://127.0.0.1:{port}"
        try:
            import urllib.request
            deadline = time.time() + 20
            while time.time() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("Uvicorn exited before browser test startup")
                try:
                    with urllib.request.urlopen(base + "/api/v1/health/ready", timeout=1) as response:
                        if response.status == 200:
                            break
                except Exception:
                    time.sleep(.2)
            else:
                raise RuntimeError("Application did not become ready for Playwright")

            errors: list[str] = []
            completed_pages: list[str] = []
            with sync_playwright() as playwright:
                launch_options = {"headless": True,
                    "args": ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--no-proxy-server", "--proxy-bypass-list=*"]}
                if browser_path:
                    launch_options["executable_path"] = browser_path
                browser = playwright.chromium.launch(**launch_options)
                page = browser.new_page(viewport={"width": 1440, "height": 1000})
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.on("console", lambda msg: errors.append(f"console.{msg.type}: {msg.text}") if msg.type == "error" else None)
                try:
                    page.goto(base, wait_until="networkidle", timeout=15000)
                except Exception as exc:
                    if "ERR_BLOCKED_BY_ADMINISTRATOR" in str(exc):
                        browser.close()
                        print(json.dumps({"status": "blocked", "reason": "browser_policy_blocks_localhost_navigation",
                                          "detail": "Chromium returned ERR_BLOCKED_BY_ADMINISTRATOR for the local test server."}, indent=2))
                        return 2
                    raise
                if not page.locator("#loginForm").is_visible():
                    raise AssertionError("Login form did not render")
                axe_script = ROOT / "node_modules" / "axe-core" / "axe.min.js"
                accessibility_pages: dict[str, dict] = {}
                if axe_script.exists():
                    page.add_script_tag(path=str(axe_script))

                def scan_accessibility(view_name: str) -> None:
                    if not axe_script.exists():
                        return
                    scan = page.evaluate("async () => { const r = await axe.run(document); return { violations: r.violations.map(v => ({ id: v.id, impact: v.impact, description: v.description, nodes: v.nodes.length })), passes: r.passes.length, incomplete: r.incomplete.length }; }")
                    accessibility_pages[view_name] = scan
                    if scan["violations"]:
                        errors.append(f"Accessibility violations on {view_name}: " + json.dumps(scan["violations"]))

                scan_accessibility("login")
                page.locator("#username").fill("browser-admin")
                page.locator("#password").fill("browser-e2e-password-123")
                page.locator('#loginForm button[type="submit"]').click()
                page.locator("#appView").wait_for(state="visible", timeout=10000)
                page.locator("#page-overview .stat-value").first.wait_for(state="visible", timeout=10000)
                completed_pages.append("overview")
                scan_accessibility("overview")

                # Exercise every primary page against the real local API.
                expected = {
                    "data": "Import customer data",
                    "customers": "Customer directory",
                    "analytics": "Customer & subscription cohorts",
                    "models": "Model training",
                    "retention": "Retention worklist",
                    "operations": "ML platform capabilities",
                }
                for key, heading in expected.items():
                    page.locator(f'[data-page="{key}"]').click()
                    page.get_by_text(heading, exact=True).first.wait_for(state="visible", timeout=10000)
                    completed_pages.append(key)
                    scan_accessibility(key)

                # Perform an actual browser-mediated upload through the dashboard and API.
                page.locator('[data-page="data"]').click()
                page.locator("#uploadForm").wait_for(state="visible")
                customer_csv = tmp / "browser-customer.csv"
                customer_csv.write_text("customer_id,name,email\nBROWSER-E2E-1,Browser E2E Customer,browser@example.invalid\n",
                                        encoding="utf-8")
                page.locator("#importFile").set_input_files(str(customer_csv))
                page.locator('#uploadForm button[type="submit"]').click()
                page.get_by_text("Import completed.", exact=False).wait_for(state="visible", timeout=10000)
                scan_accessibility("data_after_upload")

                # Confirm customer listing reflects the browser-originated import.
                page.locator('[data-page="customers"]').click()
                page.get_by_text("Browser E2E Customer", exact=False).wait_for(state="visible", timeout=10000)
                scan_accessibility("customers_after_upload")
                accessibility_violations = [
                    {"page": name, **violation}
                    for name, scan in accessibility_pages.items()
                    for violation in scan.get("violations", [])
                ]
                accessibility = ({"status": "passed" if not accessibility_violations else "failed",
                                  "scanned_views": list(accessibility_pages),
                                  "violations": accessibility_violations,
                                  "pass_count": sum(x.get("passes", 0) for x in accessibility_pages.values()),
                                  "incomplete_count": sum(x.get("incomplete", 0) for x in accessibility_pages.values())}
                                 if axe_script.exists() else
                                 {"status": "not_run", "reason": "axe-core is not installed in this workspace"})
                browser.close()

            result = {"status": "passed" if not errors else "failed", "browser": "Chromium",
                      "chromium_executable": browser_path or "Playwright-managed Chromium", "pages_rendered": completed_pages,
                      "browser_upload_and_customer_readback": "passed", "accessibility": accessibility,
                      "console_or_page_errors": errors}
            print(json.dumps(result, indent=2))
            return 0 if not errors else 1
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            if process.stdout:
                process.stdout.close()


if __name__ == "__main__":
    raise SystemExit(main())
