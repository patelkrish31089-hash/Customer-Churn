#!/usr/bin/env bash
set -Eeuo pipefail

: "${POSTGRES_PASSWORD:?POSTGRES_PASSWORD must be supplied by the CI secret/environment}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p reports
BACKUP_FILE="${RUNNER_TEMP:-/tmp}/churn-postgres-backup.sql"
COMPOSE_STARTED=0
cleanup() {
  status=$?
  trap - EXIT
  if [[ "$COMPOSE_STARTED" == "1" ]]; then
    if [[ "$status" -ne 0 ]]; then docker compose logs --no-color > reports/docker_runtime_failure.log 2>&1 || true; fi
    docker compose down -v --remove-orphans || true
  fi
  exit "$status"
}
trap cleanup EXIT

COMPOSE_STARTED=1
docker compose up --build -d
for attempt in $(seq 1 60); do
  if curl --fail --silent http://127.0.0.1:8000/api/v1/health/ready >/dev/null; then break; fi
  if [[ "$attempt" == "60" ]]; then echo "Application did not become ready" >&2; exit 1; fi
  sleep 3
done
curl --fail --silent http://127.0.0.1:8000/api/v1/health/ready > reports/docker_ready.json

docker compose exec -T app python -m app.cli create-admin \
  --username ci-admin --password 'ci-container-password-12345'
login() {
  curl --fail --silent http://127.0.0.1:8000/api/v1/auth/login \
    -H 'Content-Type: application/json' \
    -d '{"username":"ci-admin","password":"ci-container-password-12345"}'
}
TOKEN="$(login | python -c 'import json,sys; print(json.load(sys.stdin)["access_token"])')"
curl --fail --silent http://127.0.0.1:8000/api/v1/auth/me \
  -H "Authorization: Bearer $TOKEN" > reports/docker_identity_before_restart.json

# Confirm the standalone worker container can claim and complete a persisted job.
JOB_KEY="docker-worker-$(date +%s)-$RANDOM"
JOB_JSON="$(curl --fail --silent http://127.0.0.1:8000/api/v1/jobs \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"job_type\":\"quality_audit\",\"payload\":{\"scope\":\"all\"},\"idempotency_key\":\"$JOB_KEY\"}")"
JOB_ID="$(printf '%s' "$JOB_JSON" | python -c 'import json,sys; print(json.load(sys.stdin)["id"])')"
JOB_DONE=0
for attempt in $(seq 1 45); do
  JOB_STATUS="$(curl --fail --silent "http://127.0.0.1:8000/api/v1/jobs/$JOB_ID" -H "Authorization: Bearer $TOKEN" | python -c 'import json,sys; print(json.load(sys.stdin)["status"])')"
  if [[ "$JOB_STATUS" == "succeeded" ]]; then JOB_DONE=1; break; fi
  if [[ "$JOB_STATUS" == "failed" ]]; then echo "Worker job failed: $JOB_ID" >&2; exit 1; fi
  sleep 2
done
if [[ "$JOB_DONE" != "1" ]]; then echo "Background worker did not finish job $JOB_ID" >&2; docker compose logs worker >&2; exit 1; fi
docker compose ps --services --filter status=running | grep -qx worker
printf '%s\n' "$JOB_JSON" > reports/docker_worker_job_enqueued.json

# The job state must remain durable across an API restart.
docker compose restart app
for attempt in $(seq 1 40); do
  if curl --fail --silent http://127.0.0.1:8000/api/v1/health/ready >/dev/null; then break; fi
  if [[ "$attempt" == "40" ]]; then echo "Application did not recover after restart" >&2; exit 1; fi
  sleep 2
done
curl --fail --silent http://127.0.0.1:8000/api/v1/auth/me \
  -H "Authorization: Bearer $TOKEN" > reports/docker_identity_after_restart.json
JOB_STATUS_AFTER_RESTART="$(curl --fail --silent "http://127.0.0.1:8000/api/v1/jobs/$JOB_ID" -H "Authorization: Bearer $TOKEN" | python -c 'import json,sys; print(json.load(sys.stdin)["status"])')"
if [[ "$JOB_STATUS_AFTER_RESTART" != "succeeded" ]]; then echo "Persisted worker job status was not readable after app restart" >&2; exit 1; fi
docker compose ps --services --filter status=running | grep -qx worker

# Exercise a real PostgreSQL dump and restore into a separate disposable database.
docker compose exec -T -e PGPASSWORD="$POSTGRES_PASSWORD" db pg_dump -U churn -d churn --no-owner --no-acl > "$BACKUP_FILE"
test -s "$BACKUP_FILE"
docker compose exec -T -e PGPASSWORD="$POSTGRES_PASSWORD" db createdb -U churn churn_restore
docker compose exec -T -e PGPASSWORD="$POSTGRES_PASSWORD" db psql -U churn -d churn_restore < "$BACKUP_FILE" >/dev/null
RESTORED_USERS="$(docker compose exec -T -e PGPASSWORD="$POSTGRES_PASSWORD" db psql -U churn -d churn_restore -Atc 'select count(*) from users' | tr -d '\r')"
if [[ "$RESTORED_USERS" -lt 1 ]]; then echo "Restored database did not contain expected admin user" >&2; exit 1; fi
docker compose exec -T -e PGPASSWORD="$POSTGRES_PASSWORD" db dropdb -U churn churn_restore
rm -f "$BACKUP_FILE"
python - <<'PY'
import json
from pathlib import Path
Path('reports/docker_runtime_evidence.json').write_text(json.dumps({
  'status': 'passed', 'checks': {
    'compose_build_and_start': True,
    'postgres_and_application_health': True,
    'authenticated_api': True,
    'worker_process_and_durable_job_execution': True,
    'job_state_survives_api_restart': True,
    'worker_remains_running_after_api_restart': True,
    'application_restart_and_database_persistence': True,
    'pg_dump_backup': True,
    'restore_into_separate_database': True,
    'restored_rows_verified': True,
    'disposable_restore_database_removed': True,
    'volumes_removed_after_test': 'docker compose down -v in cleanup'
  },
  'database_engine': 'PostgreSQL 16 via Docker Compose',
  'data_provenance': 'temporary synthetic CI administrator only'
}, indent=2) + '\n', encoding='utf-8')
PY
