#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PYTHON="${PYTHON:-$ROOT/.venv-local/bin/python}"
REVIEWED_BY="${REVIEWED_BY:-$(id -un)}"
[[ -x "$PYTHON" ]] || { echo "Local venv missing; run scripts/run_local_demo.sh first" >&2; exit 2; }
[[ -n "$REVIEWED_BY" ]] || { echo "Set REVIEWED_BY to a reviewer identifier" >&2; exit 2; }
for stage in core runtime migrations product synthetic browser report; do
  echo "=== Local verification stage: $stage ==="
  "$PYTHON" scripts/verify.py --stage "$stage"
done
"$PYTHON" scripts/local_demo_acceptance.py --reviewed-by "$REVIEWED_BY"
