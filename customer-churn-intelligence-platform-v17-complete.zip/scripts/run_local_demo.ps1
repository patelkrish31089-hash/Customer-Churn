[CmdletBinding()]
param(
    [ValidateRange(60, 5000)] [int]$Customers = 180,
    [ValidateRange(1024, 65535)] [int]$Port = 8000,
    [switch]$SkipInstall
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Venv = Join-Path $Root '.venv-local'
$Python = Join-Path $Venv 'Scripts\python.exe'
$WorkerProcess = $null
$Original = @{
    APP_ENV = $env:APP_ENV; DATABASE_URL = $env:DATABASE_URL; UPLOAD_DIR = $env:UPLOAD_DIR;
    ARTIFACT_DIR = $env:ARTIFACT_DIR; LOG_LEVEL = $env:LOG_LEVEL
}

function Invoke-Checked {
    param([string]$Label, [string]$Executable, [string[]]$Arguments)
    Write-Host "`n=== $Label ===" -ForegroundColor Cyan
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Label failed (exit $LASTEXITCODE). See the error above." }
}

Push-Location $Root
try {
    $Launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($Launcher) {
        & $Launcher.Source -3.12 -c 'import sys; print(sys.version)' *> $null
        if ($LASTEXITCODE -eq 0) { $BasePython = $Launcher.Source; $BaseArgs = @('-3.12') }
        else {
            & $Launcher.Source -3.11 -c 'import sys; print(sys.version)' *> $null
            if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 or 3.12 and enable the Python launcher.' }
            $BasePython = $Launcher.Source; $BaseArgs = @('-3.11')
        }
    } else {
        $Cmd = Get-Command python -ErrorAction SilentlyContinue
        if (-not $Cmd) { throw 'Python 3.11 or 3.12 is required.' }
        $Detected = & $Cmd.Source -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
        if ($Detected.Trim() -notin @('3.11','3.12')) { throw "Python 3.11/3.12 required; found $Detected." }
        $BasePython = $Cmd.Source; $BaseArgs = @()
    }

    if (-not (Test-Path (Join-Path $Venv 'pyvenv.cfg'))) {
        Invoke-Checked 'Create isolated virtual environment' $BasePython ($BaseArgs + @('-m','venv',$Venv))
    }
    if (-not $SkipInstall) {
        Invoke-Checked 'Upgrade pip' $Python @('-m','pip','install','--upgrade','pip')
        Invoke-Checked 'Install application dependencies' $Python @('-m','pip','install','-r','requirements.txt')
    }

    $env:APP_ENV = 'development'
    $env:DATABASE_URL = 'sqlite:///./data/churn.db'
    $env:UPLOAD_DIR = './data/uploads'
    $env:ARTIFACT_DIR = './artifacts'
    $env:LOG_LEVEL = 'INFO'
    New-Item -ItemType Directory -Force -Path 'data','data/uploads','artifacts' | Out-Null

    Invoke-Checked 'Apply database migrations' $Python @('-m','app.cli','init-db')
    Invoke-Checked 'Create/extend synthetic demonstration population' $Python @('-m','app.cli','seed-demo','--customers',$Customers.ToString(),'--seed','29')
    Invoke-Checked 'Create a local administrator (interactive password prompt)' $Python @('scripts/bootstrap_admin.py')

    $WorkerOut = Join-Path $Root 'data/worker.log'
    $WorkerErr = Join-Path $Root 'data/worker-error.log'
    $WorkerProcess = Start-Process -FilePath $Python -ArgumentList @('-m','app.worker','run','--poll-interval','2','--lease-seconds','900') -WorkingDirectory $Root -PassThru -WindowStyle Hidden -RedirectStandardOutput $WorkerOut -RedirectStandardError $WorkerErr
    Write-Host "`nBackground worker started (PID $($WorkerProcess.Id)); logs: data/worker.log" -ForegroundColor Cyan
    Write-Host "`nOpening the local dashboard at http://127.0.0.1:$Port" -ForegroundColor Green
    Write-Host 'Sign in with the administrator username/password you just created. Press Ctrl+C to stop.' -ForegroundColor Yellow
    Invoke-Checked 'Start application server' $Python @('-m','uvicorn','app.main:app','--host','127.0.0.1','--port',$Port.ToString())
}
finally {
    if ($WorkerProcess -and -not $WorkerProcess.HasExited) { Stop-Process -Id $WorkerProcess.Id -Force -ErrorAction SilentlyContinue }
    foreach ($Key in $Original.Keys) {
        if ($null -eq $Original[$Key]) { Remove-Item "Env:\$Key" -ErrorAction SilentlyContinue }
        else { Set-Item "Env:\$Key" $Original[$Key] }
    }
    Pop-Location
}
