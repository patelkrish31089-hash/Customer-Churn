from __future__ import annotations

import json
from pathlib import Path


def main() -> int:
    from airflow.models.dagbag import DagBag

    root = Path(__file__).resolve().parents[1]
    dag_path = root / "dags" / "customer_churn_daily_scoring.py"
    bag = DagBag(dag_folder=str(dag_path), include_examples=False)
    if bag.import_errors:
        print(json.dumps({"status": "failed", "import_errors": bag.import_errors}, indent=2))
        return 1
    dag = bag.get_dag("customer_churn_daily_scoring")
    if dag is None:
        print(json.dumps({"status": "failed", "reason": "expected_dag_not_discovered"}, indent=2))
        return 1
    task_ids = sorted(task.task_id for task in dag.tasks)
    if "score_population" not in task_ids:
        print(json.dumps({"status": "failed", "reason": "score_population_task_missing", "task_ids": task_ids}, indent=2))
        return 1
    print(json.dumps({"status": "passed", "dag_id": dag.dag_id,
                      "schedule": str(dag.schedule_interval if hasattr(dag, "schedule_interval") else dag.timetable),
                      "task_ids": task_ids, "execution": "dag-parse-only; scheduler/task execution not asserted"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
