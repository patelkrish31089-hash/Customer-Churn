[CmdletBinding()]
param(
    [ValidateRange(0.25, 60)] [double]$PollInterval = 2,
    [ValidateRange(30, 7200)] [int]$LeaseSeconds = 900
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$VenvPython = Join-Path $Root '.venv-local\Scripts\python.exe'
$Python = if (Test-Path $VenvPython) { $VenvPython } else { (Get-Command python -ErrorAction Stop).Source }
Push-Location $Root
try {
    & $Python -m app.worker run --poll-interval $PollInterval.ToString([Globalization.CultureInfo]::InvariantCulture) --lease-seconds $LeaseSeconds
    if ($LASTEXITCODE -ne 0) { throw "Worker exited with code $LASTEXITCODE" }
}
finally { Pop-Location }
