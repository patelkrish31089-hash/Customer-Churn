"""Small, dependency-free AST security smoke for first-party Python source.

This is defense-in-depth only. It is not a replacement for Bandit, pip-audit,
secret scanning, code review, or an independent penetration test.
"""
from __future__ import annotations

import argparse
import ast
import json
from dataclasses import asdict, dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = ROOT / "app"


@dataclass(frozen=True)
class Finding:
    path: str
    line: int
    rule: str
    message: str


def dotted_name(node: ast.AST) -> str:
    parts: list[str] = []
    current: ast.AST | None = node
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if isinstance(current, ast.Name):
        parts.append(current.id)
    return ".".join(reversed(parts))


def analyze_source(source: str, display_path: str = "<memory>") -> list[Finding]:
    try:
        tree = ast.parse(source, filename=display_path)
    except SyntaxError as exc:
        return [Finding(display_path, exc.lineno or 1, "PY001", "Python source does not parse")]

    findings: list[Finding] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = dotted_name(node.func)
        line = getattr(node, "lineno", 1)
        if name in {"eval", "exec"}:
            findings.append(Finding(display_path, line, "PYSEC001", f"Dynamic code execution via {name}()"))
        elif name == "os.system":
            findings.append(Finding(display_path, line, "PYSEC002", "Shell command executed through os.system()"))
        elif name in {"subprocess.run", "subprocess.Popen", "subprocess.call", "subprocess.check_call", "subprocess.check_output"}:
            if any(keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True
                   for keyword in node.keywords):
                findings.append(Finding(display_path, line, "PYSEC003", "Subprocess call enables shell=True"))
        elif name in {"pickle.load", "pickle.loads", "cPickle.load", "cPickle.loads", "dill.load", "dill.loads"}:
            findings.append(Finding(display_path, line, "PYSEC004", "Unsafe object deserialization primitive"))
        elif name == "tempfile.mktemp":
            findings.append(Finding(display_path, line, "PYSEC005", "Race-prone tempfile.mktemp() used"))
        elif name in {"ssl._create_unverified_context"}:
            findings.append(Finding(display_path, line, "PYSEC006", "TLS certificate verification disabled"))
        elif name in {"requests.get", "requests.post", "requests.put", "requests.delete", "httpx.get", "httpx.post", "httpx.put", "httpx.delete"}:
            if any(keyword.arg == "verify" and isinstance(keyword.value, ast.Constant) and keyword.value.value is False
                   for keyword in node.keywords):
                findings.append(Finding(display_path, line, "PYSEC006", "HTTP TLS certificate verification disabled"))
        elif name == "yaml.load":
            has_safe_loader = any(keyword.arg == "Loader" and dotted_name(keyword.value) in {
                "yaml.SafeLoader", "yaml.CSafeLoader"} for keyword in node.keywords)
            if not has_safe_loader:
                findings.append(Finding(display_path, line, "PYSEC007", "yaml.load() without an explicit safe loader"))
    return findings


def scan_tree(root: Path = APP_ROOT) -> list[Finding]:
    findings: list[Finding] = []
    for path in sorted(root.rglob("*.py")):
        if any(part in {"__pycache__", ".venv"} for part in path.parts):
            continue
        try:
            source = path.read_text(encoding="utf-8")
        except OSError:
            findings.append(Finding(str(path), 1, "IO001", "Unable to read Python source"))
            continue
        findings.extend(analyze_source(source, str(path.relative_to(ROOT))))
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=APP_ROOT)
    args = parser.parse_args()
    findings = scan_tree(args.root)
    report = {"status": "passed" if not findings else "findings", "scope": "first-party Python AST patterns",
              "finding_count": len(findings), "findings": [asdict(item) for item in findings],
              "limitation": "Supplemental heuristic only; not Bandit, pip-audit, a secrets scanner, or a penetration test."}
    print(json.dumps(report, indent=2))
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
