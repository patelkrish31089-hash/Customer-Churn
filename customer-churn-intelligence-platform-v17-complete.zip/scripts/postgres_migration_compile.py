from __future__ import annotations

import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def main() -> int:
    env = os.environ.copy()
    env.update({"APP_ENV": "test", "DATABASE_URL": "postgresql://compile_only:compile_only@127.0.0.1/churn"})
    proc = subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head", "--sql"],
                          cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, timeout=45)
    if proc.returncode != 0:
        result = {"status": "failed", "step": "alembic_offline_upgrade_head",
                  "exit_code": proc.returncode, "output_tail": proc.stdout[-8000:]}
        (REPORTS / "postgresql_offline_migration_evidence.json").write_text(
            json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 1
    sql_path = REPORTS / "postgresql_offline_migrations.sql"
    sql_path.write_text(proc.stdout, encoding="utf-8")
    required = ["CREATE TABLE customers", "CREATE TABLE subscriptions", "CREATE TABLE churn_labels",
                "CREATE TABLE feature_snapshots", "CREATE TABLE model_releases",
                "CREATE TABLE predictions", "FOREIGN KEY"]
    missing = [token for token in required if token not in proc.stdout]
    forbidden = [token for token in ("PRAGMA", "AUTOINCREMENT", "WITHOUT ROWID") if token in proc.stdout.upper()]
    result = {"status": "passed" if not missing and not forbidden else "failed",
              "dialect": "PostgreSQL", "mode": "Alembic offline SQL generation; no database server was contacted",
              "migration_sql_file": str(sql_path.relative_to(ROOT)),
              "sql_lines": len(proc.stdout.splitlines()), "required_ddl_markers": required,
              "missing_markers": missing, "sqlite_only_markers": forbidden,
              "generated_at": datetime.now(timezone.utc).isoformat(),
              "runtime_postgresql_connection": "not tested; PostgreSQL server and driver unavailable"}
    (REPORTS / "postgresql_offline_migration_evidence.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
