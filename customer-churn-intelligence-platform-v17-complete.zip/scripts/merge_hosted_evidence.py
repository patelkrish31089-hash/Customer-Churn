from __future__ import annotations

"""Validate one GitHub Actions run's artifacts and record technical-gate closure.

Artifacts must be extracted into separate subdirectories under --artifact-root.
The importer never accepts a missing artifact, a different run/commit, a failed
job, or a partial report as a pass. External company/assessor gates are not
covered by this importer.
"""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_ARTIFACTS = {
    "clean-install-python-3.11": ("clean_install_acceptance.json", "clean_install", "3.11"),
    "clean-install-python-3.12": ("clean_install_acceptance.json", "clean_install", "3.12"),
    "quality-security-toolchain-evidence": ("quality_security_acceptance.json", "quality_security", ""),
    "backend-postgresql-python-3.11": ("postgresql_runtime_evidence.json", "postgresql", "3.11"),
    "backend-postgresql-python-3.12": ("postgresql_runtime_evidence.json", "postgresql", "3.12"),
    "docker-compose-runtime-evidence": ("docker_runtime_evidence.json", "docker", ""),
    "mlops-adapter-runtime-evidence": ("mlops_runtime_evidence.json", "mlops", ""),
    "airflow-dag-runtime-evidence": ("airflow_dag_evidence.json", "airflow", ""),
}
GATE_TO_ARTIFACTS = {
    "clean_virtual_environment_install": ["clean-install-python-3.11", "clean-install-python-3.12"],
    "quality_and_security_toolchain": ["quality-security-toolchain-evidence"],
    "postgresql_runtime": ["backend-postgresql-python-3.11", "backend-postgresql-python-3.12"],
    "docker_runtime": ["docker-compose-runtime-evidence"],
    "mlops_runtime": ["mlops-adapter-runtime-evidence", "airflow-dag-runtime-evidence"],
}


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return value


def locate_artifacts(root: Path) -> dict[str, tuple[Path, dict[str, Any]]]:
    found: dict[str, tuple[Path, dict[str, Any]]] = {}
    for metadata_path in root.rglob("ci_run_metadata.json"):
        metadata = read_json(metadata_path)
        name = str(metadata.get("artifact_name", ""))
        if name in REQUIRED_ARTIFACTS:
            if name in found:
                raise ValueError(f"Duplicate artifact directory for {name}")
            found[name] = (metadata_path.parent, metadata)
    return found


def validate_provenance(
    name: str, metadata: dict[str, Any], run_id: str, run_attempt: str,
    commit_sha: str, expected_repository: str,
) -> list[str]:
    errors = []
    if metadata.get("schema_version") != 1:
        errors.append("unsupported_metadata_schema")
    if metadata.get("workflow") != "full-platform-acceptance":
        errors.append("wrong_workflow")
    if str(metadata.get("run_id", "")) != run_id:
        errors.append("wrong_run_id")
    if str(metadata.get("run_attempt", "")) != run_attempt:
        errors.append("wrong_run_attempt")
    if str(metadata.get("commit_sha", "")).lower() != commit_sha.lower():
        errors.append("wrong_commit_sha")
    if str(metadata.get("job_status", "")).lower() != "success":
        errors.append("job_not_successful")
    if metadata.get("artifact_name") != name:
        errors.append("artifact_name_mismatch")
    expected_version = REQUIRED_ARTIFACTS[name][2]
    if expected_version and str(metadata.get("matrix_python_version", "")) != expected_version:
        errors.append("wrong_matrix_python_version")
    if not metadata.get("repository"):
        errors.append("repository_missing")
    elif metadata.get("repository") != expected_repository:
        errors.append("repository_mismatch")
    if not metadata.get("job_id"):
        errors.append("job_id_missing")
    return errors


def validate_payload(kind: str, payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if kind == "clean_install":
        steps = payload.get("steps", [])
        names = {str(item.get("name")) for item in steps if isinstance(item, dict)}
        required = {"upgrade_pip", "isolated_venv_check", "install_all_declared_groups",
                    "pip_check", "python_compile", "strict_pytest", "frontend_javascript_syntax",
                    "installed_package_inventory"}
        if payload.get("status") != "PASS":
            errors.append("clean_install_report_not_passed")
        if payload.get("isolated_environment") is not True or payload.get("system_site_packages") is not False:
            errors.append("isolated_venv_not_proven")
        if not required.issubset(names):
            errors.append("clean_install_steps_incomplete")
        if any(item.get("status") != "PASS" for item in steps if isinstance(item, dict)):
            errors.append("clean_install_step_failed")
    elif kind == "quality_security":
        checks = payload.get("checks", [])
        names = {str(item.get("name")) for item in checks if isinstance(item, dict)}
        required = {"pip_check", "ruff", "bandit", "pip_audit", "first_party_ast_security"}
        if payload.get("status") != "PASS":
            errors.append("quality_security_report_not_passed")
        if not required.issubset(names):
            errors.append("quality_security_checks_incomplete")
        if any(item.get("status") != "PASS" for item in checks if isinstance(item, dict)):
            errors.append("quality_security_check_failed")
    elif kind == "postgresql":
        if payload.get("status") != "passed" or payload.get("database_engine") != "postgresql":
            errors.append("postgresql_runtime_not_passed")
        if not payload.get("server_version"):
            errors.append("postgresql_server_version_missing")
        required_checks = {"migrated_schema_present", "customer_subscription_invoice_payment_crud",
                           "numeric_18_2_precision", "unique_constraint", "foreign_key_constraint",
                           "transaction_rollback", "committed_data_persistence", "api_readiness",
                           "authentication", "session_revocation", "fixture_cleanup"}
        checks = payload.get("checks", {})
        if not required_checks.issubset(checks):
            errors.append("postgresql_checks_incomplete")
        if any(checks.get(name) is not True for name in required_checks):
            errors.append("postgresql_check_failed")
    elif kind == "worker_queue":
        if payload.get("status") != "passed" or payload.get("database_dialect") != "postgresql":
            errors.append("postgresql_worker_queue_runtime_not_passed")
        required_checks = {"queue_table_migrated", "enqueue_persisted", "worker_claimed_job",
                           "quality_audit_handler_executed", "result_persisted", "lease_released",
                           "at_least_once_semantics_documented"}
        checks = payload.get("checks", {})
        if not required_checks.issubset(checks):
            errors.append("worker_queue_checks_incomplete")
        if any(checks.get(name) is not True for name in required_checks):
            errors.append("worker_queue_check_failed")
    elif kind == "docker":
        if payload.get("status") != "passed":
            errors.append("docker_runtime_not_passed")
        expected = {"compose_build_and_start", "postgres_and_application_health", "authenticated_api",
                    "application_restart_and_database_persistence", "worker_process_and_durable_job_execution",
                    "job_state_survives_api_restart", "worker_remains_running_after_api_restart", "pg_dump_backup",
                    "restore_into_separate_database", "restored_rows_verified"}
        checks = payload.get("checks", {})
        if not expected.issubset(checks):
            errors.append("docker_recovery_checks_incomplete")
        if any(checks.get(name) is not True for name in expected):
            errors.append("docker_recovery_check_failed")
    elif kind == "mlops":
        if payload.get("status") != "passed":
            errors.append("mlops_runtime_not_passed")
        if payload.get("mlflow_tracking") != "logged_and_read_back":
            errors.append("mlflow_readback_not_proven")
        if payload.get("evidently_report") != "generated":
            errors.append("evidently_report_not_generated")
    elif kind == "airflow":
        if payload.get("status") != "passed":
            errors.append("airflow_runtime_not_passed")
        if payload.get("task_state") != "success" or payload.get("batch_status") != "completed":
            errors.append("airflow_batch_execution_not_proven")
        if payload.get("failed") != 0:
            errors.append("airflow_failed_count_nonzero")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate downloaded GitHub Actions acceptance evidence.")
    parser.add_argument("--artifact-root", type=Path, required=True,
                        help="Directory containing individually extracted GitHub Actions artifacts")
    parser.add_argument("--run-id", required=True, help="Single GitHub Actions workflow run ID")
    parser.add_argument("--run-attempt", required=True, help="GitHub Actions run attempt number (usually 1)")
    parser.add_argument("--commit-sha", required=True, help="Full 40-character commit SHA for that run")
    parser.add_argument("--expected-repository", required=True,
                        help="Exact owner/repository expected for every artifact, e.g. owner/project")
    parser.add_argument("--recorded-by", default="github-actions",
                        help="Workflow actor or operator that performed the aggregation; not a reviewer")
    parser.add_argument("--reviewed-by", default="",
                        help="Optional human reviewer identifier. Only this writes hosted_gate_closure.json.")
    args = parser.parse_args()

    if not args.artifact_root.is_dir():
        parser.error("--artifact-root must be an existing directory of extracted artifacts")
    if len(args.commit_sha) != 40 or any(char not in "0123456789abcdefABCDEF" for char in args.commit_sha):
        parser.error("--commit-sha must be a full 40-character hexadecimal SHA")
    if not args.expected_repository.strip() or "/" not in args.expected_repository:
        parser.error("--expected-repository must be an exact owner/repository value")
    if not args.recorded_by.strip():
        parser.error("--recorded-by cannot be blank")

    if not args.run_attempt.isdigit() or int(args.run_attempt) < 1:
        parser.error("--run-attempt must be a positive integer")

    located = locate_artifacts(args.artifact_root)
    expected_repository = args.expected_repository.strip()
    artifact_results: dict[str, dict[str, Any]] = {}
    for name, (filename, kind, _) in REQUIRED_ARTIFACTS.items():
        artifact_errors = []
        item = located.get(name)
        if item is None:
            artifact_results[name] = {"status": "BLOCKED", "errors": ["artifact_missing"]}
            continue
        folder, metadata = item
        artifact_errors.extend(validate_provenance(
            name, metadata, args.run_id, args.run_attempt, args.commit_sha, expected_repository
        ))
        evidence_path = folder / filename
        if not evidence_path.is_file():
            artifact_errors.append("evidence_file_missing")
            payload = {}
        else:
            try:
                payload = read_json(evidence_path)
                artifact_errors.extend(validate_payload(kind, payload))
                if kind == "postgresql":
                    worker_path = folder / "worker_queue_runtime_evidence.json"
                    if not worker_path.is_file():
                        artifact_errors.append("worker_queue_runtime_evidence_missing")
                    else:
                        artifact_errors.extend(validate_payload("worker_queue", read_json(worker_path)))
            except (OSError, json.JSONDecodeError, ValueError) as exc:
                payload = {}
                artifact_errors.append(f"evidence_unreadable:{type(exc).__name__}")
        artifact_results[name] = {
            "status": "PASS" if not artifact_errors else "BLOCKED",
            "errors": artifact_errors,
            "metadata_file": str((folder / "ci_run_metadata.json").relative_to(args.artifact_root)),
            "evidence_file": str(evidence_path.relative_to(args.artifact_root)) if evidence_path.exists() else None,
            "job_id": metadata.get("job_id"),
            "job_status": metadata.get("job_status"),
            "artifact_name": name,
        }

    gate_results = {}
    for gate, required_artifacts in GATE_TO_ARTIFACTS.items():
        failed = [name for name in required_artifacts if artifact_results.get(name, {}).get("status") != "PASS"]
        gate_results[gate] = {
            "status": "PASS" if not failed else "BLOCKED",
            "required_artifacts": required_artifacts,
            "failed_artifacts": failed,
        }

    report = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "workflow": "full-platform-acceptance",
        "run_id": args.run_id,
        "run_attempt": args.run_attempt,
        "repository": expected_repository,
        "commit_sha": args.commit_sha.lower(),
        "recorded_by": args.recorded_by.strip(),
        "reviewed_by": args.reviewed_by.strip() or None,
        "review_status": "human_review_recorded" if args.reviewed_by.strip() else "not_reviewed",
        "artifact_root": str(args.artifact_root.resolve()),
        "artifact_results": artifact_results,
        "checks": gate_results,
        "technical_gates_passed": sum(item["status"] == "PASS" for item in gate_results.values()),
        "technical_gates_total": len(gate_results),
        "overall_status": "PASS" if all(item["status"] == "PASS" for item in gate_results.values()) else "BLOCKED",
        "limitations": [
            "This validates hosted technical artifacts from one workflow run/commit only.",
            "It does not close CRM, staging, real-company data, business-policy or independent penetration-test gates.",
            "The reviewer must inspect job logs and vulnerability findings before approving release readiness.",
        ],
    }
    # Automated CI creates an unreviewed aggregate. The verifier intentionally
    # ignores it for gate promotion until a human reruns the importer with
    # --reviewed-by after inspecting the underlying job logs.
    reports_dir = ROOT / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    if not args.reviewed_by.strip():
        # An automated, unreviewed run must never leave a prior reviewer attestation
        # in place where the verifier could continue to consume stale evidence.
        stale_closure = reports_dir / "hosted_gate_closure.json"
        stale_closure.unlink(missing_ok=True)
    filename = "hosted_gate_closure.json" if args.reviewed_by.strip() else "hosted_evidence_aggregate.json"
    out = reports_dir / filename
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"overall_status": report["overall_status"],
                      "technical_gates_passed": report["technical_gates_passed"],
                      "technical_gates_total": report["technical_gates_total"],
                      "report": str(out.relative_to(ROOT))}, indent=2))
    return 0 if report["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
