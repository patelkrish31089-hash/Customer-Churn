[CmdletBinding()]
param([string]$ReviewedBy = $env:USERNAME)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Python = Join-Path $Root '.venv-local\Scripts\python.exe'
if (-not (Test-Path $Python)) { throw 'Local virtual environment missing. Run .\scripts\run_local_demo.ps1 first.' }
if ([string]::IsNullOrWhiteSpace($ReviewedBy)) { throw 'Provide -ReviewedBy with a reviewer identifier.' }
Push-Location $Root
try {
    foreach ($Stage in @('core','runtime','migrations','product','synthetic','browser','report')) {
        Write-Host "`n=== Local verification stage: $Stage ===" -ForegroundColor Cyan
        & $Python 'scripts/verify.py' '--stage' $Stage
        if ($LASTEXITCODE -ne 0) { throw "Verification stage '$Stage' failed (exit $LASTEXITCODE)." }
    }
    Write-Host "`n=== Local demo acceptance profile ===" -ForegroundColor Cyan
    & $Python 'scripts/local_demo_acceptance.py' '--reviewed-by' $ReviewedBy
    if ($LASTEXITCODE -ne 0) { throw "Local demo acceptance did not pass (exit $LASTEXITCODE)." }
    Write-Host "`nLocal-demo acceptance completed. Review reports/local_demo_acceptance.json and reports/verification.md." -ForegroundColor Green
} finally { Pop-Location }
