from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def request(url: str, method: str = "GET", body: dict | None = None, token: str | None = None):
    headers = {"Accept": "application/json"}
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode("utf-8")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=3) as response:
            raw = response.read()
            return response.status, response.headers.get("Content-Type", ""), raw
    except urllib.error.HTTPError as exc:
        return exc.code, exc.headers.get("Content-Type", ""), exc.read()


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="churn-http-smoke-") as temp:
        temp_path = Path(temp)
        db_path = temp_path / "runtime.sqlite"
        env = os.environ.copy()
        env.update({
            "APP_ENV": "test",
            "DATABASE_URL": f"sqlite:///{db_path}",
            "UPLOAD_DIR": str(temp_path / "uploads"),
            "ARTIFACT_DIR": str(temp_path / "artifacts"),
            "LOG_LEVEL": "WARNING",
        })
        subprocess.run([sys.executable, "-m", "app.cli", "init-db"], cwd=ROOT, env=env,
                       check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
        subprocess.run([sys.executable, "-m", "app.cli", "create-admin", "--username", "runtime-admin",
                        "--password", "runtime-smoke-password-123"], cwd=ROOT, env=env,
                       check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)

        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        process = subprocess.Popen([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1",
                                    "--port", str(port), "--log-level", "warning"], cwd=ROOT, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        try:
            deadline = time.time() + 20
            live = ready = None
            while time.time() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("Uvicorn exited before becoming ready")
                try:
                    live = request(base + "/api/v1/health/live")
                    ready = request(base + "/api/v1/health/ready")
                    if live[0] == 200 and ready[0] == 200:
                        break
                except Exception:
                    pass
                time.sleep(0.2)
            if not live or live[0] != 200 or not ready or ready[0] != 200:
                raise RuntimeError(f"Health checks failed: live={live}, ready={ready}")

            status, content_type, page = request(base + "/")
            if status != 200 or "text/html" not in content_type or b"Churn" not in page:
                raise RuntimeError("Dashboard root did not return the expected HTML document")

            status, _, login = request(base + "/api/v1/auth/login", "POST",
                                       {"username": "runtime-admin", "password": "runtime-smoke-password-123"})
            if status != 200:
                raise RuntimeError(f"Login failed: HTTP {status}")
            token = json.loads(login)["access_token"]
            me_status, _, me = request(base + "/api/v1/auth/me", token=token)
            if me_status != 200 or json.loads(me).get("role") != "admin":
                raise RuntimeError("Authenticated /auth/me request failed")
            logout_status, _, _ = request(base + "/api/v1/auth/logout", "POST", token=token)
            revoked_status, _, _ = request(base + "/api/v1/auth/me", token=token)
            if logout_status != 200 or revoked_status != 401:
                raise RuntimeError("Logout did not revoke the runtime session")

            print(json.dumps({"liveness_http": live[0], "readiness_http": ready[0],
                              "dashboard_http": status, "login_http": 200, "auth_me_http": me_status,
                              "logout_http": logout_status, "revoked_session_http": revoked_status,
                              "server_shutdown": "graceful"}, indent=2))
            return 0
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            if process.stdout:
                process.stdout.close()


if __name__ == "__main__":
    raise SystemExit(main())
