from __future__ import annotations

import json
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    workflow_path = ROOT / ".github/workflows/ci.yml"
    workflow = yaml.load(workflow_path.read_text(encoding="utf-8"), Loader=yaml.BaseLoader)
    events = workflow.get("on", {})
    if not isinstance(events, dict) or "workflow_dispatch" not in events:
        raise AssertionError("CI workflow must support a manual workflow_dispatch run")
    jobs = workflow.get("jobs", {})
    required_jobs = {
        "clean-install-acceptance", "quality-security-toolchain", "backend-postgresql",
        "docker-compose-runtime", "browser-e2e-accessibility", "mlops-adapter-runtime",
        "airflow-dag-runtime", "aggregate-acceptance-evidence",
    }
    missing = sorted(required_jobs - set(jobs))
    if missing:
        raise AssertionError(f"Required acceptance jobs are missing: {missing}")

    job_steps: dict[str, list[dict]] = {}
    for name, job in jobs.items():
        job_steps[name] = job.get("steps", [])

    for name, required in {
        "clean-install-acceptance": ["scripts/clean_install_acceptance.py"],
        "quality-security-toolchain": ["requirements-advanced-ml.txt", "requirements-explainability.txt",
                                       "scripts/quality_security_acceptance.py"],
        "backend-postgresql": ["python -m pip check", "alembic upgrade head",
                                "scripts/postgres_runtime_smoke.py", "scripts/worker_queue_smoke.py"],
        "docker-compose-runtime": ["scripts/docker_runtime_smoke.sh"],
        "browser-e2e-accessibility": ["playwright install --with-deps chromium", "npm install --no-save axe-core",
                                      "scripts/browser_e2e.py", "scripts/browser_bridge_e2e.py"],
        "mlops-adapter-runtime": ["requirements-mlops-optional.txt", "scripts/mlops_adapter_smoke.py"],
        "airflow-dag-runtime": ["constraints-${AIRFLOW_VERSION}", "scripts/airflow_dag_runtime_smoke.sh"],
    }.items():
        contents = "\n".join(str(step.get("run", "")) for step in job_steps[name])
        absent = [term for term in required if term not in contents]
        if absent:
            raise AssertionError(f"CI job {name} is missing required acceptance steps: {absent}")

    # Clean-install acceptance must use supported runtimes and an actual fresh-venv harness.
    clean_job = jobs["clean-install-acceptance"]
    python_versions = clean_job.get("strategy", {}).get("matrix", {}).get("python-version", [])
    if set(python_versions) != {"3.11", "3.12"}:
        raise AssertionError("clean-install-acceptance must verify Python 3.11 and 3.12")
    clean_uses = [str(step.get("uses", "")) for step in job_steps["clean-install-acceptance"]]
    if not any(value.startswith("actions/setup-python@") for value in clean_uses):
        raise AssertionError("clean-install-acceptance must provision its Python interpreter")
    if not any(value.startswith("actions/setup-node@") for value in clean_uses):
        raise AssertionError("clean-install-acceptance must provision Node.js for frontend syntax checks")

    # Docker Compose creates and tests its own PostgreSQL service, so it must not
    # be skipped when the separate hosted PostgreSQL matrix fails.
    docker_needs = jobs["docker-compose-runtime"].get("needs", [])
    if isinstance(docker_needs, str):
        docker_needs = [docker_needs]
    if "backend-postgresql" in docker_needs:
        raise AssertionError("docker-compose-runtime must run independently of backend-postgresql")

    aggregate_job = jobs["aggregate-acceptance-evidence"]
    if aggregate_job.get("if") != "always()":
        raise AssertionError("aggregate-acceptance-evidence must run even when an upstream gate fails")
    aggregate_needs = aggregate_job.get("needs", [])
    if isinstance(aggregate_needs, str):
        aggregate_needs = [aggregate_needs]
    expected_upstream = required_jobs - {"aggregate-acceptance-evidence"}
    if set(aggregate_needs) != expected_upstream:
        raise AssertionError("aggregate-acceptance-evidence must wait for every independent technical evidence job")
    aggregate_contents = "\n".join(str(step.get("run", "")) for step in job_steps["aggregate-acceptance-evidence"])
    for marker in ("scripts/merge_hosted_evidence.py", "--expected-repository", "--run-attempt", "--commit-sha", "--recorded-by"):
        if marker not in aggregate_contents:
            raise AssertionError(f"Hosted artifact aggregation is missing provenance guard: {marker}")
    if "--reviewed-by" in aggregate_contents:
        raise AssertionError("Automated CI aggregation must not impersonate a human reviewer")
    if not any(step.get("uses", "").startswith("actions/download-artifact@") for step in job_steps["aggregate-acceptance-evidence"]):
        raise AssertionError("Hosted aggregation must download artifacts from the current workflow run")

    # Verify the PostgreSQL job is backed by a real service container, not a SQLite substitute.
    postgres_service = jobs["backend-postgresql"].get("services", {}).get("postgres", {})
    if not str(postgres_service.get("image", "")).startswith("postgres:"):
        raise AssertionError("backend-postgresql must provision a PostgreSQL service container")
    postgres_env = jobs["backend-postgresql"].get("env", {})
    if "postgresql+psycopg://" not in str(postgres_env.get("DATABASE_URL", "")):
        raise AssertionError("backend-postgresql must target the PostgreSQL service through psycopg")
    for name, job in jobs.items():
        try:
            timeout_minutes = int(job.get("timeout-minutes", "0"))
        except (TypeError, ValueError):
            timeout_minutes = 0
        if timeout_minutes < 1 or timeout_minutes > 60:
            raise AssertionError(f"CI job {name} must have an explicit timeout of at most 60 minutes")

    # Every job publishes its own execution evidence even when the job fails.
    for name, steps in job_steps.items():
        uploaded = any(step.get("uses", "").startswith("actions/upload-artifact@") and
                       step.get("if", "") == "always()" for step in steps)
        if not uploaded:
            raise AssertionError(f"CI job {name} does not upload evidence with if: always()")
        if not any("scripts/write_ci_metadata.py" in str(step.get("run", "")) and
                   step.get("if", "") == "always()" for step in steps):
            raise AssertionError(f"CI job {name} does not write run/commit provenance metadata")
        if not any(("reports/ci_run_metadata.json" in str(step.get("with", {}).get("path", "")) or
                    "reports/*.json" in str(step.get("with", {}).get("path", "")))
                   for step in steps if step.get("uses", "").startswith("actions/upload-artifact@")):
            raise AssertionError(f"CI job {name} does not upload run/commit provenance metadata")

    required_paths = ["scripts/clean_install_acceptance.py", "scripts/quality_security_acceptance.py",
                      "scripts/write_ci_metadata.py", "scripts/merge_hosted_evidence.py",
                      "scripts/postgres_runtime_smoke.py", "scripts/worker_queue_smoke.py", "scripts/docker_runtime_smoke.sh",
                      "scripts/browser_e2e.py", "scripts/browser_bridge_e2e.py", "scripts/mlops_adapter_smoke.py",
                      "scripts/airflow_dag_runtime_smoke.sh", "scripts/source_security_smoke.py",
                      "scripts/merge_local_evidence.py", "scripts/run_acceptance.ps1", "scripts/sqlite_worker_runtime_smoke.py"]
    absent_paths = [path for path in required_paths if not (ROOT / path).is_file()]
    if absent_paths:
        raise AssertionError(f"CI references missing local scripts: {absent_paths}")
    clean_harness = (ROOT / "scripts/clean_install_acceptance.py").read_text(encoding="utf-8")
    for marker in ("system_site_packages=False", "requirements-dev.txt", "requirements-advanced-ml.txt",
                   "requirements-explainability.txt", "isolated_venv_check", "installed_package_inventory",
                   "base_report[\"steps\"].append(freeze)", "pip", "pytest", "-W", "error"):
        if marker not in clean_harness:
            raise AssertionError(f"Clean-install harness is missing acceptance marker: {marker}")
    quality_harness = (ROOT / "scripts/quality_security_acceptance.py").read_text(encoding="utf-8")
    for marker in ("pip", "check", "ruff", "bandit", "pip_audit", "source_security_smoke.py"):
        if marker not in quality_harness:
            raise AssertionError(f"Quality/security harness is missing acceptance marker: {marker}")

    result = {
        "status": "passed", "workflow": str(workflow_path.relative_to(ROOT)),
        "manual_dispatch": True, "jobs": sorted(jobs),
        "evidence_uploaded_from_every_job": True,
        "required_acceptance_scripts_present": required_paths,
        "note": "Static workflow contract validation only; remote GitHub Actions execution has not been observed.",
    }
    report = ROOT / "reports" / "ci_workflow_contract_evidence.json"
    report.parent.mkdir(exist_ok=True)
    report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
