from __future__ import annotations

"""Review machine-local acceptance evidence without pretending it is hosted CI.

Only technical runtime gates can be closed here. The report is tied to the
current source tree digest and requires a named reviewer. Company-owned gates
(CRM, staging, real data, policy approval and independent penetration testing)
are intentionally outside this importer.
"""

import argparse
import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from scripts.merge_hosted_evidence import validate_payload

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
SOURCE_SUFFIXES = {".py", ".yml", ".yaml", ".toml", ".txt", ".ini", ".ps1", ".sh", ".sql", ".js", ".jsx", ".ts", ".tsx", ".html", ".css", ".json", ".md"}
SOURCE_NAMES = {".gitignore", ".dockerignore", "Dockerfile", "alembic.ini"}
EXCLUDED_PARTS = {
    ".git", ".venv", ".venv-v12", ".venv-v14", "__pycache__", ".pytest_cache", ".ruff_cache",
    "node_modules", "reports", "data", "artifacts", "uploads",
}

# For every local gate, all evidence inputs listed here must exist and pass.
LOCAL_EVIDENCE: dict[str, tuple[tuple[str, str], ...]] = {
    "clean_virtual_environment_install": (("clean_install_acceptance.json", "clean_install"),),
    "quality_and_security_toolchain": (("quality_security_acceptance.json", "quality_security"),),
    "postgresql_runtime": (("postgresql_runtime_evidence.json", "postgresql"),
                          ("worker_queue_runtime_evidence.json", "worker_queue")),
    "docker_runtime": (("docker_runtime_evidence.json", "docker"),),
    "mlops_runtime": (("mlops_runtime_evidence.json", "mlops"), ("airflow_dag_evidence.json", "airflow")),
}


def source_tree_sha256(root: Path = ROOT) -> str:
    """Hash first-party source/config files; exclude generated reports and local data."""
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*")):
        if not path.is_file() or (path.suffix.lower() not in SOURCE_SUFFIXES and path.name not in SOURCE_NAMES):
            continue
        relative = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        digest.update(relative.as_posix().encode("utf-8"))
        digest.update(b"\0")
        try:
            digest.update(path.read_bytes())
        except OSError as exc:
            raise RuntimeError(f"Could not hash source file {relative}: {exc}") from exc
        digest.update(b"\0")
    return digest.hexdigest()


def read_payload(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Evidence root must be a JSON object")
    return value


def validate_local_gate(gate: str, reports: Path) -> dict[str, Any]:
    evidence_results: list[dict[str, Any]] = []
    errors: list[str] = []
    for filename, kind in LOCAL_EVIDENCE[gate]:
        path = reports / filename
        if not path.is_file():
            evidence_results.append({"file": filename, "status": "BLOCKED", "errors": ["evidence_file_missing"]})
            errors.append(f"{filename}:evidence_file_missing")
            continue
        try:
            payload = read_payload(path)
            payload_errors = validate_payload(kind, payload)
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            payload_errors = [f"evidence_unreadable:{type(exc).__name__}"]
        evidence_results.append({
            "file": filename,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "status": "PASS" if not payload_errors else "BLOCKED",
            "errors": payload_errors,
        })
        errors.extend(f"{filename}:{error}" for error in payload_errors)
    return {
        "status": "PASS" if not errors else "BLOCKED",
        "required_evidence": [name for name, _ in LOCAL_EVIDENCE[gate]],
        "evidence": evidence_results,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate local technical gate evidence for the current source tree.")
    parser.add_argument("--reviewed-by", required=True, help="Reviewer identifier; do not use a secret or account token")
    args = parser.parse_args()
    reviewer = args.reviewed_by.strip()
    if not reviewer:
        parser.error("--reviewed-by cannot be blank")

    REPORTS.mkdir(parents=True, exist_ok=True)
    checks = {gate: validate_local_gate(gate, REPORTS) for gate in LOCAL_EVIDENCE}
    source_digest = source_tree_sha256(ROOT)
    report = {
        "schema_version": 1,
        "evidence_type": "reviewed_local_acceptance",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_tree_sha256": source_digest,
        "reviewed_by": reviewer,
        "machine": {"platform": platform.platform(), "python": sys.version.split()[0]},
        "checks": checks,
        "technical_gates_passed": sum(item["status"] == "PASS" for item in checks.values()),
        "technical_gates_total": len(checks),
        "overall_status": "PASS" if all(item["status"] == "PASS" for item in checks.values()) else "BLOCKED",
        "limitations": [
            "This report is self-reviewed local evidence, not a hosted CI attestation.",
            "Evidence is bound to the current source/config tree digest; any source/config change invalidates this report.",
            "CRM, hosted staging, real-company model validation, business-policy sign-off and independent penetration testing are not closable by local technical evidence.",
            "Reviewer must inspect the referenced logs and underlying test output before approving each gate.",
        ],
    }
    output = REPORTS / "local_gate_closure.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "overall_status": report["overall_status"],
        "technical_gates_passed": report["technical_gates_passed"],
        "technical_gates_total": report["technical_gates_total"],
        "blocked_gates": [name for name, result in checks.items() if result["status"] != "PASS"],
        "report": str(output.relative_to(ROOT)),
        "source_tree_sha256": source_digest,
    }, indent=2))
    return 0 if report["overall_status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
