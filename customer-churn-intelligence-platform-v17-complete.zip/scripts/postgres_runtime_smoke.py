from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import create_engine, inspect, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session


def main() -> int:
    database_url = os.getenv("DATABASE_URL", "").strip()
    if not database_url.startswith(("postgresql+psycopg://", "postgresql://")):
        print(json.dumps({"status": "blocked", "reason": "DATABASE_URL must target PostgreSQL"}))
        return 2

    from app.models import AuditEvent, Customer, Invoice, Payment, Subscription, User
    from app.security import hash_password

    engine = create_engine(database_url, pool_pre_ping=True, connect_args={"connect_timeout": 5})
    suffix = uuid.uuid4().hex[:12]
    username = f"pg-smoke-{suffix}"
    customer_ref = f"PG-SMOKE-CUST-{suffix}"
    subscription_ref = f"PG-SMOKE-SUB-{suffix}"
    invoice_ref = f"PG-SMOKE-INV-{suffix}"
    payment_ref = f"PG-SMOKE-PAY-{suffix}"
    evidence: dict = {"status": "failed", "database_engine": "postgresql"}
    try:
        with engine.connect() as conn:
            server_version = conn.execute(text("select version()")).scalar_one()
            revision = conn.execute(text("select version_num from alembic_version")).scalar_one()
            table_names = set(inspect(conn).get_table_names())
            required = {"users", "customers", "subscriptions", "invoices", "payments", "session_tokens", "audit_events", "background_jobs"}
            missing = sorted(required - table_names)
            if missing:
                raise AssertionError(f"Required migrated PostgreSQL tables are missing: {missing}")

        user_id = customer_id = subscription_id = invoice_id = payment_id = None
        with Session(engine, expire_on_commit=False) as db:
            user = User(username=username, password_hash=hash_password("pg-runtime-smoke-password"), role="admin")
            customer = Customer(external_id=customer_ref, name="PostgreSQL runtime smoke",
                                email=f"{suffix}@example.invalid", source_name="verification_fixture")
            db.add_all([user, customer])
            db.flush()
            subscription = Subscription(external_id=subscription_ref, customer_id=customer.id,
                                        plan="Verification", status="active",
                                        start_date=datetime.now(timezone.utc), mrr=Decimal("19.95"),
                                        currency="USD", source_name="verification_fixture")
            db.add(subscription)
            db.flush()
            invoice = Invoice(external_id=invoice_ref, customer_id=customer.id,
                              subscription_id=subscription.id, invoice_date=datetime.now(timezone.utc),
                              amount=Decimal("19.95"), currency="USD", status="paid",
                              source_name="verification_fixture")
            db.add(invoice)
            db.flush()
            payment = Payment(external_id=payment_ref, customer_id=customer.id, invoice_id=invoice.id,
                              payment_date=datetime.now(timezone.utc), amount=Decimal("19.95"),
                              currency="USD", status="succeeded", source_name="verification_fixture")
            db.add(payment)
            db.commit()
            user_id, customer_id, subscription_id, invoice_id, payment_id = (
                user.id, customer.id, subscription.id, invoice.id, payment.id
            )

            # Numeric precision must survive a database round trip exactly.
            persisted_mrr = db.get(Subscription, subscription_id).mrr
            persisted_invoice = db.get(Invoice, invoice_id).amount
            persisted_payment = db.get(Payment, payment_id).amount
            if (Decimal(persisted_mrr) != Decimal("19.95") or
                    Decimal(persisted_invoice) != Decimal("19.95") or
                    Decimal(persisted_payment) != Decimal("19.95")):
                raise AssertionError("PostgreSQL Numeric(18,2) round trip changed a monetary value")

            # Unique external customer identity must be enforced by the live database.
            unique_enforced = False
            try:
                with db.begin_nested():
                    db.add(Customer(external_id=customer_ref, name="Duplicate should fail"))
                    db.flush()
            except IntegrityError:
                unique_enforced = True
            if not unique_enforced:
                raise AssertionError("Customer external_id uniqueness was not enforced")

            # Foreign-key integrity must be enforced by the live database.
            foreign_key_enforced = False
            try:
                with db.begin_nested():
                    db.add(Subscription(external_id=f"{subscription_ref}-bad-fk", customer_id=2_000_000_000,
                                        plan="Invalid", status="active", start_date=datetime.now(timezone.utc),
                                        mrr=Decimal("1.00"), currency="USD"))
                    db.flush()
            except IntegrityError:
                foreign_key_enforced = True
            if not foreign_key_enforced:
                raise AssertionError("Subscription customer foreign key was not enforced")

            # Rollback must leave no row behind.
            rollback_ref = f"PG-SMOKE-ROLLBACK-{suffix}"
            transaction = db.begin_nested()
            db.add(Customer(external_id=rollback_ref, name="Rollback fixture"))
            db.flush()
            transaction.rollback()
            db.expire_all()
            if db.scalar(select(Customer.id).where(Customer.external_id == rollback_ref)) is not None:
                raise AssertionError("PostgreSQL transaction rollback retained an inserted row")

        # Exercise the FastAPI auth path against the same PostgreSQL schema and data.
        from fastapi.testclient import TestClient
        from app.db import get_db
        from app.main import app

        def override_db():
            with Session(engine, expire_on_commit=False) as db:
                yield db

        app.dependency_overrides[get_db] = override_db
        try:
            with TestClient(app) as client:
                ready = client.get("/api/v1/health/ready")
                if ready.status_code != 200:
                    raise AssertionError(f"PostgreSQL readiness API failed: {ready.status_code} {ready.text}")
                login = client.post("/api/v1/auth/login", json={
                    "username": username, "password": "pg-runtime-smoke-password"
                })
                if login.status_code != 200:
                    raise AssertionError(f"PostgreSQL authentication failed: {login.status_code} {login.text}")
                token = login.json()["access_token"]
                me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
                if me.status_code != 200 or me.json().get("username") != username:
                    raise AssertionError("PostgreSQL-authenticated identity read-back failed")
                logout = client.post("/api/v1/auth/logout", headers={"Authorization": f"Bearer {token}"})
                if logout.status_code != 200:
                    raise AssertionError("PostgreSQL logout failed")
                revoked = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
                if revoked.status_code != 401:
                    raise AssertionError("PostgreSQL session revocation was not enforced")
        finally:
            app.dependency_overrides.pop(get_db, None)

        # Read committed data from a new connection to prove persistence across sessions.
        with Session(engine) as db:
            if db.get(Customer, customer_id) is None or db.get(Payment, payment_id) is None:
                raise AssertionError("Committed PostgreSQL records were not persistent")
            db.delete(db.get(Customer, customer_id))  # FK cascades clear subscription, invoice and payment.
            db.query(AuditEvent).filter_by(actor_id=user_id).delete(synchronize_session=False)
            db.delete(db.get(User, user_id))
            db.commit()

        evidence = {
            "status": "passed", "database_engine": "postgresql", "server_version": server_version,
            "alembic_revision": revision, "required_tables": sorted(required),
            "checks": {
                "migrated_schema_present": True, "customer_subscription_invoice_payment_crud": True,
                "numeric_18_2_precision": True, "unique_constraint": True, "foreign_key_constraint": True,
                "transaction_rollback": True, "committed_data_persistence": True,
                "api_readiness": True, "authentication": True, "session_revocation": True,
                "fixture_cleanup": True,
            },
            "fixture_provenance": "temporary synthetic verification records; deleted after test",
        }
        print(json.dumps(evidence, indent=2, default=str))
        return 0
    except Exception as exc:
        evidence.update({"error_type": type(exc).__name__, "error": str(exc)[:1200]})
        print(json.dumps(evidence, indent=2, default=str))
        return 1
    finally:
        engine.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
