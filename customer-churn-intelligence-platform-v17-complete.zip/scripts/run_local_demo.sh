#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
CUSTOMERS="${CUSTOMERS:-180}"
PORT="${PORT:-8000}"

if [[ ! "$CUSTOMERS" =~ ^[0-9]+$ ]] || (( CUSTOMERS < 60 || CUSTOMERS > 5000 )); then
  echo "CUSTOMERS must be an integer from 60 to 5000" >&2; exit 2
fi
if [[ ! "$PORT" =~ ^[0-9]+$ ]] || (( PORT < 1024 || PORT > 65535 )); then
  echo "PORT must be an integer from 1024 to 65535" >&2; exit 2
fi

BASE_PYTHON=""
for candidate in python3.12 python3.11 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    version="$($candidate -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
    if [[ "$version" == "3.11" || "$version" == "3.12" ]]; then BASE_PYTHON="$candidate"; break; fi
  fi
done
[[ -n "$BASE_PYTHON" ]] || { echo "Install Python 3.11 or 3.12 first" >&2; exit 2; }

if [[ ! -f .venv-local/pyvenv.cfg ]]; then "$BASE_PYTHON" -m venv .venv-local; fi
PYTHON="$ROOT/.venv-local/bin/python"
if [[ "${SKIP_INSTALL:-0}" != "1" ]]; then
  "$PYTHON" -m pip install --upgrade pip
  "$PYTHON" -m pip install -r requirements.txt
fi

export APP_ENV=development
export DATABASE_URL=sqlite:///./data/churn.db
export UPLOAD_DIR=./data/uploads
export ARTIFACT_DIR=./artifacts
export LOG_LEVEL=INFO
mkdir -p data/uploads artifacts logs
"$PYTHON" -m app.cli init-db
"$PYTHON" -m app.cli seed-demo --customers "$CUSTOMERS" --seed 29
"$PYTHON" scripts/bootstrap_admin.py
echo "Open http://127.0.0.1:${PORT} and sign in with the admin account you created."
"$PYTHON" -m app.worker run --poll-interval 2 --lease-seconds 900 >> logs/worker.log 2>&1 &
WORKER_PID=$!
cleanup() {
  kill "$WORKER_PID" 2>/dev/null || true
  wait "$WORKER_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM
"$PYTHON" -m uvicorn app.main:app --host 127.0.0.1 --port "$PORT"
