[CmdletBinding()]
param(
    [ValidateSet('3.11', '3.12')]
    [string]$PythonVersion = '3.12',
    [string]$ReviewedBy = $env:USERNAME,
    [switch]$SkipInstall,
    [switch]$WithContainers,
    [switch]$WithMLOps,
    [switch]$WithBrowserNative
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Reports = Join-Path $Root 'reports'
$Venv = Join-Path $Root '.venv-v15'
$OriginalPostgresPassword = $env:POSTGRES_PASSWORD
$OriginalDatabaseUrl = $env:DATABASE_URL
New-Item -ItemType Directory -Force -Path $Reports | Out-Null

function Invoke-Checked {
    param([string]$Label, [string]$Executable, [string[]]$Arguments)
    Write-Host "`n=== $Label ===" -ForegroundColor Cyan
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed with exit code $LASTEXITCODE. Inspect the matching report/log under reports/."
    }
}

function Resolve-Python {
    $Launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($Launcher) {
        & $Launcher.Source "-$PythonVersion" -c 'import sys; print(sys.executable)'
        if ($LASTEXITCODE -eq 0) { return @($Launcher.Source, "-$PythonVersion") }
    }
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $Python) { throw 'Python 3.11 or 3.12 is required. Install Python and enable the py launcher.' }
    $Actual = & $Python.Source -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
    if ($Actual.Trim() -ne $PythonVersion) {
        throw "Requested Python $PythonVersion but 'python' resolves to $Actual. Install the matching version or use the py launcher."
    }
    return @($Python.Source)
}

function Invoke-Python {
    param([string]$Label, [string]$Interpreter, [string[]]$Arguments)
    Invoke-Checked -Label $Label -Executable $Interpreter -Arguments $Arguments
}

Push-Location $Root
try {
    if ([string]::IsNullOrWhiteSpace($ReviewedBy)) {
        throw 'Provide -ReviewedBy with the reviewer identifier. This is recorded in the local evidence report.'
    }

    $PythonCommand = Resolve-Python
    $BasePython = $PythonCommand[0]
    $BaseArgs = @()
    if ($PythonCommand.Count -gt 1) { $BaseArgs += $PythonCommand[1] }
    $Version = & $BasePython @BaseArgs -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'
    if ($Version.Trim() -ne $PythonVersion) { throw "Python version mismatch: expected $PythonVersion; got $Version." }

    if (-not $SkipInstall) {
        if (-not (Test-Path (Join-Path $Venv 'pyvenv.cfg'))) {
            Write-Host "Creating project environment at $Venv"
            & $BasePython @BaseArgs -m venv $Venv
            if ($LASTEXITCODE -ne 0) { throw 'Could not create the project virtual environment.' }
        }
        $VenvPython = Join-Path $Venv 'Scripts\python.exe'
        Invoke-Python 'Upgrade pip' $VenvPython @('-m', 'pip', 'install', '--upgrade', 'pip')
        Invoke-Python 'Install project, test, ML and explainability dependencies' $VenvPython @(
            '-m', 'pip', 'install', '-r', 'requirements-dev.txt', '-r',
            'requirements-advanced-ml.txt', '-r', 'requirements-explainability.txt'
        )
    } else {
        $VenvPython = Join-Path $Venv 'Scripts\python.exe'
        if (-not (Test-Path $VenvPython)) { throw "-SkipInstall was specified but $VenvPython does not exist." }
    }

    # A second, disposable venv proves installation is isolated from .venv-v14.
    Invoke-Python 'Fresh isolated installation acceptance' $VenvPython @('scripts/clean_install_acceptance.py')

    foreach ($Stage in @('core', 'runtime', 'migrations', 'product', 'synthetic', 'browser')) {
        Invoke-Python "Local verification stage: $Stage" $VenvPython @('scripts/verify.py', '--stage', $Stage)
    }

    Invoke-Python 'Quality and security toolchain' $VenvPython @('scripts/quality_security_acceptance.py')

    if ($WithBrowserNative) {
        Invoke-Python 'Install Playwright Chromium' $VenvPython @('-m', 'playwright', 'install', 'chromium')
        $Npm = Get-Command npm -ErrorAction SilentlyContinue
        if (-not $Npm) { throw 'Node.js/npm is required for axe-core browser accessibility evidence.' }
        Invoke-Checked 'Install axe-core for the browser audit' $Npm.Source @('install', '--no-save', 'axe-core')
        Invoke-Python 'Native browser journey and axe-core accessibility' $VenvPython @('scripts/browser_e2e.py')
    }

    if ($WithMLOps) {
        Invoke-Python 'Install MLflow and Evidently' $VenvPython @('-m', 'pip', 'install', '-r', 'requirements-mlops-optional.txt')
        # Persist stdout as evidence while preserving the exit code.
        $MLOpsOutput = & $VenvPython 'scripts/mlops_adapter_smoke.py'
        if ($LASTEXITCODE -ne 0) { throw 'MLflow/Evidently smoke failed.' }
        [System.IO.File]::WriteAllText((Join-Path $Reports 'mlops_runtime_evidence.json'), ($MLOpsOutput -join [Environment]::NewLine), (New-Object System.Text.UTF8Encoding($false)))
    }

    if ($WithContainers) {
        $Docker = Get-Command docker -ErrorAction SilentlyContinue
        if (-not $Docker) { throw 'Docker CLI is not installed. Install Docker Desktop and enable the Linux container engine.' }
        Invoke-Checked 'Docker daemon availability' $Docker.Source @('info')
        $Bash = Get-Command bash -ErrorAction SilentlyContinue
        if (-not $Bash) { throw 'Git Bash or WSL bash is required to run scripts/docker_runtime_smoke.sh.' }

        $RandomBytes = New-Object byte[] 32
        $RandomGenerator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try { $RandomGenerator.GetBytes($RandomBytes) } finally { $RandomGenerator.Dispose() }
        $Password = -join ($RandomBytes | ForEach-Object { $_.ToString('x2') })
        $env:POSTGRES_PASSWORD = $Password
        try {
            Invoke-Checked 'Docker Compose build, health, restart, backup and restore smoke' $Bash.Source @('scripts/docker_runtime_smoke.sh')

            Invoke-Checked 'Start disposable PostgreSQL service' $Docker.Source @('compose', 'up', '-d', 'db')
            $env:DATABASE_URL = "postgresql+psycopg://churn:$Password@127.0.0.1:5432/churn"
            $Ready = $false
            for ($Attempt = 0; $Attempt -lt 40; $Attempt++) {
                & $Docker.Source compose exec -T db pg_isready -U churn -d churn *> $null
                if ($LASTEXITCODE -eq 0) { $Ready = $true; break }
                Start-Sleep -Seconds 2
            }
            if (-not $Ready) { throw 'PostgreSQL container did not become ready.' }
            Invoke-Python 'PostgreSQL migrations' $VenvPython @('-m', 'alembic', 'upgrade', 'head')
            $PgOutput = & $VenvPython 'scripts/postgres_runtime_smoke.py'
            if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL live CRUD/constraint/authentication smoke failed.' }
            [System.IO.File]::WriteAllText((Join-Path $Reports 'postgresql_runtime_evidence.json'), ($PgOutput -join [Environment]::NewLine), (New-Object System.Text.UTF8Encoding($false)))
        } finally {
            & $Docker.Source compose down -v --remove-orphans *> $null
        }
    }

    Invoke-Python 'Build reviewed local evidence closure report' $VenvPython @('scripts/merge_local_evidence.py', '--reviewed-by', $ReviewedBy)
    Invoke-Python 'Final acceptance report' $VenvPython @('scripts/verify.py', '--stage', 'report')
    Invoke-Python 'Refresh release manifest' $VenvPython @('scripts/build_manifest.py')

    Write-Host "`nAcceptance run completed. Review reports/verification.md and reports/local_gate_closure.json." -ForegroundColor Green
    Write-Host 'External company gates still require real CRM, staging, company data, business-owner approval and independent assessor evidence.' -ForegroundColor Yellow
    Write-Host 'For hosted Airflow and repeatable cloud-runner verification, run GitHub Actions: full-platform-acceptance.' -ForegroundColor Yellow
}
finally {
    if ($null -ne $OriginalPostgresPassword) { $env:POSTGRES_PASSWORD = $OriginalPostgresPassword }
    else { Remove-Item Env:\POSTGRES_PASSWORD -ErrorAction SilentlyContinue }
    if ($null -ne $OriginalDatabaseUrl) { $env:DATABASE_URL = $OriginalDatabaseUrl }
    else { Remove-Item Env:\DATABASE_URL -ErrorAction SilentlyContinue }
    Pop-Location
}
