#!/usr/bin/env bash
set -Eeuo pipefail

: "${AIRFLOW_HOME:?AIRFLOW_HOME must be set}"
: "${DATABASE_URL:?DATABASE_URL must point to a disposable SQLite app database}"
: "${ARTIFACT_DIR:?ARTIFACT_DIR must be set}"
: "${UPLOAD_DIR:?UPLOAD_DIR must be set}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p reports "$ARTIFACT_DIR" "$UPLOAD_DIR" "$AIRFLOW_HOME"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
export APP_ENV=test
export AIRFLOW__CORE__LOAD_EXAMPLES=False

airflow db migrate
python scripts/smoke_demo.py > reports/airflow_seed_evidence.json
LOGICAL_DATE="$(date -u +%Y-%m-%d)T00:00:00+00:00"
export AIRFLOW_TEST_LOGICAL_DATE="$LOGICAL_DATE"
airflow dags test customer_churn_daily_scoring "$LOGICAL_DATE" \
  --dagfile-path "$ROOT/dags/customer_churn_daily_scoring.py" \
  > reports/airflow_dag_execution.log 2>&1
STATE_OUTPUT="$(airflow tasks states-for-dag-run customer_churn_daily_scoring "$LOGICAL_DATE" --output json)"
printf '%s\n' "$STATE_OUTPUT" > reports/airflow_task_states.json
python - <<'PY'
import json
import os
from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from app.models import PredictionBatch

raw = Path('reports/airflow_task_states.json').read_text(encoding='utf-8')
try:
    state_data = json.loads(raw)
except json.JSONDecodeError as exc:
    raise SystemExit(f'Airflow task-state output was not JSON: {exc}')
found_success = False
stack = [state_data]
while stack:
    item = stack.pop()
    if isinstance(item, dict):
        if item.get('task_id') == 'score_population':
            state = str(item.get('state', item.get('task_state', ''))).lower()
            found_success = state in {'success', 'successful'}
        stack.extend(item.values())
    elif isinstance(item, list):
        stack.extend(item)
if not found_success:
    raise SystemExit('Airflow score_population task state was not success; inspect reports/airflow_task_states.json')
engine = create_engine(os.environ['DATABASE_URL'])
try:
    with Session(engine) as db:
        batches = db.query(PredictionBatch).order_by(PredictionBatch.created_at.desc()).limit(1).all()
        if not batches:
            raise SystemExit('Airflow task completed but did not persist a PredictionBatch')
        batch = batches[0]
        if batch.status != 'completed' or batch.succeeded_count < 1 or batch.failed_count:
            raise SystemExit(f'Airflow batch did not complete cleanly: status={batch.status}, succeeded={batch.succeeded_count}, failed={batch.failed_count}')
        evidence = {
            'status': 'passed', 'airflow_version': __import__('airflow').__version__,
            'dag_id': 'customer_churn_daily_scoring', 'task_id': 'score_population',
            'logical_date': os.environ.get('AIRFLOW_TEST_LOGICAL_DATE'),
            'task_state': 'success', 'batch_id': batch.batch_id,
            'release_id': batch.release_id, 'requested': batch.requested_count,
            'succeeded': batch.succeeded_count, 'failed': batch.failed_count,
            'batch_status': batch.status,
            'scope': 'Airflow dag test execution; a live scheduler/executor service is not asserted',
            'data_provenance': 'synthetic demo data only'
        }
        Path('reports/airflow_dag_evidence.json').write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(evidence, indent=2))
finally:
    engine.dispose()
PY
