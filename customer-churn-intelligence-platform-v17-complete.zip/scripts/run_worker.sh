#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PYTHON="${PYTHON:-$ROOT/.venv-local/bin/python}"
if [[ ! -x "$PYTHON" ]]; then PYTHON="${PYTHON_FALLBACK:-python3}"; fi
"$PYTHON" -m app.worker run --poll-interval "${WORKER_POLL_INTERVAL:-2}" --lease-seconds "${WORKER_LEASE_SECONDS:-900}"
