from __future__ import annotations

"""Execute and capture the complete first-party quality/security toolchain."""

import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(parents=True, exist_ok=True)

COMMANDS = [
    ("pip_check", [sys.executable, "-m", "pip", "check"], 120),
    ("ruff", ["ruff", "check", "app", "tests", "scripts"], 180),
    ("bandit", ["bandit", "-q", "-r", "app", "-ll"], 180),
    ("pip_audit", [sys.executable, "-m", "pip_audit", "-r", "requirements-dev.txt",
                    "-r", "requirements-advanced-ml.txt", "-r", "requirements-explainability.txt"], 600),
    ("first_party_ast_security", [sys.executable, "scripts/source_security_smoke.py"], 60),
]


def main() -> int:
    results = []
    started = time.monotonic()
    for name, command, timeout in COMMANDS:
        step_started = time.monotonic()
        try:
            completed = subprocess.run(
                command, cwd=ROOT, text=True, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, timeout=timeout, check=False,
            )
            output = completed.stdout or ""
            exit_code = completed.returncode
            status = "PASS" if exit_code == 0 else "FAIL"
        except subprocess.TimeoutExpired as exc:
            output = exc.stdout or ""
            if isinstance(output, bytes):
                output = output.decode("utf-8", errors="replace")
            output += f"\nTimed out after {timeout} seconds."
            exit_code = None
            status = "FAIL"
        except OSError as exc:
            output = f"Command unavailable: {type(exc).__name__}: {exc}"
            exit_code = None
            status = "FAIL"

        safe_name = "".join(char if char.isalnum() or char in "-_" else "_" for char in name)
        log_path = REPORTS / f"quality_security_{safe_name}.log"
        log_path.write_text(output, encoding="utf-8")
        results.append({
            "name": name, "command": command, "status": status, "exit_code": exit_code,
            "duration_seconds": round(time.monotonic() - step_started, 3),
            "log_file": str(log_path.relative_to(ROOT)), "output_tail": output[-3000:],
        })

    passed = all(item["status"] == "PASS" for item in results)
    report = {
        "gate": "quality_and_security_toolchain",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if passed else "FAIL",
        "checks": results,
        "summary": {"passed": sum(item["status"] == "PASS" for item in results),
                    "failed": sum(item["status"] != "PASS" for item in results),
                    "total": len(results)},
        "duration_seconds": round(time.monotonic() - started, 3),
        "scope_note": "Ruff, Bandit, pip-audit and the supplemental AST scanner; this is not a penetration test.",
    }
    output = REPORTS / "quality_security_acceptance.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "summary": report["summary"],
                      "report": str(output.relative_to(ROOT))}, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
