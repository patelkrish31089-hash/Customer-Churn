from __future__ import annotations

"""Run the full dependency install and regression suite inside a fresh isolated venv.

This script intentionally uses only the Python standard library in the caller's
interpreter. It is suitable for a clean GitHub Actions runner and records each
step even when installation or tests fail.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import venv
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports"
REPORTS.mkdir(parents=True, exist_ok=True)


def run_step(name: str, command: list[str], env: dict[str, str], timeout: int) -> dict:
    started = time.monotonic()
    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            check=False,
        )
        output = result.stdout or ""
        exit_code = result.returncode
        status = "PASS" if exit_code == 0 else "FAIL"
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "")
        if isinstance(output, bytes):
            output = output.decode("utf-8", errors="replace")
        output += f"\nTimed out after {timeout} seconds."
        exit_code = None
        status = "FAIL"
    except OSError as exc:
        output = f"Could not execute command: {type(exc).__name__}: {exc}"
        exit_code = None
        status = "FAIL"

    safe_name = "".join(char if char.isalnum() or char in "-_" else "_" for char in name)
    log_path = REPORTS / f"clean_install_{safe_name}.log"
    log_path.write_text(output, encoding="utf-8")
    return {
        "name": name,
        "command": command,
        "status": status,
        "exit_code": exit_code,
        "duration_seconds": round(time.monotonic() - started, 3),
        "log_file": str(log_path.relative_to(ROOT)),
        "output_tail": output[-3000:],
    }


def main() -> int:
    created = time.monotonic()
    base_report = {
        "gate": "clean_virtual_environment_install",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "host_python": sys.version.split()[0],
        "requested_python": "Python 3.11 or 3.12 (enforced by CI matrix)",
        "isolated_environment": True,
        "system_site_packages": False,
        "steps": [],
    }

    with tempfile.TemporaryDirectory(prefix="churn-clean-install-") as temporary:
        venv_dir = Path(temporary) / "venv"
        try:
            venv.EnvBuilder(with_pip=True, clear=True, system_site_packages=False).create(venv_dir)
        except Exception as exc:  # environment creation errors are retained as a gate failure
            base_report["status"] = "FAIL"
            base_report["error"] = f"venv creation failed: {type(exc).__name__}: {exc}"
            (REPORTS / "clean_install_acceptance.json").write_text(
                json.dumps(base_report, indent=2) + "\n", encoding="utf-8"
            )
            return 1

        if os.name == "nt":
            python = str(venv_dir / "Scripts" / "python.exe")
        else:
            python = str(venv_dir / "bin" / "python")

        env = os.environ.copy()
        env.update({
            "PYTHONNOUSERSITE": "1",
            "APP_ENV": "test",
            "DATABASE_URL": "sqlite:///:memory:",
            "OMP_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
        })

        commands = [
            ("isolated_venv_check", [python, "-c", "import sys; assert sys.prefix != sys.base_prefix; print(sys.prefix)"], 30),
            ("upgrade_pip", [python, "-m", "pip", "install", "--upgrade", "pip"], 600),
            ("install_all_declared_groups", [python, "-m", "pip", "install", "-r", "requirements-dev.txt",
                                               "-r", "requirements-advanced-ml.txt", "-r",
                                               "requirements-explainability.txt"], 1800),
            ("pip_check", [python, "-m", "pip", "check"], 120),
            ("python_compile", [python, "-m", "compileall", "-q", "app", "tests", "scripts"], 120),
            ("strict_pytest", [python, "-m", "pytest", "-q", "-W", "error", "--junitxml",
                                "reports/junit-clean-install.xml"], 600),
        ]
        for name, command, timeout in commands:
            step = run_step(name, command, env, timeout)
            base_report["steps"].append(step)
            if step["status"] != "PASS":
                break

        if base_report["steps"] and all(step["status"] == "PASS" for step in base_report["steps"]):
            node = shutil.which("node")
            if node:
                step = run_step("frontend_javascript_syntax", [node, "--check", "app/static/app.js"], env, 60)
                base_report["steps"].append(step)
            else:
                base_report["steps"].append({
                    "name": "frontend_javascript_syntax", "status": "FAIL", "exit_code": None,
                    "output_tail": "Node.js 22 must be installed by the runner before this script.",
                })

        # The package inventory is an acceptance step, not merely an unreferenced log.
        # The hosted-evidence importer requires this result before it can close the gate.
        freeze = run_step("installed_package_inventory", [python, "-m", "pip", "freeze", "--all"], env, 120)
        base_report["steps"].append(freeze)
        base_report["package_inventory_log"] = freeze["log_file"]
        base_report["isolated_prefix_verified"] = any(
            step["name"] == "isolated_venv_check" and step["status"] == "PASS"
            for step in base_report["steps"]
        )
        base_report["status"] = (
            "PASS" if base_report["steps"] and all(step["status"] == "PASS" for step in base_report["steps"])
            else "FAIL"
        )
        base_report["duration_seconds"] = round(time.monotonic() - created, 3)

    output = REPORTS / "clean_install_acceptance.json"
    output.write_text(json.dumps(base_report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": base_report["status"], "steps": [
        {"name": step["name"], "status": step["status"]} for step in base_report["steps"]
    ], "report": str(output.relative_to(ROOT))}, indent=2))
    return 0 if base_report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
