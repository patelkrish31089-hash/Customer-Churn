"""Daily prediction DAG. Mount the repository on the Airflow workers as PYTHONPATH."""
from __future__ import annotations

try:  # Airflow 3.x Task SDK; supports Airflow 2.x fallback for compatible deployments.
    from airflow.sdk import dag, task
except ImportError:  # pragma: no cover - depends on optional Airflow runtime
    from airflow.decorators import dag, task
import pendulum


@dag(schedule="0 5 * * *", start_date=pendulum.datetime(2025, 1, 1, tz="UTC"),
     catchup=False, max_active_runs=1, tags=["churn", "mlops", "batch-scoring"],
     doc_md="Daily batch churn scoring using one pinned approved model release per batch.")
def customer_churn_daily_scoring():
    @task(retries=2, retry_delay=pendulum.duration(minutes=5))
    def score_population(logical_date=None):
        from app.db import SessionLocal
        from app.services.ml import score_customer_batch
        if logical_date is None:
            logical_date = pendulum.now("UTC")
        cutoff = logical_date.in_timezone("UTC").replace(hour=0, minute=0, second=0, microsecond=0)
        key = f"airflow-daily-{cutoff.to_date_string()}"
        db = SessionLocal()
        try:
            return score_customer_batch(db, cutoff, key)
        finally:
            db.close()

    score_population()


customer_churn_daily_scoring()
