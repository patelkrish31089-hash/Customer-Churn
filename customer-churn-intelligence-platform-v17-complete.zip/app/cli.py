from __future__ import annotations

import argparse
import sys
from alembic import command
from alembic.config import Config
from app.config import settings
from app.db import SessionLocal
from app.models import User
from app.security import hash_password
from app.demo import seed_demo


def alembic_config() -> Config:
    config = Config("alembic.ini")
    config.set_main_option("sqlalchemy.url", settings.database_url.replace("%", "%%"))
    return config


def main() -> int:
    parser = argparse.ArgumentParser(description="Churn Intelligence Platform command line")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init-db", help="Apply database migrations")
    create = sub.add_parser("create-admin", help="Create the first or another administrator")
    create.add_argument("--username", required=True)
    create.add_argument("--password", required=True)
    demo = sub.add_parser("seed-demo", help="Create clearly-labelled synthetic demo data")
    demo.add_argument("--customers", type=int, default=180)
    demo.add_argument("--seed", type=int, default=29)
    args = parser.parse_args()

    if args.command == "init-db":
        command.upgrade(alembic_config(), "head")
        print("Database migrations applied.")
        return 0
    if args.command == "create-admin":
        db = SessionLocal()
        try:
            if db.query(User).filter_by(username=args.username).first():
                print("Username already exists", file=sys.stderr); return 2
            user = User(username=args.username, password_hash=hash_password(args.password), role="admin")
            db.add(user); db.commit()
            print(f"Administrator created: {user.username} (ID {user.id})")
            return 0
        finally:
            db.close()
    if args.command == "seed-demo":
        if settings.environment == "production":
            print("Demo seeding is disabled in production", file=sys.stderr); return 3
        if args.customers < 60 or args.customers > 5000:
            print("--customers must be between 60 and 5000 to support a meaningful demonstration", file=sys.stderr); return 2
        db = SessionLocal()
        try:
            result = seed_demo(db, args.customers, args.seed)
            print(result)
            return 0
        finally:
            db.close()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
