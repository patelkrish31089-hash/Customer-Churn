from __future__ import annotations

import math
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from sqlalchemy.orm import Session

from app.models import (ChurnLabel, Customer, FeatureSnapshot, Invoice, Prediction,
                        Subscription, UsageEvent)
from app.utils import json_loads


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _month_age(start: datetime, point: datetime) -> int:
    return max(0, (point.year - start.year) * 12 + point.month - start.month)


def overview(db: Session) -> dict:
    customers = db.query(Customer).count()
    subscriptions = db.query(Subscription).count()
    labels = db.query(ChurnLabel).filter(ChurnLabel.entity_scope == "customer",
                                         ChurnLabel.churn_30d.in_([0, 1]),
                                         ChurnLabel.is_censored.is_(False)).all()
    positives = sum(x.churn_30d == 1 for x in labels)
    preds = db.query(Prediction).all()
    bands = {b: sum(p.risk_band == b for p in preds) for b in ("low", "medium", "high")}
    return {"customers": customers, "subscriptions": subscriptions, "mature_labels": len(labels),
            "labeled_churn_rate": positives / len(labels) if labels else None,
            "predictions": len(preds), "risk_bands": bands,
            "data_provenance": "Mixed or synthetic until source provenance is reviewed"}


def cohort_retention(db: Session, max_age_months: int = 36) -> dict:
    """Reconstruct customer, subscription and usage retention at month-age from dated records."""
    if not 1 <= max_age_months <= 120:
        raise ValueError("max_age_months must be between 1 and 120")
    customers = db.query(Customer).filter(Customer.acquisition_date.is_not(None)).all()
    subscriptions = db.query(Subscription).all()
    usage = db.query(UsageEvent).all()
    now = datetime.now(timezone.utc)
    by_customer: dict[int, list[Subscription]] = defaultdict(list)
    for sub in subscriptions:
        by_customer[sub.customer_id].append(sub)
    by_usage: dict[int, list[UsageEvent]] = defaultdict(list)
    for event in usage:
        by_usage[event.customer_id].append(event)
    cohorts: dict[str, list[Customer]] = defaultdict(list)
    for customer in customers:
        acquisition = _aware(customer.acquisition_date)
        if acquisition:
            cohorts[acquisition.strftime("%Y-%m")].append(customer)

    rows = []
    matrices = {"customer": [], "subscription": [], "engagement": []}
    for cohort, members in sorted(cohorts.items()):
        members.sort(key=lambda x: x.id)
        acquired = _aware(members[0].acquisition_date)
        cohort_cells = {kind: [] for kind in matrices}
        max_age = min(max_age_months, max(0, _month_age(acquired, now)))
        last_cell = None
        for age in range(max_age + 1):
            # Measure at month-end so every account acquired in the cohort month has entered observation.
            year = acquired.year + (acquired.month - 1 + age) // 12
            month = (acquired.month - 1 + age) % 12 + 1
            next_year = year + (1 if month == 12 else 0)
            next_month = 1 if month == 12 else month + 1
            month_end = datetime(next_year, next_month, 1, tzinfo=timezone.utc) - timedelta(microseconds=1)
            point = min(month_end, now)
            customer_den = len(members)
            customer_active = 0
            subscription_den = 0
            subscription_active = 0
            engagement_active = 0
            for customer in members:
                customer_subs = by_customer.get(customer.id, [])
                active_for_customer = []
                for sub in customer_subs:
                    start = _aware(sub.start_date)
                    finish = _aware(sub.cancellation_date or sub.end_date)
                    if start and start <= point:
                        subscription_den += 1
                        active = finish is None or finish > point
                        if active and sub.status not in {"cancelled", "canceled", "expired", "ended"}:
                            subscription_active += 1
                            active_for_customer.append(sub)
                if active_for_customer:
                    customer_active += 1
                # Engagement is defined as >=1 usage event in the trailing 30 days.
                engage = any((_aware(e.event_time) is not None and point - _aware(e.event_time) < __import__("datetime").timedelta(days=30)
                              and _aware(e.event_time) <= point) for e in by_usage.get(customer.id, []))
                if engage:
                    engagement_active += 1
            cell = {"age_months": age,
                    "customer_retention": customer_active / customer_den if customer_den else None,
                    "subscription_retention": subscription_active / subscription_den if subscription_den else None,
                    "engagement_retention": engagement_active / customer_den if customer_den else None,
                    "customers_at_risk": customer_den, "subscriptions_at_risk": subscription_den}
            cohort_cells["customer"].append(cell["customer_retention"])
            cohort_cells["subscription"].append(cell["subscription_retention"])
            cohort_cells["engagement"].append(cell["engagement_retention"])
            last_cell = cell
        if last_cell is not None:
            rows.append({"cohort": cohort, "customers": len(members),
                         "current_active_rate": last_cell["customer_retention"],
                         "age_months_observed": len(cohort_cells["customer"]) - 1})
        for kind in matrices:
            matrices[kind].append({"cohort": cohort, "customers": len(members), "values": cohort_cells[kind]})
    return {"method": "dated subscription lifecycle and event records reconstructed by acquisition-month age",
            "rows": rows, "heatmaps": matrices,
            "definitions": {"customer": "share with at least one active subscription at month-age checkpoint",
                            "subscription": "share of subscriptions started by checkpoint and not ended by checkpoint",
                            "engagement": "share of cohort with at least one usage event in preceding 30 days"},
            "limitation": "Reconstruction uses currently stored source records; missing historical status events or incomplete source history can bias estimates. This is not a randomized treatment effect."}


def _km(records: list[tuple[float, bool]]) -> dict[str, Any]:
    if not records:
        return {"points": [], "sample_count": 0}
    survival = 1.0
    greenwood_sum = 0.0
    points = [{"day": 0, "survival": 1.0, "ci_lower": 1.0, "ci_upper": 1.0,
               "at_risk": len(records), "events": 0, "censored": 0}]
    times = sorted({duration for duration, event in records if event})
    for t in times:
        at_risk = sum(duration >= t for duration, _ in records)
        events = sum(duration == t and event for duration, event in records)
        censored = sum(duration == t and not event for duration, event in records)
        if at_risk > events and events:
            survival *= 1.0 - events / at_risk
            greenwood_sum += events / (at_risk * (at_risk - events))
        elif at_risk == events and events:
            survival = 0.0
        if 0 < survival < 1 and greenwood_sum > 0:
            se = survival * math.sqrt(greenwood_sum)
            lower, upper = max(0.0, survival - 1.96 * se), min(1.0, survival + 1.96 * se)
        else:
            lower = upper = survival
        points.append({"day": int(t), "survival": float(survival), "ci_lower": float(lower),
                       "ci_upper": float(upper), "at_risk": int(at_risk),
                       "events": int(events), "censored": int(censored)})
    return {"points": points, "sample_count": len(records)}


def survival_curve(db: Session, group_by_segment: bool = True) -> dict:
    records = []
    by_segment: dict[str, list[tuple[float, bool]]] = defaultdict(list)
    reasons = defaultdict(int)
    now = datetime.now(timezone.utc)
    for customer in db.query(Customer).all():
        subs = db.query(Subscription).filter_by(customer_id=customer.id).all()
        if not subs:
            continue
        starts = [_aware(s.start_date) for s in subs if s.start_date]
        if not starts:
            continue
        start = min(starts)
        terminal = [_aware(s.cancellation_date or s.end_date) for s in subs if s.cancellation_date or s.end_date]
        # Customer churn is observable only after every subscription is terminal.
        event = bool(terminal) and len(terminal) == len(subs)
        finish = max(terminal) if event else now
        duration = float(max(0, (finish - start).days))
        records.append((duration, event))
        by_segment[customer.segment or "unknown"].append((duration, event))
        if event:
            reasons["VOLUNTARY" if any((s.churn_reason or "").lower() in {"voluntary", "customer_request", "customer_cancellation"} for s in subs) else
                    "INVOLUNTARY" if any((s.churn_reason or "").lower() in {"non_payment", "payment_failure", "dunning"} for s in subs) else "OTHER_OR_UNKNOWN"] += 1
    if not records:
        return {"points": [], "sample_count": 0, "groups": {}, "logrank": None}
    result = _km(records)
    groups = {name: _km(group) for name, group in sorted(by_segment.items())} if group_by_segment else {}
    logrank = None
    nonempty = [(name, group) for name, group in sorted(by_segment.items()) if group]
    if len(nonempty) == 2:
        logrank = _logrank_two_groups(nonempty[0][1], nonempty[1][1])
        logrank["groups"] = [nonempty[0][0], nonempty[1][0]]
    result.update({"method": "Kaplan-Meier product-limit estimate with Greenwood 95% pointwise confidence intervals",
                   "groups": groups, "logrank_two_group_test": logrank,
                   "terminal_event_reason_counts": dict(reasons),
                   "censoring": "customers with any subscription lacking a terminal date are right-censored at analysis time",
                   "caveat": "Descriptive; reactivation, simultaneous subscription changes, competing risks and source completeness require company-approved lifecycle policy."})
    return result


def _logrank_two_groups(a: list[tuple[float, bool]], b: list[tuple[float, bool]]) -> dict[str, Any]:
    try:
        from scipy.stats import chi2
    except ImportError:
        return {"available": False, "reason": "scipy_not_installed"}
    observed = expected = variance = 0.0
    for t in sorted({d for d, event in a + b if event}):
        n1 = sum(d >= t for d, _ in a); n2 = sum(d >= t for d, _ in b)
        e1 = sum(d == t and e for d, e in a); e2 = sum(d == t and e for d, e in b)
        n = n1 + n2; events = e1 + e2
        if n <= 1 or events == 0:
            continue
        observed += e1
        expected += events * n1 / n
        variance += (n1 * n2 * events * (n - events)) / (n * n * (n - 1))
    if variance <= 0:
        return {"available": False, "reason": "insufficient_event_variance"}
    statistic = (observed - expected) ** 2 / variance
    return {"available": True, "test": "two-sample log-rank chi-square approximation", "statistic": statistic,
            "degrees_of_freedom": 1, "p_value": float(chi2.sf(statistic, 1)),
            "interpretation": "Association test only; not a causal treatment-effect estimate."}


def feature_summary(db: Session) -> dict:
    snapshots = db.query(FeatureSnapshot).all()
    if not snapshots:
        return {"snapshot_count": 0, "numeric_summary": {}, "missingness": {}}
    buckets: dict[str, list[float]] = defaultdict(list)
    missing: dict[str, int] = defaultdict(int)
    keys = set()
    for snapshot in snapshots:
        features = json_loads(snapshot.features_json)
        keys.update(features)
        for key, value in features.items():
            if isinstance(value, (int, float)) and math.isfinite(float(value)):
                buckets[key].append(float(value))
            elif value is None:
                missing[key] += 1
    summary = {}
    histograms = {}
    outliers = {}
    for key, values in buckets.items():
        arr = np.asarray(values, dtype=float)
        q1, median, q3 = np.quantile(arr, [.25, .5, .75]).tolist()
        iqr = q3 - q1
        summary[key] = {"count": len(values), "mean": float(arr.mean()), "std": float(arr.std(ddof=1)) if len(arr)>1 else 0.0,
                        "min": float(arr.min()), "q1": float(q1), "median": float(median), "q3": float(q3),
                        "max": float(arr.max())}
        counts, edges = np.histogram(arr, bins=min(12, max(3, int(math.sqrt(len(arr))))))
        histograms[key] = [{"lower": float(edges[i]), "upper": float(edges[i+1]), "count": int(counts[i])} for i in range(len(counts))]
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        outliers[key] = {"count": int(((arr < low) | (arr > high)).sum()), "lower_bound": float(low), "upper_bound": float(high)}
    missingness = {key: {"missing_count": missing.get(key, 0), "missing_rate": missing.get(key, 0) / len(snapshots)} for key in sorted(keys)}
    return {"snapshot_count": len(snapshots), "numeric_summary": summary,
            "histograms": histograms, "outlier_review": outliers, "missingness": missingness,
            "note": "EDA uses stored feature snapshots. Outlier flags are review signals, not automatic deletion or proof of invalid data."}


def eda_report(db: Session) -> dict[str, Any]:
    base = feature_summary(db)
    snapshots = db.query(FeatureSnapshot).all()
    numeric = list(base.get("numeric_summary", {}))
    matrix: dict[str, dict[str, float | None]] = {}
    vectors: dict[str, list[float]] = {k: [] for k in numeric}
    for snap in snapshots:
        values = json_loads(snap.features_json)
        for key in numeric:
            value = values.get(key)
            vectors[key].append(float(value) if isinstance(value, (int, float)) and math.isfinite(float(value)) else float("nan"))
    if len(snapshots) >= 3:
        arr = np.column_stack([vectors[k] for k in numeric]) if numeric else np.empty((len(snapshots), 0))
        for i, left in enumerate(numeric):
            matrix[left] = {}
            for j, right in enumerate(numeric):
                valid = np.isfinite(arr[:, i]) & np.isfinite(arr[:, j])
                if valid.sum() >= 3 and np.std(arr[valid, i]) > 0 and np.std(arr[valid, j]) > 0:
                    matrix[left][right] = float(np.corrcoef(arr[valid, i], arr[valid, j])[0, 1])
                else:
                    matrix[left][right] = None
    labels = db.query(ChurnLabel).filter_by(entity_scope="customer", horizon_days=30, is_censored=False).filter(ChurnLabel.churn_30d.in_([0, 1])).all()
    positives = sum(x.churn_30d == 1 for x in labels)
    total = len(labels)
    return {**base, "correlation_matrix": matrix,
            "label_balance": {"mature_binary_labels": total, "churn_positive": positives,
                              "churn_negative": total - positives,
                              "positive_rate": positives / total if total else None},
            "scope": "descriptive EDA only; target-dependent hypothesis tests are not used for model selection"}


def financial_impact_scenario(db: Session, threshold: float, contribution_margin: float,
                              retention_success_rate: float, contact_cost: float) -> dict[str, Any]:
    """Scenario estimate. Every economic input is caller-supplied; no business margin is invented."""
    if not 0 <= threshold <= 1 or not 0 <= retention_success_rate <= 1:
        raise ValueError("threshold and retention_success_rate must be between 0 and 1")
    if contribution_margin < 0 or contact_cost < 0:
        raise ValueError("financial assumptions must be non-negative")
    latest: dict[int, Prediction] = {}
    for prediction in db.query(Prediction).order_by(Prediction.created_at.desc()).all():
        latest.setdefault(prediction.customer_id, prediction)
    selected = [p for p in latest.values() if p.probability >= threshold]
    expected_churn = sum(float(p.probability) for p in selected)
    expected_saved = expected_churn * retention_success_rate
    gross = expected_saved * contribution_margin
    cost = len(selected) * contact_cost
    return {"scenario_only": True, "assumptions": {"threshold": threshold, "contribution_margin_per_saved_customer": contribution_margin,
            "retention_success_rate": retention_success_rate, "contact_cost_per_selected_customer": contact_cost},
            "customers_scored": len(latest), "customers_selected": len(selected),
            "expected_churn_events_in_selected_group": expected_churn,
            "expected_customers_saved": expected_saved, "gross_contribution_margin": gross,
            "contact_cost": cost, "net_scenario_value": gross - cost,
            "disclaimer": "Illustrative scenario arithmetic, not realized savings, causal uplift, a forecast or a finance-approved business case."}


def _wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float | None, float | None]:
    """Wilson score interval for a binomial proportion; returns nulls for empty groups."""
    if total <= 0:
        return None, None
    p = successes / total
    denom = 1.0 + (z * z / total)
    center = (p + (z * z / (2 * total))) / denom
    margin = (z * math.sqrt((p * (1 - p) / total) + (z * z / (4 * total * total)))) / denom
    return max(0.0, center - margin), min(1.0, center + margin)


def fairness_audit(db: Session, release_id: str, threshold: float = 0.5,
                   group_by: str = "segment", min_group_size: int = 20) -> dict[str, Any]:
    """Descriptive group-metric review on predictions joined to exact mature labels.

    A prediction is evaluated only when customer, cutoff timestamp and horizon match
    a mature, uncensored customer-scope label. This is a review aid, not a legal or
    regulatory fairness certification.
    """
    from sqlalchemy import and_

    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold must be between 0 and 1")
    if group_by not in {"segment", "country"}:
        raise ValueError("group_by must be segment or country")
    if not 2 <= min_group_size <= 100_000:
        raise ValueError("min_group_size must be between 2 and 100000")
    if not db.query(Prediction).filter_by(release_id=release_id).first():
        raise ValueError("No saved predictions exist for this model release")

    matched = (db.query(Prediction, Customer, ChurnLabel)
               .join(Customer, Prediction.customer_id == Customer.id)
               .join(ChurnLabel, and_(
                   ChurnLabel.customer_id == Prediction.customer_id,
                   ChurnLabel.entity_scope == "customer",
                   ChurnLabel.cutoff_date == Prediction.cutoff_date,
                   ChurnLabel.horizon_days == Prediction.horizon_days,
                   ChurnLabel.is_censored.is_(False),
                   ChurnLabel.churn_30d.in_([0, 1]),
               ))
               .filter(Prediction.release_id == release_id)
               .order_by(Prediction.id.asc()).all())

    grouped: dict[str, list[tuple[int, int]]] = defaultdict(list)
    for prediction, customer, label in matched:
        group_value = getattr(customer, group_by) or "unknown"
        grouped[str(group_value)].append((int(label.churn_30d), int(float(prediction.probability) >= threshold)))

    results: dict[str, Any] = {}
    comparable: list[dict[str, Any]] = []
    for group_name, pairs in sorted(grouped.items()):
        n = len(pairs)
        positives = sum(actual for actual, _ in pairs)
        negatives = n - positives
        predicted_positive = sum(predicted for _, predicted in pairs)
        tp = sum(actual and predicted for actual, predicted in pairs)
        fp = sum((not actual) and predicted for actual, predicted in pairs)
        tn = sum((not actual) and (not predicted) for actual, predicted in pairs)
        fn = sum(actual and (not predicted) for actual, predicted in pairs)
        low, high = _wilson_interval(predicted_positive, n)
        eligible = n >= min_group_size and positives >= 5 and negatives >= 5
        item = {
            "sample_count": n,
            "actual_churn_positive": positives,
            "actual_churn_negative": negatives,
            "predicted_positive": predicted_positive,
            "selection_rate": predicted_positive / n if n else None,
            "selection_rate_ci95": [low, high],
            "precision": tp / (tp + fp) if tp + fp else None,
            "recall_tpr": tp / positives if positives else None,
            "false_positive_rate": fp / negatives if negatives else None,
            "specificity": tn / negatives if negatives else None,
            "true_positive": tp, "false_positive": fp, "true_negative": tn, "false_negative": fn,
            "comparison_status": "eligible_for_descriptive_comparison" if eligible else "insufficient_group_sample",
        }
        results[group_name] = item
        if eligible:
            comparable.append(item)

    selection_rates = [x["selection_rate"] for x in comparable]
    recalls = [x["recall_tpr"] for x in comparable if x["recall_tpr"] is not None]
    max_rate = max(selection_rates) if selection_rates else None
    min_rate = min(selection_rates) if selection_rates else None
    return {
        "release_id": release_id,
        "threshold": threshold,
        "group_by": group_by,
        "minimum_group_size": min_group_size,
        "matched_mature_predictions": len(matched),
        "groups": results,
        "eligible_group_count": len(comparable),
        "descriptive_disparities": {
            "selection_rate_gap": (max_rate - min_rate) if max_rate is not None and min_rate is not None else None,
            "selection_rate_ratio": (min_rate / max_rate) if max_rate and min_rate is not None else None,
            "recall_tpr_gap": (max(recalls) - min(recalls)) if len(recalls) >= 2 else None,
        },
        "status": "reviewable" if len(comparable) >= 2 else "insufficient_comparable_groups",
        "limitations": [
            "Only predictions joined to the exact customer, cutoff and horizon of mature uncensored labels are included.",
            "Group metrics are descriptive; confidence intervals for selection rate do not remove sampling or confounding bias.",
            "Small groups are not compared. This report is not a fairness certification or legal compliance assessment.",
            "Review protected attributes, lawful basis, business context and intervention impact with qualified stakeholders before use.",
        ],
    }
