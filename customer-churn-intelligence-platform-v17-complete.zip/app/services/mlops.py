from __future__ import annotations

import math
import json
from collections import defaultdict
from sqlalchemy.orm import Session
from app.models import DriftReport, FeatureSnapshot, ModelRelease, Prediction
from app.utils import json_dumps, json_loads


def calculate_psi(reference: list[float], current: list[float], bins: int = 10) -> float:
    """Population Stability Index with clipped zero proportions and shared reference bins."""
    import numpy as np
    ref = np.asarray([x for x in reference if math.isfinite(float(x))], dtype=float)
    cur = np.asarray([x for x in current if math.isfinite(float(x))], dtype=float)
    if len(ref) < 2 or len(cur) < 2:
        raise ValueError("At least two finite values are required in each distribution")
    edges = np.unique(np.quantile(ref, np.linspace(0,1,bins+1)))
    if len(edges) < 3:
        edges = np.linspace(float(ref.min()) - 1e-9, float(ref.max()) + 1e-9, min(bins, 3)+1)
    else:
        edges[0] -= 1e-9; edges[-1] += 1e-9
    r_counts, _ = np.histogram(ref, bins=edges)
    c_counts, _ = np.histogram(cur, bins=edges)
    r = np.clip(r_counts / len(ref), 1e-6, None)
    c = np.clip(c_counts / len(cur), 1e-6, None)
    return float(np.sum((c-r) * np.log(c/r)))


def run_drift_check(db: Session, release_id: str, baseline_snapshot_ids: list[int] | None = None, threshold: float = 0.2) -> dict:
    release = db.query(ModelRelease).filter_by(release_id=release_id).one_or_none()
    if not release: raise ValueError("Model release not found")
    snaps = db.query(FeatureSnapshot).filter_by(feature_version=release.feature_version).order_by(FeatureSnapshot.cutoff_date.asc(), FeatureSnapshot.id.asc()).all()
    if baseline_snapshot_ids:
        base = [db.get(FeatureSnapshot, i) for i in baseline_snapshot_ids]
        base = [x for x in base if x]
    else:
        base = snaps[:max(2, len(snaps)//2)]
    current = snaps[len(base):]
    if len(base) < 2 or len(current) < 2:
        raise ValueError("Drift check needs at least two baseline and two current feature snapshots")
    numeric = defaultdict(lambda: ([], []))
    for s in base:
        for k,v in json_loads(s.features_json).items():
            if isinstance(v, (int,float)): numeric[k][0].append(float(v))
    for s in current:
        for k,v in json_loads(s.features_json).items():
            if isinstance(v, (int,float)): numeric[k][1].append(float(v))
    results = []
    for name, (ref, cur) in numeric.items():
        if len(ref) < 2 or len(cur) < 2: continue
        psi = calculate_psi(ref, cur)
        status = "drift_detected" if psi >= threshold else "within_threshold"
        report = DriftReport(release_id=release_id, metric_name=f"psi:{name}", metric_value=psi,
                             threshold=threshold, status=status,
                             details_json=json_dumps({"baseline_count":len(ref),"current_count":len(cur)}))
        db.add(report); results.append({"feature":name,"psi":psi,"status":status})
    db.commit()
    return {"release_id":release_id,"threshold":threshold,"features":results,
            "drifted_features":sum(x["status"] == "drift_detected" for x in results),
            "interpretation":"Feature distribution drift is not a measurement of model accuracy."}


def run_evidently_drift(db: Session, release_id: str, baseline_snapshot_ids: list[int] | None = None) -> dict:
    """Optional Evidently report generation. Missing package/service is reported, never marked green."""
    try:
        import pandas as pd
        try:
            from evidently import Report
            from evidently.presets import DataDriftPreset
        except ImportError:
            from evidently.legacy.report import Report
            from evidently.legacy.metric_preset import DataDriftPreset
    except ImportError:
        return {"status": "blocked", "reason": "evidently_or_pandas_not_installed"}
    release = db.query(ModelRelease).filter_by(release_id=release_id).one_or_none()
    if not release:
        raise ValueError("Model release not found")
    snapshots = db.query(FeatureSnapshot).filter_by(feature_version=release.feature_version).order_by(
        FeatureSnapshot.cutoff_date.asc(), FeatureSnapshot.id.asc()).all()
    if baseline_snapshot_ids:
        baseline_ids = set(baseline_snapshot_ids)
        baseline = [x for x in snapshots if x.id in baseline_ids]
        current = [x for x in snapshots if x.id not in baseline_ids]
    else:
        split = max(2, len(snapshots) // 2)
        baseline, current = snapshots[:split], snapshots[split:]
    if len(baseline) < 2 or len(current) < 2:
        return {"status": "blocked", "reason": "insufficient_baseline_or_current_snapshots"}
    def frame(rows):
        items = [json_loads(x.features_json) for x in rows]
        data = pd.DataFrame(items)
        numeric = data.select_dtypes(include=["number"])
        return numeric.replace([float("inf"), float("-inf")], float("nan"))
    try:
        report = Report(metrics=[DataDriftPreset()])
        result = report.run(reference_data=frame(baseline), current_data=frame(current))
        rendered = result.json()
        artifact = {"status": "completed", "release_id": release_id,
                    "baseline_count": len(baseline), "current_count": len(current),
                    "report_json": json.loads(rendered),
                    "interpretation": "Evidently drift output is a data-quality/distribution signal, not model accuracy."}
        db.add(DriftReport(release_id=release_id, metric_name="evidently_dataset_drift",
                           metric_value=0.0, threshold=0.0, status="report_generated",
                           details_json=json_dumps({"baseline_count": len(baseline), "current_count": len(current)})))
        db.commit()
        return artifact
    except Exception as exc:
        return {"status": "error", "error_type": type(exc).__name__,
                "reason": "Evidently report execution failed; inspect service logs without exposing customer data."}


def integration_capabilities() -> dict:
    from app.integrations.mlflow_tracking import tracking_status
    try:
        import airflow  # noqa: F401
        airflow_state = "installed"
    except ImportError:
        airflow_state = "not_installed"
    try:
        import evidently  # noqa: F401
        evidently_state = "installed"
    except ImportError:
        evidently_state = "not_installed"
    return {"mlflow": tracking_status()["status"], "airflow": airflow_state,
            "airflow_dag": "present" if __import__("pathlib").Path("dags/customer_churn_daily_scoring.py").exists() else "missing",
            "evidently": evidently_state, "local_model_registry": "implemented",
            "local_drift_monitor": "implemented", "evidently_drift_reports": "optional_integration",
            "scheduled_batch_scoring": "airflow_dag_authored_runtime_unverified",
            "hosted_deployment": "not_verified"}
