from __future__ import annotations

import uuid
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from app.models import (CRMAction, Customer, FeatureSnapshot, Prediction,
                        RetentionRecommendation, ExternalIdentity)
from app.utils import json_dumps, json_loads


def generate_recommendations(db: Session) -> dict:
    from app.services.retention_governance import DEFAULT_PLAYBOOKS, list_playbooks
    playbooks = {x["playbook_key"]: x for x in list_playbooks(db)}
    created = 0
    skipped_fatigue = 0
    skipped_cooldown = 0
    latest = {}
    for prediction in db.query(Prediction).order_by(Prediction.created_at.desc()).all():
        latest.setdefault(prediction.customer_id, prediction)
    for customer_id, pred in latest.items():
        if pred.risk_band == "low":
            continue
        existing = db.query(RetentionRecommendation).filter_by(customer_id=customer_id,
                    prediction_id=pred.id).first()
        if existing:
            continue
        snapshot = db.get(FeatureSnapshot, pred.feature_snapshot_id)
        features = json_loads(snapshot.features_json) if snapshot else {}
        if features.get("payment_failures_90d", 0) > 0:
            category, title = "payment_assistance", "Review recent payment difficulties"
            rationale = "Recent failed payment records may indicate billing friction. Verify the account before outreach."
            evidence = {"payment_failures_90d": features.get("payment_failures_90d")}
        elif features.get("usage_decline_7d_vs_prior_7d") is not None and features.get("usage_decline_7d_vs_prior_7d") < -0.25:
            category, title = "product_adoption", "Investigate declining product engagement"
            rationale = "Recorded product activity declined versus the preceding 7-day window. Review adoption needs."
            evidence = {"usage_decline_7d_vs_prior_7d": features.get("usage_decline_7d_vs_prior_7d")}
        elif features.get("open_support_tickets", 0) > 0 or features.get("high_priority_tickets", 0) > 0:
            category, title = "support_recovery", "Review unresolved customer support issues"
            rationale = "Unresolved or high-priority support records are present. Confirm resolution status."
            evidence = {"open_support_tickets": features.get("open_support_tickets"),
                        "high_priority_tickets": features.get("high_priority_tickets")}
        else:
            category, title = "relationship_review", "Schedule a customer health review"
            rationale = "The approved model indicates elevated churn risk. Review the customer context before action."
            evidence = {"model_risk_band": pred.risk_band, "model_probability": pred.probability}
        entry = playbooks.get(category, {})
        policy = entry.get("policy", DEFAULT_PLAYBOOKS.get(category, {}))
        if not entry.get("enabled", policy.get("enabled", True)):
            continue
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(days=int(policy.get("cooldown_days", 0)))
        recent_same = db.query(RetentionRecommendation).filter(
            RetentionRecommendation.customer_id == customer_id,
            RetentionRecommendation.category == category,
            RetentionRecommendation.created_at >= cutoff).first()
        if recent_same:
            skipped_cooldown += 1
            continue
        contact_cap = int(policy.get("max_external_contacts_30d", 2))
        external_actions = db.query(CRMAction).join(RetentionRecommendation,
            CRMAction.recommendation_id == RetentionRecommendation.id).filter(
                RetentionRecommendation.customer_id == customer_id,
                CRMAction.provider != "sandbox", CRMAction.status == "sent",
                CRMAction.created_at >= datetime.now(timezone.utc) - timedelta(days=30)).count()
        if external_actions >= contact_cap:
            skipped_fatigue += 1
            continue
        evidence.update({"playbook_version": entry.get("version", "1.0"),
                         "channel": policy.get("channel", "internal_task"),
                         "contact_fatigue_external_actions_30d": external_actions})
        db.add(RetentionRecommendation(customer_id=customer_id, prediction_id=pred.id, category=category,
                                        title=title, rationale=rationale, evidence_json=json_dumps(evidence),
                                        priority="high" if pred.risk_band == "high" else "medium",
                                        status="pending_approval"))
        created += 1
    db.commit()
    return {"created": created, "skipped_cooldown": skipped_cooldown,
            "skipped_contact_fatigue": skipped_fatigue,
            "status": "recommendations_require_human_approval"}


def review_recommendation(db: Session, recommendation_id: int, decision: str, approver_id: int) -> RetentionRecommendation:
    rec = db.get(RetentionRecommendation, recommendation_id)
    if not rec: raise ValueError("Recommendation not found")
    if rec.status != "pending_approval": raise ValueError("Only pending recommendations can be reviewed")
    if decision not in {"approved", "rejected"}: raise ValueError("decision must be approved or rejected")
    rec.status = decision
    rec.approved_by = approver_id if decision == "approved" else None
    rec.updated_at = datetime.now(timezone.utc)
    db.commit()
    return rec


def execute_sandbox_action(db: Session, recommendation_id: int, idempotency_key: str) -> dict:
    rec = db.get(RetentionRecommendation, recommendation_id)
    if not rec: raise ValueError("Recommendation not found")
    if rec.status != "approved": raise ValueError("CRM action requires an approved recommendation")
    customer = db.get(Customer, rec.customer_id)
    if not customer or not customer.consent_to_contact:
        raise ValueError("Customer contact consent is missing; action was not queued")
    existing = db.query(CRMAction).filter_by(idempotency_key=idempotency_key).one_or_none()
    if existing:
        return {"action_id": existing.id, "status": existing.status, "idempotent_reuse": True,
                "message": "Existing sandbox action returned; no duplicate action created."}
    action = CRMAction(recommendation_id=rec.id, provider="sandbox", action_type="create_internal_task",
                       idempotency_key=idempotency_key, status="sandbox_completed",
                       external_reference=f"LOCAL-TASK-{uuid.uuid4().hex[:12]}",
                       result_json=json_dumps({"simulated": True,
                           "note": "No external CRM or customer communication was contacted."}))
    db.add(action); db.commit(); db.refresh(action)
    return {"action_id": action.id, "status": action.status, "provider": "sandbox",
            "simulated": True, "idempotent_reuse": False}


def record_outcome(db: Session, recommendation_id: int, outcome: str, notes: str | None = None) -> RetentionRecommendation:
    rec = db.get(RetentionRecommendation, recommendation_id)
    if not rec: raise ValueError("Recommendation not found")
    if outcome not in {"retained", "churned", "no_response", "not_applicable", "unknown"}:
        raise ValueError("Unsupported outcome")
    # Keep observed outcomes separate from inferred treatment effects.
    from app.models import AuditEvent
    rec.outcome_json = json_dumps({"outcome": outcome, "notes": (notes or "")[:500],
                                   "recorded_at": datetime.now(timezone.utc).isoformat(),
                                   "causal_effect_established": False})
    rec.updated_at = datetime.now(timezone.utc)
    db.add(AuditEvent(action="retention_outcome_recorded", entity_type="recommendation",
                      entity_id=str(rec.id), metadata_json=json_dumps({"outcome": outcome})))
    db.commit()
    return rec


def execute_live_crm_action(db: Session, recommendation_id: int, provider: str, idempotency_key: str,
                            client=None) -> dict:
    from app.integrations.crm import (execute_provider_action, ProviderConfigurationError, ProviderRequestError)
    rec = db.get(RetentionRecommendation, recommendation_id)
    if not rec:
        raise ValueError("Recommendation not found")
    if rec.status != "approved":
        raise ValueError("External CRM action requires an approved recommendation")
    customer = db.get(Customer, rec.customer_id)
    if not customer or not customer.consent_to_contact:
        raise ValueError("Explicit customer contact consent is missing; no external action was sent")
    if provider not in {"salesforce", "hubspot", "intercom"}:
        raise ValueError("Unsupported CRM provider")
    existing = db.query(CRMAction).filter_by(idempotency_key=idempotency_key).one_or_none()
    if existing:
        return {"action_id": existing.id, "provider": existing.provider, "status": existing.status,
                "idempotent_reuse": True, "message": "Existing action returned. Unknown delivery states are never automatically retried."}
    identity = db.query(ExternalIdentity).filter_by(provider=provider, entity_type="customer",
                                                     local_entity_id=customer.id).one_or_none()
    if not identity:
        raise ValueError("Customer has no verified external identity mapping for this CRM provider")
    action = CRMAction(recommendation_id=rec.id, provider=provider, action_type="create_followup",
                       idempotency_key=idempotency_key, status="pending_external_delivery",
                       result_json=json_dumps({"remote_customer_id": identity.remote_entity_id}))
    db.add(action); db.commit(); db.refresh(action)
    try:
        result = execute_provider_action(provider, remote_customer_id=identity.remote_entity_id,
                    title=rec.title, body=rec.rationale, priority=rec.priority, client=client)
        action.status = "sent"
        action.external_reference = result.get("external_id")
        action.result_json = json_dumps({"http_status": result.get("http_status"),
                                         "external_reference": result.get("external_id"),
                                         "delivery": "provider_acknowledged"})
    except ProviderConfigurationError as exc:
        action.status = "not_configured"
        action.result_json = json_dumps({"error": str(exc)[:300], "delivery": "not_attempted"})
    except ProviderRequestError as exc:
        action.status = "delivery_unknown" if exc.category == "delivery_unknown_timeout" else "failed"
        action.result_json = json_dumps({"error_category": exc.category, "http_status": exc.status_code,
                                         "delivery": "unknown" if action.status == "delivery_unknown" else "rejected_or_failed"})
    except Exception as exc:
        action.status = "failed"
        action.result_json = json_dumps({"error_category": type(exc).__name__, "delivery": "failed"})
    db.commit(); db.refresh(action)
    return {"action_id": action.id, "provider": provider, "status": action.status,
            "external_reference": action.external_reference, "idempotent_reuse": False,
            "result": json_loads(action.result_json),
            "note": "External tasks/notes are created only after review approval and explicit contact consent."}
