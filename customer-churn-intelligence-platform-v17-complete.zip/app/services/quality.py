from __future__ import annotations

import json
import math
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy.orm import Session

from app.models import (Customer, DataQualityFinding, DataQualityRule, DataQualityRun,
                        Invoice, Payment, Subscription, SupportTicket, UsageEvent, AuditEvent)
from app.utils import json_dumps, json_loads, parse_datetime

ENTITY_MODELS = {
    "customer": Customer, "subscription": Subscription, "invoice": Invoice,
    "payment": Payment, "usage": UsageEvent, "support": SupportTicket,
}
DEFAULT_RULES = {
    "customer_missing_email": {"enabled": True, "severity": "info", "parameters": {}},
    "subscription_date_order": {"enabled": True, "severity": "critical", "parameters": {}},
    "invoice_amount_outlier": {"enabled": True, "severity": "warning", "parameters": {"iqr_multiplier": 3.0}},
    "payment_amount_outlier": {"enabled": True, "severity": "warning", "parameters": {"iqr_multiplier": 3.0}},
    "usage_quantity_outlier": {"enabled": True, "severity": "warning", "parameters": {"iqr_multiplier": 3.0}},
    "support_resolution_order": {"enabled": True, "severity": "critical", "parameters": {}},
    "customer_duplicate_email": {"enabled": True, "severity": "warning", "parameters": {}},
    "customer_email_format": {"enabled": True, "severity": "warning", "parameters": {}},
    "invoice_due_date_order": {"enabled": True, "severity": "warning", "parameters": {}},
    "payment_invoice_customer_mismatch": {"enabled": True, "severity": "critical", "parameters": {}},
    "payment_invoice_date_order": {"enabled": True, "severity": "info", "parameters": {}},
    "usage_subscription_customer_mismatch": {"enabled": True, "severity": "critical", "parameters": {}},
}


def list_rules(db: Session) -> list[dict[str, Any]]:
    stored = {r.rule_code: r for r in db.query(DataQualityRule).all()}
    out = []
    for code, base in DEFAULT_RULES.items():
        row = stored.get(code)
        out.append({"rule_code": code, "enabled": row.enabled if row else base["enabled"],
                    "severity": row.severity if row else base["severity"],
                    "parameters": json_loads(row.parameters_json) if row else base["parameters"]})
    return out


def update_rule(db: Session, code: str, enabled: bool, severity: str, parameters: dict[str, Any], actor_id: int) -> dict[str, Any]:
    if code not in DEFAULT_RULES:
        raise ValueError("Unknown quality rule")
    if severity not in {"info", "warning", "critical"}:
        raise ValueError("severity must be info, warning, or critical")
    if code.endswith("_outlier"):
        multiplier = float(parameters.get("iqr_multiplier", 3.0))
        if not 1.0 <= multiplier <= 10.0:
            raise ValueError("iqr_multiplier must be between 1 and 10")
        parameters = {"iqr_multiplier": multiplier}
    else:
        parameters = {}
    rule = db.query(DataQualityRule).filter_by(rule_code=code).one_or_none()
    if rule is None:
        rule = DataQualityRule(rule_code=code)
        db.add(rule)
    rule.enabled = enabled
    rule.severity = severity
    rule.parameters_json = json_dumps(parameters)
    rule.updated_by = actor_id
    db.add(AuditEvent(actor_id=actor_id, action="data_quality_rule_updated", entity_type="quality_rule",
                      entity_id=code, metadata_json=json_dumps({"enabled": enabled, "severity": severity})))
    db.commit()
    return {"rule_code": code, "enabled": enabled, "severity": severity, "parameters": parameters}


def run_quality_audit(db: Session, scope: str = "all", rule_version: str = "1.0") -> dict[str, Any]:
    if scope not in {"all", *ENTITY_MODELS.keys()}:
        raise ValueError("scope must be all or one of: customer, subscription, invoice, payment, usage, support")
    rules = {r["rule_code"]: r for r in list_rules(db)}
    findings: list[dict[str, Any]] = []
    scanned = 0

    def add(code: str, kind: str, entity_id: int, field: str, value: Any, message: str, details: dict | None = None):
        rule = rules[code]
        if rule["enabled"]:
            findings.append({"rule_code": code, "entity_type": kind, "entity_id": entity_id,
                             "field_name": field, "severity": rule["severity"],
                             "observed_value": None if value is None else str(value)[:500],
                             "message": message, "details": details or {}})

    def rows(kind: str):
        model = ENTITY_MODELS[kind]
        return db.query(model).all()

    if scope in {"all", "customer"}:
        items = rows("customer"); scanned += len(items)
        email_groups: dict[str, list[Customer]] = {}
        for c in items:
            if not c.email:
                add("customer_missing_email", "customer", c.id, "email", None, "Customer email is missing; email is optional unless a downstream workflow requires it.")
            else:
                if "@" not in c.email or c.email.startswith("@") or c.email.endswith("@") or any(ch.isspace() for ch in c.email):
                    add("customer_email_format", "customer", c.id, "email", c.email, "Email format does not pass the basic syntax check; verify against an authorized source.")
                email_groups.setdefault(c.email.strip().lower(), []).append(c)
        for email, grouped in email_groups.items():
            if len(grouped) > 1:
                for c in grouped:
                    add("customer_duplicate_email", "customer", c.id, "email", email, "Email is shared by multiple customer records; do not auto-merge identities.", {"matching_customer_ids": [x.id for x in grouped]})
    if scope in {"all", "subscription"}:
        items = rows("subscription"); scanned += len(items)
        for x in items:
            if x.end_date and x.end_date < x.start_date:
                add("subscription_date_order", "subscription", x.id, "end_date", x.end_date.isoformat(), "Subscription end date precedes its start date.")
            if x.cancellation_date and x.cancellation_date < x.start_date:
                add("subscription_date_order", "subscription", x.id, "cancellation_date", x.cancellation_date.isoformat(), "Subscription cancellation date precedes its start date.")
    for kind, field, code in (("invoice", "amount", "invoice_amount_outlier"),
                              ("payment", "amount", "payment_amount_outlier"),
                              ("usage", "quantity", "usage_quantity_outlier")):
        if scope not in {"all", kind}:
            continue
        items = rows(kind); scanned += len(items)
        # Compare outliers within currency for monetary observations; never mix currency distributions.
        groups: dict[str, list[Any]] = {}
        for x in items:
            key = getattr(x, "currency", "all")
            groups.setdefault(str(key), []).append(x)
        multiplier = float(rules[code]["parameters"].get("iqr_multiplier", 3.0))
        for group, grouped in groups.items():
            vals = [float(getattr(x, field)) for x in grouped if getattr(x, field) is not None and math.isfinite(float(getattr(x, field)))]
            if len(vals) < 8:
                continue
            vals_sorted = sorted(vals)
            q1, q3 = _quantile(vals_sorted, .25), _quantile(vals_sorted, .75)
            iqr = q3 - q1
            if iqr <= 0:
                continue
            low, high = q1 - multiplier * iqr, q3 + multiplier * iqr
            for x in grouped:
                value = float(getattr(x, field))
                if value < low or value > high:
                    add(code, kind, x.id, field, value, f"{field} is outside the {multiplier:g}×IQR review range.", {"group": group, "lower_bound": low, "upper_bound": high, "review_only": True})
    if scope in {"all", "support"}:
        items = rows("support"); scanned += len(items)
        for x in items:
            if x.resolved_at and x.resolved_at < x.created_at:
                add("support_resolution_order", "support", x.id, "resolved_at", x.resolved_at.isoformat(), "Support resolution timestamp precedes ticket creation.")
    if scope in {"all", "invoice"}:
        for invoice in rows("invoice"):
            if invoice.due_date and invoice.due_date < invoice.invoice_date:
                add("invoice_due_date_order", "invoice", invoice.id, "due_date", invoice.due_date.isoformat(),
                    "Invoice due date precedes invoice date.")
    if scope in {"all", "payment"}:
        for payment in rows("payment"):
            if payment.invoice_id:
                invoice = db.get(Invoice, payment.invoice_id)
                if invoice and invoice.customer_id != payment.customer_id:
                    add("payment_invoice_customer_mismatch", "payment", payment.id, "invoice_id", payment.invoice_id,
                        "Payment and linked invoice belong to different customers.", {"invoice_customer_id": invoice.customer_id,
                        "payment_customer_id": payment.customer_id})
                if invoice and payment.payment_date < invoice.invoice_date:
                    add("payment_invoice_date_order", "payment", payment.id, "payment_date", payment.payment_date.isoformat(),
                        "Payment date precedes linked invoice date; check prepayment policy.", {"invoice_id": invoice.id})
    if scope in {"all", "usage"}:
        for usage_event in rows("usage"):
            if usage_event.subscription_id:
                subscription = db.get(Subscription, usage_event.subscription_id)
                if subscription and subscription.customer_id != usage_event.customer_id:
                    add("usage_subscription_customer_mismatch", "usage", usage_event.id, "subscription_id", usage_event.subscription_id,
                        "Usage event and linked subscription belong to different customers.", {"subscription_customer_id": subscription.customer_id,
                        "usage_customer_id": usage_event.customer_id})

    run_id = str(uuid.uuid4())
    critical = sum(x["severity"] == "critical" for x in findings)
    warning = sum(x["severity"] == "warning" for x in findings)
    info = sum(x["severity"] == "info" for x in findings)
    # A transparent issue-rate score, not a certification or a universal quality standard.
    penalty = critical * 5 + warning * 2 + info * .5
    score = round(max(0.0, 100.0 - (100.0 * penalty / max(scanned, 1))), 2)
    run = DataQualityRun(run_id=run_id, scope=scope, rule_version=rule_version, records_scanned=scanned,
                         finding_count=len(findings), quality_score=score,
                         summary_json=json_dumps({"critical": critical, "warning": warning, "info": info,
                                                  "score_method": "100 minus severity-weighted finding rate; review score only"}))
    db.add(run); db.flush()
    for f in findings:
        db.add(DataQualityFinding(run_id=run_id, entity_type=f["entity_type"], entity_id=f["entity_id"],
                                  field_name=f["field_name"], rule_code=f["rule_code"], severity=f["severity"],
                                  message=f["message"], observed_value=f["observed_value"], details_json=json_dumps(f["details"])))
    db.commit()
    return {"run_id": run_id, "scope": scope, "records_scanned": scanned, "finding_count": len(findings),
            "quality_score": score, "summary": json_loads(run.summary_json), "status": "completed"}


def _quantile(values: list[float], q: float) -> float:
    if len(values) == 1:
        return values[0]
    pos = (len(values) - 1) * q
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    return values[lo] + (values[hi] - values[lo]) * (pos - lo)


CORRECTION_FIELDS = {
    "customer": {"email", "segment", "country"},
    "subscription": {"plan", "status", "mrr", "currency", "end_date", "cancellation_date"},
    "invoice": {"amount", "currency", "status", "due_date"},
    "payment": {"amount", "currency", "status"},
    "usage": {"quantity", "event_type"},
    "support": {"resolved_at", "status", "priority", "category"},
}


def review_finding(db: Session, finding_id: int, decision: str, reviewer_id: int,
                   corrected_value: Any = None, note: str | None = None) -> DataQualityFinding:
    finding = db.get(DataQualityFinding, finding_id)
    if not finding:
        raise ValueError("Quality finding not found")
    if finding.status != "open":
        raise ValueError("Only open findings can be reviewed")
    if decision not in {"correct", "accepted_risk", "false_positive"}:
        raise ValueError("decision must be correct, accepted_risk, or false_positive")
    if decision == "correct":
        allowed = CORRECTION_FIELDS.get(finding.entity_type, set())
        if finding.field_name not in allowed:
            raise ValueError("This field is not eligible for assisted correction")
        obj = db.get(ENTITY_MODELS[finding.entity_type], finding.entity_id)
        if obj is None:
            raise ValueError("Source record no longer exists")
        value = corrected_value
        if finding.field_name in {"amount", "mrr", "quantity"}:
            try: value = Decimal(str(value))
            except (InvalidOperation, TypeError): raise ValueError("Correction must be numeric")
            if not value.is_finite() or value < 0: raise ValueError("Correction must be a finite non-negative value")
        elif finding.field_name in {"end_date", "cancellation_date", "due_date", "resolved_at"}:
            value = parse_datetime(value) if value not in (None, "") else None
        elif finding.field_name == "currency":
            value = str(value).upper()
            if len(value) != 3 or not value.isalpha(): raise ValueError("Currency must be a 3-letter code")
        elif finding.field_name == "status":
            value = str(value).lower()
            allowed_status = {"active", "cancelled", "canceled", "expired", "ended", "paused", "suspended", "open", "resolved", "closed", "succeeded", "paid", "completed", "failed", "declined", "rejected"}
            if value not in allowed_status: raise ValueError("Unsupported status value")
        else:
            value = str(value).strip() if value is not None else None
            if value is not None and len(value) > 200: raise ValueError("Correction value is too long")
        setattr(obj, finding.field_name, value)
        finding.status = "corrected"
    else:
        finding.status = decision
    finding.reviewer_id = reviewer_id
    finding.review_note = (note or "")[:500] or None
    finding.reviewed_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=reviewer_id, action=f"quality_finding_{decision}", entity_type=finding.entity_type,
                      entity_id=str(finding.entity_id), metadata_json=json_dumps({"finding_id": finding.id, "field": finding.field_name})))
    db.commit(); db.refresh(finding)
    return finding


def list_findings(db: Session, status: str | None = "open", limit: int = 100) -> list[dict[str, Any]]:
    query = db.query(DataQualityFinding)
    if status:
        query = query.filter_by(status=status)
    items = query.order_by(DataQualityFinding.created_at.desc()).limit(max(1, min(limit, 500))).all()
    return [{"id": x.id, "run_id": x.run_id, "entity_type": x.entity_type, "entity_id": x.entity_id,
             "field_name": x.field_name, "rule_code": x.rule_code, "severity": x.severity,
             "status": x.status, "message": x.message, "observed_value": x.observed_value,
             "details": json_loads(x.details_json), "review_note": x.review_note} for x in items]


def bulk_review_findings(db: Session, finding_ids: list[int], decision: str,
                         reviewer_id: int, note: str | None = None) -> dict[str, Any]:
    """Apply one non-mutating review disposition atomically to open findings.

    Corrections remain single-record operations because each field has its own
    typed value and validation rules. Bulk actions are limited to dispositions
    that do not alter source business data.
    """
    if not finding_ids or len(finding_ids) > 100:
        raise ValueError("Select between 1 and 100 findings")
    if len(set(finding_ids)) != len(finding_ids):
        raise ValueError("Duplicate finding IDs are not allowed")
    if any(not isinstance(value, int) or value <= 0 for value in finding_ids):
        raise ValueError("Finding IDs must be positive integers")
    if decision not in {"accepted_risk", "false_positive"}:
        raise ValueError("Bulk decision must be accepted_risk or false_positive")
    clean_note = (note or "").strip()
    if len(clean_note) > 500:
        raise ValueError("Review note must be no longer than 500 characters")

    try:
        rows = (db.query(DataQualityFinding)
                .filter(DataQualityFinding.id.in_(finding_ids))
                .with_for_update()
                .all())
        by_id = {row.id: row for row in rows}
        missing = sorted(set(finding_ids) - set(by_id))
        if missing:
            raise ValueError(f"Finding IDs not found: {missing}")
        not_open = sorted(row.id for row in rows if row.status != "open")
        if not_open:
            raise ValueError(f"Only open findings can be bulk reviewed; already reviewed: {not_open}")

        now = datetime.now(timezone.utc)
        for finding_id in finding_ids:
            row = by_id[finding_id]
            row.status = decision
            row.reviewer_id = reviewer_id
            row.review_note = clean_note or None
            row.reviewed_at = now
            db.add(AuditEvent(
                actor_id=reviewer_id,
                action=f"quality_finding_{decision}",
                entity_type=row.entity_type,
                entity_id=str(row.entity_id),
                metadata_json=json_dumps({
                    "finding_id": row.id,
                    "field": row.field_name,
                    "bulk_review": True,
                    "decision": decision,
                }),
            ))
        db.commit()
    except Exception:
        db.rollback()
        raise

    return {"reviewed_count": len(finding_ids), "finding_ids": finding_ids,
            "decision": decision, "reviewer_id": reviewer_id,
            "reviewed_at": now, "atomic": True}
