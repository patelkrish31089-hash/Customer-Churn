from __future__ import annotations

import csv
import io
import json
from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from app.models import (
    AuditEvent,
    Customer,
    DataQualityFinding,
    ImportBatch,
    ModelRelease,
    Prediction,
    RetentionRecommendation,
)
from app.services.analytics import cohort_retention, overview, survival_curve
from app.utils import json_loads


REPORTS: dict[str, dict[str, Any]] = {
    "overview": {
        "title": "Platform overview",
        "description": "Customer, subscription, mature-label and prediction summary.",
        "roles": {"admin", "analyst", "retention_manager", "viewer"},
        "formats": ["json"],
    },
    "customers": {
        "title": "Customer directory",
        "description": "Customer identities, segmentation, contact-consent status and provenance. Email addresses are excluded.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "predictions": {
        "title": "Churn predictions",
        "description": "Saved churn probabilities with customer segment, cutoff, horizon and model release.",
        "roles": {"admin", "analyst", "retention_manager"},
        "formats": ["csv", "json"],
    },
    "models": {
        "title": "Model registry",
        "description": "Model release status, version and recorded evaluation metrics.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "retention": {
        "title": "Retention worklist",
        "description": "Human-reviewed retention recommendations and their recorded outcomes.",
        "roles": {"admin", "analyst", "retention_manager"},
        "formats": ["csv", "json"],
    },
    "quality": {
        "title": "Data-quality findings",
        "description": "Quality findings, severity, review disposition and record references.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "imports": {
        "title": "Import batches",
        "description": "Source files, ingestion status and accepted/rejected row counts.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "cohorts": {
        "title": "Cohort retention",
        "description": "Acquisition-month retention summaries reconstructed from stored lifecycle records.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "survival": {
        "title": "Survival analysis",
        "description": "Kaplan–Meier points, confidence intervals, at-risk counts and event counts.",
        "roles": {"admin", "analyst"},
        "formats": ["csv", "json"],
    },
    "audit": {
        "title": "Audit events",
        "description": "Administrative audit history. Restricted to administrators.",
        "roles": {"admin"},
        "formats": ["csv", "json"],
    },
}


def _iso(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def _json_text(value: Any) -> str:
    if isinstance(value, str):
        try:
            return json.dumps(json.loads(value), ensure_ascii=False, sort_keys=True)
        except (json.JSONDecodeError, TypeError):
            return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=_iso)


def _dataset(db: Session, report_key: str) -> tuple[list[str], list[dict[str, Any]], str]:
    if report_key == "overview":
        data = overview(db)
        return list(data.keys()), [data], "Descriptive counts only; no model performance claim is implied."

    if report_key == "customers":
        rows = db.query(Customer).order_by(Customer.id.asc()).all()
        columns = ["id", "external_id", "name", "segment", "country", "consent_to_contact", "source_name", "created_at"]
        values = [{key: _iso(getattr(row, key)) for key in columns} for row in rows]
        return columns, values, "Customer email addresses are intentionally omitted from this export."

    if report_key == "predictions":
        rows = (db.query(Prediction, Customer)
                .join(Customer, Prediction.customer_id == Customer.id)
                .order_by(Prediction.created_at.desc(), Prediction.id.desc()).all())
        columns = ["prediction_id", "customer_id", "customer_external_id", "customer_name", "segment",
                   "probability", "risk_band", "cutoff_date", "horizon_days", "release_id", "created_at"]
        values = [{
            "prediction_id": prediction.id,
            "customer_id": customer.id,
            "customer_external_id": customer.external_id,
            "customer_name": customer.name,
            "segment": customer.segment,
            "probability": prediction.probability,
            "risk_band": prediction.risk_band,
            "cutoff_date": _iso(prediction.cutoff_date),
            "horizon_days": prediction.horizon_days,
            "release_id": prediction.release_id,
            "created_at": _iso(prediction.created_at),
        } for prediction, customer in rows]
        return columns, values, "Predictions are model outputs, not confirmed churn outcomes."

    if report_key == "models":
        rows = db.query(ModelRelease).order_by(ModelRelease.created_at.desc()).all()
        columns = ["release_id", "training_run_id", "model_name", "status", "feature_version", "horizon_days",
                   "metrics_json", "approved_by", "approved_at", "created_at"]
        values = [{
            "release_id": row.release_id, "training_run_id": row.training_run_id, "model_name": row.model_name,
            "status": row.status, "feature_version": row.feature_version, "horizon_days": row.horizon_days,
            "metrics_json": _json_text(row.metrics_json), "approved_by": row.approved_by,
            "approved_at": _iso(row.approved_at), "created_at": _iso(row.created_at),
        } for row in rows]
        return columns, values, "Metric values retain the validation/test provenance recorded by the training pipeline."

    if report_key == "retention":
        rows = (db.query(RetentionRecommendation, Customer)
                .join(Customer, RetentionRecommendation.customer_id == Customer.id)
                .order_by(RetentionRecommendation.priority.desc(), RetentionRecommendation.created_at.desc()).all())
        columns = ["recommendation_id", "customer_id", "customer_external_id", "customer_name", "segment",
                   "consent_to_contact", "category", "title", "priority", "status", "rationale", "outcome_json", "created_at"]
        values = [{
            "recommendation_id": rec.id, "customer_id": customer.id,
            "customer_external_id": customer.external_id, "customer_name": customer.name,
            "segment": customer.segment, "consent_to_contact": customer.consent_to_contact,
            "category": rec.category, "title": rec.title, "priority": rec.priority,
            "status": rec.status, "rationale": rec.rationale,
            "outcome_json": _json_text(rec.outcome_json), "created_at": _iso(rec.created_at),
        } for rec, customer in rows]
        return columns, values, "Recommendations require human approval and consent checks before external contact."

    if report_key == "quality":
        rows = db.query(DataQualityFinding).order_by(DataQualityFinding.created_at.desc()).all()
        columns = ["id", "run_id", "entity_type", "entity_id", "field_name", "rule_code", "severity",
                   "status", "message", "reviewer_id", "review_note", "reviewed_at", "created_at"]
        values = [{key: _iso(getattr(row, key)) for key in columns} for row in rows]
        return columns, values, "A finding is a review signal; it is not an automatic deletion or correction."

    if report_key == "imports":
        rows = db.query(ImportBatch).order_by(ImportBatch.created_at.desc()).all()
        columns = ["batch_id", "dataset_type", "filename", "source_name", "status", "records_received",
                   "records_accepted", "records_rejected", "created_at", "completed_at"]
        values = [{
            "batch_id": row.id, "dataset_type": row.dataset_type, "filename": row.filename,
            "source_name": row.source_name, "status": row.status, "records_received": row.records_received,
            "records_accepted": row.records_accepted, "records_rejected": row.records_rejected,
            "created_at": _iso(row.created_at), "completed_at": _iso(row.completed_at),
        } for row in rows]
        return columns, values, "Import status and row counts are sourced from persisted import batches."

    if report_key == "cohorts":
        data = cohort_retention(db)
        columns = ["cohort", "customers", "current_active_rate", "age_months_observed"]
        values = [{key: row.get(key) for key in columns} for row in data.get("rows", [])]
        return columns, values, data.get("limitation", "Cohort estimates depend on source history completeness.")

    if report_key == "survival":
        data = survival_curve(db)
        columns = ["day", "survival", "ci_lower", "ci_upper", "at_risk", "events", "censored"]
        values = [{key: point.get(key) for key in columns} for point in data.get("points", [])]
        return columns, values, data.get("caveat", "Descriptive survival analysis only.")

    if report_key == "audit":
        rows = db.query(AuditEvent).order_by(AuditEvent.created_at.desc(), AuditEvent.id.desc()).limit(5000).all()
        columns = ["id", "actor_id", "action", "entity_type", "entity_id", "correlation_id", "metadata_json", "created_at"]
        values = [{
            "id": row.id, "actor_id": row.actor_id, "action": row.action, "entity_type": row.entity_type,
            "entity_id": row.entity_id, "correlation_id": row.correlation_id,
            "metadata_json": _json_text(row.metadata_json), "created_at": _iso(row.created_at),
        } for row in rows]
        return columns, values, "Latest 5,000 audit events; administrators only."

    raise KeyError(report_key)


def report_catalog(role: str) -> list[dict[str, Any]]:
    return [{"key": key, "title": definition["title"], "description": definition["description"],
             "formats": list(definition["formats"])}
            for key, definition in REPORTS.items() if role in definition["roles"]]


def build_report(db: Session, report_key: str, role: str) -> dict[str, Any]:
    definition = REPORTS.get(report_key)
    if definition is None:
        raise KeyError(report_key)
    if role not in definition["roles"]:
        raise PermissionError("This role is not allowed to export the requested report")
    columns, rows, limitation = _dataset(db, report_key)
    return {
        "report_key": report_key,
        "title": definition["title"],
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "row_count": len(rows),
        "columns": columns,
        "rows": rows,
        "limitation": limitation,
        "data_provenance": "Current persisted application records; source-level provenance is retained where available.",
    }


def to_csv(report: dict[str, Any]) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=report["columns"], extrasaction="ignore", lineterminator="\n")
    writer.writeheader()
    for row in report["rows"]:
        safe_row = {}
        for column in report["columns"]:
            value = row.get(column)
            if isinstance(value, (dict, list)):
                value = _json_text(value)
            elif isinstance(value, (datetime, date)):
                value = value.isoformat()
            # Spreadsheet formula injection: neutralize untrusted text cells, not numeric values.
            if isinstance(value, str) and value.startswith(("=", "+", "-", "@", "\t", "\r")):
                value = "'" + value
            safe_row[column] = value
        writer.writerow(safe_row)
    return output.getvalue()
