from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy.orm import Session

from app.models import (Customer, RetentionAssignment, RetentionExperiment,
                        RetentionExperimentAssignment, RetentionPlaybook, RetentionRecommendation, User, AuditEvent)
from app.utils import json_dumps, json_loads

DEFAULT_PLAYBOOKS = {
    "payment_assistance": {"enabled": True, "channel": "internal_task", "cooldown_days": 14,
                            "allowed_roles": ["retention_manager", "admin"], "max_external_contacts_30d": 2},
    "product_adoption": {"enabled": True, "channel": "internal_task", "cooldown_days": 21,
                          "allowed_roles": ["retention_manager", "admin"], "max_external_contacts_30d": 2},
    "support_recovery": {"enabled": True, "channel": "internal_task", "cooldown_days": 7,
                          "allowed_roles": ["retention_manager", "admin"], "max_external_contacts_30d": 2},
    "relationship_review": {"enabled": True, "channel": "internal_task", "cooldown_days": 30,
                             "allowed_roles": ["retention_manager", "admin"], "max_external_contacts_30d": 2},
}


def list_playbooks(db: Session) -> list[dict[str, Any]]:
    stored = db.query(RetentionPlaybook).order_by(RetentionPlaybook.playbook_key, RetentionPlaybook.created_at.desc()).all()
    result = []
    seen = set()
    for row in stored:
        if row.playbook_key not in seen:
            result.append({"playbook_key": row.playbook_key, "version": row.version, "enabled": row.enabled,
                           "policy": json_loads(row.policy_json), "created_at": row.created_at})
            seen.add(row.playbook_key)
    for key, policy in DEFAULT_PLAYBOOKS.items():
        if key not in seen:
            result.append({"playbook_key": key, "version": "1.0", "enabled": policy["enabled"], "policy": policy, "source": "code_default"})
    return result


def publish_playbook(db: Session, key: str, policy: dict[str, Any], actor_id: int) -> dict[str, Any]:
    if key not in DEFAULT_PLAYBOOKS:
        raise ValueError("Unknown playbook key")
    allowed = {"enabled", "channel", "cooldown_days", "allowed_roles", "max_external_contacts_30d"}
    if set(policy) - allowed:
        raise ValueError("Unsupported playbook policy field")
    merged = {**DEFAULT_PLAYBOOKS[key], **policy}
    if merged["channel"] not in {"internal_task", "email_draft", "crm_task"}:
        raise ValueError("channel must be internal_task, email_draft, or crm_task")
    if not isinstance(merged["cooldown_days"], int) or not 0 <= merged["cooldown_days"] <= 365:
        raise ValueError("cooldown_days must be an integer from 0 to 365")
    if not isinstance(merged["max_external_contacts_30d"], int) or not 0 <= merged["max_external_contacts_30d"] <= 10:
        raise ValueError("max_external_contacts_30d must be an integer from 0 to 10")
    if not set(merged["allowed_roles"]).issubset({"admin", "retention_manager", "analyst"}):
        raise ValueError("allowed_roles contains an unsupported role")
    previous = db.query(RetentionPlaybook).filter_by(playbook_key=key).order_by(RetentionPlaybook.created_at.desc()).first()
    version = f"{float(previous.version) + 0.1:.1f}" if previous else "1.0"
    row = RetentionPlaybook(playbook_key=key, version=version, enabled=bool(merged["enabled"]),
                            policy_json=json_dumps(merged), created_by=actor_id)
    db.add(row)
    db.add(AuditEvent(actor_id=actor_id, action="retention_playbook_published", entity_type="retention_playbook",
                      entity_id=key, metadata_json=json_dumps({"version": version})))
    db.commit()
    return {"playbook_key": key, "version": version, "enabled": row.enabled, "policy": merged}


def assign_recommendation(db: Session, recommendation_id: int, assignee_id: int,
                           due_at: datetime | None = None, notes: str | None = None) -> RetentionAssignment:
    recommendation = db.get(RetentionRecommendation, recommendation_id)
    if not recommendation:
        raise ValueError("Recommendation not found")
    if recommendation.status not in {"approved", "pending_approval"}:
        raise ValueError("Only active recommendations can be assigned")
    user = db.get(User, assignee_id)
    if not user or not user.is_active or user.role not in {"admin", "retention_manager", "analyst"}:
        raise ValueError("Assignee must be an active retention-capable user")
    existing = db.query(RetentionAssignment).filter_by(recommendation_id=recommendation_id).one_or_none()
    if existing:
        existing.assignee_id = assignee_id
        existing.due_at = due_at
        existing.notes = (notes or "")[:500] or None
        existing.status = "reassigned"
        row = existing
    else:
        row = RetentionAssignment(recommendation_id=recommendation_id, assignee_id=assignee_id,
                                  due_at=due_at, notes=(notes or "")[:500] or None, status="assigned")
        db.add(row)
    db.add(AuditEvent(actor_id=assignee_id, action="retention_recommendation_assigned", entity_type="recommendation",
                      entity_id=str(recommendation_id), metadata_json=json_dumps({"assignee_id": assignee_id})))
    db.commit(); db.refresh(row)
    return row


def create_experiment(db: Session, name: str, hypothesis: str, treatment_pct: int,
                      followup_days: int, actor_id: int) -> RetentionExperiment:
    if not 10 <= treatment_pct <= 90:
        raise ValueError("treatment_pct must be between 10 and 90")
    if not 7 <= followup_days <= 180:
        raise ValueError("followup_days must be between 7 and 180")
    if len(name.strip()) < 3 or len(hypothesis.strip()) < 10:
        raise ValueError("Experiment name and hypothesis are required")
    key = uuid.uuid4().hex
    experiment = RetentionExperiment(experiment_key=key, name=name.strip()[:160],
                                     hypothesis=hypothesis.strip()[:4000],
                                     allocation_treatment_pct=treatment_pct,
                                     followup_days=followup_days, status="draft", created_by=actor_id)
    db.add(experiment); db.commit(); db.refresh(experiment)
    return experiment


def start_experiment(db: Session, experiment_id: int, actor_id: int) -> RetentionExperiment:
    experiment = db.get(RetentionExperiment, experiment_id)
    if not experiment:
        raise ValueError("Experiment not found")
    if experiment.status != "draft":
        raise ValueError("Only draft experiments can be started")
    experiment.status = "active"
    experiment.started_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=actor_id, action="retention_experiment_started", entity_type="retention_experiment",
                      entity_id=str(experiment.id), metadata_json="{}"))
    db.commit(); db.refresh(experiment)
    return experiment


def enroll_experiment(db: Session, experiment_id: int, customer_ids: list[int] | None = None) -> dict[str, Any]:
    experiment = db.get(RetentionExperiment, experiment_id)
    if not experiment or experiment.status != "active":
        raise ValueError("Experiment must be active before enrolling customers")
    query = db.query(Customer)
    if customer_ids is not None:
        if len(customer_ids) > 5000:
            raise ValueError("At most 5000 customers may be enrolled in one request")
        query = query.filter(Customer.id.in_(set(customer_ids)))
    created = 0
    for customer in query.order_by(Customer.id).all():
        if db.query(RetentionExperimentAssignment).filter_by(experiment_id=experiment.id, customer_id=customer.id).first():
            continue
        digest = hashlib.sha256(f"{experiment.experiment_key}:{customer.id}".encode()).digest()
        bucket = int.from_bytes(digest[:8], "big") % 100
        arm = "treatment" if bucket < experiment.allocation_treatment_pct else "control"
        db.add(RetentionExperimentAssignment(experiment_id=experiment.id, customer_id=customer.id, arm=arm))
        created += 1
    db.commit()
    return {"experiment_id": experiment.id, "enrolled": created,
            "assignment_method": "deterministic SHA-256 bucket; stable on experiment key and customer ID",
            "randomized": True, "control_receives_automated_outreach": False}


def record_experiment_outcome(db: Session, assignment_id: int, outcome: str,
                               actor_id: int) -> RetentionExperimentAssignment:
    assignment = db.get(RetentionExperimentAssignment, assignment_id)
    if not assignment:
        raise ValueError("Experiment assignment not found")
    experiment = db.get(RetentionExperiment, assignment.experiment_id)
    if not experiment or experiment.status != "active":
        raise ValueError("Experiment is not active")
    if outcome not in {"retained", "churned", "no_response", "unknown"}:
        raise ValueError("outcome must be retained, churned, no_response, or unknown")
    if assignment.outcome is not None:
        raise ValueError("Outcome is already recorded and immutable; use a separately reviewed correction process")
    now = datetime.now(timezone.utc)
    assigned_at = assignment.assigned_at.replace(tzinfo=timezone.utc) if assignment.assigned_at.tzinfo is None else assignment.assigned_at
    if now < assigned_at + timedelta(days=experiment.followup_days):
        raise ValueError("Outcome window has not matured; do not record an early binary outcome")
    assignment.outcome = outcome
    assignment.outcome_at = now
    db.add(AuditEvent(actor_id=actor_id, action="retention_experiment_outcome_recorded",
                      entity_type="retention_experiment_assignment", entity_id=str(assignment.id),
                      metadata_json=json_dumps({"experiment_id": experiment.id, "outcome": outcome})))
    db.commit(); db.refresh(assignment)
    return assignment


def correct_experiment_outcome(db: Session, assignment_id: int, outcome: str,
                               actor_id: int, reason: str) -> RetentionExperimentAssignment:
    """Apply an explicitly reviewed admin correction while preserving the prior value in audit."""
    assignment = db.get(RetentionExperimentAssignment, assignment_id)
    if not assignment:
        raise ValueError("Experiment assignment not found")
    if assignment.outcome is None:
        raise ValueError("There is no recorded outcome to correct")
    if outcome not in {"retained", "churned", "no_response", "unknown"}:
        raise ValueError("outcome must be retained, churned, no_response, or unknown")
    if not isinstance(reason, str) or len(reason.strip()) < 10:
        raise ValueError("A correction reason of at least 10 characters is required")
    previous = assignment.outcome
    if previous == outcome:
        raise ValueError("Corrected outcome must differ from the recorded value")
    now = datetime.now(timezone.utc)
    assignment.outcome = outcome
    assignment.outcome_at = now
    db.add(AuditEvent(actor_id=actor_id, action="retention_experiment_outcome_corrected",
                      entity_type="retention_experiment_assignment", entity_id=str(assignment.id),
                      metadata_json=json_dumps({
                          "previous_outcome": previous, "corrected_outcome": outcome,
                          "reason": reason.strip()[:500], "correction_at": now.isoformat(),
                      })))
    db.commit(); db.refresh(assignment)
    return assignment


def experiment_report(db: Session, experiment_id: int) -> dict[str, Any]:
    experiment = db.get(RetentionExperiment, experiment_id)
    if not experiment:
        raise ValueError("Experiment not found")
    rows = db.query(RetentionExperimentAssignment).filter_by(experiment_id=experiment_id).all()
    now = datetime.now(timezone.utc)
    arms: dict[str, dict[str, Any]] = {}
    for arm in ("treatment", "control"):
        subset = [x for x in rows if x.arm == arm]
        matured_assignments = []
        for item in subset:
            assigned_at = item.assigned_at.replace(tzinfo=timezone.utc) if item.assigned_at.tzinfo is None else item.assigned_at
            if now >= assigned_at + timedelta(days=experiment.followup_days):
                matured_assignments.append(item)
        def outcome_was_recorded_after_maturity(item: RetentionExperimentAssignment) -> bool:
            if item.outcome_at is None:
                return False
            assigned_at = item.assigned_at.replace(tzinfo=timezone.utc) if item.assigned_at.tzinfo is None else item.assigned_at
            outcome_at = item.outcome_at.replace(tzinfo=timezone.utc) if item.outcome_at.tzinfo is None else item.outcome_at
            return outcome_at >= assigned_at + timedelta(days=experiment.followup_days)

        binary = [x for x in matured_assignments
                  if x.outcome in {"retained", "churned"} and outcome_was_recorded_after_maturity(x)]
        retained = sum(x.outcome == "retained" for x in binary)
        non_binary = sum(x.outcome in {"no_response", "unknown"} and outcome_was_recorded_after_maturity(x)
                         for x in matured_assignments)
        arms[arm] = {
            "assigned": len(subset),
            "matured_assignments": len(matured_assignments),
            "mature_binary_outcomes": len(binary),
            "missing_or_nonbinary_outcomes": len(matured_assignments) - len(binary),
            "nonbinary_outcomes_recorded": non_binary,
            "retained": retained,
            "churned": len(binary) - retained,
            "retention_rate_complete_case": retained / len(binary) if binary else None,
            "binary_outcome_coverage": len(binary) / len(matured_assignments) if matured_assignments else None,
        }
    effect = None
    inference = {
        "available": False,
        "reason": "At least 20 matured binary outcomes per arm are required for the descriptive complete-case approximation.",
        "estimand": "complete_case_risk_difference",
        "strict_intent_to_treat": False,
        "limitation": "Customers with missing or nonbinary outcomes are not included in the complete-case rate. A pre-specified missing-outcome strategy and sensitivity analysis are required for an ITT claim.",
    }
    a, b = arms["treatment"], arms["control"]
    if a["mature_binary_outcomes"] >= 20 and b["mature_binary_outcomes"] >= 20:
        import math
        from scipy.stats import norm
        p1, p0 = a["retention_rate_complete_case"], b["retention_rate_complete_case"]
        effect = p1 - p0
        se = math.sqrt(p1 * (1 - p1) / a["mature_binary_outcomes"] + p0 * (1 - p0) / b["mature_binary_outcomes"])
        z = effect / se if se else 0.0
        inference = {
            "available": True,
            "method": "unpooled normal approximation for complete-case risk difference",
            "estimand": "complete_case_risk_difference",
            "risk_difference": effect,
            "ci95": [max(-1.0, effect - 1.96 * se), min(1.0, effect + 1.96 * se)],
            "p_value_two_sided": float(2 * norm.sf(abs(z))) if se else 1.0,
            "strict_intent_to_treat": False,
            "interpretation": "Descriptive complete-case comparison among assignments with observed binary outcomes. This is not a strict intent-to-treat estimate and is not proof of causal campaign effectiveness.",
            "missing_outcome_warning": "Compare outcome coverage between arms and run a pre-specified missing-outcome sensitivity analysis before causal interpretation.",
        }
    return {
        "experiment_id": experiment.id,
        "name": experiment.name,
        "status": experiment.status,
        "hypothesis": experiment.hypothesis,
        "followup_days": experiment.followup_days,
        "arms": arms,
        "treatment_minus_control_retention_rate": effect,
        "inference": inference,
        "warning": "Observed outcomes are required. Synthetic, immature, missing or incomplete follow-up cannot establish real campaign effectiveness.",
    }


def close_experiment(db: Session, experiment_id: int, actor_id: int) -> RetentionExperiment:
    experiment = db.get(RetentionExperiment, experiment_id)
    if not experiment or experiment.status != "active":
        raise ValueError("Only active experiments can be closed")
    experiment.status = "closed"
    experiment.ended_at = datetime.now(timezone.utc)
    db.add(AuditEvent(actor_id=actor_id, action="retention_experiment_closed", entity_type="retention_experiment",
                      entity_id=str(experiment.id), metadata_json="{}"))
    db.commit(); db.refresh(experiment)
    return experiment
