from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from sqlalchemy.orm import Session

from app.models import ChurnLabel, FeatureSnapshot
from app.services.ml import NUMERIC_FEATURES, _as_utc, assemble_dataset
from app.utils import json_loads, stable_fingerprint


def audit_training_dataset(
    db: Session,
    feature_version: str = "2.1",
    horizon_days: int = 30,
    as_of: datetime | None = None,
) -> dict[str, Any]:
    """Audit the exact mature dataset used by model training without exposing PII."""
    if not feature_version or len(feature_version) > 32:
        raise ValueError("feature_version must contain 1 to 32 characters")
    if not 1 <= horizon_days <= 365:
        raise ValueError("horizon_days must be 1..365")
    observed_at = _as_utc(as_of or datetime.now(timezone.utc))
    labels = db.query(ChurnLabel).filter(
        ChurnLabel.entity_scope == "customer", ChurnLabel.horizon_days == horizon_days
    ).all()
    exclusions: dict[str, int] = defaultdict(int)
    for label in labels:
        cutoff = _as_utc(label.cutoff_date)
        maturity = _as_utc(label.maturity_date)
        if label.is_censored or label.churn_30d not in (0, 1):
            exclusions["censored_or_unknown_label"] += 1
            continue
        if maturity > observed_at:
            exclusions["label_horizon_not_yet_mature"] += 1
            continue
        if maturity != cutoff + timedelta(days=horizon_days):
            exclusions["maturity_date_mismatch"] += 1
            continue
        event = _as_utc(label.event_date) if label.event_date is not None else None
        if label.churn_30d == 1 and (event is None or not (cutoff < event <= maturity)):
            exclusions["positive_event_outside_horizon"] += 1
            continue
        if label.churn_30d == 0 and event is not None:
            exclusions["negative_label_has_event_date"] += 1
            continue
        snapshot = db.query(FeatureSnapshot).filter_by(
            customer_id=label.customer_id, cutoff_date=label.cutoff_date,
            feature_version=feature_version,
        ).one_or_none()
        if snapshot is None:
            exclusions["exact_feature_snapshot_missing"] += 1
            continue
        try:
            decoded = json_loads(snapshot.features_json)
        except (TypeError, ValueError):
            exclusions["feature_snapshot_invalid_json"] += 1
            continue
        if not isinstance(decoded, dict):
            exclusions["feature_snapshot_not_object"] += 1

    rows = assemble_dataset(db, feature_version, horizon_days)
    missing_by_feature: dict[str, int] = {}
    for name in NUMERIC_FEATURES:
        missing_by_feature[name] = sum(
            1 for row in rows
            if row.get(name) is None or not np.isfinite(float(row.get(name)))
        )
    cutoffs = sorted({_as_utc(row["cutoff_date"]) for row in rows})
    partitions: dict[str, list[dict[str, Any]]] = {"train": [], "validation": [], "test": []}
    if len(cutoffs) >= 3:
        train_end = max(1, int(len(cutoffs) * 0.60))
        validation_end = max(train_end + 1, int(len(cutoffs) * 0.80))
        validation_end = min(validation_end, len(cutoffs) - 1)
        train_dates = set(cutoffs[:train_end])
        validation_dates = set(cutoffs[train_end:validation_end])
        test_dates = set(cutoffs[validation_end:])
        partitions = {
            "train": [row for row in rows if _as_utc(row["cutoff_date"]) in train_dates],
            "validation": [row for row in rows if _as_utc(row["cutoff_date"]) in validation_dates],
            "test": [row for row in rows if _as_utc(row["cutoff_date"]) in test_dates],
        }

    partition_summary = {}
    customer_partition: dict[int, set[str]] = defaultdict(set)
    for name, part in partitions.items():
        positive = sum(int(row["label"]) for row in part)
        partition_summary[name] = {
            "rows": len(part), "positive": positive, "negative": len(part) - positive,
            "first_cutoff": min((_as_utc(row["cutoff_date"]).isoformat() for row in part), default=None),
            "last_cutoff": max((_as_utc(row["cutoff_date"]).isoformat() for row in part), default=None),
            "has_both_classes": positive > 0 and positive < len(part),
        }
        for row in part:
            customer_partition[int(row["customer_id"])].add(name)
    overlap_customers = sum(len(names) > 1 for names in customer_partition.values())

    rows_for_fingerprint = [{
        "customer_id": int(row["customer_id"]),
        "cutoff": _as_utc(row["cutoff_date"]).isoformat(),
        "label": int(row["label"]),
        "fp": row["source_fingerprint"],
    } for row in rows]
    fingerprint = stable_fingerprint(rows_for_fingerprint)
    checks = {
        "minimum_rows_30": len(rows) >= 30,
        "at_least_three_cutoffs": len(cutoffs) >= 3,
        "all_three_partitions_have_at_least_10_rows": all(partition_summary[k]["rows"] >= 10 for k in partitions),
        "all_three_partitions_have_both_classes": all(partition_summary[k]["has_both_classes"] for k in partitions),
        "feature_contract_has_no_target_like_names": not any(
            any(token in name.lower() for token in ("churn", "cancel", "termination", "label", "target", "event_date"))
            for name in NUMERIC_FEATURES
        ),
    }
    ready = all(checks.values())
    missing_rates = {
        name: {"missing": count, "rate": round(count / len(rows), 6) if rows else None}
        for name, count in missing_by_feature.items()
    }
    class_positive = sum(int(row["label"]) for row in rows)
    return {
        "status": "ready_for_training" if ready else "insufficient_or_blocked",
        "observed_at": observed_at.isoformat(),
        "feature_version": feature_version,
        "horizon_days": horizon_days,
        "dataset": {
            "rows": len(rows), "unique_customers": len({int(row["customer_id"]) for row in rows}),
            "cutoff_count": len(cutoffs), "first_cutoff": cutoffs[0].isoformat() if cutoffs else None,
            "last_cutoff": cutoffs[-1].isoformat() if cutoffs else None,
            "positive": class_positive, "negative": len(rows) - class_positive,
            "positive_rate": round(class_positive / len(rows), 6) if rows else None,
            "fingerprint": fingerprint,
        },
        "partitions": partition_summary,
        "feature_missingness": missing_rates,
        "exclusions": dict(sorted(exclusions.items())),
        "readiness_checks": checks,
        "repeated_customers_across_partitions": overlap_customers,
        "warnings": [
            "Repeated customers may appear in more than one chronological cutoff partition; this estimates future scoring for an existing population, not new-customer generalization.",
            "Feature source timestamps are not reconstructed from the opaque source fingerprint. Point-in-time correctness relies on the feature builder's cutoff filters and should be audited against source extracts for a company dataset.",
            "A ready status validates dataset structure only; it is not evidence of real-world model accuracy, fairness, or business value.",
        ],
    }
