from __future__ import annotations

import json
import math
import os
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sqlalchemy.orm import Session
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score,
                             log_loss, balanced_accuracy_score)
from sklearn.calibration import calibration_curve, CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

from app.config import settings
from app.models import ChurnLabel, Customer, FeatureSnapshot, ModelRelease, Prediction, PredictionBatch, TrainingRun
from app.utils import json_dumps, json_loads, finite_probability, risk_band, stable_fingerprint

NUMERIC_FEATURES = [
    "tenure_days", "active_subscription_count", "subscription_count", "usage_events_7d",
    "usage_events_30d", "usage_events_90d", "usage_quantity_30d", "usage_decline_7d_vs_prior_7d",
    "inactivity_days", "payment_failures_90d", "support_tickets_30d", "open_support_tickets",
    "high_priority_tickets", "invoices_count", "successful_payment_count", "failed_payment_rate_90d",
    "mrr_single_currency", "paid_single_currency_90d",
    "usage_active_days_30d", "usage_event_type_count_30d", "usage_decline_30d_vs_prior_30d",
    "usage_velocity_7d", "usage_velocity_30d", "payment_recency_days", "payment_frequency_90d",
    "overdue_invoice_count", "median_support_resolution_hours", "active_contract_days_remaining",
    "active_plan_diversity", "average_active_subscription_mrr_single_currency",
    "invoice_recency_days", "invoice_frequency_90d", "invoice_single_currency_90d",
]


def _as_utc(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def assemble_dataset(db: Session, feature_version: str = "2.1", horizon_days: int = 30) -> list[dict[str, Any]]:
    """Assemble only exact, mature, uncensored labels with valid event-window semantics.

    Feature snapshots are joined on the exact customer/cutoff/version tuple. A
    label cannot enter training until its horizon has matured relative to the
    real current time, even if a caller previously supplied a future `as_of`.
    """
    rows = []
    now = datetime.now(timezone.utc)
    labels = db.query(ChurnLabel).filter(ChurnLabel.entity_scope == "customer",
                                         ChurnLabel.horizon_days == horizon_days,
                                         ChurnLabel.churn_30d.in_([0, 1]),
                                         ChurnLabel.is_censored.is_(False)).all()
    for label in labels:
        cutoff = _as_utc(label.cutoff_date)
        maturity = _as_utc(label.maturity_date)
        if maturity > now or maturity != cutoff + timedelta(days=horizon_days):
            continue
        event = _as_utc(label.event_date) if label.event_date is not None else None
        target = int(label.churn_30d)
        if target == 1 and (event is None or not (cutoff < event <= maturity)):
            continue
        if target == 0 and event is not None:
            continue
        snapshot = db.query(FeatureSnapshot).filter_by(customer_id=label.customer_id,
                                                       cutoff_date=label.cutoff_date,
                                                       feature_version=feature_version).one_or_none()
        if snapshot is None:
            continue
        try:
            raw = json_loads(snapshot.features_json)
        except (TypeError, ValueError):
            continue
        if not isinstance(raw, dict):
            continue
        numeric = {}
        for key in NUMERIC_FEATURES:
            value = raw.get(key)
            try:
                numeric[key] = float(value) if value is not None and math.isfinite(float(value)) else np.nan
            except (TypeError, ValueError):
                numeric[key] = np.nan
        rows.append({"customer_id": label.customer_id, "cutoff_date": label.cutoff_date,
                     "label": target, "feature_snapshot_id": snapshot.id,
                     "source_fingerprint": snapshot.source_fingerprint, **numeric})
    return sorted(rows, key=lambda x: (x["cutoff_date"], x["customer_id"]))


def _metrics(y_true, probs, threshold: float = 0.5) -> dict[str, Any]:
    y_pred = (np.asarray(probs) >= threshold).astype(int)
    y = np.asarray(y_true).astype(int)
    p = np.clip(np.asarray(probs, dtype=float), 1e-7, 1 - 1e-7)
    cm = confusion_matrix(y, y_pred, labels=[0, 1]).tolist()
    tn, fp, fn, tp = cm[0][0], cm[0][1], cm[1][0], cm[1][1]
    result = {
        "sample_count": int(len(y)), "positive_count": int(y.sum()),
        "negative_count": int(len(y) - y.sum()), "threshold": float(threshold),
        "precision": float(precision_score(y, y_pred, zero_division=0)),
        "recall": float(recall_score(y, y_pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)) if tn + fp else None,
        "balanced_accuracy": float(balanced_accuracy_score(y, y_pred)) if len(set(y)) > 1 else None,
        "f1": float(f1_score(y, y_pred, zero_division=0)),
        "brier_score": float(brier_score_loss(y, p)),
        "log_loss": float(log_loss(y, p, labels=[0, 1])),
        "confusion_matrix": cm,
    }
    result["pr_auc"] = float(average_precision_score(y, p)) if len(set(y)) > 1 else None
    result["roc_auc"] = float(roc_auc_score(y, p)) if len(set(y)) > 1 else None
    return result


def _threshold_analysis(y_true, probabilities) -> dict[str, Any]:
    thresholds = [round(x, 2) for x in np.linspace(.10, .90, 17)]
    points = [_metrics(y_true, probabilities, threshold) for threshold in thresholds]
    # Threshold is selected solely on validation F1; final test labels remain untouched.
    best = max(points, key=lambda x: (x["f1"], x["precision"], -abs(x["threshold"] - .5)))
    return {"selected_threshold": best["threshold"], "selection_metric": "validation_f1",
            "points": points, "warning": "Threshold selection is a validation-only policy choice; do not select a threshold on the held-out test set."}


def _cost_threshold_analysis(y_true, probabilities, false_positive_cost: float,
                             false_negative_cost: float, cost_unit: str = "business_units") -> dict[str, Any]:
    if not math.isfinite(false_positive_cost) or not math.isfinite(false_negative_cost):
        raise ValueError("Decision costs must be finite")
    if false_positive_cost < 0 or false_negative_cost < 0 or false_positive_cost + false_negative_cost == 0:
        raise ValueError("Provide non-negative decision costs with at least one positive cost")
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(probabilities, dtype=float)
    points = []
    for threshold in [round(x, 2) for x in np.linspace(.10, .90, 17)]:
        pred = (p >= threshold).astype(int)
        tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel().tolist()
        total = fp * false_positive_cost + fn * false_negative_cost
        points.append({"threshold": threshold, "false_positives": int(fp), "false_negatives": int(fn),
                       "true_positives": int(tp), "true_negatives": int(tn),
                       "false_positive_cost": float(fp * false_positive_cost),
                       "false_negative_cost": float(fn * false_negative_cost),
                       "total_cost": float(total), "cost_per_observation": float(total / len(y)) if len(y) else None})
    best = min(points, key=lambda x: (x["total_cost"], abs(x["threshold"] - .5)))
    return {"selected_threshold": best["threshold"], "selection_metric": "minimum_validation_expected_decision_cost",
            "cost_unit": cost_unit, "assumptions": {"false_positive_cost": float(false_positive_cost),
            "false_negative_cost": float(false_negative_cost)}, "points": points,
            "minimum_validation_cost": best["total_cost"],
            "warning": "This optimizes the supplied per-error costs on validation data only. Costs must use one consistent business unit/currency and be approved by finance; held-out test labels were not used for threshold selection."}


def _calibration_summary(y_true, probabilities, bins: int = 8) -> dict[str, Any]:
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(probabilities, dtype=float)
    if not len(y):
        return {"available": False, "reason": "empty_partition"}
    fraction, mean = calibration_curve(y, p, n_bins=min(bins, max(2, len(y)//3)), strategy="quantile")
    ece = float(np.mean(np.abs(fraction - mean))) if len(fraction) else None
    return {"available": True, "method": "quantile reliability bins", "expected_calibration_error": ece,
            "bins": [{"mean_predicted_probability": float(m), "observed_event_rate": float(f)}
                     for m, f in zip(mean, fraction)],
            "brier_score": float(brier_score_loss(y, p)),
            "caveat": "Calibration estimates are noisy on small cohorts and are not a substitute for prospective validation."}


def _bootstrap_metric_intervals(rows, probabilities, repetitions: int = 200, seed: int = 73) -> dict[str, Any]:
    # Cluster bootstrap by customer keeps repeated observations for a sampled customer together.
    rng = np.random.default_rng(seed)
    customers = sorted({int(r["customer_id"]) for r in rows})
    if len(customers) < 10:
        return {"available": False, "reason": "fewer_than_10_unique_customers"}
    idx_by_customer = {c: np.asarray([i for i, r in enumerate(rows) if int(r["customer_id"]) == c], dtype=int) for c in customers}
    y = np.asarray([r["label"] for r in rows], dtype=int)
    p = np.asarray(probabilities, dtype=float)
    pr_values, roc_values = [], []
    for _ in range(repetitions):
        chosen = rng.choice(customers, size=len(customers), replace=True)
        indices = np.concatenate([idx_by_customer[int(c)] for c in chosen])
        if len(set(y[indices])) < 2:
            continue
        pr_values.append(float(average_precision_score(y[indices], p[indices])))
        roc_values.append(float(roc_auc_score(y[indices], p[indices])))
    if len(pr_values) < 30:
        return {"available": False, "reason": "insufficient_valid_cluster_resamples", "valid_resamples": len(pr_values)}
    return {"available": True, "method": "customer-cluster bootstrap percentile interval", "valid_resamples": len(pr_values),
            "pr_auc_95_ci": [float(x) for x in np.quantile(pr_values, [.025, .975])],
            "roc_auc_95_ci": [float(x) for x in np.quantile(roc_values, [.025, .975])],
            "warning": "Intervals are unstable with few independent customers; they quantify sample uncertainty, not generalization to another company."}


def _make_pipeline(algorithm: str, config: dict[str, Any] | None = None):
    config = config or {}
    preprocessing = Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                              ("scale", StandardScaler())])
    # Keep a stable, named feature matrix through every estimator. LightGBM's
    # sklearn wrapper records feature_names_in_ during fit and warns (or fails
    # under strict warning policies) when prediction receives an unnamed array.
    # All supported sklearn versions in requirements.txt support set_output.
    preprocessing.set_output(transform="pandas")
    if algorithm == "logistic_regression":
        estimator = LogisticRegression(max_iter=1200, class_weight="balanced", random_state=41,
                                       C=float(config.get("C", 1.0)))
    elif algorithm == "random_forest":
        estimator = RandomForestClassifier(n_estimators=int(config.get("n_estimators", 160)),
                                           max_depth=int(config.get("max_depth", 8)), min_samples_leaf=2,
                                           class_weight="balanced_subsample", random_state=41, n_jobs=1)
    elif algorithm == "xgboost":
        try:
            from xgboost import XGBClassifier
        except ImportError as exc:
            raise ValueError("XGBoost is not installed; install requirements-advanced-ml.txt") from exc
        estimator = XGBClassifier(n_estimators=int(config.get("n_estimators", 100)), max_depth=int(config.get("max_depth", 3)),
                                  learning_rate=float(config.get("learning_rate", .05)), subsample=.9,
                                  colsample_bytree=.9, reg_lambda=1.0, objective="binary:logistic",
                                  eval_metric="logloss", random_state=41, n_jobs=1, verbosity=0)
    elif algorithm == "lightgbm":
        try:
            from lightgbm import LGBMClassifier
        except ImportError as exc:
            raise ValueError("LightGBM is not installed; install requirements-advanced-ml.txt") from exc
        estimator = LGBMClassifier(n_estimators=int(config.get("n_estimators", 100)),
                                   max_depth=int(config.get("max_depth", -1)), num_leaves=15,
                                   learning_rate=float(config.get("learning_rate", .05)),
                                   class_weight="balanced", random_state=41, n_jobs=1, verbosity=-1)
    else:
        raise ValueError("Unsupported algorithm")
    return Pipeline([("features", preprocessing), ("model", estimator)])


def _available_algorithms() -> list[str]:
    choices = ["logistic_regression", "random_forest"]
    try:
        import xgboost  # noqa: F401
        choices.append("xgboost")
    except ImportError:
        pass
    try:
        import lightgbm  # noqa: F401
        choices.append("lightgbm")
    except ImportError:
        pass
    return choices

def train_models(db: Session, feature_version: str = "2.1", horizon_days: int = 30,
                 false_positive_cost: float | None = None, false_negative_cost: float | None = None,
                 cost_unit: str = "business_units") -> dict[str, Any]:
    rows = assemble_dataset(db, feature_version, horizon_days)
    if (false_positive_cost is None) != (false_negative_cost is None):
        raise ValueError("Provide both false_positive_cost and false_negative_cost, or neither")
    if false_positive_cost is not None and (false_positive_cost < 0 or false_negative_cost < 0):
        raise ValueError("Decision costs cannot be negative")
    if len(rows) < 30:
        raise ValueError(f"At least 30 mature labeled feature snapshots are required; found {len(rows)}")
    cutoffs = sorted({x["cutoff_date"] for x in rows})
    if len(cutoffs) < 3:
        raise ValueError("At least three distinct historical cutoff dates are required for chronological train/validation/test")
    train_end = max(1, int(len(cutoffs) * .60))
    val_end = max(train_end + 1, int(len(cutoffs) * .80))
    val_end = min(val_end, len(cutoffs) - 1)
    train_dates, val_dates, test_dates = set(cutoffs[:train_end]), set(cutoffs[train_end:val_end]), set(cutoffs[val_end:])
    train = [r for r in rows if r["cutoff_date"] in train_dates]
    valid = [r for r in rows if r["cutoff_date"] in val_dates]
    test = [r for r in rows if r["cutoff_date"] in test_dates]
    def valid_partition(part, name):
        if len(part) < 10 or len({x["label"] for x in part}) < 2:
            raise ValueError(f"{name} partition requires at least 10 observations and both target classes; found {len(part)}")
    valid_partition(train, "Training"); valid_partition(valid, "Validation"); valid_partition(test, "Test")
    x_train = np.asarray([[r[k] for k in NUMERIC_FEATURES] for r in train], dtype=float)
    y_train = np.asarray([r["label"] for r in train], dtype=int)
    x_val = np.asarray([[r[k] for k in NUMERIC_FEATURES] for r in valid], dtype=float)
    y_val = np.asarray([r["label"] for r in valid], dtype=int)
    x_test = np.asarray([[r[k] for k in NUMERIC_FEATURES] for r in test], dtype=float)
    y_test = np.asarray([r["label"] for r in test], dtype=int)
    candidate_configs = {
        "logistic_regression": [{"C": .5}, {"C": 1.0}, {"C": 2.0}],
        "random_forest": [{"n_estimators": 120, "max_depth": 5}, {"n_estimators": 160, "max_depth": 8}],
        "xgboost": [{"n_estimators": 80, "max_depth": 2}, {"n_estimators": 120, "max_depth": 3}],
        "lightgbm": [{"n_estimators": 80, "max_depth": 4}, {"n_estimators": 120, "max_depth": 6}],
    }
    candidates = []
    candidate_results = []
    for algorithm in _available_algorithms():
        for config in candidate_configs[algorithm]:
            pipeline = _make_pipeline(algorithm, config)
            pipeline.fit(x_train, y_train)
            val_probs = pipeline.predict_proba(x_val)[:, 1]
            val_metrics = _metrics(y_val, val_probs)
            score = val_metrics["pr_auc"] if val_metrics["pr_auc"] is not None else 0.0
            candidates.append((score, algorithm, config, pipeline, val_metrics, val_probs))
            candidate_results.append({"algorithm": algorithm, "parameters": config,
                                      "validation_pr_auc": score, "validation_f1_at_0_5": val_metrics["f1"]})
    if not candidates:
        raise ValueError("No supported model algorithm is available")
    _, chosen, chosen_config, model, validation_metrics, val_probs = max(candidates, key=lambda x: (x[0], x[4]["f1"]))
    # Fit probability calibration using only the chronological training partition.
    # Validation is used only to select the decision threshold; test remains untouched
    # until the final one-time report.
    predictor = model
    calibration_status = {"available": False, "reason": "training_partition_too_small_for_3_fold_calibration"}
    class_counts = np.bincount(y_train, minlength=2)
    if int(class_counts.min()) >= 3:
        try:
            cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=73)
            predictor = CalibratedClassifierCV(estimator=model, method="sigmoid", cv=cv)
            predictor.fit(x_train, y_train)
            calibration_status = {"available": True, "method": "sigmoid", "fit_partition": "training_only",
                                  "cross_validation_folds": 3,
                                  "note": "Calibration fit excludes validation and final test observations."}
        except Exception as exc:
            predictor = model
            calibration_status = {"available": False, "reason": type(exc).__name__,
                                  "note": "Uncalibrated candidate retained; inspect dependency compatibility."}
    val_scoring = predictor.predict_proba(x_val)[:, 1]
    threshold_policy = (_cost_threshold_analysis(y_val, val_scoring, false_positive_cost,
                                                  false_negative_cost, cost_unit)
                        if false_positive_cost is not None and false_negative_cost is not None
                        else _threshold_analysis(y_val, val_scoring))
    selected_threshold = threshold_policy["selected_threshold"]
    test_probs = predictor.predict_proba(x_test)[:, 1]
    test_metrics = _metrics(y_test, test_probs, selected_threshold)
    test_calibration = _calibration_summary(y_test, test_probs)
    test_ci = _bootstrap_metric_intervals(test, test_probs)
    release_id, run_id = str(uuid.uuid4()), str(uuid.uuid4())
    settings.artifact_dir.mkdir(parents=True, exist_ok=True)
    artifact = settings.artifact_dir / f"model-{release_id}.joblib"
    joblib.dump({"pipeline": model, "predictor": predictor, "calibration": calibration_status,
                 "features": NUMERIC_FEATURES, "feature_version": feature_version,
                 "horizon_days": horizon_days, "algorithm": chosen, "parameters": chosen_config,
                 "decision_threshold": selected_threshold,
                 "background": x_train[:min(len(x_train), 80)]}, artifact)
    fingerprint = stable_fingerprint([{"customer_id":r["customer_id"],"cutoff":r["cutoff_date"].isoformat(),
                                      "label":r["label"],"fp":r["source_fingerprint"]} for r in rows])
    metrics = {"validation": _metrics(y_val, val_scoring, selected_threshold),
               "validation_raw_model": validation_metrics,
               "validation_calibrated": _metrics(y_val, val_scoring, selected_threshold),
               "probability_calibration": calibration_status,
               "test": test_metrics,
               "test_calibration": test_calibration, "test_confidence_intervals": test_ci,
               "threshold_analysis": threshold_policy,
               "candidate_comparison": candidate_results,
               "algorithms_available": _available_algorithms(),
               "split": {"strategy": "chronological by unique prediction cutoff",
                         "train_cutoffs": [x.isoformat() for x in sorted(train_dates)],
                         "validation_cutoffs": [x.isoformat() for x in sorted(val_dates)],
                         "test_cutoffs": [x.isoformat() for x in sorted(test_dates)],
                         "train_rows": len(train), "validation_rows": len(valid), "test_rows": len(test),
                         "unique_customers": len({x["customer_id"] for x in rows})},
               "metric_provenance": "local dataset; not a real-company performance claim"}
    try:
        from app.integrations.mlflow_tracking import track_training_run
        metrics["mlflow_tracking"] = track_training_run(run_id, chosen, chosen_config, metrics, artifact,
                                                         dataset_fingerprint=fingerprint)
    except Exception as exc:
        metrics["mlflow_tracking"] = {"status": "error", "error_type": type(exc).__name__}
    db.add(TrainingRun(run_id=run_id, status="completed", algorithm=chosen,
                       dataset_fingerprint=fingerprint, feature_version=feature_version,
                       metrics_json=json_dumps(metrics), artifact_path=str(artifact)))
    db.add(ModelRelease(release_id=release_id, training_run_id=run_id, model_name=chosen,
                        artifact_path=str(artifact), status="candidate", feature_version=feature_version,
                        horizon_days=horizon_days, metrics_json=json_dumps(metrics)))
    db.commit()
    return {"run_id": run_id, "release_id": release_id, "algorithm": chosen,
            "status": "candidate_requires_approval", "metrics": metrics, "artifact": artifact.name}

def approve_release(db: Session, release_id: str, approver_id: int) -> ModelRelease:
    release = db.query(ModelRelease).filter_by(release_id=release_id).one_or_none()
    if not release: raise ValueError("Model release not found")
    if release.status not in {"candidate", "approved"}: raise ValueError("Only a candidate may be approved")
    if not Path(release.artifact_path).exists(): raise ValueError("Model artifact is missing")
    # Keep a single currently approved release per horizon; preserve prior release records.
    for old in db.query(ModelRelease).filter_by(status="approved", horizon_days=release.horizon_days).all():
        old.status = "superseded"
    release.status = "approved"
    release.approved_by = approver_id
    release.approved_at = datetime.now(timezone.utc)
    db.commit()
    return release


def predict_customer(db: Session, customer_id: int, cutoff: datetime, release_id: str | None = None,
                     include_explanation: bool = True) -> dict[str, Any]:
    from app.services.data import build_features
    cutoff = cutoff if cutoff.tzinfo else cutoff.replace(tzinfo=timezone.utc)
    cutoff = cutoff.astimezone(timezone.utc)
    releases = db.query(ModelRelease).filter_by(status="approved")
    if release_id:
        releases = releases.filter_by(release_id=release_id)
    release = releases.order_by(ModelRelease.approved_at.desc()).first()
    if not release: raise ValueError("No approved model release is available")
    build_features(db, cutoff, release.feature_version, customer_ids=[customer_id])
    snapshot = db.query(FeatureSnapshot).filter_by(customer_id=customer_id, cutoff_date=cutoff,
                                                     feature_version=release.feature_version).one_or_none()
    if snapshot is None: raise ValueError("Point-in-time feature snapshot not found")
    existing = db.query(Prediction).filter_by(customer_id=customer_id, release_id=release.release_id,
                                               cutoff_date=cutoff, horizon_days=release.horizon_days).one_or_none()
    if existing:
        return {"prediction_id": existing.id, "customer_id": customer_id, "probability": existing.probability,
                "risk_band": existing.risk_band, "release_id": release.release_id, "idempotent_reuse": True}
    bundle = joblib.load(release.artifact_path)
    if bundle.get("feature_version") != release.feature_version or bundle.get("horizon_days") != release.horizon_days:
        raise ValueError("Model artifact metadata does not match approved release")
    values = json_loads(snapshot.features_json)
    vector = []
    for key in bundle["features"]:
        value = values.get(key)
        vector.append(float(value) if value is not None else np.nan)
    scoring_model = bundle.get("predictor", bundle["pipeline"])
    probability = finite_probability(scoring_model.predict_proba(np.asarray([vector], dtype=float))[0, 1])
    explanation = (explain_prediction(bundle, vector) if include_explanation else {
        "method": "not_requested", "available": False,
        "disclaimer": "Explanation was skipped for this operational scoring call."
    })
    record = Prediction(customer_id=customer_id, release_id=release.release_id, cutoff_date=cutoff,
                        horizon_days=release.horizon_days, probability=probability,
                        risk_band=risk_band(probability), feature_snapshot_id=snapshot.id,
                        explanation_json=json_dumps(explanation))
    db.add(record); db.commit(); db.refresh(record)
    return {"prediction_id": record.id, "customer_id": customer_id, "probability": probability,
            "risk_band": record.risk_band, "release_id": release.release_id, "idempotent_reuse": False,
            "explanation": explanation}


def explain_prediction(bundle: dict[str, Any], vector: list[float]) -> dict[str, Any]:
    pipeline = bundle["pipeline"]
    names = bundle["features"]
    try:
        import shap
        estimator = pipeline.named_steps["model"]
        transform = pipeline.named_steps["features"]
        transformed = np.asarray(transform.transform(np.asarray([vector], dtype=float)), dtype=float)
        background = np.asarray(bundle.get("background", []), dtype=float)
        transformed_background = np.asarray(transform.transform(background), dtype=float) if len(background) else None
        if hasattr(estimator, "feature_importances_"):
            explainer = shap.TreeExplainer(estimator)
            output = explainer.shap_values(transformed)
            base = explainer.expected_value
            if isinstance(output, list):
                contributions = np.asarray(output[-1])[0]
                base_value = float(np.asarray(base).reshape(-1)[-1])
            elif np.asarray(output).ndim == 3:
                contributions = np.asarray(output)[0, :, -1]
                base_value = float(np.asarray(base).reshape(-1)[-1])
            else:
                contributions = np.asarray(output).reshape(-1)
                base_value = float(np.asarray(base).reshape(-1)[-1] if np.asarray(base).ndim else base)
            predicted = float(pipeline.predict_proba(np.asarray([vector], dtype=float))[0, 1])
            reconstructed = base_value + float(np.sum(contributions))
            error = abs(reconstructed - predicted)
            feature_names = list(names) + [f"{name}__missing" for name in names]
            if len(feature_names) != len(contributions):
                feature_names = [f"transformed_feature_{i}" for i in range(len(contributions))]
            order = np.argsort(np.abs(contributions))[::-1][:10]
            return {"method": "SHAP TreeExplainer", "available": True,
                    "top_factors": [{"feature": feature_names[int(i)], "shap_value": float(contributions[i]),
                                     "feature_value": None} for i in order],
                    "base_value": base_value, "model_probability": predicted,
                    "additivity_error": error, "additivity_verified": error <= 0.02,
                    "explanation_scope": "local model-output attribution", "causal": False}
        if hasattr(estimator, "coef_") and transformed_background is not None:
            explainer = shap.LinearExplainer(estimator, transformed_background)
            values = explainer(transformed)
            contributions = np.asarray(values.values).reshape(-1)
            base = float(np.asarray(values.base_values).reshape(-1)[0])
            feature_names = list(names) + [f"{name}__missing" for name in names]
            if len(feature_names) != len(contributions):
                feature_names = [f"transformed_feature_{i}" for i in range(len(contributions))]
            order = np.argsort(np.abs(contributions))[::-1][:10]
            return {"method": "SHAP LinearExplainer", "available": True,
                    "top_factors": [{"feature": feature_names[int(i)], "shap_value": float(contributions[i])} for i in order],
                    "base_value": base, "additivity_verified": True,
                    "explanation_scope": "linear model-output attribution", "causal": False}
    except Exception as exc:
        shap_error = type(exc).__name__
    else:
        shap_error = "unsupported_model_or_insufficient_background"
    model = pipeline.named_steps["model"]
    fallback: dict[str, Any] = {"method": "model_native_global_importance", "available": False, "top_factors": []}
    try:
        if hasattr(model, "feature_importances_"):
            weights = model.feature_importances_
            fallback["method"] = "tree_feature_importance_not_local_shap"
            fallback["available"] = True
            fallback["top_factors"] = [{"feature": f"transformed_feature_{i}", "importance": float(weights[i])}
                                       for i in np.argsort(weights)[::-1][:8]]
        elif hasattr(model, "coef_"):
            weights = np.abs(model.coef_[0])
            fallback["method"] = "absolute_logistic_coefficients_not_local_shap"
            fallback["available"] = True
            fallback["top_factors"] = [{"feature": f"transformed_feature_{i}", "importance": float(weights[i])}
                                       for i in np.argsort(weights)[::-1][:8]]
    except Exception:
        pass
    fallback["shap_unavailable_reason"] = shap_error
    fallback["disclaimer"] = "Global model importance is not a per-customer SHAP explanation and is not causal."
    return fallback

def rollback_release(db: Session, release_id: str) -> ModelRelease:
    target = db.query(ModelRelease).filter_by(release_id=release_id).one_or_none()
    if not target:
        raise ValueError("Model release not found")
    if target.status not in {"superseded", "approved"}:
        raise ValueError("Only a previously approved or currently approved release can be activated")
    if not Path(target.artifact_path).exists():
        raise ValueError("Model artifact is missing")
    for active in db.query(ModelRelease).filter_by(status="approved", horizon_days=target.horizon_days).all():
        if active.release_id != target.release_id:
            active.status = "superseded"
    target.status = "approved"
    target.approved_at = datetime.now(timezone.utc)
    db.commit()
    return target


def evaluate_matured_predictions(db: Session) -> dict[str, Any]:
    from app.models import ChurnLabel
    from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
    by_release = {}
    records = db.query(Prediction).all()
    for prediction in records:
        label = db.query(ChurnLabel).filter_by(entity_scope="customer", entity_ref=str(
            db.get(Customer, prediction.customer_id).external_id), cutoff_date=prediction.cutoff_date,
            horizon_days=prediction.horizon_days).one_or_none()
        if label is None or label.churn_30d not in (0, 1) or label.is_censored:
            continue
        group = by_release.setdefault(prediction.release_id, {"y": [], "p": []})
        group["y"].append(int(label.churn_30d)); group["p"].append(float(prediction.probability))
    result = {}
    for release_id, values in by_release.items():
        y, p = values["y"], values["p"]
        metrics = {"matured_observations":len(y),"brier_score":float(brier_score_loss(y,p)),
                   "roc_auc":float(roc_auc_score(y,p)) if len(set(y))>1 else None,
                   "pr_auc":float(average_precision_score(y,p)) if len(set(y))>1 else None}
        result[release_id] = metrics
    return {"releases":result,"note":"Only exact customer, prediction-cutoff and horizon matches with matured labels are evaluated. Absence of matured labels is not scored as zero."}



def retry_failed_prediction_batch(db: Session, batch_id: str, new_idempotency_key: str,
                                  cutoff: datetime | None = None) -> dict[str, Any]:
    """Retry only failed customer IDs, preserving the original approved release pin."""
    previous = db.query(PredictionBatch).filter_by(batch_id=batch_id).one_or_none()
    if not previous:
        raise ValueError("Prediction batch not found")
    if previous.status not in {"partial", "failed"}:
        raise ValueError("Only partial or failed batches can be retried")
    failed_ids = [int(x["customer_id"]) for x in json_loads(previous.results_json)
                  if x.get("status") == "failed" and x.get("customer_id") is not None]
    if not failed_ids:
        raise ValueError("The previous batch has no failed customer IDs")
    return score_customer_batch(db, cutoff or previous.cutoff_date, new_idempotency_key,
                                failed_ids, previous.release_id)


def global_shap_summary(db: Session, release_id: str, sample_limit: int = 250) -> dict[str, Any]:
    """Compute mean absolute SHAP attributions over stored predictions for one pinned release."""
    try:
        import shap
    except ImportError:
        return {"available": False, "method": "SHAP not installed", "reason": "install requirements-explainability.txt"}
    release = db.query(ModelRelease).filter_by(release_id=release_id).one_or_none()
    if not release:
        raise ValueError("Model release not found")
    if not Path(release.artifact_path).exists():
        raise ValueError("Model artifact is missing")
    bundle = joblib.load(release.artifact_path)
    if bundle.get("feature_version") != release.feature_version or bundle.get("horizon_days") != release.horizon_days:
        raise ValueError("Model artifact metadata does not match release")
    predictions = db.query(Prediction).filter_by(release_id=release_id).order_by(Prediction.created_at.desc()).limit(min(max(sample_limit, 10), 1000)).all()
    rows = []
    for prediction in predictions:
        snapshot = db.get(FeatureSnapshot, prediction.feature_snapshot_id)
        if snapshot is None or snapshot.feature_version != release.feature_version:
            continue
        values = json_loads(snapshot.features_json)
        rows.append([float(values[k]) if values.get(k) is not None else np.nan for k in bundle["features"]])
    if len(rows) < 10:
        return {"available": False, "method": "SHAP", "reason": "at_least_10_saved_predictions_with_matching_feature_snapshots_required",
                "sample_count": len(rows)}
    pipeline = bundle["pipeline"]
    transformer = pipeline.named_steps["features"]
    estimator = pipeline.named_steps["model"]
    matrix = np.asarray(rows, dtype=float)
    transformed = np.asarray(transformer.transform(matrix), dtype=float)
    background = np.asarray(bundle.get("background", []), dtype=float)
    transformed_background = np.asarray(transformer.transform(background), dtype=float) if len(background) else None
    try:
        if hasattr(estimator, "feature_importances_"):
            explainer = shap.TreeExplainer(estimator)
            values = explainer.shap_values(transformed)
            base = explainer.expected_value
            if isinstance(values, list):
                contributions = np.asarray(values[-1], dtype=float)
                base_value = float(np.asarray(base).reshape(-1)[-1])
            elif np.asarray(values).ndim == 3:
                contributions = np.asarray(values, dtype=float)[:, :, -1]
                base_value = float(np.asarray(base).reshape(-1)[-1])
            else:
                contributions = np.asarray(values, dtype=float)
                base_value = float(np.asarray(base).reshape(-1)[-1] if np.asarray(base).ndim else base)
        elif hasattr(estimator, "coef_") and transformed_background is not None:
            explanation = shap.LinearExplainer(estimator, transformed_background)(transformed)
            contributions = np.asarray(explanation.values, dtype=float)
            base_value = float(np.asarray(explanation.base_values).reshape(-1)[0])
        else:
            return {"available": False, "method": "SHAP", "reason": "model_family_not_supported", "sample_count": len(rows)}
        if contributions.ndim != 2 or contributions.shape[0] != len(rows):
            raise ValueError("Unexpected SHAP value tensor shape")
        feature_names = list(bundle["features"]) + [f"{name}__missing" for name in bundle["features"]]
        if len(feature_names) != contributions.shape[1]:
            feature_names = [f"transformed_feature_{i}" for i in range(contributions.shape[1])]
        mean_abs = np.mean(np.abs(contributions), axis=0)
        top = np.argsort(mean_abs)[::-1][:20]
        return {"available": True, "method": "SHAP global mean absolute attribution",
                "release_id": release_id, "algorithm": release.model_name, "sample_count": len(rows),
                "base_value": base_value,
                "top_features": [{"feature": feature_names[int(i)], "mean_abs_shap": float(mean_abs[i])} for i in top],
                "interpretation": "Magnitude of contribution to model output over stored scored cases. Not causal and not a substitute for segment-specific review.",
                "output_space": "model raw output for tree/linear explainers; do not interpret as probability units"}
    except Exception as exc:
        return {"available": False, "method": "SHAP", "reason": type(exc).__name__, "sample_count": len(rows)}


def customer_360(db: Session, customer_id: int) -> dict[str, Any] | None:
    from app.models import (Invoice, Payment, SupportTicket, Subscription, UsageEvent,
                            CRMAction, RetentionRecommendation, AuditEvent)
    customer = db.get(Customer, customer_id)
    if customer is None:
        return None
    subscriptions = db.query(Subscription).filter_by(customer_id=customer_id).all()
    invoices = db.query(Invoice).filter_by(customer_id=customer_id).all()
    payments = db.query(Payment).filter_by(customer_id=customer_id).all()
    usage = db.query(UsageEvent).filter_by(customer_id=customer_id).all()
    tickets = db.query(SupportTicket).filter_by(customer_id=customer_id).all()
    currencies = sorted({x.currency for x in subscriptions} | {x.currency for x in invoices} | {x.currency for x in payments})
    financials = {}
    for currency in currencies:
        currency_invoices = [x for x in invoices if x.currency == currency]
        currency_payments = [x for x in payments if x.currency == currency]
        financials[currency] = {
            "mrr": round(sum(float(x.mrr) for x in subscriptions if x.currency == currency and x.status == "active"), 2),
            "invoiced": round(sum(float(x.amount) for x in currency_invoices), 2),
            "paid": round(sum(float(x.amount) for x in currency_payments if x.status in {"succeeded", "paid", "completed"}), 2),
            "open_invoice_count": sum(x.status not in {"paid", "void", "cancelled", "canceled"} for x in currency_invoices),
            "payment_failure_count": sum(x.status in {"failed", "declined", "reversed"} for x in currency_payments),
        }
    preds = db.query(Prediction).filter_by(customer_id=customer_id).order_by(Prediction.created_at.desc()).limit(10).all()
    recommendations = db.query(RetentionRecommendation).filter_by(customer_id=customer_id).order_by(RetentionRecommendation.created_at.desc()).limit(50).all()
    actions = (db.query(CRMAction).join(RetentionRecommendation, CRMAction.recommendation_id == RetentionRecommendation.id)
               .filter(RetentionRecommendation.customer_id == customer_id).order_by(CRMAction.created_at.desc()).limit(50).all())
    audit = db.query(AuditEvent).filter(AuditEvent.entity_type == "customer", AuditEvent.entity_id == str(customer_id)).limit(100).all()
    timeline: list[dict[str, Any]] = []
    def event(when, kind, title, detail, source_type, source_id, status=None):
        if when:
            timeline.append({"timestamp": when, "type": kind, "title": title, "detail": detail,
                             "source_type": source_type, "source_id": str(source_id), "status": status})
    for row in subscriptions:
        event(row.start_date, "subscription_started", f"Subscription {row.external_id} started", row.plan,
              "subscription", row.id, row.status)
        event(row.cancellation_date or row.end_date, "subscription_ended", f"Subscription {row.external_id} ended",
              row.churn_reason or "End date recorded", "subscription", row.id, row.status)
    for row in invoices:
        event(row.invoice_date, "invoice", f"Invoice {row.external_id}", f"{row.amount} {row.currency}", "invoice", row.id, row.status)
    for row in payments:
        event(row.payment_date, "payment", f"Payment {row.external_id}", f"{row.amount} {row.currency}", "payment", row.id, row.status)
    for row in usage:
        event(row.event_time, "usage", row.event_type, f"Quantity {row.quantity:g}", "usage_event", row.id)
    for row in tickets:
        event(row.created_at, "support_ticket", f"Support ticket {row.external_id}", row.category or "Support interaction",
              "support_ticket", row.id, row.status)
        event(row.resolved_at, "support_resolved", f"Support ticket {row.external_id} resolved", row.priority,
              "support_ticket", row.id, row.status)
    for row in preds:
        event(row.created_at, "churn_prediction", f"Churn prediction {row.risk_band}",
              f"{row.probability:.1%} · {row.horizon_days}-day horizon · release {row.release_id[:8]}",
              "prediction", row.id, row.risk_band)
    for row in recommendations:
        event(row.created_at, "retention_recommendation", row.title, row.rationale,
              "retention_recommendation", row.id, row.status)
    for row in actions:
        event(row.created_at, "crm_action", f"{row.provider} {row.action_type}", row.status,
              "crm_action", row.id, row.status)
    for row in audit:
        event(row.created_at, "audit", row.action, row.metadata_json[:200], "audit_event", row.id)
    def timeline_sort_key(item):
        stamp = item["timestamp"]
        return stamp.replace(tzinfo=timezone.utc) if stamp.tzinfo is None else stamp.astimezone(timezone.utc)
    timeline.sort(key=timeline_sort_key, reverse=True)
    return {"id": customer.id, "external_id": customer.external_id, "name": customer.name,
            "email": customer.email, "segment": customer.segment, "country": customer.country,
            "consent_to_contact": customer.consent_to_contact,
            "subscriptions": [{"id":s.id,"external_id":s.external_id,"plan":s.plan,"status":s.status,
                               "start_date":s.start_date,"end_date":s.end_date,"cancellation_date":s.cancellation_date,
                               "mrr":float(s.mrr),"currency":s.currency,"source_name":s.source_name} for s in subscriptions],
            "invoices": [{"id":x.id,"external_id":x.external_id,"subscription_id":x.subscription_id,
                          "invoice_date":x.invoice_date,"due_date":x.due_date,"amount":float(x.amount),
                          "currency":x.currency,"status":x.status,"source_name":x.source_name} for x in invoices],
            "payments": [{"id":x.id,"external_id":x.external_id,"invoice_id":x.invoice_id,
                          "payment_date":x.payment_date,"amount":float(x.amount),"currency":x.currency,
                          "status":x.status,"source_name":x.source_name} for x in payments],
            "financials_by_currency": financials,
            "usage": {"event_count":len(usage),"last_event":max((x.event_time for x in usage),default=None),
                      "recent_event_types":sorted({x.event_type for x in usage})},
            "support": {"ticket_count":len(tickets),"open_count":sum(x.status not in {"resolved","closed"} for x in tickets),
                        "tickets":[{"id":x.id,"external_id":x.external_id,"created_at":x.created_at,
                                    "resolved_at":x.resolved_at,"status":x.status,"priority":x.priority,
                                    "category":x.category} for x in tickets]},
            "predictions": [{"id":p.id,"probability":p.probability,"risk_band":p.risk_band,
                             "release_id":p.release_id,"cutoff_date":p.cutoff_date,"horizon_days":p.horizon_days,
                             "explanation":json_loads(p.explanation_json)} for p in preds],
            "recommendations": [{"id":r.id,"title":r.title,"category":r.category,"priority":r.priority,
                                 "status":r.status,"created_at":r.created_at,"evidence":json_loads(r.evidence_json)}
                                for r in recommendations],
            "crm_actions": [{"id":a.id,"provider":a.provider,"action_type":a.action_type,"status":a.status,
                             "external_reference":a.external_reference,"created_at":a.created_at} for a in actions],
            "timeline": timeline[:250],
            "timeline_total": len(timeline),
            "data_provenance": {"customer_source":customer.source_name,
                                "subscription_sources":sorted({x.source_name for x in subscriptions}),
                                "invoice_sources":sorted({x.source_name for x in invoices}),
                                "payment_sources":sorted({x.source_name for x in payments}),
                                "usage_sources":sorted({x.source_name for x in usage}),
                                "support_sources":sorted({x.source_name for x in tickets})},
            "freshness": {"latest_usage_at":max((x.event_time for x in usage),default=None),
                          "latest_support_at":max((x.created_at for x in tickets),default=None),
                          "latest_invoice_at":max((x.invoice_date for x in invoices),default=None),
                          "latest_payment_at":max((x.payment_date for x in payments),default=None)}}


def score_customer_batch(db: Session, cutoff: datetime, idempotency_key: str,
                         customer_ids: list[int] | None = None, release_id: str | None = None) -> dict[str, Any]:
    """Score a population with one pinned approved release; isolate row failures and preserve idempotency."""
    from app.services.data import build_features
    cutoff = cutoff if cutoff.tzinfo else cutoff.replace(tzinfo=timezone.utc)
    cutoff = cutoff.astimezone(timezone.utc)
    existing_batch = db.query(PredictionBatch).filter_by(idempotency_key=idempotency_key).one_or_none()
    if existing_batch:
        return {"batch_id": existing_batch.batch_id, "status": existing_batch.status,
                "requested": existing_batch.requested_count, "succeeded": existing_batch.succeeded_count,
                "failed": existing_batch.failed_count, "idempotent_reuse": True,
                "results": json_loads(existing_batch.results_json)}
    releases = db.query(ModelRelease).filter_by(status="approved")
    if release_id:
        releases = releases.filter_by(release_id=release_id)
    release = releases.order_by(ModelRelease.approved_at.desc()).first()
    if not release:
        raise ValueError("No approved model release is available")
    query = db.query(Customer).order_by(Customer.id)
    if customer_ids is not None:
        normalized_ids = sorted(set(int(x) for x in customer_ids))
        if len(normalized_ids) > 5000:
            raise ValueError("A batch may contain at most 5000 customer IDs")
        query = query.filter(Customer.id.in_(normalized_ids))
    customers = query.all()
    if not customers:
        raise ValueError("No customers matched the requested batch")
    batch = PredictionBatch(batch_id=str(uuid.uuid4()), idempotency_key=idempotency_key,
                            release_id=release.release_id, cutoff_date=cutoff, status="running",
                            requested_count=len(customers))
    db.add(batch); db.commit(); db.refresh(batch)
    build_features(db, cutoff, release.feature_version, customer_ids=[c.id for c in customers])
    bundle = joblib.load(release.artifact_path)
    if bundle.get("feature_version") != release.feature_version or bundle.get("horizon_days") != release.horizon_days:
        batch.status = "failed"; batch.failed_count = len(customers)
        batch.results_json = json_dumps([{"error": "artifact_metadata_mismatch"}])
        batch.completed_at = datetime.now(timezone.utc); db.commit()
        raise ValueError("Model artifact metadata does not match the pinned approved release")
    results = []
    succeeded = failed = 0
    for customer in customers:
        try:
            snapshot = db.query(FeatureSnapshot).filter_by(customer_id=customer.id, cutoff_date=cutoff,
                       feature_version=release.feature_version).one_or_none()
            if snapshot is None:
                raise ValueError("point_in_time_snapshot_missing")
            previous = db.query(Prediction).filter_by(customer_id=customer.id, release_id=release.release_id,
                           cutoff_date=cutoff, horizon_days=release.horizon_days).one_or_none()
            if previous:
                results.append({"customer_id": customer.id, "prediction_id": previous.id,
                                "probability": previous.probability, "status": "reused"})
                succeeded += 1
                continue
            values = json_loads(snapshot.features_json)
            vector = [float(values.get(key)) if values.get(key) is not None else np.nan for key in bundle["features"]]
            scoring_model = bundle.get("predictor", bundle["pipeline"])
            probability = finite_probability(scoring_model.predict_proba(np.asarray([vector], dtype=float))[0, 1])
            record = Prediction(customer_id=customer.id, release_id=release.release_id, cutoff_date=cutoff,
                                horizon_days=release.horizon_days, probability=probability, risk_band=risk_band(probability),
                                feature_snapshot_id=snapshot.id, explanation_json=json_dumps({"method": "batch_scoring_not_requested", "available": False}))
            db.add(record); db.flush()
            results.append({"customer_id": customer.id, "prediction_id": record.id,
                            "probability": probability, "risk_band": record.risk_band, "status": "scored"})
            succeeded += 1
        except Exception as exc:
            results.append({"customer_id": customer.id, "status": "failed", "error_type": type(exc).__name__})
            failed += 1
    batch.succeeded_count = succeeded
    batch.failed_count = failed
    batch.status = "completed" if failed == 0 else ("partial" if succeeded else "failed")
    batch.results_json = json_dumps(results)
    batch.completed_at = datetime.now(timezone.utc)
    db.commit()
    return {"batch_id": batch.batch_id, "release_id": release.release_id, "cutoff_at": cutoff,
            "status": batch.status, "requested": len(customers), "succeeded": succeeded, "failed": failed,
            "idempotent_reuse": False, "results": results}
