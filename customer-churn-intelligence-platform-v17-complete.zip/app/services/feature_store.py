from __future__ import annotations

import csv
import io
import math
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from app.models import Customer, FeatureSnapshot
from app.services.ml import NUMERIC_FEATURES
from app.utils import json_loads

FEATURE_VERSION = "2.1"

# Definitions are kept in source control so the same contract is visible in the
# API, UI and training pipeline. Every feature is computed using records whose
# event timestamp is <= the snapshot cutoff.
FEATURE_GROUPS: dict[str, set[str]] = {
    "lifecycle": {
        "tenure_days", "active_subscription_count", "subscription_count",
        "active_contract_days_remaining", "active_plan_diversity",
    },
    "engagement": {
        "usage_events_7d", "usage_events_30d", "usage_events_90d",
        "usage_quantity_30d", "usage_decline_7d_vs_prior_7d", "inactivity_days",
        "usage_active_days_30d", "usage_event_type_count_30d",
        "usage_decline_30d_vs_prior_30d", "usage_velocity_7d", "usage_velocity_30d",
    },
    "billing": {
        "payment_failures_90d", "invoices_count", "successful_payment_count",
        "failed_payment_rate_90d", "mrr_single_currency", "paid_single_currency_90d",
        "payment_recency_days", "payment_frequency_90d", "overdue_invoice_count",
        "average_active_subscription_mrr_single_currency", "invoice_recency_days",
        "invoice_frequency_90d", "invoice_single_currency_90d",
    },
    "support": {
        "support_tickets_30d", "open_support_tickets", "high_priority_tickets",
        "median_support_resolution_hours",
    },
}

FEATURE_DESCRIPTIONS = {
    "tenure_days": "Elapsed days from the customer's first observed subscription start to the cutoff.",
    "active_subscription_count": "Subscriptions considered active at the cutoff under the current lifecycle rules.",
    "subscription_count": "Subscriptions whose start timestamp is no later than the cutoff.",
    "usage_events_7d": "Usage event count in the seven days ending at the cutoff.",
    "usage_events_30d": "Usage event count in the 30 days ending at the cutoff.",
    "usage_events_90d": "Usage event count in the 90 days ending at the cutoff.",
    "usage_quantity_30d": "Sum of usage quantity in the trailing 30-day window.",
    "usage_decline_7d_vs_prior_7d": "Relative usage event-count change in the latest seven days versus the preceding seven days.",
    "inactivity_days": "Whole days since the last observed usage event at or before the cutoff.",
    "payment_failures_90d": "Failed or declined payment count in the trailing 90-day window.",
    "support_tickets_30d": "Support tickets created in the trailing 30-day window.",
    "open_support_tickets": "Support tickets not marked resolved or closed by the cutoff.",
    "high_priority_tickets": "Tickets classified high, urgent or critical by the cutoff.",
    "invoices_count": "Invoice count with invoice timestamp at or before the cutoff.",
    "successful_payment_count": "Successful payment count observed at or before the cutoff.",
    "failed_payment_rate_90d": "Failed payment share among payments in the trailing 90-day window.",
    "mrr_single_currency": "Active subscription MRR; populated only when amounts share a single currency.",
    "paid_single_currency_90d": "Successful payment amount over 90 days; populated only for a single currency.",
    "usage_active_days_30d": "Distinct UTC calendar days with usage in the trailing 30-day window.",
    "usage_event_type_count_30d": "Distinct usage event types in the trailing 30-day window.",
    "usage_decline_30d_vs_prior_30d": "Relative usage event-count change in the latest 30 days versus the prior 30 days.",
    "usage_velocity_7d": "Usage event count per observed day in the trailing seven-day window.",
    "usage_velocity_30d": "Usage event count per observed day in the trailing 30-day window.",
    "payment_recency_days": "Days since the most recent payment observed by the cutoff.",
    "payment_frequency_90d": "Payment event count in the trailing 90-day window.",
    "overdue_invoice_count": "Unsettled invoices with due timestamps before the cutoff.",
    "median_support_resolution_hours": "Median resolution duration for tickets resolved by the cutoff.",
    "active_contract_days_remaining": "Days remaining to the nearest known active subscription end date.",
    "active_plan_diversity": "Number of distinct active plan names at the cutoff.",
    "average_active_subscription_mrr_single_currency": "Mean active subscription MRR when all active subscriptions share one currency.",
    "invoice_recency_days": "Days since the latest invoice observed by the cutoff.",
    "invoice_frequency_90d": "Invoice count in the trailing 90-day window.",
    "invoice_single_currency_90d": "Invoice amount over 90 days; populated only for a single currency.",
}


def _aware(value: datetime) -> datetime:
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def feature_registry(version: str = FEATURE_VERSION) -> dict[str, Any]:
    if version != FEATURE_VERSION:
        raise ValueError(f"Unsupported feature contract version: {version}")
    definitions = []
    for name in NUMERIC_FEATURES:
        group = next((key for key, members in FEATURE_GROUPS.items() if name in members), "unclassified")
        definitions.append({
            "name": name,
            "version": version,
            "group": group,
            "data_type": "number",
            "nullable": True,
            "point_in_time": True,
            "description": FEATURE_DESCRIPTIONS.get(name, name.replace("_", " ").capitalize()),
            "null_semantics": "Unknown, unavailable or not safely aggregatable; not zero unless the transformation explicitly defines zero.",
        })
    return {
        "feature_version": version,
        "contract_status": "implemented_in_source",
        "feature_count": len(definitions),
        "point_in_time_policy": "Only source events timestamped at or before the snapshot cutoff may contribute.",
        "currency_policy": "Monetary values are not summed across currencies; scalar monetary features are null for mixed-currency customers.",
        "mutability": "Snapshots are immutable and uniquely keyed by customer, cutoff timestamp and feature version.",
        "features": definitions,
    }


def feature_store_summary(db: Session, version: str = FEATURE_VERSION) -> dict[str, Any]:
    feature_registry(version)  # Validate the requested contract.
    snapshots = (db.query(FeatureSnapshot)
                 .filter(FeatureSnapshot.feature_version == version)
                 .order_by(FeatureSnapshot.cutoff_date.asc(), FeatureSnapshot.id.asc()).all())
    required = list(NUMERIC_FEATURES)
    missing = {key: 0 for key in required}
    invalid_payloads = 0
    unique_customers: set[int] = set()
    cutoffs: set[str] = set()
    earliest = latest = None
    for row in snapshots:
        unique_customers.add(row.customer_id)
        cutoff = _aware(row.cutoff_date)
        earliest = cutoff if earliest is None or cutoff < earliest else earliest
        latest = cutoff if latest is None or cutoff > latest else latest
        cutoffs.add(cutoff.isoformat())
        try:
            payload = json_loads(row.features_json)
        except (TypeError, ValueError):
            payload = None
        if not isinstance(payload, dict):
            invalid_payloads += 1
            for key in required:
                missing[key] += 1
            continue
        for key in required:
            value = payload.get(key)
            if value is None or isinstance(value, bool):
                missing[key] += 1
                continue
            try:
                if not math.isfinite(float(value)):
                    missing[key] += 1
            except (TypeError, ValueError):
                missing[key] += 1
    total = len(snapshots)
    missingness = {key: {"missing_count": count,
                         "missing_rate": (count / total) if total else None}
                   for key, count in missing.items()}
    return {
        "feature_version": version,
        "snapshot_count": total,
        "unique_customers": len(unique_customers),
        "unique_cutoffs": len(cutoffs),
        "earliest_cutoff": earliest,
        "latest_cutoff": latest,
        "invalid_payload_count": invalid_payloads,
        "feature_count": len(required),
        "missingness": missingness,
        "contract_coverage_rate": (sum(1 for count in missing.values() if count == 0) / len(required)) if required else 1.0,
        "immutability_key": ["customer_id", "cutoff_date", "feature_version"],
        "limitation": "Coverage is descriptive for stored snapshots. It does not prove source-system completeness or feature correctness on company data.",
    }


def latest_online_features(db: Session, customer_id: int, as_of: datetime,
                           version: str = FEATURE_VERSION, freshness_days: int = 7) -> dict[str, Any] | None:
    if freshness_days < 0 or freshness_days > 3650:
        raise ValueError("freshness_days must be between 0 and 3650")
    feature_registry(version)
    point = _aware(as_of)
    row = (db.query(FeatureSnapshot)
           .filter(FeatureSnapshot.customer_id == customer_id,
                   FeatureSnapshot.feature_version == version,
                   FeatureSnapshot.cutoff_date <= point)
           .order_by(FeatureSnapshot.cutoff_date.desc(), FeatureSnapshot.id.desc())
           .first())
    if row is None:
        return None
    customer = db.get(Customer, customer_id)
    if customer is None:
        return None
    cutoff = _aware(row.cutoff_date)
    age_seconds = max(0.0, (point - cutoff).total_seconds())
    age_days = age_seconds / 86400.0
    payload = json_loads(row.features_json)
    if not isinstance(payload, dict):
        raise ValueError("Stored feature snapshot payload is not a JSON object")
    return {
        "customer_id": customer_id,
        "external_id": customer.external_id,
        "feature_version": version,
        "snapshot_id": row.id,
        "cutoff_at": cutoff,
        "as_of": point,
        "age_days": round(age_days, 4),
        "freshness_days_limit": freshness_days,
        "fresh": age_days <= freshness_days,
        "stale": age_days > freshness_days,
        "source_fingerprint": row.source_fingerprint,
        "features": payload,
        "selection_policy": "latest immutable snapshot at or before the requested as_of timestamp; future snapshots are never returned",
    }


def customer_feature_history(db: Session, customer_id: int, version: str = FEATURE_VERSION,
                              limit: int = 50) -> list[dict[str, Any]]:
    feature_registry(version)
    if limit < 1 or limit > 500:
        raise ValueError("limit must be between 1 and 500")
    rows = (db.query(FeatureSnapshot)
            .filter_by(customer_id=customer_id, feature_version=version)
            .order_by(FeatureSnapshot.cutoff_date.desc(), FeatureSnapshot.id.desc())
            .limit(limit).all())
    return [{"snapshot_id": row.id, "cutoff_at": _aware(row.cutoff_date),
             "feature_version": row.feature_version, "source_fingerprint": row.source_fingerprint,
             "created_at": row.created_at} for row in rows]


def export_feature_snapshots(db: Session, version: str = FEATURE_VERSION, limit: int = 10000) -> str:
    feature_registry(version)
    if limit < 1 or limit > 50000:
        raise ValueError("limit must be between 1 and 50000")
    rows = (db.query(FeatureSnapshot)
            .filter_by(feature_version=version)
            .order_by(FeatureSnapshot.cutoff_date.asc(), FeatureSnapshot.customer_id.asc())
            .limit(limit).all())
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    columns = ["snapshot_id", "customer_id", "cutoff_at", "feature_version", "source_fingerprint", *NUMERIC_FEATURES]
    writer.writerow(columns)
    for row in rows:
        try:
            payload = json_loads(row.features_json)
        except (TypeError, ValueError):
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        values: list[Any] = [row.id, row.customer_id, _aware(row.cutoff_date).isoformat(),
                             row.feature_version, row.source_fingerprint]
        values.extend(payload.get(key) for key in NUMERIC_FEATURES)
        writer.writerow(values)
    return output.getvalue()
