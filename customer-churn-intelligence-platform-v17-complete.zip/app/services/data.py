from __future__ import annotations

import csv
import io
import json
import statistics
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import (
    AuditEvent, ChurnLabel, Customer, DataIssue, FeatureSnapshot, ImportBatch, Invoice,
    Payment, Subscription, SupportTicket, UsageEvent,
)
from app.utils import json_dumps, json_loads, parse_datetime, sha256_bytes, stable_fingerprint, to_decimal

DATASET_SCHEMAS: dict[str, set[str]] = {
    "customers": {"customer_id", "name"},
    "subscriptions": {"subscription_id", "customer_id", "start_date"},
    "invoices": {"invoice_id", "customer_id", "invoice_date", "amount"},
    "payments": {"payment_id", "customer_id", "payment_date", "amount"},
    "usage": {"event_id", "customer_id", "event_time"},
    "support": {"ticket_id", "customer_id", "created_at"},
}


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _str(row: dict[str, Any], key: str, default: str = "") -> str:
    value = row.get(key, default)
    return str(value).strip() if value is not None else default


def _money(row: dict[str, Any], key: str):
    value = row.get(key)
    if value in (None, ""):
        return to_decimal(0, field=key)
    amount = to_decimal(value, field=key)
    if amount < 0:
        raise ValueError(f"{key} cannot be negative")
    return amount.quantize(__import__("decimal").Decimal("0.01"))


def _float(row: dict[str, Any], key: str, default: float = 0.0) -> float:
    value = row.get(key)
    if value in (None, ""):
        return default
    amount = to_decimal(value, field=key)
    return float(amount)


def _audit(db: Session, action: str, entity_type: str, entity_id: str, actor_id: int | None = None, metadata: Any = None):
    db.add(AuditEvent(actor_id=actor_id, action=action, entity_type=entity_type,
                      entity_id=entity_id, metadata_json=json_dumps(metadata or {})))


def import_csv(db: Session, dataset_type: str, filename: str, content: bytes, source_name: str = "uploaded_csv") -> dict[str, Any]:
    if dataset_type not in DATASET_SCHEMAS:
        raise ValueError(f"Unsupported dataset_type. Expected one of: {', '.join(DATASET_SCHEMAS)}")
    digest = sha256_bytes(content)
    duplicate = db.query(ImportBatch).filter_by(dataset_type=dataset_type, sha256=digest, status="completed").first()
    if duplicate:
        return {"batch_id": duplicate.id, "status": "duplicate", "records_received": duplicate.records_received,
                "records_accepted": duplicate.records_accepted, "records_rejected": duplicate.records_rejected,
                "message": "This file has already been imported; no records were changed."}
    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("CSV must be UTF-8 encoded") from exc
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise ValueError("CSV must include a header row")
    headers = {h.strip() for h in reader.fieldnames if h}
    missing = DATASET_SCHEMAS[dataset_type] - headers
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")
    rows = list(reader)
    batch = ImportBatch(dataset_type=dataset_type, filename=filename[:255], sha256=digest,
                        source_name=source_name, status="processing", records_received=len(rows))
    db.add(batch)
    db.flush()

    def process(row: dict[str, Any]) -> None:
        if dataset_type == "customers":
            ext = _str(row, "customer_id")
            values = dict(name=_str(row, "name"), email=_str(row, "email") or None,
                          segment=_str(row, "segment") or None, country=_str(row, "country") or None,
                          acquisition_date=parse_datetime(row.get("acquisition_date")),
                          consent_to_contact=_str(row, "consent_to_contact", "false").lower() in {"true", "1", "yes"},
                          source_name=source_name)
            if not ext or not values["name"]: raise ValueError("customer_id and name are required")
            obj = db.query(Customer).filter_by(external_id=ext).one_or_none()
        elif dataset_type == "subscriptions":
            customer = db.query(Customer).filter_by(external_id=_str(row, "customer_id")).one_or_none()
            if not customer: raise ValueError("Unknown customer_id; import the customer record first")
            ext = _str(row, "subscription_id")
            start = parse_datetime(row.get("start_date"))
            if not ext or not start: raise ValueError("subscription_id and valid start_date are required")
            values = dict(customer_id=customer.id, plan=_str(row, "plan", "unknown"),
                          status=_str(row, "status", "active").lower(), start_date=start,
                          end_date=parse_datetime(row.get("end_date")),
                          cancellation_date=parse_datetime(row.get("cancellation_date")),
                          churn_reason=_str(row, "churn_reason").lower() or None,
                          mrr=_money(row, "mrr"), currency=_str(row, "currency", "USD").upper(), source_name=source_name)
            if values["status"] not in {"active", "cancelled", "canceled", "expired", "ended", "paused", "suspended"}:
                raise ValueError("Unsupported subscription status")
            if len(values["currency"]) != 3: raise ValueError("currency must be a 3-letter code")
            obj = db.query(Subscription).filter_by(external_id=ext).one_or_none()
        elif dataset_type == "invoices":
            customer = db.query(Customer).filter_by(external_id=_str(row, "customer_id")).one_or_none()
            if not customer: raise ValueError("Unknown customer_id; import customers first")
            sub = None
            if _str(row, "subscription_id"):
                sub = db.query(Subscription).filter_by(external_id=_str(row, "subscription_id")).one_or_none()
                if not sub: raise ValueError("Unknown subscription_id")
            ext = _str(row, "invoice_id")
            invoice_date = parse_datetime(row.get("invoice_date")); amount = _money(row, "amount")
            if not ext or not invoice_date or amount < 0: raise ValueError("Invalid invoice ID, date or amount")
            values = dict(customer_id=customer.id, subscription_id=sub.id if sub else None,
                          invoice_date=invoice_date, due_date=parse_datetime(row.get("due_date")), amount=amount,
                          currency=_str(row, "currency", "USD").upper(), status=_str(row, "status", "open").lower(), source_name=source_name)
            obj = db.query(Invoice).filter_by(source_name=source_name, external_id=ext).one_or_none()
        elif dataset_type == "payments":
            customer = db.query(Customer).filter_by(external_id=_str(row, "customer_id")).one_or_none()
            if not customer: raise ValueError("Unknown customer_id; import customers first")
            invoice = None
            if _str(row, "invoice_id"):
                invoice = db.query(Invoice).filter_by(external_id=_str(row, "invoice_id")).one_or_none()
                if not invoice: raise ValueError("Unknown invoice_id")
            ext = _str(row, "payment_id")
            pay_date = parse_datetime(row.get("payment_date")); amount = _money(row, "amount")
            if not ext or not pay_date or amount < 0: raise ValueError("Invalid payment ID, date or amount")
            values = dict(customer_id=customer.id, invoice_id=invoice.id if invoice else None, payment_date=pay_date,
                          amount=amount, currency=_str(row, "currency", "USD").upper(),
                          status=_str(row, "status", "succeeded").lower(), source_name=source_name)
            obj = db.query(Payment).filter_by(source_name=source_name, external_id=ext).one_or_none()
        elif dataset_type == "usage":
            customer = db.query(Customer).filter_by(external_id=_str(row, "customer_id")).one_or_none()
            if not customer: raise ValueError("Unknown customer_id; import customers first")
            sub = None
            if _str(row, "subscription_id"):
                sub = db.query(Subscription).filter_by(external_id=_str(row, "subscription_id")).one_or_none()
                if not sub: raise ValueError("Unknown subscription_id")
            ext = _str(row, "event_id"); event_time = parse_datetime(row.get("event_time"))
            if not ext or not event_time: raise ValueError("event_id and valid event_time are required")
            values = dict(customer_id=customer.id, subscription_id=sub.id if sub else None, event_time=event_time,
                          event_type=_str(row, "event_type", "activity"), quantity=_float(row, "quantity", 1.0), source_name=source_name)
            obj = db.query(UsageEvent).filter_by(source_name=source_name, external_id=ext).one_or_none()
        else:  # support
            customer = db.query(Customer).filter_by(external_id=_str(row, "customer_id")).one_or_none()
            if not customer: raise ValueError("Unknown customer_id; import customers first")
            ext = _str(row, "ticket_id"); created = parse_datetime(row.get("created_at"))
            if not ext or not created: raise ValueError("ticket_id and valid created_at are required")
            values = dict(customer_id=customer.id, created_at=created, resolved_at=parse_datetime(row.get("resolved_at")),
                          status=_str(row, "status", "open").lower(), priority=_str(row, "priority", "normal").lower(),
                          category=_str(row, "category") or None, source_name=source_name)
            obj = db.query(SupportTicket).filter_by(source_name=source_name, external_id=ext).one_or_none()
        if obj:
            for key, value in values.items(): setattr(obj, key, value)
        else:
            cls = {"customers": Customer, "subscriptions": Subscription, "invoices": Invoice,
                   "payments": Payment, "usage": UsageEvent, "support": SupportTicket}[dataset_type]
            db.add(cls(external_id=ext, **values))
        db.flush()

    accepted = rejected = 0
    issues = []
    for idx, raw in enumerate(rows, start=2):
        row = {str(k).strip(): (v.strip() if isinstance(v, str) else v) for k, v in raw.items() if k}
        try:
            with db.begin_nested():
                process(row)
            accepted += 1
        except Exception as exc:
            rejected += 1
            issues.append(DataIssue(batch_id=batch.id, row_number=idx, issue_code="ROW_VALIDATION_ERROR",
                                    message=str(exc)[:500], raw_row=json_dumps(row)))
    if issues:
        db.add_all(issues)
    batch.records_accepted = accepted
    batch.records_rejected = rejected
    batch.status = "completed" if rejected == 0 else ("completed_with_errors" if accepted else "failed")
    batch.completed_at = datetime.now(timezone.utc)
    _audit(db, "dataset_imported", "import_batch", str(batch.id), metadata={"dataset_type": dataset_type, "accepted": accepted, "rejected": rejected})
    db.commit()
    return {"batch_id": batch.id, "status": batch.status, "records_received": len(rows),
            "records_accepted": accepted, "records_rejected": rejected}

def batch_report(db: Session, batch_id: int) -> dict[str, Any] | None:
    batch = db.get(ImportBatch, batch_id)
    if not batch: return None
    issues = db.query(DataIssue).filter_by(batch_id=batch_id).order_by(DataIssue.row_number).all()
    return {"batch_id": batch.id, "dataset_type": batch.dataset_type, "filename": batch.filename,
            "status": batch.status, "records_received": batch.records_received,
            "records_accepted": batch.records_accepted, "records_rejected": batch.records_rejected,
            "issues": [{"row_number": x.row_number, "code": x.issue_code, "message": x.message} for x in issues]}


def generate_labels(db: Session, cutoff: datetime, as_of: datetime, horizon_days: int = 30, scope: str = "customer") -> dict[str, int]:
    from app.utils import as_utc
    cutoff, as_of = as_utc(cutoff), as_utc(as_of)
    if horizon_days < 1 or horizon_days > 365: raise ValueError("horizon_days must be 1..365")
    if scope not in {"customer", "subscription"}: raise ValueError("scope must be customer or subscription")
    maturity = cutoff + timedelta(days=horizon_days)
    if scope == "subscription":
        entities = db.query(Subscription).filter(Subscription.start_date <= cutoff).all()
        made = censored = positives = negatives = 0
        for sub in entities:
            start_at = _aware(sub.start_date)
            end_at = _aware(sub.end_date)
            cancel_at = _aware(sub.cancellation_date)
            event_at = cancel_at or end_at
            active_at_cutoff = start_at <= cutoff and (end_at is None or end_at > cutoff)
            if not active_at_cutoff:
                continue
            label = None; kind = "UNKNOWN"; is_censored = as_of < maturity
            if event_at and cutoff < event_at <= maturity:
                label = 1; kind = classify_churn_reason(sub.churn_reason)
                is_censored = False; positives += 1
            elif as_of >= maturity:
                label = 0; kind = "NONE"; is_censored = False; negatives += 1
            else:
                censored += 1
            previous = db.query(ChurnLabel).filter_by(entity_scope="subscription", entity_ref=sub.external_id,
                                                        cutoff_date=cutoff, horizon_days=horizon_days).one_or_none()
            values = dict(churn_30d=label, churn_type=kind, event_date=event_at if label == 1 else None,
                          maturity_date=maturity, is_censored=is_censored, policy_version="1.0",
                          evidence=json_dumps({"scope": scope, "subscription_id": sub.external_id,
                                               "reason": sub.churn_reason, "observation_complete": as_of >= maturity}))
            if previous:
                for key, value in values.items(): setattr(previous, key, value)
            else:
                db.add(ChurnLabel(customer_id=sub.customer_id, entity_scope="subscription", entity_ref=sub.external_id,
                                  subscription_id=sub.id, cutoff_date=cutoff, horizon_days=horizon_days, **values))
            made += 1
        db.commit()
        return {"created": made, "positive": positives, "negative": negatives, "censored": censored}


    customers = db.query(Customer).all()
    made = positives = negatives = censored = 0
    for customer in customers:
        subs = db.query(Subscription).filter_by(customer_id=customer.id).filter(Subscription.start_date <= cutoff).all()
        eligible = [s for s in subs if _aware(s.end_date) is None or _aware(s.end_date) > cutoff]
        if not eligible: continue
        terminations = []
        for sub in eligible:
            ev = _aware(sub.cancellation_date) or _aware(sub.end_date)
            if ev and cutoff < ev <= maturity:
                terminations.append((ev, sub))
        event_at = None; kind = "UNKNOWN"; label = None; is_censored = False
        if terminations:
            last_event = max(x[0] for x in terminations)
            # A customer is considered churned only if all eligible subscriptions terminate
            # in-window and no replacement service starts on/before the final termination.
            all_ended = all((_aware(s.cancellation_date) or _aware(s.end_date)) is not None and
                            (_aware(s.cancellation_date) or _aware(s.end_date)) <= maturity for s in eligible)
            replacement = db.query(Subscription).filter(Subscription.customer_id == customer.id,
                                                        Subscription.start_date > cutoff,
                                                        Subscription.start_date <= last_event).count() > 0
            if all_ended and not replacement:
                event_at = last_event
                reasons = {classify_churn_reason(s.churn_reason) for ev, s in terminations if ev == last_event}
                kind = reasons.pop() if len(reasons) == 1 else "UNKNOWN"
                label = 1
                positives += 1
            elif as_of < maturity:
                is_censored = True; censored += 1
            else:
                label = 0; kind = "NONE"; negatives += 1
        elif as_of >= maturity:
            label = 0; kind = "NONE"; negatives += 1
        else:
            is_censored = True; censored += 1
        previous = db.query(ChurnLabel).filter_by(entity_scope="customer", entity_ref=customer.external_id,
                                                   cutoff_date=cutoff, horizon_days=horizon_days).one_or_none()
        values = dict(churn_30d=label, churn_type=kind, event_date=event_at, maturity_date=maturity,
                      is_censored=is_censored, policy_version="1.0",
                      evidence=json_dumps({"scope": "customer", "eligible_subscriptions": [s.external_id for s in eligible],
                                           "event_window": f"({cutoff.isoformat()}, {maturity.isoformat()}]"}))
        if previous:
            for k,v in values.items(): setattr(previous,k,v)
        else:
            db.add(ChurnLabel(customer_id=customer.id, entity_scope="customer", entity_ref=customer.external_id,
                              cutoff_date=cutoff, horizon_days=horizon_days, **values))
        made += 1
    db.commit()
    return {"created": made, "positive": positives, "negative": negatives, "censored": censored}


def classify_churn_reason(reason: str | None) -> str:
    if not reason: return "UNKNOWN"
    value = reason.strip().lower().replace("-", "_").replace(" ", "_")
    if any(x in value for x in ("customer_request", "customer_cancellation", "voluntary", "competitor", "too_expensive", "not_needed", "cancelled_by_customer", "canceled_by_customer")):
        return "VOLUNTARY"
    if any(x in value for x in ("non_payment", "payment_failure", "dunning", "past_due", "failed_payment")):
        return "INVOLUNTARY"
    if any(x in value for x in ("admin", "sunset", "migration", "legal", "fraud", "product_discontinued")):
        return "OTHER"
    return "UNKNOWN"


def _window_counts(query, date_col, cutoff: datetime, days: int) -> int:
    return query.filter(date_col > cutoff - timedelta(days=days), date_col <= cutoff).count()


def build_features(db: Session, cutoff: datetime, feature_version: str = "2.1", customer_ids: list[int] | None = None) -> dict[str, int]:
    from app.utils import as_utc
    cutoff = as_utc(cutoff)
    customer_query = db.query(Customer)
    if customer_ids is not None:
        customer_query = customer_query.filter(Customer.id.in_(customer_ids))
    customers = customer_query.all()
    created = skipped = 0
    for c in customers:
        subs = db.query(Subscription).filter(Subscription.customer_id == c.id, Subscription.start_date <= cutoff).all()
        invoices = db.query(Invoice).filter(Invoice.customer_id == c.id, Invoice.invoice_date <= cutoff).all()
        payments = db.query(Payment).filter(Payment.customer_id == c.id, Payment.payment_date <= cutoff).all()
        usages = db.query(UsageEvent).filter(UsageEvent.customer_id == c.id, UsageEvent.event_time <= cutoff).all()
        tickets = db.query(SupportTicket).filter(SupportTicket.customer_id == c.id, SupportTicket.created_at <= cutoff).all()
        active_subs = [s for s in subs if s.status not in {"paused", "suspended"} and
                       (_aware(s.end_date) is None or _aware(s.end_date) > cutoff) and
                       (_aware(s.cancellation_date) is None or _aware(s.cancellation_date) > cutoff)]
        usage_7 = [u for u in usages if _aware(u.event_time) > cutoff - timedelta(days=7)]
        usage_14 = [u for u in usages if cutoff - timedelta(days=14) < _aware(u.event_time) <= cutoff - timedelta(days=7)]
        usage_30 = [u for u in usages if _aware(u.event_time) > cutoff - timedelta(days=30)]
        usage_60_prior = [u for u in usages if cutoff - timedelta(days=60) < _aware(u.event_time) <= cutoff - timedelta(days=30)]
        usage_90 = [u for u in usages if _aware(u.event_time) > cutoff - timedelta(days=90)]
        recent_payments = [p for p in payments if _aware(p.payment_date) > cutoff - timedelta(days=90)]
        successful_payments = [p for p in payments if p.status in {"succeeded", "paid", "completed"}]
        failed = [p for p in recent_payments if p.status in {"failed", "declined", "rejected"}]
        paid_90 = [p for p in successful_payments if _aware(p.payment_date) > cutoff - timedelta(days=90)]
        overdue_invoices = [inv for inv in invoices if inv.status not in {"paid", "settled", "void", "cancelled"}
                            and inv.due_date and _aware(inv.due_date) < cutoff]
        resolved_tickets = [t for t in tickets if t.resolved_at]
        resolution_hours = [max(0.0, (_aware(t.resolved_at) - _aware(t.created_at)).total_seconds() / 3600.0)
                            for t in resolved_tickets]
        open_tickets = [t for t in tickets if t.status not in {"resolved", "closed"}]
        high_tickets = [t for t in tickets if t.priority.lower() in {"high", "urgent", "critical"}]
        inactivity_days = None
        if usages:
            inactivity_days = max(0, (cutoff - max(_aware(u.event_time) for u in usages)).days)
        # Currency-specific financial fields prevent summing unlike currencies.
        mrr_by_currency: dict[str, float] = defaultdict(float)
        billed_by_currency: dict[str, float] = defaultdict(float)
        paid_by_currency: dict[str, float] = defaultdict(float)
        for s in active_subs: mrr_by_currency[s.currency] += float(s.mrr)
        for inv in invoices: billed_by_currency[inv.currency] += float(inv.amount)
        for p in payments:
            if p.status in {"succeeded", "paid", "completed"}:
                paid_by_currency[p.currency] += float(p.amount)
        feats = {
            "tenure_days": max(0, (cutoff - min((_aware(s.start_date) for s in subs), default=cutoff)).days),
            "active_subscription_count": len(active_subs),
            "subscription_count": len(subs),
            "mrr_by_currency": dict(mrr_by_currency),
            "invoice_total_by_currency": dict(billed_by_currency),
            "payment_total_by_currency": dict(paid_by_currency),
            "usage_events_7d": len(usage_7), "usage_events_30d": len(usage_30),
            "usage_events_90d": len(usage_90),
            "usage_quantity_30d": sum(float(x.quantity) for x in usage_30),
            "usage_active_days_30d": len({_aware(x.event_time).date() for x in usage_30}),
            "usage_event_type_count_30d": len({x.event_type for x in usage_30}),
            "usage_decline_7d_vs_prior_7d": _rate_change(len(usage_7), len(usage_14)),
            "usage_decline_30d_vs_prior_30d": _rate_change(len(usage_30), len(usage_60_prior)),
            "usage_velocity_7d": len(usage_7) / 7.0,
            "usage_velocity_30d": len(usage_30) / 30.0,
            "inactivity_days": inactivity_days,
            "payment_failures_90d": len(failed),
            "payment_recency_days": ((cutoff - max(_aware(p.payment_date) for p in successful_payments)).days
                                     if successful_payments else None),
            "payment_frequency_90d": len(paid_90),
            "payment_monetary_by_currency_90d": {currency: round(sum(float(p.amount) for p in paid_90 if p.currency == currency), 2)
                                                    for currency in sorted({p.currency for p in paid_90})},
            "invoice_recency_days": ((cutoff - max(_aware(i.invoice_date) for i in invoices)).days
                                     if invoices else None),
            "invoice_frequency_90d": sum(1 for i in invoices if _aware(i.invoice_date) > cutoff - timedelta(days=90)),
            "invoice_monetary_by_currency_90d": {currency: round(sum(float(i.amount) for i in invoices
                if i.currency == currency and _aware(i.invoice_date) > cutoff - timedelta(days=90)), 2)
                for currency in sorted({i.currency for i in invoices
                    if _aware(i.invoice_date) > cutoff - timedelta(days=90)})},
            "overdue_invoice_count": len(overdue_invoices),
            "overdue_amount_by_currency": {currency: round(sum(float(i.amount) for i in overdue_invoices if i.currency == currency), 2)
                                             for currency in sorted({i.currency for i in overdue_invoices})},
            "median_support_resolution_hours": (sorted(resolution_hours)[len(resolution_hours)//2] if resolution_hours else None),
            "support_tickets_30d": sum(1 for t in tickets if _aware(t.created_at) > cutoff - timedelta(days=30)),
            "open_support_tickets": len(open_tickets),
            "high_priority_tickets": len(high_tickets),
            "invoices_count": len(invoices),
            "successful_payment_count": len(successful_payments),
            "failed_payment_rate_90d": len(failed) / len(recent_payments) if recent_payments else 0.0,
            "active_contract_days_remaining": min((max(0, (_aware(s.end_date) - cutoff).days) for s in active_subs if s.end_date), default=None),
            "active_plan_diversity": len({s.plan for s in active_subs}),
            # A monetary average has a valid scalar interpretation only for one currency.
            "average_active_subscription_mrr_single_currency": (
                sum(float(s.mrr) for s in active_subs) / len(active_subs)
                if active_subs and len({s.currency for s in active_subs}) == 1 else None),
            "segment": c.segment or "unknown", "country": c.country or "unknown",
        }
        # A numeric aggregate is only emitted when a single currency is represented.
        if len(mrr_by_currency) == 1: feats["mrr_single_currency"] = next(iter(mrr_by_currency.values()))
        if len(paid_by_currency) == 1: feats["paid_single_currency_90d"] = next(iter(paid_by_currency.values()))
        invoice_90d = {currency: amount for currency, amount in feats["invoice_monetary_by_currency_90d"].items()}
        if len(invoice_90d) == 1: feats["invoice_single_currency_90d"] = next(iter(invoice_90d.values()))
        fingerprint = stable_fingerprint({"customer": c.external_id, "cutoff": cutoff, "source_ids": {
            "subscriptions": [s.id for s in subs], "invoices": [i.id for i in invoices],
            "payments": [p.id for p in payments], "usage": [u.id for u in usages], "support": [t.id for t in tickets]}})
        prev = db.query(FeatureSnapshot).filter_by(customer_id=c.id, cutoff_date=cutoff, feature_version=feature_version).one_or_none()
        if prev:
            # Point-in-time feature snapshots are immutable. Never rewrite an existing snapshot.
            skipped += 1; continue
        db.add(FeatureSnapshot(customer_id=c.id, cutoff_date=cutoff, feature_version=feature_version,
                               features_json=json_dumps(feats), source_fingerprint=fingerprint))
        created += 1
    db.commit()
    return {"created": created, "already_exists": skipped}


def _rate_change(current: int, prior: int) -> float | None:
    if prior == 0: return None if current == 0 else 1.0
    return (current - prior) / prior


def create_synthetic_demo(db: Session, customers: int = 180, seed: int = 19) -> dict[str, int]:
    """Create clearly marked synthetic records for local demonstrations and tests only."""
    import random
    from datetime import timedelta
    random.seed(seed)
    now = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    made = 0
    for i in range(customers):
        ext = f"SYN-CUST-{i+1:05d}"
        if db.query(Customer).filter_by(external_id=ext).first(): continue
        c = Customer(external_id=ext, name=f"Synthetic Customer {i+1}",
                     email=f"customer{i+1}@example.invalid", segment=random.choice(["SMB", "Mid-Market", "Enterprise"]),
                     country=random.choice(["IN", "US", "GB"]), acquisition_date=now - timedelta(days=random.randint(60, 900)),
                     consent_to_contact=(i % 3 == 0), source_name="synthetic_demo")
        db.add(c); db.flush()
        starts = [now - timedelta(days=random.randint(60, 800))]
        for j in range(random.choices([1,2,3], [0.75,0.20,0.05])[0]):
            start = starts[0] if j == 0 else now - timedelta(days=random.randint(45, 500))
            churn = (i % 7 == 0 and j == 0)
            end = now - timedelta(days=random.randint(1, 20)) if churn else None
            reason = random.choice(["customer_request", "non_payment", "product_sunset"]) if churn else None
            sub = Subscription(external_id=f"SYN-SUB-{i+1:05d}-{j+1}", customer_id=c.id,
                               plan=random.choice(["Starter", "Growth", "Pro"]),
                               status="cancelled" if churn else "active", start_date=start, end_date=end,
                               cancellation_date=end, churn_reason=reason, mrr=random.choice([29,49,99,199]),
                               currency=random.choice(["USD", "INR"]), source_name="synthetic_demo")
            db.add(sub)
        made += 1
    db.commit()
    return {"customers_created": made, "customers_total": db.query(Customer).count(), "synthetic": True}


def import_tabular_file(db: Session, dataset_type: str, filename: str, content: bytes,
                        source_name: str = "uploaded_file") -> dict[str, Any]:
    """Import CSV, XLSX or JSON records through the same canonical row validator."""
    from pathlib import Path
    suffix = Path(filename).suffix.lower()
    if suffix == ".csv":
        return import_csv(db, dataset_type, filename, content, source_name)
    if suffix == ".json":
        try:
            payload = json.loads(content.decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("JSON upload must be valid UTF-8 JSON") from exc
        if isinstance(payload, dict):
            payload = payload.get("records", payload.get("data"))
        if not isinstance(payload, list) or not all(isinstance(row, dict) for row in payload):
            raise ValueError("JSON upload must contain an array of record objects or {records: [...]} ")
        rows = payload
    elif suffix == ".xlsx":
        try:
            import openpyxl
            workbook = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            sheet = workbook.active
            iterator = sheet.iter_rows(values_only=True)
            headers = next(iterator, None)
            if not headers:
                raise ValueError("Excel worksheet must contain a header row")
            names = [str(value).strip() if value is not None else "" for value in headers]
            rows = [dict(zip(names, values)) for values in iterator if any(v is not None for v in values)]
            workbook.close()
        except ImportError as exc:
            raise ValueError("Excel support requires openpyxl; install requirements.txt") from exc
        except Exception as exc:
            if isinstance(exc, ValueError):
                raise
            raise ValueError("Excel file could not be parsed") from exc
    else:
        raise ValueError("Supported upload formats are .csv, .xlsx and .json")
    if dataset_type not in DATASET_SCHEMAS:
        raise ValueError(f"Unsupported dataset_type. Expected one of: {', '.join(DATASET_SCHEMAS)}")
    headers = {str(k).strip() for row in rows for k in row.keys() if k is not None}
    missing = DATASET_SCHEMAS[dataset_type] - headers
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")
    output = io.StringIO(newline="")
    fieldnames = sorted(headers)
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        normalized = {}
        for key, value in row.items():
            if isinstance(value, datetime):
                normalized[str(key)] = value.isoformat()
            elif value is None:
                normalized[str(key)] = ""
            else:
                normalized[str(key)] = str(value)
        writer.writerow(normalized)
    return import_csv(db, dataset_type, filename, output.getvalue().encode("utf-8"), source_name)
