from __future__ import annotations

import math
from statistics import NormalDist
from typing import Any


def calculate_binary_experiment_sample_size(
    *,
    baseline_retention: float,
    minimum_detectable_effect: float,
    treatment_pct: int = 50,
    alpha: float = 0.05,
    power: float = 0.80,
) -> dict[str, Any]:
    """Approximate sample size for a two-sided, two-arm difference in proportions.

    The estimate uses a normal approximation for an independent binary endpoint.
    It is a planning aid, not a substitute for a statistician's protocol review.
    """
    if not math.isfinite(baseline_retention) or not 0.01 <= baseline_retention <= 0.99:
        raise ValueError("baseline_retention must be between 0.01 and 0.99")
    if not math.isfinite(minimum_detectable_effect) or not 0.005 <= minimum_detectable_effect <= 0.50:
        raise ValueError("minimum_detectable_effect must be between 0.005 and 0.50")
    treatment_rate = baseline_retention + minimum_detectable_effect
    if treatment_rate >= 0.999:
        raise ValueError("baseline_retention plus minimum_detectable_effect must be below 0.999")
    if isinstance(treatment_pct, bool) or not isinstance(treatment_pct, int) or not 10 <= treatment_pct <= 90:
        raise ValueError("treatment_pct must be an integer between 10 and 90")
    if not math.isfinite(alpha) or not 0.01 <= alpha <= 0.10:
        raise ValueError("alpha must be between 0.01 and 0.10")
    if not math.isfinite(power) or not 0.70 <= power <= 0.99:
        raise ValueError("power must be between 0.70 and 0.99")

    treatment_share = treatment_pct / 100.0
    control_share = 1.0 - treatment_share
    ratio = treatment_share / control_share  # n_treatment / n_control
    p0 = baseline_retention
    p1 = treatment_rate
    pooled = (p0 + ratio * p1) / (1.0 + ratio)
    z_alpha = NormalDist().inv_cdf(1.0 - alpha / 2.0)
    z_power = NormalDist().inv_cdf(power)
    pooled_variance_term = pooled * (1.0 - pooled) * (1.0 + 1.0 / ratio)
    alternative_variance_term = p0 * (1.0 - p0) + p1 * (1.0 - p1) / ratio
    numerator = (
        z_alpha * math.sqrt(pooled_variance_term)
        + z_power * math.sqrt(alternative_variance_term)
    ) ** 2
    control_n = math.ceil(numerator / (minimum_detectable_effect ** 2))
    treatment_n = math.ceil(control_n * ratio)
    return {
        "method": "two-sided normal approximation for independent proportions with unequal allocation",
        "baseline_retention": p0,
        "target_treatment_retention": p1,
        "minimum_detectable_effect": minimum_detectable_effect,
        "treatment_allocation_pct": treatment_pct,
        "control_allocation_pct": 100 - treatment_pct,
        "alpha": alpha,
        "target_power": power,
        "required_control_n": control_n,
        "required_treatment_n": treatment_n,
        "required_total_n": control_n + treatment_n,
        "assumptions": [
            "One independent binary outcome per randomized customer.",
            "No clustering, repeated customer enrollment, contamination or attrition inflation.",
            "Two-sided test; normal approximation; fixed baseline and effect assumptions.",
        ],
        "warning": "Planning estimate only. Add allowance for attrition/design effects and obtain business/statistical review before launching an experiment.",
    }
