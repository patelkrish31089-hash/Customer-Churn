from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import BackgroundJob
from app.config import settings
from app.utils import json_dumps, json_loads, parse_datetime


class _StrictPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")


class LabelsPayload(_StrictPayload):
    cutoff_at: datetime
    as_of: datetime | None = None
    horizon_days: int = Field(default=30, ge=1, le=365)
    scope: Literal["customer", "subscription"] = "customer"


class FeaturesPayload(_StrictPayload):
    cutoff_at: datetime
    feature_version: Literal["2.1"] = "2.1"
    customer_ids: list[int] | None = Field(default=None, max_length=5000)


class QualityPayload(_StrictPayload):
    scope: Literal["all", "customer", "subscription", "invoice", "payment", "usage", "support"] = "all"


class TrainPayload(_StrictPayload):
    feature_version: Literal["2.1"] = "2.1"
    horizon_days: int = Field(default=30, ge=1, le=365)
    false_positive_cost: float | None = Field(default=None, ge=0)
    false_negative_cost: float | None = Field(default=None, ge=0)
    cost_unit: str = Field(default="business_units", min_length=1, max_length=24)


class ScorePayload(_StrictPayload):
    cutoff_at: datetime
    customer_ids: list[int] | None = Field(default=None, max_length=5000)
    release_id: str | None = Field(default=None, min_length=1, max_length=36)


class EmptyPayload(_StrictPayload):
    pass


class SourceSyncPayload(_StrictPayload):
    connection_key: str = Field(min_length=3, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")


class ImportFilePayload(_StrictPayload):
    dataset_type: Literal["customers", "subscriptions", "invoices", "payments", "usage", "support"]
    stored_name: str = Field(pattern=r"^[a-f0-9]{32}\.(csv|xlsx|json)$", max_length=40)
    original_filename: str = Field(min_length=1, max_length=180)
    source_name: str = Field(min_length=1, max_length=120)
    content_sha256: str = Field(pattern=r"^[a-f0-9]{64}$", min_length=64, max_length=64)


PAYLOAD_MODELS: dict[str, type[BaseModel]] = {
    "generate_labels": LabelsPayload,
    "build_features": FeaturesPayload,
    "quality_audit": QualityPayload,
    "train_models": TrainPayload,
    "score_batch": ScorePayload,
    "retention_generate": EmptyPayload,
    "sync_source": SourceSyncPayload,
    "import_file": ImportFilePayload,
}

JOB_ROLES: dict[str, set[str]] = {
    "generate_labels": {"admin", "analyst"},
    "build_features": {"admin", "analyst"},
    "quality_audit": {"admin", "analyst"},
    "train_models": {"admin", "analyst"},
    "score_batch": {"admin", "analyst", "retention_manager"},
    "retention_generate": {"admin", "analyst", "retention_manager"},
    "sync_source": {"admin", "analyst"},
    "import_file": {"admin", "analyst"},
}


def validate_payload(job_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    model = PAYLOAD_MODELS.get(job_type)
    if model is None:
        raise ValueError("Unsupported job type")
    try:
        return model.model_validate(payload).model_dump(mode="json")
    except ValidationError as exc:
        raise ValueError("Invalid job payload: " + "; ".join(
            f"{'.'.join(str(x) for x in item['loc'])}: {item['msg']}" for item in exc.errors()
        )) from exc


def payload_digest(job_type: str, payload: dict[str, Any]) -> str:
    canonical = json_dumps({"job_type": job_type, "payload": payload})
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def enqueue_job(db: Session, job_type: str, payload: dict[str, Any], idempotency_key: str,
                created_by: int | None, *, priority: int = 100, max_attempts: int = 3) -> tuple[BackgroundJob, bool]:
    if not 8 <= len(idempotency_key) <= 120:
        raise ValueError("Idempotency key must contain 8–120 characters")
    clean_payload = validate_payload(job_type, payload)
    digest = payload_digest(job_type, clean_payload)
    existing = db.query(BackgroundJob).filter_by(idempotency_key=idempotency_key).one_or_none()
    if existing:
        if existing.payload_sha256 != digest:
            raise ValueError("Idempotency key was already used with a different job payload")
        return existing, True
    if priority < 1 or priority > 1000:
        raise ValueError("Priority must be between 1 and 1000")
    job = BackgroundJob(
        job_type=job_type, status="queued", payload_json=json_dumps(clean_payload),
        payload_sha256=digest, idempotency_key=idempotency_key, created_by=created_by,
        priority=priority, attempts=0, max_attempts=max_attempts,
        available_at=datetime.now(timezone.utc), progress_pct=0,
        progress_message="Waiting for a worker", result_json="{}",
    )
    db.add(job)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        existing = db.query(BackgroundJob).filter_by(idempotency_key=idempotency_key).one_or_none()
        if existing and existing.payload_sha256 == digest:
            return existing, True
        raise ValueError("Idempotency key conflicts with an existing job")
    db.refresh(job)
    return job, False


def job_dict(job: BackgroundJob, *, include_payload: bool = True) -> dict[str, Any]:
    result: dict[str, Any] = {
        "id": job.id, "job_type": job.job_type, "status": job.status,
        "idempotency_key": job.idempotency_key, "created_by": job.created_by,
        "priority": job.priority, "attempts": job.attempts, "max_attempts": job.max_attempts,
        "progress_pct": job.progress_pct, "progress_message": job.progress_message,
        "result": json_loads(job.result_json), "error_message": job.error_message,
        "created_at": job.created_at, "started_at": job.started_at,
        "finished_at": job.finished_at, "available_at": job.available_at,
    }
    if include_payload:
        result["payload"] = json_loads(job.payload_json)
    return result


def execute_job(db: Session, job: BackgroundJob) -> dict[str, Any]:
    """Execute one allowlisted job. Handlers are local DB/service operations."""
    payload = json_loads(job.payload_json)
    if job.job_type == "generate_labels":
        from app.services.data import generate_labels
        cutoff = parse_datetime(payload["cutoff_at"])
        as_of = parse_datetime(payload.get("as_of")) or datetime.now(timezone.utc)
        return generate_labels(db, cutoff, as_of, int(payload["horizon_days"]), payload["scope"])
    if job.job_type == "build_features":
        from app.services.data import build_features
        return build_features(db, parse_datetime(payload["cutoff_at"]), payload["feature_version"], payload.get("customer_ids"))
    if job.job_type == "quality_audit":
        from app.services.quality import run_quality_audit
        return run_quality_audit(db, payload["scope"])
    if job.job_type == "train_models":
        from app.services.ml import train_models
        return train_models(db, payload["feature_version"], int(payload["horizon_days"]),
                            payload.get("false_positive_cost"), payload.get("false_negative_cost"), payload["cost_unit"])
    if job.job_type == "score_batch":
        from app.services.ml import score_customer_batch
        stable_key = "job-" + hashlib.sha256(job.idempotency_key.encode("utf-8")).hexdigest()[:48]
        return score_customer_batch(db, parse_datetime(payload["cutoff_at"]), stable_key,
                                    payload.get("customer_ids"), payload.get("release_id"))
    if job.job_type == "retention_generate":
        from app.services.retention import generate_recommendations
        return generate_recommendations(db)
    if job.job_type == "sync_source":
        from app.integrations.sources import sync_rest_source
        from app.models import DataSourceConnection
        source = db.query(DataSourceConnection).filter_by(connection_key=payload["connection_key"]).one_or_none()
        if source is None:
            raise ValueError("Data source connection was not found")
        return sync_rest_source(db, source)
    if job.job_type == "import_file":
        from app.services.data import import_tabular_file
        stored_name = payload["stored_name"]
        queue_dir = (settings.upload_dir / "queued").resolve()
        file_path = (queue_dir / stored_name).resolve()
        if file_path.parent != queue_dir:
            raise ValueError("Queued import file path is outside the configured queue directory")
        if not file_path.is_file():
            raise ValueError("Queued import file is missing")
        content = file_path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        if digest != payload["content_sha256"]:
            raise ValueError("Queued import file checksum does not match the submitted content")
        return import_tabular_file(db, payload["dataset_type"], payload["original_filename"],
                                   content, payload["source_name"])
    raise ValueError("Job type is no longer supported by this worker")
