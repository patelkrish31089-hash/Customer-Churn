from __future__ import annotations

import hashlib
import logging
import os
import sqlite3
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import settings
from app.db import get_db, engine
from app.models import (AuditEvent, ChurnLabel, Customer, CRMAction, ImportBatch, ModelRelease, BackgroundJob,
                        Prediction, PredictionBatch, RetentionRecommendation, SessionToken, User,
                        DataSourceConnection, ExternalIdentity, DataQualityRun, RetentionExperiment,
                        RetentionExperimentAssignment, RetentionAssignment)
from app.security import current_user, create_session, hash_password, require_roles, token_digest, verify_password
from app.utils import json_dumps, json_loads, parse_datetime, safe_filename
from app.services.data import import_csv, import_tabular_file, batch_report, generate_labels, build_features, create_synthetic_demo
from app.services.analytics import overview, cohort_retention, survival_curve, feature_summary, fairness_audit
from app.services.dataset_audit import audit_training_dataset
from app.services.ml import (train_models, approve_release, rollback_release, evaluate_matured_predictions,
                             predict_customer, customer_360, score_customer_batch,
                             retry_failed_prediction_batch, global_shap_summary)
from app.services.retention import generate_recommendations, review_recommendation, execute_sandbox_action, execute_live_crm_action, record_outcome
from app.services.mlops import run_drift_check, run_evidently_drift, integration_capabilities
from app.services.quality import (list_rules, update_rule, run_quality_audit, list_findings, review_finding,
                                   bulk_review_findings)
from app.services.retention_governance import (list_playbooks, publish_playbook, assign_recommendation,
    create_experiment, start_experiment, enroll_experiment, record_experiment_outcome,
    experiment_report, close_experiment, correct_experiment_outcome)
from app.services.experiment_design import calculate_binary_experiment_sample_size
from app.integrations.sources import validate_source_url, sync_rest_source
from app.integrations.crm import provider_capabilities
from app.services.reporting import build_report, report_catalog, to_csv
from app.services.jobs import JOB_ROLES, enqueue_job, job_dict
from app.services.feature_store import (feature_registry, feature_store_summary, latest_online_features,
                                        customer_feature_history, export_feature_snapshots)

logging.basicConfig(level=getattr(logging, settings.log_level, logging.INFO),
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("churn_platform")


class LoginBody(BaseModel):
    username: str
    password: str


class UserCreateBody(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=12, max_length=200)
    role: str = "analyst"


class CutoffBody(BaseModel):
    cutoff_at: datetime
    as_of: datetime | None = None
    horizon_days: int = 30
    scope: str = "customer"


class FeatureBody(BaseModel):
    cutoff_at: datetime
    feature_version: str = "2.1"


class FeatureMaterializationBody(BaseModel):
    cutoff_at: datetime
    feature_version: str = "2.1"
    customer_ids: list[int] | None = Field(default=None, max_length=5000)


class QualityBulkReviewBody(BaseModel):
    finding_ids: list[int] = Field(min_length=1, max_length=100)
    decision: str
    note: str | None = Field(default=None, max_length=500)


class TrainBody(BaseModel):
    feature_version: str = "2.1"
    horizon_days: int = Field(default=30, ge=1, le=365)
    false_positive_cost: float | None = Field(default=None, ge=0)
    false_negative_cost: float | None = Field(default=None, ge=0)
    cost_unit: str = Field(default="business_units", min_length=1, max_length=24)


class PredictionBody(BaseModel):
    cutoff_at: datetime
    release_id: str | None = None


class ReviewBody(BaseModel):
    decision: str


class OutcomeBody(BaseModel):
    outcome: str
    notes: str | None = None

class CRMExecuteBody(BaseModel):
    idempotency_key: str = Field(min_length=8, max_length=100)
    provider: str = "sandbox"


class BatchPredictionBody(BaseModel):
    cutoff_at: datetime
    idempotency_key: str = Field(min_length=8, max_length=120)
    customer_ids: list[int] | None = None
    release_id: str | None = None


class DataSourceBody(BaseModel):
    connection_key: str = Field(min_length=3, max_length=80, pattern=r"^[a-zA-Z0-9_-]+$")
    name: str = Field(min_length=3, max_length=160)
    dataset_type: str
    endpoint_url: str = Field(min_length=10, max_length=1000)
    credential_env_var: str | None = None
    record_path: str | None = Field(default=None, max_length=300)
    field_mapping: dict[str, str] = Field(default_factory=dict)


class QualityRuleBody(BaseModel):
    enabled: bool = True
    severity: str = "warning"
    parameters: dict = Field(default_factory=dict)


class QualityReviewBody(BaseModel):
    decision: str
    corrected_value: str | float | int | None = None
    note: str | None = Field(default=None, max_length=500)


class FinancialScenarioBody(BaseModel):
    threshold: float = Field(ge=0, le=1)
    contribution_margin: float = Field(ge=0)
    retention_success_rate: float = Field(ge=0, le=1)
    contact_cost: float = Field(ge=0)


class ExternalIdentityBody(BaseModel):
    provider: str
    entity_type: str = "customer"
    local_entity_id: int
    remote_entity_id: str = Field(min_length=1, max_length=160)


class RetentionPlaybookBody(BaseModel):
    policy: dict


class RetentionAssignBody(BaseModel):
    assignee_id: int
    due_at: datetime | None = None
    notes: str | None = Field(default=None, max_length=500)


class ExperimentCreateBody(BaseModel):
    name: str = Field(min_length=3, max_length=160)
    hypothesis: str = Field(min_length=10, max_length=4000)
    treatment_pct: int = Field(default=50, ge=10, le=90)
    followup_days: int = Field(default=30, ge=7, le=180)


class ExperimentEnrollBody(BaseModel):
    customer_ids: list[int] | None = None


class ExperimentOutcomeBody(BaseModel):
    outcome: str = Field(pattern="^(retained|churned|no_response|unknown)$")


class ExperimentOutcomeCorrectionBody(BaseModel):
    outcome: str = Field(pattern="^(retained|churned|no_response|unknown)$")
    reason: str = Field(min_length=10, max_length=500)


class ExperimentSampleSizeBody(BaseModel):
    baseline_retention: float = Field(ge=0.01, le=0.99)
    minimum_detectable_effect: float = Field(ge=0.005, le=0.50)
    treatment_pct: int = Field(default=50, ge=10, le=90)
    alpha: float = Field(default=0.05, ge=0.01, le=0.10)
    power: float = Field(default=0.80, ge=0.70, le=0.99)

class DriftBody(BaseModel):
    release_id: str
    threshold: float = 0.2
    baseline_snapshot_ids: list[int] | None = None


class UserStatusBody(BaseModel):
    is_active: bool


class JobCreateBody(BaseModel):
    job_type: str = Field(min_length=3, max_length=48)
    payload: dict = Field(default_factory=dict)
    idempotency_key: str = Field(min_length=8, max_length=120)
    priority: int = Field(default=100, ge=1, le=1000)



@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    settings.artifact_dir.mkdir(parents=True, exist_ok=True)
    yield


app = FastAPI(title=settings.app_name, version=settings.app_version, lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=list(settings.cors_origins),
                   allow_credentials=False, allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
                   allow_headers=["Authorization", "Content-Type", "X-Correlation-ID"])


@app.middleware("http")
async def correlation_middleware(request: Request, call_next):
    correlation_id = request.headers.get("X-Correlation-ID") or str(uuid.uuid4())
    request.state.correlation_id = correlation_id
    try:
        response = await call_next(request)
    except Exception:
        logger.exception("Unhandled request error correlation_id=%s path=%s", correlation_id, request.url.path)
        response = JSONResponse(status_code=500, content={"error": {"code": "INTERNAL_ERROR", "message": "An unexpected error occurred", "correlation_id": correlation_id}})
    response.headers["X-Correlation-ID"] = correlation_id
    return response


@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(status_code=400, content={"error": {"code": "INVALID_REQUEST", "message": str(exc),
                                                              "correlation_id": getattr(request.state, "correlation_id", None)}})


@app.get("/api/v1/health/live")
def health_live():
    return {"status": "alive", "app": settings.app_name, "version": settings.app_version}


@app.get("/api/v1/health/ready")
def health_ready(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"status": "ready", "database": "reachable", "environment": settings.environment}
    except Exception:
        raise HTTPException(status_code=503, detail="Required database dependency is unavailable")


@app.post("/api/v1/auth/login")
def login(body: LoginBody, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(username=body.username).one_or_none()
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = create_session(db, user)
    db.add(AuditEvent(actor_id=user.id, action="login", entity_type="user", entity_id=str(user.id), metadata_json="{}"))
    db.commit()
    return {"access_token": token, "token_type": "bearer", "expires_in_hours": settings.session_ttl_hours,
            "user": {"id": user.id, "username": user.username, "role": user.role}}


@app.post("/api/v1/auth/logout")
def logout(user: User = Depends(current_user), authorization: str | None = Header(default=None), db: Session = Depends(get_db)):
    if authorization and authorization.lower().startswith("bearer "):
        session = db.query(SessionToken).filter_by(token_hash=token_digest(authorization.split(" ", 1)[1]), revoked=False).first()
        if session:
            session.revoked = True
            db.add(AuditEvent(actor_id=user.id, action="logout", entity_type="user", entity_id=str(user.id), metadata_json="{}"))
            db.commit()
    return {"status": "logged_out"}


@app.get("/api/v1/auth/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "username": user.username, "role": user.role}


@app.post("/api/v1/admin/users", status_code=201)
def create_user(body: UserCreateBody, actor: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    if body.role not in {"admin", "analyst", "retention_manager", "viewer"}:
        raise ValueError("role must be admin, analyst, retention_manager, or viewer")
    if db.query(User).filter_by(username=body.username).first():
        raise HTTPException(status_code=409, detail="Username already exists")
    user = User(username=body.username, password_hash=hash_password(body.password), role=body.role)
    db.add(user); db.commit(); db.refresh(user)
    db.add(AuditEvent(actor_id=actor.id, action="user_created", entity_type="user", entity_id=str(user.id), metadata_json=json_dumps({"role": body.role})))
    db.commit()
    return {"id": user.id, "username": user.username, "role": user.role}


@app.get("/api/v1/admin/users")
def admin_users(actor: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.created_at.asc(), User.id.asc()).all()
    return [{"id": row.id, "username": row.username, "role": row.role,
             "is_active": row.is_active, "created_at": row.created_at}
            for row in users]


@app.patch("/api/v1/admin/users/{user_id}/status")
def admin_user_status(user_id: int, body: UserStatusBody, actor: User = Depends(require_roles("admin")),
                      db: Session = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(status_code=404, detail="User not found")
    if target.id == actor.id and not body.is_active:
        raise HTTPException(status_code=409, detail="You cannot deactivate your own signed-in account")
    if target.role == "admin" and target.is_active and not body.is_active:
        active_admins = db.query(User).filter_by(role="admin", is_active=True).count()
        if active_admins <= 1:
            raise HTTPException(status_code=409, detail="The last active administrator cannot be deactivated")
    if target.is_active != body.is_active:
        target.is_active = body.is_active
        if not body.is_active:
            # Revocation is permanent for existing tokens. Reactivating the
            # account must not resurrect credentials issued before deactivation.
            db.query(SessionToken).filter_by(user_id=target.id, revoked=False).update(
                {SessionToken.revoked: True}, synchronize_session=False
            )
        db.add(AuditEvent(actor_id=actor.id, action="user_activated" if body.is_active else "user_deactivated",
                          entity_type="user", entity_id=str(target.id),
                          metadata_json=json_dumps({"role": target.role})))
        db.commit()
        db.refresh(target)
    return {"id": target.id, "username": target.username, "role": target.role, "is_active": target.is_active}


@app.get("/api/v1/admin/audit-events")
def admin_audit_events(limit: int = 100, action: str | None = None,
                       actor: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    limit = min(max(limit, 1), 500)
    query = db.query(AuditEvent)
    if action:
        query = query.filter(AuditEvent.action == action[:100])
    rows = query.order_by(AuditEvent.created_at.desc(), AuditEvent.id.desc()).limit(limit).all()
    return [{"id": row.id, "actor_id": row.actor_id, "action": row.action,
             "entity_type": row.entity_type, "entity_id": row.entity_id,
             "correlation_id": row.correlation_id, "metadata": json_loads(row.metadata_json),
             "created_at": row.created_at}
            for row in rows]


@app.post("/api/v1/jobs", status_code=202)
def create_background_job(body: JobCreateBody, user: User = Depends(current_user), db: Session = Depends(get_db)):
    allowed = JOB_ROLES.get(body.job_type)
    if allowed is None:
        raise HTTPException(status_code=422, detail="Unsupported job type")
    if user.role not in allowed:
        raise HTTPException(status_code=403, detail="Your role cannot submit this job type")
    try:
        job, reused = enqueue_job(db, body.job_type, body.payload, body.idempotency_key,
                                  user.id, priority=body.priority)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not reused:
        db.add(AuditEvent(actor_id=user.id, action="background_job_enqueued", entity_type="background_job",
                          entity_id=str(job.id), metadata_json=json_dumps({"job_type": job.job_type})))
        db.commit()
        db.refresh(job)
    return {**job_dict(job), "idempotent_reuse": reused, "worker_required": True}


@app.post("/api/v1/jobs/imports/{dataset_type}", status_code=202)
async def queue_dataset_import(dataset_type: str, file: UploadFile = File(...),
                               source_name: str = Form(default="uploaded_file"),
                               idempotency_key: str = Header(..., alias="Idempotency-Key"),
                               user: User = Depends(current_user), db: Session = Depends(get_db)):
    if user.role not in JOB_ROLES["import_file"]:
        raise HTTPException(status_code=403, detail="Your role cannot submit dataset imports")
    from app.services.data import DATASET_SCHEMAS
    if dataset_type not in DATASET_SCHEMAS:
        raise HTTPException(status_code=422, detail="Unsupported dataset type")
    if not 8 <= len(idempotency_key) <= 120:
        raise HTTPException(status_code=422, detail="Idempotency-Key must contain 8–120 characters")
    filename = safe_filename(file.filename or "dataset.csv")
    suffix = Path(filename).suffix.lower()
    if suffix not in {".csv", ".xlsx", ".json"}:
        raise HTTPException(status_code=415, detail="Only CSV, XLSX and JSON files are supported")
    source_name = source_name.strip()
    if not source_name or len(source_name) > 120:
        raise HTTPException(status_code=422, detail="source_name must contain 1–120 characters")
    content = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    await file.close()
    if not content:
        raise HTTPException(status_code=422, detail="Uploaded file is empty")
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"File exceeds the {settings.max_upload_mb} MB upload limit")
    content_hash = hashlib.sha256(content).hexdigest()
    existing = db.query(BackgroundJob).filter_by(idempotency_key=idempotency_key).one_or_none()
    if existing:
        existing_payload = json_loads(existing.payload_json)
        same_file = (existing.job_type == "import_file" and
                     existing_payload.get("content_sha256") == content_hash and
                     existing_payload.get("dataset_type") == dataset_type and
                     existing_payload.get("source_name") == source_name and
                     existing_payload.get("original_filename") == filename)
        if same_file:
            if user.role != "admin" and existing.created_by != user.id:
                raise HTTPException(status_code=409, detail="Idempotency key belongs to another user")
            return {**job_dict(existing), "idempotent_reuse": True, "worker_required": True}
        raise HTTPException(status_code=409, detail="Idempotency-Key was already used for different content")

    queue_dir = settings.upload_dir / "queued"
    queue_dir.mkdir(parents=True, exist_ok=True)
    stored_name = uuid.uuid4().hex + suffix
    stored_path = queue_dir / stored_name
    try:
        with stored_path.open("xb") as output:
            output.write(content)
        payload = {"dataset_type": dataset_type, "stored_name": stored_name,
                   "original_filename": filename, "source_name": source_name,
                   "content_sha256": content_hash}
        job, reused = enqueue_job(db, "import_file", payload, idempotency_key, user.id)
    except ValueError as exc:
        stored_path.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception:
        stored_path.unlink(missing_ok=True)
        raise
    if not reused:
        db.add(AuditEvent(actor_id=user.id, action="background_import_enqueued", entity_type="background_job",
                          entity_id=str(job.id), metadata_json=json_dumps({"dataset_type": dataset_type,
                                                                           "content_sha256": content_hash})))
        db.commit()
        db.refresh(job)
    else:
        stored_path.unlink(missing_ok=True)
    return {**job_dict(job), "idempotent_reuse": reused, "worker_required": True}


@app.get("/api/v1/jobs")
def list_background_jobs(status: str | None = None, limit: int = 100,
                         user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = min(max(limit, 1), 200)
    query = db.query(BackgroundJob)
    if user.role != "admin":
        query = query.filter(BackgroundJob.created_by == user.id)
    if status:
        if status not in {"queued", "running", "retry_wait", "succeeded", "failed", "cancelled"}:
            raise HTTPException(status_code=422, detail="Invalid job status filter")
        query = query.filter(BackgroundJob.status == status)
    rows = query.order_by(BackgroundJob.created_at.desc(), BackgroundJob.id.desc()).limit(limit).all()
    return [job_dict(row) for row in rows]


@app.get("/api/v1/jobs/summary")
def background_job_summary(user: User = Depends(current_user), db: Session = Depends(get_db)):
    from sqlalchemy import func
    query = db.query(BackgroundJob.status, func.count(BackgroundJob.id))
    if user.role != "admin":
        query = query.filter(BackgroundJob.created_by == user.id)
    counts = {status: count for status, count in query.group_by(BackgroundJob.status).all()}
    for status in ("queued", "running", "retry_wait", "succeeded", "failed", "cancelled"):
        counts.setdefault(status, 0)
    oldest = db.query(BackgroundJob).filter(BackgroundJob.status.in_(["queued", "retry_wait"]))
    if user.role != "admin":
        oldest = oldest.filter(BackgroundJob.created_by == user.id)
    oldest_job = oldest.order_by(BackgroundJob.created_at.asc()).first()
    return {"counts": counts, "total": sum(counts.values()),
            "oldest_waiting_created_at": oldest_job.created_at if oldest_job else None,
            "worker_required": True, "worker_command": "python -m app.worker run"}


@app.get("/api/v1/jobs/{job_id}")
def get_background_job(job_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    job = db.get(BackgroundJob, job_id)
    if job is None or (user.role != "admin" and job.created_by != user.id):
        raise HTTPException(status_code=404, detail="Job not found")
    return job_dict(job)


@app.post("/api/v1/jobs/{job_id}/cancel")
def cancel_background_job(job_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    job = db.get(BackgroundJob, job_id)
    if job is None or (user.role != "admin" and job.created_by != user.id):
        raise HTTPException(status_code=404, detail="Job not found")
    if job.status not in {"queued", "retry_wait"}:
        raise HTTPException(status_code=409, detail="Only queued or waiting jobs can be cancelled")
    job.status = "cancelled"
    job.finished_at = datetime.now(timezone.utc)
    job.progress_message = "Cancelled before execution"
    job.locked_by = None
    job.locked_until = None
    db.add(AuditEvent(actor_id=user.id, action="background_job_cancelled", entity_type="background_job",
                      entity_id=str(job.id), metadata_json=json_dumps({"job_type": job.job_type})))
    db.commit()
    db.refresh(job)
    return job_dict(job)


@app.post("/api/v1/jobs/{job_id}/retry")
def retry_background_job(job_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    job = db.get(BackgroundJob, job_id)
    if job is None or (user.role != "admin" and job.created_by != user.id):
        raise HTTPException(status_code=404, detail="Job not found")
    if job.status != "failed":
        raise HTTPException(status_code=409, detail="Only failed jobs can be retried")
    job.status = "queued"
    job.attempts = 0
    job.available_at = datetime.now(timezone.utc)
    job.started_at = None
    job.finished_at = None
    job.locked_by = None
    job.locked_until = None
    job.progress_pct = 0
    job.progress_message = "Manually requeued"
    job.error_message = None
    job.result_json = "{}"
    db.add(AuditEvent(actor_id=user.id, action="background_job_retried", entity_type="background_job",
                      entity_id=str(job.id), metadata_json=json_dumps({"job_type": job.job_type})))
    db.commit()
    db.refresh(job)
    return job_dict(job)


@app.get("/api/v1/reports/catalog")
def reports_catalog_api(user: User = Depends(current_user)):
    return {"reports": report_catalog(user.role), "formats": ["csv", "json"]}


@app.get("/api/v1/reports/{report_key}/export")
def export_report(report_key: str, format: str = "csv", user: User = Depends(current_user),
                  db: Session = Depends(get_db)):
    if format not in {"csv", "json"}:
        raise HTTPException(status_code=422, detail="format must be csv or json")
    try:
        report = build_report(db, report_key, user.role)
    except KeyError:
        raise HTTPException(status_code=404, detail="Unknown report")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    filename = f"churn-{report_key}-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.{format}"
    if format == "csv":
        content = to_csv(report)
        media_type = "text/csv; charset=utf-8"
    else:
        content = json_dumps(report)
        media_type = "application/json"
    return Response(content=content, media_type=media_type,
                    headers={"Content-Disposition": f'attachment; filename="{filename}"',
                             "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@app.post("/api/v1/imports/{dataset_type}", status_code=201)
async def upload_dataset(dataset_type: str, file: UploadFile = File(...), source_name: str = "uploaded_csv",
                         user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    name = safe_filename(file.filename or "upload.csv")
    if Path(name).suffix.lower() not in {".csv", ".xlsx", ".json"}:
        raise ValueError("Supported upload formats are CSV, XLSX and JSON")
    content = await file.read(settings.max_upload_mb * 1024 * 1024 + 1)
    if len(content) > settings.max_upload_mb * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Upload exceeds configured size limit")
    digest_path = settings.upload_dir / f"{uuid.uuid4().hex}_{name}"
    digest_path.write_bytes(content)
    try:
        result = import_tabular_file(db, dataset_type, name, content, source_name=source_name)
    except Exception:
        digest_path.unlink(missing_ok=True)
        raise
    result["stored_file"] = digest_path.name if result["status"] != "duplicate" else None
    result["provenance"] = source_name
    return result


@app.get("/api/v1/imports")
def list_imports(user: User = Depends(current_user), db: Session = Depends(get_db)):
    batches = db.query(ImportBatch).order_by(ImportBatch.created_at.desc()).limit(100).all()
    return [{"batch_id":b.id,"dataset_type":b.dataset_type,"filename":b.filename,"status":b.status,
             "received":b.records_received,"accepted":b.records_accepted,"rejected":b.records_rejected,
             "created_at":b.created_at} for b in batches]


@app.get("/api/v1/imports/{batch_id}")
def get_import(batch_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    result = batch_report(db, batch_id)
    if not result: raise HTTPException(status_code=404, detail="Import batch not found")
    return result


@app.get("/api/v1/sources")
def list_data_sources(user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return [{"id": x.id, "connection_key": x.connection_key, "name": x.name, "dataset_type": x.dataset_type,
             "endpoint_url": x.endpoint_url, "credential_configured": bool(x.credential_env_var),
             "enabled": x.enabled, "last_sync_at": x.last_sync_at, "last_sync_status": x.last_sync_status}
            for x in db.query(DataSourceConnection).order_by(DataSourceConnection.created_at.desc()).all()]


@app.post("/api/v1/sources", status_code=201)
def create_data_source(body: DataSourceBody, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    from app.services.data import DATASET_SCHEMAS
    if body.dataset_type not in DATASET_SCHEMAS:
        raise ValueError("Unsupported dataset_type")
    validate_source_url(body.endpoint_url)
    if db.query(DataSourceConnection).filter_by(connection_key=body.connection_key).first():
        raise HTTPException(status_code=409, detail="Data source connection key already exists")
    for remote, canonical in body.field_mapping.items():
        if not remote or canonical not in DATASET_SCHEMAS[body.dataset_type]:
            raise ValueError("Every field mapping target must be a canonical field for the selected dataset type")
    connection = DataSourceConnection(connection_key=body.connection_key, name=body.name,
        dataset_type=body.dataset_type, endpoint_url=body.endpoint_url,
        credential_env_var=body.credential_env_var, record_path=body.record_path,
        field_mapping_json=json_dumps(body.field_mapping), created_by=user.id)
    db.add(connection); db.commit(); db.refresh(connection)
    return {"id": connection.id, "connection_key": connection.connection_key, "status": "configured_without_secret_storage"}


@app.post("/api/v1/sources/{connection_key}/sync")
def sync_data_source(connection_key: str, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    connection = db.query(DataSourceConnection).filter_by(connection_key=connection_key).one_or_none()
    if not connection:
        raise HTTPException(status_code=404, detail="Data source not found")
    return sync_rest_source(db, connection)


@app.get("/api/v1/customers")
def list_customers(q: str = "", limit: int = 50, offset: int = 0,
                   user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = min(max(limit, 1), 100)
    query = db.query(Customer)
    if q:
        query = query.filter((Customer.name.ilike(f"%{q}%")) | (Customer.external_id.ilike(f"%{q}%")) | (Customer.email.ilike(f"%{q}%")))
    total = query.count()
    items = query.order_by(Customer.id).offset(max(offset,0)).limit(limit).all()
    return {"total":total,"limit":limit,"offset":max(offset,0),"items":[{"id":c.id,"external_id":c.external_id,"name":c.name,"segment":c.segment,"country":c.country} for c in items]}


@app.get("/api/v1/customers/{customer_id}")
def get_customer(customer_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    result = customer_360(db, customer_id)
    if result is None: raise HTTPException(status_code=404, detail="Customer not found")
    return result


@app.post("/api/v1/analytics/labels")
def labels(body: CutoffBody, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return generate_labels(db, body.cutoff_at, body.as_of or datetime.now(timezone.utc), body.horizon_days, body.scope)


@app.post("/api/v1/analytics/features")
def features(body: FeatureBody, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return build_features(db, body.cutoff_at, body.feature_version)


@app.get("/api/v1/analytics/overview")
def analytics_overview(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return overview(db)


@app.get("/api/v1/analytics/cohorts")
def analytics_cohorts(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return cohort_retention(db)


@app.get("/api/v1/analytics/survival")
def analytics_survival(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return survival_curve(db)


@app.get("/api/v1/analytics/features")
def analytics_features(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return feature_summary(db)


@app.get("/api/v1/analytics/eda")
def analytics_eda(user: User = Depends(current_user), db: Session = Depends(get_db)):
    from app.services.analytics import eda_report
    return eda_report(db)


@app.get("/api/v1/analytics/fairness")
def analytics_fairness(release_id: str, threshold: float = 0.5, group_by: str = "segment",
                       min_group_size: int = 20,
                       user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return fairness_audit(db, release_id, threshold, group_by, min_group_size)


@app.get("/api/v1/analytics/features/customer/{customer_id}")
def feature_snapshot_get(customer_id: int, cutoff_at: datetime, feature_version: str = "2.1",
                         user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    from app.models import FeatureSnapshot
    row = db.query(FeatureSnapshot).filter_by(customer_id=customer_id, cutoff_date=cutoff_at,
                                               feature_version=feature_version).one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="Feature snapshot not found for the exact customer, cutoff and version")
    return {"id": row.id, "customer_id": row.customer_id, "cutoff_at": row.cutoff_date,
            "feature_version": row.feature_version, "source_fingerprint": row.source_fingerprint,
            "features": json_loads(row.features_json), "created_at": row.created_at,
            "immutable": True}


@app.get("/api/v1/feature-store/registry")
def feature_store_registry(feature_version: str = "2.1",
                          user: User = Depends(require_roles("admin", "analyst", "viewer"))):
    try:
        return feature_registry(feature_version)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/v1/feature-store/summary")
def feature_store_coverage(feature_version: str = "2.1",
                           user: User = Depends(require_roles("admin", "analyst", "viewer")),
                           db: Session = Depends(get_db)):
    try:
        return feature_store_summary(db, feature_version)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/v1/feature-store/customers/{customer_id}/online")
def feature_store_online(customer_id: int, as_of: datetime | None = None,
                         feature_version: str = "2.1", freshness_days: int = 7,
                         user: User = Depends(require_roles("admin", "analyst", "retention_manager")),
                         db: Session = Depends(get_db)):
    try:
        result = latest_online_features(db, customer_id, as_of or datetime.now(timezone.utc),
                                        feature_version, freshness_days)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if result is None:
        raise HTTPException(status_code=404, detail="No feature snapshot exists at or before the requested as_of timestamp")
    return result


@app.get("/api/v1/feature-store/customers/{customer_id}/history")
def feature_store_history(customer_id: int, feature_version: str = "2.1", limit: int = 50,
                          user: User = Depends(require_roles("admin", "analyst", "retention_manager")),
                          db: Session = Depends(get_db)):
    try:
        return customer_feature_history(db, customer_id, feature_version, limit)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/v1/feature-store/export")
def feature_store_export(feature_version: str = "2.1", limit: int = 10000,
                         user: User = Depends(require_roles("admin", "analyst")),
                         db: Session = Depends(get_db)):
    try:
        content = export_feature_snapshots(db, feature_version, limit)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    filename = f"feature-snapshots-{feature_version}.csv"
    return Response(content=content, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@app.post("/api/v1/feature-store/materialize", status_code=202)
def feature_store_materialize(body: FeatureMaterializationBody,
                              idempotency_key: str = Header(..., alias="Idempotency-Key"),
                              user: User = Depends(require_roles("admin", "analyst")),
                              db: Session = Depends(get_db)):
    if body.feature_version != "2.1":
        raise HTTPException(status_code=422, detail="Unsupported feature contract version")
    if body.customer_ids is not None and (any(value <= 0 for value in body.customer_ids)
                                           or len(set(body.customer_ids)) != len(body.customer_ids)):
        raise HTTPException(status_code=422, detail="Customer IDs must be unique positive integers")
    try:
        job, reused = enqueue_job(db, "build_features", {
            "cutoff_at": body.cutoff_at.isoformat(),
            "feature_version": body.feature_version,
            "customer_ids": body.customer_ids,
        }, idempotency_key, user.id)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    payload = job_dict(job, include_payload=False)
    payload["idempotent_reuse"] = reused
    return payload


@app.post("/api/v1/analytics/financial-impact")
def analytics_financial_impact(body: FinancialScenarioBody, user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    from app.services.analytics import financial_impact_scenario
    return financial_impact_scenario(db, body.threshold, body.contribution_margin,
                                     body.retention_success_rate, body.contact_cost)


@app.get("/api/v1/quality/rules")
def quality_rules(user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return list_rules(db)


@app.patch("/api/v1/quality/rules/{rule_code}")
def quality_rule_update(rule_code: str, body: QualityRuleBody, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    return update_rule(db, rule_code, body.enabled, body.severity, body.parameters, user.id)


@app.post("/api/v1/quality/audit", status_code=201)
def quality_audit(scope: str = "all", user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return run_quality_audit(db, scope)


@app.get("/api/v1/quality/findings")
def quality_findings(status: str | None = "open", limit: int = 100,
                     user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return list_findings(db, status, limit)


@app.post("/api/v1/quality/findings/bulk-review")
def quality_findings_bulk_review(body: QualityBulkReviewBody,
                                user: User = Depends(require_roles("admin", "analyst")),
                                db: Session = Depends(get_db)):
    try:
        return bulk_review_findings(db, body.finding_ids, body.decision, user.id, body.note)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/v1/quality/findings/{finding_id}/review")
def quality_finding_review(finding_id: int, body: QualityReviewBody,
                           user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    row = review_finding(db, finding_id, body.decision, user.id, body.corrected_value, body.note)
    return {"id": row.id, "status": row.status, "reviewed_at": row.reviewed_at}


@app.get("/api/v1/quality/runs")
def quality_runs(limit: int = 50, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    items = db.query(DataQualityRun).order_by(DataQualityRun.created_at.desc()).limit(min(max(limit, 1), 200)).all()
    return [{"run_id": x.run_id, "scope": x.scope, "records_scanned": x.records_scanned,
             "finding_count": x.finding_count, "quality_score": x.quality_score,
             "summary": json_loads(x.summary_json), "created_at": x.created_at} for x in items]


@app.get("/api/v1/ml/dataset-audit")
def ml_dataset_audit(feature_version: str = "2.1", horizon_days: int = 30,
                     user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    try:
        return audit_training_dataset(db, feature_version, horizon_days)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.post("/api/v1/ml/train", status_code=201)
def train(body: TrainBody, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return train_models(db, body.feature_version, body.horizon_days,
                        body.false_positive_cost, body.false_negative_cost, body.cost_unit)


@app.get("/api/v1/ml/models")
def models(user: User = Depends(current_user), db: Session = Depends(get_db)):
    items = db.query(ModelRelease).order_by(ModelRelease.created_at.desc()).all()
    return [{"release_id":m.release_id,"model_name":m.model_name,"status":m.status,"horizon_days":m.horizon_days,
             "feature_version":m.feature_version,"metrics":json_loads(m.metrics_json),"created_at":m.created_at} for m in items]


@app.post("/api/v1/ml/models/{release_id}/approve")
def approve_model(release_id: str, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    release = approve_release(db, release_id, user.id)
    db.add(AuditEvent(actor_id=user.id, action="model_release_approved", entity_type="model_release",
                      entity_id=release_id, metadata_json="{}")); db.commit()
    return {"release_id":release.release_id,"status":release.status,"approved_by":user.username}


@app.post("/api/v1/ml/models/{release_id}/rollback")
def rollback_model(release_id: str, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    release = rollback_release(db, release_id)
    db.add(AuditEvent(actor_id=user.id, action="model_release_rollback", entity_type="model_release",
                      entity_id=release_id, metadata_json="{}")); db.commit()
    return {"release_id":release.release_id,"status":release.status,"rollback":"completed"}


@app.get("/api/v1/ops/performance")
def model_performance(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return evaluate_matured_predictions(db)


@app.get("/api/v1/ops/retraining-readiness")
def retraining_readiness(user: User = Depends(current_user), db: Session = Depends(get_db)):
    matured = db.query(ChurnLabel).filter(ChurnLabel.entity_scope == "customer",
            ChurnLabel.churn_30d.in_([0, 1]), ChurnLabel.is_censored.is_(False)).count()
    eligible = matured >= 30
    return {"eligible_to_attempt_training":eligible,"mature_customer_labels":matured,
            "minimum_required_labels":30,"approval_required":True,
            "note":"Eligibility only checks sample count. Training still validates chronological partitions, both classes, feature alignment and model evaluation."}


@app.post("/api/v1/ml/predict/{customer_id}")
def predict(customer_id: int, body: PredictionBody, user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return predict_customer(db, customer_id, body.cutoff_at, body.release_id)


@app.get("/api/v1/ml/predictions")
def predictions(limit: int = 100, user: User = Depends(current_user), db: Session = Depends(get_db)):
    limit = min(max(limit,1),500)
    items = db.query(Prediction).order_by(Prediction.created_at.desc()).limit(limit).all()
    return [{"id":p.id,"customer_id":p.customer_id,"probability":p.probability,"risk_band":p.risk_band,
             "release_id":p.release_id,"cutoff_date":p.cutoff_date,"horizon_days":p.horizon_days} for p in items]


@app.post("/api/v1/ml/predict/batch", status_code=201)
def predict_batch(body: BatchPredictionBody,
                  user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return score_customer_batch(db, body.cutoff_at, body.idempotency_key, body.customer_ids, body.release_id)


@app.post("/api/v1/ml/predict/batches/{batch_id}/retry", status_code=201)
def prediction_batch_retry(batch_id: str, idempotency_key: str = Header(..., alias="Idempotency-Key"),
                           user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    if len(idempotency_key) < 8 or len(idempotency_key) > 120:
        raise HTTPException(status_code=422, detail="Idempotency-Key must contain 8–120 characters")
    return retry_failed_prediction_batch(db, batch_id, idempotency_key)


@app.get("/api/v1/ml/models/{release_id}/shap/global")
def model_global_shap(release_id: str, sample_limit: int = 250,
                      user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return global_shap_summary(db, release_id, sample_limit)


@app.get("/api/v1/ml/predict/batches")
def prediction_batches(limit: int = 50, user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(PredictionBatch).order_by(PredictionBatch.created_at.desc()).limit(min(max(limit, 1), 200)).all()
    return [{"batch_id": x.batch_id, "release_id": x.release_id, "status": x.status,
             "requested": x.requested_count, "succeeded": x.succeeded_count, "failed": x.failed_count,
             "results": json_loads(x.results_json), "created_at": x.created_at, "completed_at": x.completed_at} for x in rows]


@app.post("/api/v1/retention/recommendations/generate", status_code=201)
def retention_generate(user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return generate_recommendations(db)


@app.get("/api/v1/retention/recommendations")
def retention_list(user: User = Depends(current_user), db: Session = Depends(get_db)):
    items = db.query(RetentionRecommendation).order_by(RetentionRecommendation.created_at.desc()).limit(250).all()
    return [{"id":r.id,"customer_id":r.customer_id,"prediction_id":r.prediction_id,"category":r.category,
             "title":r.title,"rationale":r.rationale,"evidence":json_loads(r.evidence_json),"priority":r.priority,
             "status":r.status,"outcome":json_loads(r.outcome_json)} for r in items]


@app.post("/api/v1/retention/recommendations/{recommendation_id}/review")
def retention_review(recommendation_id: int, body: ReviewBody,
                     user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    rec = review_recommendation(db, recommendation_id, body.decision, user.id)
    db.add(AuditEvent(actor_id=user.id, action=f"recommendation_{body.decision}", entity_type="recommendation",
                      entity_id=str(rec.id), metadata_json="{}")); db.commit()
    return {"id":rec.id,"status":rec.status}


@app.post("/api/v1/retention/recommendations/{recommendation_id}/outcome")
def retention_outcome(recommendation_id: int, body: OutcomeBody,
                      user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    rec = record_outcome(db, recommendation_id, body.outcome, body.notes)
    return {"id":rec.id,"outcome":json_loads(rec.outcome_json)}


@app.get("/api/v1/retention/playbooks")
def retention_playbooks(user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return list_playbooks(db)


@app.put("/api/v1/retention/playbooks/{playbook_key}")
def retention_playbook_publish(playbook_key: str, body: RetentionPlaybookBody,
                               user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    return publish_playbook(db, playbook_key, body.policy, user.id)


@app.post("/api/v1/retention/recommendations/{recommendation_id}/assign", status_code=201)
def retention_assign(recommendation_id: int, body: RetentionAssignBody,
                     user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    row = assign_recommendation(db, recommendation_id, body.assignee_id, body.due_at, body.notes)
    return {"id": row.id, "recommendation_id": row.recommendation_id, "assignee_id": row.assignee_id,
            "due_at": row.due_at, "status": row.status}


@app.get("/api/v1/retention/assignments")
def retention_assignments(user: User = Depends(require_roles("admin", "retention_manager", "analyst")), db: Session = Depends(get_db)):
    query = db.query(RetentionAssignment).order_by(RetentionAssignment.due_at.asc())
    if user.role == "retention_manager":
        query = query.filter_by(assignee_id=user.id)
    return [{"id": x.id, "recommendation_id": x.recommendation_id, "assignee_id": x.assignee_id,
             "due_at": x.due_at, "status": x.status, "notes": x.notes} for x in query.limit(500).all()]


@app.post("/api/v1/retention/experiments/sample-size")
def retention_experiment_sample_size(body: ExperimentSampleSizeBody,
                                     user: User = Depends(require_roles("admin", "analyst", "retention_manager"))):
    try:
        return calculate_binary_experiment_sample_size(
            baseline_retention=body.baseline_retention,
            minimum_detectable_effect=body.minimum_detectable_effect,
            treatment_pct=body.treatment_pct,
            alpha=body.alpha,
            power=body.power,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/api/v1/retention/experiments")
def retention_experiment_list(user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    items = db.query(RetentionExperiment).order_by(RetentionExperiment.created_at.desc()).limit(100).all()
    return [{"id": x.id, "experiment_key": x.experiment_key, "name": x.name, "hypothesis": x.hypothesis,
             "status": x.status, "followup_days": x.followup_days,
             "treatment_pct": x.allocation_treatment_pct,
             "assignments": db.query(RetentionExperimentAssignment).filter_by(experiment_id=x.id).count(),
             "created_at": x.created_at} for x in items]


@app.post("/api/v1/retention/experiments", status_code=201)
def retention_experiment_create(body: ExperimentCreateBody,
                                user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    row = create_experiment(db, body.name, body.hypothesis, body.treatment_pct, body.followup_days, user.id)
    return {"id": row.id, "experiment_key": row.experiment_key, "status": row.status}


@app.post("/api/v1/retention/experiments/{experiment_id}/start")
def retention_experiment_start(experiment_id: int, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    row = start_experiment(db, experiment_id, user.id)
    return {"id": row.id, "status": row.status, "started_at": row.started_at}


@app.post("/api/v1/retention/experiments/{experiment_id}/enroll")
def retention_experiment_enroll(experiment_id: int, body: ExperimentEnrollBody,
                                user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return enroll_experiment(db, experiment_id, body.customer_ids)


@app.post("/api/v1/retention/experiments/assignments/{assignment_id}/outcome")
def retention_experiment_record_outcome(assignment_id: int, body: ExperimentOutcomeBody,
                                        user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    row = record_experiment_outcome(db, assignment_id, body.outcome, user.id)
    return {"assignment_id": row.id, "outcome": row.outcome, "outcome_at": row.outcome_at}


@app.post("/api/v1/retention/experiments/assignments/{assignment_id}/outcome/correction")
def retention_experiment_correct_outcome(assignment_id: int, body: ExperimentOutcomeCorrectionBody,
                                         user: User = Depends(require_roles("admin")),
                                         db: Session = Depends(get_db)):
    try:
        row = correct_experiment_outcome(db, assignment_id, body.outcome, user.id, body.reason)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"assignment_id": row.id, "outcome": row.outcome, "outcome_at": row.outcome_at,
            "corrected": True, "audit_required": True}


@app.get("/api/v1/retention/experiments/{experiment_id}/report")
def retention_experiment_get_report(experiment_id: int,
                                    user: User = Depends(require_roles("admin", "analyst", "retention_manager")), db: Session = Depends(get_db)):
    return experiment_report(db, experiment_id)


@app.post("/api/v1/retention/experiments/{experiment_id}/close")
def retention_experiment_close(experiment_id: int, user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    row = close_experiment(db, experiment_id, user.id)
    return {"id": row.id, "status": row.status, "ended_at": row.ended_at}


@app.post("/api/v1/crm/identities", status_code=201)
def crm_identity_create(body: ExternalIdentityBody,
                        user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    if body.provider not in {"salesforce", "hubspot", "intercom"} or body.entity_type != "customer":
        raise ValueError("Only customer identities for salesforce, hubspot, and intercom are supported")
    customer = db.get(Customer, body.local_entity_id)
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    previous = db.query(ExternalIdentity).filter_by(provider=body.provider, entity_type="customer",
                                                     local_entity_id=body.local_entity_id).one_or_none()
    if previous:
        previous.remote_entity_id = body.remote_entity_id
    else:
        previous = ExternalIdentity(provider=body.provider, entity_type="customer",
                                     local_entity_id=body.local_entity_id, remote_entity_id=body.remote_entity_id)
        db.add(previous)
    db.commit(); db.refresh(previous)
    return {"id": previous.id, "provider": previous.provider, "local_entity_id": previous.local_entity_id,
            "remote_entity_id": previous.remote_entity_id}


@app.post("/api/v1/crm/providers/{provider}/recommendations/{recommendation_id}/execute")
def crm_provider_execute(provider: str, recommendation_id: int, body: CRMExecuteBody,
                         user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    if body.provider not in {"sandbox", provider}:
        raise ValueError("Provider in path and body must match")
    return execute_live_crm_action(db, recommendation_id, provider, body.idempotency_key)


@app.post("/api/v1/crm/sandbox/{recommendation_id}/execute")
def crm_sandbox(recommendation_id: int, body: CRMExecuteBody,
                user: User = Depends(require_roles("admin", "retention_manager")), db: Session = Depends(get_db)):
    return execute_sandbox_action(db, recommendation_id, body.idempotency_key)


@app.get("/api/v1/crm/actions")
def crm_actions(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return [{"id":a.id,"recommendation_id":a.recommendation_id,"provider":a.provider,"action_type":a.action_type,
             "status":a.status,"external_reference":a.external_reference,"result":json_loads(a.result_json)}
            for a in db.query(CRMAction).order_by(CRMAction.created_at.desc()).limit(100).all()]


@app.get("/api/v1/ops/integrations")
def integrations(user: User = Depends(current_user)):
    return {"platform": integration_capabilities(), "crm_providers": provider_capabilities()}


@app.post("/api/v1/ops/drift")
def drift(body: DriftBody, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return run_drift_check(db, body.release_id, body.baseline_snapshot_ids, body.threshold)


@app.post("/api/v1/ops/evidently-drift")
def evidently_drift(body: DriftBody, user: User = Depends(require_roles("admin", "analyst")), db: Session = Depends(get_db)):
    return run_evidently_drift(db, body.release_id, body.baseline_snapshot_ids)


@app.get("/api/v1/ops/drift")
def drift_reports(user: User = Depends(current_user), db: Session = Depends(get_db)):
    from app.models import DriftReport
    return [{"id":r.id,"release_id":r.release_id,"metric_name":r.metric_name,"metric_value":r.metric_value,
             "threshold":r.threshold,"status":r.status,"created_at":r.created_at}
            for r in db.query(DriftReport).order_by(DriftReport.created_at.desc()).limit(200).all()]


@app.post("/api/v1/admin/backup")
def backup_database(user: User = Depends(require_roles("admin")), db: Session = Depends(get_db)):
    if not settings.database_url.startswith("sqlite"):
        raise HTTPException(status_code=501, detail="This local backup command supports SQLite only; use the configured database provider's backup procedure for PostgreSQL.")
    raw_path = settings.database_url.removeprefix("sqlite:///")
    source = Path(raw_path).resolve()
    if not source.exists(): raise HTTPException(status_code=409, detail="Database file does not exist")
    target = settings.artifact_dir / f"backup-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.sqlite"
    src = sqlite3.connect(source); dst = sqlite3.connect(target)
    try: src.backup(dst)
    finally: dst.close(); src.close()
    verify = sqlite3.connect(target)
    try: result = verify.execute("PRAGMA integrity_check").fetchone()[0]
    finally: verify.close()
    if result != "ok":
        target.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail="Backup integrity check failed")
    return {"backup_file":target.name,"integrity_check":result,"restore_note":"Restore only into a stopped/disposable database after preserving the current database."}


@app.get("/")
def dashboard():
    return FileResponse(Path(__file__).parent / "static" / "index.html")


app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")
