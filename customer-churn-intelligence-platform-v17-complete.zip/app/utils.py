from __future__ import annotations

import hashlib
import json
import math
import secrets
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any


def json_dumps(value: Any) -> str:
    return json.dumps(value, default=lambda x: x.isoformat() if hasattr(x, "isoformat") else str(x), separators=(",", ":"))


def json_loads(value: str | None, default: Any = None) -> Any:
    if not value:
        return {} if default is None else default
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return {} if default is None else default


def parse_datetime(value: Any, *, end_of_day: bool = False) -> datetime | None:
    if value is None or str(value).strip() == "":
        return None
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, date):
        dt = datetime.combine(value, datetime.max.time() if end_of_day else datetime.min.time())
    else:
        raw = str(value).strip()
        try:
            dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            try:
                d = date.fromisoformat(raw[:10])
                dt = datetime.combine(d, datetime.max.time() if end_of_day else datetime.min.time())
            except ValueError as exc:
                raise ValueError(f"Invalid date/time value: {raw}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def as_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def to_decimal(value: Any, *, field: str = "value") -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"{field} must be numeric") from exc
    if not result.is_finite():
        raise ValueError(f"{field} must be finite")
    return result


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_fingerprint(value: Any) -> str:
    return sha256_bytes(json_dumps(value).encode("utf-8"))


def safe_filename(filename: str) -> str:
    import re
    name = filename.replace("\\", "/").split("/")[-1]
    cleaned = re.sub(r"[^A-Za-z0-9_.-]", "_", name).strip("._")
    return (cleaned or "upload.csv")[:180]


def risk_band(probability: float) -> str:
    if probability >= 0.70:
        return "high"
    if probability >= 0.35:
        return "medium"
    return "low"


def finite_probability(value: Any) -> float:
    result = float(value)
    if not math.isfinite(result) or not 0 <= result <= 1:
        raise ValueError("Model returned an invalid probability")
    return result


def new_secret() -> str:
    return secrets.token_urlsafe(36)
