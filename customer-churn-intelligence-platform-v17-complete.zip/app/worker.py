from __future__ import annotations

import argparse
import logging
import os
import signal
import socket
import time
import uuid
from datetime import datetime, timedelta, timezone
from threading import Event, Thread

from sqlalchemy import and_, or_
from sqlalchemy.orm import Session, sessionmaker

from app.db import SessionLocal
from app.models import BackgroundJob
from app.services.jobs import execute_job
from app.utils import json_dumps, json_loads

logger = logging.getLogger("churn_worker")
_STOP = False


def _request_stop(_signum, _frame):
    global _STOP
    _STOP = True


def claim_next_job(db: Session, worker_id: str, lease_seconds: int = 900) -> int | None:
    """Claim the oldest eligible job using a DB row lock (Postgres) and lease.

    Run one worker process for SQLite deployments. PostgreSQL supports multiple
    worker replicas with SKIP LOCKED semantics.
    """
    now = datetime.now(timezone.utc)
    expired = db.query(BackgroundJob).filter(
        BackgroundJob.status == "running",
        BackgroundJob.locked_until.is_not(None),
        BackgroundJob.locked_until <= now,
        BackgroundJob.attempts >= BackgroundJob.max_attempts,
    ).all()
    for row in expired:
        row.status = "failed"
        row.error_message = "Worker lease expired after maximum attempts"
        row.finished_at = now
        row.locked_by = None
        row.locked_until = None
    db.flush()

    eligible = or_(
        and_(BackgroundJob.status.in_(["queued", "retry_wait"]), BackgroundJob.available_at <= now),
        and_(BackgroundJob.status == "running", BackgroundJob.locked_until.is_not(None),
             BackgroundJob.locked_until <= now, BackgroundJob.attempts < BackgroundJob.max_attempts),
    )
    job = (db.query(BackgroundJob).filter(eligible)
           .order_by(BackgroundJob.priority.desc(), BackgroundJob.created_at.asc(), BackgroundJob.id.asc())
           .with_for_update(skip_locked=True).first())
    if job is None:
        db.commit()
        return None
    job.status = "running"
    job.attempts += 1
    job.locked_by = worker_id
    job.locked_until = now + timedelta(seconds=lease_seconds)
    job.started_at = job.started_at or now
    job.progress_pct = max(job.progress_pct, 1)
    job.progress_message = "Worker claimed job"
    job.error_message = None
    db.commit()
    return job.id


def _renew_lease_loop(job_id: int, worker_id: str, session_factory: sessionmaker,
                      lease_seconds: int, stop_event: Event) -> None:
    """Renew a running job lease while its handler is executing."""
    interval = max(5.0, min(60.0, lease_seconds / 3))
    while not stop_event.wait(interval):
        db = session_factory()
        try:
            job = db.get(BackgroundJob, job_id)
            if job is None or job.status != "running" or job.locked_by != worker_id:
                return
            job.locked_until = datetime.now(timezone.utc) + timedelta(seconds=lease_seconds)
            db.commit()
        except Exception:
            db.rollback()
            logger.exception("Lease heartbeat failed for job %s", job_id)
        finally:
            db.close()


def process_claimed_job(job_id: int, worker_id: str, session_factory: sessionmaker,
                        *, backoff_base_seconds: int = 5, lease_seconds: int = 900) -> dict:
    db: Session = session_factory()
    heartbeat_stop = Event()
    heartbeat: Thread | None = None
    try:
        job = db.get(BackgroundJob, job_id)
        if job is None or job.status != "running" or job.locked_by != worker_id:
            return {"job_id": job_id, "status": "lost_lease"}
        job_type = job.job_type
        payload = json_loads(job.payload_json)
        heartbeat = Thread(target=_renew_lease_loop,
                           args=(job_id, worker_id, session_factory, lease_seconds, heartbeat_stop),
                           name=f"job-lease-{job_id}", daemon=True)
        heartbeat.start()
        try:
            result = execute_job(db, job)
            # A slow handler may have lost its lease because the database became
            # unavailable. Never let an old worker overwrite a newer claim.
            job = db.get(BackgroundJob, job_id)
            if job is None or job.status != "running" or job.locked_by != worker_id:
                return {"job_id": job_id, "status": "lost_lease"}
            job.status = "succeeded"
            job.progress_pct = 100
            job.progress_message = "Completed"
            job.result_json = json_dumps(result)
            job.error_message = None
            job.finished_at = datetime.now(timezone.utc)
            job.locked_by = None
            job.locked_until = None
            db.commit()
            # Uploaded files are retained for retry while a job is pending.
            # Delete only after the import handler and job completion committed.
            if job_type == "import_file":
                from pathlib import Path
                from app.config import settings
                stored_name = str(payload.get("stored_name", ""))
                queue_dir = (settings.upload_dir / "queued").resolve()
                file_path = (queue_dir / stored_name).resolve()
                if file_path.parent == queue_dir:
                    file_path.unlink(missing_ok=True)
            return {"job_id": job_id, "status": "succeeded", "result": result}
        except Exception as exc:
            db.rollback()
            job = db.get(BackgroundJob, job_id)
            if job is None or job.status != "running" or job.locked_by != worker_id:
                return {"job_id": job_id, "status": "lost_lease"}
            now = datetime.now(timezone.utc)
            job.error_message = f"{type(exc).__name__}: {str(exc)[:1500]}"
            job.progress_message = "Attempt failed; retry scheduled" if job.attempts < job.max_attempts else "Attempts exhausted"
            job.locked_by = None
            job.locked_until = None
            if job.attempts >= job.max_attempts:
                job.status = "failed"
                job.finished_at = now
            else:
                job.status = "retry_wait"
                delay = min(300, backoff_base_seconds * (2 ** max(0, job.attempts - 1)))
                job.available_at = now + timedelta(seconds=delay)
            db.commit()
            logger.exception("Job %s failed on attempt %s", job_id, job.attempts)
            return {"job_id": job_id, "status": job.status, "error": job.error_message,
                    "available_at": job.available_at.isoformat() if job.available_at else None}
    finally:
        heartbeat_stop.set()
        if heartbeat is not None:
            heartbeat.join(timeout=2)
        db.close()


def process_one_job(session_factory: sessionmaker = SessionLocal, worker_id: str | None = None,
                    lease_seconds: int = 900) -> dict | None:
    worker_id = worker_id or f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"
    db = session_factory()
    try:
        job_id = claim_next_job(db, worker_id, lease_seconds)
    finally:
        db.close()
    if job_id is None:
        return None
    return process_claimed_job(job_id, worker_id, session_factory, lease_seconds=lease_seconds)


def run_worker(poll_interval: float = 2.0, worker_id: str | None = None,
               max_jobs: int = 0, lease_seconds: int = 900) -> int:
    global _STOP
    _STOP = False
    worker_id = worker_id or f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"
    signal.signal(signal.SIGINT, _request_stop)
    signal.signal(signal.SIGTERM, _request_stop)
    processed = 0
    logger.info("Worker started id=%s poll=%.2fs", worker_id, poll_interval)
    while not _STOP:
        result = process_one_job(SessionLocal, worker_id, lease_seconds)
        if result is None:
            time.sleep(poll_interval)
            continue
        processed += 1
        logger.info("Job completed result=%s", result)
        if max_jobs and processed >= max_jobs:
            break
    logger.info("Worker stopped id=%s processed=%s", worker_id, processed)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Churn platform persistent background worker")
    sub = parser.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="Poll the durable queue until stopped")
    run.add_argument("--poll-interval", type=float, default=2.0)
    run.add_argument("--worker-id", default=None)
    run.add_argument("--max-jobs", type=int, default=0, help="0 means unlimited")
    run.add_argument("--lease-seconds", type=int, default=900)
    args = parser.parse_args()
    if args.command == "run":
        if not 0.25 <= args.poll_interval <= 60:
            parser.error("--poll-interval must be between 0.25 and 60 seconds")
        if args.max_jobs < 0 or not 30 <= args.lease_seconds <= 7200:
            parser.error("--max-jobs must be >= 0 and --lease-seconds 30..7200")
        logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                            format="%(asctime)s %(levelname)s %(name)s %(message)s")
        return run_worker(args.poll_interval, args.worker_id, args.max_jobs, args.lease_seconds)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
