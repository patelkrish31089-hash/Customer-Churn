"""SQLAlchemy declarative metadata base, kept free of engine initialization.

Alembic's offline migration renderer imports this module without requiring a
live database driver or opening an application database connection.
"""
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass
