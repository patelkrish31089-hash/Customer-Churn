from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy.orm import Session
from app.models import (Customer, Subscription, Invoice, Payment, UsageEvent, SupportTicket,
                        ChurnLabel, FeatureSnapshot)
from app.services.data import build_features
from app.utils import json_dumps


def seed_demo(db: Session, customers: int = 180, seed: int = 29) -> dict:
    """Seed labelled synthetic training cohorts for local verification, not real business use."""
    rng = random.Random(seed)
    today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    created = 0
    for i in range(customers):
        ext = f"SYN-CUST-{i+1:05d}"
        existing = db.query(Customer).filter_by(external_id=ext).one_or_none()
        if existing:
            continue
        start = today - timedelta(days=rng.randint(240, 1200))
        is_churn = rng.random() < 0.28
        churn_at = start + timedelta(days=rng.randint(75, 88)) if is_churn else None
        reason = rng.choice(["customer_request", "non_payment", "product_sunset"]) if is_churn else None
        currency = rng.choice(["USD", "INR"])
        customer = Customer(external_id=ext, name=f"Synthetic Customer {i+1}",
                            email=f"customer{i+1}@example.invalid", segment=rng.choice(["SMB", "Mid-Market", "Enterprise"]),
                            country=rng.choice(["IN", "US", "GB"]), acquisition_date=start,
                            consent_to_contact=(i % 4 == 0), source_name="synthetic_demo")
        db.add(customer); db.flush()
        subscription = Subscription(external_id=f"SYN-SUB-{i+1:05d}", customer_id=customer.id,
                                    plan=rng.choice(["Starter", "Growth", "Pro"]),
                                    status="cancelled" if is_churn else "active", start_date=start,
                                    end_date=churn_at, cancellation_date=churn_at, churn_reason=reason,
                                    mrr=Decimal(str(rng.choice([29, 49, 99, 199]))), currency=currency,
                                    source_name="synthetic_demo")
        db.add(subscription); db.flush()
        # Billing and activity history is generated strictly before/after the cohort cutoff as appropriate.
        for month in range(1, 7):
            inv_date = start + timedelta(days=30*month)
            if inv_date > today: continue
            invoice_id = f"SYN-INV-{i+1:05d}-{month}"
            invoice = Invoice(external_id=invoice_id, customer_id=customer.id, subscription_id=subscription.id,
                              invoice_date=inv_date, amount=Decimal(str(subscription.mrr)), currency=currency,
                              status="paid" if rng.random() > 0.08 else "open", source_name="synthetic_demo")
            db.add(invoice); db.flush()
            pay_status = "failed" if rng.random() < (0.15 if is_churn else 0.04) else "succeeded"
            db.add(Payment(external_id=f"SYN-PAY-{i+1:05d}-{month}", customer_id=customer.id,
                           invoice_id=invoice.id, payment_date=inv_date + timedelta(days=2),
                           amount=Decimal(str(subscription.mrr)) if pay_status == "succeeded" else Decimal("0.00"),
                           currency=currency, status=pay_status, source_name="synthetic_demo"))
        for event_no in range(16):
            event_at = start + timedelta(days=event_no * 7 + 1)
            if event_at > today: continue
            # Engagement declines in part of churn cohort, creating demonstrative, not validated, signal.
            if is_churn and event_no > 9 and rng.random() < 0.60: continue
            db.add(UsageEvent(external_id=f"SYN-EVT-{i+1:05d}-{event_no}", customer_id=customer.id,
                              subscription_id=subscription.id, event_time=event_at,
                              event_type=rng.choice(["login", "feature_use", "session"]),
                              quantity=float(rng.randint(1,5)), source_name="synthetic_demo"))
        if rng.random() < 0.30:
            t = start + timedelta(days=rng.randint(20, 150))
            db.add(SupportTicket(external_id=f"SYN-TKT-{i+1:05d}", customer_id=customer.id,
                                 created_at=t, resolved_at=t+timedelta(days=2),
                                 status="resolved", priority=rng.choice(["normal", "high"]),
                                 category="product_help", source_name="synthetic_demo"))
        created += 1
    db.commit()

    # Each synthetic entity receives a historical, customer-specific prediction cutoff.
    # This creates a genuine chronological population while keeping features point-in-time.
    label_count = feature_count = 0
    all_customers = db.query(Customer).filter(Customer.external_id.like("SYN-CUST-%")).all()
    for customer in all_customers:
        sub = db.query(Subscription).filter_by(customer_id=customer.id).first()
        start_at = sub.start_date.replace(tzinfo=timezone.utc) if sub.start_date.tzinfo is None else sub.start_date
        cutoff = start_at + timedelta(days=60)
        maturity = cutoff + timedelta(days=30)
        event_at = sub.cancellation_date
        if event_at is not None and event_at.tzinfo is None:
            event_at = event_at.replace(tzinfo=timezone.utc)
        if event_at and cutoff < event_at <= maturity:
            target = 1
            churn_type = "VOLUNTARY" if sub.churn_reason == "customer_request" else ("INVOLUNTARY" if sub.churn_reason == "non_payment" else "OTHER")
        elif today >= maturity:
            target = 0; churn_type = "NONE"
        else:
            target = None; churn_type = "UNKNOWN"
        exists = db.query(ChurnLabel).filter_by(entity_scope="customer", entity_ref=customer.external_id,
                                                cutoff_date=cutoff, horizon_days=30).one_or_none()
        if not exists:
            db.add(ChurnLabel(customer_id=customer.id, entity_scope="customer", entity_ref=customer.external_id,
                              cutoff_date=cutoff, horizon_days=30, churn_30d=target, churn_type=churn_type,
                              event_date=event_at if target == 1 else None, maturity_date=maturity,
                              is_censored=target is None, evidence=json_dumps({"synthetic":True,"policy":"demo-v1"})))
            label_count += 1
        before = db.query(FeatureSnapshot).filter_by(customer_id=customer.id, cutoff_date=cutoff, feature_version="2.1").one_or_none()
        if not before:
            build_features(db, cutoff, "2.1", customer_ids=[customer.id])
            feature_count += 1
    db.commit()
    return {"customers_created":created,"customers_total":len(all_customers),"labels_created":label_count,
            "feature_snapshots_created":feature_count,"provenance":"synthetic_demo","not_real_company_data":True}
