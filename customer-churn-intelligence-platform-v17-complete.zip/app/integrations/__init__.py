"""External provider adapters. Credentials are read at runtime from environment/secret managers."""
