from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import httpx
from sqlalchemy.orm import Session

from app.models import DataSourceConnection
from app.services.data import DATASET_SCHEMAS, import_tabular_file
from app.utils import json_dumps, json_loads

MAX_REST_RESPONSE_BYTES = 25 * 1024 * 1024


class RestResponseTooLarge(ValueError):
    """REST response exceeded the bounded import size."""


def validate_source_url(url: str, allowed_hosts: set[str] | None = None,
                        resolve_dns: bool = False) -> str:
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("REST source URL must be HTTPS and cannot include embedded credentials")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"}:
        raise ValueError("Localhost data sources are not allowed")
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None and not ip.is_global:
        raise ValueError("Private or non-routable IP addresses are not allowed as REST sources")
    allow = allowed_hosts or {x.strip().lower() for x in os.getenv("DATA_SOURCE_ALLOWED_HOSTS", "").split(",") if x.strip()}
    if allow and host not in allow:
        raise ValueError("REST source host is not in DATA_SOURCE_ALLOWED_HOSTS allowlist")
    if not allow:
        raise ValueError("DATA_SOURCE_ALLOWED_HOSTS must explicitly allow the REST source host")
    # API requests use this check before opening a connection. Reject a
    # hostname that resolves to a private, loopback, link-local, multicast,
    # reserved or otherwise non-global address. Network egress controls are
    # still required to defend against DNS rebinding between lookup and connect.
    if resolve_dns and ip is None:
        try:
            addresses = {item[4][0].split("%", 1)[0]
                         for item in socket.getaddrinfo(host, parsed.port or 443, type=socket.SOCK_STREAM)}
        except OSError as exc:
            raise ValueError("REST source hostname could not be resolved") from exc
        if not addresses:
            raise ValueError("REST source hostname has no address records")
        for address in addresses:
            resolved_ip = ipaddress.ip_address(address)
            if not resolved_ip.is_global:
                raise ValueError("REST source hostname resolves to a private or non-routable address")
    return host


def _select_path(payload: Any, path: str | None) -> Any:
    if not path:
        return payload
    current = payload
    for segment in path.split("."):
        if isinstance(current, dict):
            current = current.get(segment)
        elif isinstance(current, list) and segment.isdigit():
            current = current[int(segment)] if int(segment) < len(current) else None
        else:
            return None
    return current


def _apply_mapping(records: list[dict[str, Any]], mapping: dict[str, str]) -> list[dict[str, Any]]:
    if not mapping:
        return records
    # mapping is remote_field -> canonical_field; unmapped values are preserved for auditability.
    normalized = []
    for row in records:
        result = dict(row)
        for remote, canonical in mapping.items():
            if remote in row and canonical:
                result[canonical] = row[remote]
        normalized.append(result)
    return normalized


def sync_rest_source(db: Session, connection: DataSourceConnection, client: httpx.Client | None = None) -> dict[str, Any]:
    if not connection.enabled:
        raise ValueError("REST source is disabled")
    # A supplied client is used for deterministic tests or a caller-managed
    # transport. The production path always resolves and checks public IPs.
    validate_source_url(connection.endpoint_url, resolve_dns=client is None)
    if connection.dataset_type not in DATASET_SCHEMAS:
        raise ValueError("REST source dataset type is unsupported")
    headers = {"Accept": "application/json"}
    if connection.credential_env_var:
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{2,119}", connection.credential_env_var):
            raise ValueError("Credential environment variable name is invalid")
        token = os.getenv(connection.credential_env_var, "").strip()
        if not token:
            raise ValueError("Configured REST source credential is missing from the environment")
        headers["Authorization"] = f"Bearer {token}"
    own_client = client is None
    client = client or httpx.Client(timeout=httpx.Timeout(20.0, connect=5.0),
                                    follow_redirects=False, trust_env=False)
    try:
        # Stream instead of materializing an unbounded response body before
        # enforcing the configured limit.
        chunks: list[bytes] = []
        size = 0
        with client.stream("GET", connection.endpoint_url, headers=headers,
                            follow_redirects=False) as response:
            response.raise_for_status()
            for chunk in response.iter_bytes():
                size += len(chunk)
                if size > MAX_REST_RESPONSE_BYTES:
                    raise RestResponseTooLarge("REST source response exceeds the 25 MB import limit")
                chunks.append(chunk)
        payload = json.loads(b"".join(chunks))
    except RestResponseTooLarge as exc:
        connection.last_sync_at = datetime.now(timezone.utc)
        connection.last_sync_status = "failed"
        db.commit()
        raise ValueError(str(exc)) from exc
    except (httpx.HTTPError, ValueError) as exc:
        connection.last_sync_at = datetime.now(timezone.utc)
        connection.last_sync_status = "failed"
        db.commit()
        raise ValueError(f"REST source sync failed: {type(exc).__name__}") from exc
    finally:
        if own_client:
            client.close()
    records = _select_path(payload, connection.record_path)
    if isinstance(records, dict):
        records = records.get("records", records.get("results", records.get("data")))
    if not isinstance(records, list) or not all(isinstance(x, dict) for x in records):
        raise ValueError("REST response must resolve to an array of record objects")
    mapped = _apply_mapping(records, json_loads(connection.field_mapping_json))
    result = import_tabular_file(db, connection.dataset_type, f"rest-{connection.connection_key}.json",
                                 json_dumps(mapped).encode("utf-8"), source_name=f"rest:{connection.connection_key}")
    connection.last_sync_at = datetime.now(timezone.utc)
    connection.last_sync_status = result.get("status", "unknown")
    db.commit()
    return {"connection_key": connection.connection_key, "status": connection.last_sync_status,
            "import": result, "record_path": connection.record_path,
            "mapping_fields": len(json_loads(connection.field_mapping_json)),
            "credential_source": connection.credential_env_var or None}
