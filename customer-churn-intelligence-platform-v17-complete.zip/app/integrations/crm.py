from __future__ import annotations

import os
import ipaddress
import re
import socket
from datetime import datetime, timezone
from typing import Any
from urllib.parse import quote, urlparse

import httpx


class ProviderConfigurationError(RuntimeError):
    pass


class ProviderRequestError(RuntimeError):
    def __init__(self, provider: str, status_code: int | None, category: str):
        self.provider = provider
        self.status_code = status_code
        self.category = category
        super().__init__(f"{provider} request failed ({category})")


def provider_capabilities() -> dict[str, dict[str, Any]]:
    sf_url = os.getenv("SALESFORCE_INSTANCE_URL", "").strip()
    hubspot_token = os.getenv("HUBSPOT_PRIVATE_APP_TOKEN", "").strip()
    intercom_token = os.getenv("INTERCOM_ACCESS_TOKEN", "").strip()
    return {
        "salesforce": {"configured": bool(sf_url and os.getenv("SALESFORCE_ACCESS_TOKEN")),
                       "action": "create_task", "requires_external_customer_mapping": True},
        "hubspot": {"configured": bool(hubspot_token), "action": "create_contact_associated_task",
                    "requires_external_customer_mapping": True,
                    "api_version": os.getenv("HUBSPOT_API_VERSION", "2026-09")},
        "intercom": {"configured": bool(intercom_token), "action": "create_contact_timeline_note",
                     "requires_external_customer_mapping": True,
                     "api_version": os.getenv("INTERCOM_API_VERSION", "2.17")},
    }


def _safe_json(response: httpx.Response) -> dict[str, Any]:
    try:
        payload = response.json()
        return payload if isinstance(payload, dict) else {"response_type": type(payload).__name__}
    except Exception:
        return {"response_text": response.text[:500]}


def _send(client: httpx.Client, provider: str, url: str, headers: dict[str, str], body: dict[str, Any]) -> dict[str, Any]:
    try:
        response = client.post(url, headers=headers, json=body, follow_redirects=False)
    except httpx.TimeoutException as exc:
        # The provider may have accepted the request before the client timed out. Caller must reconcile manually.
        raise ProviderRequestError(provider, None, "delivery_unknown_timeout") from exc
    except httpx.HTTPError as exc:
        raise ProviderRequestError(provider, None, "transport_error") from exc
    if 300 <= response.status_code < 400:
        # Do not accept redirects: provider tokens must never be forwarded to
        # an unvalidated Location host.
        raise ProviderRequestError(provider, response.status_code, "redirect_refused")
    if response.status_code >= 400:
        payload = _safe_json(response)
        category = str(payload.get("category") or payload.get("errorCode") or f"http_{response.status_code}")[:80]
        raise ProviderRequestError(provider, response.status_code, category)
    payload = _safe_json(response)
    external_id = payload.get("id") or payload.get("task", {}).get("id") or payload.get("data", {}).get("id")
    return {"http_status": response.status_code, "external_id": str(external_id) if external_id is not None else None,
            "response": payload}


def execute_provider_action(provider: str, *, remote_customer_id: str, title: str, body: str,
                            priority: str, client: httpx.Client | None = None) -> dict[str, Any]:
    """Create an approved CRM task/note. Secrets are read only at call time; no token is persisted."""
    if not remote_customer_id:
        raise ProviderConfigurationError("External customer identity mapping is required")
    own_client = client is None
    # Keep the ownership flag: the default outbound client must perform DNS
    # validation before connecting. Injected clients are reserved for tests or
    # explicitly controlled transports and do not perform real DNS lookups.
    client = client or httpx.Client(timeout=httpx.Timeout(20.0, connect=5.0),
                                    follow_redirects=False, trust_env=False)
    try:
        if provider == "salesforce":
            base = os.getenv("SALESFORCE_INSTANCE_URL", "").rstrip("/")
            token = os.getenv("SALESFORCE_ACCESS_TOKEN", "").strip()
            version = os.getenv("SALESFORCE_API_VERSION", "").strip()
            parsed = urlparse(base)
            host = (parsed.hostname or "").lower().rstrip(".")
            if parsed.scheme != "https" or not host or not token or not version:
                raise ProviderConfigurationError("Set HTTPS SALESFORCE_INSTANCE_URL, SALESFORCE_ACCESS_TOKEN and SALESFORCE_API_VERSION")
            if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {"", "/"}:
                raise ProviderConfigurationError("SALESFORCE_INSTANCE_URL must be an HTTPS origin without credentials, path, query or fragment")
            try:
                host_ip = ipaddress.ip_address(host)
            except ValueError:
                host_ip = None
            allowed_hosts = {x.strip().lower().rstrip(".") for x in
                             os.getenv("SALESFORCE_ALLOWED_HOSTS", "").split(",") if x.strip()}
            if (host_ip is not None and not host_ip.is_global) or not (
                host.endswith(".salesforce.com") or host in allowed_hosts
            ):
                raise ProviderConfigurationError("Salesforce instance host must be a public *.salesforce.com host or an exact SALESFORCE_ALLOWED_HOSTS entry")
            if own_client and host_ip is None:
                try:
                    addresses = {item[4][0].split("%", 1)[0]
                                 for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
                except OSError as exc:
                    raise ProviderConfigurationError("Salesforce instance hostname could not be resolved") from exc
                if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
                    raise ProviderConfigurationError("Salesforce instance hostname resolves to a non-public address")
            if not re.fullmatch(r"\d{2}\.\d", version):
                raise ProviderConfigurationError("SALESFORCE_API_VERSION must be numeric, for example 67.0")
            url = f"{base}/services/data/v{version}/sobjects/Task/"
            payload = {"Subject": title[:255], "Status": "Not Started",
                       "Priority": "High" if priority == "high" else "Normal",
                       "Description": body[:32000], "WhoId": remote_customer_id,
                       "ActivityDate": datetime.now(timezone.utc).date().isoformat()}
            headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        elif provider == "hubspot":
            token = os.getenv("HUBSPOT_PRIVATE_APP_TOKEN", "").strip()
            version = os.getenv("HUBSPOT_API_VERSION", "2026-09").strip()
            association_type = os.getenv("HUBSPOT_CONTACT_ASSOCIATION_TYPE_ID", "").strip()
            if not token or not version:
                raise ProviderConfigurationError("Set HUBSPOT_PRIVATE_APP_TOKEN and HUBSPOT_API_VERSION")
            if not association_type.isdigit():
                raise ProviderConfigurationError("Set HUBSPOT_CONTACT_ASSOCIATION_TYPE_ID from the target HubSpot portal association schema")
            payload = {"properties": {"hs_timestamp": str(int(datetime.now(timezone.utc).timestamp() * 1000)),
                                      "hs_task_body": body[:5000], "hs_task_subject": title[:255],
                                      "hs_task_status": "NOT_STARTED", "hs_task_priority": "HIGH" if priority == "high" else "MEDIUM"},
                       "associations": [{"to": {"id": remote_customer_id},
                                         "types": [{"associationCategory": "HUBSPOT_DEFINED",
                                                    "associationTypeId": int(association_type)}]}]}
            url = f"https://api.hubapi.com/crm/objects/{version}/tasks"
            headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        elif provider == "intercom":
            token = os.getenv("INTERCOM_ACCESS_TOKEN", "").strip()
            version = os.getenv("INTERCOM_API_VERSION", "2.17").strip()
            if not token or not version:
                raise ProviderConfigurationError("Set INTERCOM_ACCESS_TOKEN and INTERCOM_API_VERSION")
            payload = {"body": f"Retention follow-up task: {title}\n\n{body}"[:10000]}
            url = f"https://api.intercom.io/contacts/{quote(remote_customer_id, safe='')}/notes"
            headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json",
                       "Intercom-Version": version}
        else:
            raise ValueError("Provider must be salesforce, hubspot, or intercom")
        return _send(client, provider, url, headers, payload)
    finally:
        if own_client:
            client.close()
