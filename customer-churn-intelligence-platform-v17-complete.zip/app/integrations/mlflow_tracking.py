from __future__ import annotations

import os
from pathlib import Path
from typing import Any


def tracking_status() -> dict[str, Any]:
    uri = os.getenv("MLFLOW_TRACKING_URI", "").strip()
    if not uri:
        return {"status": "not_configured", "configured": False}
    try:
        import mlflow  # noqa: F401
    except ImportError:
        return {"status": "package_missing", "configured": True, "tracking_uri_set": True}
    return {"status": "configured", "configured": True, "tracking_uri_set": True}


def track_training_run(run_id: str, algorithm: str, parameters: dict[str, Any], metrics: dict[str, Any],
                       artifact_path: Path, dataset_fingerprint: str) -> dict[str, Any]:
    status = tracking_status()
    if status["status"] != "configured":
        return status
    import mlflow
    mlflow.set_tracking_uri(os.environ["MLFLOW_TRACKING_URI"])
    mlflow.set_experiment(os.getenv("MLFLOW_EXPERIMENT_NAME", "customer-churn-intelligence"))
    with mlflow.start_run(run_name=f"{algorithm}-{run_id[:8]}") as run:
        mlflow.log_params({"algorithm": algorithm, **{k: str(v) for k, v in parameters.items()},
                           "dataset_fingerprint": dataset_fingerprint})
        flattened = {}
        for partition in ("validation", "test"):
            for key, value in metrics.get(partition, {}).items():
                if isinstance(value, (int, float)) and value is not None:
                    flattened[f"{partition}_{key}"] = float(value)
        if flattened:
            mlflow.log_metrics(flattened)
        mlflow.set_tags({"application": "customer-churn-intelligence", "local_training_run_id": run_id,
                         "data_provenance": "must_be_reviewed_before_production"})
        mlflow.log_artifact(str(artifact_path), artifact_path="model-artifact")
        return {"status": "logged", "run_id": run.info.run_id, "experiment_id": run.info.experiment_id}
