from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from sqlalchemy.engine import make_url


@dataclass(frozen=True)
class Settings:
    app_name: str = "Churn Intelligence Platform"
    app_version: str = "1.8.0"
    environment: str = "development"
    database_url: str = "sqlite:///./data/churn.db"
    upload_dir: Path = Path("./data/uploads")
    artifact_dir: Path = Path("./artifacts")
    log_level: str = "INFO"
    session_ttl_hours: int = 12
    max_upload_mb: int = 25
    cors_origins: tuple[str, ...] = ("http://127.0.0.1:8000", "http://localhost:8000")

    @classmethod
    def from_env(cls) -> "Settings":
        env = os.getenv("APP_ENV", "development").strip().lower()
        db_url = os.getenv("DATABASE_URL", "sqlite:///./data/churn.db").strip()
        origins = tuple(x.strip() for x in os.getenv(
            "CORS_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000"
        ).split(",") if x.strip())
        settings = cls(
            app_name=os.getenv("APP_NAME", "Churn Intelligence Platform"),
            app_version=os.getenv("APP_VERSION", "1.8.0"),
            environment=env,
            database_url=db_url,
            upload_dir=Path(os.getenv("UPLOAD_DIR", "./data/uploads")),
            artifact_dir=Path(os.getenv("ARTIFACT_DIR", "./artifacts")),
            log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
            session_ttl_hours=int(os.getenv("SESSION_TTL_HOURS", "12")),
            max_upload_mb=int(os.getenv("MAX_UPLOAD_MB", "25")),
            cors_origins=origins,
        )
        settings.validate()
        return settings

    def validate(self) -> None:
        if self.environment not in {"development", "test", "staging", "production"}:
            raise ValueError("APP_ENV must be development, test, staging, or production")
        if not 1 <= self.session_ttl_hours <= 24 * 30:
            raise ValueError("SESSION_TTL_HOURS must be between 1 and 720")
        if not 1 <= self.max_upload_mb <= 500:
            raise ValueError("MAX_UPLOAD_MB must be between 1 and 500")
        try:
            url = make_url(self.database_url)
        except Exception as exc:
            raise ValueError("DATABASE_URL is malformed") from exc
        if not url.drivername:
            raise ValueError("DATABASE_URL must include a database driver")
        if self.environment in {"staging", "production"} and not os.getenv("SECRET_KEY", "").strip():
            raise ValueError("SECRET_KEY is required in staging and production")
        if self.environment == "production":
            if url.database in {None, ":memory:"}:
                raise ValueError("Production DATABASE_URL must identify a persistent database")
            if not self.cors_origins or "*" in self.cors_origins:
                raise ValueError("Production CORS_ORIGINS must be explicit; wildcard is forbidden")
            if os.getenv("ALLOW_DEMO_SEED", "false").lower() == "true":
                raise ValueError("Demo seeding is forbidden in production")


settings = Settings.from_env()
