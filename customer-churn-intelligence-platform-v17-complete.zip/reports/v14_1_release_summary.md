# Customer Churn Intelligence Platform V14.1 — verification summary

Generated: 2026-11-07
Application version: `1.4.1`

## Release result

- Strict automated tests: **115 passed, 0 failed, 0 skipped** (`python -m pytest -q -W error`).
- Local verification stages: **5/5 passed** — core, runtime, migrations, synthetic workflow and Chromium UI/API bridge.
- Local-demo profile: **14/14 PASS**. This scope excludes, rather than passes, production-only gates.
- Production acceptance: **14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance checks**.
- Shared interpreter diagnostic: one unrelated MoviePy/Pillow conflict is `NOT_APPLICABLE`, not an application acceptance failure.

## V14.1 implementation additions

1. Permission-filtered CSV/JSON exports for overview, customers, predictions, models, retention, data quality, imports, cohorts, survival and administrator audit data. Customer exports omit email; CSV formula-like untrusted text is neutralized.
2. Administrator account listing, creation, activation/deactivation and audit-history UI/API. Deactivation revokes existing sessions permanently; reactivation requires a fresh login.
3. Descriptive model fairness review based on exact mature, uncensored customer/cutoff/horizon label joins, with group-size warnings and selection/precision/recall/FPR metrics.
4. Exact point-in-time feature snapshot retrieval by customer, cutoff and feature contract version.
5. Training-dataset readiness/leakage audit with exact label/snapshot matching, mature-horizon/event-window checks, exclusions, chronological partition sizes/class balance, per-feature missingness, repeat-customer overlap warning and stable dataset fingerprint.
6. Model training now excludes future-maturity labels, incorrect maturity windows, positive events outside the horizon, negative labels that have event dates, missing exact snapshots and malformed feature payloads.
7. Browser flow now verifies the dataset audit, Reports/export, Administration/audit, file import, Customer 360 and logout.

## Fresh evidence

- `verification.json` and `verification.md`: authoritative aggregate production acceptance.
- `verification_core.json`, `verification_runtime.json`, `verification_migrations.json`, `verification_synthetic.json`, `verification_browser.json`: independent stage evidence.
- `junit.xml`: strict regression suite details.
- `browser_bridge_e2e_evidence.json`: Chromium browser-bridge journey; 17 recorded page/flow checkpoints, 14 accessibility-smoke views and 241 visible controls checked. This is a limited semantic accessibility smoke, not full WCAG/axe certification, and the API transport is host-side rather than native browser CORS.
- `synthetic_workflow_evidence.json`: 120-customer synthetic training/scoring/retention pipeline execution. It is not a real-company accuracy result.
- `local_demo_acceptance.json`: local synthetic-demo profile only.
- `package_manifest.json`: SHA-256 hashes for the release files (manifest excludes itself to prevent recursive hashing).

## Remaining ten production gates

### Technical/runtime

1. `postgresql_runtime` — no PostgreSQL server/driver runtime was available; only offline migration/DDL compilation passed.
2. `docker_runtime` — no Docker CLI/daemon was available; Compose static validation passed.
3. `clean_virtual_environment_install` — package-index DNS/network access prevented a fresh isolated dependency install.
4. `mlops_runtime` — MLflow, Airflow and Evidently runtimes were not installed/configured.
5. `quality_and_security_toolchain` — Ruff, Bandit and pip-audit were unavailable. The supplemental first-party scanner is not a substitute.

### Company/independent-owner

6. `live_crm_provider_sandbox` — no authorized CRM tenant, OAuth grants, scopes or webhook configuration was supplied.
7. `hosted_staging_deployment` — no approved hosting account, domain, TLS certificate or deployment authorization was supplied.
8. `real_company_model_validation` — no authorized company dataset with mature churn outcomes was supplied.
9. `business_churn_policy_signoff` — churn/cancellation/pause/reactivation/censoring semantics still require company approval.
10. `independent_penetration_test` — independent assessor authorization, report, remediation and retest evidence are required.

These gates are intentionally `BLOCKED`; code changes, local synthetic data, mocks, workflow definitions and self-review cannot substitute for the missing environment or independent evidence. Several feature details in the 20-phase roadmap also remain marked `Partial`; see `docs/ROADMAP_COVERAGE.md`.

## Run locally on Windows

From PowerShell in the extracted project directory:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_local_demo.ps1
```

Then open `http://127.0.0.1:8000`. The launcher initializes the SQLite demo database, creates the first administrator interactively and seeds clearly identified synthetic records. For the technical acceptance prerequisites and owner evidence, see `docs/verification/V14_1_GATE_CLOSURE_CHECKLIST.md`.

**Release boundary:** V14.1 is locally regression-tested and suitable for a controlled synthetic-data demonstration. It is not yet approved for staging or production.
