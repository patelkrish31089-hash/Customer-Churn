# Customer Churn Intelligence Platform V17 — verification summary

Generated 2026-11-07 from the V17 source tree.

## Results

- Strict regression: **147 passed, 0 failed, 0 skipped** (`python -m pytest -q -W error`).
- Production acceptance: **16 PASS / 0 FAIL / 10 BLOCKED** across **26 unique checks**.
- Local-demo acceptance: **15/15 PASS** for the declared local SQLite/demo scope. The ten production-only gates are excluded, not passed.
- Product integration: **PASS** for the Feature Store and atomic bulk data-quality review API workflow.
- Package manifest: 184 files with per-file SHA-256 values (manifest excludes itself).

## V17 product updates

- Feature Store page: model-contract-derived registry, snapshot coverage and missingness, as-of online retrieval, per-customer history, CSV export and queued materialization.
- Data Quality bulk review: accept-risk and false-positive decisions, complete-selection validation before mutation, all-or-nothing persistence and one audit event per finding.
- New product integration check included in local, PowerShell and GitHub Actions workflows.
- Updated browser bridge includes the Feature Store view.

## Local acceptance stages

| Stage | Passing checks |
|---|---:|
| Core (compile/import/JS/strict tests/secret heuristic/AST smoke) | 6 |
| Runtime (HTTP/auth, concurrency, SQLite worker queue) | 3 |
| Migrations/deployment/CI contract | 4 |
| Feature Store + bulk-quality API workflow | 1 |
| Synthetic ML workflow | 1 |
| Chromium UI/API bridge | 1 |
| **Total** | **16** |

One shared-interpreter `pip check` diagnostic is marked NOT_APPLICABLE and is excluded from the production acceptance total. A fresh isolated dependency install remains a blocked production gate.

## Ten production gates still blocked

### Technical runtime/toolchain

1. **PostgreSQL runtime** — no PostgreSQL server/driver was available; SQLite and offline PostgreSQL DDL checks are not equivalent.
2. **Docker runtime** — no Docker CLI/daemon was available; Compose static validation is not container execution.
3. **Clean isolated install** — package-index DNS was unavailable, so a disposable full dependency installation could not complete.
4. **MLOps runtime** — MLflow, Evidently and Airflow services/runtime were not installed or configured.
5. **Quality/security toolchain** — Ruff, Bandit and pip-audit were unavailable. The first-party heuristic smoke does not replace them.

### Company/independent evidence

6. **Live CRM sandbox** — requires an authorized provider tenant, scopes and credentials.
7. **Hosted staging** — requires a company-controlled host/project, domain/TLS, secrets, backups and rollback proof.
8. **Real-company model validation** — requires authorized records with mature outcomes and a frozen holdout; synthetic data is not evidence.
9. **Business churn-policy sign-off** — cancellation, pause, grace-period, reactivation and censoring semantics need written owner approval.
10. **Independent penetration test** — requires an authorized independent assessor, report, remediation and retest.

These ten items are not application code defects that can be fixed by inventing evidence. The precise acceptance steps and owners are in `docs/verification/V17_GATE_CLOSURE_CHECKLIST.md`.

## Important evidence boundaries

- Feature Store and bulk review product integration was exercised against isolated SQLite. It does not prove PostgreSQL transaction/locking behavior at production scale.
- Synthetic churn training/approval/scoring/retention proves workflow execution only; no real-company accuracy or retention-lift claim is made.
- Chromium semantic accessibility smoke is not full WCAG/axe certification.
- Local-demo PASS means all 15 checks in that specific local profile passed; it does not mean the ten production gates passed.
