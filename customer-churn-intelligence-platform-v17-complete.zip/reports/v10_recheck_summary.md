# V10 independent recheck — 2026-11-07

## Outcome

The supplied V10 archive was extracted and its five local verification stages were executed again from the project root. The aggregate report was regenerated from those stage results.

**14 PASS / 0 FAIL / 10 BLOCKED across 24 unique acceptance gates.** One unrelated shared-host `pip check` diagnostic is `NOT_APPLICABLE` and is not counted as an acceptance gate.

The strict regression suite completed **87 passed, 0 failed, 0 errors, 0 skipped**, with warnings treated as errors (`python -m pytest -q -W error --junitxml reports/junit.xml`). Python compilation, application import and JavaScript syntax checks passed.

## Passed locally

| Area | Evidence | Result |
|---|---|---|
| Core checks | `verification_core.json`, `junit.xml`, `source_security_smoke.json` | 6 PASS; one unrelated host diagnostic N/A |
| Local HTTP runtime and concurrency | `verification_runtime.json`, `runtime_http_evidence.json`, `performance_smoke.json` | 2 PASS |
| Migrations and deployment configuration | `verification_migrations.json`, `migration_lifecycle_evidence.json`, `postgresql_offline_migration_evidence.json`, `deployment_compose_check.json`, `ci_workflow_contract_evidence.json` | 4 PASS |
| Synthetic end-to-end workflow | `verification_synthetic.json`, `synthetic_workflow_evidence.json` | 1 PASS |
| Chromium UI/API bridge | `verification_browser.json`, `browser_bridge_e2e_evidence.json` | 1 PASS |

PostgreSQL **offline SQL generation** passed; this is not a live PostgreSQL server test. Compose **static validation** passed; this is not a Docker runtime test. Synthetic model execution is not real-company accuracy evidence. Browser evidence uses a host-side API bridge; native browser-origin HTTP/CORS and axe-core/full WCAG execution remain outside this local run.

## Ten blocked gates — required closure action

| Gate | Why it remains blocked | What must happen to close it |
|---|---|---|
| PostgreSQL runtime | No PostgreSQL server binaries/service and no `psycopg` runtime driver are available in this execution environment. | Run the `backend-postgresql` hosted CI job; retain migration round-trip, CRUD, constraints, numeric precision, rollback and authenticated API evidence against PostgreSQL 16. |
| Docker runtime | Docker CLI/daemon are unavailable here. | Run `docker-compose-runtime` on a Docker-enabled runner; retain build, health, restart-persistence, backup and restore evidence. |
| Clean isolated install | Package-index DNS/network access prevented dependency installation into a fresh virtual environment. | Run the clean-install steps on a supported Python 3.11/3.12 runner with package-index access; record install log, `pip check` and regression results. |
| MLOps runtime | MLflow, Evidently and Airflow are not installed/configured in this workspace. | Run the `mlops-adapter-runtime` and `airflow-dag-runtime` CI jobs; retain MLflow read-back, Evidently report and Airflow DAG/batch evidence. |
| Quality/security toolchain | Ruff, Bandit and pip-audit are unavailable locally. The passing AST scanner is supplemental and does not replace them. | Run Ruff, Bandit and pip-audit in the hosted CI job; review and resolve or formally accept findings. |
| Live CRM provider sandbox | No authorized Salesforce/HubSpot/Intercom sandbox, OAuth grants, scopes or webhook credentials were supplied. | An authorized administrator configures secrets in the protected CI secret store; execute provider create/read-back/reconciliation and webhook checks. |
| Hosted staging deployment | No hosting account, domain/TLS, secret store or deployment authorization was supplied. | The deployment owner provisions and authorizes staging; deploy the tested release and capture readiness, RBAC, migration, backup/restore and rollback evidence. |
| Real-company model validation | No authorized company dataset with sufficiently mature churn outcomes was supplied. | The data owner provides governed longitudinal data; run a leakage-safe chronological holdout and review calibration, subgroup performance, thresholds and explanation stability. |
| Business churn-policy sign-off | Cancellation, reactivation, pause, grace-period, involuntary churn and censoring semantics need business approval. | Product/business owner approves and versions the target/label policy. Do not infer policy from synthetic data. |
| Independent penetration test | No independently authorized assessor/report/retest evidence was supplied. | Commission an independent assessor under written scope and authorization; remediate findings and obtain retest evidence. |

## Hosted jobs that can close technical/tooling blockers

The repository includes `.github/workflows/ci.yml` with jobs for PostgreSQL, Docker Compose, browser/accessibility, MLflow/Evidently, and Airflow. Push this project to the authorized private Git repository and run **Actions → full-platform-acceptance → Run workflow**. A successful workflow and reviewed artifacts can close the applicable technical/tooling gates. The existence or static validation of the workflow alone does not close them.

CRM credentials, company data, business policy approval, a staging account and independent penetration-test evidence must still be supplied by the authorized company owners/assessor. They cannot be created or truthfully self-certified by modifying application code.

## Commands executed

```bash
python scripts/verify.py --stage core
python scripts/verify.py --stage runtime
python scripts/verify.py --stage migrations
python scripts/verify.py --stage synthetic
python scripts/verify.py --stage browser
python scripts/verify.py --stage report
```

The authoritative machine-readable and Markdown summaries are `reports/verification.json` and `reports/verification.md`. Gate status has not been changed from `BLOCKED` without the required evidence.
