INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
INFO  [alembic.runtime.migration] Generating static SQL
INFO  [alembic.runtime.migration] Generating static SQL
INFO  [alembic.runtime.migration] Will assume transactional DDL.
INFO  [alembic.runtime.migration] Will assume transactional DDL.
BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

INFO  [alembic.runtime.migration] Running upgrade  -> 97bdfcc071ca, initial schema
INFO  [alembic.runtime.migration] Running upgrade  -> 97bdfcc071ca, initial schema
-- Running upgrade  -> 97bdfcc071ca

CREATE TABLE customers (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    name VARCHAR(200) NOT NULL, 
    email VARCHAR(254), 
    segment VARCHAR(100), 
    country VARCHAR(80), 
    acquisition_date TIMESTAMP WITH TIME ZONE, 
    consent_to_contact BOOLEAN NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_customers_email ON customers (email);

CREATE UNIQUE INDEX ix_customers_external_id ON customers (external_id);

CREATE TABLE drift_reports (
    id SERIAL NOT NULL, 
    release_id VARCHAR(36) NOT NULL, 
    metric_name VARCHAR(80) NOT NULL, 
    metric_value FLOAT NOT NULL, 
    threshold FLOAT NOT NULL, 
    status VARCHAR(24) NOT NULL, 
    details_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_drift_reports_release_id ON drift_reports (release_id);

CREATE TABLE import_batches (
    id SERIAL NOT NULL, 
    dataset_type VARCHAR(32) NOT NULL, 
    filename VARCHAR(255) NOT NULL, 
    sha256 VARCHAR(64) NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    records_received INTEGER NOT NULL, 
    records_accepted INTEGER NOT NULL, 
    records_rejected INTEGER NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    completed_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_import_batches_sha256 ON import_batches (sha256);

CREATE TABLE training_runs (
    id SERIAL NOT NULL, 
    run_id VARCHAR(36) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    algorithm VARCHAR(80) NOT NULL, 
    dataset_fingerprint VARCHAR(64) NOT NULL, 
    feature_version VARCHAR(32) NOT NULL, 
    metrics_json TEXT NOT NULL, 
    artifact_path VARCHAR(500), 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE UNIQUE INDEX ix_training_runs_run_id ON training_runs (run_id);

CREATE TABLE users (
    id SERIAL NOT NULL, 
    username VARCHAR(80) NOT NULL, 
    password_hash VARCHAR(255) NOT NULL, 
    role VARCHAR(32) NOT NULL, 
    is_active BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE UNIQUE INDEX ix_users_username ON users (username);

CREATE TABLE audit_events (
    id SERIAL NOT NULL, 
    actor_id INTEGER, 
    action VARCHAR(100) NOT NULL, 
    entity_type VARCHAR(80) NOT NULL, 
    entity_id VARCHAR(120) NOT NULL, 
    correlation_id VARCHAR(64), 
    metadata_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(actor_id) REFERENCES users (id)
);

CREATE INDEX ix_audit_events_action ON audit_events (action);

CREATE TABLE data_issues (
    id SERIAL NOT NULL, 
    batch_id INTEGER NOT NULL, 
    row_number INTEGER NOT NULL, 
    issue_code VARCHAR(80) NOT NULL, 
    message VARCHAR(500) NOT NULL, 
    raw_row TEXT NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(batch_id) REFERENCES import_batches (id) ON DELETE CASCADE
);

CREATE INDEX ix_data_issues_batch_id ON data_issues (batch_id);

CREATE TABLE feature_snapshots (
    id SERIAL NOT NULL, 
    customer_id INTEGER NOT NULL, 
    cutoff_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    feature_version VARCHAR(32) NOT NULL, 
    features_json TEXT NOT NULL, 
    source_fingerprint VARCHAR(64) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    CONSTRAINT uq_feature_customer_cutoff_version UNIQUE (customer_id, cutoff_date, feature_version)
);

CREATE INDEX ix_feature_snapshots_customer_id ON feature_snapshots (customer_id);

CREATE INDEX ix_feature_snapshots_cutoff_date ON feature_snapshots (cutoff_date);

CREATE TABLE model_releases (
    id SERIAL NOT NULL, 
    release_id VARCHAR(36) NOT NULL, 
    training_run_id VARCHAR(36) NOT NULL, 
    model_name VARCHAR(100) NOT NULL, 
    artifact_path VARCHAR(500) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    feature_version VARCHAR(32) NOT NULL, 
    horizon_days INTEGER NOT NULL, 
    metrics_json TEXT NOT NULL, 
    approved_by INTEGER, 
    approved_at TIMESTAMP WITH TIME ZONE, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(approved_by) REFERENCES users (id)
);

CREATE UNIQUE INDEX ix_model_releases_release_id ON model_releases (release_id);

CREATE TABLE session_tokens (
    id SERIAL NOT NULL, 
    user_id INTEGER NOT NULL, 
    token_hash VARCHAR(64) NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    revoked BOOLEAN NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX ix_session_tokens_token_hash ON session_tokens (token_hash);

CREATE INDEX ix_session_tokens_user_id ON session_tokens (user_id);

CREATE TABLE subscriptions (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    customer_id INTEGER NOT NULL, 
    plan VARCHAR(120) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    start_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    end_date TIMESTAMP WITH TIME ZONE, 
    cancellation_date TIMESTAMP WITH TIME ZONE, 
    churn_reason VARCHAR(80), 
    mrr NUMERIC(18, 2) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE
);

CREATE INDEX ix_subscription_customer_status ON subscriptions (customer_id, status);

CREATE INDEX ix_subscriptions_customer_id ON subscriptions (customer_id);

CREATE UNIQUE INDEX ix_subscriptions_external_id ON subscriptions (external_id);

CREATE TABLE support_tickets (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    customer_id INTEGER NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    resolved_at TIMESTAMP WITH TIME ZONE, 
    status VARCHAR(32) NOT NULL, 
    priority VARCHAR(32) NOT NULL, 
    category VARCHAR(100), 
    source_name VARCHAR(120) NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    CONSTRAINT uq_ticket_source_external UNIQUE (source_name, external_id)
);

CREATE INDEX ix_support_tickets_created_at ON support_tickets (created_at);

CREATE INDEX ix_support_tickets_customer_id ON support_tickets (customer_id);

CREATE INDEX ix_support_tickets_external_id ON support_tickets (external_id);

CREATE TABLE churn_labels (
    id SERIAL NOT NULL, 
    customer_id INTEGER NOT NULL, 
    entity_scope VARCHAR(24) NOT NULL, 
    entity_ref VARCHAR(120) NOT NULL, 
    subscription_id INTEGER, 
    cutoff_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    horizon_days INTEGER NOT NULL, 
    churn_30d INTEGER, 
    churn_type VARCHAR(32) NOT NULL, 
    event_date TIMESTAMP WITH TIME ZONE, 
    maturity_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    is_censored BOOLEAN NOT NULL, 
    policy_version VARCHAR(32) NOT NULL, 
    evidence TEXT NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL, 
    CONSTRAINT uq_label_entity_cutoff_horizon UNIQUE (entity_scope, entity_ref, cutoff_date, horizon_days)
);

CREATE INDEX ix_churn_labels_customer_id ON churn_labels (customer_id);

CREATE INDEX ix_churn_labels_cutoff_date ON churn_labels (cutoff_date);

CREATE INDEX ix_churn_labels_entity_ref ON churn_labels (entity_ref);

CREATE INDEX ix_churn_labels_entity_scope ON churn_labels (entity_scope);

CREATE TABLE invoices (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    customer_id INTEGER NOT NULL, 
    subscription_id INTEGER, 
    invoice_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    due_date TIMESTAMP WITH TIME ZONE, 
    amount NUMERIC(18, 2) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL, 
    CONSTRAINT uq_invoice_source_external UNIQUE (source_name, external_id)
);

CREATE INDEX ix_invoices_customer_id ON invoices (customer_id);

CREATE INDEX ix_invoices_external_id ON invoices (external_id);

CREATE TABLE predictions (
    id SERIAL NOT NULL, 
    customer_id INTEGER NOT NULL, 
    release_id VARCHAR(36) NOT NULL, 
    cutoff_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    horizon_days INTEGER NOT NULL, 
    probability FLOAT NOT NULL, 
    risk_band VARCHAR(20) NOT NULL, 
    feature_snapshot_id INTEGER NOT NULL, 
    explanation_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(feature_snapshot_id) REFERENCES feature_snapshots (id), 
    CONSTRAINT uq_prediction_idempotency UNIQUE (customer_id, release_id, cutoff_date, horizon_days)
);

CREATE INDEX ix_predictions_customer_id ON predictions (customer_id);

CREATE INDEX ix_predictions_release_id ON predictions (release_id);

CREATE TABLE usage_events (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    customer_id INTEGER NOT NULL, 
    subscription_id INTEGER, 
    event_time TIMESTAMP WITH TIME ZONE NOT NULL, 
    event_type VARCHAR(100) NOT NULL, 
    quantity FLOAT NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL, 
    CONSTRAINT uq_usage_source_external UNIQUE (source_name, external_id)
);

CREATE INDEX ix_usage_events_customer_id ON usage_events (customer_id);

CREATE INDEX ix_usage_events_event_time ON usage_events (event_time);

CREATE INDEX ix_usage_events_external_id ON usage_events (external_id);

CREATE TABLE payments (
    id SERIAL NOT NULL, 
    external_id VARCHAR(120) NOT NULL, 
    customer_id INTEGER NOT NULL, 
    invoice_id INTEGER, 
    payment_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    amount NUMERIC(18, 2) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    source_name VARCHAR(120) NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(invoice_id) REFERENCES invoices (id) ON DELETE SET NULL, 
    CONSTRAINT uq_payment_source_external UNIQUE (source_name, external_id)
);

CREATE INDEX ix_payments_customer_id ON payments (customer_id);

CREATE INDEX ix_payments_external_id ON payments (external_id);

CREATE TABLE retention_recommendations (
    id SERIAL NOT NULL, 
    customer_id INTEGER NOT NULL, 
    prediction_id INTEGER, 
    category VARCHAR(80) NOT NULL, 
    title VARCHAR(200) NOT NULL, 
    rationale TEXT NOT NULL, 
    evidence_json TEXT NOT NULL, 
    priority VARCHAR(20) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    outcome_json TEXT NOT NULL, 
    approved_by INTEGER, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(approved_by) REFERENCES users (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(prediction_id) REFERENCES predictions (id)
);

CREATE INDEX ix_retention_recommendations_customer_id ON retention_recommendations (customer_id);

CREATE TABLE crm_actions (
    id SERIAL NOT NULL, 
    recommendation_id INTEGER NOT NULL, 
    provider VARCHAR(40) NOT NULL, 
    action_type VARCHAR(80) NOT NULL, 
    idempotency_key VARCHAR(100) NOT NULL, 
    status VARCHAR(32) NOT NULL, 
    external_reference VARCHAR(120), 
    result_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(recommendation_id) REFERENCES retention_recommendations (id), 
    UNIQUE (idempotency_key)
);

CREATE INDEX ix_crm_actions_recommendation_id ON crm_actions (recommendation_id);

INSERT INTO alembic_version (version_num) VALUES ('97bdfcc071ca') RETURNING alembic_version.version_num;

INFO  [alembic.runtime.migration] Running upgrade 97bdfcc071ca -> 378650450249, advanced data quality, batches, CRM identities and retention governance
INFO  [alembic.runtime.migration] Running upgrade 97bdfcc071ca -> 378650450249, advanced data quality, batches, CRM identities and retention governance
-- Running upgrade 97bdfcc071ca -> 378650450249

CREATE TABLE data_quality_runs (
    id SERIAL NOT NULL, 
    run_id VARCHAR(36) NOT NULL, 
    scope VARCHAR(32) NOT NULL, 
    rule_version VARCHAR(32) NOT NULL, 
    records_scanned INTEGER NOT NULL, 
    finding_count INTEGER NOT NULL, 
    quality_score FLOAT NOT NULL, 
    summary_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE UNIQUE INDEX ix_data_quality_runs_run_id ON data_quality_runs (run_id);

CREATE TABLE external_identities (
    id SERIAL NOT NULL, 
    provider VARCHAR(40) NOT NULL, 
    entity_type VARCHAR(40) NOT NULL, 
    local_entity_id INTEGER NOT NULL, 
    remote_entity_id VARCHAR(160) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT uq_external_identity_local UNIQUE (provider, entity_type, local_entity_id), 
    CONSTRAINT uq_external_identity_remote UNIQUE (provider, entity_type, remote_entity_id)
);

CREATE INDEX ix_external_identities_local_entity_id ON external_identities (local_entity_id);

CREATE INDEX ix_external_identities_provider ON external_identities (provider);

CREATE INDEX ix_external_identities_remote_entity_id ON external_identities (remote_entity_id);

CREATE TABLE data_quality_findings (
    id SERIAL NOT NULL, 
    run_id VARCHAR(36) NOT NULL, 
    entity_type VARCHAR(40) NOT NULL, 
    entity_id INTEGER NOT NULL, 
    field_name VARCHAR(80) NOT NULL, 
    rule_code VARCHAR(100) NOT NULL, 
    severity VARCHAR(20) NOT NULL, 
    status VARCHAR(24) NOT NULL, 
    message VARCHAR(500) NOT NULL, 
    observed_value TEXT, 
    details_json TEXT NOT NULL, 
    reviewer_id INTEGER, 
    review_note VARCHAR(500), 
    reviewed_at TIMESTAMP WITH TIME ZONE, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(reviewer_id) REFERENCES users (id), 
    FOREIGN KEY(run_id) REFERENCES data_quality_runs (run_id) ON DELETE CASCADE
);

CREATE INDEX ix_data_quality_findings_entity_id ON data_quality_findings (entity_id);

CREATE INDEX ix_data_quality_findings_entity_type ON data_quality_findings (entity_type);

CREATE INDEX ix_data_quality_findings_rule_code ON data_quality_findings (rule_code);

CREATE INDEX ix_data_quality_findings_run_id ON data_quality_findings (run_id);

CREATE INDEX ix_data_quality_findings_status ON data_quality_findings (status);

CREATE TABLE retention_experiments (
    id SERIAL NOT NULL, 
    experiment_key VARCHAR(80) NOT NULL, 
    name VARCHAR(160) NOT NULL, 
    hypothesis TEXT NOT NULL, 
    allocation_treatment_pct INTEGER NOT NULL, 
    followup_days INTEGER NOT NULL, 
    status VARCHAR(24) NOT NULL, 
    created_by INTEGER, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    started_at TIMESTAMP WITH TIME ZONE, 
    ended_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES users (id)
);

CREATE UNIQUE INDEX ix_retention_experiments_experiment_key ON retention_experiments (experiment_key);

CREATE INDEX ix_retention_experiments_status ON retention_experiments (status);

CREATE TABLE retention_playbooks (
    id SERIAL NOT NULL, 
    playbook_key VARCHAR(80) NOT NULL, 
    version VARCHAR(32) NOT NULL, 
    enabled BOOLEAN NOT NULL, 
    policy_json TEXT NOT NULL, 
    created_by INTEGER, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES users (id), 
    CONSTRAINT uq_playbook_key_version UNIQUE (playbook_key, version)
);

CREATE INDEX ix_retention_playbooks_playbook_key ON retention_playbooks (playbook_key);

CREATE TABLE prediction_batches (
    id SERIAL NOT NULL, 
    batch_id VARCHAR(36) NOT NULL, 
    idempotency_key VARCHAR(120) NOT NULL, 
    release_id VARCHAR(36) NOT NULL, 
    cutoff_date TIMESTAMP WITH TIME ZONE NOT NULL, 
    status VARCHAR(24) NOT NULL, 
    requested_count INTEGER NOT NULL, 
    succeeded_count INTEGER NOT NULL, 
    failed_count INTEGER NOT NULL, 
    results_json TEXT NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    completed_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id), 
    FOREIGN KEY(release_id) REFERENCES model_releases (release_id)
);

CREATE UNIQUE INDEX ix_prediction_batches_batch_id ON prediction_batches (batch_id);

CREATE UNIQUE INDEX ix_prediction_batches_idempotency_key ON prediction_batches (idempotency_key);

CREATE INDEX ix_prediction_batches_release_id ON prediction_batches (release_id);

CREATE INDEX ix_prediction_batches_status ON prediction_batches (status);

CREATE TABLE retention_assignments (
    id SERIAL NOT NULL, 
    recommendation_id INTEGER NOT NULL, 
    assignee_id INTEGER NOT NULL, 
    due_at TIMESTAMP WITH TIME ZONE, 
    status VARCHAR(24) NOT NULL, 
    notes VARCHAR(500), 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(assignee_id) REFERENCES users (id), 
    FOREIGN KEY(recommendation_id) REFERENCES retention_recommendations (id) ON DELETE CASCADE, 
    CONSTRAINT uq_retention_assignment_recommendation UNIQUE (recommendation_id)
);

CREATE INDEX ix_retention_assignments_assignee_id ON retention_assignments (assignee_id);

CREATE INDEX ix_retention_assignments_recommendation_id ON retention_assignments (recommendation_id);

CREATE TABLE retention_experiment_assignments (
    id SERIAL NOT NULL, 
    experiment_id INTEGER NOT NULL, 
    customer_id INTEGER NOT NULL, 
    recommendation_id INTEGER, 
    arm VARCHAR(16) NOT NULL, 
    outcome VARCHAR(32), 
    outcome_at TIMESTAMP WITH TIME ZONE, 
    assigned_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
    FOREIGN KEY(experiment_id) REFERENCES retention_experiments (id) ON DELETE CASCADE, 
    FOREIGN KEY(recommendation_id) REFERENCES retention_recommendations (id) ON DELETE SET NULL, 
    CONSTRAINT uq_experiment_customer UNIQUE (experiment_id, customer_id)
);

CREATE INDEX ix_retention_experiment_assignments_customer_id ON retention_experiment_assignments (customer_id);

CREATE INDEX ix_retention_experiment_assignments_experiment_id ON retention_experiment_assignments (experiment_id);

UPDATE alembic_version SET version_num='378650450249' WHERE alembic_version.version_num = '97bdfcc071ca';

INFO  [alembic.runtime.migration] Running upgrade 378650450249 -> e561c6756edf, quality rules and external data sources
INFO  [alembic.runtime.migration] Running upgrade 378650450249 -> e561c6756edf, quality rules and external data sources
-- Running upgrade 378650450249 -> e561c6756edf

CREATE TABLE data_quality_rules (
    id SERIAL NOT NULL, 
    rule_code VARCHAR(100) NOT NULL, 
    enabled BOOLEAN NOT NULL, 
    severity VARCHAR(20) NOT NULL, 
    parameters_json TEXT NOT NULL, 
    updated_by INTEGER, 
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(updated_by) REFERENCES users (id)
);

CREATE UNIQUE INDEX ix_data_quality_rules_rule_code ON data_quality_rules (rule_code);

CREATE TABLE data_source_connections (
    id SERIAL NOT NULL, 
    connection_key VARCHAR(80) NOT NULL, 
    name VARCHAR(160) NOT NULL, 
    dataset_type VARCHAR(32) NOT NULL, 
    endpoint_url VARCHAR(1000) NOT NULL, 
    credential_env_var VARCHAR(120), 
    record_path VARCHAR(300), 
    field_mapping_json TEXT NOT NULL, 
    enabled BOOLEAN NOT NULL, 
    last_sync_at TIMESTAMP WITH TIME ZONE, 
    last_sync_status VARCHAR(40), 
    created_by INTEGER, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES users (id)
);

CREATE UNIQUE INDEX ix_data_source_connections_connection_key ON data_source_connections (connection_key);

UPDATE alembic_version SET version_num='e561c6756edf' WHERE alembic_version.version_num = '378650450249';

INFO  [alembic.runtime.migration] Running upgrade e561c6756edf -> 20261107_jobs, durable background jobs and worker leases
INFO  [alembic.runtime.migration] Running upgrade e561c6756edf -> 20261107_jobs, durable background jobs and worker leases
-- Running upgrade e561c6756edf -> 20261107_jobs

CREATE TABLE background_jobs (
    id SERIAL NOT NULL, 
    job_type VARCHAR(48) NOT NULL, 
    status VARCHAR(24) NOT NULL, 
    payload_json TEXT NOT NULL, 
    payload_sha256 VARCHAR(64) NOT NULL, 
    idempotency_key VARCHAR(120) NOT NULL, 
    created_by INTEGER, 
    priority INTEGER NOT NULL, 
    attempts INTEGER NOT NULL, 
    max_attempts INTEGER NOT NULL, 
    available_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    locked_by VARCHAR(120), 
    locked_until TIMESTAMP WITH TIME ZONE, 
    progress_pct INTEGER NOT NULL, 
    progress_message VARCHAR(300), 
    result_json TEXT NOT NULL, 
    error_message TEXT, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    started_at TIMESTAMP WITH TIME ZONE, 
    finished_at TIMESTAMP WITH TIME ZONE, 
    PRIMARY KEY (id), 
    CONSTRAINT uq_background_jobs_idempotency_key UNIQUE (idempotency_key), 
    FOREIGN KEY(created_by) REFERENCES users (id) ON DELETE SET NULL
);

CREATE INDEX ix_background_jobs_job_type ON background_jobs (job_type);

CREATE INDEX ix_background_jobs_status ON background_jobs (status);

CREATE INDEX ix_background_jobs_available_at ON background_jobs (available_at);

CREATE INDEX ix_background_jobs_created_by ON background_jobs (created_by);

CREATE INDEX ix_background_jobs_status_available ON background_jobs (status, available_at);

CREATE INDEX ix_background_jobs_created_by_created ON background_jobs (created_by, created_at);

UPDATE alembic_version SET version_num='20261107_jobs' WHERE alembic_version.version_num = 'e561c6756edf';

COMMIT;

