# Verification report

Generated: 2026-11-07T10:36:16.493980+00:00

**Result: 16 passed / 0 failed / 10 blocked / 26 unique acceptance checks.**
**Not-applicable environment diagnostics: 1.**

Blocker counts are deduplicated by acceptance gate. Missing tools appear once in the gate they affect; they are also listed in the tool inventory below.

| Check | Status | Exit code | Duration |
|---|---:|---:|---:|
| python_compile | PASS | 0 | 0.717s |
| application_import | PASS | 0 | 2.323s |
| frontend_javascript_syntax | PASS | 0 | 0.065s |
| pytest_regression_warnings_as_errors | PASS | 0 | 30.222s |
| static_secret_pattern_scan | PASS | 0 | —s |
| first_party_ast_security_smoke | PASS | 0 | 0.917s |
| runtime_http_startup_auth_shutdown | PASS | 0 | 6.335s |
| http_concurrency_smoke | PASS | 0 | 6.391s |
| sqlite_background_worker_queue_end_to_end | PASS | 0 | 3.326s |
| sqlite_migration_upgrade_downgrade_reupgrade | PASS | 0 | 4.989s |
| postgresql_offline_migration_compile | PASS | 0 | 1.919s |
| deployment_compose_static_validation | PASS | 0 | 0.766s |
| ci_workflow_acceptance_contract | PASS | 0 | 0.766s |
| feature_store_and_quality_review_api_end_to_end | PASS | 0 | 2.521s |
| synthetic_end_to_end_training_prediction_retention | PASS | 0 | 4.824s |
| browser_e2e_and_semantic_accessibility_smoke | PASS | 0 | 9.768s |
| live_crm_provider_sandbox | BLOCKED | None | —s |
| hosted_staging_deployment | BLOCKED | None | —s |
| real_company_model_validation | BLOCKED | None | —s |
| independent_penetration_test | BLOCKED | None | —s |
| business_churn_policy_signoff | BLOCKED | None | —s |
| postgresql_runtime | BLOCKED | None | —s |
| docker_runtime | BLOCKED | None | —s |
| clean_virtual_environment_install | BLOCKED | None | —s |
| mlops_runtime | BLOCKED | None | —s |
| quality_and_security_toolchain | BLOCKED | None | —s |

## Environment diagnostics

- **host_environment_pip_check — NOT_APPLICABLE:** Excluded from application acceptance totals. The clean-install production gate remains blocked until package-index access and an isolated install are available.

## Tool inventory (informational; not additional blocker rows)

| Tool | Availability |
|---|---|
| mlflow | not_installed |
| airflow | not_installed |
| evidently | not_installed |
| pip_audit | not_installed |
| playwright | installed |
| shap | installed |
| ruff | not_installed |
| xgboost | installed |
| lightgbm | installed |
| openpyxl | installed |
| psycopg | not_installed |
| yaml | installed |
| bandit | not_installed |
| docker_cli | not_installed |
| postgres_server_tools | not_installed |

## Host environment inventory

A read-only capability inventory (including browser management policy and tool availability) is saved in `reports/host_environment_inventory.json`. It records credential presence only, never secret values.

## External and production boundaries

A blocked gate means the required environment, external authorization, data, tool or independent evidence was unavailable in this run. It is not silently converted to PASS.

Synthetic model metrics are pipeline-execution evidence only, not real-world performance or causal retention evidence.

## Reproduction

Run `python scripts/verify.py --stage core`, then `runtime`, `migrations`, `product`, `synthetic`, `browser`, and finally `report`.
