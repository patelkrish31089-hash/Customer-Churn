# V12 fresh verification summary

Generated: 2026-11-07T06:48:18.054735+00:00

## Verified in this workspace

**98 automated tests passed; 0 failed**, with warnings treated as errors.

| Stage | Passed | Failed | Blocked | Not applicable |
|---|---:|---:|---:|---:|
| core | 6 | 0 | 0 | 1 |
| runtime | 2 | 0 | 0 | 0 |
| migrations | 4 | 0 | 0 | 0 |
| synthetic | 1 | 0 | 0 | 0 |
| browser | 1 | 0 | 0 | 0 |

**Acceptance gates: 14 PASS / 0 FAIL / 10 BLOCKED across 24 unique gates.**

The shared interpreter reports an unrelated MoviePy/Pillow conflict as a not-applicable host diagnostic; MoviePy is not a project dependency.

## V12 changes

- Added `scripts/run_acceptance.ps1` for Windows-local acceptance. It can run isolated install, strict tests, local stages, quality/security checks and optional native-browser/axe, MLflow/Evidently, Docker and PostgreSQL checks.
- Added `scripts/merge_local_evidence.py` to validate actual machine evidence and reviewer attribution before closing technical gates.
- Local closure reports are tied to a SHA-256 source/config tree digest and evidence-file hashes. Changing source/config or evidence invalidates the review.
- Updated `scripts/verify.py` to distinguish `reviewed_local` from `hosted_ci` evidence.
- Added tests for partial evidence, full evidence, source/evidence-change invalidation and preserving company approval gates.

## Remaining ten blocked gates

| Gate | Reason it remains blocked |
|---|---|
| `live_crm_provider_sandbox` | No authorized CRM sandbox accounts, OAuth grants, scopes or webhook secrets were supplied. |
| `hosted_staging_deployment` | No hosting account, domain, TLS certificate or deployment authorization was supplied. |
| `real_company_model_validation` | No authorized company dataset with mature churn outcomes was supplied. |
| `independent_penetration_test` | An independent assessor and test authorization/evidence are required. |
| `business_churn_policy_signoff` | The company must approve cancellation, reactivation, pause, grace-period and censoring semantics. |
| `postgresql_runtime` | No PostgreSQL server/driver runtime is available; PostgreSQL offline DDL compilation passed. Missing tools: psycopg, postgres_server_tools |
| `docker_runtime` | No Docker daemon/CLI is available; Compose static validation passed. Missing tools: docker_cli |
| `clean_virtual_environment_install` | Package-index DNS/network access is unavailable, preventing a fresh dependency install in an isolated environment. |
| `mlops_runtime` | MLflow tracking, Airflow scheduling and Evidently runtime services are not installed/configured. Missing tools: mlflow, airflow, evidently |
| `quality_and_security_toolchain` | Ruff, pip-audit and Bandit are not installed in this workspace; compile/tests and the limited secret-pattern scan are not substitutes for these tools. Missing tools: pip_audit, bandit, ruff |

## Work not executed here

- Windows PowerShell runner end-to-end execution (PowerShell is unavailable in this workspace).
- Fresh isolated dependency installation (package-index DNS/network access is unavailable).
- Ruff, Bandit and pip-audit (not installed; package-index access is unavailable).
- Live PostgreSQL runtime (server/driver unavailable) and Docker Compose runtime (Docker CLI/daemon unavailable).
- MLflow, Evidently and Airflow runtime (optional stack unavailable).
- Remote GitHub Actions execution (no authorized repository credentials or remote run evidence).
- Live CRM, staging, real-company data, business-policy approval and independent penetration test.

**Release boundary:** This package has a verified local test suite and synthetic workflow. It is not production-approved; external gates remain open until their specific evidence is supplied.
