# Customer Churn Intelligence Platform V15 — release and verification summary

Date: 2026-11-07

## Release scope

V15 builds on the V14.1 application and introduces a durable database-backed background-job queue with a separate worker process. It is a development/controlled-demo release, not a production-approved system.

### Main additions

- Persistent `background_jobs` table with idempotency key, payload digest, priority, attempt count/limit, availability time, lease owner/expiry, progress, result and error metadata.
- Typed allowlisted job payloads and role-aware job submission.
- Separate worker process with PostgreSQL `FOR UPDATE SKIP LOCKED` claim semantics, lease heartbeat, expired lease recovery, bounded retry/backoff and stale-worker fencing.
- Authenticated jobs list/detail/summary, cancel and retry endpoints; non-admin users are restricted to their own jobs.
- Bounded asynchronous file import with server-generated filename, checksum validation, idempotency and safe cleanup after successful completion.
- Dashboard Jobs & activity view and asynchronous submission for large imports, labels, feature generation, quality audits, model training, batch scoring, retention generation and configured REST source sync.
- Docker Compose worker service and local launchers that start the separate worker.
- Evidence importers require PostgreSQL worker evidence and stronger Docker worker/persisted-job checks before those production gates can pass.

## Fresh verification results

| Measure | Result |
|---|---:|
| Strict automated tests (`pytest -q -W error`) | **122 passed, 0 failed, 0 skipped** |
| Core stage | 6 PASS, 0 FAIL (one shared-host diagnostic NOT_APPLICABLE) |
| Runtime stage | 3 PASS, 0 FAIL |
| Migration/deployment-contract stage | 4 PASS, 0 FAIL |
| Synthetic ML workflow stage | 1 PASS, 0 FAIL |
| Chromium UI/API bridge stage | 1 PASS, 0 FAIL |
| Aggregate production acceptance | **15 PASS / 0 FAIL / 10 BLOCKED across 25 unique checks** |

The aggregate ten BLOCKED rows are PostgreSQL runtime, Docker runtime, clean isolated install, MLOps runtime, quality/security toolchain, live CRM sandbox, hosted staging, real-company model validation, business-policy sign-off and independent penetration testing.

## Evidence boundaries

The actual worker integration smoke ran on a temporary migrated SQLite database. It proves queue persistence and handler execution for the local single-worker scope; it does not prove PostgreSQL locking, multi-worker contention or Docker recovery. PostgreSQL offline DDL compilation is not PostgreSQL runtime. Compose/CI static validation is not a hosted workflow. Synthetic customer data is not a real-company performance benchmark. The browser smoke uses a host-side API bridge and semantic accessibility checks; it is not full axe-core/WCAG certification.

The shared agent interpreter is not an isolated project environment, so its package compatibility diagnostic is `NOT_APPLICABLE`; the clean isolated installation gate remains BLOCKED pending a network-enabled supported Python 3.11/3.12 environment.

## Run locally

Windows PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\run_local_demo.ps1
```

Open `http://127.0.0.1:8000`. For a complete technical acceptance run on a network-enabled Windows machine with Python 3.11/3.12, use `scripts/run_acceptance.ps1`; see `docs/verification/V15_GATE_CLOSURE_CHECKLIST.md`.

## Release decision

V15 is suitable for controlled local demonstration and further integration work with synthetic data. It is **not production accepted**. Do not connect production CRM credentials or import real customer data until the relevant authorization, data governance, company policy and security acceptance gates are approved.
