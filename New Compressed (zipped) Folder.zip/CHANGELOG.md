# Changes

## 1.3.0

Fixed

- **A failed record no longer advances the export watermark** (BUG 1). The watermark and the batch checksum were taken
  from the *selection*: with a destination that refused the first record and accepted the second, the watermark came
  from the refused one and the checksum covered a row the destination had never seen. Every record now carries its own
  outcome — `PENDING`, `ACKNOWLEDGED`, `FAILED` or `QUARANTINED`, with attempts and the error — and only acknowledged
  records make a checksum or move a watermark. The watermark is the newest instant up to which every record of the
  stream was acknowledged, per tenant, and it stops at the first outstanding record, including one that shares its
  instant with an acknowledged record. A batch that fails is retried and, if it keeps failing, broken into
  single-record writes so one bad row cannot take its neighbours down.
- **A Snowflake session that is not the configured one is refused** (BUG 2). The connection test compared the
  warehouse and the database, ignored the schema, the account and the region, and treated a value the session did not
  report as agreement — so a session in `OTHER_SCHEMA` reported healthy against a configuration saying `PUBLIC` and
  then wrote its rows to the wrong schema. All six compared fields must match, a silent value is a mismatch, a
  connector exception becomes a refusal with its kind, and TLS cannot be switched off. Every configured identifier is
  validated and quoted before it reaches a statement.
- **Two tenants' records can no longer collide** (BUG 3). The canonical export record had no tenant, so its identity
  was `customer|model|version|day`: inside one run two tenants' rows were deduplicated into one, and at the warehouse
  the MERGE updated the other tenant's row in place. `tenant_id` is now the record's first required field and leads the
  identity, the idempotency key, the deduplication, the primary key and the MERGE's `ON` clause; a record built without
  a tenant is refused rather than defaulted. The record schema moves to `1.1.0`.
- **The release validator no longer passes on another commit's evidence** (BUG 4). `--release` compared the register's
  `meta.source_commit` with an argument that `main` filled from the same register, so it agreed with itself: 26 PASSes
  earned at `0224654` passed while the source was at a later commit. The claim is now compared with `git`, every PASS and
  FAIL must be verified at the commit being released, the working tree must be clean, and the JUnit files must carry a
  sidecar naming their commit and command, with no failures, no errors and no skips, and two runs must agree test by
  test. A PARTIAL is exempt from the commit requirement on purpose: it states what is missing, not what ran.

Added

- **The export outbox** (migration `0005`, additive and reversible). `export_runs` records one row per tenant,
  destination and run; `export_outbox` records one row per record with its identity, idempotency key, payload digest,
  state, attempts and error; `export_checkpoints` holds each tenant's contiguous acknowledged watermark and only moves
  it forward. `services/export_outbox.py` writes them and answers "what is outstanding", so a restarted run resumes
  instead of guessing. A run that mixes tenants is refused.
- `scripts/reverify_1_3_0_register.py` brings the register's evidence to the release commit: it stamps an entry only
  when the test module its evidence names passed in both release runs, decides the entries that name no module one by
  one, and exits non-zero on anything it cannot decide. It is what turned two 1.2.0 PASSes (`R-13`, `R-38`) into
  PARTIALs, because a PASS that cannot be repeated is history.
- `scripts/record_test_run.py` writes the metadata sidecar `--release` requires; `build_1_3_0_register.py` reads JUnit
  files, compares the register with the tree, and allows exactly one documented exception — a documentation-only commit
  above the commit it names, because the register cannot contain its own hash.
- **A destination that is a real database.** `services/destinations/postgres.py` delivers to the PostgreSQL this
  platform already runs: a primary key on `(tenant_id, external_customer_id, model_name, model_version,
  data_cutoff_timestamp)` that the server enforces, an `INSERT … ON CONFLICT` upsert the server executes, a run row an
  operator can read, a session read-back that refuses a connection in the wrong schema, and a connection URL redacted
  before it can reach a log. Ten tests, one of which starts an export through `POST /exports/runs`, lets the worker
  drain it, and finds the rows and the run row with an independent connection. It is the first time this release can
  *show* the delivery pipeline delivering; it is still not a warehouse, and GATE 12 stays BLOCKED.
- **Every gate is a probe, and the probes are published.** `scripts/gate_ledger.py` runs all fifteen gates the register
  declares and writes `docs/1_3_0_GATES.md`, which `--check` refuses to leave stale. Three gates are decided on this
  machine (a live PostgreSQL 17.12 with the migration and delivery tests passing in both release runs; ruff, pip-audit
  and the secret scan clean with bandit reporting zero findings at high or medium; 176 of 176 lock pins installed at the
  locked version); eleven report the account, host, assessor or binary they could not find, by name; one has nothing to
  probe. A probe may narrow a gate and may never promote one, and `--write-register` now copies each probe into the
  register beside its gate's declared result, so the two answers sit next to each other instead of being reconciled.
- **The SMTP acceptance is repeatable.** `scripts/acceptance_smtp_73.py` drives the platform's own transport against
  **aiosmtpd**, an SMTP server this repository did not write: 73 attempted, 73 accepted with `250`, 73 received with
  their `X-Churn-Message-Ref` header. `R-13` returns to PASS with that evidence in it, and `GATE 13` stays BLOCKED,
  because a protocol acceptance against a local server is not a provider's reputation, bounces or deliverability.

Measured

- The performance figures were re-taken on a rebuilt sandbox and **the environment moved the API numbers down**
  (59.3 / 84.8 / 78.3 req/s at 1 / 8 / 32 clients against 77.4 / 96.2 / 91.6 before, unattributed). The delivery
  figures reproduce to the digit, including the one that matters: ten refused records in a 10 000-record run turn 20
  destination calls into 5 020. `docs/1_3_0_PERFORMANCE_REPORT.md` leads with the discrepancy rather than picking the
  flattering number.
- `record_run()` on PostgreSQL is 835 rows/s against SQLite's 1 786, so a 100 000-record run spends about two minutes
  writing its own run record; and `outstanding()` on a 50 000-row backlog takes 0.85 s.

- Four regression files, one per defect, each named for the failure it prevents:
  `test_failed_first_record_does_not_advance_watermark.py`, `test_schema_mismatch_fails_validation.py`,
  `test_tenant_id_prevents_crm_collisions.py`, `test_release_validator_rejects_stale_evidence.py`, plus
  `test_export_outbox.py` for the schema, the checkpoint and the resume path.

## 1.2.0

A release built against a register rather than a wish list: `docs/1_2_0_REQUIREMENT_TRACEABILITY.md` holds 58
requirements with a status each, and nothing moves to PASS without a run at the current commit.

Added

- **Human labels for support text, so sentiment accuracy can be measured on something real** (migration `0004`).
  A batch draws support interactions (sampled, by language, or an explicit list), two people label each text
  independently, agreement is reported before any model is scored (exact agreement and Cohen's kappa per pair, plus
  the disagreements), a reviewer adjudicates each disagreement, and the batch freezes — after which nothing changes.
  Only a frozen batch can be exported or evaluated, so a model's accuracy can never be computed against a set that
  was edited after the numbers were seen. The batch carries whether its text is synthetic, and the evaluation
  inherits that, so a result on generated text is never presented as evidence about real text.
- A permission of its own for labelling, `signals:annotate`, held by analysts, customer-success users and the
  engineering roles: labelling is neither changing what the product computes (`signals:write`) nor deciding another
  person's disagreement (`signals:approve`).

Changed

- `tests/test_api.py` gains the twelve new operations in its access-rule table (202 operations declared).
- **Quiet hours for marketing messages.** With `CHURN_NOTIFY_QUIET_HOURS` set (an `HH:MM-HH:MM` window, wrapping
  midnight, interpreted in `CHURN_NOTIFY_QUIET_TIMEZONE`), a marketing message that would land inside the customer's
  window is *held* — still `queued`, released through the same deferred-job mechanism as a retry at the window's end
  — rather than dropped or sent. Transactional messages are unaffected. A malformed window or an unknown time zone
  is a validation failure naming the setting, not a silent default.
- **Backup and restore** (`churn-platform backup`, `restore`, `backup-check`; `src/churn_platform/backup.py`). One
  archive with a manifest of a SHA-256 per member; `restore` verifies every checksum and every member path before it
  writes anything, then checks the database's health afterwards (migration revision, eleven table counts, newest audit
  event) and refuses to call the restore done if the revision moved. `backup-check` verifies an archive without
  restoring it. SQLite uses `VACUUM INTO`; PostgreSQL uses `pg_dump --format=custom` and `pg_restore`.
- **Security jobs in CI**: Bandit (`-ll`), `pip-audit` against `requirements.lock` and `scripts/scan_secrets.py`, a
  credential scan with an explicit, reasoned suppression list. All three run clean at this commit; see
  `docs/1_2_0_SECURITY_REPORT.md`.

Changed

- Version 1.2.0, and five new reports: `docs/1_2_0_SECURITY_REPORT.md`, `docs/1_2_0_DISASTER_RECOVERY_REPORT.md`,
  `docs/1_2_0_NOTIFICATION_DELIVERY.md`, `docs/1_2_0_PERFORMANCE_REPORT.md`, `docs/1_2_0_CRM_ACCEPTANCE.md`,
  plus `docs/1_2_0_PRODUCTION_ACCEPTANCE.md` and `docs/1_2_0_COMPLETE_AUDIT.md`.
- `docs/1_2_0_IMPLEMENTATION_STATUS.md` and the register carry the new counts (28 PASS, 14 PARTIAL,
  6 NOT_IMPLEMENTED, 8 BLOCKED, 2 NOT_APPLICABLE).

Fixed

- **Backup could not have backed up PostgreSQL.** `pg_dump` and `pg_restore` were handed the SQLAlchemy URL
  (`postgresql+psycopg://…`), which they do not understand: they fell back to a local socket and the operating
  system's user name (`FATAL: role "user" does not exist`). `backup.libpq_url()` now translates the scheme; a
  measured backup (1.90 s) and restore (3.37 s) with eleven identical table counts is recorded in
  `docs/1_2_0_DISASTER_RECOVERY_REPORT.md`.

## 1.1.1

A small release with one feature and three fixes, made while proving the 1.1.0 vendor work for real against
third-party software running on one machine: Keycloak 26.0 for single sign-on, a mail server (Mailpit) for the
e-mail channel, and a CRM built to HubSpot's rules for OAuth, signed events and reverse ETL. What each of those
proved, and what still needs a paid vendor account, is in [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

Added

- **The e-mail channel can be delivered through an SMTP server**: a provider of type `smtp` (host, port, sender,
  optional `starttls`, optional `username`/`password`), schema change in migration `0003`. It speaks SMTP itself
  (`EHLO`, `STARTTLS`, `AUTH`, `MAIL FROM`/`RCPT TO`/`DATA`, `QUIT`), records the `Message-ID` the server assigned,
  and treats an unreachable mail server as a temporary failure. `SANDBOX` takes the handshake only. No vendor
  account is needed for this path at all.

Fixed

- **An OAuth CRM connection could not be created through the API** (DEF-083): `POST /api/v1/crm/connections` had
  no `auth_type`, so a `SANDBOX` connection demanded an access token that only the consent flow can produce. It is
  now possible to create a connection whose way in is OAuth and authorise it afterwards.
- **A provider without credentials could not leave `DRY_RUN`** (DEF-084), which made an SMTP relay that takes mail
  without authentication impossible to use. An SMTP provider may now be switched on without credentials; a server
  that demands authentication answers 530 and the message records it.
- **A mail server is checked before the platform connects to it** (DEF-085): the SMTP provider took the host
  straight from its configuration, so an address the HTTP providers refuse — `127.0.0.1`, a private range, a name
  that does not resolve — was reached anyway. It now goes through the same outbound guard, and a relay on this
  machine needs `CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS=true` like any other private address.

## 1.1.0

Release 1.0.1 listed, under "Differences from the brief", what the platform only approximated or left to other
tools. 1.1.0 builds those parts. What was run for it, and what could not be run because it needs an account with a
vendor, is in [docs/LIMITATIONS.md](docs/LIMITATIONS.md). Nothing that sends data out of the platform is switched
on by an upgrade: CRM connections keep the mode they have (`TEST_ONLY` unless somebody chose another), message
providers start in `DRY_RUN`, campaigns start as dry runs.

Added

- **Support sentiment from a trained model** ([docs/SIGNALS.md](docs/SIGNALS.md)). A multilingual transformer
  (pinned and checksummed, about 170 MB) scores every support text inside the installation; no text leaves it.
  Personal data is removed before scoring. A text that cannot be scored says why. Without the model the platform
  falls back to the English word list of 1.0 and labels it as a baseline everywhere. Accuracy on real support text
  is shown as *not measured* until a labelled sample has been evaluated.
- **Feature adoption rate**: a reviewed catalogue of product features; adopted features divided by the features
  the customer could use, with the denominator stored.
- **Identity mapping and active users**: identifiers in telemetry resolve to people; daily and monthly active users
  count distinct people under an approved definition of activity.
- **History of customer attributes**: industry, size, employees, region, country and acquisition channel are kept
  with the period in which each value held. A feature vector for a past date carries the values of that date.
- **Model lifecycle** ([docs/ORCHESTRATION.md](docs/ORCHESTRATION.md)): candidate, validated, approved, staging,
  production, archived; promotion gates as an approved policy; every transition on record, blocked ones included.
  MLflow follows the lifecycle with tags and the aliases `validated`, `staging` and `production`, and can be made
  the registry of record (`CHURN_MODEL_REGISTRY=mlflow`).
- **Airflow drives the night step by step**: `churn-platform pipeline-step` runs one step per run key and is safe
  to retry; the DAG has one task per step. `CHURN_ORCHESTRATOR` says who starts the nightly work.
- **CRM** ([docs/OUTBOUND.md](docs/OUTBOUND.md)): authorisation by OAuth with token refresh, signed events from the
  CRM, and reverse-ETL syncs to a CRM connection or to a file for a tool such as Hightouch or Census.
- **Messages and campaigns**: e-mail (SendGrid, Amazon SES), text message (Twilio), push (Firebase) and in-app,
  with approved templates, consent, suppression list, frequency caps and unsubscribe links. Campaigns carry out
  what the retention playbook decided: the automated tier of the brief (content e-mails, or the 15 % offer once a
  person approved it) and the card-expiry reminder by text message and in-app message.
- **Security** ([docs/SECURITY_OPERATIONS.md](docs/SECURITY_OPERATIONS.md)): request limits shared by all server
  processes, trusted proxies, session tokens replaced on a schedule, single sign-on with OpenID Connect.
- 72 automated tests and ten requirements (REQ-SIG-01 to 04, REQ-ML-07, REQ-OPS-07, REQ-ACT-04, REQ-ACT-05,
  REQ-SEC-07, REQ-SEC-08).

Changed

- **The feature catalogue has 84 features** (69 before). Two kept their name and changed their meaning:
  `negative_ticket_share_90d` is the share of tickets the sentiment model labels negative (it was a word-list
  match), `avg_daily_active_users_30d` counts resolved people (it counted raw user references). Five customer
  attributes are read from their history instead of today's value. **Train new models after the upgrade**: a model
  trained with 1.0 would be fed values it was not trained on.
- **The nightly pipeline has seven steps**; `signals` runs after the data-quality checks.
- `GET /api/v1/jobs/active` lists running jobs and queued jobs due within 15 minutes; jobs dated further ahead are
  counted in `scheduled`.
- The demo holds the new signals, three campaigns (one rehearsed as a dry run) and an export sync; its figures
  differ from 1.0.1.
- The container image installs the `nlp` extra. The model weights are not in the image:
  `churn-platform sentiment-model fetch` downloads them into the data directory.
- `churn-platform serve` no longer takes `--forwarded-allow-ips`. `CHURN_TRUSTED_PROXIES` is the one list of
  proxies whose forwarded headers are believed; the option is refused with a message that says so.
- The compose file passes `CHURN_TRUSTED_PROXIES` and `CHURN_PUBLIC_BASE_URL` from `.env` to the containers.

Fixed

- DEF-068 to DEF-082 in [docs/DEFECT_LOG.md](docs/DEFECT_LOG.md). Three concern 1.0 installations: any client
  could obtain the `Strict-Transport-Security` header by claiming HTTPS in a forwarded header (DEF-068), a client
  on the server's own machine could choose the address it was counted under (DEF-082), and sign-in limits were
  counted per server process (DEF-069). The others were found in 1.1.0 code before release.

Upgrading from 1.0.x

- `churn-platform migrate` applies migration `0002`: 28 new tables, and 37 new columns on seven existing tables
  (`users`, `auth_sessions`, `customers`, `model_versions`, `campaigns`, `crm_connections`, `crm_deliveries`).
  Existing data is kept; attribute history starts from the change log the platform already held.
  `churn-platform downgrade 0001` removes the new tables and columns.
- Optional: `pip install 'churn-platform[nlp]'` and `churn-platform sentiment-model fetch`. Without them sentiment
  stays on the labelled word-list baseline.
- Behind a reverse proxy set `CHURN_TRUSTED_PROXIES`, also when the proxy runs on the same machine (`127.0.0.1`);
  without it forwarded headers are ignored, so limits and sessions see the proxy's address and the
  transport-security header is not sent. Remove `--forwarded-allow-ips` from the `serve` command: it is refused.
  Set `CHURN_PUBLIC_BASE_URL` before using single sign-on, CRM OAuth or marketing e-mail.
- With an external orchestrator set `CHURN_ORCHESTRATOR=airflow` for the API, the worker and the Airflow workers
  and replace the DAG file: the 1.0 DAG ran the whole chain as one task (`nightly --wait`), the new one has one
  task per step.

## 1.0.1

Release 1.0.0 listed eight things that had never been run. 1.0.1 is the result of running them. What was run, how,
and what still could not be run is in [docs/LIMITATIONS.md](docs/LIMITATIONS.md); the defects are DEF-061 to
DEF-067 in [docs/DEFECT_LOG.md](docs/DEFECT_LOG.md).

Fixed

- **HubSpot**: a task is created with the `associations` member HubSpot requires, and property values are sent as
  text. Both requests were invalid for HubSpot's published API description.
- **Intercom**: an executed recommendation is written to the company as attributes. It used to be sent as an event
  without a contact, which Intercom refuses.
- **Salesforce**: the risk-score update can no longer create an account for a customer Salesforce does not know
  (`updateOnly=true`; an `api_version` below `v61.0` is refused).
- **`create-user` at a terminal**: Ctrl-C and Ctrl-D at the password prompt end the command with one line instead
  of a stack trace, and a missing tenant is reported before the password is asked.
- **arm64 image**: installs the CPU-only XGBoost package, as on x86-64, instead of the GPU build with its CUDA
  runtime package.
- **Airflow DAG**: loads on Airflow 3 without a deprecation warning.

Added

- `scripts/check_crm_contracts.py`: checks the HubSpot and Intercom requests against the vendors' published API
  descriptions. The CI workflow runs it in a job of its own.
- `scripts/load_test.py` and the measured figures in the README.
- `docs/CRM_SETUP.md`: what each vendor needs before the first run, and what has been verified.
- The browser tests can run against several server processes (`CHURN_TEST_SERVE_WORKERS`).

Changed for existing installations

- An Intercom connection created with 1.0.0 keeps working; the mapping key `event_prefix` is no longer used.
- Nothing else: no migration, no change to the API apart from the CRM requests above.

## 1.0.0

First release.
