# Churn Platform

Predicts which subscription customers are likely to cancel in the next 30 days, explains why, and turns the
prediction into reviewed retention actions. It implements the project brief
[*Customer Churn Prediction for Subscription Businesses*](docs/brief/) as one application: data ingestion,
a point-in-time feature store, customer signals (support sentiment, feature adoption, active users, attribute
history), model training and evaluation, SHAP explanations, a model registry with a lifecycle and promotion gates,
nightly scoring, retention playbooks, CRM hand-over, messages and campaigns, experiments, monitoring and a web
interface.

Version 1.2.0 ([what changed](CHANGELOG.md)). Python 3.11 to 3.13. PostgreSQL in production, SQLite for a single machine.

- What it does not do, and what has not been proven: [docs/LIMITATIONS.md](docs/LIMITATIONS.md)
- Customer signals: [docs/SIGNALS.md](docs/SIGNALS.md) · Model lifecycle, MLflow and Airflow:
  [docs/ORCHESTRATION.md](docs/ORCHESTRATION.md) · CRM, reverse ETL, messages and campaigns:
  [docs/OUTBOUND.md](docs/OUTBOUND.md) · Limits, proxies, sessions and single sign-on:
  [docs/SECURITY_OPERATIONS.md](docs/SECURITY_OPERATIONS.md)
- How each requirement of the brief is covered and tested: [docs/traceability/TRACEABILITY.md](docs/traceability/TRACEABILITY.md)
- 1.2.0 works from a register rather than a to-do list: `docs/1_2_0_REQUIREMENT_TRACEABILITY.md` holds every requirement
  with a status and the evidence behind it, and `docs/1_2_0_PRODUCTION_ACCEPTANCE.md` says which gates are open and why.
  What it added: human labels for support text (so sentiment accuracy can be measured), quiet hours for marketing
  messages, and a backup and restore that has actually been restored.
- 1.1.1 was made while proving the vendor work of 1.1.0 for real: single sign-on against a Keycloak 26.0 server,
  e-mail through a real SMTP server (new in 1.1.1), CRM OAuth, signed events and reverse ETL against a CRM built to
  HubSpot's rules, all running on one machine. The table in
  [docs/LIMITATIONS.md](docs/LIMITATIONS.md) says what each proved and what still needs a paid vendor account.
- Release 1.1.0 against 1.0.1: [where it started](docs/ENHANCEMENT_BASELINE.md) ·
  [what was missing and what became of it](docs/MISSING_FEATURE_REGISTER.md) ·
  [what it did to the existing features](docs/EXISTING_FEATURE_HEALTH_REPORT.md) ·
  [work items, requirements, tests and runs](docs/REQUIREMENT_TRACEABILITY.md)
- Defects found and fixed while building it: [docs/DEFECT_LOG.md](docs/DEFECT_LOG.md)

## Try it

The demo creates a tenant filled with **synthetic** customers and runs the whole lifecycle on them: import, data
quality, customer signals, labels, features, training of four algorithms, evaluation, approval, scoring,
recommendations, an A/A experiment, monitoring, a campaign rehearsed as a dry run and an export for a reverse-ETL
tool. It takes two to four minutes on a two-core machine. Nothing in it sends anything to anybody.

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.lock      # the versions the tests ran against
.venv/bin/pip install --no-deps -e .

export DEMO_PASSWORD='choose-a-passphrase-of-12+-characters'
.venv/bin/churn-platform sentiment-model fetch   # optional: 170 MB, the sentiment model; without it a word list stands in
.venv/bin/churn-platform seed-demo --password-env DEMO_PASSWORD
CHURN_EMBEDDED_WORKER=true .venv/bin/churn-platform serve --port 8000
```

Open <http://127.0.0.1:8000> and sign in. Without `--password-env` a password is generated and printed once.
The database is `./var/churn.db` and uploaded files and models go to `./var/data`; delete `./var` to start again.

| Sign in as | Role | What this person does |
|---|---|---|
| `admin@demo.example` | Administrator | Everything, except approving their own work |
| `approver@demo.example` | Approver | Second pair of eyes: approves policies, feature contracts, models, retention actions |
| `data.scientist@demo.example` | Data scientist | Labels, features, training, evaluation, scoring |
| `analyst@demo.example` | Analyst | Reads everything, runs analyses, exports scores |
| `csm@demo.example` | Customer success | Works the retention queue |
| `viewer@demo.example` | Viewer | Read only |

Two more roles exist without a demo user: `data_engineer` (sources, imports, data quality) and `auditor`
(read only, including the audit trail).

`seed-demo` accepts `--customers` (1200), `--months` (15), `--seed` (42), `--n-iter` (6 hyper-parameter candidates
per algorithm), `--end-date` (last day of history, default yesterday) and `--slug`. The same seed and end date
give the same data, the same models and the same numbers. The figures quoted in this file are those of
`--end-date 2026-11-09` with the default seed; a demo whose history ends on another day shows other figures.

### Reading the demo

- **The numbers describe the simulator.** Every figure on screen comes from generated data. They show how the
  platform works, not how accurate it will be for a real business.
- **Which model is in production.** The demo registers the run with the best PR-AUC on the validation split. On this
  small data set that is often logistic regression, not a boosted tree.
- **The money figures are examples.** The cost matrix (50 dollars per offer, 5,000 dollars per lost customer) and
  the 15% discount are the examples of the brief and are labelled as such.
- **The A/A experiment.** The demo splits customers at random on a past scoring date and delivers nothing, so there
  is no effect to find. With `--end-date 2026-11-09` the two arms still differ at p = 0.039. That is chance: about
  1 split in 20 crosses the 5% threshold. The experiment page repeats the split 400 times on the same customers and
  shows that about 5% of the splits are "significant", which is what a sound assignment and comparison produce. The
  uplift model fitted on this experiment fails validation, as it must.
- **Input drift reads "warning".** Monitoring compares the customers scored today with the training period. 18 of
  84 features have moved (with `--end-date 2026-11-09`), half of them measures of age in a simulated customer base
  that is still growing. That is below the approved alert rule, so no alert is raised.
- **Sentiment.** With the model fetched, every support ticket of the demo is scored. The screen shows the last 180
  days: 1,349 scored texts in English, French, German and Spanish; 89 Hindi and Turkish texts show as "unsupported
  language" and 27 empty ones as "empty". The texts
  are generated from templates, so the labels say nothing about accuracy on real conversations; the screen shows
  accuracy as *not measured*. Without the model the screen says that a word-list baseline stands in.
- **Campaigns.** The re-engagement e-mails of the automated tier run as a dry run: 165 customers are enrolled (17
  of them in the control group), 148 first e-mails are built and checked, none is sent. The message providers are
  in dry-run mode.

## What is inside

| Stage | What the platform does | Screen |
|---|---|---|
| Ingest | Files (CSV, TSV, JSON, JSON Lines, Excel, Parquet), signed webhooks and scheduled REST pulls for ten entities: customers, accounts, plans, subscriptions and their events, invoices, payments, usage events, support interactions, acquisitions. Column mapping, validation, quarantine with reviewed corrections. | Sources & imports, Data quality |
| Label | "Churned within 30 days of date T", voluntary and involuntary, under a versioned churn definition. | Churn labels |
| Features | 84 features computed strictly from what was known at T: RFM, usage velocity, 7-day against 30-day changes, inactivity streaks, support friction, billing signals, sentiment, adoption, active users. | Feature store |
| Signals | Sentiment of support text from a multilingual model that runs locally; feature adoption rate against a reviewed feature list; identity mapping and daily active users; history of customer attributes. | Signals |
| Explore | Churn overview, cohort retention heat map, Kaplan-Meier survival curves, churner profile. | Analytics |
| Train | Logistic regression, random forest, XGBoost and LightGBM with class weights or SMOTE, cross-validated in time order, calibrated. | Training |
| Evaluate | PR-AUC first, recall, precision, ROC-AUC, and a decision threshold that minimises expected cost under an approved cost matrix. The test split can be used once per model. | Training |
| Explain | SHAP: global importance and a waterfall per customer. | Training, Customers |
| Govern | Registry with a lifecycle (candidate, validated, approved, staging, production, archived), promotion gates, approval by a second person; MLflow follows it and can be the registry of record. | Registry |
| Score | Nightly batch for every active subscriber: probability, risk tier, decile, top three reasons. CSV export. | Predictions, Customers |
| Act | Playbooks by risk and value: a call for high-value accounts (human review), an automated sequence or discount for the rest, a payment reminder before a card expires. Hand-over to Salesforce, HubSpot or Intercom (token or OAuth); reverse-ETL syncs to a CRM or to a file; e-mail, text, push and in-app messages; campaigns that carry out the playbook. Everything starts in test or dry-run mode. | Recommendations, CRM sync, Syncs & exports, Messages, Campaigns |
| Learn | Randomised experiments with sample-size planning and guardrails; uplift models that must pass validation before they steer anything. | Experiments & uplift |
| Operate | Feature, prediction and performance drift, alerts, retraining candidates, the nightly pipeline on the built-in schedule or step by step under Airflow, job queue. | Monitoring, Jobs & pipeline, Orchestration |
| Control | Eight roles, optional or enforced one-time codes, single sign-on (OpenID Connect), request limits shared by all server processes, four-eyes approval, a hash-chained audit trail, tenant isolation. | Policies, Security, Administration |

The score export has one row per customer:
`user_id, customer_name, as_of_date, churn_probability, risk_tier, risk_decile, top_reason_1, top_reason_2, top_reason_3, model_version_id`.

## Run it with Docker

One image serves as web server, worker and command line. The compose file adds PostgreSQL and runs the
`production` profile.

```bash
cp .env.example .env            # then fill in CHURN_SECRET_KEY and POSTGRES_PASSWORD
docker compose up --build -d
docker compose run --rm -e DEMO_PASSWORD='choose-a-passphrase' web seed-demo --password-env DEMO_PASSWORD   # optional
```

The application listens on port 8000 (`CHURN_HTTP_PORT` changes it). TLS is not terminated: put a reverse proxy in
front before exposing it, name it in `CHURN_TRUSTED_PROXIES` and the public address in `CHURN_PUBLIC_BASE_URL`
(both in `.env`); forwarded headers from anybody else are ignored.

The image (1.2 GB) contains the runtime of the sentiment model, not its weights. Fetch them once into the data
volume, or leave it and the word-list baseline stands in:

```bash
docker compose run --rm web sentiment-model fetch
```

`docker build --build-arg EXTRAS=nlp,mlops .` adds MLflow and Evidently; `--build-arg EXTRAS= .` leaves the
sentiment runtime out. Neither variant, and no `linux/arm64` image, was built for 1.1.0;
[LIMITATIONS](docs/LIMITATIONS.md) says what was checked.

## Set up a real tenant

```bash
export CHURN_DATABASE_URL='postgresql+psycopg://user:password@host:5432/churn'
export CHURN_SECRET_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
export CHURN_DATA_DIR=/srv/churn/data
export CHURN_ENV=production CHURN_ALLOW_FRAMING=false

churn-platform migrate
churn-platform create-tenant --slug acme --name "Acme Ltd"
export FIRST_PASSWORD='a-passphrase-of-12+-characters'
churn-platform create-user --tenant acme --email you@acme.example --role admin --password-env FIRST_PASSWORD
churn-platform create-user --tenant acme --email second@acme.example --role approver --password-env FIRST_PASSWORD
churn-platform serve --host 0.0.0.0 --port 8000        # in one process
churn-platform worker                                  # in another
```

Both users change their password under *My account* after the first sign-in. Then, in the web interface: add a
source and upload files (parents first: customers and plans before subscriptions), review the data-quality report,
approve the churn definition, cost matrix and playbook under *Policies* (author and approver must be two people),
build labels and features, train, evaluate, register and approve a model, and set the nightly schedule under
*Jobs & pipeline*.

## Configuration

Settings are environment variables, or files of the same name in the directory `CHURN_SECRETS_DIR`.

| Variable | Default | Meaning |
|---|---|---|
| `CHURN_ENV` | `development` | `development`, `test`, `staging` or `production`. The last two refuse to start with the development key, SQLite, self-approval or the embedded worker; `production` also requires `CHURN_ALLOW_FRAMING=false`. |
| `CHURN_SECRET_KEY` | development key | At least 32 characters outside development. |
| `CHURN_DATABASE_URL` | `sqlite:///./var/churn.db` | `postgresql+psycopg://…` in production. |
| `CHURN_DATA_DIR` | `./var/data` | Uploaded files, data sets, model artefacts. Shared by web and worker. |
| `CHURN_EMBEDDED_WORKER` | `false` | Run the job worker inside `serve`. Development only. |
| `CHURN_MFA_REQUIRED_ROLES` | empty | Comma-separated roles that must sign in with a one-time code, for example `admin,approver`. |
| `CHURN_LOGIN_MAX_FAILURES` / `CHURN_LOGIN_LOCKOUT_MINUTES` | 5 / 15 | Account lockout. |
| `CHURN_PASSWORD_MIN_LENGTH` | 12 | |
| `CHURN_SESSION_TTL_MINUTES` / `CHURN_SESSION_IDLE_MINUTES` | 480 / 120 | Session lifetime and idle time-out. |
| `CHURN_ALLOW_FRAMING` | `true` | `false` forbids embedding the application in a frame. |
| `CHURN_MAX_UPLOAD_MB` | 200 | |
| `CHURN_LOG_LEVEL` / `CHURN_LOG_JSON` | `INFO` / `true` | Logs are JSON lines on standard error. |
| `CHURN_MLFLOW_TRACKING_URI` | unset | When set, every registered model version is created in this MLflow server and follows the lifecycle there. |
| `CHURN_MODEL_REGISTRY` | `platform` | `mlflow`: a model serves only while MLflow's `production` alias names the same version and model file. |
| `CHURN_ORCHESTRATOR` | `platform` | `airflow`: the built-in nightly schedule stands down and `pipeline-step` is accepted. |
| `CHURN_SENTIMENT_PROVIDER` | `auto` | `auto` uses the model when it is installed and verified, else the word-list baseline; `onnx_transformer` makes a missing model an error; `lexicon_baseline` forces the baseline. |
| `CHURN_SENTIMENT_MODEL_DIR` | `<data dir>/models/sentiment` | Where `sentiment-model fetch` puts the weights. |
| `CHURN_PUBLIC_BASE_URL` | unset | The address users reach the platform at. Needed for single sign-on, CRM OAuth and unsubscribe links. |
| `CHURN_TRUSTED_PROXIES` | empty | Addresses or CIDR ranges of reverse proxies whose forwarded headers are believed; nobody else's are. A proxy on the same machine is listed too (`127.0.0.1`). |
| `CHURN_FORCE_HTTPS` / `CHURN_HSTS_SECONDS` | `false` / 31536000 | Send `Strict-Transport-Security` on every response; its lifetime. |
| `CHURN_SESSION_ROTATE_MINUTES` | 60 | The web application replaces its session token this often. |
| `CHURN_RATE_LIMIT_…_PER_MINUTE` | see [SECURITY_OPERATIONS](docs/SECURITY_OPERATIONS.md) | Sign-in, changes, exports, single predictions and CRM syncs; counted in the database. `CHURN_RATE_LIMIT_ENABLED=false` switches them off. |
| `CHURN_NOTIFY_ALLOW_LIVE` | `false` | Must be `true` before a message provider may be switched to live sending. |
| `CHURN_NOTIFY_MAX_PER_CUSTOMER_PER_DAY` / `…_PER_WEEK` | 2 / 5 | Frequency caps for marketing messages. |
| `CHURN_CRM_ALLOW_PRODUCTION` | `false` | Must be `true` before a CRM connection may be created in `PRODUCTION` mode. `SANDBOX` needs no setting. |
| `CHURN_JOB_MAX_ATTEMPTS` | 3 | Attempts per background job. |

`GET /healthz` answers while the process is alive, `GET /readyz` once the database answers. The API lives under
`/api/v1`; its interactive documentation is at `/api/docs` in development and test.

## Command line

```
churn-platform migrate | downgrade <revision> | db-status
churn-platform create-tenant --slug SLUG [--name NAME]
churn-platform create-user --tenant SLUG --email EMAIL [--name NAME] [--role ROLE] [--password-env VAR]
churn-platform serve [--host HOST] [--port PORT] [--workers N]
churn-platform worker [--once]
churn-platform seed-demo [--slug demo] [--customers 1200] [--months 15] [--seed 42] [--end-date DATE] [--n-iter 6] [--password-env VAR]
churn-platform nightly --tenant SLUG [--wait]
churn-platform pipeline-step --tenant SLUG --step STEP --run-key KEY [--wait] [--inline]
churn-platform sentiment-model fetch | verify | status
churn-platform verify-audit --tenant SLUG
```

`db-status` exits 1 when the schema is not in sync, `verify-audit` exits 1 when the audit chain is broken.
`nightly` queues the whole nightly run (for cron). `pipeline-step` runs one step for an external orchestrator and
is safe to repeat: the same run key never runs a step twice (exit 0 done, 1 failed, 2 refused, 3 still running).
[deploy/airflow/churn_nightly_dag.py](deploy/airflow/churn_nightly_dag.py) has one task per step; see
[docs/ORCHESTRATION.md](docs/ORCHESTRATION.md). `sentiment-model verify` exits 1 when a file of the model does not
match its pinned checksum.

`create-user` without `--password-env` asks for the password twice on the terminal and shows nothing that is typed.

`serve --workers N` starts N server processes. Sessions, account lockout, request limits and jobs are kept in the
database and behave the same with any number of processes. Run more than one process on PostgreSQL, not on SQLite.

Before connecting Salesforce, HubSpot or Intercom read [docs/CRM_SETUP.md](docs/CRM_SETUP.md): it lists the fields
each vendor needs and says plainly that no vendor account has accepted a request from this software yet. The same
holds for the message providers (SendGrid, Amazon SES, Twilio, Firebase): see [docs/OUTBOUND.md](docs/OUTBOUND.md).

## Load

Measured with `scripts/load_test.py` on the reference demo (1,200 customers): each client sends one request, waits
for the answer and sends the next, drawn from the mix of requests the web application makes. Server and load
generator shared one machine with 2 CPUs and 2 GB of memory, so the figures are a lower bound. Every level ran for
20 seconds after a 5-second warm-up.

Release 1.1.0, SQLite, measured once on the release candidate (two small fixes were made after it; see below):

| Server processes | Requests | 1 client | 8 clients | 32 clients |
|---|---|---|---|---|
| 1 | reads | 52 requests/s, p95 48 ms | 90 requests/s, p95 243 ms | 85 requests/s, p95 711 ms |
| 2 | reads | 53 requests/s, p95 48 ms | 93 requests/s, p95 266 ms | 85 requests/s, p95 1,046 ms |
| 1 | 5% real-time scoring, limits off | 54 requests/s, p95 45 ms | 86 requests/s, p95 242 ms | 83 requests/s, p95 729 ms |

No request failed in these runs. With the request limits on, the same scoring run had 9, 47 and 87 refused requests
(HTTP 429) at the three levels: one user may score 60 single customers a minute
(`CHURN_RATE_LIMIT_PREDICT_PER_MINUTE`), and the test signs in as one user. That is the limit doing its work, not
a failure; batch scoring is not limited.

Release 1.0.1, for comparison and for PostgreSQL, which was not measured again:

| Database | Server processes | 1 client | 8 clients | 32 clients |
|---|---|---|---|---|
| SQLite | 1 | 49 requests/s, p95 53 ms | 80 requests/s, p95 280 ms | 77 requests/s, p95 796 ms |
| SQLite | 2 | 47 requests/s, p95 56 ms | 86 requests/s, p95 288 ms | 74 requests/s, p95 1,144 ms |
| PostgreSQL | 1 | 43 requests/s, p95 55 ms | 61 requests/s, p95 290 ms | 54 requests/s, p95 939 ms |
| PostgreSQL | 2 | 46 requests/s, p95 56 ms | 77 requests/s, p95 251 ms | 67 requests/s, p95 1,119 ms |

Read it as: with 8 or 32 clients this machine answered 80 to 90 requests per second on SQLite that day; more
clients wait longer, they are not served faster. One client alone waits about 20 ms on average; 32 clients queue and wait about
0.3 seconds each (median). On two CPUs that the load generator also uses, a second server process adds nothing on
SQLite. The new signals did not slow the existing screens down.

**How far to trust these figures.** The build machine is shared, and it decides more than the software does. The
whole 1.1.0 matrix was repeated a day later on the released code and gave 20 to 25 requests a second with one
client and 34 to 67 with 8 or 32; a few minutes after that, the release candidate and the released code were
measured in turn, twice each, and both gave 44 to 45 requests a second with one client and 70 to 79 with eight. So
the two fixes made after the candidate changed nothing that can be measured, and the table shows what this
machine did on its best day. All three sets of results are kept with the release evidence.

Other measurements of 1.1.0 on the same machine: seeding the reference demo, sentiment scoring included, took
98, 119 and 222 seconds in three runs (the last one while other work used the machine); the sentiment model
scores about 2,000 texts a minute and needs 430 to 460 MB of memory in the process that scores (the worker).

Not measured: PostgreSQL on 1.1.0, hours of load, larger tenants, a generator on a second machine, the screens
added in 1.1.0 (they are not part of the request mix).

```bash
DEMO_PASSWORD='...' python scripts/load_test.py --base-url http://127.0.0.1:8000 \
    --email analyst@demo.example --password-env DEMO_PASSWORD --concurrency 1,8,32 --duration 20
```

## Checking a change

```bash
ruff check src tests scripts
for f in src/churn_platform/web/js/*.js; do node --check "$f"; done
bandit -c pyproject.toml -r src -q
python -m playwright install chromium          # once, for the user-interface tests
python -m pytest                               # everything
python -m pytest -m "not e2e"                  # without the browser tests
```

Each run first seeds a small demo tenant that the tests copy (about a minute). The suite holds 490 tests; one
of them scores text with the real sentiment model and needs `CHURN_TEST_SENTIMENT_MODEL_DIR`. Release 1.1.0 was
built from test runs in strict mode on Python 3.11, 3.12 and 3.13 with PostgreSQL, started directly on the build
machine: no GitHub repository was available and the CI workflow was not run for this release.

| Variable | Effect |
|---|---|
| `CHURN_TEST_POSTGRES_URL` | Runs the PostgreSQL tests against this **empty, disposable** database, for example `postgresql+psycopg://churn:secret@127.0.0.1:5432/churn_test`. Without it they are skipped. |
| `CHURN_TEST_STRICT=1` | A test that cannot run (no PostgreSQL, no browser) fails instead of being skipped. Releases are built this way. |
| `CHURN_TEST_TEMPLATE_DIR` | Keeps the seeded tenant between runs in this directory; it is rebuilt when the package sources change. Use a directory on disk, not a RAM-backed `/tmp`. |
| `CHURN_TEST_SERVE_WORKERS` | The browser tests start the server with this many processes (`serve --workers N`); default 1. |
| `CHURN_TEST_SENTIMENT_MODEL_DIR` | A directory that holds the fetched sentiment model (`<data dir>/models/sentiment`). Without it the test that uses the real model is skipped, or fails in strict mode. |
| `CHURN_TEST_SCREENSHOT_DIR` | The browser tests save a screenshot of every screen for every role, desktop and phone, in this directory. |
| `PLAYWRIGHT_BROWSERS_PATH` | Playwright's own variable: where Chromium is installed. |

Every test names the requirements it verifies (`@pytest.mark.req("REQ-ML-04")`). The test run writes them into its
JUnit report, and one command turns the report into the traceability matrix. It fails when a requirement has no
passing test:

```bash
python -m pytest --junitxml=report.xml
python scripts/build_traceability.py --junit report.xml
```

## Verifying a release

A release archive carries `MANIFEST.json`: every file with its size and SHA-256, the commit it was built from, and
the test run and traceability result it was built with. In the unpacked archive:

```bash
python3 scripts/build_manifest.py --check
```

exits 0 when every file is what the manifest says, and lists missing, changed or unlisted files otherwise.
A release is built from a clean checkout with:

```bash
python scripts/build_manifest.py --junit report.xml --require-clean --zip release/churn-platform-1.2.0.zip
```

## Repository

```
src/churn_platform/     the application
  api/                  HTTP API (FastAPI)
  services/             ingestion, features, training, evaluation, retention, experiments, monitoring, …
  worker/               background job runner
  models/, migrations/  database schema and its migrations
  web/                  the web interface (no build step)
tests/                  the test suite; tests/e2e drives a real browser
scripts/                traceability matrix, release manifest, wheel check, CRM contract check, load test
docs/                   limitations, defect log, signals, orchestration, outbound, security operations, CRM set-up,
                        the 1.1.0 baseline, registers and reports, traceability catalogue and matrix, the brief
deploy/airflow/         DAG that runs the nightly work step by step
Dockerfile, docker-compose.yml, .env.example
```
