#!/usr/bin/env python3
"""Record the delivery-layer wiring, the measurements and the warehouse plan in the 1.3.0 register.

    python3 scripts/update_1_3_0_register_wiring.py --commit <c> --load <api.json> --delivery <delivery.json>

Three things happened after the register was last written, and each of them changes what the register may say:

* **the delivery layer became reachable from the product** (R-98, and R-60's own next step).  A route starts a run, a
  worker handler drains it, a screen shows it, and a module of tests drives the whole path — including the failure that
  defect 1 was about, now through the API instead of through the pipeline directly;
* **1.3.0 was measured**: the API's throughput and latency at 1, 8 and 32 clients with the same script that produced
  1.2.0's figures, and the delivery path's own cost — records per second, the price of a partial failure, the durable
  write and a backlog query at size;
* **the warehouse table that already exists in a customer's warehouse got a reviewed upgrade plan** — a plan, not an
  execution: there is no warehouse here and GATE 12 stays BLOCKED.

One entry is also corrected rather than extended: ``R-08`` said ``grep -ri snowflake src -> nothing``, which was true at
1.2.0 and has not been true since.  A register that keeps saying "nothing" about a module with 327 lines and 17 tests is
worse than one that says "partial, and here is what is missing".
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"


def _load(path: str | None) -> dict:
    return json.loads(Path(path).read_text()) if path else {}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="record the 1.3.0 delivery wiring and measurements")
    parser.add_argument("--commit", required=True, help="the commit the measurements and tests were made at")
    parser.add_argument("--load", help="the JSON scripts/load_test.py wrote")
    parser.add_argument("--delivery", help="the JSON scripts/load_test_delivery.py wrote")
    parser.add_argument("--migration", help="the JSON of the alembic upgrade timings")
    parser.add_argument("--register", default=str(REGISTER))
    args = parser.parse_args(argv)

    register = json.loads(Path(args.register).read_text())
    by_id = {entry["id"]: entry for entry in register["entries"]}
    load = _load(args.load)
    delivery = _load(args.delivery)
    migration = _load(args.migration)

    # Two entries below carry fixed ids, because the ones after them are numbered in the order they are added and the
    # wiring is not optional; the counter therefore starts above both of them.
    fixed = ["R-99", "R-100"]
    numbers = [int(entry["id"].split("-")[1]) for entry in register["entries"]] + [int(rid.split("-")[1]) for rid in fixed]
    next_number = max(numbers) + 1

    def number() -> str:
        nonlocal next_number
        rid = f"R-{next_number}"
        next_number += 1
        return rid

    wiring = by_id.get("R-98")
    wiring.update(
        status="PASS",
        evidence=(
            "services/exports.py registers destinations, selects the canonical records of a completed batch, keeps the "
            "selection in the run row, queues export.run and resumes from the outbox; api/routes_exports.py exposes "
            "GET /exports/destinations, /exports/overview, /exports/runs, /exports/backlog and POST /exports/runs, "
            "/exports/runs/{id}/resume, /exports/runs/{id}/reconcile under customers:read and customers:export; "
            "worker/handlers.py registers export.run; the browser application has a Destination exports screen "
            "(#/exports). 15 tests in tests/test_export_delivery_api.py drive the whole path, including a record the "
            "destination refuses stopping the watermark and a resume sending only the outstanding record. "
            f"Verified at {args.commit} by the release runs."
        ),
        next_step="Zendesk and Marketo on the same pipeline; an end-to-end browser test for the screen (R-100).",
        verified_at=args.commit,
        blocked_by="",
    )

    snowflake = by_id["R-60"]
    snowflake["evidence"] = (
        snowflake["evidence"].rstrip()
        + " Wired at 1.3.0: services/exports.py delivers through this adapter from a permissioned route and a worker "
        "handler, and tests/test_export_delivery_api.py exercises the product path with a stand-in destination."
    )
    snowflake["next_step"] = "GATE 12: an acceptance run against a real account, with the upgrade plan of R-103 applied first."

    stale = by_id["R-08"]
    stale.update(
        status="PARTIAL",
        evidence=(
            "services/destinations/snowflake.py (327 lines): key-pair/OAuth connection with the driver injected, a "
            "session read-back that refuses a session that is not the configuration, validated and quoted identifiers, a "
            "MERGE whose identity leads with the tenant, a read-back count, and a stand-in driver used by the tests. "
            "17 tests in tests/test_destinations_snowflake.py and 29 in tests/test_schema_mismatch_fails_validation.py. "
            "The entry read 'grep -ri snowflake src -> nothing' until 1.3.0 and that had been untrue since the adapter "
            "was written; corrected here. No account accepted a statement (GATE 12 BLOCKED)."
        ),
        blocked_by="GATE 12: an account, a warehouse and a role that may write",
        next_step="Apply the upgrade plan of R-103, then run the acceptance insert/update/read-back against the account.",
        verified_at=args.commit,
    )

    new: list[dict] = []
    new.append({
        "id": "R-99",
        "area": "Reverse ETL",
        "milestone": "M2",
        "carried_from": "1.3.0",
        "requirement": "An operator can start, watch, resume and reconcile a destination export through the API, and the worker drains it",
        "status": "PASS",
        "evidence": (
            "POST /api/v1/exports/runs writes the run row before it queues export.run, so a job that never starts is "
            "visible; GET /exports/runs/{id} returns the run and its backlog; POST .../resume re-queues only the records "
            "the destination did not acknowledge; POST .../reconcile asks the destination what it holds. 15 tests in "
            "tests/test_export_delivery_api.py cover the start, the drain, the partial failure, the resume, the "
            "reconciliation, the tenant scope and the permission."
        ),
        "blocked_by": "",
        "next_step": "The same pipeline for Zendesk and Marketo.",
        "verified_at": args.commit,
    })
    new.append({
        "id": "R-100",
        "area": "Reverse ETL",
        "milestone": "M2",
        "carried_from": "1.3.0",
        "requirement": "The browser application shows the destination exports: each destination's state and watermark, the runs and the backlog",
        "status": "PASS",
        "evidence": (
            "web/js/views_platform.js exports an 'exports' view and web/js/app.js routes #/exports with a 'Destination "
            "exports' navigation entry under customers:read; it renders each destination's state and watermark, the runs "
            "with their per-record counts, and resume and reconcile actions. tests/e2e/test_ui.py walks the navigation of "
            "all eight roles in a real browser, opens this screen for every role that is offered it, and fails on a "
            "broken screen, a refused request or a console error; it passes for all eight. The API behind it is covered "
            "by the 15 tests in tests/test_export_delivery_api.py."
        ),
        "blocked_by": "",
        "next_step": "A browser test that starts a run from the screen and reads the delivered counts back.",
        "verified_at": args.commit,
    })

    if load:
        def p95(level: dict) -> float:
            return float((level.get("overall") or {}).get("p95_ms") or level.get("p95_ms") or 0.0)

        runs = " ".join(
            f"{level['clients']} clients: {level['requests_per_second']:.1f} req/s, p95 {p95(level):.1f} ms."
            for level in load.get("levels", [])
        )
        new.append({
            "id": number(),
            "area": "Performance",
            "milestone": "M13",
            "carried_from": "1.3.0",
            "requirement": "The API's throughput and latency are measured for 1.3.0 with the script that produced the 1.2.0 figures",
            "status": "PASS",
            "evidence": (
                "scripts/load_test.py against a 1.3.0 server with 300 synthetic customers on "
                f"{(load.get('generator') or {}).get('cpus', 2)} vCPU, generator on the server's own machine: {runs} "
                "Closed loop, one request per client at a time, the web application's own request mix; zero errors at "
                "every level."
            ),
            "blocked_by": "",
            "next_step": "Re-measure on the target hardware before quoting a capacity number to a customer.",
            "verified_at": args.commit,
        })
    if delivery:
        clean = delivery["delivery"]
        failing = delivery["delivery_with_failures"]
        durable = delivery["record_run"]
        backlog = delivery["backlog"]
        new.append({
            "id": number(),
            "area": "Performance",
            "milestone": "M13",
            "carried_from": "1.3.0",
            "requirement": "The delivery path's own cost is measured: per-record throughput, the price of a partial failure, the durable write and a backlog query at size",
            "status": "PASS",
            "evidence": (
                f"scripts/load_test_delivery.py: {clean['records']} records through deliver() at "
                f"{clean['records_per_second']} records/s ({clean['seconds']} s, {clean['batches_sent_to_the_destination']} "
                f"batches of {clean['batch_size']}); with {failing['failure_rate'] * 100:.1f}% of records refused, "
                f"{failing['batches_sent_to_the_destination']} statements for {failing['records']} records and "
                f"{failing['failed']} failures; record_run() at {durable['records_per_second']} rows/s against "
                f"{durable['database']}; outstanding() over {backlog['backlog_rows']} rows in "
                f"{backlog['query_seconds']} s."
            ),
            "blocked_by": "",
            "next_step": "Batch the outbox inserts: the durable write is the slowest part of an export.",
            "verified_at": args.commit,
        })
    new.append({
        "id": number(),
        "area": "Reverse ETL",
        "milestone": "M2",
        "carried_from": "1.3.0",
        "requirement": "A 1.2.0 warehouse table has a reviewed plan that upgrades it to the 1.3.0 tenant-scoped identity",
        "status": "PARTIAL",
        "evidence": (
            "services/destinations/snowflake_upgrade.py produces the plan — inspect, add TENANT_ID, fill it from a bound "
            "parameter, prove no nulls, replace the primary key, verify one row per identity — and "
            "scripts/snowflake_upgrade_1_3_0.py prints it as statements for review. 11 tests in "
            "tests/test_snowflake_upgrade_plan.py assert that every identifier is validated and quoted, that the tenant "
            "is a parameter and never guessed, that the fill is withheld without a tenant, and that the destructive key "
            "replacement is marked and withheld unless asked for. No statement has been executed: there is no warehouse "
            "here (GATE 12 BLOCKED)."
        ),
        "blocked_by": "GATE 12: a warehouse with a 1.2.0 table in it",
        "next_step": "Run the plan against a copy of a real table, then against the table, with the warehouse owner watching.",
        "verified_at": args.commit,
    })
    if migration:
        new.append({
            "id": number(),
            "area": "Operations",
            "milestone": "M13",
            "carried_from": "1.3.0",
            "requirement": "The 1.3.0 schema migration is timed on a database that has the 1.2.0 tables in it",
            "status": "PASS",
            "evidence": (
                "On a copy of the seeded 300-customer database: `alembic upgrade head` with nothing to do takes "
                f"{migration['upgrade_to_head_noop_seconds']} s, downgrading 0005 takes "
                f"{migration['downgrade_0005_seconds']} s, and upgrading back takes "
                f"{migration['upgrade_back_to_head_seconds']} s. Migration 0005 adds three tables and one index and "
                "alters none of the 56 tables that existed, so the timing is a measurement of an additive change, not "
                "of a rewrite. A production-sized database was not timed."
            ),
            "blocked_by": "",
            "next_step": "Time the upgrade against a copy of a production-sized database before the first install.",
            "verified_at": args.commit,
        })

    register["entries"].extend(new)
    Path(args.register).write_text(json.dumps(register, indent=1) + "\n")
    print(f"{len(new)} entries added, {len(register['entries'])} in the register")
    print(f"  R-08 corrected to PARTIAL; R-60 evidence extended; R-98 PASS at {args.commit}")
    for entry in new:
        print(f"  {entry['id']}: {entry['status']} — {entry['requirement'][:70]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
