#!/usr/bin/env python3
"""Build ``docs/1_3_0_REQUIREMENT_MATRIX.md`` from the register and the tests.

    python3 scripts/build_1_3_0_matrix.py            # write the matrix
    python3 scripts/build_1_3_0_matrix.py --check     # fail when the document on disk is stale

The matrix answers, for every requirement, one question the traceability document does not: **what would catch this if
it broke?**  It is built from two files, neither of which is written by hand:

* ``docs/1_3_0_requirements.json`` — the requirement, its status, its evidence and the commit it was verified at;
* the tests themselves — every test module declares ``pytestmark = pytest.mark.req("REQ-…")``, and the matrix maps each
  historical requirement id to the modules and test counts that name it.

A requirement with a PASS and no test naming it is reported in a section of its own rather than being quietly given a
dash.  That is the difference between a matrix and a decoration.

The historical ids (``REQ-…``, 58 of them, from ``docs/traceability/requirements.toml``) and the 1.3.0 ids (``R-nn``,
in the register) are kept apart on purpose: the brief's requirements are what the PDF asked for, and the register's
entries are how this release tracks them.  Merging the two numbering schemes would destroy the mapping to the PDF.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"
DOCUMENT = ROOT / "docs" / "1_3_0_REQUIREMENT_MATRIX.md"
TESTS = ROOT / "tests"
CATALOGUE = ROOT / "docs" / "traceability" / "requirements.toml"
REQ_RE = re.compile(r"REQ-[A-Z]+-\d{2}")


def catalogue() -> dict[str, dict[str, str]]:
    """The brief's own requirement catalogue: id, title, statement, the sections it comes from."""
    if not CATALOGUE.exists():
        return {}
    text = CATALOGUE.read_text()
    entries: dict[str, dict[str, str]] = {}
    current: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if stripped == "[[requirement]]":
            if current.get("id"):
                entries[current["id"]] = current
            current = {}
        elif stripped.startswith("id ="):
            current["id"] = stripped.split("=", 1)[1].strip().strip('"')
        elif stripped.startswith("title ="):
            current["title"] = stripped.split("=", 1)[1].strip().strip('"')
        elif stripped.startswith("brief ="):
            current["brief"] = stripped.split("=", 1)[1].strip()
        elif stripped.startswith("statement ="):
            current["statement"] = stripped.split("=", 1)[1].strip().strip('"')
        elif stripped.startswith('"""') and current.get("id") and "statement" not in current:
            current["statement"] = stripped.strip('"')
    if current.get("id"):
        entries[current["id"]] = current
    return entries


def tests_by_requirement() -> tuple[dict[str, dict[str, int]], list[str]]:
    """Which modules name which requirement, and how many tests each module holds.  No test is counted twice."""
    mapping: dict[str, dict[str, int]] = defaultdict(dict)
    unnamed: list[str] = []
    for path in sorted(TESTS.rglob("test_*.py")):
        tree = ast.parse(path.read_text())
        named: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(getattr(target, "id", "") == "pytestmark" for target in node.targets):
                for call in ast.walk(node.value):
                    if isinstance(call, ast.Call) and getattr(call.func, "attr", "") == "req":
                        for argument in call.args:
                            if isinstance(argument, ast.Constant):
                                named.update(REQ_RE.findall(str(argument.value)))
        count = sum(1 for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))
        relative = path.relative_to(ROOT).as_posix()
        if not named:
            unnamed.append(relative)
        for requirement in named:
            mapping[requirement][relative] = count
    return mapping, unnamed


#: the brief's requirement families, and the register areas that carry them
FAMILY = {
    "REQ-DATA": ("Real data", "Database", "Reverse ETL"),
    "REQ-ML": ("MLflow", "Performance", "Monitoring", "Regression"),
    "REQ-SIG": ("Sentiment", "Feature adoption"),
    "REQ-AN": ("Performance",),
    "REQ-ACT": ("CRM", "Reverse ETL", "Email", "SMS", "Push"),
    "REQ-OPS": ("Airflow", "Operations", "Deployment", "Performance"),
    "REQ-SEC": ("Security", "Privacy", "SSO"),
    "REQ-GOV": ("Governance", "Privacy"),
    "REQ-QA": ("Release", "Regression"),
}


def family_of(requirement: str) -> str:
    return requirement.rsplit("-", 1)[0]


def build() -> str:
    register = json.loads(REGISTER.read_text())
    brief = catalogue()
    mapping, unnamed = tests_by_requirement()
    lines = [
        "# 1.3.0 — the requirement matrix, and what would catch a regression",
        "",
        "Generated from `docs/1_3_0_requirements.json`, `docs/traceability/requirements.toml` and the test modules by",
        "`scripts/build_1_3_0_matrix.py`. Do not edit: run the script, or `--check` fails.",
        "",
        "Two numbering schemes are kept apart. The brief's 58 requirements are `REQ-…` and come from",
        "`docs/traceability/requirements.toml`; they are what the PDF asked for and they must not be renumbered. The",
        "1.3.0 register's entries are `R-nn`; they are how this release tracks the work, including the requirements the",
        "1.3.0 brief added. A test may only name a `REQ-…` id, and the traceability tool enforces that: a test naming",
        "an id the catalogue does not hold is a build failure, not a typo.",
        "",
        "## The brief's requirements",
        "",
        "| Id | Requirement | The register's entries for its area | Modules that name it | Tests behind it |",
        "|---|---|---|---|---|",
    ]
    carried = [entry for entry in register["entries"] if str(entry.get("carried_from")) == "1.2.0"]
    by_brief: dict[str, list[dict]] = defaultdict(list)
    for entry in register["entries"]:
        for requirement in REQ_RE.findall(str(entry.get("requirement", "")) + " " + str(entry.get("evidence", ""))):
            by_brief[requirement].append(entry)
    for requirement, meta in brief.items():
        modules = mapping.get(requirement, {})
        areas = FAMILY.get(family_of(requirement), ())
        tally: dict[str, int] = defaultdict(int)
        for entry in register["entries"]:
            if entry.get("area") in areas:
                tally[entry["status"]] += 1
        summary = ", ".join(f"{count} {status}" for status, count in sorted(tally.items())) or "no register entries"
        lines.append(
            f"| {requirement} | {meta.get('title', '')} | {summary} | "
            f"{', '.join(f'`{module}`' for module in sorted(modules)) or '—'} | "
            f"{sum(modules.values()) or '—'} |"
        )
    lines += [
        "",
        "## The 1.3.0 register's entries",
        "",
        "| Id | Area | Status | Verified at | Evidence | Tests in its area |",
        "|---|---|---|---|---|---|",
    ]
    tests_by_area: dict[str, int] = defaultdict(int)
    for requirement, modules in mapping.items():
        for area in FAMILY.get(family_of(requirement), ()):
            tests_by_area[area] += sum(modules.values())
    for entry in register["entries"]:
        caught = tests_by_area.get(entry.get("area", ""), 0)
        lines.append(
            f"| {entry['id']} | {entry.get('area', '')} | **{entry['status']}** | "
            f"`{entry.get('verified_at') or '—'}` | {str(entry.get('evidence', '')).replace('|', chr(92) + '|')} | "
            f"{caught or '—'} |"
        )
    lines += [
        "",
        "## Requirements named by no test module",
        "",
        "A PASS with no test naming it is not automatically wrong — some requirements are met by a document, a",
        "migration or a script — but it is not *covered*, and this list is where that is visible instead of hidden.",
        "",
    ]
    uncovered = sorted(requirement for requirement in brief if requirement not in mapping)
    lines += [f"- {requirement}" for requirement in uncovered] or ["- none"]
    lines += [
        "",
        f"Test modules that name no requirement at all: **{len(unnamed)}**.",
        "",
        *(f"- `{path}`" for path in unnamed),
        "",
        "## Where the numbers come from",
        "",
        f"- register entries: **{len(register['entries'])}**",
        f"- brief requirements: **{len(brief)}**",
        f"- brief requirements named by at least one test module: **{len(brief) - len(uncovered)} of {len(brief)}**",
        f"- test modules naming a brief requirement: **{len({module for modules in mapping.values() for module in modules})}**",
        f"- test modules naming none: **{len(unnamed)}**",
        f"- register entries carried from 1.2.0: **{len(carried)}**",
        "",
        "The two numbering schemes are not interchangeable: a `REQ-…` id is the brief's, an `R-nn` id is this release's.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="build the 1.3.0 requirement matrix")
    parser.add_argument("--check", action="store_true", help="fail when the document on disk is stale")
    args = parser.parse_args(argv)
    document = build()
    if args.check:
        current = DOCUMENT.read_text() if DOCUMENT.exists() else ""
        if current != document:
            print(f"{DOCUMENT.relative_to(ROOT)} is out of date; run scripts/build_1_3_0_matrix.py", file=sys.stderr)
            return 1
        print(f"{DOCUMENT.relative_to(ROOT)} is up to date")
        return 0
    DOCUMENT.write_text(document)
    print(f"wrote {DOCUMENT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
