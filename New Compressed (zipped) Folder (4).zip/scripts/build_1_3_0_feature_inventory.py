#!/usr/bin/env python3
"""Build ``docs/1_3_0_FEATURE_INVENTORY.md`` from the register and the source.

    python3 scripts/build_1_3_0_feature_inventory.py           # write
    python3 scripts/build_1_3_0_feature_inventory.py --check    # fail when stale

The inventory answers "what can this installation actually do, and what is only described?"  It is built from three
sources and nothing else:

* ``docs/1_3_0_requirements.json`` — every requirement with a status, an area and a milestone;
* ``docs/traceability/requirements.toml`` — the brief's 38 requirements, which are the *customer-facing* capabilities
  rather than this release's work items;
* the source tree — for each area, the modules that exist, named from the tree rather than from memory.

The point of generating it is that a hand-written inventory always drifts towards optimism: a feature that was deleted
stays in the list because nobody removes a line they once earned.  Here a module that does not exist cannot be listed,
and a requirement whose status is NOT_IMPLEMENTED appears under "not built" with its area beside it.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"
DOCUMENT = ROOT / "docs" / "1_3_0_FEATURE_INVENTORY.md"

#: the register's areas, and where a reader would find them in the source (checked, not assumed)
AREA_SOURCE = {
    "CRM": ("src/churn_platform/services/crm.py", "src/churn_platform/services/crm_oauth.py",
            "src/churn_platform/api/routes_platform.py"),
    "Reverse ETL": ("src/churn_platform/services/reverse_etl.py", "src/churn_platform/services/export_record.py",
                    "src/churn_platform/services/destinations/base.py", "src/churn_platform/services/destinations/snowflake.py",
                    "src/churn_platform/services/export_outbox.py", "src/churn_platform/migrations/versions/0005_export_outbox.py"),
    "Email": ("src/churn_platform/services/notify.py", "src/churn_platform/api/routes_platform.py"),
    "SMS": ("src/churn_platform/services/notify.py",),
    "Push": ("src/churn_platform/services/notify.py",),
    "Airflow": ("deploy/airflow/churn_nightly_dag.py", "src/churn_platform/services/orchestration.py"),
    "Security": ("src/churn_platform/security.py", "src/churn_platform/netguard.py", "src/churn_platform/services/auth.py"),
    "SSO": ("src/churn_platform/services/sso.py",),
    "Privacy": ("src/churn_platform/services/ingestion.py", "src/churn_platform/services/audit.py"),
    "Sentiment": ("src/churn_platform/services/sentiment.py", "src/churn_platform/services/annotations.py"),
    "Feature adoption": ("src/churn_platform/services/adoption.py",),
    "MLflow": ("src/churn_platform/services/mlflow_mirror.py", "src/churn_platform/services/registry.py"),
    "Real data": ("src/churn_platform/services/ingestion.py", "src/churn_platform/services/readers.py"),
    "Release": ("scripts/build_1_3_0_register.py", "scripts/record_test_run.py", "scripts/build_1_3_0_matrix.py"),
    "Performance": ("docs/1_2_0_PERFORMANCE_REPORT.md",),
    "Database": ("src/churn_platform/db.py", "src/churn_platform/dbadmin.py", "src/churn_platform/migrations/versions"),
    "Deployment": ("Dockerfile", "docker-compose.yml"),
    "Frontend": ("src/churn_platform/web/js/app.js", "src/churn_platform/api/app.py"),
    "Monitoring": ("src/churn_platform/services/monitoring.py", "src/churn_platform/services/retraining.py"),
    "Regression": ("docs/1_3_0_EXISTING_FEATURE_REGRESSION.md",),
    "Operations": ("src/churn_platform/worker/runner.py", "src/churn_platform/backup.py"),
    "Governance": ("src/churn_platform/services/audit.py", "src/churn_platform/services/policies.py"),
}
STATUS_ORDER = ("PASS", "PARTIAL", "BLOCKED", "NOT_IMPLEMENTED", "NOT_TESTED", "NOT_APPLICABLE")


def build() -> str:
    register = json.loads(REGISTER.read_text())
    entries = register["entries"]
    by_area: dict[str, list[dict]] = defaultdict(list)
    for entry in entries:
        by_area[entry.get("area", "?")].append(entry)
    tally = Counter(entry["status"] for entry in entries)
    lines = [
        "# 1.3.0 — feature inventory",
        "",
        "Generated from `docs/1_3_0_requirements.json` and the source tree by",
        "`scripts/build_1_3_0_feature_inventory.py`; run the script after changing either, or `--check` fails.",
        "",
        "A feature is listed as **working** only where its requirement is PASS *and* the module that implements it exists",
        "in the tree at the commit this document was generated from. A requirement that is PARTIAL is listed with what is",
        "missing in the register's own words; NOT_IMPLEMENTED appears under \"not built\" rather than being left out.",
        "",
        "## The installation, in numbers",
        "",
        f"- requirements in the register: **{len(entries)}** ({len({entry.get('carried_from') for entry in entries})} release"
        " generations: 1.2.0's 58 and the 1.3.0 additions)",
        *(f"- **{status}**: {tally.get(status, 0)}" for status in STATUS_ORDER),
        f"- areas: **{len(by_area)}**",
        "",
        "## By area",
        "",
        "| Area | Requirements | Working now | Partial | Blocked | Not built | Where it lives |",
        "|---|---|---|---|---|---|---|",
    ]
    for area in sorted(by_area):
        group = by_area[area]
        counts = Counter(entry["status"] for entry in group)
        sources = AREA_SOURCE.get(area, ())
        existing = [path for path in sources if (ROOT / path).exists()]
        missing = [path for path in sources if not (ROOT / path).exists()]
        where = ", ".join(f"`{path}`" for path in existing) or "—"
        if missing:
            where += " · missing: " + ", ".join(f"`{path}`" for path in missing)
        lines.append(
            f"| {area} | {len(group)} | {counts.get('PASS', 0)} | {counts.get('PARTIAL', 0)} | "
            f"{counts.get('BLOCKED', 0)} | {counts.get('NOT_IMPLEMENTED', 0)} | {where} |"
        )
    lines += ["", "## What works now", "", "Requirements marked PASS, with the evidence the register records.", ""]
    passing = [entry for entry in entries if entry["status"] == "PASS"]
    lines += ["| Id | Area | Requirement | Evidence | Verified at |", "|---|---|---|---|---|"]
    for entry in passing:
        lines.append(
            f"| {entry['id']} | {entry.get('area', '')} | {str(entry['requirement']).replace('|', chr(92) + '|')} | "
            f"{str(entry.get('evidence', '')).replace('|', chr(92) + '|')} | `{entry.get('verified_at', '—')}` |"
        )
    lines += ["", "## What is partial, and what is missing from it", ""]
    lines += ["| Id | Area | Requirement | What is missing |", "|---|---|---|---|"]
    for entry in entries:
        if entry["status"] == "PARTIAL":
            lines.append(
                f"| {entry['id']} | {entry.get('area', '')} | {str(entry['requirement']).replace('|', chr(92) + '|')} | "
                f"{str(entry.get('next_step', '')).replace('|', chr(92) + '|')} |"
            )
    lines += ["", "## What is blocked, and by whom", ""]
    lines += ["| Id | Area | Requirement | Blocked by |", "|---|---|---|---|"]
    for entry in entries:
        if entry["status"] == "BLOCKED":
            lines.append(
                f"| {entry['id']} | {entry.get('area', '')} | {str(entry['requirement']).replace('|', chr(92) + '|')} | "
                f"{str(entry.get('blocked_by', '')).replace('|', chr(92) + '|')} |"
            )
    lines += ["", "## Not built", ""]
    lines += ["| Id | Area | Requirement | Next step |", "|---|---|---|---|"]
    for entry in entries:
        if entry["status"] == "NOT_IMPLEMENTED":
            lines.append(
                f"| {entry['id']} | {entry.get('area', '')} | {str(entry['requirement']).replace('|', chr(92) + '|')} | "
                f"{str(entry.get('next_step', '')).replace('|', chr(92) + '|')} |"
            )
    lines += [
        "",
        "## How to read this document",
        "",
        "- **Working now** means the code exists, a test exercises it at the commit in the register, and the register's",
        "  evidence names where. It does not mean a vendor has accepted anything: that is what the fifteen gates are for,",
        "  and a gate marked BLOCKED says the vendor is missing rather than that the work is undone.",
        "- **Partial** is not a softer word for done: the register's `next_step` is the work that remains, written so that",
        "  someone else could pick it up.",
        "- An area with more than one row of \"not built\" is an area where the PDF asked for something this release did",
        "  not reach. It is listed, not omitted.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="build the 1.3.0 feature inventory")
    parser.add_argument("--check", action="store_true", help="fail when the document on disk is stale")
    args = parser.parse_args(argv)
    document = build()
    if args.check:
        current = DOCUMENT.read_text() if DOCUMENT.exists() else ""
        if current != document:
            print(f"{DOCUMENT.relative_to(ROOT)} is out of date; run scripts/build_1_3_0_feature_inventory.py", file=sys.stderr)
            return 1
        print(f"{DOCUMENT.relative_to(ROOT)} is up to date")
        return 0
    DOCUMENT.write_text(document)
    print(f"wrote {DOCUMENT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
