#!/usr/bin/env python3
"""Fail when something that looks like a credential is committed.

The rule set is deliberately narrow and its false-positive list empty: a scan that cries wolf is turned off, and a
scan that is turned off protects nothing.  It looks for the shapes of the secrets this project could actually leak —
provider keys, private keys, bearer tokens, passwords in a URL — plus any ``.env`` file that is not the example.

    python scripts/scan_secrets.py            # scan the working tree
    python scripts/scan_secrets.py --staged   # scan only what git has staged (used before a commit)
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "build", "dist", "release", ".pytest_cache", ".ruff_cache"}
SKIP_PATTERNS = ("*.egg-info",)
SKIP_SUFFIXES = {".zip", ".pyc", ".onnx", ".png", ".jpg", ".jpeg", ".gz", ".pdf", ".whl"}
# Where the pattern cannot tell a live credential from a written-down placeholder, and a person has looked.
# Each entry says why.  Anything not listed here fails the build.
SUPPRESSED: dict[tuple[str, str], str] = {
    ("README.md", "password in a URL"): "connection-string example: 'user:password' are the placeholders",
    ("docs/", "password in a URL"): "documented examples with placeholder credentials",
    (".env.example", "password in a URL"): "the example environment file: the point of the file is a placeholder",
    ("tests/", "password in a URL"): "test fixtures: a placeholder, or the loopback PostgreSQL of the CI service",
    (".github/workflows/", "password in a URL"): "the CI service container's loopback database, not a secret",
}
PATTERNS = (
    ("private key", re.compile(r"-----BEGIN (RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----")),
    ("AWS access key id", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("SendGrid key", re.compile(r"\bSG\.[A-Za-z0-9_\-]{16,}\.[A-Za-z0-9_\-]{16,}\b")),
    ("Twilio key", re.compile(r"\bSK[0-9a-fA-F]{32}\b")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b")),
    ("Slack token", re.compile(r"\bxox[abprs]-[0-9A-Za-z\-]{10,}")),
    ("bearer token in a file", re.compile(r"(?i)\bauthorization\s*[:=]\s*['\"]?bearer\s+[A-Za-z0-9._\-]{20,}")),
    ("password in a URL", re.compile(r"\b[a-z][a-z0-9+.\-]*://[^\s:/@]+:[^\s:/@]{6,}@")),
)
def _suppressed(relative: str, label: str) -> bool:
    return any((relative == path or relative.startswith(path)) and wanted == label for (path, wanted) in SUPPRESSED)


def files(staged: bool) -> list[Path]:
    if staged:
        out = subprocess.run(["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"], cwd=ROOT, capture_output=True, text=True, check=False)
        return [ROOT / name for name in out.stdout.split() if (ROOT / name).is_file()]
    found = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in SKIP_DIRS for part in path.parts) or any(part.endswith(".egg-info") for part in path.parts):
            continue
        if path.suffix.lower() in SKIP_SUFFIXES or any(path.match(pattern) for pattern in SKIP_PATTERNS):
            continue
        found.append(path)
    return found


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    findings, suppressed = [], []
    for path in files("--staged" in argv):
        relative = path.relative_to(ROOT).as_posix()
        if path.name.startswith(".env") and path.name != ".env.example":
            findings.append(f"{relative}: a .env file must not be committed")
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for label, pattern in PATTERNS:
            for match in pattern.finditer(text):
                if _suppressed(relative, label):
                    suppressed.append(f"{relative}: {label}")
                    continue
                line = text.count("\n", 0, match.start()) + 1
                findings.append(f"{relative}:{line}: {label}")
    for finding in findings:
        print(finding)
    if suppressed:
        print(f"suppressed with a written reason: {len(suppressed)}")
    if findings:
        print(f"{len(findings)} possible credential(s) found", file=sys.stderr)
        return 1
    print("no credential found")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
