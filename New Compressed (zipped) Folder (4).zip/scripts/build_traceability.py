#!/usr/bin/env python3
"""Build the requirements traceability matrix from a test run.

    python scripts/build_traceability.py --junit report.xml [--junit more.xml]

Every test names the requirements it verifies (``@pytest.mark.req("REQ-...")``); pytest writes them into
the JUnit report as ``requirement`` properties.  This script joins the report(s) with the catalogue in
``docs/traceability/requirements.toml`` and writes ``TRACEABILITY.md`` and ``traceability.json`` next to it.

It exits with status 1, after writing the files, when the evidence is incomplete:

* a requirement has no passing test, or one of its tests failed;
* a test was skipped (unless ``--allow-skips``): a skipped test is missing evidence, not a pass;
* a test names a requirement that is not in the catalogue, or names none at all;
* the catalogue contradicts itself (duplicate identifier, a brief section pointing at an unknown requirement).

Only the standard library is used, so the script runs before the project is installed.
"""

from __future__ import annotations

import argparse
import json
import sys
import tomllib
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CATALOGUE = ROOT / "docs" / "traceability" / "requirements.toml"
COVERAGE = ("full", "partial", "context")
ORIGINS = ("brief", "derived")


@dataclass
class Test:
    name: str
    outcome: str  # passed | failed | skipped
    requirements: tuple[str, ...]
    report: str


@dataclass
class Evidence:
    tests: list[Test] = field(default_factory=list)
    reports: list[dict] = field(default_factory=list)

    def count(self, outcome: str) -> int:
        return sum(1 for t in self.tests if t.outcome == outcome)


def load_catalogue(path: Path) -> tuple[list[dict], list[dict], list[str]]:
    with path.open("rb") as handle:
        data = tomllib.load(handle)
    requirements, brief, problems = data.get("requirement", []), data.get("brief", []), []
    seen: set[str] = set()
    for req in requirements:
        missing = [key for key in ("id", "title", "origin", "brief", "statement") if key not in req]
        if missing:
            problems.append(f"catalogue: requirement {req.get('id', '?')} lacks {', '.join(missing)}")
            continue
        if req["id"] in seen:
            problems.append(f"catalogue: {req['id']} is listed twice")
        seen.add(req["id"])
        if req["origin"] not in ORIGINS:
            problems.append(f"catalogue: {req['id']} has origin '{req['origin']}' (expected one of {', '.join(ORIGINS)})")
        if req["origin"] == "brief" and not req["brief"]:
            problems.append(f"catalogue: {req['id']} claims to come from the brief but cites no section")
    sections = {entry.get("section") for entry in brief}
    for entry in brief:
        missing = [key for key in ("section", "topic", "coverage", "requirements", "note") if key not in entry]
        if missing:
            problems.append(f"catalogue: brief section {entry.get('section', '?')} lacks {', '.join(missing)}")
            continue
        if entry["coverage"] not in COVERAGE:
            problems.append(f"catalogue: brief section {entry['section']} has coverage '{entry['coverage']}'")
        if entry["coverage"] == "partial" and not entry["note"].strip():
            problems.append(f"catalogue: brief section {entry['section']} is partial but does not say what differs")
        for req_id in entry["requirements"]:
            if req_id not in seen:
                problems.append(f"catalogue: brief section {entry['section']} points at unknown requirement {req_id}")
    for req in requirements:
        for section in req.get("brief", []):
            if section not in sections:
                problems.append(f"catalogue: {req.get('id')} cites brief section '{section}', which has no [[brief]] entry")
    return requirements, brief, problems


def load_junit(paths: list[Path]) -> Evidence:
    evidence = Evidence()
    for path in paths:
        root = ET.parse(path).getroot()  # noqa: S314 - the reports are written by our own test run  # nosec B314
        suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
        for suite in suites:
            evidence.reports.append({"file": path.name, "timestamp": suite.get("timestamp", ""), "tests": int(suite.get("tests", 0))})
            for case in suite.iter("testcase"):
                if case.find("failure") is not None or case.find("error") is not None:
                    outcome = "failed"
                elif case.find("skipped") is not None:
                    outcome = "skipped"
                else:
                    outcome = "passed"
                reqs = tuple(sorted({p.get("value", "") for p in case.iter("property") if p.get("name") == "requirement"}))
                module = case.get("classname", "").removeprefix("tests.")
                evidence.tests.append(Test(f"{module}::{case.get('name', '')}", outcome, reqs, path.name))
    return evidence


def analyse(requirements: list[dict], brief: list[dict], evidence: Evidence, *, allow_skips: bool) -> tuple[dict, list[str]]:
    problems: list[str] = []
    known = {req["id"] for req in requirements}
    by_req: dict[str, list[Test]] = defaultdict(list)
    for test in evidence.tests:
        if not test.requirements:
            problems.append(f"test without a requirement: {test.name}")
        for req_id in test.requirements:
            if req_id not in known:
                problems.append(f"test {test.name} names unknown requirement {req_id}")
            by_req[req_id].append(test)
        if test.outcome == "failed":
            problems.append(f"failed test: {test.name}")
        elif test.outcome == "skipped" and not allow_skips:
            problems.append(f"skipped test (missing evidence): {test.name}")
    rows = []
    for req in requirements:
        tests = sorted(by_req.get(req["id"], []), key=lambda t: t.name)
        counts = {outcome: sum(1 for t in tests if t.outcome == outcome) for outcome in ("passed", "failed", "skipped")}
        if counts["failed"]:
            status = "FAILED"
        elif not counts["passed"]:
            status = "NO EVIDENCE"
            problems.append(f"{req['id']} has no passing test")
        elif counts["skipped"]:
            status = "verified (some tests skipped)" if allow_skips else "INCOMPLETE"
        else:
            status = "verified"
        rows.append({**req, "tests": [{"name": t.name, "outcome": t.outcome} for t in tests], "counts": counts, "status": status})
    status_of = {row["id"]: row["status"] for row in rows}
    sections = []
    for entry in brief:
        linked = [status_of.get(req_id, "NO EVIDENCE") for req_id in entry["requirements"]]
        sections.append({**entry, "verified": all(s.startswith("verified") for s in linked) if linked else None})
    totals = {outcome: evidence.count(outcome) for outcome in ("passed", "failed", "skipped")}
    result = {"reports": evidence.reports, "totals": {"tests": len(evidence.tests), **totals}, "requirements": rows, "brief": sections,
              "problems": problems, "complete": not problems}  # fmt: skip
    return result, problems


def _cell(text: str) -> str:
    return " ".join(str(text).split()).replace("|", "\\|")


def render(result: dict) -> str:
    totals = result["totals"]
    lines = [
        "# Requirements traceability matrix",
        "",
        "Generated by `scripts/build_traceability.py` from the JUnit report of a test run and the catalogue in",
        "`docs/traceability/requirements.toml`. Do not edit by hand: change the catalogue or the tests and run it again.",
        "",
        f"**Evidence:** {totals['tests']} tests: {totals['passed']} passed, {totals['failed']} failed, {totals['skipped']} skipped. "
        + "Reports: " + "; ".join(f"`{r['file']}` ({r['tests']} tests, started {r['timestamp'] or 'unknown'})" for r in result["reports"]) + ".",
        "",
        f"**Result:** {'every requirement is verified by passing tests.' if result['complete'] else 'INCOMPLETE, see the problems below.'}",
        "",
    ]
    if result["problems"]:
        lines += ["## Problems", ""] + [f"- {_cell(p)}" for p in result["problems"]] + [""]
    lines += [
        "## 1. The brief, section by section",
        "",
        "Coverage: **full** = built as written; **partial** = built with the stated difference; **context** = explanatory text.",
        "",
        "| Brief | Topic | Coverage | Requirements | Tests pass | Difference from the brief |",
        "|---|---|---|---|---|---|",
    ]
    for entry in result["brief"]:
        lines.append(f"| {_cell(entry['section'])} | {_cell(entry['topic'])} | {entry['coverage']} | {', '.join(entry['requirements']) or '-'} | "
                     f"{'-' if entry['verified'] is None else 'yes' if entry['verified'] else 'NO'} | {_cell(entry['note'])} |")  # fmt: skip
    lines += [
        "",
        "## 2. Requirements",
        "",
        "Origin: **brief** = stated in the brief; **derived** = not stated there, needed to run the system with real customer data.",
        "",
        "| Requirement | Title | Origin | Brief sections | Tests passed | Status |",
        "|---|---|---|---|---|---|",
    ]
    for row in result["requirements"]:
        counts = row["counts"]
        lines.append(f"| {row['id']} | {_cell(row['title'])} | {row['origin']} | {', '.join(row['brief']) or '-'} | "
                     f"{counts['passed']} of {len(row['tests'])} | {row['status']} |")  # fmt: skip
    lines += ["", "## 3. Tests per requirement", ""]
    for row in result["requirements"]:
        lines += [f"### {row['id']}: {_cell(row['title'])}", "", _cell(row["statement"]), ""]
        lines += [f"- {t['outcome']}: `{t['name']}`" for t in row["tests"]] or ["- no test"]
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--junit", action="append", required=True, type=Path, help="JUnit XML report of a test run (repeatable)")
    parser.add_argument("--catalogue", type=Path, default=CATALOGUE)
    parser.add_argument("--out", type=Path, help="Markdown matrix (default: TRACEABILITY.md next to the catalogue)")
    parser.add_argument("--json", type=Path, help="machine-readable result (default: traceability.json next to the catalogue)")
    parser.add_argument("--allow-skips", action="store_true", help="do not treat skipped tests as missing evidence (local runs)")
    args = parser.parse_args(argv)
    for path in [args.catalogue, *args.junit]:
        if not path.is_file():
            print(f"error: {path} does not exist", file=sys.stderr)
            return 2
    requirements, brief, catalogue_problems = load_catalogue(args.catalogue)
    result, problems = analyse(requirements, brief, load_junit(args.junit), allow_skips=args.allow_skips)
    result["problems"] = problems = catalogue_problems + problems
    result["complete"] = not problems
    out = args.out or args.catalogue.with_name("TRACEABILITY.md")
    as_json = args.json or args.catalogue.with_name("traceability.json")
    out.write_text(render(result), encoding="utf-8")
    as_json.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    verified = sum(1 for row in result["requirements"] if row["status"].startswith("verified"))
    print(f"{verified} of {len(result['requirements'])} requirements verified by {result['totals']['passed']} passing tests -> {out}")
    for problem in problems:
        print(f"problem: {problem}", file=sys.stderr)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
