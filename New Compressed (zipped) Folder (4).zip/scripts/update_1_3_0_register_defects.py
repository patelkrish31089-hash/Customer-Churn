#!/usr/bin/env python3
"""Record the M1 defect fixes in the 1.3.0 register, from the evidence the runs produced.

    python3 scripts/update_1_3_0_register_defects.py \
        --commit 0b81cad \
        --junit /var/tmp/release/final-a.xml /var/tmp/release/final-b.xml

Why a script and not an edit: the register is the release's only statement of what is true, and an entry typed by hand
carries numbers that nobody recomputed.  This one reads the JUnit files the suite actually produced, counts the tests in
the four regression modules, and writes those counts into the evidence text.  If a run is missing, it refuses to write
anything rather than inventing a number.

It touches only the entries it names and `meta`; everything else in the register is left exactly as it was, so a
hand-written status outside this milestone cannot be silently rewritten.
"""

from __future__ import annotations

import argparse
import json
import xml.etree.ElementTree as ElementTree  # nosec S314 - it parses the JUnit files the release runs produced, not untrusted input
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"

MODULES = {
    "watermark": "tests/test_failed_first_record_does_not_advance_watermark.py",
    "outbox": "tests/test_export_outbox.py",
    "tenant": "tests/test_tenant_id_prevents_crm_collisions.py",
    "schema": "tests/test_schema_mismatch_fails_validation.py",
    "release": "tests/test_release_validator_rejects_stale_evidence.py",
    "export_record": "tests/test_export_record.py",
    "snowflake": "tests/test_destinations_snowflake.py",
}


def junit_counts(paths: list[Path]) -> tuple[dict[str, int], dict[str, int]]:
    """Per-module case counts and the overall totals, from the JUnit files as produced."""
    if not paths:
        raise SystemExit("no JUnit file was given: the register will not be updated with invented numbers")
    totals: Counter[str] = Counter()
    per_module: dict[str, int] = dict.fromkeys(MODULES, 0)
    for path in paths:
        if not path.exists():
            raise SystemExit(f"{path} does not exist: the register will not be updated without the evidence")
        root = ElementTree.parse(path).getroot()  # noqa: S314 - parses the JUnit files the release runs produced  # nosec B314 - the files are the release runs' own JUnit output
        suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
        cases = [case for suite in suites for case in suite.iter("testcase")]
        totals["tests"] = max(totals["tests"], len(cases))
        totals["failures"] = max(totals["failures"], sum(1 for c in cases if c.find("failure") is not None))
        totals["errors"] = max(totals["errors"], sum(1 for c in cases if c.find("error") is not None))
        totals["skipped"] = max(totals["skipped"], sum(1 for c in cases if c.find("skipped") is not None))
        if not per_module["watermark"]:
            for name, module in MODULES.items():
                per_module[name] = sum(1 for case in cases if case.get("classname", "").startswith(module.replace("/", ".").removesuffix(".py")))
    return per_module, dict(totals)


def entry(**fields) -> dict:
    return fields


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="write the M1 defect entries into the 1.3.0 register")
    parser.add_argument("--commit", required=True, help="the commit the evidence was produced at")
    parser.add_argument("--junit", nargs="+", default=[], help="the JUnit files (one per run)")
    parser.add_argument("--register", default=str(REGISTER))
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    per_module, totals = junit_counts([Path(path) for path in args.junit])
    register = json.loads(Path(args.register).read_text())
    entries = {item["id"]: item for item in register["entries"]}
    commit = args.commit

    # --------------------------------------------------------------- the four defects
    additions = [
        entry(
            id="R-92", area="Reverse ETL", milestone="M1", carried_from="1.3.0",
            requirement=("A delivery run records what the destination acknowledged, per record, and its watermark is the "
                         "newest instant up to which every record of the stream was acknowledged, per tenant"),
            status="PASS",
            evidence=(f"services/destinations/base.py: RecordOutcome per record (PENDING/ACKNOWLEDGED/FAILED/QUARANTINED, "
                      f"attempts, error code and description, identity, idempotency key, payload digest), "
                      f"contiguous_watermark() walking acknowledged records in time order and stopping at the first "
                      f"outstanding one — records sharing an instant are a group, so an instant that is half-delivered "
                      f"does not advance the watermark — tenant_watermarks(), a checksum over exactly the acknowledged "
                      f"set, checkpoint_of()/resume(), and a batch that fails broken into single-record writes. "
                      f"{per_module['watermark']} tests in {MODULES['watermark']}, each failing if the old behaviour "
                      f"returns. Reproduced first: with C1 refused and C2 accepted, the 1.2.0 code took the watermark "
                      f"from C1 and the checksum over C1."),
            blocked_by="", next_step="M2: drain the outbox from a worker handler and expose the run through the API.",
        ),
        entry(
            id="R-93", area="Reverse ETL", milestone="M1", carried_from="1.3.0",
            requirement=("Per-record delivery state, the run record and the tenant checkpoint are persisted (migration "
                         "0005): a restarted run resumes what was not acknowledged instead of re-sending or skipping it"),
            status="PASS",
            evidence=(f"migrations/versions/0005_export_outbox.py creates export_runs, export_outbox and export_checkpoints "
                      f"— unique on (tenant, destination, run_id), (destination, idempotency_key) and (tenant, destination) "
                      f"respectively — additively, with a downgrade that drops exactly those three tables; "
                      f"services/export_outbox.py writes them, answers outstanding()/acknowledged_keys()/watermark_for(), "
                      f"advances the checkpoint only forwards, and refuses a run that mixes tenants. "
                      f"{per_module['outbox']} tests in {MODULES['outbox']}, the last of which upgrades, inspects and "
                      f"downgrades a real PostgreSQL 17 database and checks migration 0004's tables are intact."),
            blocked_by="", next_step="M2: call it from the run path once the destinations are reachable from the API.",
        ),
        entry(
            id="R-94", area="Reverse ETL", milestone="M1", carried_from="1.3.0",
            requirement=("The tenant is part of the canonical export record and of every key derived from it, so two "
                         "tenants' rows can never overwrite or deduplicate each other"),
            status="PASS",
            evidence=(f"services/export_record.py: tenant_id is the first field, required, and schema 1.1.0 says so; "
                      f"services/destinations/base.py identity() and idempotency_key() lead with it; "
                      f"services/destinations/snowflake.py's primary key and MERGE ON clause lead with TENANT_ID; "
                      f"from_prediction() refuses a prediction whose tenant cannot be established. "
                      f"{per_module['tenant']} tests in {MODULES['tenant']}. Reproduced first: identity(t1) == identity(t2) "
                      f"was True and tenant_id was absent from the schema."),
            blocked_by="", next_step="A warehouse created by an earlier 1.3.0 build needs the ALTER and backfill described in docs/1_3_0_KNOWN_LIMITATIONS.md.",
        ),
        entry(
            id="R-95", area="Reverse ETL", milestone="M1", carried_from="1.3.0",
            requirement=("A Snowflake connection is accepted only when the session is the configured one: account, region, "
                         "warehouse, database, schema and role are read back and compared, a value the session does not "
                         "report is a mismatch, TLS cannot be disabled, and configured identifiers are validated and quoted"),
            status="PASS",
            evidence=(f"services/destinations/snowflake.py: test_connection() reads CURRENT_VERSION/USER/ROLE/WAREHOUSE/"
                      f"DATABASE/SCHEMA/ACCOUNT/REGION and refuses any difference; a connector exception becomes a refusal "
                      f"with its kind; tls=False is refused before the network; quote() validates every configured name and "
                      f"every DDL, MERGE, COUNT and INSERT uses it. {per_module['schema']} tests in {MODULES['schema']}. "
                      f"Reproduced first: schema OTHER_SCHEMA against a configured PUBLIC reported ok=True. "
                      f"The statement shapes are verified locally; no Snowflake account exists here, so GATE 12 stays BLOCKED."),
            blocked_by="GATE 12: a Snowflake account, warehouse, database, schema and a write role to accept the statements",
            next_step="Run the acceptance script against a sandbox account and record what it returns.",
        ),
        entry(
            id="R-96", area="Release", milestone="M1", carried_from="1.3.0",
            requirement=("A release cannot pass on evidence from another commit, on a dirty tree, or on a suite that did "
                         "not run: the register's claim is compared with git and JUnit evidence must carry a sidecar"),
            status="PASS",
            evidence=(f"scripts/build_1_3_0_register.py: --release compares meta.source_commit with git HEAD, requires every "
                      f"PASS/PARTIAL/FAIL to be verified at that commit, refuses a dirty tree, requires at least one JUnit "
                      f"file with a .meta.json sidecar naming its commit and command and a digest that still matches, "
                      f"rejects failures, errors and skips, and requires two runs to agree test by test; one documented "
                      f"exception, a documentation-only commit above the evidence commit, is checked rather than assumed. "
                      f"scripts/record_test_run.py writes the sidecar. {per_module['release']} tests in {MODULES['release']}. "
                      f"Reproduced first: a register claiming 0224654 against a tree at b4fd131 produced no problems at all."),
            blocked_by="", next_step="Extend the same binding to the ZIP: record the archive digest in the register at release time.",
        ),
        entry(
            id="R-97", area="Release", milestone="M1", carried_from="1.3.0",
            requirement=("The file structure, the requirement matrix and the feature inventory are generated from the tree, "
                         "the register and the tests, and each fails a --check when it is stale"),
            status="PASS",
            evidence=("scripts/build_1_3_0_file_structure.py, scripts/build_1_3_0_matrix.py and "
                      "scripts/build_1_3_0_feature_inventory.py write docs/1_3_0_FILE_STRUCTURE.md, "
                      "docs/1_3_0_REQUIREMENT_MATRIX.md and docs/1_3_0_FEATURE_INVENTORY.md; each has --check, and all "
                      "three were checked at this commit. The matrix keeps the brief's REQ- ids and the register's R-nn ids "
                      "apart and lists the brief requirements that no test module names."),
            blocked_by="", next_step="Add the three --check commands to CI once the release documents are final.",
        ),
        entry(
            id="R-98", area="Reverse ETL", milestone="M2", carried_from="1.3.0",
            requirement=("The export layer is reachable from the product: a route starts a delivery to a destination, a "
                         "worker handler drains the outbox, and a screen shows the runs and their watermarks"),
            status="NOT_IMPLEMENTED",
            evidence=("Nothing calls services/destinations or services/export_outbox outside the tests: there is no route, "
                      "no job handler and no screen. The layer is a library with a schema behind it."),
            blocked_by="",
            next_step="M2: a permissioned route, a jobs handler that drains the outbox with the destination's retry policy, and the run view on the Operations screen.",
        ),
    ]
    for added in additions:
        entries[added["id"]] = added  # new ids only; an existing id is not overwritten
    register["entries"] = sorted(entries.values(), key=lambda item: int(item["id"].split("-")[1]))

    # --------------------------------------------------------------- the entries M1 changed
    if "R-59" in entries:
        entries["R-59"]["evidence"] = (
            f"services/export_record.py: twenty fields (the specification's eighteen plus approval_status and the tenant, "
            f"which leads because it is part of every identity), schema 1.1.0, types, nullability, enumerations, range "
            f"checks, UTC-offset timestamps, a canonical JSON line per record, a batch checksum and a refusal for a record "
            f"without a tenant. {per_module['export_record']} tests in {MODULES['export_record']}. Still not reachable from "
            f"the API or the export path: see R-98."
        )
        entries["R-59"]["next_step"] = "M2: route the file and PostgreSQL exports through it and expose a destination route."
    if "R-60" in entries:
        entries["R-60"]["evidence"] = (
            f"services/destinations/{{base,snowflake}}.py: validation against the canonical record, deduplication on the "
            f"tenant-scoped identity, batched MERGE, retry with backoff, per-record outcomes, a contiguous per-tenant "
            f"watermark, a checksum over the acknowledged set, read-back reconciliation that may answer unknown, a session "
            f"read-back that refuses a session that is not the configuration, validated and quoted identifiers, and the "
            f"run/outbox/checkpoint tables of migration 0005. {per_module['snowflake']} tests in "
            f"{MODULES['snowflake']} and {per_module['outbox']} in {MODULES['outbox']}. The driver is a stand-in: no "
            f"Snowflake account and no SDK here (GATE 12 BLOCKED), and nothing outside the tests calls this layer (R-98)."
        )

    meta = register["meta"]
    meta["source_commit"] = commit
    meta["test_count"] = totals["tests"]
    meta["test_runs"] = {
        "runs": len(args.junit),
        "tests": totals["tests"],
        "failures": totals["failures"],
        "errors": totals["errors"],
        "skipped": totals["skipped"],
        "note": "read from the JUnit files the release runs produced; both runs at the same commit",
    }
    for added in additions:
        if added["status"] in ("PASS", "PARTIAL", "FAIL"):
            added["verified_at"] = commit
    for item in register["entries"]:
        if item["id"] in {added["id"] for added in additions} and item["status"] in ("PASS", "PARTIAL", "FAIL"):
            item["verified_at"] = commit

    if args.dry_run:
        print(json.dumps({"added": [added["id"] for added in additions], "totals": totals}, indent=1))
        return 0
    Path(args.register).write_text(json.dumps(register, indent=1) + "\n")
    print(
        f"register updated at {commit}: {len(additions)} entries added, {totals['tests']} tests over {len(args.junit)} run(s), "
        f"{totals['failures']} failures, {totals['errors']} errors, {totals['skipped']} skipped"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
