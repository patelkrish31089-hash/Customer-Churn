#!/usr/bin/env python3
"""What the delivery path costs: records per second, the price of a failure, and a backlog query at size.

    python3 scripts/load_test_delivery.py --records 10000 --failure-rate 0.01 --backlog 100000 \
        --json /var/tmp/release/delivery-load.json
    python3 scripts/load_test_delivery.py --database postgres      # same, against CHURN_TEST_POSTGRES_URL

Four measurements, each because a 1.3.0 report would otherwise only be able to say "expected":

1. **throughput** — ``deliver()`` with a stand-in destination, N records, a fixed batch size.  This is the pipeline's own
   cost: validation, deduplication, the per-record outcome list, the checksum over the acknowledged records, and the
   reconciliation count.
2. **the price of a failure** — the same run with a share of records the destination refuses.  A failing batch is split
   into single-record writes so one bad row cannot take its neighbours down; that is a correctness trade, and this is
   what it costs.
3. **the durable write** — ``record_run()`` against a real database: one outbox row per record, one run row, one
   checkpoint.  This is the number a 10 000-record export has to survive, and it is dominated by the inserts, not by
   the delivery.
4. **the backlog query** — ``outstanding()`` over a backlog of M rows, which is what a restarted run asks before it
   sends anything.  The index on ``(tenant_id, status)`` is the thing that decides it.

The destination is a stand-in: it counts what it is given and refuses what it is told to refuse.  Nothing here claims a
vendor's throughput — a real Snowflake warehouse answers in tens of milliseconds per statement and this script cannot
see that.  What it measures is the platform's own cost per record, which is what the release can be held to.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
import tempfile
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


class Counting:
    """A destination that counts and, when told to, refuses: it is the load, not the vendor, being measured."""

    name = "load-stand-in"

    def __init__(self, refuse_every: int = 0):
        self.refuse_every = refuse_every
        self.rows = 0
        self.calls = 0

    def test_connection(self):
        return {"ok": True}

    def ensure_schema(self):
        return None

    def write(self, records, *, run_id):
        self.calls += 1
        if self.refuse_every:
            # keyed on the record, not on its position in the call: a split batch must refuse the same record again
            for record in records:
                if record["customer_id"] % self.refuse_every == 0:
                    raise RuntimeError(f"refused {record['external_customer_id']}")
        self.rows += len(records)
        return len(records)

    def count_stored(self, *, run_id):
        return self.rows


def records(count: int, *, tenant_id: int = 1, day: int = 1) -> list[dict]:
    base = datetime(2026, 1, 1, tzinfo=UTC)
    out = []
    for index in range(count):
        stamp = base + timedelta(minutes=index)
        out.append({
            "tenant_id": tenant_id, "customer_id": index, "account_id": None,
            "external_customer_id": f"C{index:07d}", "crm_contact_id": None,
            "churn_probability": 0.5, "risk_tier": "high", "risk_decile": 3,
            "prediction_horizon_days": 30, "prediction_timestamp": stamp,
            "data_cutoff_timestamp": stamp.replace(hour=0) - timedelta(days=1),
            "model_name": "load", "model_version": "1", "feature_version": "contract-1",
            "model_checksum": "a" * 64, "top_reason_1": "no login", "top_reason_2": None,
            "top_reason_3": None, "recommended_intervention": None, "approval_status": "approved",
        })  # fmt: skip
    return out


def measure_delivery(count: int, batch_size: int, failure_rate: float) -> dict:
    from churn_platform.services.destinations.base import RetryPolicy, deliver

    rows = records(count)
    refuse_every = int(round(1 / failure_rate)) if failure_rate else 0
    destination = Counting(refuse_every=refuse_every)
    started = time.perf_counter()
    result = deliver(destination, rows, run_id=f"load-{count}", batch_size=batch_size,
                     policy=RetryPolicy(attempts=1), sleep=lambda _s: None)  # fmt: skip
    seconds = time.perf_counter() - started
    return {
        "records": count,
        "batch_size": batch_size,
        "failure_rate": failure_rate,
        "seconds": round(seconds, 3),
        "records_per_second": round(count / seconds, 1) if seconds else None,
        "acknowledged": result.written,
        "failed": result.failed,
        "batches_sent_to_the_destination": destination.calls,
        "retries": result.retries,
        "quarantined": len(result.quarantined),
    }


def measure_record_run(count: int, *, database_url: str) -> dict:
    """The durable write: one outbox row per record through ``record_run``."""
    from churn_platform.db import session_scope
    from churn_platform.services import export_outbox
    from churn_platform.services.destinations.base import deliver

    rows = records(count)
    result = deliver(Counting(), rows, run_id=f"store-{count}", batch_size=count)
    started = time.perf_counter()
    with session_scope() as session:
        export_outbox.record_run(session, result, tenant_id=1)
    seconds = time.perf_counter() - started
    return {
        "records": count,
        "seconds": round(seconds, 3),
        "records_per_second": round(count / seconds, 1) if seconds else None,
        "database": "postgresql" if database_url.startswith("postgresql") else "sqlite",
    }


def measure_backlog(size: int) -> dict:
    """A backlog of ``size`` rows: how long the query a restarted run makes takes to answer."""
    from sqlalchemy import insert

    from churn_platform.db import session_scope
    from churn_platform.models import ExportOutboxRecord, ExportRun
    from churn_platform.services import export_outbox

    started = time.perf_counter()
    with session_scope() as session:
        run = ExportRun(tenant_id=2, destination="load-stand-in", run_id=f"backlog-{size}", status="partial",
                        records_selected=size, started_at=datetime.now(UTC))  # fmt: skip
        session.add(run)
        session.flush()
        batch = [{
            "tenant_id": 2, "export_run_id": run.id, "destination": "load-stand-in",
            "identity_key": f"2|C{index:07d}|load|1|2026-01-01", "idempotency_key": f"load-stand-in:2|C{index:07d}|{index}",
            "payload_checksum": "b" * 64, "prediction_timestamp": datetime(2026, 1, 1, tzinfo=UTC) + timedelta(minutes=index),
            "status": "FAILED", "attempts": 1, "created_at": datetime.now(UTC),
        } for index in range(size)]  # fmt: skip
        for start in range(0, len(batch), 5000):
            session.execute(insert(ExportOutboxRecord), batch[start : start + 5000])
    written = time.perf_counter() - started
    started = time.perf_counter()
    with session_scope() as session:
        rows = export_outbox.outstanding(session, 2, "load-stand-in")
    read = time.perf_counter() - started
    return {
        "backlog_rows": size,
        "write_seconds": round(written, 3),
        "query_seconds": round(read, 3),
        "rows_returned": len(rows),
        "query": "export_outbox.outstanding(tenant 2, load-stand-in) — where status != 'ACKNOWLEDGED', ordered by timestamp",
    }


def prepare_database(use_postgres: bool) -> tuple[str, callable]:
    """A migrated database with one tenant, and the cleanup that removes it again."""
    from churn_platform import config, db, dbadmin
    from churn_platform.db import session_scope
    from churn_platform.services import auth

    if use_postgres:
        url = os.environ.get("CHURN_TEST_POSTGRES_URL", "")
        if not url:
            raise SystemExit("--database postgres needs CHURN_TEST_POSTGRES_URL")
        from sqlalchemy import text

        db.dispose_engine()
        os.environ["CHURN_DATABASE_URL"] = url
        config.reset_settings_cache()
        db.dispose_engine()
        with db.get_engine().begin() as conn:
            conn.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
        dbadmin.upgrade()
        workdir = None
    else:
        workdir = Path(tempfile.mkdtemp(prefix="churn-load-"))
        url = f"sqlite:///{workdir / 'load.db'}"
        os.environ["CHURN_DATABASE_URL"] = url
        os.environ["CHURN_DATA_DIR"] = str(workdir / "data")
        config.reset_settings_cache()
        db.dispose_engine()
        dbadmin.upgrade()

    with session_scope() as session:
        auth.create_tenant(session, "load", "Load")

    def cleanup() -> None:
        db.dispose_engine()
        if workdir is not None:
            shutil.rmtree(workdir, ignore_errors=True)

    return url, cleanup


def main() -> int:
    parser = argparse.ArgumentParser(description="measure the delivery path")
    parser.add_argument("--records", type=int, default=10_000)
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--failure-rate", type=float, default=0.01)
    parser.add_argument("--backlog", type=int, default=100_000)
    parser.add_argument("--database", choices=("sqlite", "postgres"), default="sqlite")
    parser.add_argument("--json", metavar="FILE")
    args = parser.parse_args()

    url, cleanup = prepare_database(args.database == "postgres")
    try:
        result = {
            "measured_at": datetime.now(UTC).isoformat(),
            "environment": {
                "python": platform.python_version(),
                "machine": platform.machine(),
                "processors": os.cpu_count(),
                "database": "postgresql" if url.startswith("postgresql") else "sqlite",
                "records": args.records,
                "batch_size": args.batch_size,
            },
            "delivery": measure_delivery(args.records, args.batch_size, 0.0),
            "delivery_with_failures": measure_delivery(args.records, args.batch_size, args.failure_rate),
            "record_run": measure_record_run(min(args.records, 5_000), database_url=url),
            "backlog": measure_backlog(args.backlog),
        }
    finally:
        cleanup()

    print(json.dumps(result, indent=1))
    if args.json:
        Path(args.json).write_text(json.dumps(result, indent=1) + "\n")
        print(f"written to {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
