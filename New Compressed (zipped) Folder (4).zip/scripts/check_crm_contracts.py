#!/usr/bin/env python3
"""Check the CRM requests the platform builds against the API descriptions the vendors publish.

    python scripts/check_crm_contracts.py                 # downloads the descriptions (needs network access)
    python scripts/check_crm_contracts.py --spec-dir DIR  # uses hubspot-companies.json, hubspot-tasks.json, intercom.yaml

For every request the HubSpot and Intercom connectors can send, the script checks that

  * the path exists in the vendor's description and accepts the HTTP method;
  * every query and header parameter sent is one the operation declares, required ones are present, and a value
    restricted to a list (Intercom-Version) is on it;
  * the JSON body is valid for the operation's request schema: required members, member types, the type of
    free-form property values, and the alternatives of anyOf / oneOf.

This is a check of shape, on the vendor's own machine-readable description.  It does not show that a vendor
account accepts the request: custom properties must exist there, the token needs the right scopes, and a
description can lag behind the service.  Salesforce publishes no description that can be fetched without signing
in to an org (the OpenAPI document for sObjects is generated per org), so the Salesforce requests are not checked
here; docs/CRM_SETUP.md says what they rest on.

Exit code 0: every request conforms.  1: at least one does not.  2: a description could not be read.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.request
from pathlib import Path
from typing import Any

SOURCES = {
    "hubspot-companies.json": "https://raw.githubusercontent.com/HubSpot/HubSpot-public-api-spec-collection/main/PublicApiSpecs/CRM/Companies/Rollouts/424/v3/companies.json",
    "hubspot-tasks.json": "https://raw.githubusercontent.com/HubSpot/HubSpot-public-api-spec-collection/main/PublicApiSpecs/CRM/Tasks/Rollouts/424/v3/tasks.json",
    "intercom.yaml": "https://raw.githubusercontent.com/intercom/Intercom-OpenAPI/main/descriptions/{version}/api.intercom.io.yaml",
}
RISK = {"external_id": "C000123", "probability": 0.812345, "risk_tier": "high", "top_reasons": ["No login for 21 days", "Open ticket for 3 days"],
        "as_of_date": "2026-11-01"}  # fmt: skip
TASK = {"external_id": "C000123", "subject": "[Churn risk] Senior CSM call - Acme", "body": "Churn probability: 81.2%", "priority": 1,
        "segment": "high_risk_high_value", "action_code": "csm_white_glove_call", "created_at": "2026-11-01T08:00:00+00:00",
        "created_epoch": 1793520000}  # fmt: skip
NOTES: set[str] = set()  # places where a description contradicts itself (filled by problems())
JSON_TYPES: dict[str, tuple[type, ...]] = {"string": (str,), "integer": (int,), "number": (int, float), "boolean": (bool,), "object": (dict,),
                                           "array": (list,)}  # fmt: skip


def resolve(document: dict, node: Any) -> Any:
    """Follow ``$ref`` pointers inside one document."""
    while isinstance(node, dict) and "$ref" in node:
        target: Any = document
        for part in node["$ref"].removeprefix("#/").split("/"):
            target = target[part.replace("~1", "/").replace("~0", "~")]
        node = target
    return node


def problems(document: dict, schema: Any, value: Any, where: str = "body") -> list[str]:
    """What makes ``value`` invalid for an OpenAPI 3.0 schema (the subset of JSON Schema these descriptions use)."""
    schema = resolve(document, schema)
    if not isinstance(schema, dict):
        return []
    found: list[str] = []
    if value is None:
        return [] if schema.get("nullable") else [f"{where}: null is not allowed"]
    expected = schema.get("type")
    if expected in JSON_TYPES and (not isinstance(value, JSON_TYPES[expected]) or (isinstance(value, bool) and expected != "boolean")):
        return [f"{where}: expected {expected}, got {type(value).__name__} ({value!r})"]
    if "enum" in schema and value not in schema["enum"]:
        found.append(f"{where}: {value!r} is not one of {schema['enum']}")
    if isinstance(value, dict):
        found += [f"{where}: required member '{name}' is missing" for name in schema.get("required", []) if name not in value]
        declared, extra = schema.get("properties", {}), schema.get("additionalProperties")
        example = schema.get("example")
        if isinstance(extra, dict) and isinstance(example, dict) and any(problems(document, extra, v) for v in example.values()):
            # The description contradicts itself: its own example for this member breaks the value type it declares
            # (Intercom: custom attribute values declared as strings, the example holds a boolean and two numbers).
            # Nothing can be concluded from such a declaration, so it is reported and not enforced.
            NOTES.add(f"{where}: the description's own example {json.dumps(example)} breaks the value type it declares "
                      f"({extra.get('type')}); value types are not checked there")  # fmt: skip
            extra = None
        for name, member in value.items():
            if name in declared:
                found += problems(document, declared[name], member, f"{where}.{name}")
            elif extra is False:
                found.append(f"{where}: member '{name}' is not allowed")
            elif isinstance(extra, dict):
                found += problems(document, extra, member, f"{where}.{name}")
    if isinstance(value, list) and "items" in schema:
        for index, item in enumerate(value):
            found += problems(document, schema["items"], item, f"{where}[{index}]")
    for part in schema.get("allOf", []):
        found += problems(document, part, value, where)
    for keyword, enough in (("anyOf", lambda n: n >= 1), ("oneOf", lambda n: n == 1)):
        if keyword in schema:
            failures = [problems(document, alternative, value, where) for alternative in schema[keyword]]
            matching = sum(1 for failure in failures if not failure)
            if not enough(matching):
                closest = min(failures, key=len) if matching == 0 else [f"{matching} alternatives match"]
                found.append(f"{where}: matches {matching} of the {len(failures)} alternatives of {keyword} (closest: {'; '.join(closest)})")
    return found


def check_request(document: dict, base_url: str, request: dict) -> list[str]:
    """Problems of one built request (method, url, params, headers, json) against one API description."""
    servers = [server["url"].rstrip("/") for server in document.get("servers", [])]
    if base_url.rstrip("/") not in servers:
        return [f"{base_url} is not a server of this description ({', '.join(servers)})"]
    path, method = request["url"][len(base_url.rstrip("/")):], request["method"].lower()
    template = next((t for t in document["paths"] if re.fullmatch(re.sub(r"\{[^/]+\}", "[^/]+", t), path)), None)
    if template is None:
        return [f"no path in the description matches {path}"]
    item = document["paths"][template]
    if method not in item:
        return [f"{template} does not accept {method.upper()} (it accepts {', '.join(m.upper() for m in item if m in ('get', 'put', 'post', 'patch', 'delete'))})"]
    operation, found = item[method], []
    declared = [resolve(document, p) for p in [*item.get("parameters", []), *operation.get("parameters", [])]]
    for place, sent in (("query", request.get("params", {})), ("header", request.get("headers", {}))):
        known = {p["name"].lower() if place == "header" else p["name"]: p for p in declared if p["in"] == place}
        for name, value in sent.items():
            key = name.lower() if place == "header" else name
            if key not in known:
                found.append(f"{place} parameter '{name}' is not declared by {method.upper()} {template}")
            else:
                found += problems(document, known[key].get("schema", {}), value, f"{place} parameter '{name}'")
        found += [f"required {place} parameter '{p['name']}' is missing" for key, p in known.items()
                  if p.get("required") and key not in {n.lower() if place == "header" else n for n in sent}]  # fmt: skip
    body = operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema")
    if body is None:
        found.append(f"{method.upper()} {template} declares no JSON request body")
    else:
        found += problems(document, body, request["json"])
    return found


def load(spec_dir: Path | None, name: str, version: str) -> dict:
    if spec_dir is not None:
        text = (spec_dir / name).read_text()
    else:
        url = SOURCES[name].format(version=version)
        with urllib.request.urlopen(url, timeout=60) as response:  # noqa: S310 - fixed https URLs above  # nosec B310
            text = response.read().decode()
    if name.endswith(".json"):
        return json.loads(text)
    import yaml

    return yaml.safe_load(text)


def built_requests() -> list[tuple[str, str, str, dict]]:
    """(description file, base URL, label, request) for everything the HubSpot and Intercom connectors send."""
    from churn_platform.models import CRMConnection
    from churn_platform.services import crm

    hubspot = CRMConnection(provider="hubspot", base_url="https://api.hubapi.com", field_mapping=dict(crm.DEFAULT_MAPPING["hubspot"]))
    intercom = CRMConnection(provider="intercom", base_url="https://api.intercom.io", field_mapping=dict(crm.DEFAULT_MAPPING["intercom"]))
    return [
        ("hubspot-companies.json", hubspot.base_url, "HubSpot risk score", crm.build_request(hubspot, "risk_score", RISK)),
        ("hubspot-tasks.json", hubspot.base_url, "HubSpot task", crm.build_request(hubspot, "task", TASK)),
        ("intercom.yaml", intercom.base_url, "Intercom risk score", crm.build_request(intercom, "risk_score", RISK)),
        ("intercom.yaml", intercom.base_url, "Intercom recommended action", crm.build_request(intercom, "task", TASK)),
    ]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--spec-dir", type=Path, help="directory holding the three descriptions instead of downloading them")
    args = parser.parse_args(argv)
    from churn_platform.services import crm

    version, documents, failed = crm.DEFAULT_MAPPING["intercom"].get("api_version", "2.14"), {}, 0
    for name, base_url, label, request in built_requests():
        try:
            if name not in documents:
                documents[name] = load(args.spec_dir, name, version)
        except (OSError, ValueError) as exc:
            print(f"cannot read the description {name}: {exc}", file=sys.stderr)
            return 2
        found = check_request(documents[name], base_url, request)
        failed += bool(found)
        described = documents[name].get("info", {})
        print(f"{'FAIL' if found else 'ok  '}  {label}: {request['method']} {request['url']}  [{described.get('title')} {described.get('version')}]")
        for problem in found:
            print(f"        {problem}")
        for note in sorted(NOTES):
            print(f"        note: {note}")
        NOTES.clear()
    print(f"{len(built_requests()) - failed} of {len(built_requests())} requests conform to the vendor's description")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
