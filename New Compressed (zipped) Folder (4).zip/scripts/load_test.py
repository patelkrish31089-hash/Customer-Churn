#!/usr/bin/env python3
"""Load test against a running server: throughput and latency of the screens people use, at several levels of
concurrency.

    DEMO_PASSWORD=... python scripts/load_test.py --base-url http://127.0.0.1:8000 \\
        --email analyst@demo.example --password-env DEMO_PASSWORD --concurrency 1,8,32 --duration 30

How the load is made.  Each of C clients sends one request, waits for the answer and sends the next (a closed
loop: the request rate is whatever the server sustains, there is no queue building up outside it).  The request is
drawn at random from a fixed mix modelled on the web application: the customer list and single customers, the
predictions of the latest batch and their explanations, recommendations, the monitoring and analytics reports,
alerts, and the "running jobs" poll every open page sends.  ``--scoring-share`` adds real-time scoring of single
customers (a write: features are computed, a prediction is stored).

The script signs in ONCE and every client uses that session: sign-in is rate limited and five wrong passwords
lock an account, so a sign-in storm would measure the limiter.  Answers are read completely; anything but 2xx is
counted as an error and listed by status.

What the figures do not say.  The generator runs where you start it: on the server's own machine it takes
processor time away from the server, so the figures are a lower bound.  A closed loop hides the latency a real
user would see once requests arrive faster than the server answers.  The figures hold for the data set and the
machine of the run; both are printed with the result.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import platform
import random
import sys
import time
from collections import Counter, defaultdict
from typing import Any

import httpx

API = "/api/v1"
# (name, weight): the share of each kind of request among the reads
READ_MIX = [("customer list", 22), ("customer", 24), ("batch predictions", 10), ("explanation", 6), ("recommendations", 10),
            ("monitoring report", 6), ("analytics report", 6), ("alerts", 6), ("running jobs", 10)]  # fmt: skip


def percentile(sorted_values: list[float], share: float) -> float:
    """Nearest-rank percentile of an ascending list (the value at least ``share`` of the observations do not exceed)."""
    if not sorted_values:
        return float("nan")
    rank = max(1, -(-len(sorted_values) * share // 1))  # ceil without importing math
    return sorted_values[int(rank) - 1]


def summarise(latencies: list[float]) -> dict[str, float]:
    ordered = sorted(latencies)
    return {"count": len(ordered), "mean_ms": round(sum(ordered) / len(ordered), 1) if ordered else float("nan"),
            **{f"p{int(share * 100)}_ms": round(percentile(ordered, share), 1) for share in (0.5, 0.9, 0.95, 0.99)},
            "max_ms": round(ordered[-1], 1) if ordered else float("nan")}  # fmt: skip


class Target:
    """What the requests address: found once, before the measurement starts."""

    def __init__(self, customer_ids: list[int], customer_pages: int, batch_id: int, prediction_ids: list[int], prediction_pages: int) -> None:
        self.customer_ids, self.customer_pages, self.batch_id = customer_ids, customer_pages, batch_id
        self.prediction_ids, self.prediction_pages = prediction_ids, prediction_pages

    def request(self, name: str, rng: random.Random) -> tuple[str, str, dict[str, Any]]:
        if name == "customer list":
            return "GET", f"{API}/customers", {"page": rng.randint(1, self.customer_pages), "page_size": 25, "sort": "risk"}
        if name == "customer":
            return "GET", f"{API}/customers/{rng.choice(self.customer_ids)}", {}
        if name == "batch predictions":
            return "GET", f"{API}/predictions/batches/{self.batch_id}/predictions", {"page": rng.randint(1, self.prediction_pages), "page_size": 25}
        if name == "explanation":
            return "GET", f"{API}/predictions/{rng.choice(self.prediction_ids)}/explanation", {}
        if name == "score one customer":
            return "POST", f"{API}/customers/{rng.choice(self.customer_ids)}/predict", {}
        path = {"recommendations": "/retention/recommendations", "monitoring report": "/monitoring/latest", "analytics report": "/analytics/reports/latest",
                "alerts": "/alerts", "running jobs": "/jobs/active"}[name]  # fmt: skip
        params = {"recommendations": {"page_size": 25}, "alerts": {"page_size": 25}, "analytics report": {"kind": "overview"}}
        return "GET", f"{API}{path}", params.get(name, {})


async def discover(client: httpx.AsyncClient) -> Target:
    async def get(path: str, **params: Any) -> dict:
        response = await client.get(f"{API}{path}", params=params)
        response.raise_for_status()
        return response.json()

    customers = await get("/customers", page=1, page_size=200)
    batches = await get("/predictions/batches", page_size=5)
    if not customers["items"] or not batches["items"]:
        raise SystemExit("the tenant has no customers or no scored batch: seed the demo first")
    batch_id = batches["items"][0]["id"]
    predictions = await get(f"/predictions/batches/{batch_id}/predictions", page=1, page_size=200)
    return Target([c["id"] for c in customers["items"]], max(1, min(40, customers["total"] // 25)), batch_id,
                  [p["id"] for p in predictions["items"]], max(1, min(40, predictions["total"] // 25)))  # fmt: skip


async def run_level(client: httpx.AsyncClient, target: Target, mix: list[tuple[str, float]], *, clients: int, warmup: float, duration: float,
                    seed: int) -> dict:
    names, weights = [name for name, _ in mix], [weight for _, weight in mix]
    latencies: dict[str, list[float]] = defaultdict(list)
    errors: Counter[str] = Counter()
    start = time.perf_counter()
    measure_from, stop_at = start + warmup, start + warmup + duration

    async def one_client(index: int) -> None:
        rng = random.Random(seed * 1000 + index)  # a reproducible request mix, nothing secret
        while True:
            name = rng.choices(names, weights)[0]
            method, path, params = target.request(name, rng)
            began = time.perf_counter()
            if began >= stop_at:
                return
            try:
                response = await client.request(method, path, params=params)
                await response.aread()
                outcome = None if response.status_code < 300 else f"HTTP {response.status_code}"
            except httpx.HTTPError as exc:
                outcome = type(exc).__name__
            ended = time.perf_counter()
            if began >= measure_from and ended <= stop_at:  # only requests that lie wholly inside the window
                if outcome is None:
                    latencies[name].append((ended - began) * 1000)
                else:
                    errors[f"{name}: {outcome}"] += 1

    await asyncio.gather(*(one_client(index) for index in range(clients)))
    everything = [value for values in latencies.values() for value in values]
    failed = sum(errors.values())
    return {"clients": clients, "seconds": duration, "requests": len(everything) + failed, "errors": failed, "error_detail": dict(errors),
            "requests_per_second": round((len(everything) + failed) / duration, 1), "overall": summarise(everything),
            "by_request": {name: summarise(latencies[name]) for name in names if latencies[name]}}  # fmt: skip


async def main_async(args: argparse.Namespace) -> dict:
    password = os.environ.get(args.password_env)
    if not password:
        raise SystemExit(f"environment variable {args.password_env} is empty or not set")
    levels = [int(part) for part in args.concurrency.split(",")]
    limits = httpx.Limits(max_connections=max(levels) + 2, max_keepalive_connections=max(levels) + 2)
    async with httpx.AsyncClient(base_url=args.base_url, timeout=args.timeout, limits=limits) as client:
        signed_in = await client.post(f"{API}/auth/login", json={"email": args.email, "password": password})
        if signed_in.status_code != 200:
            raise SystemExit(f"sign-in failed: HTTP {signed_in.status_code} {signed_in.text[:200]}")
        client.headers["Authorization"] = f"Bearer {signed_in.json()['token']}"
        info = (await client.get(f"{API}/system/info")).json()
        target = await discover(client)
        reads = 100 - args.scoring_share
        mix = [(name, weight * reads / 100) for name, weight in READ_MIX] + ([("score one customer", args.scoring_share)] if args.scoring_share else [])
        results = []
        for clients in levels:
            level = await run_level(client, target, mix, clients=clients, warmup=args.warmup, duration=args.duration, seed=args.seed)
            results.append(level)
            overall = level["overall"]
            print(f"{clients:>4} clients  {level['requests_per_second']:>7.1f} req/s  p50 {overall['p50_ms']:>7.1f} ms  p95 {overall['p95_ms']:>7.1f} ms  "
                  f"p99 {overall['p99_ms']:>7.1f} ms  max {overall['max_ms']:>7.1f} ms  errors {level['errors']}", flush=True)  # fmt: skip
            await asyncio.sleep(args.pause)
        await client.post(f"{API}/auth/logout")
    return {"base_url": args.base_url, "label": args.label, "server": {key: info.get(key) for key in ("version", "environment", "database")},
            "generator": {"machine": platform.machine(), "cpus": os.cpu_count(), "python": platform.python_version(), "same_host_as_server": args.base_url.split("//")[1].startswith(("127.", "localhost"))},
            "mix_percent": {name: round(weight, 1) for name, weight in mix}, "warmup_seconds": args.warmup, "seed": args.seed,
            "data": {"customer_pages": target.customer_pages, "batch_id": target.batch_id}, "levels": results}  # fmt: skip


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--email", required=True)
    parser.add_argument("--password-env", required=True, metavar="VAR", help="environment variable holding the password")
    parser.add_argument("--concurrency", default="1,8,32", help="comma-separated numbers of concurrent clients (default: 1,8,32)")
    parser.add_argument("--duration", type=float, default=30.0, help="measured seconds per level (default: 30)")
    parser.add_argument("--warmup", type=float, default=5.0, help="seconds before measuring starts, per level (default: 5)")
    parser.add_argument("--pause", type=float, default=2.0, help="seconds between levels (default: 2)")
    parser.add_argument("--scoring-share", type=float, default=0.0, help="percent of requests that score one customer in real time (default: 0)")
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--label", default="", help="free text stored with the result (what was running, where)")
    parser.add_argument("--json", metavar="FILE", help="also write the full result to this file")
    args = parser.parse_args(argv)
    if not 0 <= args.scoring_share <= 100:
        parser.error("--scoring-share is a percentage between 0 and 100")
    result = asyncio.run(main_async(args))
    if args.json:
        with open(args.json, "w") as sink:
            json.dump(result, sink, indent=1)
    failed = sum(level["errors"] for level in result["levels"])
    if failed:
        print(f"{failed} request(s) failed: " + json.dumps({k: v for level in result['levels'] for k, v in level['error_detail'].items()}), file=sys.stderr)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
