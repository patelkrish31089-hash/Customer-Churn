#!/usr/bin/env python3
"""Build, validate and check the 1.3.0 requirement register.

    python scripts/build_1_3_0_register.py            # recompute the counts, write the traceability document
    python scripts/build_1_3_0_register.py --check    # fail when the document on disk is not what the register says
    python scripts/build_1_3_0_register.py --release  # the stricter checks a release must pass

The register is ``docs/1_3_0_requirements.json`` and it is the only place a requirement's status is written down; the
Markdown table next to it is generated, never edited by hand.  That is deliberate.  The 1.2.0 register carried a
hand-written ``meta.counts`` block that disagreed with its own 58 entries (23/16/9/2 against 28/14/6/2) and nobody
noticed until an audit counted them, because two summaries of one fact drift apart the moment one of them is edited
by hand.  Here the counts are computed from the entries on every run, and ``--check`` proves the document matches.

What the checks are for:

* every id unique and well formed, so an entry can be cited in a test and in a report and mean one thing;
* every status from the fixed vocabulary — nothing invents "mostly done" (see ``docs/1_3_0_BASELINE_AUDIT.md``);
* a PASS, FAIL or PARTIAL must carry evidence: the file, the command or the test that shows it;
* a BLOCKED must name what blocks it, because "blocked" without a dependency is an excuse;
* a PASS must say at which commit it was last executed (``verified_at``) — a PARTIAL does not, because it is a
  statement of what is missing rather than of what ran — and ``--release`` fails when a PASS's commit is not the
  commit being released — historical reports are evidence for the commit they name and for no other;
* ``--release`` also compares the register's ``meta.source_commit`` with the tree's actual HEAD.  1.3.0's first
  ``--release`` run reported ten problems-free while the register claimed ``0224654`` and the source was ``b4fd131``:
  the check compared the register with itself, so a register that had never been touched since the last release passed.
  A check that asks the same document twice always agrees with itself.  Here the claim is compared with ``git``;
* ``--release`` reads the JUnit XML the run produced, and the sidecar ``<junit>.meta.json`` that
  ``scripts/record_test_run.py`` writes next to it: the commit, the command, the digest of the file and the totals.  A
  JUnit file with a failure, an error or a skip in it is not a passing suite — and a skipped test is not an executed
  test, so it cannot support a PASS either.  When two runs are given, their per-test outcomes must agree
* the fifteen gates must all be present, of the right kind, with an owner, an environment, a command, a result and the
  limitation that remains.  A gate table with no command in it is a claim, not evidence.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ElementTree  # nosec S314 - it parses the JUnit file the suite wrote, from a path this tool was given, not untrusted input
from collections import Counter, defaultdict
from collections.abc import Iterable
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"
DOCUMENT = ROOT / "docs" / "1_3_0_REQUIREMENT_TRACEABILITY.md"

STATUSES = ("PASS", "FAIL", "PARTIAL", "BLOCKED", "NOT_IMPLEMENTED", "NOT_TESTED", "NOT_APPLICABLE")
# A status that asserts something was observed must say what was observed.
#: a PARTIAL is a statement of incompleteness, not of an execution, so it is not held to a commit it ran at
NEEDS_EVIDENCE = {"PASS", "FAIL"}
GATE_COUNT = 15
TECHNICAL_GATES = 10
MIN_EVIDENCE = 40
ID_RE = re.compile(r"^R-\d{2,3}$")
GATE_RE = re.compile(r"^GATE (\d{1,2})$")


def load(path: Path = REGISTER) -> dict[str, Any]:
    return json.loads(path.read_text())


def git(*arguments: str) -> str:
    out = subprocess.run(["git", *arguments], cwd=ROOT, capture_output=True, text=True, check=False)
    return out.stdout.strip()


def head_commit() -> str:
    out = subprocess.run(["git", "rev-parse", "--short=7", "HEAD"], cwd=ROOT, capture_output=True, text=True, check=False)
    return out.stdout.strip() or "unknown"


def counts(entries: list[dict[str, Any]]) -> dict[str, int]:
    """The counts that go in ``meta.counts``: computed, never typed."""
    return dict(sorted(Counter(entry["status"] for entry in entries).items()))



def junit_totals(path: Path) -> dict[str, Any]:
    """Read a JUnit XML file into the numbers a claim may rest on, and the outcome of every test in it.

    ``skipped`` is counted separately on purpose: a skipped test did not run, so it is neither a pass nor a failure, and
    a suite of 500 passed and 58 skipped is not a suite of 558 passed.
    """
    try:
        tree = ElementTree.parse(path)  # noqa: S314  # nosec B314 - the suite's own JUnit output, from a path given to this tool
    except (OSError, ElementTree.ParseError) as exc:
        raise ValueError(f"{path} is not readable JUnit XML: {exc}") from exc
    root = tree.getroot()
    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
    cases = [case for suite in suites for case in suite.iter("testcase")]
    outcomes: dict[str, str] = {}
    failures = errors = skipped = 0
    for case in cases:
        name = f"{case.get('classname', '')}::{case.get('name', '')}"
        if case.find("failure") is not None:
            outcomes[name] = "failed"
            failures += 1
        elif case.find("error") is not None:
            outcomes[name] = "error"
            errors += 1
        elif case.find("skipped") is not None:
            outcomes[name] = "skipped"
            skipped += 1
        else:
            outcomes[name] = "passed"
    return {
        "path": str(path),
        "tests": len(cases),
        "failures": failures,
        "errors": errors,
        "skipped": skipped,
        "outcomes": outcomes,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    }


def check_evidence(paths: list[Path], *, commit: str, allowed_commits: set[str], min_tests: int) -> list[str]:
    """The problems with a set of JUnit files offered as release evidence.  Empty means the evidence is usable."""
    problems: list[str] = []
    if not paths:
        problems.append("release evidence: no JUnit file was given, so nothing was executed for this release")
        return problems
    seen_runs: list[dict[str, Any]] = []
    for path in paths:
        if not path.exists():
            problems.append(f"release evidence: {path} does not exist")
            continue
        try:
            totals = junit_totals(path)
        except ValueError as exc:
            problems.append(f"release evidence: {exc}")
            continue
        sidecar = path.with_suffix(path.suffix + ".meta.json")
        if not sidecar.exists():
            problems.append(f"release evidence: {sidecar.name} is missing, so {path.name} cannot be tied to a commit")
        else:
            try:
                meta = json.loads(sidecar.read_text())
            except json.JSONDecodeError:
                problems.append(f"release evidence: {sidecar.name} is not JSON")
                meta = {}
            named = str(meta.get("commit", ""))
            if not named:
                problems.append(f"release evidence: {sidecar.name} does not name a commit")
            elif named not in allowed_commits:
                problems.append(f"release evidence: {path.name} was produced at {named}, which is not the release commit {commit}")
            if meta.get("sha256") and meta["sha256"] != totals["sha256"]:
                problems.append(f"release evidence: {path.name} has changed since it was recorded ({sidecar.name} disagrees)")
            if not str(meta.get("command", "")).strip():
                problems.append(f"release evidence: {sidecar.name} does not say how the suite was run")
        if totals["failures"] or totals["errors"]:
            problems.append(f"release evidence: {path.name} contains {totals['failures']} failure(s) and {totals['errors']} error(s)")
        if totals["skipped"]:
            problems.append(
                f"release evidence: {path.name} contains {totals['skipped']} skipped test(s); a skip is not an executed test"
            )
        if min_tests and totals["tests"] < min_tests:
            problems.append(f"release evidence: {path.name} has {totals['tests']} tests, fewer than the recorded baseline of {min_tests}")
        seen_runs.append(totals)
    if len(seen_runs) > 1:
        first = seen_runs[0]
        for other in seen_runs[1:]:
            if other["tests"] != first["tests"]:
                problems.append(
                    f"release evidence: {Path(first['path']).name} ran {first['tests']} tests and "
                    f"{Path(other['path']).name} ran {other['tests']}: the runs are not of the same suite"
                )  # fmt: skip
            differing = sorted(name for name in set(first["outcomes"]) | set(other["outcomes"])
                               if first["outcomes"].get(name) != other["outcomes"].get(name))  # fmt: skip
            if differing:
                problems.append(
                    f"release evidence: the two runs disagree on {len(differing)} test(s), first {differing[0]}"
                )
    return problems


def documentation_only_above(commit: str, head: str) -> bool:
    """True when ``head`` differs from ``commit`` in documentation alone.

    Evidence is produced at a commit, and that commit cannot contain the register that names it, so the two are always
    a step apart — sometimes more than one step, because the register, the reports and the generated documents are
    written and rewritten after the last test run. This asks git what actually changed: if every path between the
    evidence commit and the tree is documentation (``docs/``, the changelog, the readme, release output), then the
    source that was tested is the source being released. One source, test or script file in that range and the answer
    is no, whatever the register says.
    """
    result = subprocess.run(
        ["git", "-C", str(ROOT), "diff", "--name-only", f"{commit}..{head}"],
        capture_output=True,
        text=True,
    )
    if result.returncode:
        return False
    changed = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return bool(changed) and all(path.startswith(REGISTER_DOCUMENTS) for path in changed)


def release_commits(commit: str, candidates: Iterable[str] = ()) -> set[str]:
    """The commits a release may call its own: the tree, and any commit the documents were written above.

    ``candidates`` are the commits the register and the evidence sidecars name. A candidate is allowed when the tree
    differs from it in documentation only, which is the one exception a release needs and can check.
    """
    allowed = {commit}
    for candidate in candidates:
        candidate = str(candidate or "").strip()
        if candidate and candidate not in allowed and documentation_only_above(candidate, commit):
            allowed.add(candidate)
    return allowed


def working_tree_problems() -> list[str]:
    dirty = [line for line in git("status", "--porcelain").splitlines() if line.strip()]
    return [f"release evidence: the working tree is not clean ({len(dirty)} uncommitted path(s)); the commit cannot be named"] if dirty else []

#: the only files a register may be committed in a commit *after* the one its evidence names
REGISTER_DOCUMENTS = ("docs/", "release/", "CHANGELOG.md", "README.md")


def validate(register: dict[str, Any], source_commit: str | None = None, release: bool = False, *,
             actual_commit: str | None = None, allowed_commits: Iterable[str] | None = None) -> list[str]:
    problems: list[str] = []
    entries = register.get("entries") or []
    if not entries:
        problems.append("the register has no entries")
    seen: set[str] = set()
    for entry in entries:
        rid = entry.get("id", "?")
        if not ID_RE.match(str(rid)):
            problems.append(f"{rid}: id is not of the form R-nn")
        if rid in seen:
            problems.append(f"{rid}: duplicate id")
        seen.add(rid)
        status = entry.get("status")
        if status not in STATUSES:
            problems.append(f"{rid}: status {status!r} is not in the vocabulary {STATUSES}")
        if not str(entry.get("requirement", "")).strip():
            problems.append(f"{rid}: no requirement text")
        if status in NEEDS_EVIDENCE and len(str(entry.get("evidence", "")).strip()) < MIN_EVIDENCE:
            problems.append(f"{rid}: status {status} with no evidence")
        if status == "BLOCKED" and not str(entry.get("blocked_by", "")).strip():
            problems.append(f"{rid}: BLOCKED without saying what blocks it")
        if status == "PASS" and not str(entry.get("verified_at", "")).strip():
            problems.append(f"{rid}: PASS without the commit it was verified at")
        if status == "NOT_IMPLEMENTED" and str(entry.get("verified_at", "")).strip():
            problems.append(f"{rid}: NOT_IMPLEMENTED but claims a verification commit")
        if release:
            if status == "NOT_TESTED":
                problems.append(f"{rid}: NOT_TESTED at release time — it was never executed")
            if status in NEEDS_EVIDENCE:
                allowed = set(allowed_commits or ())
                target = actual_commit or source_commit
                if target:
                    allowed.add(str(target))
                if not entry.get("verified_at"):
                    problems.append(f"{rid}: {status} at release time without a commit it was verified at")
                elif allowed and str(entry["verified_at"]) not in allowed:
                    problems.append(
                        f"{rid}: {status} verified at {entry.get('verified_at')}, not at the release commit {target}"
                        + (f" (or {sorted(allowed - {str(target)})[0]})" if allowed - {str(target)} else "")
                    )

    gates = register.get("gates") or []
    if len(gates) != GATE_COUNT:
        problems.append(f"{len(gates)} gates, expected {GATE_COUNT}")
    numbers = []
    for gate in gates:
        gid = gate.get("id", "?")
        match = GATE_RE.match(str(gid))
        if not match:
            problems.append(f"{gid}: gate id is not of the form 'GATE n'")
            continue
        number = int(match.group(1))
        numbers.append(number)
        expected_kind = "technical" if number <= TECHNICAL_GATES else "external"
        if gate.get("kind") != expected_kind:
            problems.append(f"{gid}: kind {gate.get('kind')!r}, expected {expected_kind}")
        if gate.get("result") not in STATUSES:
            problems.append(f"{gid}: result {gate.get('result')!r} is not in the vocabulary")
        for field in ("title", "owner", "environment", "command", "remaining_limitation"):
            if not str(gate.get(field, "")).strip():
                problems.append(f"{gid}: no {field}")
        if gate.get("result") == "PASS":
            for field in ("evidence", "timestamp", "source_commit"):
                if not str(gate.get(field, "")).strip():
                    problems.append(f"{gid}: PASS without {field}")
            allowed = set(allowed_commits or ())
            if actual_commit:
                allowed.add(str(actual_commit))
            if release and allowed and str(gate.get("source_commit", "")) not in allowed:
                problems.append(f"{gid}: PASS recorded at {gate.get('source_commit')}, not at the release commit {actual_commit}")
    if numbers and sorted(numbers) != list(range(1, GATE_COUNT + 1)):
        problems.append(f"gate numbers are {sorted(numbers)}, expected 1..{GATE_COUNT}")

    if release:
        claimed = str((register.get("meta") or {}).get("source_commit") or "").strip()
        tree = str(actual_commit or source_commit or "").strip()
        if not tree:
            problems.append("the register cannot be released without knowing the commit the tree is at")
        elif not claimed:
            problems.append("the register does not say which commit it was written against")
        elif claimed != tree and not documentation_only_above(claimed, tree):
            problems.append(
                f"the register claims it was written against {claimed}; the source is at {tree}, and the difference "
                "between them is more than the register and the documents generated from it"
            )
    return problems


def recount(register: dict[str, Any]) -> dict[str, Any]:
    """Put the computed counts into ``meta``; return the register as it should be on disk."""
    meta = dict(register.get("meta") or {})
    entries = register["entries"]
    meta["counts"] = counts(entries)
    meta["entries"] = len(entries)
    meta["counts_note"] = "computed from the entries by scripts/build_1_3_0_register.py; never written by hand"
    register["meta"] = meta
    return register


def by_area(entries: list[dict[str, Any]]) -> list[tuple[str, dict[str, int], int]]:
    grouped: dict[str, Counter[str]] = defaultdict(Counter)
    for entry in entries:
        grouped[entry.get("area", "?")][entry["status"]] += 1
    return sorted((area, dict(sorted(counter.items())), sum(counter.values())) for area, counter in grouped.items())


def render(register: dict[str, Any]) -> str:
    meta = register["meta"]
    entries = register["entries"]
    total = len(entries)
    tally = counts(entries)
    lines = [
        "# 1.3.0 — requirement traceability",
        "",
        "Generated from `docs/1_3_0_requirements.json` by `scripts/build_1_3_0_register.py`. Do not edit this file: edit",
        "the register and run the script, or `--check` fails the build.",
        "",
        f"Baseline: **{meta.get('baseline_release', '?')}** at commit `{meta.get('baseline_commit', '?')}`. "
        f"Register written against `{meta.get('source_commit', '?')}`.",
        "",
        "## Counts",
        "",
        "| Status | Requirements |",
        "|---|---|",
        *(f"| {status} | {tally.get(status, 0)} |" for status in STATUSES),
        f"| **total** | **{total}** |",
        "",
        "Each status means one thing, and the meaning is the same in every document of this release: **PASS** — observed",
        "on the current source (the evidence names where); **FAIL** — observed and wrong; **PARTIAL** — some of it exists",
        "and is observed, some does not; **BLOCKED** — the code may exist but the proof needs a party who is not here, and",
        "the dependency is named; **NOT_IMPLEMENTED** — absent from the source; **NOT_TESTED** — present, never executed;",
        "**NOT_APPLICABLE** — the requirement does not apply, and the entry says why.",
        "",
        "## By area",
        "",
        "| Area | Requirements | " + " | ".join(STATUSES) + " |",
        "|---|---|" + "---|" * len(STATUSES),
    ]
    for area, counter, size in by_area(entries):
        lines.append(f"| {area} | {size} | " + " | ".join(str(counter.get(status, 0)) or "·" for status in STATUSES) + " |")
    lines += ["", "## The requirements", "", "| Id | Area | Requirement | Status | Verified at | Evidence | Blocked by | Next step |", "|---|---|---|---|---|---|---|---|"]
    for entry in entries:
        cells = [
            entry["id"],
            entry.get("area", ""),
            str(entry.get("requirement", "")).replace("|", "\\|"),
            f"**{entry['status']}**",
            f"`{entry['verified_at']}`" if entry.get("verified_at") else "—",
            str(entry.get("evidence", "")).replace("|", "\\|") or "—",
            str(entry.get("blocked_by", "")).replace("|", "\\|") or "—",
            str(entry.get("next_step", "")).replace("|", "\\|") or "—",
        ]
        lines.append("| " + " | ".join(cells) + " |")

    stale = [e for e in entries if e["status"] == "PASS" and e.get("verified_at") and e["verified_at"] != meta.get("source_commit")]
    lines += ["", "## The fifteen gates", "", "| Gate | Kind | Result | What closes it | Owner | Environment | Command | Evidence | Remaining limitation |", "|---|---|---|---|---|---|---|---|---|"]
    for gate in register["gates"]:
        cells = [
            gate["id"],
            gate.get("kind", ""),
            f"**{gate['result']}**",
            str(gate.get("title", "")).replace("|", "\\|"),
            str(gate.get("owner", "")).replace("|", "\\|"),
            str(gate.get("environment", "")).replace("|", "\\|"),
            f"`{gate['command']}`" if gate.get("command") else "—",
            str(gate.get("evidence", "")).replace("|", "\\|") or "—",
            str(gate.get("remaining_limitation", "")).replace("|", "\\|"),
        ]
        lines.append("| " + " | ".join(cells) + " |")
    lines += [
        "",
        "## Passes carried from an earlier commit",
        "",
        "A PASS is a statement about the source as it was executed. In this register that is what `verified_at` is for. A",
        "PASS whose `verified_at` is not the commit being released is history, not a current result, and can only be",
        "carried forward by running the evidence again — which is what `--release` insists on.",
        "",
        f"Carried PASSes whose `verified_at` is behind the register's `source_commit` ({meta.get('source_commit', '?')}): **{len(stale)}**.",
        *(f"- {entry['id']} — verified at `{entry['verified_at']}`" for entry in stale),
        "",
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="build, validate and check the 1.3.0 requirement register")
    parser.add_argument("--check", action="store_true", help="fail when the traceability document on disk differs")
    parser.add_argument("--release", action="store_true", help="the stricter checks a release must pass")
    parser.add_argument("--register", default=str(REGISTER), help="register to read (default: docs/1_3_0_requirements.json)")
    parser.add_argument("--document", default=str(DOCUMENT), help="document to write (default: docs/1_3_0_REQUIREMENT_TRACEABILITY.md)")
    parser.add_argument("--junit", action="append", default=[], metavar="PATH",
                        help="a JUnit XML file produced by the suite (repeat it for the second run); required by --release")
    parser.add_argument("--min-tests", type=int, default=None,
                        help="the smallest suite a release accepts (default: the register's meta.test_count)")
    parser.add_argument("--allow-dirty", action="store_true", help="skip the clean-tree check (development only)")
    args = parser.parse_args(argv)

    register_path = Path(args.register)
    register = recount(load(register_path))
    tree = head_commit()
    claimed = register["meta"].get("source_commit") or tree
    candidates: list[str] = [str(register["meta"].get("source_commit") or "")]
    for path in map(Path, args.junit or []):
        sidecar = path.with_suffix(path.suffix + ".meta.json")
        if sidecar.exists():
            try:
                candidates.append(str(json.loads(sidecar.read_text()).get("commit") or ""))
            except json.JSONDecodeError:
                candidates.append("")
    allowed = release_commits(tree, candidates) if args.release else {tree}
    problems = validate(register, source_commit=claimed, release=args.release, actual_commit=tree,
                        allowed_commits=allowed)
    document = render(register)

    evidence: dict[str, Any] = {}
    if args.release:
        if claimed not in allowed:
            problems.append(f"the register claims {claimed}, which is neither the tree ({tree}) nor a documentation-only commit above it")
        if not args.allow_dirty:
            problems.extend(working_tree_problems())
        minimum = args.min_tests if args.min_tests is not None else int(register["meta"].get("test_count") or 0)
        junit_paths = [Path(path) for path in args.junit]
        problems.extend(check_evidence(junit_paths, commit=tree, allowed_commits=allowed, min_tests=minimum))
        evidence = {
            "commit": tree,
            "allowed_commits": sorted(allowed),
            "min_tests": minimum,
            "runs": [junit_totals(path)["tests"] if path.exists() else None for path in junit_paths],
            "junit": [str(path) for path in junit_paths],
        }

    if args.check:
        current = Path(args.document).read_text() if Path(args.document).exists() else ""
        if current != document:
            print(f"{args.document} is out of date; run scripts/build_1_3_0_register.py", file=sys.stderr)
            return 1
    else:
        register_path.write_text(json.dumps(register, indent=1) + "\n")
        Path(args.document).write_text(document)
        tally = register["meta"]["counts"]
        print(f"{len(register['entries'])} requirements: " + ", ".join(f"{k} {v}" for k, v in tally.items()))
        print(f"wrote {args.document}")

    if evidence:
        print(json.dumps(evidence, indent=1))
    for problem in problems:
        print(f"register: {problem}", file=sys.stderr)
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
