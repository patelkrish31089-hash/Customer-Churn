#!/usr/bin/env python3
"""Probe every gate the release declares, and write down what each one actually is at this commit.

    python3 scripts/gate_ledger.py --commit "$(git rev-parse --short HEAD)"
    python3 scripts/gate_ledger.py --check          # fail if the document on disk is stale

The register carries fifteen gates.  Nine of them are BLOCKED, and until this script existed that word was an
assertion in a document: a reader had no way to tell "blocked" from "we did not get to it", and nobody could tell when
a gate had quietly stopped being blocked.  A gate is now a probe — a command this script runs — and the probe answers
one of four things:

* **PASS** — the thing the gate asks for was observed to hold here, and the observation is in the evidence;
* **PARTIAL** — part of it was observed, and the evidence says which part;
* **BLOCKED** — the precondition is *absent*, and the probe names the variable, host, package or account that is
  missing.  This is a fact about this machine, checked rather than declared, and it is the strongest statement a
  repository can make about a vendor it does not have;
* **NOT_IMPLEMENTED** — there is nothing to probe yet.

The rule the script enforces on itself: **it never promotes a gate.**  A probe that finds a precondition *present* says
so and stops, because the thing that closes a vendor gate is an acceptance run against the vendor, not the discovery
that an environment variable is set.  Only the probe of a gate whose criterion this machine can meet on its own —
lint, security, a live database, a clean install from the lock — produces a PASS.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from collections.abc import Callable
from datetime import UTC, datetime
from importlib import metadata
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"
DOCUMENT = ROOT / "docs" / "1_3_0_GATES.md"
LOCK = ROOT / "requirements.lock"


def _run(command: list[str], *, timeout: int = 600) -> tuple[int, str]:
    try:
        finished = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 1, f"{type(exc).__name__}: {exc}"
    return finished.returncode, (finished.stdout or "") + (finished.stderr or "")


def _junit_modules(paths: list[Path]) -> dict[str, tuple[int, int]]:
    """``{module: (tests, failures)}`` from the JUnit files a release run produced."""
    import xml.etree.ElementTree as ET

    counts: dict[str, tuple[int, int]] = {}
    for path in paths:
        if not path.is_file():
            continue
        root = ET.parse(path).getroot()  # noqa: S314  # nosec B314 - the file is this repository's own test output, not input from a user
        for case in root.iter("testcase"):
            classname = case.get("classname") or ""
            parts = classname.split(".")
            module = "tests/" + parts[1] + ".py" if len(parts) > 1 and parts[1].startswith("test_") else ""
            bad = 1 if (case.find("failure") is not None or case.find("error") is not None) else 0
            tests, failures = counts.get(module, (0, 0))
            counts[module] = (tests + 1, failures + bad)
    return counts


def _present(*names: str) -> list[str]:
    """The variables of ``names`` that are set to something."""
    return [name for name in names if str(os.environ.get(name, "")).strip()]


def _missing(*names: str) -> str:
    return ", ".join(names)


# --------------------------------------------------------------------------- the probes
#: Every probe returns ``{"state", "observed", "detail"}``.  ``observed`` is the sentence the document prints; it must
#: be something a reader could check, not a summary of an intention.


def gate_1_postgres(context: dict[str, Any]) -> dict[str, Any]:
    """PostgreSQL live: a real server answering, and the migration and delivery tests passing in the release runs."""
    url = str(os.environ.get("CHURN_TEST_POSTGRES_URL", "")).strip()
    if not url:
        return {"state": "BLOCKED", "observed": "CHURN_TEST_POSTGRES_URL is unset, so no live server was probed",
                "detail": {"precondition_absent": "CHURN_TEST_POSTGRES_URL"}}  # fmt: skip
    try:
        import psycopg
    except ModuleNotFoundError:
        return {"state": "BLOCKED", "observed": "psycopg is not installed, so the server cannot be probed",
                "detail": {"precondition_absent": "psycopg"}}  # fmt: skip
    try:
        with psycopg.connect(url.replace("postgresql+psycopg://", "postgresql://", 1), connect_timeout=5) as connection:
            version, = connection.execute("SELECT version()").fetchone()  # fmt: skip
            tables, = connection.execute("SELECT COUNT(*) FROM information_schema.tables "
                                         "WHERE table_schema = 'public'").fetchone()  # fmt: skip
    except Exception as exc:
        return {"state": "BLOCKED", "observed": f"the server refused the probe: {type(exc).__name__}: {str(exc)[:160]}",
                "detail": {"precondition_absent": "a reachable PostgreSQL"}}  # fmt: skip
    modules = context.get("junit") or []
    evidence = ["tests/test_migrations.py", "tests/test_export_outbox.py", "tests/test_destinations_postgres.py"]
    counted = _junit_modules(modules)
    if not modules:
        return {"state": "PARTIAL", "observed": f"{version.split(' on ')[0]} answered and holds {tables} tables, but no JUnit "
                                                "file was given, so the migration and delivery tests were not checked",
                "detail": {"version": version.split(" on ")[0], "tables": tables}}  # fmt: skip
    absent = [module for module in evidence if module not in counted]
    failing = [module for module in evidence if counted.get(module, (0, 0))[1]]
    if absent or failing:
        return {"state": "PARTIAL", "observed": f"the server answered ({tables} tables) but {', '.join(absent + failing)} "
                                                "did not appear in the release runs", "detail": {"absent": absent, "failing": failing}}  # fmt: skip
    return {"state": "PASS",
            "observed": f"{version.split(' on ')[0]} answered; {', '.join(evidence)} ran with no failure in the release runs; "
                        f"{tables} tables in public",
            "detail": {"version": version.split(" on ")[0], "tables": tables, "modules": evidence}}  # fmt: skip


def gate_2_container(context: dict[str, Any]) -> dict[str, Any]:
    """A container runtime: the image built, compose up, restart, backup, restore."""
    docker = shutil.which("docker")
    if not docker:
        return {"state": "BLOCKED", "observed": "no docker binary on PATH, so no image can be built or run here",
                "detail": {"precondition_absent": "docker"}}  # fmt: skip
    code = _run([docker, "info"], timeout=60)[0]
    return {"state": "PARTIAL" if code == 0 else "BLOCKED",
            "observed": f"docker is present and `docker info` exited {code}; no 1.3.0 image has been built from this tree",
            "detail": {}}  # fmt: skip


def gate_3_clean_install(context: dict[str, Any]) -> dict[str, Any]:
    """Every pin in the lock is installed at the version the lock names."""
    pins: dict[str, str] = {}
    for line in LOCK.read_text().splitlines():
        text = line.strip()
        if not text or text.startswith("#") or text.startswith("-") or "==" not in text or ";" in text:
            continue
        name, version = text.split("==", 1)
        pins[name.split("[")[0].strip().lower()] = version.strip()
    if not pins:
        return {"state": "BLOCKED", "observed": "the lock file named no pins", "detail": {}}
    installed, missing, wrong = {}, [], []
    for name, version in pins.items():
        try:
            found = metadata.version(name)
        except metadata.PackageNotFoundError:
            missing.append(name)
            continue
        installed[name] = found
        if found != version:
            wrong.append(f"{name} {found} != {version}")
    if wrong:
        return {"state": "PARTIAL", "observed": f"{len(pins) - len(missing) - len(wrong)} of {len(pins)} pins exact; {len(wrong)} differ",
                "detail": {"differ": wrong[:10]}}  # fmt: skip
    return {"state": "PASS" if not missing else "PARTIAL",
            "observed": f"{len(installed)} of {len(pins)} pins installed at the locked version; {len(missing)} are for "
                        f"another platform or extra and are absent",
            "detail": {"missing": sorted(missing)[:12], "pins": len(pins)}}  # fmt: skip


def gate_4_scheduler(context: dict[str, Any]) -> dict[str, Any]:
    """A real scheduler with multi-cycle execution."""
    try:
        import airflow  # type: ignore[import-not-found]  # noqa: F401
    except ModuleNotFoundError:
        return {"state": "BLOCKED", "observed": "apache-airflow is not installed, so no scheduler exists to run cycles",
                "detail": {"precondition_absent": "apache-airflow"}}  # fmt: skip
    return {"state": "PARTIAL", "observed": "apache-airflow imports; no 1.3.0 schedule has been run through it", "detail": {}}


def gate_5_mlflow(context: dict[str, Any]) -> dict[str, Any]:
    """A remote, authenticated MLflow registry."""
    url = _present("CHURN_MLFLOW_TRACKING_URI", "MLFLOW_TRACKING_URI")
    local = ROOT / "var" / "data" / "mlflow"
    if not url:
        return {"state": "BLOCKED", "observed": "no tracking URI is configured (CHURN_MLFLOW_TRACKING_URI); the mirror "
                                                "is local only", "detail": {"precondition_absent": "a remote tracking URI"}}  # fmt: skip
    return {"state": "PARTIAL", "observed": f"a tracking URI is configured ({url[0]}); no authenticated server was probed by this script",
            "detail": {"local_mirror": local.is_dir()}}  # fmt: skip


def gate_6_lint_security(context: dict[str, Any]) -> dict[str, Any]:
    """ruff, bandit, pip-audit and the secret scan — run, not remembered.

    ``bandit`` is read from its JSON report rather than its exit code, and that is a decision worth stating: bandit
    exits 1 when it finds something **and also** when it meets a ``# nosec`` marker that suppressed nothing.  The
    second case is a comment to tidy, not a vulnerability, and treating the two as the same thing would either fail a
    release over a stale comment or teach everyone to ignore the gate.  The number of unused markers is reported here
    so that it stays visible instead of becoming a silence.
    """
    results = {}
    for name, command in (
        ("ruff", [sys.executable, "-m", "ruff", "check", "."]),
        ("pip-audit", [sys.executable, "-m", "pip_audit", "--requirement", "requirements.lock", "--strict",
                       "--disable-pip", "--no-deps"]),
        ("secrets", [sys.executable, "scripts/scan_secrets.py"]),
    ):
        code, output = _run(command)
        results[name] = {"exit": code, "tail": output.strip().splitlines()[-1][:200] if output.strip() else ""}
    bandit_json = ROOT / "release" / "bandit.json"
    bandit_json.parent.mkdir(exist_ok=True)
    code, output = _run([sys.executable, "-m", "bandit", "-q", "-r", "src", "scripts", "-x", "tests", "-ll",
                         "-f", "json", "-o", str(bandit_json)])
    try:
        report = json.loads(bandit_json.read_text())
    except (OSError, ValueError):
        report = {"results": [{"issue_text": "bandit produced no readable report"}], "metrics": {}}
    results["bandit"] = {"findings": len(report.get("results", [])),
                         "unused_nosec": len([line for line in output.splitlines() if "nosec encountered" in line])}
    findings = [name for name, result in results.items() if result.get("exit") or result.get("findings")]
    state = "PASS" if not findings else "PARTIAL"
    if not findings:
        observed = (f"ruff, pip-audit and the secret scan exited 0; bandit reports {len(report.get('results', []))} "
                    f"findings at high or medium, with {results['bandit']['unused_nosec']} `# nosec` markers that "
                    "suppress nothing and are counted rather than hidden")
    else:
        observed = f"{', '.join(findings)} reported something"
    return {"state": state, "observed": observed, "detail": results}


def gate_7_distributed(context: dict[str, Any]) -> dict[str, Any]:
    """Distributed rate limiting, hosted OIDC, TLS — none of which a local process can prove."""
    redis = _present("CHURN_REDIS_URL")
    return {"state": "BLOCKED", "observed": "no Redis is configured (CHURN_REDIS_URL unset), so the limiter is the "
                                            "single-process store the release says it is", "detail": {"redis": bool(redis)}}  # fmt: skip


def gate_8_deletion(context: dict[str, Any]) -> dict[str, Any]:
    """Customer deletion and correction with a restore verification."""
    return {"state": "NOT_IMPLEMENTED", "observed": "no deletion path exists in the product; nothing to probe",
            "detail": {}}  # fmt: skip


def gate_9_load(context: dict[str, Any]) -> dict[str, Any]:
    """Sustained load on a host somebody owns."""
    host = _present("CHURN_STAGING_HOST")
    return {"state": "BLOCKED", "observed": "no staging host is configured (CHURN_STAGING_HOST unset); the 1.3.0 figures "
                                            "are one machine and one process",
            "detail": {"staging": bool(host)}}  # fmt: skip


def gate_10_labelled_data(context: dict[str, Any]) -> dict[str, Any]:
    """A labelled, non-synthetic sample and a model measured on it."""
    path = _present("CHURN_LABELLED_SAMPLE")
    return {"state": "BLOCKED", "observed": "no labelled sample exists (CHURN_LABELLED_SAMPLE unset); every ML figure in "
                                            "this release is on synthetic data and says so",
            "detail": {"sample": bool(path)}}  # fmt: skip


def gate_11_crm_vendors(context: dict[str, Any]) -> dict[str, Any]:
    """Salesforce, HubSpot and Intercom sandbox acceptance."""
    names = ("CHURN_SALESFORCE_CLIENT_ID", "CHURN_HUBSPOT_CLIENT_ID", "CHURN_INTERCOM_CLIENT_ID")
    found = _present(*names)
    return {"state": "BLOCKED" if len(found) < len(names) else "PARTIAL",
            "observed": f"no vendor sandbox is configured: {_missing(*[n for n in names if n not in found])} "
                        f"{'are unset' if len(found) < len(names) else 'are set, but no acceptance run has been made'}",
            "detail": {"configured": found}}  # fmt: skip


def gate_12_warehouse(context: dict[str, Any]) -> dict[str, Any]:
    """Snowflake, Zendesk and Marketo acceptance."""
    names = ("CHURN_EXPORT_SNOWFLAKE_ACCOUNT", "CHURN_ZENDESK_SUBDOMAIN", "CHURN_MARKETO_CLIENT_ID")
    found = _present(*names)
    driver = True
    try:
        import snowflake.connector  # type: ignore[import-not-found]  # noqa: F401
    except ModuleNotFoundError:
        driver = False
    return {"state": "BLOCKED" if len(found) < len(names) else "PARTIAL",
            "observed": f"no warehouse and no support desk are configured: {_missing(*[n for n in names if n not in found])} "
                        f"are unset; snowflake-connector-python is {'installed' if driver else 'not installed'}, so the "
                        "adapter has never been given a session",
            "detail": {"configured": found, "driver": driver,
                       "plan": "scripts/snowflake_upgrade_1_3_0.py prints the upgrade for an existing table"}}


def gate_13_messaging(context: dict[str, Any]) -> dict[str, Any]:
    """Email, SMS and push by a real provider."""
    names = ("CHURN_SES_REGION", "CHURN_TWILIO_ACCOUNT_SID", "CHURN_FCM_PROJECT_ID", "CHURN_APNS_KEY_ID")
    found = _present(*names)
    return {"state": "BLOCKED" if len(found) < len(names) else "PARTIAL",
            "observed": f"no sending account exists: {_missing(*[n for n in names if n not in found])} are unset. The SMTP "
                        "path is exercised against a real SMTP server in the suite, which proves the protocol and not a provider",
            "detail": {"configured": found}}  # fmt: skip


def gate_14_staging(context: dict[str, Any]) -> dict[str, Any]:
    """Hosted staging, monitoring and disaster recovery."""
    host = _present("CHURN_STAGING_HOST", "CHURN_STAGING_URL")
    return {"state": "BLOCKED" if not host else "PARTIAL",
            "observed": "no host, domain or RPO/RTO is configured, so nothing outside this machine has been run",
            "detail": {"configured": host}}  # fmt: skip


def gate_15_assessor(context: dict[str, Any]) -> dict[str, Any]:
    """An independent penetration test, CI on a hosted runner, a signed business case."""
    cis = _present("GITHUB_ACTIONS", "CI")
    return {"state": "BLOCKED", "observed": "no assessor and no hosted runner: this process is "
                                            f"{'a CI runner' if cis else 'a local shell'}, and no penetration test has been commissioned",
            "detail": {"ci": bool(cis)}}  # fmt: skip


PROBES: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
    "GATE 1": gate_1_postgres,
    "GATE 2": gate_2_container,
    "GATE 3": gate_3_clean_install,
    "GATE 4": gate_4_scheduler,
    "GATE 5": gate_5_mlflow,
    "GATE 6": gate_6_lint_security,
    "GATE 7": gate_7_distributed,
    "GATE 8": gate_8_deletion,
    "GATE 9": gate_9_load,
    "GATE 10": gate_10_labelled_data,
    "GATE 11": gate_11_crm_vendors,
    "GATE 12": gate_12_warehouse,
    "GATE 13": gate_13_messaging,
    "GATE 14": gate_14_staging,
    "GATE 15": gate_15_assessor,
}


def probe_all(junit: list[Path] | None = None) -> list[dict[str, Any]]:
    """Probe every gate that the register lists, in the register's order."""
    register = json.loads(REGISTER.read_text())
    context = {"junit": junit or []}
    results = []
    for gate in register["gates"]:
        probe = PROBES.get(gate["id"])
        result = probe(context) if probe else {"state": "NOT_IMPLEMENTED", "observed": "no probe is written for this gate", "detail": {}}
        results.append({**gate, **{"probe": result["state"], "observed": result["observed"], "probe_detail": result["detail"]}})
    return results


def document(results: list[dict[str, Any]], commit: str) -> str:
    by_state: dict[str, int] = {}
    for result in results:
        by_state[result["probe"]] = by_state.get(result["probe"], 0) + 1
    lines = [
        "# 1.3.0 — the gates, probed",
        "",
        "Generated by `scripts/gate_ledger.py`; `--check` fails when this file is stale.  Every row is the output of a",
        "command that ran at **" + commit + "** on this machine.  `BLOCKED` here means a probe looked for the",
        "precondition and did not find it — not that somebody wrote the word in a table.",
        "",
        "| | |",
        "|---|---|",
        f"| commit | `{commit}` |",
        "| gates | " + ", ".join(f"{state} {count}" for state, count in sorted(by_state.items())) + " |",
        "| probes | `python3 scripts/gate_ledger.py --commit " + commit + "` |",
        "",
        "A probe never promotes a gate: finding an environment variable set is not an acceptance run, so the script",
        "reports it and leaves the status alone.  The gates this machine can decide on its own — a live PostgreSQL",
        "with the migration and delivery tests passing, the four lint and security tools, and an installation that",
        "matches the lock pin for pin — are decided here and nowhere else.",
        "",
        "| Gate | Owner | Declared | Probed | What the probe found |",
        "|---|---|---|---|---|",
    ]
    for result in results:
        lines.append(f"| {result['id']} — {result['title']} | {result['owner']} | {result['result']} | **{result['probe']}** | {result['observed']} |")
    lines += [
        "",
        "## What closes each blocked gate",
        "",
        "| Gate | The one thing missing |",
        "|---|---|",
    ]
    for result in results:
        if result["probe"] in ("BLOCKED", "NOT_IMPLEMENTED", "PARTIAL") and result["result"] != "PASS":
            lines.append(f"| {result['id']} | {result['remaining_limitation']} |")
    lines += [
        "",
        "## The gates this release passes, and on what",
        "",
        "| Gate | Evidence |",
        "|---|---|",
    ]
    for result in results:
        if result["probe"] == "PASS":
            lines.append(f"| {result['id']} | {result['observed']} |")
    lines.append("")
    return "\n".join(lines) + "\n"


def write_register(results: list[dict[str, Any]], commit: str, path: Path = REGISTER) -> int:
    """Put each probe beside the gate it probed, without touching the gate's declared result.

    A probe may only *narrow*.  It cannot promote a gate, because the criterion of a vendor gate is an acceptance run
    against the vendor and the criterion of a technical gate may be wider than what one machine can show — GATE 3 asks
    for three interpreters, and this machine has one.  So the register now carries two answers per gate: what the
    release declares and what a command found here, with the commit each was observed at.  Where they disagree, the
    document prints both and a reader can see the disagreement instead of a reconciliation nobody can check.
    """
    register = json.loads(path.read_text())
    stamped = 0
    observed_at = datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")
    for gate in register["gates"]:
        match = next((result for result in results if result["id"] == gate["id"]), None)
        if match is None:
            continue
        gate["probe"] = match["probe"]
        gate["probe_evidence"] = match["observed"]
        gate["probe_commit"] = commit
        gate["probe_observed_at"] = observed_at
        stamped += 1
    path.write_text(json.dumps(register, indent=1) + "\n")
    return stamped


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="probe every release gate and write what it found")
    parser.add_argument("--commit", default="", help="the commit the probe is made at (default: git HEAD)")
    parser.add_argument("--document", default=str(DOCUMENT))
    parser.add_argument("--check", action="store_true", help="fail when the document on disk differs")
    parser.add_argument("--json", default="", help="also write the probes here")
    parser.add_argument("--junit", type=Path, action="append", default=None,
                        help="a JUnit file of the release run; the gates that rest on tests are checked against it")
    parser.add_argument("--write-register", action="store_true",
                        help="record each probe in docs/1_3_0_requirements.json beside the gate it probed")
    args = parser.parse_args(argv)

    commit = args.commit.strip()
    if not commit:
        code, output = _run(["git", "rev-parse", "--short", "HEAD"])
        if code:
            raise SystemExit("git could not name the commit; pass --commit")
        commit = output.strip()
    results = probe_all(args.junit)
    text = document(results, commit)
    target = Path(args.document)
    if args.check:
        current = target.read_text() if target.exists() else ""
        if current != text:
            print(f"{target} is stale: run scripts/gate_ledger.py --commit {commit}")
            return 1
        print(f"{target} is up to date ({len(results)} gates)")
        return 0
    target.write_text(text)
    if args.write_register:
        print(f"{write_register(results, commit)} gates now carry their probe in {REGISTER.relative_to(ROOT)}")
    if args.json:
        Path(args.json).write_text(json.dumps({"commit": commit, "gates": results}, indent=1) + "\n")
    by_state: dict[str, int] = {}
    for result in results:
        by_state[result["probe"]] = by_state.get(result["probe"], 0) + 1
    print(f"wrote {target}: " + ", ".join(f"{state} {count}" for state, count in sorted(by_state.items())))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
