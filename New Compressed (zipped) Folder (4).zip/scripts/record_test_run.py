#!/usr/bin/env python3
"""Record what a test run was, next to the JUnit file it produced.

    python3 -m pytest -q --junitxml=release/run1.xml
    python3 scripts/record_test_run.py release/run1.xml "python3 -m pytest -q" ...

The sidecar ``run1.xml.meta.json`` carries the commit the run was made at, the command, the interpreter, when it started
and finished, how many tests ran, and the SHA-256 of the XML.  ``build_1_3_0_register.py --release`` refuses a JUnit file
without one: a bare XML file is a document with no author, no date and no subject, and 1.3.0's own release was nearly
signed off on exactly such a file — a suite recorded at ``0224654`` while the source was at ``b4fd131``.

The command is required, not optional.  "It passed" is not evidence; "this command, at this commit, produced this file"
is.  The sidecar deliberately records no environment secrets: only the interpreter version and the platform.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ElementTree  # nosec S314 - it parses the JUnit file the run just produced, not untrusted input
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def git(*arguments: str) -> str:
    return subprocess.run(["git", *arguments], cwd=ROOT, capture_output=True, text=True, check=False).stdout.strip()


def totals(path: Path) -> dict[str, int]:
    root = ElementTree.parse(path).getroot()  # noqa: S314 - parses the JUnit file the run just produced  # nosec B314 - the file is the run's own JUnit output
    suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
    cases = [case for suite in suites for case in suite.iter("testcase")]
    return {
        "tests": len(cases),
        "failures": sum(1 for case in cases if case.find("failure") is not None),
        "errors": sum(1 for case in cases if case.find("error") is not None),
        "skipped": sum(1 for case in cases if case.find("skipped") is not None),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="write the metadata sidecar for a JUnit file")
    parser.add_argument("junit", help="the JUnit XML file the run wrote")
    parser.add_argument("command", nargs="+", help="the command that produced it, quoted")
    parser.add_argument("--started-at", default=None, help="ISO-8601 start; defaults to now")
    args = parser.parse_args(argv)

    path = Path(args.junit)
    if not path.exists():
        print(f"{path} does not exist", file=sys.stderr)
        return 1
    dirty = [line for line in git("status", "--porcelain").splitlines() if line.strip()]
    sidecar = {
        "junit": str(path),
        "commit": git("rev-parse", "--short=7", "HEAD"),
        "full_commit": git("rev-parse", "HEAD"),
        "branch": git("rev-parse", "--abbrev-ref", "HEAD"),
        "command": " ".join(args.command),
        "started_at": args.started_at or datetime.now(UTC).isoformat(),
        "recorded_at": datetime.now(UTC).isoformat(),
        "interpreter": ".".join(str(part) for part in sys.version_info[:3]),
        "platform": platform.platform(),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "working_tree_clean": not dirty,
        "working_tree_dirty_paths": len(dirty),
        **totals(path),
    }
    target = path.with_suffix(path.suffix + ".meta.json")
    target.write_text(json.dumps(sidecar, indent=1) + "\n")
    print(f"wrote {target}: {sidecar['tests']} tests at {sidecar['commit']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
