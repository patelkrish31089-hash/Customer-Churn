#!/usr/bin/env python3
"""Earlier name of ``build_manifest.py``, kept so that existing instructions keep working.  Same options, same result."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_manifest import main

if __name__ == "__main__":
    sys.exit(main())
