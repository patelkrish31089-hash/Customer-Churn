#!/usr/bin/env python3
"""Build ``docs/1_3_0_FILE_STRUCTURE.md`` from the tree as it actually is.

    python3 scripts/build_1_3_0_file_structure.py           # write the document
    python3 scripts/build_1_3_0_file_structure.py --check    # fail when it is stale

The 1.3.0 brief asks for the project's file structure; the only way for such a document to stay true is to generate it.
Each module is described by its own first docstring line, so the description cannot drift from the code — if a module's
purpose changes, its docstring changes, and this document is rebuilt. Files whose docstring is missing say so, which is
itself a finding rather than a blank.

Nothing secret is read: the document lists names, sizes and docstrings of Python and Markdown files, plus the counts of
tests. It does not read ``.env``, keys, certificates or anything under ``release/``.
"""

from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCUMENT = ROOT / "docs" / "1_3_0_FILE_STRUCTURE.md"
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", "release", "node_modules", ".venv", "build", "dist", ".mypy_cache",
             ".ruff_cache", "data", ".arena"}  # fmt: skip
AREA_TITLES = {
    "src/churn_platform/api": "The HTTP API (FastAPI), one router module per area",
    "src/churn_platform/models": "The ORM models, split by area; importing the package registers every table",
    "src/churn_platform/migrations/versions": "Alembic revisions, one file per release, applied in order",
    "src/churn_platform/services": "The business logic; every service is importable and testable without HTTP",
    "src/churn_platform/services/destinations": "Where predictions are delivered (1.3.0)",
    "src/churn_platform/worker": "The background worker and its job handlers",
    "src/churn_platform/web": "The browser application served by FastAPI (no build step, no CDN)",
    "scripts": "Repository tooling: registers, matrices and release evidence",
    "deploy": "Deployment assets (the Airflow DAG)",
    "docs": "Release documents, the requirement register and the traceability catalogue",
    "tests": "The suite: one module per area, plus the browser tests in tests/e2e",
    "tests/e2e": "End-to-end tests through a real browser (Playwright)",
}


def docstring(path: Path) -> str:
    try:
        module = ast.parse(path.read_text())
    except (SyntaxError, UnicodeDecodeError):
        return "(not parseable as Python)"
    text = (ast.get_docstring(module) or "").strip()
    if not text:
        return "(no module docstring)"
    return text.splitlines()[0].strip()


def files(base: Path) -> list[Path]:
    return sorted(
        path for path in base.iterdir()
        if path.is_file() and not path.name.endswith((".pyc", ".pyo")) and path.name != ".DS_Store"
    )


def directories(base: Path) -> list[Path]:
    return sorted(path for path in base.iterdir() if path.is_dir() and path.name not in SKIP_DIRS)


def describe(directory: Path, depth: int = 0) -> list[str]:
    lines: list[str] = []
    relative = directory.relative_to(ROOT).as_posix()
    title = AREA_TITLES.get(relative)
    header = f"{'#' * (3 + depth)} `{relative}/`"
    lines.append(header)
    lines.append("")
    if title:
        lines += [title, ""]
    python = [path for path in files(directory) if path.suffix == ".py"]
    if python:
        lines += ["| File | Purpose (from its own docstring) |", "|---|---|"]
        for path in python:
            lines.append(f"| `{path.name}` | {docstring(path).replace('|', chr(92) + '|')} |")
        lines.append("")
    other = [path for path in files(directory) if path.suffix != ".py"]
    if other:
        lines.append("Other files: " + ", ".join(f"`{path.name}`" for path in other) + ".")
        lines.append("")
    for child in directories(directory):
        if child.name == "versions" and relative.endswith("migrations"):
            lines += describe_migrations(child)
            continue
        lines += describe(child, depth + 1)
    return lines


def describe_migrations(directory: Path) -> list[str]:
    lines = ["#### `src/churn_platform/migrations/versions/`", "", "Alembic revisions, one file per release, applied in order", ""]
    lines += ["| Revision | Purpose |", "|---|---|"]
    for path in sorted(files(directory)):
        if path.suffix != ".py" or path.name == "__init__.py":
            continue
        lines.append(f"| `{path.name}` | {docstring(path).replace('|', chr(92) + '|')} |")
    lines.append("")
    return lines


def count_tests() -> tuple[int, int]:
    modules = tests = 0
    for path in sorted((ROOT / "tests").rglob("test_*.py")):
        modules += 1
        tree = ast.parse(path.read_text())
        tests += sum(1 for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"))
    return modules, tests


def build() -> str:
    modules, tests = count_tests()
    api_routes = sum(1 for path in (ROOT / "src" / "churn_platform" / "api").glob("routes_*.py"))
    revisions = len(list((ROOT / "src" / "churn_platform" / "migrations" / "versions").glob("[0-9]*.py")))
    lines = [
        "# 1.3.0 — file structure",
        "",
        "Generated from the tree by `scripts/build_1_3_0_file_structure.py`; run the script after adding a module, or",
        "`--check` fails. Every description is the module's own first docstring line, so the document cannot describe a",
        "file differently from the file itself.",
        "",
        "## At a glance",
        "",
        f"- migrations: **{revisions}** (`0001` … `0005`)",
        f"- API router modules: **{api_routes}**",
        f"- test modules: **{modules}**, test functions before parametrisation: **{tests}** (the collected count is in docs/1_3_0_TEST_BASELINE.md)",
        "- packages: `api`, `models`, `migrations`, `services`, `services/destinations`, `worker`",
        "",
        "## Layout",
        "",
        "```",
        *(line for line in _tree(ROOT)),
        "```",
        "",
        "## The source, area by area",
        "",
    ]
    for area in ("src/churn_platform", "src/churn_platform/api", "src/churn_platform/models",
                 "src/churn_platform/services", "src/churn_platform/services/destinations",
                 "src/churn_platform/worker", "src/churn_platform/web", "scripts", "deploy", "tests", "tests/e2e", "docs"):  # fmt: skip
        path = ROOT / area
        if not path.exists():
            continue
        title = AREA_TITLES.get(area, "")
        heading = "##" if area.count("/") <= 1 else "###"
        lines += [f"{heading} `{area}/`", ""]
        if title:
            lines += [title, ""]
        python = [item for item in files(path) if item.suffix == ".py"]
        if python:
            lines += ["| File | Purpose |", "|---|---|"]
            lines += [f"| `{item.name}` | {docstring(item).replace('|', chr(92) + '|')} |" for item in python]
            lines.append("")
        subdirs = [item.name for item in directories(path)]
        if subdirs:
            lines += [f"Subdirectories: {', '.join(f'`{name}/`' for name in subdirs)}", ""]
        if area.endswith("migrations"):
            continue
    lines += describe_migrations(ROOT / "src" / "churn_platform" / "migrations" / "versions")
    lines += [
        "## What is deliberately not in this document",
        "",
        "- no file contents: the structure is the map, the code is the territory;",
        "- no `.env`, key, certificate or credential file is read or listed;",
        "- no `release/` artefacts: they are build output, and the manifest of a release is described in",
        "  `docs/1_3_0_FINAL_TEST_REPORT.md` instead.",
        "",
    ]
    return "\n".join(lines)


def _tree(base: Path, prefix: str = "") -> list[str]:
    entries = directories(base) + files(base)
    entries = [entry for entry in entries if not entry.name.startswith(".") or entry.name in (".github", ".env.example")]
    out: list[str] = []
    for index, entry in enumerate(entries):
        last = index == len(entries) - 1
        marker = "└── " if last else "├── "
        out.append(prefix + marker + entry.name + ("/" if entry.is_dir() else ""))
        if entry.is_dir() and entry.relative_to(ROOT).as_posix() not in ("docs/brief", "docs/traceability"):
            out += _tree(entry, prefix + ("    " if last else "│   "))
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="build the 1.3.0 file structure document")
    parser.add_argument("--check", action="store_true", help="fail when the document on disk is stale")
    args = parser.parse_args(argv)
    document = build()
    if args.check:
        current = DOCUMENT.read_text() if DOCUMENT.exists() else ""
        if current != document:
            print(f"{DOCUMENT.relative_to(ROOT)} is out of date; run scripts/build_1_3_0_file_structure.py", file=sys.stderr)
            return 1
        print(f"{DOCUMENT.relative_to(ROOT)} is up to date")
        return 0
    DOCUMENT.write_text(document)
    print(f"wrote {DOCUMENT.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
