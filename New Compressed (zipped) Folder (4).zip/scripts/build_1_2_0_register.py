#!/usr/bin/env python3
"""Render the 1.2.0 requirement register (Markdown) from its source of truth (JSON).

    python scripts/build_1_2_0_register.py            # write docs/1_2_0_REQUIREMENT_TRACEABILITY.md
    python scripts/build_1_2_0_register.py --check    # fail when the Markdown is out of date

The JSON is edited by hand — one entry per requirement, with the evidence that made its status true and, for a
BLOCKED one, what would unblock it.  The gates are listed here because they are a fixed set agreed with the
master prompt, and each one names the requirements that carry it.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "docs" / "1_2_0_requirements.json"
TARGET = ROOT / "docs" / "1_2_0_REQUIREMENT_TRACEABILITY.md"
ORDER = ("PASS", "PARTIAL", "FAIL", "BLOCKED", "NOT_IMPLEMENTED", "NOT_TESTED", "NOT_APPLICABLE")

GATES = (
    ("GATE 1", "technical", "PASS", "PostgreSQL runtime, migrations, concurrency (R-46)"),
    ("GATE 2", "technical", "PARTIAL", "Docker build and runtime (R-48) — rebuilt and re-verified for 1.2.0"),
    ("GATE 3", "technical", "PASS", "Clean dependency installation on three interpreters (R-56)"),
    ("GATE 4", "technical", "PARTIAL", "Airflow scheduler and remote MLflow (R-34, R-36)"),
    ("GATE 5", "technical", "PASS", "Ruff, Bandit, pip-audit, secret scanning (R-44): all four commands clean at 0224654"),
    ("GATE 6", "technical", "BLOCKED", "Sentiment and adoption evaluation on labelled data (R-27, R-31)"),
    ("GATE 7", "technical", "PARTIAL", "Multi-process rate limiting PASS; hosted OIDC and production TLS BLOCKED (R-42, R-39)"),
    ("GATE 8", "technical", "BLOCKED", "Sustained load and staging recovery (R-50)"),
    ("GATE 9", "external", "BLOCKED", "Salesforce, HubSpot, Intercom sandbox acceptance (R-01..R-03)"),
    ("GATE 10", "external", "BLOCKED", "Real email, SMS and push provider acceptance (R-12, R-19..R-21)"),
    ("GATE 11", "external", "BLOCKED", "Hosted staging deployment"),
    ("GATE 12", "external", "BLOCKED", "Real-company churn-model validation (R-51)"),
    ("GATE 13", "external", "BLOCKED", "Business-policy and financial-assumption approval (R-52)"),
    ("GATE 14", "external", "BLOCKED", "Independent penetration testing (R-45)"),
    ("GATE 15", "external", "BLOCKED", "Disaster-recovery acceptance by the system owner (R-47, R-50)"),
)


def escape(text: str | None) -> str:
    return (text or "").replace("|", "\\|")


def render() -> str:
    document = json.loads(SOURCE.read_text())
    meta, entries = document["meta"], document["entries"]
    counts = dict.fromkeys(ORDER, 0)
    for entry in entries:
        counts[entry["status"]] = counts.get(entry["status"], 0) + 1
        if entry["status"] not in ORDER:
            raise SystemExit(f"{entry['id']}: unknown status {entry['status']}")
        if entry["status"] == "BLOCKED" and not entry.get("blocked_by"):
            raise SystemExit(f"{entry['id']}: BLOCKED without saying what would unblock it")
        if entry["status"] == "PASS" and not entry.get("evidence"):
            raise SystemExit(f"{entry['id']}: PASS without evidence")
    lines = [
        "# 1.2.0 — requirement traceability",
        "",
        "Generated from `docs/1_2_0_requirements.json` (edit that file, then re-run `scripts/build_1_2_0_register.py`).",
        "",
        f"Source: release {meta['source_release']}, commit `{meta['source_commit']}`.",
        "",
        "## Counts at the baseline",
        "",
        "| Status | Requirements |",
        "|---|---|",
        *(f"| {status} | {counts.get(status, 0)} |" for status in ORDER),
        "",
        f"**{len(entries)} requirements.** No requirement is PASS without evidence at the source commit;",
        "no requirement is BLOCKED without naming what would unblock it.",
        "",
        "## The register",
        "",
        "| ID | Area | Requirement | Status | Evidence | What is next | Unblocked by |",
        "|---|---|---|---|---|---|---|",
        *(
            f"| {e['id']} | {escape(e['area'])} | {escape(e['requirement'])} | **{e['status']}** | {escape(e['evidence'])} | "
            f"{escape(e['next_step'])} | {escape(e['blocked_by'])} |"
            for e in entries
        ),
        "",
        "## How a status changes",
        "",
        "1. A change to the code makes every PASS that covers it stale: the status goes back to NOT_TESTED until a run at",
        "   the new commit restores it.",
        "2. A BLOCKED item is only closed by evidence the blocker names — an account, a dataset, an assessor, a host.",
        "3. A NOT_APPLICABLE item is only valid with its reason written down, and the reason is reviewable.",
        "",
        "## Gates",
        "",
        "| Gate | Kind | State | Requirement |",
        "|---|---|---|---|",
        *(f"| {gate} | {kind} | **{state}** | {text} |" for gate, kind, state, text in GATES),
        "",
        "A technical gate may only move to PASS with a run recorded at the final commit. An external gate may only move",
        "to PASS with evidence from the party it names; nothing here can be closed from this machine.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="exit 1 when the Markdown is not what the JSON renders to")
    args = parser.parse_args(argv)
    rendered = render()
    if args.check:
        current = TARGET.read_text() if TARGET.exists() else ""
        if current != rendered:
            print(f"{TARGET.relative_to(ROOT)} is out of date; run scripts/build_1_2_0_register.py", file=sys.stderr)
            return 1
        print(f"{TARGET.relative_to(ROOT)} matches docs/1_2_0_requirements.json")
        return 0
    TARGET.write_text(rendered)
    print(f"wrote {TARGET.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
