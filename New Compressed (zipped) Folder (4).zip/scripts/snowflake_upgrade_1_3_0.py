#!/usr/bin/env python3
"""Print the statements that upgrade a 1.2.0 Snowflake table to the 1.3.0 identity.

    python3 scripts/snowflake_upgrade_1_3_0.py --tenant-id 1
    python3 scripts/snowflake_upgrade_1_3_0.py --tenant-id 1 --schema ANALYTICS --destructive --sql

It prints; it does not connect.  There is no warehouse in this repository, so the plan is something a person reads,
checks against their own table and then runs with their own credentials and their own change process.  ``--sql`` prints
only the statements, so the output can be reviewed in a pull request and pasted into a change ticket.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from churn_platform.services.destinations import snowflake, snowflake_upgrade  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="print the 1.3.0 warehouse upgrade plan")
    parser.add_argument("--table", default=snowflake.TABLE)
    parser.add_argument("--runs-table", default=snowflake.RUNS_TABLE)
    parser.add_argument("--schema", default=None, help="the schema the tables live in (default: the session's)")
    parser.add_argument("--tenant-id", type=int, default=None, help="the tenant the existing rows belong to")
    parser.add_argument("--destructive", action="store_true", help="include the primary-key replacement")
    parser.add_argument("--sql", action="store_true", help="print only the statements, one per line")
    args = parser.parse_args(argv)

    document = snowflake_upgrade.plan(table=args.table, runs_table=args.runs_table, schema=args.schema,
                                      tenant_id=args.tenant_id)  # fmt: skip
    planned = snowflake_upgrade.statements(document, destructive=args.destructive, tenant_id=args.tenant_id)
    if args.sql:
        for item in planned:
            print(f"{item['sql']};")
        return 0
    print(json.dumps({**document, "runnable": planned, "destructive_included": args.destructive}, indent=1))
    if not args.destructive:
        print("\n(the primary-key replacement is not in this list: pass --destructive when you have decided to rebuild)")
    if args.tenant_id is None:
        print("(the tenant fill is not in this list: pass --tenant-id N, the tenant those rows belong to)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
