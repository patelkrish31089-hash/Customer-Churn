#!/usr/bin/env python3
"""The 1.2.0 SMTP acceptance, re-run here: 73 messages, one mail server, no vendor.

    pip install aiosmtpd                       # a dev tool, not a dependency of the platform
    python3 scripts/acceptance_smtp_73.py --json /var/tmp/release/smtp-73.json

Why this exists.  `R-13` was recorded as PASS during 1.1.1 against Mailpit and then **withdrawn** at 1.3.0, because
there was no mail server in the release environment and a PASS nobody can repeat is history.  The suite does deliver
over SMTP in `tests/test_outbound.py`, against a small server written for the test — which proves the platform's
half of the conversation and shares the test's assumptions about the other half.

This script removes that objection as far as a machine without a provider can: it starts **aiosmtpd**, an SMTP server
this repository did not write, sends the platform's own messages through
`churn_platform.services.notify._smtp_call` — the function the product uses, not a copy of it — and counts what the
server accepted.  What it still does not prove is a *provider*: no SES, no SendGrid, no reputation, no bounce handling.
GATE 13 stays BLOCKED, and the register says so in the same sentence that records this PASS.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

MESSAGES = 73


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="send 73 messages through the platform's SMTP transport")
    parser.add_argument("--json", default="", help="write the measurement here")
    parser.add_argument("--messages", type=int, default=MESSAGES)
    args = parser.parse_args(argv)

    try:
        from aiosmtpd.controller import Controller
    except ModuleNotFoundError:
        print("aiosmtpd is not installed: pip install aiosmtpd (a dev tool, not a dependency of the platform)")
        return 2

    os.environ.setdefault("CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS", "true")  # the server is on this machine
    os.environ.setdefault("CHURN_ENV", "development")
    from churn_platform.services import notify

    received: list[str] = []

    class Sink:
        async def handle_DATA(self, server, session, envelope):  # the aiosmtpd protocol; the names are its own
            received.append(envelope.content.decode("utf-8", "replace"))
            return "250 2.0.0 Message accepted for delivery"

    # aiosmtpd probes the port it is given, so it is given a free one rather than 0
    import socket

    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    controller = Controller(Sink(), hostname="127.0.0.1", port=port)
    controller.start()
    accepted = refused = 0
    failures: list[str] = []
    try:
        for index in range(args.messages):
            request = {
                "method": "SMTP",
                "smtp": {"host": "127.0.0.1", "port": port, "starttls": False, "username": None, "password": None},
                "json": {
                    "from": "retention@corp.example",
                    "from_name": "Retention",
                    "to": f"customer{index}@example.test",
                    "subject": f"Acceptance message {index + 1}",
                    "body": f"Message {index + 1} of {args.messages}, sent through the platform's SMTP transport.",
                    "message_ref": f"smtp-acceptance-{index + 1}",
                },
            }
            try:
                answer = notify._smtp_call(request)  # the product's transport, not a copy of it
            except Exception as exc:  # a refusal is counted, not raised: the point is the count
                refused += 1
                failures.append(f"{index + 1}: {type(exc).__name__}: {str(exc)[:120]}")
                continue
            if int(answer.status_code) == 250:
                accepted += 1
            else:
                refused += 1
                failures.append(f"{index + 1}: status {answer.status_code}")
    finally:
        controller.stop()

    passed = accepted == args.messages and len(received) == args.messages
    report = {
        "measured_at": datetime.now(UTC).isoformat(),
        "server": "aiosmtpd (independent implementation, dev tool)",
        "transport": "churn_platform.services.notify._smtp_call",
        "messages_attempted": args.messages,
        "accepted_with_250": accepted,
        "received_by_the_server": len(received),
        "refused": refused,
        "failures": failures[:5],
        "all_received_have_the_reference_header": sum(1 for body in received if "X-Churn-Message-Ref: smtp-acceptance" in body),
        "result": "PASS" if passed else "FAIL",
        "limit": "An SMTP protocol acceptance on this machine. No provider, no reputation, no bounce handling: GATE 13 is BLOCKED.",
    }
    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        Path(args.json).write_text(json.dumps(report, indent=1) + "\n")
    print(json.dumps({key: report[key] for key in ("messages_attempted", "accepted_with_250", "received_by_the_server", "result")}, indent=1))
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
