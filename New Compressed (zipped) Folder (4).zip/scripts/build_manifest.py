#!/usr/bin/env python3
"""Build, verify and package the release manifest.

    python scripts/build_manifest.py --junit report.xml --zip release/churn-platform.zip
    python scripts/build_manifest.py --check            # in an unpacked release: is every file what the manifest says?

The manifest (``release/MANIFEST.json`` in a checkout, ``MANIFEST.json`` at the top of an unpacked release)
lists every file of the release with its size and SHA-256, the version, the git commit it was built from
and the test evidence it was built with.  ``--zip`` writes the release archive and reads it back to verify
every member against the manifest.  ``--check`` compares a manifest with the files on disk and exits with
status 1 when a file is missing, changed or not listed.

Only the standard library is used.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import tomllib
import xml.etree.ElementTree as ET
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MANIFEST_NAME = "MANIFEST.json"
# never part of a release: version control, caches, runtime state, earlier release output, the manifest itself
SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".ruff_cache", ".venv", "venv", "node_modules", "var", "release", "htmlcov", ".mypy_cache"}
SKIP_TOP_DIRS = {"build", "dist"}  # left behind by building the package in the tree; only at the top, so nothing can hide deeper down
SKIP_SUFFIXES = (".pyc", ".pyo", ".db", ".db-wal", ".db-shm", ".egg-info")
SKIP_NAMES = {MANIFEST_NAME, ".coverage", ".env"}
ZIP_TIME = (2026, 1, 1, 0, 0, 0)  # fixed member timestamp: the same files give the same archive


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _excluded(relative: Path) -> bool:
    return (any(part in SKIP_DIRS or part.endswith(".egg-info") for part in relative.parts) or relative.name in SKIP_NAMES
            or relative.name.endswith(SKIP_SUFFIXES) or (len(relative.parts) > 1 and relative.parts[0] in SKIP_TOP_DIRS))  # fmt: skip


def _git(root: Path, *args: str) -> str | None:
    if not (root / ".git").exists():
        return None
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, timeout=60, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return done.stdout if done.returncode == 0 else None


def release_files(root: Path) -> list[Path]:
    """Files of the release, relative to ``root``: what git tracks or would track; without git, everything not excluded."""
    listed = _git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard")
    if listed is not None:
        candidates = [Path(name) for name in listed.split("\0") if name]
    else:
        candidates = [path.relative_to(root) for path in root.rglob("*") if path.is_file()]
    return sorted({p for p in candidates if (root / p).is_file() and not _excluded(p)}, key=lambda p: p.as_posix())


def git_state(root: Path) -> dict | None:
    commit = _git(root, "rev-parse", "HEAD")
    if commit is None:
        return None
    changed = [line[3:] for line in (_git(root, "status", "--porcelain") or "").splitlines() if line.strip()]
    return {"commit": commit.strip(), "branch": (_git(root, "rev-parse", "--abbrev-ref", "HEAD") or "").strip(), "dirty": bool(changed),
            "uncommitted": changed}  # fmt: skip


def test_evidence(reports: list[Path]) -> dict | None:
    if not reports:
        return None
    totals = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    files = []
    for path in reports:
        root = ET.parse(path).getroot()  # noqa: S314 - the reports are written by our own test run  # nosec B314
        suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
        for suite in suites:
            for key in totals:
                totals[key] += int(suite.get(key, 0))
            files.append({"file": path.name, "sha256": sha256(path), "started": suite.get("timestamp", "")})
    return {**totals, "passed": totals["tests"] - totals["failures"] - totals["errors"] - totals["skipped"], "reports": files}


def traceability(root: Path) -> dict | None:
    path = root / "docs" / "traceability" / "traceability.json"
    if not path.is_file():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data.get("requirements", [])
    return {"requirements": len(rows), "verified": sum(1 for r in rows if str(r.get("status", "")).startswith("verified")), "complete": bool(data.get("complete")),
            "tests": data.get("totals", {})}  # fmt: skip


def build(root: Path, reports: list[Path]) -> dict:
    with (root / "pyproject.toml").open("rb") as handle:
        project = tomllib.load(handle)["project"]
    files = [{"path": p.as_posix(), "bytes": (root / p).stat().st_size, "sha256": sha256(root / p)} for p in release_files(root)]
    return {"name": project["name"], "version": project["version"], "generated_at": datetime.now(UTC).isoformat(timespec="seconds"),
            "python": platform.python_version(), "git": git_state(root), "tests": test_evidence(reports), "traceability": traceability(root),
            "file_count": len(files), "total_bytes": sum(f["bytes"] for f in files), "files": files}  # fmt: skip


def check(root: Path, manifest: dict) -> list[str]:
    """Differences between a manifest and the files under ``root`` (empty when they agree)."""
    problems = []
    listed = {entry["path"]: entry for entry in manifest.get("files", [])}
    for name, entry in listed.items():
        path = root / name
        if not path.is_file():
            problems.append(f"missing: {name}")
        elif path.stat().st_size != entry["bytes"] or sha256(path) != entry["sha256"]:
            problems.append(f"changed: {name}")
    problems += [f"not in the manifest: {p.as_posix()}" for p in release_files(root) if p.as_posix() not in listed]
    return problems


def write_zip(root: Path, manifest: dict, manifest_bytes: bytes, target: Path) -> str:
    """Write the archive (one top-level directory, fixed timestamps), read it back and compare every member with the manifest."""
    top = f"{manifest['name']}-{manifest['version']}"
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for entry in [*manifest["files"], {"path": MANIFEST_NAME}]:
            data = manifest_bytes if entry["path"] == MANIFEST_NAME else (root / entry["path"]).read_bytes()
            info = zipfile.ZipInfo(f"{top}/{entry['path']}", date_time=ZIP_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            mode = (root / entry["path"]).stat().st_mode if entry["path"] != MANIFEST_NAME else 0o644
            info.external_attr = (0o755 if mode & 0o111 else 0o644) << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise SystemExit(f"error: {target} is corrupt")
        names = set(archive.namelist())
        expected = {f"{top}/{entry['path']}" for entry in manifest["files"]} | {f"{top}/{MANIFEST_NAME}"}
        if names != expected:
            raise SystemExit(f"error: {target} does not hold exactly the files of the manifest")
        for entry in manifest["files"]:
            if hashlib.sha256(archive.read(f"{top}/{entry['path']}")).hexdigest() != entry["sha256"]:
                raise SystemExit(f"error: {entry['path']} differs inside {target}")
    return sha256(target)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--root", type=Path, default=ROOT, help="release tree (default: the checkout this script lives in)")
    parser.add_argument("--junit", action="append", default=[], type=Path, help="JUnit report of the release test run (repeatable)")
    parser.add_argument("--out", type=Path, help=f"manifest to write (default: <root>/release/{MANIFEST_NAME})")
    parser.add_argument("--zip", type=Path, dest="archive", help="also write the release archive here and verify it")
    parser.add_argument("--require-clean", action="store_true", help="fail when the checkout has uncommitted changes or the evidence is incomplete")
    parser.add_argument("--check", action="store_true", help="verify the files on disk against an existing manifest instead of building one")
    args = parser.parse_args(argv)
    root = args.root.resolve()
    if args.check:
        candidates = [args.out] if args.out else [root / MANIFEST_NAME, root / "release" / MANIFEST_NAME]
        found = next((p for p in candidates if p and p.is_file()), None)
        if found is None:
            print(f"error: no {MANIFEST_NAME} found in {root} or {root / 'release'}", file=sys.stderr)
            return 2
        manifest = json.loads(found.read_text(encoding="utf-8"))
        problems = check(root, manifest)
        for problem in problems:
            print(problem, file=sys.stderr)
        print(f"{manifest['name']} {manifest['version']}: {len(manifest['files'])} files listed, {len(problems)} difference(s)")
        return 1 if problems else 0
    for path in args.junit:
        if not path.is_file():
            print(f"error: {path} does not exist", file=sys.stderr)
            return 2
    manifest = build(root, args.junit)
    if args.require_clean:
        reasons = []
        git, tests, trace = manifest["git"], manifest["tests"], manifest["traceability"]
        if git is None:
            reasons.append("not a git checkout")
        elif git["dirty"]:
            reasons.append("uncommitted changes: " + ", ".join(git["uncommitted"][:10]))
        if tests is None:
            reasons.append("no test report given (--junit)")
        elif tests["failures"] or tests["errors"] or tests["skipped"] or not tests["tests"]:
            reasons.append(f"the test run is not clean: {tests['failures']} failed, {tests['errors']} errors, {tests['skipped']} skipped of {tests['tests']}")
        if trace is None or not trace["complete"]:
            reasons.append("the traceability matrix is missing or incomplete (run scripts/build_traceability.py)")
        if reasons:
            for reason in reasons:
                print(f"error: {reason}", file=sys.stderr)
            return 1
    out = (args.out or root / "release" / MANIFEST_NAME).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    out.write_bytes(manifest_bytes)
    print(f"{manifest['name']} {manifest['version']}: {manifest['file_count']} files, {manifest['total_bytes']:,} bytes -> {out}")
    if args.archive:
        digest = write_zip(root, manifest, manifest_bytes, args.archive.resolve())
        print(f"archive {args.archive} ({args.archive.stat().st_size:,} bytes, sha256 {digest}) verified against the manifest")
    return 0


if __name__ == "__main__":
    sys.exit(main())
