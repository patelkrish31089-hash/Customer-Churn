#!/usr/bin/env python3
"""Check that a built wheel carries every file of the package.

    python scripts/check_wheel.py dist/churn_platform-1.1.0-py3-none-any.whl [src]

A file that exists in the source tree but is missing from the wheel (a migration, a stylesheet, a
template) is invisible while developing with an editable install and breaks the first real
installation.  Exit code 0: complete; 1: files are missing or unexpected; 2: wrong usage.
Only the standard library is used.
"""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

IGNORED_DIRECTORIES = {"__pycache__"}
IGNORED_SUFFIXES = {".pyc", ".pyo"}


def source_files(src: Path) -> set[str]:
    found = set()
    for path in src.rglob("*"):
        relative = path.relative_to(src)
        if not path.is_file() or path.suffix in IGNORED_SUFFIXES:
            continue
        if any(part in IGNORED_DIRECTORIES or part.endswith(".egg-info") for part in relative.parts):
            continue
        found.add(relative.as_posix())
    return found


def compare(wheel: Path, src: Path) -> tuple[list[str], list[str]]:
    """Return (missing from the wheel, in the wheel without a source file)."""
    with zipfile.ZipFile(wheel) as archive:
        packed = {name for name in archive.namelist() if not name.endswith("/") and ".dist-info/" not in name}
    expected = source_files(src)
    return sorted(expected - packed), sorted(packed - expected)


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) not in (1, 2):
        print(__doc__.strip().splitlines()[2].strip(), file=sys.stderr)
        return 2
    wheel, src = Path(args[0]), Path(args[1] if len(args) == 2 else "src")
    if not wheel.is_file() or not src.is_dir():
        print(f"not found: {wheel if not wheel.is_file() else src}", file=sys.stderr)
        return 2
    missing, unexpected = compare(wheel, src)
    for name in missing:
        print(f"missing from the wheel: {name}", file=sys.stderr)
    for name in unexpected:
        print(f"in the wheel without a source file: {name}", file=sys.stderr)
    if missing or unexpected:
        return 1
    print(f"{wheel.name}: all {len(source_files(src))} package files are present")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
