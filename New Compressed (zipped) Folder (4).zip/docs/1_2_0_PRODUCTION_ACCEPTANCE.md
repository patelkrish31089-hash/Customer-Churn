# 1.2.0 — production acceptance

The answer to "is this production ready", in the only form that survives a review: what is proven, what is not, and
who or what is missing for each. The rule of this document is that a gate is never moved by wishing.

## Verdict

**Not production accepted.** 28 of 58 requirements in the register are PASS, 14 are PARTIAL, 6 are NOT_IMPLEMENTED
and 8 are BLOCKED; of the fifteen gates, seven are technical and eight are held by a party outside this machine.
Nothing here is a judgement on the engineering: a system without a vendor account that has accepted a message, a
real customer's data, an owner's RPO and an assessor's report cannot be called production accepted, and saying
otherwise would be the one thing this whole exercise exists to avoid.

## The fifteen gates

| Gate | What closes it | State now | Evidence, or who holds it |
|---|---|---|---|
| 1 — PostgreSQL runtime, migration, recovery | a suite run on PostgreSQL | **PASS** | 495 tests, PostgreSQL, strict mode, Python 3.13.16; migrations 0001–0004 up, down and up with no drift |
| 2 — Docker build, deploy, restart | image built and run | **PARTIAL** | the 1.1.0 image was built, started and smoke-tested; the 1.2.0 image has not been built yet (M11) |
| 3 — clean dependency installation | install from the lock file on each interpreter | **PASS** | three interpreters built from `requirements.lock` (3.11.18, 3.12.16, 3.13.16), 498 tests passing on each, and the packaged wheel installed and started from the archive |
| 4 — Airflow scheduler and remote MLflow | a scheduler that stays up; a remote registry | **BLOCKED** | a single scheduler run succeeded (1.1.1); consecutive scheduled nights and a remote MLflow have not happened |
| 5 — Ruff, Bandit, pip-audit, secret scanning | the four commands run clean | **PASS** | `docs/1_2_0_SECURITY_REPORT.md`: Bandit 0 high/0 medium, pip-audit no known vulnerabilities, secret scan clean; jobs added to `ci.yml` |
| 6 — sentiment and adoption evaluation on labelled data | a labelled dataset | **PARTIAL** | adoption arithmetic is verified (R-31 PASS); the annotation workflow exists so sentiment can be measured, but no real labelled set has been scored (R-27 BLOCKED) |
| 7 — multi-process rate limiting, OIDC, TLS | two processes, a provider, a certificate | **PARTIAL** | rate limiting is shared through the database and tested across processes; Keycloak proved OIDC; a hosted provider and a production TLS setup are BLOCKED |
| 8 — performance, sustained load, staging recovery | a staging environment and owner-set SLOs | **BLOCKED** | only closed-loop figures on a 2 vCPU machine |
| 9 — Salesforce, HubSpot, Intercom sandbox | vendor accounts | **BLOCKED** | adapters and the local stand-in; no vendor has answered |
| 10 — real e-mail, SMS, push provider | credentials and a verified sender | **BLOCKED** | SMTP proved against a real mail server; no vendor account |
| 11 — hosted staging deployment | a host and DNS | **BLOCKED** | — |
| 12 — real-company churn validation | authorised data with mature labels | **BLOCKED** | synthetic only |
| 13 — business policy and financial assumptions | the owner's approval | **BLOCKED** | — |
| 14 — independent penetration test | an assessor | **BLOCKED** | — |
| 15 — disaster recovery accepted by the owner | the owner's RPO/RTO and a staging restore | **BLOCKED** | the mechanism and a real restore exist (R-47 PASS); the numbers and the environment are the owner's |

## What a reader should take from a PASS

A PASS means: the capability is in the source, a test or a recorded run at the named commit exercises it, and the
evidence is in this repository. It does not mean "works at your scale", "agreed with your security team" or
"accepted by your vendor". Those are the eight external gates.

## The shortest path from here to production accepted

1. An owner names RPO/RTO, the cost of a false negative, and signs the churn thresholds → unblocks 13 and 15.
2. A staging host (one machine is enough) → unblocks 8, 11 and the restore exercise.
3. One CRM sandbox, one email provider with a verified sender → unblocks 9 and 10 and closes the two PARTIAL rows
   that depend on them.
4. A labelled sample of support conversations (a few hundred, two reviewers, one afternoon) → closes 6.
5. An assessor → closes 14.
6. A repository and a token → runs the CI workflow on GitHub's runners, which is R-58.

Every one of those is an afternoon of somebody else's time, not another milestone of engineering.
