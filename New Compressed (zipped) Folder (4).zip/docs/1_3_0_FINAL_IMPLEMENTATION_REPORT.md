# 1.3.0 — final implementation report

This is the summary a reader gets first. Everything in it is a pointer to something longer that was produced by a run,
not by memory: the register for statuses, the test report for numbers, the milestone review for what each fix does not
do, and the known limitations for the rest.

## The release, as it stands

| | |
|---|---|
| release commit | **`3079f49`** on `main`, working tree clean |
| version | `1.3.0` in `pyproject.toml`, `__init__.py` and `CHANGELOG.md`; `/healthz` reports it |
| suite | **689 passed**, 0 failed, 0 errored, 0 skipped, twice at that commit (760.58 s, 624.58 s) |
| register | 106 requirements — PASS **39**, PARTIAL **21**, NOT_IMPLEMENTED 36, BLOCKED 8, NOT_APPLICABLE 2 — `--check` and `--release` both exit 0 |
| gates | 15 probed: 3 PASS, 11 BLOCKED with the missing thing named, 1 NOT_IMPLEMENTED |
| archive | `release/churn-platform-1.3.0.zip`, 243 files and its manifest, 4194581 bytes of manifest, 1273462 bytes on the wire, sha256 `efe03dcd867b7f3950c06ee9b80af2af36e653000d5d425197a7c81be6c017d4`, every member read back against the manifest |
| lint and security | `ruff check .` clean; `bandit -ll` 0 high, 0 medium; `pip-audit` no known vulnerability; `scan_secrets.py` no credential |

The register's PASS count is 36 of 104, and the shape of the number is worth more than the number. Six entries were
added at the last step, when the delivery layer acquired callers and the release acquired measurements; one of them
(R-104) times the schema migration; one (R-103, the warehouse upgrade plan) is deliberately PARTIAL because the plan has
never been executed against a warehouse. The PASS count also *fell* earlier, from 32 to 30, and that is the honest
direction: `R-13` (SMTP acceptance against Mailpit) and `R-38` (Keycloak 26.0) are PASSes from 1.2.0 that cannot be
re-observed here, so they are PARTIAL with the reason in the entry rather than a PASS carried forward from a commit
nobody can re-run. `scripts/reverify_1_3_0_register.py` performs that reconciliation and exits non-zero on anything it
cannot decide.

## What this release is

1.3.0 takes the platform that 1.2.0 released — 498 tests, 58 requirements, a browser application served by FastAPI, a
worker, SQLite and PostgreSQL — and fixes the four defects the brief names, then adds the delivery layer those defects
were found in: a canonical prediction record, a shared destination pipeline with a Snowflake adapter, and an outbox with
a per-tenant checkpoint.

## The four defects

| # | Defect as the brief states it | What was actually wrong | Fixed in | Held by |
|---|---|---|---|---|
| 1 | export watermark / checkpoint correctness | the watermark and the checksum came from the *selection*, not from what the destination acknowledged | `services/destinations/base.py` | `tests/test_failed_first_record_does_not_advance_watermark.py` (15 tests) |
| 2 | Snowflake actual ≠ configured schema must fail | the connection test compared two of six values and treated a missing value as agreement | `services/destinations/snowflake.py` | `tests/test_schema_mismatch_fails_validation.py` (29 tests) |
| 3 | tenant collisions in export identity and MERGE | the record had no tenant, so two tenants' rows deduplicated inside a run and overwrote each other at the warehouse | `services/export_record.py`, `destinations/*` | `tests/test_tenant_id_prevents_crm_collisions.py` (14 tests) |
| 4 | release validator false PASS | `--release` compared the register with an argument filled from the same register, so it could not fail | `scripts/build_1_3_0_register.py` | `tests/test_release_validator_rejects_stale_evidence.py` (21 tests) |

Each was reproduced first, and the reproduction is quoted at the top of the file that now holds it. The reproductions
are also in `docs/1_3_0_IMPLEMENTATION_REPORT.md`, section "M1 (second pass)".

## What was added

- **Migration `0005`** — `export_runs`, `export_outbox`, `export_checkpoints`; additive, reversible, exercised on SQLite
  and on PostgreSQL 17.11.
- **`services/export_outbox.py`** — record a run, advance a tenant checkpoint only forwards, answer what is still
  outstanding, refuse a run that mixes tenants.
- **`scripts/record_test_run.py`** — the sidecar that binds a JUnit file to a commit and a command.
- **The delivery surface, reachable** — `services/exports.py`, eight routes under `/exports` (start, runs, one run,
  backlog, destinations, overview, resume, reconcile) behind `customers:read` and `customers:export`, a worker handler
  that drains `export.run`, and a **Destination exports** screen in every role's navigation. 15 tests drive it through
  the API, including the defect-1 failure seen from the product side.
- **`services/destinations/postgres.py`** — a destination that is a real database. The pipeline can now be shown
  delivering, because there is something real to deliver to: 10 tests, one of them an export started through the API,
  drained by the worker and read back by an independent connection.
- **`scripts/gate_ledger.py` + `docs/1_3_0_GATES.md`** — every gate probed, the result published, and the register
  carrying the probe beside the claim.
- **`scripts/acceptance_smtp_73.py`** — the 1.2.0 SMTP acceptance made repeatable: 73 of 73 accepted by aiosmtpd.
- **`scripts/load_test_delivery.py`** — the first measurement of the delivery path: ~2 200 records/s through
  `deliver()`, the price of a partial failure (5 020 destination calls for 20 batches when 0.1 % of records are
  refused), 842 rows/s for `record_run()` on PostgreSQL, and `outstanding()` over 50 000 rows in ~1 s.
- **`services/destinations/snowflake_upgrade.py` + `scripts/snowflake_upgrade_1_3_0.py`** — the six-step plan that
  takes an existing 1.2.0 warehouse table to the tenant-scoped identity, printed for review and executed nowhere.
- **Three generators with `--check`** — the file structure, the requirement matrix and the feature inventory are built
  from the tree, the register and the tests.
- **Eleven documents** for this release, of which four are generated and the rest state what they do not cover.

## The evidence, and its shape

| Question | Answer | Where |
|---|---|---|
| does the suite pass? | 653 passed, twice at one commit, zero failed, zero errored, zero skipped | `docs/1_3_0_FINAL_TEST_REPORT.md` |
| is the register consistent? | `--check` passes; `--release` compares the register with `git`, not with itself | `scripts/build_1_3_0_register.py` |
| what does each requirement rest on? | an entry with a status, evidence and the commit it was verified at | `docs/1_3_0_REQUIREMENT_TRACEABILITY.md` |
| what would catch a regression? | the module that names the requirement, per requirement | `docs/1_3_0_REQUIREMENT_MATRIX.md` |
| what is not done? | no vendor has ever received a record, eleven gates name the account or host they lack, the failure path costs one destination call per record, the ML figures are synthetic | `docs/1_3_0_KNOWN_LIMITATIONS.md` and `docs/1_3_0_GATES.md` |

## The four labels, and where this release stands

| Label | This release |
|---|---|
| LOCALLY VERIFIED | **earned** for the suite, the migrations and the four defect reproductions |
| INTEGRATION VERIFIED | **earned** for the platform's own API, database, worker, browser (including the export screen for all eight roles), PostgreSQL as a delivery destination, and SMTP against an independent server; **not** for any vendor |
| PDF COMPLIANT | **partially** — every module a test names passes; the brief requirements no test names are listed |
| PRODUCTION ACCEPTED | **not claimed anywhere**, and `docs/1_3_0_PRODUCTION_ACCEPTANCE.md` says why, line by line |

## What a reader should do next

1. Read `docs/1_3_0_KNOWN_LIMITATIONS.md` first — it is short and it changes how the rest reads.
2. Run the suite with the command in `docs/1_3_0_FINAL_TEST_REPORT.md`; the verdicts should reproduce or fail.
3. Run `python3 scripts/build_1_3_0_register.py --check`, `--matrix --check`, `--file-structure --check` and
   `--inventory --check`, which fail if a document on disk is stale.
4. Then, and only then, read `docs/1_3_0_PDF_COMPLIANCE_REPORT.md` against the brief.
