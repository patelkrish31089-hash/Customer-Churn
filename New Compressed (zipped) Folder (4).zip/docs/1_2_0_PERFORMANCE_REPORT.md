# 1.2.0 — performance

Measured, on the machine this release was built on, with the tooling in the repository. Every number below comes
from a run recorded at this commit; none is a target, a projection or a vendor figure.

## The measurement

| | |
|---|---|
| Machine | 2 vCPU, 1,982 MB RAM, shared build machine (the test suite's own environment) |
| Software | `churn-platform 1.2.0`, Python 3.13.16, PostgreSQL 16 on the same host |
| Data | the synthetic demo tenant: 300 customers, 9 months of history, 33,952 usage events, 600 support interactions, 473 stored predictions, 228 audit events |
| Server | `churn-platform serve`, one process, no reverse proxy, no worker alongside |
| Load | `scripts/load_test.py`, closed loop, request mix modelled on the web application (customer list, single customers, predictions and explanations, recommendations, monitoring, analytics, alerts, the running-jobs poll), 5 s warm-up, 30 s per level, generator on the same machine |

## Throughput and latency

| Clients | Requests/s | p50 | p95 | p99 | max | Errors |
|---|---|---|---|---|---|---|
| 1 | 48.6 | 14.9 ms | 49.7 ms | 68.5 ms | 122.7 ms | 0 |
| 8 | 70.7 | 92.9 ms | 237.7 ms | 309.1 ms | 419.4 ms | 0 |
| 32 | 68.6 | 430.1 ms | 721.6 ms | 887.0 ms | 1112.8 ms | 0 |

Read it as what it is. Throughput stops rising between 8 and 32 clients because the machine has two cores and the
generator is one of the processes competing for them; latency then rises while throughput stays flat — the classic
signature of a saturated server. **p95 of 238 ms at 8 clients and 722 ms at 32 means this configuration serves a
handful of analysts comfortably and is not sized for a company.** A single 2 vCPU box with the load generator on it
is not a staging environment, and the numbers say nothing about a real deployment with a separate database, workers
and a proxy.

The same test against SQLite on the same machine (for comparison only, since PostgreSQL is the production runtime):
48.6 → 58.8 req/s at one client, 70.3 req/s at eight, 0 errors.

## Backup and restore, measured on PostgreSQL

| Operation | Time | Result |
|---|---|---|
| `churn-platform backup` (pg_dump custom format + data directory, 21 members) | **1.90 s** | 3,427,004 bytes, sha256 `f969016…`, revision `0004` |
| `churn-platform backup-check` (every member's checksum) | < 0.2 s | valid, no problems |
| `churn-platform restore` into an empty database | **3.37 s** | revision `0004`, and all eleven table counts identical to the source: 2 tenants, 300 customers, 299 subscriptions, 33,952 usage events, 600 support interactions, 1 model version, 473 predictions, 86 recommendations, 44 messages, 1 CRM connection, 228 audit events |

That is a genuine destroy-and-rebuild round trip on the production database engine at demo scale, not a timing of a
test fixture. It says nothing about a 500 GB installation, for which `pg_dump` is the wrong instrument anyway.

## A defect this measurement found

The first attempt failed: `pg_dump: error: connection to server on socket "/var/run/postgresql/.s.PGSQL.5432" failed:
FATAL: role "user" does not exist`. The tool was handing the SQLAlchemy URL — `postgresql+psycopg://…` — straight
to `pg_dump`, which does not understand a driver suffix and quietly fell back to its defaults. In other words the
backup command worked on SQLite, and could not have backed up a production installation at all — and the test suite
would not have said so, because its backup tests run against SQLite. The PostgreSQL path had never been executed. Source change:
`backup.libpq_url()` translates the scheme for both `pg_dump` and `pg_restore`; `tests/test_backup.py::
test_the_postgres_client_tools_are_given_a_url_they_understand` holds it. This is the failure mode the release is
about: presence in the code is not functionality, and only a real run on the real engine shows the difference.

## What is still not measured, and cannot be here

| | Why |
|---|---|
| Sustained load over hours, memory growth, connection-pool exhaustion | needs a dedicated staging host; R-49 BLOCKED |
| Behaviour under a real user population (open arrive rate, not a closed loop) | needs production traffic or a load generator on separate hardware |
| Scaling beyond one process (workers, a second API instance) | needs a host with more than two cores to say anything |
| Locust figures | the repository's `scripts/load_test.py` is the measured instrument; the Locust suite has not been run against a staging deployment (R-50 BLOCKED) |
| Any SLO verdict | the thresholds are the owner's to set (GATE 8 BLOCKED) |

Closed-loop figures on the machine that also runs the generator are a lower bound on latency and an upper bound on
nothing. They are reported here so that the next person starts from a real baseline instead of an estimate.
