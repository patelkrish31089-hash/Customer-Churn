# Connecting Salesforce, HubSpot or Intercom

The platform writes two things to a CRM: the **risk score** of each customer of a scored batch, and a **task** when
an approved recommendation is executed through a connection. This page says what has to exist on the vendor's side,
what exactly is sent, and what has and has not been checked.

**No vendor account has accepted a request from this software.** Treat the first run against a sandbox as a test
that may fail, and read the delivery list afterwards.

What 1.1.1 did prove is the protocol: a CRM built to HubSpot's rules, running on this machine, took 85 of 85 score
updates over real HTTP through OAuth 2.0 (consent, 120-second access token, rotating refresh token, revocation),
answered 401/400/429 the way HubSpot does, and sent signed `propertyChange` events back that confirmed every
delivery. That still leaves the vendor's own service untried — the first run against a real sandbox is the moment
to check it (see the table in [`LIMITATIONS.md`](LIMITATIONS.md)).

## What was checked

| Check | Salesforce | HubSpot | Intercom |
|---|---|---|---|
| Request shapes pinned by unit tests (`tests/test_crm.py`) | yes | yes | yes |
| Requests valid for the API description the vendor publishes (`scripts/check_crm_contracts.py`) | not possible: Salesforce publishes none that can be read without an org | yes, 2 of 2 | yes, 2 of 2; the types of custom attribute values cannot be checked, because the description contradicts its own example there |
| Sent to the vendor's live host with a token the vendor must reject | yes: HTTP 401 `INVALID_SESSION_ID` from `na1.salesforce.com`, a shared instance host, not an org's own domain | yes: HTTP 401 `INVALID_AUTHENTICATION` | yes: HTTP 401 `Access Token Invalid` |
| Accepted by a vendor account | never | never | never |

The third row ran the product's own delivery code: the address check, the connection pinned to the checked address
with the vendor's TLS name, the request, and the recording of the refusal (the delivery ends as `dead` with the
vendor's message, the token is not stored with it). It shows that the requests reach the vendor's API. It cannot
show that an account accepts them, because the vendor checks the token before it looks at anything else.

Running the contract check again, for instance after a vendor announces a change:

```bash
python scripts/check_crm_contracts.py        # downloads the descriptions; exit code 1 if a request no longer conforms
```

## Before the first run

1. Create the fields listed for your vendor below. The names can be changed per connection (`field_mapping` in
   `POST /api/v1/crm/connections`); the web form uses the defaults.
2. Create the connection in the web application under **CRM sync → New connection**, mode `SANDBOX`, with the URL
   and a token of a sandbox or developer account. A `TEST_ONLY` connection never sends anything: it builds each
   request and shows it in the delivery list, which is a good way to read what would be sent.
3. Choose **Sync latest scores** for the high tier only and read the delivery list: `sent` with the vendor's record
   id, or `dead` with the vendor's answer.
4. Execute one approved recommendation through the connection and check the task on the vendor's side.
5. `PRODUCTION` mode is refused until the operator starts the platform with `CHURN_CRM_ALLOW_PRODUCTION=true`.

Three rules hold for every vendor:

- **The token is used as given.** It is stored encrypted and sent as `Authorization: Bearer`. The platform does not
  renew it. When it stops working, deliveries end as `dead` with the vendor's 401.
- **A connection cannot be edited and a dead delivery is not sent again.** To replace a token, or to send again
  after a failure that will not heal by itself, create a new connection and sync again.
- **A customer the vendor does not know.** According to their documentation, Salesforce and HubSpot answer
  "not found"; the platform then ends the delivery as `dead` and nothing is created. Intercom creates the company
  (see below). None of this could be observed without an account.

## Authorising with OAuth instead of a pasted token (1.1.0)

A connection can obtain its token through the CRM's consent screen (`Syncs & exports → Set up OAuth`, then
`Connect`). The platform then stores access and refresh token encrypted, refreshes the access token before it
expires and once more when the CRM answers 401, and stops deliveries when the CRM refuses the refresh until
somebody authorises the connection again. That removes the expiry problem of a pasted Salesforce token described
below. The flow, the events the CRM can send back and reverse-ETL syncs are described in
[OUTBOUND.md](OUTBOUND.md).

**Not verified with any vendor.** The consent flow, the token exchange and the refresh were written from the
vendors' public documentation and run against stand-ins inside the test suite. No Salesforce, HubSpot or Intercom
app has shown its consent screen to this software or issued it a token. Expect to adjust endpoints or scopes on the
first real connection, and use a sandbox for it.

## Salesforce

| | |
|---|---|
| Base URL | The org's own domain, for example `https://yourcompany.my.salesforce.com` |
| Token | An OAuth access token. Salesforce access tokens expire with the session, so a connection stops working when its token does. A pasted token is not refreshed; a connection authorised through OAuth is. |
| API version | `v61.0` by default; `v61.0` or later is required and enforced when the connection is created |
| On the object (default `Account`) | An external-id field holding the platform's customer id (default `External_Id__c`), and `Churn_Probability__c` (number between 0 and 1), `Churn_Risk_Tier__c` (text), `Churn_Top_Reasons__c` (text, 255), `Churn_Scored_On__c` (date) |

Risk score: `PATCH /services/data/v61.0/sobjects/Account/External_Id__c/<customer id>?updateOnly=true` with the four
fields. `updateOnly` is what stops Salesforce from creating an account for a customer it does not know; versions
before 61.0 do not have it, which is why they are refused.

Task: `POST /services/data/v61.0/sobjects/Task` with `Subject`, `Description`, `Priority` (`High` or `Normal`),
`Status` (`Not Started`) and the account referenced through its external id
(`"What": {"attributes": {"type": "Account"}, "External_Id__c": "<customer id>"}`).

**Check this first in a sandbox:** `What` on a task can point at several kinds of record. Salesforce documents
references by external id for ordinary relationships; that it resolves this one with the type hint is taken from
the same mechanism working for `Owner`, and was not confirmed here.

## HubSpot

| | |
|---|---|
| Base URL | `https://api.hubapi.com` |
| Token | An access token of a private app with write access to companies and tasks |
| On companies | A property with unique values holding the platform's customer id (default `external_customer_id`), and `churn_probability`, `churn_risk_tier`, `churn_top_reasons`, `churn_scored_on` |
| On tasks | A property `churn_platform_customer_id` |

Risk score: `PATCH /crm/v3/objects/companies/<customer id>?idProperty=external_customer_id` with the four
properties. HubSpot's description types every property value as text, so the probability is sent as `"0.812345"`.

Task: `POST /crm/v3/objects/tasks` with `hs_task_subject`, `hs_task_body`, `hs_task_status` (`NOT_STARTED`),
`hs_task_priority` (`HIGH` or `MEDIUM`), `hs_timestamp` (the time the recommendation was executed) and
`churn_platform_customer_id`. **The task is not linked to the company:** linking needs HubSpot's own record id,
which the platform does not hold, so `associations` is sent empty and the customer id travels as a property.

## Intercom

| | |
|---|---|
| Base URL | `https://api.intercom.io` (Europe `https://api.eu.intercom.io`, Australia `https://api.au.intercom.io`) |
| Token | An access token of the workspace |
| API version | `2.14`, sent as `Intercom-Version`; change it with `api_version` in the field mapping |

Both kinds of delivery write attributes of the company with `POST /companies`, matched on `company_id`:

- risk score: `churn_probability`, `churn_risk_tier`, `churn_top_reasons`, `churn_scored_on`;
- executed recommendation: `churn_recommended_action`, `churn_action_subject`, `churn_action_segment`,
  `churn_action_recommended_at` (Unix time).

Two things to know:

- **Intercom creates a company it does not know.** Its call is "create or update" and has no update-only form.
  Intercom shows a company only once a user is attached to it, so such companies stay out of sight, but they exist.
- **There is no task or event.** Intercom records events against a contact and the platform knows companies, not
  the people in them. An executed recommendation is therefore visible as company attributes, on which Intercom
  can filter and trigger its own workflows.
