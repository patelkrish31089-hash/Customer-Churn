# Register of missing features

Every gap between release 1.0.1 and the project brief (and two security gaps found on the way), with what 1.1.0
does about it and how far that was proven. The baseline is described in
[ENHANCEMENT_BASELINE.md](ENHANCEMENT_BASELINE.md).

Status words:

- **PASS**: built, covered by automated tests that pass, and exercised as far as this build machine allows.
- **BLOCKED**: built and tested against stand-ins, but the proof that matters needs something that was not
  available: an account with a vendor, a real identity provider, a labelled sample of real data.
- **OPEN**: not built.

| # | Gap in 1.0.1 | Brief | What 1.1.0 does | Requirement | Status |
|---|---|---|---|---|---|
| MF-01 | Sentiment was a word-list match, English only | 3.1 | A pinned, checksummed multilingual transformer scores every support text locally; redaction before scoring; a state for every text that cannot be scored; the word list remains as a labelled fallback | REQ-SIG-01 | PASS for the mechanism. **BLOCKED for accuracy on real support text**: no labelled real sample exists; the product reports accuracy as not measured |
| MF-02 | Feature adoption was a count, not a rate | 3.1 | A reviewed catalogue of product features; rate = adopted / available, denominator stored; unmapped telemetry reported | REQ-SIG-02 | PASS |
| MF-03 | Daily active users counted raw references | 3.1 | Identity links, merge candidates decided by people, imported mappings; active users count people under an approved definition; unknown where too few events name a user | REQ-SIG-03 | PASS |
| MF-04 | Customer attributes had no history | 3.1, 3.2 | Validity periods for six attributes (five of them model features), written by imports and corrections; features read the value that held at T | REQ-SIG-04 | PASS |
| MF-05 | MLflow was a one-way copy | 8.1 | Lifecycle with promotion gates; MLflow tags and aliases follow it; MLflow can be the registry of record | REQ-ML-07 | PASS (real MLflow 3.18.0 server over HTTP). Not run: a remote, authenticated server |
| MF-06 | Airflow only started and watched the chain | 8.1 | One idempotent command per step and run key; a DAG with one task per step; exactly one orchestrator | REQ-OPS-07 | PASS (Airflow 3.4.0, `airflow dags test`). Not run: a scheduler with an executor, Airflow's own retries |
| MF-07 | CRM token pasted and never renewed; nothing came back from the CRM; no reverse ETL | 2.2, 8.2 | OAuth authorisation with refresh and revocation; signed CRM events stored once; reviewed reverse-ETL syncs to a CRM connection or a checksummed file | REQ-ACT-04 | **BLOCKED**: no vendor account or sandbox; tested against stand-ins only |
| MF-08 | No e-mail, text or push; the automated tier and the card reminder ended at a recommendation | 9.2, 9.3 | Providers for e-mail, text, push and in-app; approved templates, consent, suppression, caps, unsubscribe; campaigns that carry out the playbook's decisions | REQ-ACT-05 | **BLOCKED**: no vendor has accepted a message; everything runs in dry-run mode and against stand-ins. Apple push is rehearsal only |
| MF-09 | Request limits counted per server process | derived | Limits counted in the database; fallback or refusal when the store fails; `Retry-After` on every refusal | REQ-SEC-07 | PASS (two server processes: 10 of 150 attempts answered, as configured) |
| MF-10 | The forwarded protocol was believed from anybody, the forwarded address from every client on the server's machine | derived | One list of trusted proxies for both; the transport-security header only on HTTPS or behind a trusted proxy | REQ-SEC-07 | PASS (checked against a running server from 127.0.0.1) |
| MF-11 | No single sign-on | derived | OpenID Connect: code flow with PKCE, state and nonce, signature and claim checks, account linking, role mapping, second-factor rules | REQ-SEC-08 | PASS against the provider inside the test suite. **BLOCKED for a real provider** (Entra ID, Okta, Google, Keycloak) |
| MF-12 | Session tokens lived as long as the session | derived | Tokens replaced on a schedule; a replaced token used later revokes its descendants | REQ-SEC-07 | PASS |
| MF-13 | Snowflake as a warehouse | 8.2 | Nothing | | OPEN. PostgreSQL is the supported warehouse |
| MF-14 | Connectors for Hightouch, Census, Zendesk, Marketo | 8.2 | Nothing of their own: the reverse-ETL file export is the hand-over | | OPEN |
| MF-15 | SAML single sign-on | not in the brief | Nothing | | OPEN |

## What "BLOCKED" needs

| Item | Needed to lift it |
|---|---|
| Sentiment accuracy | A few hundred real support texts labelled by a person, uploaded under *Support sentiment → Evaluate on labelled texts* |
| CRM OAuth, events, deliveries | A sandbox or developer account at Salesforce, HubSpot or Intercom with an OAuth app, and `CHURN_PUBLIC_BASE_URL` reachable by the vendor |
| Messages | Test credentials at SendGrid, Amazon SES, Twilio or Firebase; a relay for the vendors' signed webhooks |
| Single sign-on | A tenant at an OpenID Connect provider with a registered redirect address |

Nothing in this register is switched on by an upgrade. CRM connections keep the mode they have (`TEST_ONLY` unless
an administrator chose another when creating the connection), message providers start in `DRY_RUN` and campaigns
start as dry runs. Leaving `DRY_RUN` and starting a campaign that really sends each need the approval permission;
live sending and a CRM connection in `PRODUCTION` mode also need a setting of the installation
(`CHURN_NOTIFY_ALLOW_LIVE`, `CHURN_CRM_ALLOW_PRODUCTION`).
