# 1.3.0 — milestone reviews, written independently of the implementation

Each milestone is reviewed here by someone who did not write it, against four questions: **was the defect reproduced,
is the fix the one that answers it, would the tests catch it coming back, and what does the fix still not do?** A
review that answers only the first three is marketing; the fourth is the one a reader needs.

The rule this document is held to: nothing is called verified because it was implemented. A claim here either points at
a command that was run and its output, or says plainly that it was not run.

---

## M1 — the four reproduced defects

**Reviewed at** commit `4587da6` (fixes) and `d031967` (generated documents and a test-pool correction), branch `main`,
interpreter 3.13.18, PostgreSQL 17.11, suite run twice at the same commit.

### What was reproduced before anything was changed

Every defect was reproduced against the code as it stood at `b4fd131`, in a script, not by reading it. The transcripts
are quoted in the headers of the four regression files, and the relevant lines are:

| Defect | Reproduction | What it showed |
|---|---|---|
| 1 — watermark over failed records | a destination that refuses `C1` and accepts `C2` | `watermark: 2026-11-01` — taken from the **refused** record; the checksum matched `C1`, not `C2` |
| 2 — schema mismatch accepted | a stand-in session reporting `OTHER_SCHEMA` against a configuration saying `PUBLIC` | `{'ok': True, …, 'health': 'the session answered and matches the configuration'}` |
| 3 — tenant collision | two tenants, one external customer id | `identity(t1) == identity(t2)` → `True`; `tenant_id` absent from the canonical schema |
| 4 — release validator false PASS | register claiming `0224654` with the tree at `b4fd131` | `problems reported in --release mode: []` |

None of the four was found by a failing test, because no test covered the property that was wrong: each was found by
asking the code to do the thing and reading what it said. That is itself the finding behind all four.

### Defect 1 — the watermark and the checksum were taken from the selection

**Is the fix the one that answers it?** The defect is not "the watermark was wrong by one batch"; it is that *nothing in
the system recorded what the destination accepted*, so the number had to be inferred from what was sent. The fix
therefore changes the data model rather than the arithmetic: `deliver()` now builds a `RecordOutcome` per record —
`PENDING`, `ACKNOWLEDGED`, `FAILED`, `QUARANTINED`, with attempts, error code and description — and every derived number
reads from that. The watermark is `contiguous_watermark()`, which walks acknowledged records in time order and stops at
the first outstanding one, per tenant, and which treats records that share an instant as a group: an instant at which
one record was accepted and another was not is not an instant that has been delivered.

**Would the tests catch it coming back?** Fifteen tests in
`tests/test_failed_first_record_does_not_advance_watermark.py` assert the acknowledged set, the watermark (including the
shared-instant case in both input orders), the checksum against the destination's own stored rows, the per-tenant
watermarks, the idempotency key distinguishing a retry from a correction, the batch-failure fallback to single-record
writes, the "cannot count" verification and the JSON round-trip. Reverting `contiguous_watermark` to `max()` over the
selection fails at least six of them.

**What it still does not do.** The outbox is written by `services/export_outbox.py`, and **nothing in the API calls it
yet**: the destinations layer is a library with no HTTP route, no screen and no scheduled job. A delivery run is
therefore resumable *if a caller uses the outbox*, and no caller does. This is recorded in the register as R-60 PARTIAL
with that sentence in it, and it is the first item of the next milestone rather than a footnote.

### Defect 2 — the session was compared with the configuration it came from

**Is the fix the one that answers it?** The 1.2.0 check compared two of the six configured values, and its comparison
was written so that a value the session did not report was skipped. The fix reads the session back — version, user,
role, warehouse, database, schema, account, region — compares all six configured values, treats an unreported value as a
mismatch, and turns every connector exception into a refusal that names its kind (`timeout`, `connection`) so that a
wrong key and a wrong schema are distinguishable. It also stops building SQL out of configuration: `quote()` validates
an identifier against a strict grammar and quotes it, and `problems()` validates warehouse, database, schema, role and
both table names before a connection is attempted.

**Would the tests catch it coming back?** Twenty-nine tests in `tests/test_schema_mismatch_fails_validation.py`,
including one per compared field, the unreported-value case, case-insensitivity (which is *not* a mismatch in Snowflake),
the region that was not configured, the refused TLS setting, seven accepted and nine refused identifiers, and a test
that every statement the adapter issues quotes the names it was configured with.

**What it still does not do.** No Snowflake account exists here and no SDK is installed, so **nothing proves that a real
account accepts these statements** — that is GATE 12, BLOCKED, and the adapter says so in its own module docstring.
The TLS claim is stated as a mechanism (`insecure_mode` is never passed), not as an observation of a handshake.

### Defect 3 — the tenant was not part of the record

**Is the fix the one that answers it?** The defect is structural, so the fix is: `tenant_id` is the canonical record's
first field and is required; it leads the identity, the idempotency key, the deduplication key, the Snowflake primary
key and the MERGE's `ON` clause; `from_prediction()` refuses a record whose tenant cannot be established instead of
defaulting to anything; and `record_run()` refuses a run that mixes tenants. The schema version moves to `1.1.0`,
because adding a required field is a change consumers must see.

**Would the tests catch it coming back?** Fourteen tests in `tests/test_tenant_id_prevents_crm_collisions.py`, plus the
updated schema and MERGE assertions in the two destination test files. Removing `TENANT_ID` from `_IDENTITY_COLUMNS`
fails the primary-key and MERGE tests; removing the field fails nineteen tests across three files.

**What it still does not do.** It proves the keys are tenant-scoped; it cannot prove that a real warehouse's MERGE
behaves as the statement says. Migrating a warehouse that already contains 1.2.0 rows — which had no `TENANT_ID` column
— is **not** addressed: the DDL is `CREATE TABLE IF NOT EXISTS`, so an existing table is not altered, and no backfill is
provided. That is an upgrade-path gap and it is listed in `docs/1_3_0_KNOWN_LIMITATIONS.md`.

### Defect 4 — the release validator agreed with itself

**Is the fix the one that answers it?** The 1.2.0 `--release` compared the register's `meta.source_commit` with an
argument that `main()` filled from the same register, so it could not fail. The fix compares the claim with `git`, and
adds four checks that until now did not exist: every PASS/PARTIAL/FAIL must name the release commit; the tree must be
clean; at least one JUnit file must be given, and it must have a sidecar naming its commit and command with a digest
that still matches; and two runs of the suite must agree test by test. A skipped test is treated as not executed. One
exception is allowed and checked: a documentation-only commit above the evidence commit, because the register cannot
contain the hash of the commit that contains it.

**Would the tests catch it coming back?** Twenty-one tests in `tests/test_release_validator_rejects_stale_evidence.py`,
including the release command's own exit code and message for the stale register, and a real temporary git repository for
the documentation-only exception.

**What it still does not do.** It binds evidence to a commit, not to a build: a JUnit file could in principle be
fabricated and given a matching sidecar by hand. What it removes is the *accidental* false PASS — a register left
untouched since the previous release — which is the one that actually happened. It also cannot tell whether the tests
that passed were the right ones; a suite that lost a test file would still pass. `--min-tests` against the recorded
baseline is the guard for that, and it is set from the register's `test_count`.

### Verdict on M1

The four defects are fixed, and each fix is held by tests that fail if it is undone. Everything claimed above was
executed on this machine at the commit named; the suite results are in `docs/1_3_0_TEST_BASELINE.md` and
`docs/1_3_0_FINAL_TEST_REPORT.md`. What remains — no API route into the outbox, no Snowflake account, no migration path
for existing warehouse tables, no vendor acceptance of any kind — is listed rather than smoothed over.

---

## M2 / M3 — the canonical record and the destination pipeline (reviewed with M1)

Built at `49d08d6` and `6a2e861`, and substantially reworked while fixing M1. Reviewing them together with M1 is honest,
because M1 changed them: the checksum, the watermark, the identity and the connection test are the same code.

- **The canonical record** (`services/export_record.py`) validates 20 fields, refuses an unapproved model, a naive
  timestamp, a probability outside `[0, 1]`, a decile outside `[1, 10]`, a blank required string, an unknown field and a
  malformed checksum. 30 tests.
- **The pipeline** (`services/destinations/base.py`) holds the obligations every destination shares, and the Snowflake
  adapter implements them as SQL with parameters, never as interpolation. 17 tests, all of which assert the *shape* of
  the statements rather than their effect on a warehouse.
- **The outbox** (`services/export_outbox.py`, migration `0005`) persists a run, its per-record states and the tenant
  checkpoint; it is additive and reversible, and the same tests run against SQLite and PostgreSQL. 13 tests.

The review's finding for these two milestones is the same one as M1's fourth question: **the layer is not reachable from
the product yet.** No route, no screen, no scheduled job. That is why R-59 and R-60 are PARTIAL rather than PASS, and
why the register's `next_step` for both says "wire it".
