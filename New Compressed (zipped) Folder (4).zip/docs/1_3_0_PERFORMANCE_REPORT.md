# 1.3.0 — performance report

Every number here was produced by a script in `scripts/`, at the commit named in the release state, against a database
this repository can build, and stored as JSON outside the tree.  Nothing here is an estimate or a figure carried over
from 1.2.0 without being labelled as such.

**The environment changed between measurements, and it changed the numbers.**  These figures were taken on a second
sandbox instance of the same shape as the first (2 vCPU, 2 GB), after that instance was lost.  The API is slower here
than the previous measurement of the same commit family (59.3 / 84.8 / 78.3 req/s against 77.4 / 96.2 / 91.6).  Nothing
in the code explains the difference and no controlled comparison was made, so the honest reading is: **these are the
numbers this machine produces, the previous ones are what the previous machine produced, and neither is a capacity
claim.**  What did not move is every delivery-path number and the failure-path finding, which reproduce to the digit.

Reproducing any row:

```bash
python3 scripts/load_test.py --base-url http://127.0.0.1:8000 --email admin@load.example --password-env DEMO_PASSWORD \
    --concurrency 1,8,32 --duration 30 --warmup 5 --json /var/tmp/release/load-1.3.0.json
python3 scripts/load_test_delivery.py --database sqlite   --records 10000 --failure-rate 0.001 --backlog 100000
python3 scripts/load_test_delivery.py --database postgres --records 10000 --failure-rate 0.001 --backlog 50000
```

## The API

300 synthetic customers, 18 months of history, `CHURN_ENV=development`, SQLite, 30 s per level after a 5 s warm-up, the
1.2.0 request mix (22 % customer list, 24 % single customer, 10 % batch predictions, 6 % explanation, 10 %
recommendations, 6 % each monitoring report, analytics report and alerts, 10 % running jobs):

| Concurrent clients | Throughput | p50 | p95 | p99 | max | errors |
|---|---|---|---|---|---|---|
| 1 | **59.3 req/s** | 10.3 ms | 47.7 ms | 59.6 ms | 85.9 ms | 0 |
| 8 | **84.8 req/s** | 68.8 ms | 223.2 ms | 285.3 ms | 456.8 ms | 0 |
| 32 | **78.3 req/s** | 369.6 ms | 652.7 ms | 767.0 ms | 912.9 ms | 0 |

Throughput flattens between eight and thirty-two clients while p95 climbs from 223 ms to 653 ms: that is queueing in a
single worker, not work.  Zero errors at every level.

## The delivery path

A stand-in destination that acknowledges in batches and can refuse selected records, so the platform's own cost is
measured with no network in it:

| Measurement | SQLite | PostgreSQL |
|---|---|---|
| Deliver 10 000 records, batch 500, no failures | **2087.3 rec/s** (4.791 s, 20 calls) | **2147.3 rec/s** (4.657 s, 20 calls) |
| Deliver 10 000 records, 0.1 % refused (10 records) | 2140.9 rec/s (4.671 s) but **5020 destination calls** | 2075.3 rec/s, **5020 calls** |
| `record_run()` for 5 000 records | 1786.3 rows/s | **834.7 rows/s** (5.99 s) |
| `outstanding()` on a backlog | 100 000 rows in **1.937 s** | 50 000 rows in **0.854 s** |

The finding that has not changed on either machine: **ten refused records in a 10 000-record run turn 20 destination
calls into 5020**, because the batch-failure path
re-sends one record at a time, while total time barely moves at zero latency.  Against a warehouse at 100 ms a call that
is the difference between two seconds and eight minutes.  It is the price of the correctness fix that stops a refused
record advancing the watermark, it is measured rather than suspected, and batching it is a 1.3.x item.

## The migration

`alembic upgrade head` in one process against a fresh SQLite file, so interpreter start-up is excluded: the first
upgrade takes 0.563 s, a no-op re-upgrade 0.03 s,
downgrading `0005` 0.032 s and upgrading back 0.034 s.
Migration `0005` adds three tables and one index and alters none of the 56 that existed.  **A production-sized database
was not timed**, so this says the migration is cheap, not that it stays cheap.

## The one acceptance this machine can make against a foreign implementation

73 messages sent through `notify._smtp_call` to aiosmtpd (an SMTP server this repository did
not write): **73 accepted with 250, 73 received**.  It is a
protocol acceptance, not a provider one — GATE 13 is still BLOCKED — and it is the only place in this release where the
platform's own client meets a server somebody else wrote.

## What is still not measured

| Not measured | Why |
|---|---|
| Latency against a real Snowflake account | no account (GATE 12) — the 5 020-call finding is unquantified end to end |
| More than 32 clients, more than one API worker | the sandbox has 2 vCPU |
| `record_run()` for 100 000 records | 5 000 records already shows the shape: 834.7 rows/s × 100 000 ≈ four minutes, extrapolated and not observed |
| A production-sized database under the migration | no copy exists here |
| The upgrade plan for a 1.2.0 warehouse table | no warehouse: `scripts/snowflake_upgrade_1_3_0.py` prints six statements and connects to nothing |

## The suite's duration

**760.58 s** and **624.58 s** for 689 tests, twice, at `3079f49`.  It is a property of the tests and not of the product;
it is recorded because it is real.
