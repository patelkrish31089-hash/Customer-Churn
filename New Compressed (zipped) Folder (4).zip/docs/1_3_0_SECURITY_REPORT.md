# 1.3.0 — security report

What was examined for this release, what was found, what was fixed, and — the section that matters — **what was not
examined at all**. No penetration test has been performed against this release, no third party has reviewed it, and
nothing here is a security certification.

## What 1.3.0 changed in the security surface

Three changes, all of them in the delivery layer, all of them in response to a defect that had a security consequence
rather than only a correctness one.

### 1. Configuration values no longer become SQL

`snowflake.py` built its DDL and its statements by pasting configured names — warehouse, database, schema, table —
into SQL text, and its only defence was to refuse a name containing `;`. That is a blocklist, and a blocklist over an
identifier is a losing position. Every configured identifier now passes `quote()`: it must match
`^[A-Za-z_][A-Za-z0-9_$]{0,254}$` and is returned quoted. A value that does not match is refused with a message naming
the field. Statements carry parameters for values and quoted, validated identifiers for names; nothing else reaches SQL.

Verified by: `tests/test_schema_mismatch_fails_validation.py` (seven accepted identifiers including reserved words,
nine refused including `DB; DROP TABLE X`, and a test asserting that every statement the adapter issues quotes what it
was configured with).

### 2. A connection can no longer be "healthy" while pointing at the wrong place

The 1.2.0 connection test compared two of six configured values and treated a missing value as agreement. A session in
`OTHER_SCHEMA` against a configuration saying `PUBLIC` reported `ok: True`, and the export would then write rows into
the wrong schema — a cross-environment data flow that nobody would notice until a person queried the table they
expected. All six are compared now, silence is a mismatch, and `tls=False` is refused before a connection is attempted.

Verified by: `tests/test_schema_mismatch_fails_validation.py`, including one case per compared field.

### 3. Two tenants' records can no longer collide

The canonical export record had no tenant. At the warehouse the MERGE keyed on the external customer id, so tenant B's
export **updated tenant A's row in place**: a tenant's business reading a churn probability computed from another
tenant's data. `tenant_id` is now the record's first required field and leads the identity, the idempotency key, the
deduplication, the primary key and the MERGE's `ON` clause. A record whose tenant cannot be established is refused
rather than defaulted, and `record_run()` refuses a run that mixes tenants.

Verified by: `tests/test_tenant_id_prevents_crm_collisions.py` and the updated schema/MERGE assertions in the two
destination test files.

## What the release validator now prevents, in security terms

`--release` no longer accepts a suite that did not run, a suite with a failure, an error or a **skip**, evidence from
another commit, or a dirty tree. In security terms this is the difference between an assertion and a checked assertion:
the previous check compared the register with itself and could not fail, which meant "26 requirements PASS" was a
sentence about a document rather than about the system.

## The security posture that did not change, and is not re-verified here

These were established in 1.2.0 and are unchanged by this release; the report that covers them is
`docs/1_2_0_SECURITY_REPORT.md`, and it is quoted rather than re-asserted:

- password hashing (scrypt), session tokens hashed at rest, TOTP for MFA, RBAC with a permission per operation, and an
  append-only hash-chained audit trail;
- encryption of CRM tokens and provider secrets at rest with the installation's key;
- an outbound HTTP guard against server-side request forgery (`netguard.py`), applied on every outbound call;
- tenant isolation on every query path, enforced by the services rather than by the routes;
- structured logging with correlation ids and secret redaction, and no secret in a log line or in an error envelope.

Nothing in this release added a new outbound call target, a new credential store or a new authentication path.

## What was **not** done for 1.3.0

| Activity | State | Consequence |
|---|---|---|
| penetration test | **not performed** (GATE 14 BLOCKED) | no claim of external verification exists |
| third-party code review | not performed | the review in `docs/1_3_0_MILESTONE_INDEPENDENT_REVIEW.md` is internal |
| dependency audit as of this date | not performed for 1.3.0; 1.2.0's audit is the last one on record | a new advisory may apply to a pinned version |
| secret scanning of the archive | performed as part of the release packaging (the archive contains no `.env`, key or credential: `docs/1_3_0_FINAL_TEST_REPORT.md` lists what the archive holds) | — |
| threat model for the new destination layer | written as design notes in the module docstrings, not as a separate document | a reviewer must read the modules |
| TLS handshake verification against Snowflake | **not observable here** — the claim is a mechanism (`insecure_mode` is never passed), not an observation | GATE 12 |
| data-at-rest encryption in the destination warehouse | the adapter's responsibility is not to weaken it; Snowflake account-level settings are the customer's | documented in `docs/1_3_0_DATA_GOVERNANCE_REPORT.md` |

## Findings this release did not fix, stated rather than filed

1. **The delivery layer has no route.** That is an availability gap rather than a confidentiality one today, and it
   becomes a governance question the moment it is wired: a route that starts a delivery must be permissioned and
   audited, and the run view must be tenant-scoped. R-98 records it.
2. **`export_outbox` stores idempotency keys and payload digests, not payloads.** That is deliberate — no customer data
   is duplicated into a second table — and it means a resumed run needs the records themselves, which the caller must
   supply. A future route must therefore keep the selection re-derivable or store the payload under the platform's
   encryption; that decision is not taken here.
3. **The audit trail does not yet record destination deliveries**, because nothing outside the tests delivers. When the
   route exists, the run and its acknowledgement counts must go into the audit chain, not only into `export_runs`.
