# 1.2.0 — sentiment evaluation

Two different questions live under this heading, and 1.2.0 separates them:

1. **Does the sentiment code work?** — answerable here, answered here.
2. **Is the sentiment *right* on our support conversations?** — needs a labelled sample of those conversations.
   Before 1.2.0 the sample could only come from outside the product, which made the second question a project.
   It is now a procedure inside it.

## What the product does (unchanged, verified at 1.1.1)

`services/sentiment.py` scores support text with a local multilingual transformer (ONNX, weights pinned by revision
and SHA-256), keeps a word-list baseline only as a labelled fallback, prepares text (Unicode normalisation, HTML
removal, PII redaction, language detection, length limits, duplicate detection), stores one score per interaction and
model with the model's identity, and reads those scores point-in-time. Its accuracy on real text is reported as
**not measured** — that statement is in the API and on the screen, not only in a document.

## What 1.2.0 adds: a labelled set can now be produced here

`services/annotations.py`, migration `0004`, twelve endpoints (see the access table in `tests/test_api.py`):

| Step | Rule | Why it is a rule |
|---|---|---|
| Create a batch | drawn from the tenant's own support text — sampled, by language, or an explicit list; texts shorter than 20 characters are never handed out | a reviewer cannot judge "ok thanks" |
| Declare the source | every batch records `is_synthetic`, fixed at creation | a result on generated text must never read as evidence about real text |
| Label | two different people, one label each, from positive / negative / neutral / mixed; a person may revise their own label, never somebody else's | one reader is not a measurement |
| Agreement | exact agreement and Cohen's kappa per pair of reviewers, plus the list of texts they disagreed on | a set people cannot agree on is not a benchmark for a model |
| Adjudicate | a reviewer with `signals:approve` decides each disagreement, with the decision recorded | disagreement has to end somewhere, and the trail must say where |
| Freeze | refused while any text lacks a second label or any disagreement is undecided; after freezing nothing changes | otherwise the numbers can be read while the set still moves, which is how a threshold gets tuned to the test set |
| Export / evaluate | only a frozen batch can be exported or scored; the evaluation inherits `is_synthetic` | the figure and the set it came from are tied together |

New permission `signals:annotate` (analyst, csm, data engineer, data scientist, approver, admin): labelling is
neither changing what the product computes (`signals:write`) nor deciding another reviewer's disagreement
(`signals:approve`).

## Evidence

`tests/test_annotations.py` (2 tests, in the suite: 495 passed on Python 3.13.16 with PostgreSQL at this commit):

* two reviewers label six texts; four agree, two do not;
* one reviewer revises, the disagreement count falls from two to one to none, and the revision counts once rather
  than adding a third label;
* with two disagreements back, `freeze` answers 409 `annotation_batch_incomplete` naming both texts; adjudication
  resolves them; freezing then succeeds and reports six items decided;
* after freezing, a new label and a second freeze are both refused (409 `annotation_batch_frozen`);
* an open batch cannot be exported or evaluated (409) — the numbers may not be read early;
* the export is in exactly the shape `sentiment.evaluate()` reads, and the evaluation carries
  `is_synthetic: false` for that batch, with coverage reported next to accuracy.

## What remains BLOCKED, and what exactly unblocks it

| Requirement | Blocker | What the product does meanwhile |
|---|---|---|
| R-27: accuracy on real support text | an authorised set of real support conversations, labelled by the customer's reviewers | reports *not measured*; refuses to present a synthetic figure as a real one |
| R-31/M-23: per-language accuracy | the same, with coverage of the supported languages | the harness reports per-label and per-language figures and coverage |

The remaining work is not engineering. It is: pick a sample, have two people label it, adjudicate the
disagreements, freeze, press evaluate. A customer can do that in an afternoon; the product can no longer be blamed
for being unable to receive the result.
