# 1.2.0 — implementation plan

Order and content follow the register (`docs/1_2_0_requirements.json`), not the master prompt's numbering, because
the audit found that four of the prompt's "missing" areas are already built and tested. Work is therefore split into
three kinds, and the plan says which kind every milestone is:

- **BUILD** — the capability is absent (`NOT_IMPLEMENTED`).
- **EXTEND** — the capability exists and a named part is missing (`PARTIAL`).
- **VERIFY** — no code change is expected; a run at the current commit is what is missing.

The rule that shapes the order: nothing that changes the schema or the outbound paths ships without its tests, and no
milestone is called done on one passing run. Each milestone ends with the full suite (493-test baseline plus what it
added), and 1.2.0 ends with the suite run twice on the final commit.

## Sequence

| Milestone | Kind | What | Register | Why here |
|---|---|---|---|---|
| M1 | VERIFY | Baseline audit, register, plan, risks | all | An honest starting line: 23 PASS, 16 PARTIAL, 9 NOT_IMPLEMENTED, 8 BLOCKED, 2 NOT_APPLICABLE of 58 |
| M2 | BUILD | Sentiment annotation workflow: tasks over support text, two reviewers, agreement, adjudication, frozen labelled set, export in the format `sentiment.evaluate()` reads | R-26 | Turns the one BLOCKED accuracy claim (R-27) into a procedure that needs data and nothing else — a customer can run it the day they have labels |
| M3 | VERIFY + EXTEND | Feature adoption: hand-computed cases through the API, the feature store and the model matrix; account-level policy; velocity and abandonment | R-30, R-31 | The most misread number in the product; an independent arithmetic check is cheap and settles it |
| M4 | EXTEND | CRM: the twelve-step acceptance script moved into the repository and run per adapter against the local stand-in | R-01..R-03 | Makes the only difference between today and a vendor round trip the credential itself |
| M5 | BUILD | Reverse ETL: one canonical record builder; Snowflake destination; Zendesk and Marketo adapters; partial-failure and restart tests | R-06, R-08, R-09, R-17 | The PDF's hand-over requirement, and the destinations that are actually asked for |
| M6 | BUILD | Messaging: quiet hours, open/click tracking with lawful configuration, delivery states made explicit | R-17, R-18, R-23 | Small, testable, and it removes two "provider accepted = delivered" ambiguities |
| M7 | BUILD | Push: APNs over HTTP/2 with a token, device-token registry with expiry and pruning; SMS status callbacks driven by a Twilio-compatible local stub | R-19..R-23 | The last channel that cannot leave the process today |
| M8 | EXTEND | Airflow: the nightly work split by concern, alerting, and a scheduler run across consecutive cycles with a forced failure, a retry and a restart | R-32..R-34 | Needs a container that stays up for hours; scheduled early so it can run in the background |
| M9 | EXTEND | MLflow: remote server over TLS with a token, whole lifecycle against it, checks before promotion | R-35..R-37 | Container work, same reason |
| M10 | EXTEND | SSO: provider-side logout and session revocation against Keycloak; configuration profiles for Entra ID, Okta and Google, unverified and labelled so | R-38..R-40 | Honest profiles are better than an implied acceptance |
| M11 | VERIFY | PostgreSQL, Docker image, compose, worker restart, browser E2E — rebuilt and re-run on 1.2.0 code | R-46, R-48, R-55 | Regression on the paths the new features touch |
| M12 | VERIFY | Real-data validation: the procedure, the metrics, the report template; run only when data exists | R-51, R-52 | Stays BLOCKED; what ships is the harness |
| M13 | BUILD | Backup and restore command, checksummed, with a real restore exercise; performance suite (smoke/load/stress/soak) with a sustained local run | R-47, R-49, R-50 | RPO/RTO stay the owner's; the mechanism and one measured restore are ours |
| M14 | BUILD | Privacy: customer deletion and correction with audit integrity; retention policy enforced | R-53, R-54 | Needs care about what deletion means for audit rows; planned after the schema stabilises |
| M15 | BUILD | Bandit, pip-audit, secret scanning as CI jobs with a documented suppression list | R-44 | Cheap, and it is a gate |
| M16 | VERIFY | Final: suite twice, E2E, manifest, archive, clean extraction and start, register refreshed, all reports written | R-56, R-57 | Only evidence from the final commit counts |

## What each milestone must produce

1. The change itself, on `main`, in the existing architecture — no second backend, no second frontend, no rewrite.
2. Tests that fail without the change and pass with it, in the existing suite (so the 493 baseline stays one number).
3. A row in the register with the new status and the test or run that made it true.
4. A paragraph in the matching 1.2.0 report, written from the run, not from the intent.
5. The full suite green before the next milestone starts (one heavy job at a time on a 2 vCPU machine).

## What will not happen

- No feature is called accepted because its code exists: 21 of the 58 requirements in the register are held by
  something this machine does not have, and they stay that way until the party named in the register acts.
- No mock is renamed to look like a vendor. The CRM stand-in stays called a stand-in; the Twilio stub stays called a
  stub; a synthetic evaluation stays labelled synthetic.
- No threshold is adjusted after seeing a result, no test is deleted to make a run green, and no historical PASS is
  carried forward onto changed code.

## Done, for this release

1.2.0 is done when the register has no `FAIL` and no `NOT_TESTED`, every `NOT_IMPLEMENTED` has become `PASS`,
`PARTIAL` or `BLOCKED`-with-reason, the suite has passed twice on the final commit including browser E2E, the
archive is built from a clean tree and checked, and every BLOCKED requirement names the exact artefact that would
close it. It is **not** done when everything is PASS, because 21 of those artefacts are not ours to produce.
