# 1.2.0 — requirement traceability

Generated from `docs/1_2_0_requirements.json` (edit that file, then re-run `scripts/build_1_2_0_register.py`).

Source: release 1.2.0, commit `0224654`.

## Counts at the baseline

| Status | Requirements |
|---|---|
| PASS | 26 |
| PARTIAL | 16 |
| FAIL | 0 |
| BLOCKED | 8 |
| NOT_IMPLEMENTED | 6 |
| NOT_TESTED | 0 |
| NOT_APPLICABLE | 2 |

**58 requirements.** No requirement is PASS without evidence at the source commit;
no requirement is BLOCKED without naming what would unblock it.

## The register

| ID | Area | Requirement | Status | Evidence | What is next | Unblocked by |
|---|---|---|---|---|---|---|
| R-01 | CRM | Salesforce adapter: OAuth, token refresh, field mapping, risk update, task, notes, webhooks, retry, reconciliation, revocation | **PARTIAL** | Adapter + request shapes checked against Salesforce's published description; reaches the live host (401 on a bad token). No Salesforce account has accepted a request. | M4: run the twelve-step acceptance script per adapter against the local CRM stand-in; vendor round trip needs an account. | salesforce sandbox account + OAuth client |
| R-02 | CRM | HubSpot adapter, end to end | **PARTIAL** | 85 of 85 PATCHes accepted, 85 signed events confirming deliveries, replay/stale/tampered refused with 401, task created, export, revocation: against a CRM implementing HubSpot's rules on this machine (release-evidence/1.1.1/crm). No HubSpot account involved. | M4: move the acceptance script into the repository and run it per adapter in CI (local stand-in). | hubspot test account |
| R-03 | CRM | Intercom adapter | **PARTIAL** | Request shapes checked; no Intercom workspace. | M4 | intercom test workspace |
| R-04 | CRM | One provider-neutral integration service with per-provider adapters | **PASS** | services/crm.py routes by provider through a common contract (connect, health, read, write, events, errors, retry, idempotency, reconcile); tests/test_crm.py. |  |  |
| R-05 | CRM | Replay protection, idempotency, delivery reconciliation on CRM events | **PASS** | Duplicate stored once, stale and tampered refused; confirmation tied to the vendor's event key (tests/test_crm.py; 1.1.1 evidence). |  |  |
| R-06 | Reverse ETL | Canonical prediction record with the fifteen named fields | **PARTIAL** | services/reverse_etl.py builds the record with internal/external ids, probability, tier, horizon, reasons, SHAP, model id/version, feature version and timestamps; decile and recommended intervention are not both present in every destination mapping. | M5: single canonical record builder used by every destination, asserted by one test |  |
| R-07 | Reverse ETL | Destinations: PostgreSQL analytical, file/hand-off | **PASS** | Destination types with mapping, batching, checkpoints, quarantine and export audit; 369-row export verified by sha256 (1.1.1 evidence). |  |  |
| R-08 | Reverse ETL | Snowflake destination | **NOT_IMPLEMENTED** | grep -ri snowflake src -> nothing. | M5 (M-01) | snowflake account for acceptance; a compatible local server for development |
| R-09 | Reverse ETL | Zendesk, Marketo destinations | **NOT_IMPLEMENTED** | no adapter. | M5 (M-02) | vendor accounts for acceptance |
| R-10 | Reverse ETL | Refuse to export predictions of an unapproved model | **PASS** | destination write checks the model's approval state (tests/test_retention.py, tests/test_registry_predictions.py). |  |  |
| R-11 | Reverse ETL | Hightouch / Census direct integration | **NOT_APPLICABLE** | Neither exposes a public connector API for a third-party writer; the warehouse/file hand-off covers the need. Claiming an integration would be a substitution. |  |  |
| R-12 | Email | Provider adapters (SendGrid, SES) with credentials, sandbox and live modes | **PARTIAL** | Request shapes per vendor; sandbox via each vendor's validation mode in the test suite. No vendor account has accepted a message. |  | sendgrid/ses account |
| R-13 | Email | Delivery over a real mail server | **PASS** | SMTP provider (1.1.1): 73 of 73 campaign messages accepted by Mailpit, 0 rejected; SANDBOX sends nothing; outbound address guard (DEF-085). |  |  |
| R-14 | Email | Templates, versioning, variables, preview, test send | **PASS** | services/notify.py templates with approval by a second person, version bump, placeholder validation, preview and test send; tests/test_outbound.py. |  |  |
| R-15 | Email | Campaigns: audience, eligibility, consent, steps, scheduling, pause/cancel, reporting | **PASS** | services/campaigns.py with 3 presets and API-created campaigns, consent and cooldown exclusion, A/B groups, review by a second person, worker delivery, reporting (tests/test_outbound.py). |  |  |
| R-16 | Email | Bounces, complaints, suppression, unsubscribe, webhook signature | **PASS** | Event endpoint with HMAC signature, suppression list, unsubscribe link and one-click endpoint (tests/test_outbound.py). |  |  |
| R-17 | Email | Open and click tracking where lawful and configured | **NOT_IMPLEMENTED** | no tracking endpoint or setting. | M6 (M-06) |  |
| R-18 | Email | Quiet hours | **PASS** | Quiet hours: marketing messages held (not dropped) outside a configurable window with a time zone, released through the same deferred-job mechanism as a retry; transactional messages unaffected; a malformed window or unknown zone is a loud validation failure (tests/test_outbound.py::test_a_marketing_message_outside_the_quiet_hours_is_held_and_released_rather_than_dropped). | done in M6 |  |
| R-19 | SMS | Twilio adapter, E.164 validation, consent, opt-out, suppression, status callbacks | **PARTIAL** | Adapter and consent/suppression path tested with a simulated transport; no Twilio account, so no real message and no real status callback. | M7 | twilio test account |
| R-20 | Push | FCM adapter | **PARTIAL** | Adapter with validate_only and topic support tested against a simulated transport; no Firebase project. | M7 | firebase project |
| R-21 | Push | APNs delivery over HTTP/2 | **NOT_IMPLEMENTED** | The payload is built and the message is rehearsed; the HTTP/2 client is absent, so nothing can be sent (stated in docs/LIMITATIONS.md). | M7 (M-03) | APNs key/certificate for acceptance |
| R-22 | Push | Device-token registry, expiry, invalid-token cleanup | **NOT_IMPLEMENTED** | no device_tokens table or endpoint. | M7 (M-04) |  |
| R-23 | Push | Distinguish prepared / queued / provider accepted / delivered / opened | **PARTIAL** | provider acceptance and delivery events are distinct (sent / delivered / bounced / complained / failed / blocked / suppressed / dry_run), and dry-run can never be counted as sent. Still missing: separate SENT_TO_PROVIDER / ACCEPTED / UNKNOWN states, and 'opened' (see R-17). Named in docs/1_2_0_NOTIFICATION_DELIVERY.md. | M7 |  |
| R-24 | Sentiment | Model-backed scoring with provider abstraction and versioned inference | **PASS** | Local multilingual transformer (ONNX, pinned revision + sha256) plus a word-list baseline labelled as such, per-interaction storage with model identity (services/sentiment.py, docs/SIGNALS.md). |  |  |
| R-25 | Sentiment | Text preparation: Unicode, HTML, PII redaction, language detection, chunking, empty/unsupported handling | **PASS** | services/sentiment.py preparation pipeline; tests/test_analytics.py. |  |  |
| R-26 | Sentiment | Human annotation workflow with reviewers, disagreement, export | **PASS** | A batch of support text, two independent reviewers, exact agreement and Cohen's kappa per pair reported before any model is scored, adjudication of each disagreement, a freeze that refuses while a text lacks a second label or a disagreement is undecided, and an export in the shape sentiment.evaluate() reads. A frozen batch cannot be changed; an open batch cannot be exported or evaluated. New permission signals:annotate. (tests/test_annotations.py, migration 0004) | done in M2; the reviewer *process* is the customer's |  |
| R-27 | Sentiment | Evaluation on real labelled support text | **BLOCKED** | The harness exists and is now reachable from a labelled set produced inside the product (R-26); it has only ever been run on the synthetic templates, and the result carries is_synthetic so a synthetic figure cannot be read as evidence about real text. The product still reports accuracy as not measured. | M12 (M-19) | authorised labelled support dataset |
| R-28 | Feature adoption | Governed, versioned feature catalogue with eligibility | **PASS** | ProductFeature with release/retire dates, plan tiers, availability, telemetry mapping, approval by a second person (services/adoption.py). |  |  |
| R-29 | Feature adoption | Eligibility-based adoption rate with explicit denominator; missing not zero | **PASS** | feature_engine.AdoptionGrid; rates are missing when nothing is eligible; adopted/not adopted/not eligible/unknown/missing telemetry distinguished (tests/test_features_pit.py). |  |  |
| R-30 | Feature adoption | Customer, user, account, cohort, plan and product level; breadth, frequency, depth, velocity, abandonment, time to first use | **PARTIAL** | Customer level with plan-tier and tenure segments, new/abandoned flags, 7- and 30-day and as-of windows, breadth and frequency. Not present: an account-level aggregation policy for multi-user accounts, a per-user view, adoption velocity as a series and time-to-first-use per feature (docs/1_2_0_FEATURE_ADOPTION_REPORT.md, 'What remains PARTIAL'). | M3 EXTEND: account policy, per-user view, velocity, time to first use |  |
| R-31 | Feature adoption | Independent mathematical test cases | **PASS** | Hand-computed cases in tests/test_signals.py: 2/3 and 1.0 and 0.0 rates against an explicit denominator, a rate that is missing (not zero) with an empty denominator, plan gating and release dates changing the denominator, raw breadth (3 distinct names) against the governed rate, per-entry adoption rules; and the report's mean adoption equal to the mean of the feature_adoption_rate_30d column to 1e-4 (docs/1_2_0_FEATURE_ADOPTION_REPORT.md). | done in M3 (verification); the EXTEND items are R-30 |  |
| R-32 | Airflow | Real DAG with retries, timeouts, dependency chain, single orchestration authority | **PASS** | deploy/airflow/churn_nightly_dag.py: 7 steps per tenant, retries 2, retry_delay, execution_timeout, max_active_runs=1, migration check first; CHURN_ORCHESTRATOR decides the authority and the platform refuses to double-run (tests/test_lifecycle_orchestration.py). |  |  |
| R-33 | Airflow | One DAG per concern (17 DAGs) as the master prompt lists | **PARTIAL** | the work is one DAG of seven ordered steps; splitting it further has not been shown to be necessary. | M8 (M-13) |  |
| R-34 | Airflow | Multi-night scheduler operation, retry, restart, backfill | **BLOCKED** | A scheduler run on 3.4.0 and 2.11.2 with LocalExecutor succeeded once; consecutive scheduled nights have not been observed and the container cannot stay up for days here. | M8 | an Airflow installation that stays up |
| R-35 | MLflow | Model registry with lifecycle, gates, rollback | **PASS** | services/registry.py lifecycle CANDIDATE->...->RETIRED with promotion gates, rollback and audit; tests/test_registry_predictions.py, tests/test_lifecycle_orchestration.py. |  |  |
| R-36 | MLflow | Remote authenticated tracking server as the authoritative registry | **PARTIAL** | Tracking URI and token are configurable and a mirror service exists; no remote server, TLS or token round trip has been performed. | M9 (M-14) | a remote MLflow deployment |
| R-37 | MLflow | Signature, example, checksum, lineage checked before promotion | **PASS** | signature and input example logged, artefact checksum recorded, lineage (dataset, commit) required by the gates; tests/test_mlflow_mirror.py. |  |  |
| R-38 | SSO | OIDC: discovery, PKCE, JWKS, issuer/audience, state, nonce, groups/roles, health | **PASS** | Verified against Keycloak 26.0 with a browser and over HTTP, including every refusal code and the MFA rule (release-evidence/1.1.1/sso). |  |  |
| R-39 | SSO | Hosted provider (Entra ID, Okta, Google) acceptance | **BLOCKED** | Only Keycloak has been used; no hosted tenant. | M10 | a hosted tenant and an app registration |
| R-40 | SSO | Logout and session revocation | **PARTIAL** | Session revocation is implemented and tested; single-logout propagation to the provider is not. | M10 |  |
| R-41 | SSO | SAML | **NOT_APPLICABLE** | No enterprise requirement has been named; OIDC covers the stated need. |  |  |
| R-42 | Security | Distributed rate limiting across processes with fail-open/deny policy | **PASS** | Database-backed shared counters with an atomic upsert, CHURN_RATE_LIMIT_STORE_FAILURE, per-IP/account buckets, Retry-After (services/ratelimit.py, tests/test_security.py). |  |  |
| R-43 | Security | CSRF, secure cookies, SSRF guard, webhook signature, secret box, audit log, masking | **PASS** | tests/test_security.py, tests/test_audit_policies.py; SSRF guard extended to the mail server in 1.1.1 (DEF-085). |  |  |
| R-44 | Security | Bandit, pip-audit, secret scanning in CI | **PASS** | Bandit (0 high, 0 medium), pip-audit on requirements.lock (no known vulnerabilities) and scripts/scan_secrets.py (no credential; nine matches suppressed, all of them the rule 'password in a URL', each with a written reason) run clean at this commit and are jobs in .github/workflows/ci.yml. Corrected during the 1.3.0 audit: the text said six suppressions. | done in M15; the GitHub run is R-58 |  |
| R-45 | Security | Independent penetration test | **BLOCKED** | no assessor. |  | an independent assessor |
| R-46 | Database | PostgreSQL runtime, migrations up/down, constraints, concurrency, pooling | **PASS** | 498 tests ran against PostgreSQL in strict mode at this commit; migrations 0001-0004 verified up/down/re-up with no drift (tests/test_migrations.py). Corrected during the 1.3.0 audit: the text said 493 tests and migration 0003. |  |  |
| R-47 | Database | Backup and verified restore | **PASS** | churn-platform backup / restore / backup-check: one archive with a manifest of SHA-256 per member, restore verifying every checksum and member path before writing, health check after (revision, eleven table counts, newest audit event). Exercised on SQLite by tests/test_backup.py, which destroys the database, restores from the archive alone, compares counts, and is refused on a truncated and on a doctored archive; and measured on PostgreSQL at demo scale (3.4 MB archive, 1.90 s backup, 3.37 s restore, all eleven counts identical). That run found and fixed a real defect: the client tools were handed a URL with a driver suffix and could not have backed up a production database. RPO/RTO and a scheduled, encrypted, off-site policy remain with the owner (GATE 15). | M13 mechanism done; owner-side policy stays BLOCKED |  |
| R-48 | Deployment | Docker image and compose deployment, non-root, health checks | **PARTIAL** | The 1.1.0 image was built, started and smoke-tested with compose (release-evidence/1.1.0/container); the 1.2.0 image was never built, so the 1.2.0 source has no container evidence. Corrected from PASS during the 1.3.0 audit: the PASS contradicted its own evidence. See docs/1_2_0_RECONCILIATION.md. | M11 of 1.3.0: build and exercise the 1.3.0 image (R-85). |  |
| R-49 | Performance | Load figures at several concurrency levels with the hardware stated | **PARTIAL** | Closed-loop figures measured at this commit on the build machine (2 vCPU / 1,982 MB, generator co-located, PostgreSQL, synthetic demo tenant): 48.6 req/s at 1 client (p95 49.7 ms), 70.7 at 8 (p95 237.7 ms), 68.6 at 32 (p95 721.6 ms), 0 errors; documented with what they cannot say in docs/1_2_0_PERFORMANCE_REPORT.md. Sustained load, open-loop arrival and any SLO verdict need a staging host and owner-set thresholds. | M13 (M-11) |  |
| R-50 | Performance | Sustained staging run and production sizing | **BLOCKED** | Closed-loop figures measured at this commit on the build machine (2 vCPU / 1,982 MB, generator co-located, PostgreSQL, synthetic demo tenant): 48.6 req/s at 1 client (p95 49.7 ms), 70.7 at 8 (p95 237.7 ms), 68.6 at 32 (p95 721.6 ms), 0 errors; documented with what they cannot say in docs/1_2_0_PERFORMANCE_REPORT.md. Sustained load, open-loop arrival and any SLO verdict need a staging host and owner-set thresholds. |  | a staging environment; service-level objectives set by the owner |
| R-51 | Real data | Churn model validation on authorised company data | **BLOCKED** | Synthetic only; the product does not present synthetic metrics as company evidence. | M12 | authorised historical data with mature labels |
| R-52 | Real data | Churn thresholds and financial assumptions approved by the owner | **BLOCKED** | no owner decision recorded. |  | business-policy approval |
| R-53 | Privacy | Customer-data deletion and correction workflow | **NOT_IMPLEMENTED** | no deletion path; only audit retention. | M14 (M-08) |  |
| R-54 | Privacy | Data classification, retention, masking, provider sharing controls | **PARTIAL** | Masking and audit exist; classification and retention policy are documented, not enforced by a job. | M14 |  |
| R-55 | Frontend | 32 screens, every screen on persisted data, all buttons acting | **PARTIAL** | The browser application serves the screens the register lists and the in-suite E2E drives sign-in, the pipeline and the main workflows at this commit; the dedicated browser evidence is 1.1.0's, and screens for the features added in 1.2.0 (annotation, quiet hours, backup and restore) do not exist. Corrected from PASS during the 1.3.0 audit. See docs/1_2_0_RECONCILIATION.md. | M14 of 1.3.0: add the missing screens (R-89) and drive every one of them in a current-source E2E. |  |
| R-56 | Regression | The whole suite re-run twice on the final source, plus browser E2E | **PASS** | 498 tests twice on Python 3.13.16 with identical test ids and outcomes (762.23 s, 668.79 s), then once each on 3.12.16 and 3.11.18, all against PostgreSQL in strict mode; browser E2E runs inside the suite. Corrected during the 1.3.0 audit: the text carried the 493-test figure of 1.1.1. |  |  |
| R-57 | Release | Manifest, checksums, clean extraction, install and start of the archive | **PASS** | scripts/build_manifest.py --require-clean --zip release/churn-platform-1.2.0.zip: the manifest lists every packaged file with its SHA-256 and the JUnit evidence of the release runs, refuses to build from a dirty checkout, and records the archive's own size and digest; the archive is then extracted into an empty directory, checked against the manifest, installed and started (`scripts/check_wheel.py`). Digests are in release/MANIFEST.json inside the archive and in /home/user/RELEASE-1.2.0-REPORT.md beside it, since a document cannot contain the hash of the archive that contains it. |  |  |
| R-58 | Release | CI on GitHub's own runners | **BLOCKED** | The 5-job workflow has only run on a local act runner. |  | a repository and a token |

## How a status changes

1. A change to the code makes every PASS that covers it stale: the status goes back to NOT_TESTED until a run at
   the new commit restores it.
2. A BLOCKED item is only closed by evidence the blocker names — an account, a dataset, an assessor, a host.
3. A NOT_APPLICABLE item is only valid with its reason written down, and the reason is reviewable.

## Gates

| Gate | Kind | State | Requirement |
|---|---|---|---|
| GATE 1 | technical | **PASS** | PostgreSQL runtime, migrations, concurrency (R-46) |
| GATE 2 | technical | **PARTIAL** | Docker build and runtime (R-48) — rebuilt and re-verified for 1.2.0 |
| GATE 3 | technical | **PASS** | Clean dependency installation on three interpreters (R-56) |
| GATE 4 | technical | **PARTIAL** | Airflow scheduler and remote MLflow (R-34, R-36) |
| GATE 5 | technical | **PASS** | Ruff, Bandit, pip-audit, secret scanning (R-44): all four commands clean at 0224654 |
| GATE 6 | technical | **BLOCKED** | Sentiment and adoption evaluation on labelled data (R-27, R-31) |
| GATE 7 | technical | **PARTIAL** | Multi-process rate limiting PASS; hosted OIDC and production TLS BLOCKED (R-42, R-39) |
| GATE 8 | technical | **BLOCKED** | Sustained load and staging recovery (R-50) |
| GATE 9 | external | **BLOCKED** | Salesforce, HubSpot, Intercom sandbox acceptance (R-01..R-03) |
| GATE 10 | external | **BLOCKED** | Real email, SMS and push provider acceptance (R-12, R-19..R-21) |
| GATE 11 | external | **BLOCKED** | Hosted staging deployment |
| GATE 12 | external | **BLOCKED** | Real-company churn-model validation (R-51) |
| GATE 13 | external | **BLOCKED** | Business-policy and financial-assumption approval (R-52) |
| GATE 14 | external | **BLOCKED** | Independent penetration testing (R-45) |
| GATE 15 | external | **BLOCKED** | Disaster-recovery acceptance by the system owner (R-47, R-50) |

A technical gate may only move to PASS with a run recorded at the final commit. An external gate may only move
to PASS with evidence from the party it names; nothing here can be closed from this machine.
