# 1.2.0 — implementation status

One row per milestone of `docs/1_2_0_IMPLEMENTATION_PLAN.md`. A milestone is only *done* when the full suite has
passed on the change — not when its own tests have.

| Milestone | What | State | Evidence |
|---|---|---|---|
| M1 | Baseline audit, register, plan, risks | **done** | `docs/1_2_0_BASELINE_AUDIT.md`, `docs/1_2_0_REQUIREMENT_TRACEABILITY.md` (58 requirements: 28 PASS, 14 PARTIAL, 6 NOT_IMPLEMENTED, 8 BLOCKED, 2 NOT_APPLICABLE) |
| M2 | Sentiment annotation workflow | **done** | migration `0004`, `services/annotations.py`, 12 endpoints, permission `signals:annotate`, `tests/test_annotations.py`; 495 passed on Python 3.13.16 with PostgreSQL; `docs/1_2_0_SENTIMENT_EVALUATION.md` |
| M3 | Feature-adoption verification | **verification done**, EXTEND next | `docs/1_2_0_FEATURE_ADOPTION_REPORT.md`: existing tests already hold the arithmetic (2/3, 1.0, 0.0, missing-not-zero, plan and release gating, report = feature vectors to 1e-4) so R-31 moved to PASS; R-30 stays PARTIAL for account policy, per-user view, velocity and time-to-first-use |
| M4 | CRM acceptance script in the repository | **local part done**, vendor open | `docs/1_2_0_CRM_ACCEPTANCE.md`: the twelve steps, 8 of them proven against the stand-in (`scripts/check_crm_contracts.py` → 4 of 4 requests conform to the vendors' own published descriptions; authenticated idempotent sync, retry/backoff on 429/500/timeout, 400 surfaced verbatim, internal-host refusal, tenant scoping). Steps 3, 5, 11 and 12 need a sandbox account that may receive writes → R-01..R-03 stay BLOCKED |
| M5 | Reverse ETL: canonical record, Snowflake, Zendesk, Marketo | | R-06, R-08, R-09 |
| M6 | Quiet hours, open/click tracking, explicit delivery states | **quiet hours done**, the other two open | `quiet_hours()` in `services/notify.py` with `notify_quiet_hours` / `notify_quiet_timezone`: a marketing message inside the window is *held* — status `queued`, released at the window's end through the deferred-job mechanism — never dropped; transactional messages unaffected; malformed window or unknown zone is a validation failure. Test: `tests/test_outbound.py::test_a_marketing_message_outside_the_quiet_hours_is_held_and_released_rather_than_dropped`. R-18 PASS; R-17 (open/click) and R-23 (state split) stay PARTIAL — see `docs/1_2_0_NOTIFICATION_DELIVERY.md` |
| M7 | APNs over HTTP/2, device tokens, SMS status callbacks | | R-19..R-23 |
| M8 | Airflow split by concern, multi-cycle run | | R-32..R-34 |
| M9 | Remote MLflow lifecycle | | R-35..R-37 |
| M10 | SSO logout and session revocation, provider profiles | | R-38..R-40 |
| M11 | PostgreSQL, Docker, browser E2E on 1.2.0 code | | R-46, R-48, R-55 |
| M12 | Real-data validation harness | | R-51, R-52 |
| M13 | Backup/restore with a real exercise; performance suite | **backup/restore done**, performance open | `src/churn_platform/backup.py` + `backup` / `restore` / `backup-check` CLI. `tests/test_backup.py` archives a live installation, deletes the database and the data directory, restores from the archive alone and compares eleven table counts; refuses a truncated archive, refuses a doctored member on checksum, and overwrites only with `--force`. R-47 PASS; R-49/R-50 remain BLOCKED on a staging environment and owner-set SLOs |
| M14 | Customer deletion and correction | | R-53, R-54 |
| M15 | Bandit, pip-audit, secret scanning in CI | **done** | `security` job in `.github/workflows/ci.yml`; `scripts/scan_secrets.py`; Bandit 0 high/0 medium, pip-audit no known vulnerabilities, secret scan clean at this commit; `docs/1_2_0_SECURITY_REPORT.md`. R-44 PASS; the first run on GitHub's runners is R-58 |
| M16 | Final: suite twice, E2E, manifest, archive, clean extraction | **done** | 498 passing twice on 3.13.16 (identical test ids and outcomes), once each on 3.11.18 and 3.12.16; browser E2E is part of the suite; `release/MANIFEST.json` and `release/churn-platform-1.2.0.zip` built from a clean tree and verified by extracting into an empty directory |

## Environment note

The sandbox was reset between sessions: the `uv`-managed interpreters under `~/.local` (which are not part of the
saved workspace) disappeared, so the three-interpreter matrix had to be rebuilt before the release, which it was.
All 1.2.0 evidence is from Python with PostgreSQL, in strict mode. The interpreters were rebuilt from
`requirements.lock` (`/var/tmp/rebuild_venvs.sh`, now with `--clear`) and the whole suite is green on **3.11.18,
3.12.16 and 3.13.16 — 498 tests each**, and run twice on 3.13.16 with identical test ids and outcomes.

## Numbers that must not be confused

| | 1.1.1 | 1.2.0 so far |
|---|---|---|
| Requirements with a status | 38 (PDF traceability) | 58 (this register) |
| Tests | 493 | 498 |
| PASS / PARTIAL / NOT_IMPLEMENTED / BLOCKED | — | 28 / 14 / 6 / 8 |
| External gates closed | 0 | 0 |

The two counts are different catalogues and are never added together. The PDF traceability of 1.1.1 remains the
authority for the brief; this register is the authority for the master prompt of 1.2.0.
