# 1.2.0 — complete audit

The single-page summary of the release. Detail lives in the documents it links.

## Where the release stands

| | Count |
|---|---|
| Requirements in the register | 58 |
| PASS | 28 |
| PARTIAL | 14 |
| NOT_IMPLEMENTED | 6 |
| BLOCKED (external party) | 8 |
| NOT_APPLICABLE (with reason) | 2 |
| Technical gates closed | 3 of 8 (two more partly) |
| External gates closed | 0 of 7 |
| Tests | **498, all passing**, on Python 3.13.16 with PostgreSQL — the identical run twice — and again on 3.11.18 and 3.12.16 |

## What was built in 1.2.0

| Milestone | Result | Document |
|---|---|---|
| M1 | Audit, register (58 requirements), plan, risks | `1_2_0_BASELINE_AUDIT.md`, `1_2_0_REQUIREMENT_TRACEABILITY.md`, `1_2_0_IMPLEMENTATION_PLAN.md`, `1_2_0_RISK_REGISTER.md` |
| M2 | **Human annotation of support text** — two reviewers, agreement (exact + Cohen's kappa), adjudication, a freeze that makes the set immutable, export in the evaluation's shape; new permission `signals:annotate`; migration `0004` | `1_2_0_SENTIMENT_EVALUATION.md` |
| M3 | Adoption arithmetic verified against hand-computed cases; the three genuinely missing parts named (account policy, per-user view, velocity, time to first use) | `1_2_0_FEATURE_ADOPTION_REPORT.md` |
| M6 | **Quiet hours** — marketing held, not dropped, released at the window's end; transactional untouched | `1_2_0_NOTIFICATION_DELIVERY.md` |
| M13 | **Backup and restore** — checksummed archive, traversal-checked restore, health check afterwards, and a real destroy-and-restore exercise | `1_2_0_DISASTER_RECOVERY_REPORT.md` |
| M15 | **Security tooling** — Bandit, pip-audit and a credential scan, clean at this commit, as CI jobs | `1_2_0_SECURITY_REPORT.md` |
| M13b | **Measured on PostgreSQL** — 1.90 s backup, 3.37 s restore, eleven identical counts; closed-loop load figures; and the defect that run found (`pg_dump` given a driver-suffixed URL) fixed | `1_2_0_PERFORMANCE_REPORT.md` |
| M4 | **CRM acceptance script** — four contract checks pass, 8 of 12 acceptance steps proven against the stand-in, 4 need an account | `1_2_0_CRM_ACCEPTANCE.md` |

## What is still absent from the code

Snowflake, Zendesk and Marketo destinations; APNs delivery (no HTTP/2 client); the device-token registry; open and
click tracking; the separate `sent_to_provider` / `accepted` / `unknown` message states; account-level adoption
policy; customer-data deletion; the per-concern Airflow DAGs; the remote MLflow lifecycle; the sustained load
suite. Each has a milestone in `1_2_0_IMPLEMENTATION_PLAN.md` and a row in the register.

## What cannot be done here at all

Vendor acceptance (CRM, e-mail, SMS, push), real customer data, a hosted identity provider, an owner's RPO/RTO and
business thresholds, an independent penetration test, a hosted staging environment, and a CI run on GitHub's own
runners. Eight register rows and seven gates. `1_2_0_PRODUCTION_ACCEPTANCE.md` lists what closes each one and whose
afternoon it takes.

## The one sentence

This release makes the product measurably more honest about itself — a labelled set it can actually receive, a
message it holds rather than drops, a backup it has actually restored, and a register that refuses to call a
capability accepted because the code exists.
