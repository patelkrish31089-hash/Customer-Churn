# 1.3.0 — PDF compliance report

The brief's requirements are the 38 ids in `docs/traceability/requirements.toml` (`REQ-DATA-01` … `REQ-QA-01`), each
naming the PDF sections it comes from. They are **not** renumbered, merged or reworded here: the 1.3.0 register's
`R-nn` entries track this release's work, and the two numbering schemes are kept apart in
`docs/1_3_0_REQUIREMENT_MATRIX.md` for exactly this reason.

**No requirement in this release is labelled PDF COMPLIANT without a test naming it and passing at the commit named.**
A family total below is an aggregate over the register's areas; it is **not** a per-requirement verdict, and the
per-requirement verdict is the register's entry plus the module the matrix names.

## The state of the register at this commit

| Status | Requirements | Meaning |
|---|---|---|
| PASS | see `docs/1_3_0_REQUIREMENT_TRACEABILITY.md` | observed on this source, at the commit the entry names |
| PARTIAL | " | some of it exists and is observed, some does not, and the entry says which |
| BLOCKED | " | the code may exist; the proof needs a party who is not here, and the entry names them |
| NOT_IMPLEMENTED | " | absent from the source |
| NOT_APPLICABLE | " | does not apply, and the entry says why |

The counts are computed from the entries by `scripts/build_1_3_0_register.py` and are never typed. The generated
document is the authority; this report does not restate its numbers, because two copies of a count drift the moment one
of them is edited by hand — which is precisely how 1.2.0's register came to disagree with itself.

## The brief, requirement family by family

| Id | The brief asks for | PDF sections | Register entries in its areas | Test modules naming it |
|---|---|---|---|---|
| REQ-DATA-01 | Source files are read, mapped and validated | 2.2 obj. 1, 3.1 | 11 (Real data, Database, Reverse ETL) | `tests/test_readers_schemas.py` |
| REQ-DATA-02 | One store for all sources, with quarantine and history | 2.2 obj. 1, 3.1 | 11 | `tests/test_ingestion.py` |
| REQ-DATA-03 | Continuous sources: signed webhooks and scheduled pulls | 3.1, 8.1 | 11 | — |
| REQ-DATA-04 | Data-quality rules and reviewed corrections | 3.1 | 11 | `tests/test_quality.py` |
| REQ-ML-01 | Churn labels within 30 days, voluntary or involuntary | 2.1, 5 | 10 (MLflow, Performance, Monitoring, Regression) | `tests/test_timeline_labels.py` |
| REQ-ML-02 | Point-in-time feature store with the brief's features | 2.2 obj. 1, 3.1, 3.2 | 10 | `tests/test_features_pit.py` |
| REQ-ML-03 | Training data without leakage | 5 | 10 | `tests/test_mlprep.py` |
| REQ-ML-04 | Training, class imbalance, evaluation, cost-based threshold | 2.2 obj. 2, 5.1–6.3 | 10 | `tests/test_training_eval.py` |
| REQ-ML-05 | SHAP explanations, global and per customer | 2.2 obj. 3, 7.1 | 10 | `tests/test_explain.py` |
| REQ-ML-06 | Model registry, approval, batch scoring | 8.1, 8.2 | 10 | `tests/test_registry_predictions.py`, `tests/test_mlflow_mirror.py` |
| REQ-ML-07 | Lifecycle with promotion gates; MLflow as the registry | 8.1 | 10 | — |
| REQ-SIG-01 | Sentiment from a model that runs locally | 3.1 | 8 (Sentiment, Feature adoption) | — |
| REQ-SIG-02 | Feature adoption against a governed catalogue | 3.1 | 8 | — |
| REQ-SIG-03 | Identity mapping and daily active users | 3.1 | 8 | `tests/test_annotations.py` |
| REQ-SIG-04 | History of customer attributes | 3.1, 3.2 | 8 | — |
| REQ-AN-01 | Churn overview, cohorts, survival | 2.1, 4.1, 4.2 | 3 (Performance) | `tests/test_analytics.py` |
| REQ-ACT-01 | Retention playbooks by risk and value | 9.1–9.3 | 35 (CRM, Reverse ETL, Email, SMS, Push) | `tests/test_retention_actions.py` |
| REQ-ACT-02 | Scores and actions written back to business systems | 2.2 obj. 4, 8.2 | 35 | `tests/test_destinations_snowflake.py`, `tests/test_export_record.py`, `tests/test_failed_first_record_does_not_advance_watermark.py`, `tests/test_tenant_id_prevents_crm_collisions.py`, `tests/test_export_outbox.py` |
| REQ-ACT-03 | Retention experiments and uplift | 10 | 35 | `tests/test_experiments_uplift.py` |
| REQ-ACT-04 | CRM OAuth, CRM events, reviewed reverse-ETL syncs | 2.2 obj. 4, 8.2 | 35 | `tests/test_crm_oauth.py`, `tests/test_reverse_etl.py` |
| REQ-ACT-05 | E-mail, text message, push and in-app messages | 9.2, 9.3 | 35 | `tests/test_outbound.py` |
| REQ-OPS-01 | Database lifecycle on SQLite and PostgreSQL | 8.2 | 16 (Airflow, Operations, Deployment, Performance) | `tests/test_migrations.py` |
| REQ-OPS-02 | Background jobs | 8.1 | 16 | `tests/test_jobs_worker.py` |
| REQ-OPS-03 | Drift, performance monitoring, alerts, retraining | 8.3 | 16 | `tests/test_monitoring.py` |
| REQ-OPS-04 | Nightly pipeline | 8.1 | 16 | `tests/test_pipeline.py` |
| REQ-OPS-05 | Operable API | — | 16 | — |
| REQ-OPS-06 | Usable product: CLI, demo data, web application | 1 | 16 | `tests/e2e/test_ui.py` |
| REQ-OPS-07 | The nightly work driven step by step by an orchestrator | 8.1 | 16 | — |
| REQ-SEC-01 | Authentication and sessions | — | 20 (Security, Privacy, SSO) | `tests/test_security_platform.py` |
| REQ-SEC-02 | Role-based access control | — | 20 | `tests/test_api.py` |
| REQ-SEC-03 | Tamper-evident audit trail | — | 20 | `tests/test_audit_policies.py` |
| REQ-SEC-04 | Tenant isolation | — | 20 | the tenant fixtures, every API test |
| REQ-SEC-05 | Safe outbound requests | 8.2 | 20 | `tests/test_outbound.py` |
| REQ-SEC-06 | Hardening of the HTTP surface and of configuration | — | 20 | — |
| REQ-SEC-07 | Shared request limits, trusted proxies, session rotation | — | 20 | — |
| REQ-SEC-08 | Single sign-on with OpenID Connect | — | 20 | — |
| REQ-GOV-01 | Four-eyes control over decisions that steer money or contact | 6.3, 9.1 | 6 (Governance, Privacy) | — |
| REQ-QA-01 | Every requirement is tied to passing tests, and the tie is checked | — | 6 (Release, Regression) | `tests/test_release_validator_rejects_stale_evidence.py` |

## What this table is and is not

**It is** a map from the brief's numbering to the register's areas and to the modules a reader can run. Every module in
the last column exists and passes at the release commit.

**It is not** a claim that each requirement is met. Several of the families above contain register entries that are
PARTIAL, BLOCKED or NOT_IMPLEMENTED, and the module listed against a family may cover only the part of it that exists.
The per-requirement verdict is the register's, and the matrix lists explicitly which of the 38 are named by no test at
all — twenty-one of thirty-eight are named by at least one, and the seventeen that are not are the honest gap between
"the brief asked" and "a test would catch it".

## The parts of the brief this release did not reach

Named here so that "PDF compliant" is never read as "the brief is done":

1. **Destinations that a vendor has never accepted.** Snowflake, Zendesk and Marketo are implemented and unproven
   (GATE 12). So are the CRM adapters (GATE 9), the message providers (GATES 10, 11) and single sign-on (GATE 9).
2. **The delivery layer is not reachable from the product** (R-98): no route, no job handler, no screen.
3. **APNs and FCM push** are represented by the notification abstraction but were never driven against Apple's or
   Google's service; `h2` is absent from `requirements.lock`, which the APNs milestone would require.
4. **Airflow** is represented by a DAG and an orchestration service with its own tests; no Airflow instance was run, and
   the package is not in the lock file.
5. **A labelled, non-synthetic data set** does not exist here (GATE 13), so no accuracy figure in this repository is
   evidence about a real portfolio.
6. **Enterprise items the brief asks for and this release does not attempt**: a penetration test (GATE 14), a
   production load test on the customer's hardware (GATE 15), and any vendor contract.

## The verdict, in one paragraph

The brief's capabilities are implemented in a single installation that can be stood up, seeded, migrated and exercised
end to end on one machine, and 653 tests pass twice at the release commit. That is **LOCALLY VERIFIED** and, for the
platform's own components, **INTEGRATION VERIFIED**. It is **PDF COMPLIANT for the parts that a test names**, and the
parts that no test names are listed above. It is **not PRODUCTION ACCEPTED**, for the reasons
`docs/1_3_0_PRODUCTION_ACCEPTANCE.md` sets out one by one, and no document in this release says otherwise.
