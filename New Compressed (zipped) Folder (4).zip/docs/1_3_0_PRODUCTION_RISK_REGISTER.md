# 1.3.0 — production risk register

The risks that decide whether this release is worth anything, ranked by what they would cost if they came true. Each
has a mitigation that is either in this release or explicitly not, and an owner. A risk with no owner is a wish.

| # | Risk | Likelihood | Effect | Mitigation in 1.3.0 | Owner | State |
|---|---|---|---|---|---|---|
| 1 | **A capability is claimed because the code exists, not because it was run.** The 1.2.0 backup command is the proof: it was present, tested against SQLite, and could not have backed up PostgreSQL at all | high if unmanaged | the release is fiction and the first production incident finds out | every PASS carries `verified_at`; `build_1_3_0_register.py --release` refuses a PASS verified at another commit; each new capability is proven on the engine or provider it will actually face, or marked BLOCKED | engineering | **in force** |
| 2 | **Vendor acceptance is impossible here**, and a release that quietly dresses a stand-in as a vendor | certain | a false green that no reviewer can see | the stand-in is named as a stand-in in every document; GATEs 11–13 stay BLOCKED with the exact dependency; no document uses the words "accepted by" for anything a vendor has not answered | engineering | **unavoidable, mitigated** |
| 3 | **Synthetic data is presented as model performance** | medium | decisions made on numbers that describe nothing | the evaluation keeps synthetic and real results in separate reports; the annotation batch carries whether its text is synthetic and the evaluation inherits it; R-27, R-51, R-80, R-81 stay BLOCKED until authorised data exists | data science + owner | **mitigated** |
| 4 | **Deliverability semantics are wrong**: a queued message read as delivered, a push accepted read as read | high in most systems | customers not contacted while the dashboard is green | the delivery state machine distinguishes QUEUED, SUBMITTED, ACCEPTED, DELIVERED, FAILED, UNKNOWN, and no screen or report collapses them (R-23, R-66, R-70) | engineering | **being built (M4–M6)** |
| 5 | **Privacy deletion is incomplete**: a customer is "deleted" while their rows survive in features, predictions, exports and provider systems | medium | a legal problem, not an engineering one | discovery across every store, a residual-data test, external deletion requests, and legal-hold handling (R-71..R-73, R-88) | engineering + owner | **being built (M7)** |
| 6 | **Two schedulers fight over the same batch** after Airflow is introduced | medium | duplicated CRM writes and notifications | one orchestration authority enforced by configuration and by a test that the application scheduler refuses a batch Airflow owns (R-75) | engineering | **being built (M8)** |
| 7 | **The model registry forks**: MLflow plus an application-side registry drifting apart | medium | two answers to "what is in production" | MLflow is the authority; the application stores references only; promotion and rollback go through it (R-77) | engineering | **being built (M9)** |
| 8 | **Retraining promotes itself** on a bad night of drift | medium | a worse model in production, silently | a retrain produces a candidate; promotion needs leakage validation, evaluation, calibration, a threshold, an approval and an auditable decision (R-79) | engineering + owner | **being built (M12)** |
| 9 | **The performance numbers are believed too much**: closed-loop figures from a 2 vCPU box read as capacity planning | high | a system sized on a number that describes a laptop | every figure printed with its hardware, its data set and what it cannot say; GATE 9 stays BLOCKED until a staging host exists (R-50, R-86) | engineering + owner | **mitigated** |
| 10 | **The environment resets**: interpreters, packages, database and browser disappear between sessions, and stale evidence is reused | certain (it happened twice) | results attributed to a machine state that no longer exists | the audit records the reset; evidence is regenerated on the current host; the register's `verified_at` makes the reuse visible instead of invisible | engineering | **in force** |
| 11 | **The register drifts from the documents again**, as it did in 1.2.0 (five disagreements) | medium | readers stop trusting any of it | counts and the gate table are generated from one JSON file; `--check` fails the build on a mismatch; `docs/1_2_0_RECONCILIATION.md` records the last five | engineering | **in force** |
| 12 | **Secret leakage through new provider integrations**: nine connector types, each with credentials | medium | a credential in a repository or a log | secrets only from the environment or a secret store; `scripts/scan_secrets.py` gains the new vendor key shapes; no credential in an example, a test or a document | engineering | **being built (M4–M6)** |
| 13 | **Open-redirect and token leakage through click tracking** | medium | the platform becomes a phishing relay | signed, expiring redirect links, destination allowlist, no customer identifier in the URL (R-65) | engineering | **being built (M4)** |
| 14 | **Penetration test and business approval never happen**, so the release is never accepted | high | the system is never actually approved for production | stated as BLOCKED with the owner named (GATE 15); the release claims local verification only | system owner | **external** |
| 15 | **Scope grows until nothing finishes**: 33 new requirements, 17 DAGs, 16 screens, 9 connectors | high | a half-built release that passes nothing | the register is the scope; a milestone is done only when its tests and documents exist; anything not finished stays NOT_IMPLEMENTED and is reported as such rather than described as nearly done | engineering | **in force** |

## The two that matter most

**Risk 1 and risk 2 together** are the failure mode this whole exercise exists to prevent: a system that reports
success it never observed. Every design decision in the register — the `verified_at` field, the `--release` check, the
generated counts, the refusal of the words "accepted" and "live" for anything unproven — is there because a human
reading a report cannot tell a real green from a plausible one, and a machine can.

## What would change this register

Finding a defect in a claimed-PASS capability (that is what happened in 1.2.0 with `pg_dump`); a vendor account
arriving (which converts BLOCKED rows into PASS or FAIL); an owner setting thresholds (which turns performance from a
measurement into a verdict); and any environment change, which invalidates every `verified_at` at once.
