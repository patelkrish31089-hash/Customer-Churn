# 1.2.0 — feature adoption report

The master prompt for 1.2.0 says adoption "does not calculate adoption against an eligible feature catalogue". The
audit found that it does (`docs/1_2_0_BASELINE_AUDIT.md`, §2), and this report records what was checked rather than
what was built — the honest version of that item is *verification*, and it is why M3 in the plan is a VERIFY
milestone.

## What exists, and what it refuses to do

| Rule | Where | How it is held |
|---|---|---|
| A catalogue entry is versioned and only counts after a second person approved it | `services/adoption.py` (`create_feature`, `submit`, `review`) | `tests/test_signals.py::test_catalogue_entries_are_versioned_and_count_only_after_a_second_person_approved_them` — an author cannot approve their own entry (`self_approval_forbidden`), a draft has no effect, a new version replaces the old only once approved |
| Two entries may not claim the same telemetry | `mapping_conflicts` | same test: the clash is refused with `mapping_conflict` naming both entries |
| The denominator is "features this customer could use at that date" | `feature_engine.AdoptionGrid` | `test_adoption_rate_has_an_explicit_denominator_and_follows_the_catalogue_rules` |
| A feature released after the date is not in that date's denominator | catalogue release dates | the same test: 2 of 2 before the release, 2 of 3 after |
| Plan gating changes the denominator | `eligibility.plan_tiers` | the same test (a `basic` customer is not offered an `enterprise` feature) and the report test (`automation` has fewer eligible customers than `dashboards`) |
| A rate with an empty denominator is *missing*, never zero | the grid returns a missing sentinel | the same test: no catalogue → every rate missing; a catalogue with nothing eligible → missing; a customer who used nothing → 0.0, which is a fact |
| Raw breadth is not adoption | `distinct_features_30d` vs the governed rate | the same test: 3 distinct names in telemetry, a governed rate of 2/3 |
| The adoption rule is per entry (events *and* distinct days) | `adoption_rule` | the same test: one event on one day is not adoption for `reports` |
| Telemetry that maps to nothing is named, not silently dropped | `unmapped_telemetry` | the report test: `legacy_export` with its event count |
| An entry whose telemetry never arrives is in nobody's denominator | `mapping_state` | the report test: `api_access` is `never_seen_in_telemetry`, 0 eligible customers, `invalid_mapping` facts equal to the customers measured |
| The report and the model agree | `fe.compute_features` on the same frames | the report test: the report's `mean_adoption_rate` equals the mean of the `feature_adoption_rate_30d` column |
| Segments: plan tier and tenure | `result["segments"]` | the report test |
| New and abandoned within the window | `is_new`, `is_abandoned`, `new_adopters`, `abandoned` | computed in `adoption.compute`, returned per feature |
| Point-in-time: an earlier as-of date is a second trend point | `start_run(as_of=...)` | the report test: `2026-03-01` and `2026-11-01`, and the later feature is in the earlier denominator only if it had been released |

Counts asserted on the reference demo: 8 catalogue entries, of which `api_access` has no telemetry; adoption facts for
every measured customer; the arithmetic of the report equal to the arithmetic of the feature vectors to 1e-4.

## What remains PARTIAL (register R-30)

Three things the master prompt lists are **not** present, and they stay named rather than glossed:

1. **Account-level aggregation policy.** Adoption is computed per customer. Where several users share an account
   (the seeded tenant has them — see `docs/SIGNALS.md`), a policy that says how their use adds up to the account's
   adoption is not implemented and not configurable.
2. **User-level adoption as its own view.** Usage carries an external user id and identity links exist, but adoption
   is not reported per user.
3. **Adoption velocity and time to first use.** The delta against the previous 30 days is a feature
   (`feature_adoption_delta_30d_prev30d`) and new/abandoned flags exist; velocity as a series and time-to-first-use
   per feature are not computed.

These are the M3 EXTEND items. They are additions to a working, verified calculation, not repairs to a broken one,
and the register says exactly that.

## Not claimed

Nothing in this report is evidence about a real customer base. Every figure quoted above comes from the synthetic
reference demo, and the product labels it so wherever the number appears.
