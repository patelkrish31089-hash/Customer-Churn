# Baseline before the 1.1.0 enhancement

What the platform was, measurably, before any 1.1.0 change. Everything 1.1.0 claims is a difference from this
state; the regression report ([EXISTING_FEATURE_HEALTH_REPORT.md](EXISTING_FEATURE_HEALTH_REPORT.md)) compares
against it.

## The release that was the starting point

| | |
|---|---|
| Release | 1.0.1, tag `v1.0.1`, commit `a5a21ad` |
| Archive | `churn-platform-1.0.1.zip`, SHA-256 `346c08383d2715356351eb2f4cc652ea110ef5c89e81fba80deb0dabf3291de4` |
| Test suite | 418 tests |
| Requirements | 28, each with at least one passing test (28 of 28) |
| Database schema | one migration (`0001`) |
| HTTP API | 114 operations under `/api/v1` |
| Feature catalogue | 69 features |
| Nightly pipeline | six steps: data quality, labels, features, scoring, recommendations, monitoring |

## The baseline run

Before the first 1.1.0 change the whole suite was run once more on the unchanged 1.0.1 commit, on the machine and
in the configuration used for 1.1.0 (Python 3.12.16, strict mode: nothing may be skipped, PostgreSQL available):

**418 passed in 415.92 seconds.**

The output and the JUnit report are in the release evidence (`baseline/suite_at_v1.0.1.txt`,
`baseline/junit_at_v1.0.1.xml`). A test of 1.0.1 that fails on 1.1.0 is therefore a change made by 1.1.0, not a
difference between machines.

## What 1.0.1 did not do

Taken from the "Differences from the brief" and "Security and access" sections of the 1.0.1 limitations, and from
the two items the 1.0.1 runs showed and did not change. These are the gaps the 1.1.0 work started from; what became
of each is in [MISSING_FEATURE_REGISTER.md](MISSING_FEATURE_REGISTER.md).

| Area | State in 1.0.1 |
|---|---|
| Sentiment | Share of support tickets containing a word from an English negative-word list. No trained model, no other language. |
| Feature adoption | Number of distinct product features used. Not a rate: the platform did not know the product's feature list. |
| Daily active users | Counted raw user references on usage events. No mapping from identifiers to people. |
| Customer attributes | Industry, size and region used as they are today, also for past dates. |
| MLflow | Received a copy of each registered version. Changing anything in MLflow changed nothing in the platform. |
| Orchestration | The nightly chain ran on the platform's scheduler. The Airflow DAG started the whole chain as one task and watched it. |
| CRM | A pasted access token, never renewed. No OAuth, no events from the CRM, no reverse ETL. |
| E-mail, SMS, push | Not sent. The platform decided on an action and handed it to the CRM. |
| Single sign-on | None. Local accounts with optional one-time codes. |
| Request limits | Counted per server process: with two processes, 60 sign-in attempts a minute got through where 30 were configured. |
| Transport security header | `Strict-Transport-Security` was sent to any client that claimed `X-Forwarded-Proto: https` (found while preparing 1.1.0; DEF-068). |
| Forwarded client address | Believed from the peers named with `serve --forwarded-allow-ips`, by default every client on the server's own machine (found while preparing 1.1.0; DEF-082). |

## What was already there and had to keep working

Ingestion of ten entities with mapping, validation and quarantine; churn labels under a versioned definition; the
point-in-time feature store with contracts; cohort and survival analytics; training of four algorithms with
time-ordered cross-validation and calibration; evaluation with a cost-based threshold and a test split that can be
used once; SHAP explanations; the model registry with four-eyes approval; nightly batch scoring and CSV export;
retention playbooks, recommendations, execution and outcomes; CRM hand-over to Salesforce, HubSpot and Intercom;
experiments and uplift models; drift monitoring, alerts and retraining candidates; the job queue and worker; eight
roles, one-time codes, the hash-chained audit trail and tenant isolation; the web interface; the release tooling
(traceability matrix, manifest, wheel check).
