# 1.2.0 — notification delivery

## What changed in 1.2.0

**Quiet hours (M6).** Marketing messages are held outside the configured window and released at its end; they are
never dropped, and a transactional message is not held at all. `CHURN_NOTIFY_QUIET_HOURS=21:00-08:00` and
`CHURN_NOTIFY_QUIET_TIMEZONE=Europe/Berlin`; a window may wrap midnight. A misconfigured window or an unknown time
zone is a loud validation failure, not a silent no-op — an installation that believes it is quiet while it is not is
worse than one that has the rule switched off.

Held messages keep a delivery job scheduled for the end of the window (`next_attempt_at` = window end,
`status_reason` = "quiet hours: held until …"), which is the same mechanism the retry path uses, so the message
survives a restart of the worker.

**Evidence**: `tests/test_outbound.py::test_a_marketing_message_outside_the_quiet_hours_is_held_and_released_rather_than_dropped`
— a window containing "now", whatever hour the suite runs; the marketing message is `queued` with a future
`next_attempt_at` and never reaches the mail server; a transactional message is not held; four malformed windows and
an unknown time zone are refused with the field named; with the window off, the same message is delivered and the
server receives it once.

## The delivery vocabulary, and what it does and does not mean

| State in the database | Means | Does **not** mean |
|---|---|---|
| `queued` | accepted by the platform, waiting for the worker (or held by quiet hours) | sent |
| `dry_run` | the request was built and checked; nothing left the process | sent, accepted, delivered |
| `sent` | the provider accepted it (an HTTP 2xx, an SMTP 250, or the in-app inbox) | delivered to a person |
| `delivered` | the provider's signed event says so | read |
| `bounced` / `complained` | the provider's signed event says so | — |
| `blocked` / `suppressed` / `cancelled` | the platform refused before any request was made, with the reason on the row | sent |
| `failed` | the provider refused, or the attempt ran out | sent |

The gap the master prompt is pointing at — `SENT_TO_PROVIDER` versus `ACCEPTED` versus `UNKNOWN` — is **not yet
modelled as separate states**. Today `sent` means "accepted by the provider" and there is no state for "we asked and
we do not know". Splitting it is schema work over `notification_messages` and every campaign report; it is on the
register as part of R-23 (PARTIAL) and is not claimed as done.

## What is still blocked

| Channel | Local state | Vendor acceptance |
|---|---|---|
| E-mail over SMTP | proven against a real mail server (73 of 73 accepted, 1.1.1 evidence) | — |
| E-mail through SendGrid / SES | adapter and request shape, sandbox flags | BLOCKED — no account |
| SMS through Twilio | adapter, consent, opt-out, suppression; no status callback ever received from Twilio | BLOCKED — no account |
| Push through FCM | adapter with `validate_only` and topics | BLOCKED — no Firebase project |
| Push through APNs | payload built; **no HTTP/2 client, so nothing can be sent** | NOT_IMPLEMENTED locally; BLOCKED at Apple |

No message has ever been delivered to a real person by this installation, and nothing in this release says otherwise.
