# 1.3.0 — test baseline

The number this document exists to make unambiguous: **653 tests, 653 passed, 0 failed, 0 errors, 0 skipped**, run
twice at the same commit. The 1.2.0 baseline was 498; the 1.3.0 work added 155, of which 95 are the tests written while
fixing the four defects (and of those, 88 are in the four regression modules and the outbox module).

Nothing in this document is carried over from an earlier release: every figure below was produced by a run on this
machine, and the JUnit files are named.

## The suite of record

| | Run 1 | Run 2 |
|---|---|---|
| command | `python3 -m pytest -q --junitxml=/var/tmp/release/final-a.xml` | same |
| commit | `0b81cad` | `1bee719` |
| started | 2026-11-13T08:33:33Z | 2026-11-13T08:41:21Z |
| result | **653 passed** | **653 passed** |
| duration | 481.21 s | 462.09 s |
| failed / errored / skipped | 0 / 0 / 0 | 0 / 0 / 0 |
| interpreter | CPython 3.13.18 | CPython 3.13.18 |
| database | SQLite (per test) + PostgreSQL 17.11 for the migration tests | same |
| mode | `CHURN_TEST_STRICT=1` | `CHURN_TEST_STRICT=1` |

The two runs differ in one respect, and it is recorded rather than smoothed over: run 1 was made while two documents
were being edited in the working tree (`working_tree_clean: false, working_tree_dirty_paths: 2` in
`final-a.xml.meta.json` — the implementation report and the register-update script, neither of which is source or test
code), and run 2 was made on a clean tree at the commit that included them. Run 1 is kept because it is the run that
first reached 653 passed; run 2 is the one whose sidecar says the tree was clean. **A third run at the final commit is
recorded in `docs/1_3_0_FINAL_TEST_REPORT.md`**, which is the pair used as release evidence.

## What the environment was

| Component | Version / setting | Why it matters |
|---|---|---|
| Python | 3.13.18 | the interpreter the runs used |
| PostgreSQL | 17.11 (`127.0.0.1:5432/churn_test`) | migration `0005` and the migration cycle are exercised against it |
| Playwright | Chromium, installed with `python3 -m playwright install chromium` plus `install-deps` | the browser tests run a real Chromium against the FastAPI-served application |
| sentiment model | `/var/tmp/sentiment-models/models/sentiment/nlptown-multilingual` | the transformer test needs it; strict mode fails rather than skips when it is missing |
| `CHURN_TEST_TEMPLATE_DIR` | `/var/tmp/churn_test_template` | the seeded template is built once and reused while the source fingerprint is unchanged |
| `CHURN_TEST_STRICT=1` | on | a missing prerequisite fails; a skip is not a pass |

The exact command, for reproduction:

```
TMPDIR=/var/tmp/churn-tmp \
CHURN_TEST_TEMPLATE_DIR=/var/tmp/churn_test_template \
CHURN_TEST_STRICT=1 \
CHURN_TEST_POSTGRES_URL=postgresql+psycopg://churn:churn_local_dev@127.0.0.1:5432/churn_test \
CHURN_TEST_SENTIMENT_MODEL_DIR=/var/tmp/sentiment-models/models/sentiment \
python3 -m pytest -q --junitxml=release/run.xml
```

## Where the 155 new tests are

| Module | Tests | What it holds |
|---|---|---|
| `tests/test_export_record.py` | 30 | the canonical record: 20 fields, refusals, checksum, building from the stored rows |
| `tests/test_destinations_snowflake.py` | 17 | the shared pipeline and the Snowflake statements |
| `tests/test_register_130.py` | 13 | the register tool: ids, statuses, evidence rules, the gates, the counts |
| `tests/test_schema_mismatch_fails_validation.py` | 29 | defect 2: the session read-back, identifiers, TLS |
| `tests/test_release_validator_rejects_stale_evidence.py` | 21 | defect 4: the register against the tree, JUnit evidence, the two-run comparison |
| `tests/test_failed_first_record_does_not_advance_watermark.py` | 15 | defect 1: per-record outcomes, the contiguous watermark, the checksum, resume |
| `tests/test_tenant_id_prevents_crm_collisions.py` | 14 | defect 3: the tenant in the record, the identity and the MERGE |
| `tests/test_export_outbox.py` | 13 | migration `0005`, the run record, the checkpoint, resume, PostgreSQL |

## The carried baseline

The 498 tests of 1.2.0 are unchanged and all of them passed in both runs. Nothing was deleted, renamed away from its
requirement, weakened, converted to a skip or re-pointed at a mock. The three places where a 1.3.0 change forced an
existing test to move are:

1. `tests/test_export_record.py` and `tests/test_destinations_snowflake.py` needed `tenant_id` in their fixtures once
   the record required one, and their assertions on the DDL, the MERGE and the identity were updated to the quoted,
   tenant-led forms — sixteen assertions became stricter, none looser;
2. `tests/test_destinations_snowflake.py`'s delivery-failure test now asserts a `FAILED` outcome with its error code
   instead of a quarantine, because a delivery failure is no longer reported as a validation refusal;
3. `tests/test_traceability_tool.py` required a file-level `pytestmark` on the new modules, which they have
   (`REQ-ACT-02` for the delivery work, `REQ-QA-01` for the release validator).

## What is not covered by these numbers

- The suite is a single-machine suite: SQLite for most tests, PostgreSQL for the migration and outbox tests, one Chromium
  for the browser tests. No other browser, database or operating system was used.
- No test contacts a vendor. Every destination test uses a stand-in, named as one; the gates that need a vendor are
  BLOCKED and say which vendor.
- The sentiment transformer test needs a model directory that is not in the repository; under strict mode its absence
  fails the run rather than skipping, and this run had the model.
- Performance is not measured here; the only load figures in the project are 1.2.0's, on 2 vCPU / 2 GB.
