# 1.2.0 — CRM acceptance

**No vendor has accepted a single request from this software.** This document is the script that settles that, and
the record of how much of it can be settled without an account. It exists so that the first sandbox run is a
half-hour of somebody's time and not a debugging session.

## What can be proven here, and was

Four checks run in this repository, at this commit, without a vendor account:

| Check | Command | Result |
|---|---|---|
| Shape of every request against the vendor's own published description | `python scripts/check_crm_contracts.py` | **4 of 4 conform** — HubSpot `PATCH /crm/v3/objects/companies/{id}`, HubSpot `POST /crm/v3/objects/tasks`, Intercom `POST /companies` (risk score), Intercom `POST /companies` (recommended action). Two notes on Intercom's own example disagreeing with its declared property value type |
| The same checker applied to the requests the connectors actually build | `tests/test_crm.py::test_the_contract_checker_runs_on_the_requests_the_connectors_build` | passing |
| An authenticated, idempotent sync against a local stand-in that answers like the vendor | `tests/test_crm.py::test_sandbox_sync_sends_authenticated_idempotent_requests_to_the_vetted_address` | passing |
| Every documented failure shape (429, 500, 400 with an error body, a timeout) mapped to the right delivery outcome, with retries, backoff and parking | `tests/test_crm.py::test_transient_failures_are_retried_with_backoff_and_then_parked`, `::test_delivery_outcome_by_vendor_response` | passing |

Two things that check does **not** show, and the report must not imply: a real account may reject a request because
a custom property does not exist there or the token lacks a scope, and a published description can lag the running
service.

## The twelve steps a sandbox run must perform

Each row: what to do, what proves it, and where the platform stands. "Local" means proven here against the
stand-in; "sandbox" means only a real account can prove it.

| # | Step | Proves | State |
|---|---|---|---|
| 1 | Create the connection with a sandbox token, `mode = TEST_ONLY` | credentials are accepted and stored encrypted, and nothing is sent | **local** — `test_connection_rules_and_secrets_at_rest` |
| 2 | Turn on `TEST_ONLY` build: every request is built, printed, and not sent | the requests are what the operator expects before anything leaves | **local** — `test_seeded_test_only_sync_built_every_request_and_sent_nothing` |
| 3 | Switch to `LIVE` and sync one company | the vendor accepts our `PATCH` and the custom properties exist | **sandbox only** |
| 4 | Sync the same company again | our idempotency key makes the second call a no-op at the vendor rather than a duplicate | **local** (key sent, asserted); vendor behaviour **sandbox only** |
| 5 | Execute a recommendation | a task lands on the right record with the right `What` | **sandbox only** (`test_executing_a_recommendation_through_a_connection_queues_a_crm_task` proves we queue the right thing) |
| 6 | Feed back a 429 | we back off, respect `Retry-After`, and do not lose the delivery | **local** — `test_transient_failures_are_retried_with_backoff_and_then_parked` |
| 7 | Feed back a 500 and a timeout | same, and a persistent failure parks with the vendor's answer recorded | **local** |
| 8 | Feed back a 400 with an error body | the message reaches the operator verbatim; nothing is retried that cannot succeed | **local** — `test_delivery_outcome_by_vendor_response` |
| 9 | Point the connection at a host that resolves internally | it is refused at send time, not only at setup | **local** — `test_a_host_that_turns_internal_after_setup_is_refused_at_send_time` |
| 10 | Check the audit trail of the sync | every attempt, its outcome and the vendor's response are recorded and tenant-scoped | **local** — `test_connections_and_deliveries_are_tenant_scoped` |
| 11 | Repeat 1–10 for the second and third adapter | the contract is provider-neutral, not a HubSpot-shaped special case | **sandbox only** |
| 12 | Rotate the token, revoke a scope, retry | the failure is a clear permission error, not a crash | **sandbox only** |

**Proven without an account: 8 of 12 steps (1, 2, 4-partially, 6, 7, 8, 9, 10). Remaining: 4 — steps 3, 5, 11, 12,
all of which require an account whose owner lets it receive writes.**

## The exact remaining dependency

One sandbox account per vendor (Salesforce developer org, HubSpot developer test account, Intercom app with a test
workspace), each with a token that may write companies and tasks, plus a person authorised to write two synthetic
companies into it. Nothing else is missing on this side: `docs/CRM_SETUP.md` has the setup, the checker has the
shape, the stand-in has the behaviour, and the register row (R-01..R-03) turns from BLOCKED to PASS-or-FAIL the day
those credentials exist — FAIL included, which is the point of running it.
