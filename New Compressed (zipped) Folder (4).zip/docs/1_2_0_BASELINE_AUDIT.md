# 1.2.0 — baseline audit

What this is: the state of the product at the release 1.1.1 tag, established by reading the source and running it,
**before** any 1.2.0 change. Every statement below is either a path in the repository, a command that was run, or a
test that passed on commit `443aa03`. Nothing here is carried over from a plan or from the master prompt's
description of the product: where the two disagree, this file follows the code, and the disagreement is recorded.

- Source: `main` at `443aa03`, tag `v1.1.1`, working tree clean.
- Test baseline: 493 passed, strict mode, PostgreSQL, Python 3.12.16 / 3.11.18 / 3.13.16 (613 s / 667 s / 683 s).
- Document tests: 27 passed on each interpreter. Traceability: 38 of 38 requirements.
- Release archive: `churn-platform-1.1.1.zip`, 163 files, sha256 `df9c0671…`.

## 1. Shape of the system

| Part | Where | Size |
|---|---|---|
| Python | `src/churn_platform` | 38,642 lines across 79 modules (services, models, api, worker, migrations) |
| Browser interface | `src/churn_platform/web/` (no build step, vanilla ES modules) | one application, served by FastAPI |
| Tests | `tests/` | 35 files, 493 tests, plus `tests/e2e` driving Chromium |
| Migrations | `migrations/versions/` | `0001_baseline`, `0002_signals_platform`, `0003_smtp_provider` |
| Orchestration | `deploy/airflow/churn_nightly_dag.py` + `services/orchestration.py` | one DAG, seven steps per tenant, 02:00, `CHURN_ORCHESTRATOR` decides who fires |
| CI | `.github/workflows/ci.yml` | 5 jobs, local-runner verified, never run on GitHub (KRI-6) |

## 2. What the master prompt calls "partial" or "missing", checked against the code

| Item | Prompt's premise | Actual state at `443aa03` | Evidence |
|---|---|---|---|
| Feature adoption | "does not calculate adoption against an eligible catalogue" | **Already built.** `services/adoption.py` has a governed, versioned catalogue (`ProductFeature`: release/retire dates, plan tiers, telemetry mappings, availability) with approval; `feature_engine.AdoptionGrid` computes adopted / not adopted / not eligible / unknown / missing telemetry, 7- and 30-day and as-of windows, and rates with an explicit denominator that are *missing* (never 0) when nothing is eligible | `tests/test_features_pit.py`, `tests/test_analytics.py` |
| Sentiment | "negative-word list presented as a model" | **Already a model.** `services/sentiment.py`: local multilingual transformer (ONNX, pinned revision + SHA-256), a word-list baseline kept only as a labelled fallback, text preparation (Unicode, PII redaction, language detection), per-interaction storage with model identity, and an `evaluate()` that reports accuracy per label and per language with the result marked *not measured* until run | `tests/test_analytics.py`, `docs/SIGNALS.md` |
| Distributed rate limiting | "needs Redis" | **Already shared across processes**, in the database (`rate_limit_counters`, one row per bucket/subject/minute, atomic upsert, `CHURN_RATE_LIMIT_STORE_FAILURE` = `local` or `deny`), with tests driving two server processes | `services/ratelimit.py`, `tests/test_security.py` |
| Airflow | "only a local sequential test runner" | **A real DAG** with retries, backoff, `execution_timeout`, `max_active_runs=1`, a migration check as the first task, dependency chain, and a `pipeline-step` command that is idempotent per (dag_run, task). Run on Airflow 3.4.0 and 2.11.2 under a scheduler with LocalExecutor | `deploy/airflow/`, `docs/ORCHESTRATION.md` |
| MLflow | "local only" | Local server plus an authenticated remote **is** configurable (`CHURN_MLFLOW_TRACKING_URI`, token); the remote registry round trip has not been performed | `services/mlflow_mirror.py`, `tests/test_mlflow_mirror.py` |
| CRM | "adapters exist, no acceptance" | Three provider adapters (Salesforce, HubSpot, Intercom) whose request shapes are checked against the vendors' published descriptions and reach the vendors' live hosts (401 on a bad token). Driven end to end — 85 of 85 writes, signed events, replay/stale/tampered refusals, revocation — against a CRM implementing HubSpot's rules on this machine. **No vendor account has accepted anything** | `docs/CRM_SETUP.md`, `release-evidence/1.1.1/crm/` |
| Messaging | "no vendor accepted a message" | SendGrid, SES, Twilio, FCM adapters; SMTP added in 1.1.1 and proven against a real mail server (73 of 73 accepted). No messaging vendor account, no APNs (HTTP/2 absent) | `services/notify.py`, `release-evidence/1.1.1/messages/` |
| SSO | "stub only" | Keycloak 26.0 proved the whole flow — browser and API, discovery, PKCE S256, state, claims, groups→roles, MFA rule, all refusal codes. No hosted provider; SAML absent | `services/sso.py`, `release-evidence/1.1.1/sso/` |

Consequence for the plan: four of the prompt's "gaps" (adoption, sentiment, rate limiting, Airflow) are already
implemented and tested. Work there is **verification and extension**, not construction — and the register says so
rather than counting them as new work.

## 3. What is genuinely absent (verified by search, not assumed)

| Area | Finding | Files searched |
|---|---|---|
| Snowflake / analytical destinations | no adapter, no dialect handling | `grep -ri snowflake src` → 0 |
| Marketo, Zendesk, Hightouch, Census | nothing | `grep -riE "marketo\|zendesk\|hightouch\|census" src` → 0 |
| SAML | nothing | → 0 |
| Redis | nothing (the database is the shared counter store instead) | → 0 |
| APNs | payload built and rehearsed; HTTP/2 client absent, so it cannot send | `services/notify.py` |
| Device-token management | no `device_token` table or endpoint | `grep -ri device_token` → 0 |
| Annotation workflow for sentiment | no annotator, disagreement or export flow | `grep -riE "annotat"` → 0 |
| Quiet hours | no setting or check | → 0 |
| Open / click tracking | nothing | → 0 |
| Customer-data deletion | no deletion workflow (audit retention only) | → 0 |
| Backup / restore automation | no `pg_dump`/`pg_restore` script; a backup procedure is described in prose only | `grep -rl "pg_dump"` → 0 |
| Security tooling in CI | no Bandit, pip-audit or secret scan | `.github/workflows/ci.yml` |
| Sustained load tooling | `scripts/load_test.py` is a closed-loop httpx harness; no k6/Locust, no soak run | `scripts/load_test.py` |
| 17 Airflow DAGs (prompt) | one DAG with seven steps | `deploy/airflow/` |

## 4. What cannot be done here at all

Sandbox: 2 vCPU, 2 GB RAM, no outbound vendor credentials, no company data, no independent assessor. The following
are **BLOCKED** by definition, and no amount of code changes that: Salesforce/HubSpot/Intercom sandbox acceptance,
SendGrid/SES/Twilio/FCM/APNs acceptance with real credentials, a hosted identity provider, Snowflake account,
authorised real customer data with mature churn labels, a labelled support dataset, RPO/RTO and business
thresholds set by an owner, independent penetration testing, and a hosted staging deployment.

Each is entered in the register as BLOCKED with the exact artefact that would unblock it — never as PASS, and never
as FAIL to hide that the code may be ready.

## 5. Definition used by the 1.2.0 register

| Status | Meaning |
|---|---|
| PASS | Implemented, and current evidence (a test at this commit, or a run recorded against this commit) shows it works |
| PARTIAL | Works for some inputs, providers or paths; the missing part is named |
| FAIL | Implemented but contradicted by current evidence |
| BLOCKED | Cannot be established here: needs a credential, an account, data or a person. The code may be complete |
| NOT_IMPLEMENTED | Absent from the source |
| NOT_TESTED | Present but no test or run covers it |
| NOT_APPLICABLE | Not required of this product, with the reason |

A historical PASS never survives a change to the code it covered: the register records the commit each status was
established at, and 1.2.0 re-establishes the ones its own changes touch.
