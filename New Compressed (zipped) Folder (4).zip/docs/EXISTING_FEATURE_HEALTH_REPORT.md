# Health of the existing features after 1.1.0

1.1.0 added a seventh pipeline step, fifteen features, a migration and 77 API operations to a product that was
already released. This report says what that did to what was there before. The comparison is against the baseline
run described in [ENHANCEMENT_BASELINE.md](ENHANCEMENT_BASELINE.md): release 1.0.1, 418 tests, all passing on the
same machine.

## Result

- **All 418 tests of 1.0.1 are still in the suite under the same names, and all 418 pass on 1.1.0.** None was
  removed, renamed or skipped. The release run holds 490 tests: these 418 and 72 new ones.
- **42 of the 314 test functions behind those 418 tests were edited**, in 14 files. Every edit is one of the four
  kinds listed below. The list of edited functions is kept with the release evidence
  (`edited_existing_tests.json`), the comparison of the two test reports as `regression_against_baseline.json`.
- **Three defects were found in released behaviour** and fixed (DEF-068, DEF-069, DEF-082); one property of
  released behaviour was found and documented, not changed (ties after calibration, below).

## By area

Tests of 1.0.1 in the baseline run, the same test modules in the 1.1.0 release run (Python 3.12, strict mode,
PostgreSQL), and how many test functions of the module were edited.

| Area | Test module | Tests in 1.0.1 | Passed in 1.1.0 | Functions edited |
|---|---|---|---|---|
| Web interface (browser) | `e2e/test_ui` | 18 | 18 of 18 | 3 |
| Seeded demo tenant | `test_00_template` | 1 | 1 of 1 | 1 |
| Cohort and survival analytics | `test_analytics` | 11 | 11 of 11 | – |
| HTTP API, roles, tenant isolation | `test_api` | 28 | 28 of 28 | 10 |
| Audit trail and policies | `test_audit_policies` | 25 | 25 of 25 | – |
| Sign-in, sessions, one-time codes | `test_auth` | 12 | 12 of 12 | – |
| Command line | `test_cli` | 10 | 10 of 10 | 1 |
| CRM hand-over | `test_crm` | 29 | 29 of 29 | – |
| Experiments and uplift | `test_experiments` | 15 | 15 of 15 | 1 |
| SHAP explanations | `test_explain` | 14 | 14 of 14 | 3 |
| Feature store, point-in-time rules | `test_features_pit` | 18 | 18 of 18 | 5 |
| Ingestion and quarantine | `test_ingestion` | 19 | 19 of 19 | – |
| Job queue and worker | `test_jobs_worker` | 14 | 14 of 14 | – |
| Database migrations | `test_migrations` | 4 | 4 of 4 | – |
| MLflow copy of the registry | `test_mlflow_mirror` | 3 | 3 of 3 | 1 |
| Training data sets and leakage checks | `test_mlprep` | 12 | 12 of 12 | – |
| Drift monitoring, alerts, retraining | `test_monitoring` | 15 | 15 of 15 | 2 |
| Nightly pipeline | `test_pipeline` | 13 | 13 of 13 | 8 |
| Data quality | `test_quality` | 5 | 5 of 5 | – |
| File readers and schemas | `test_readers_schemas` | 40 | 40 of 40 | – |
| Registry, scoring, export | `test_registry_predictions` | 13 | 13 of 13 | 1 |
| Recommendations and outcomes | `test_retention` | 8 | 8 of 8 | 2 |
| Security primitives | `test_security` | 25 | 25 of 25 | – |
| Timeline and churn labels | `test_timeline_labels` | 23 | 23 of 23 | – |
| Release tooling | `test_traceability_tool` | 17 | 17 of 17 | 2 |
| Training and evaluation | `test_training_eval` | 26 | 26 of 26 | 2 |

Every module holds the same tests as in 1.0.1; the 72 new tests are in four new modules.

## Why existing tests were edited

**1. The figures of the test tenant changed, because the models now see other inputs.** The test tenant is a
seeded demo of 300 customers and many tests pin its numbers. With 84 features instead of 69 a different algorithm
wins there (XGBoost instead of logistic regression), 91 recommendations are made instead of 99, the monitoring
figures move, and reports have 15 more columns. The pinned numbers were replaced by the new ones; the assertions
around them are unchanged. Modules: `test_cli`, `test_retention`, `test_monitoring`, `test_explain`,
`test_experiments`, `test_features_pit`, `test_registry_predictions`, `test_training_eval`, `test_api`,
`e2e/test_ui`.

**2. Behaviour was changed on purpose.** Each of these is in the changelog.

| Change | Tests that state it now |
|---|---|
| The nightly pipeline has seven steps (`signals` after the data-quality checks) | `test_pipeline`, `test_cli`, `test_api`, `e2e/test_ui` |
| `Strict-Transport-Security` is no longer sent because a client claims HTTPS (DEF-068) | `test_api` |
| `GET /jobs/active` lists work in progress, not jobs dated days ahead (DEF-075) | `test_api`, `e2e/test_ui` |
| The feature catalogue knows a third point-in-time class, `history`, and a sixth snapshot feature (DEF-073) | `test_features_pit`, `test_api` |
| MLflow tags follow the lifecycle instead of freezing at registration | `test_mlflow_mirror` |
| 191 API operations and 38 requirements are listed where 114 and 28 were | `test_api`, `test_traceability_tool` |
| The isolation test tries every new route with another tenant's identifiers | `test_api` |

**3. The seeded demo leaves one job waiting.** The demo rehearses a campaign whose second step is due three days
later, so one job stays queued. Tests that asserted "no job is left" now assert "no job is left except that one".
Modules: `test_00_template`, `test_cli`, `test_pipeline`, `e2e/test_ui`.

**4. One assertion was weakened, and this is the place to say so.** `test_training_eval` asserted that
calibration leaves the ROC-AUC of a model exactly unchanged. With the new features the logistic regression of the
test tenant produces raw scores below one in a million for some customers; calibration clips those to one value,
so these customers tie and the ROC-AUC moves from 0.7120 to 0.7115. The clipping is 1.0 behaviour; the old test
data never reached it. The test now asserts what is true: calibration never reverses an order, creates no tie
where nothing was clipped, leaves the ROC-AUC unchanged there, and moves it by less than 0.005 overall. The
property is listed in [LIMITATIONS.md](LIMITATIONS.md) under *Modelling*. The clip itself was not changed: doing
so would change every probability the platform has ever shown.

## Changes an existing installation will notice

- **Models have to be retrained.** Two features kept their names and changed their meaning
  (`negative_ticket_share_90d`, `avg_daily_active_users_30d`), and five customer attributes are now read from
  their history. A model trained with 1.0 is fed values it was not trained on.
- **Behind a reverse proxy, `CHURN_TRUSTED_PROXIES` has to be set**, also for a proxy on the same machine
  (`127.0.0.1`). Without it forwarded headers are ignored: limits and session records see the proxy's address,
  and the transport-security header is not sent. `serve --forwarded-allow-ips` is refused with a message that
  names the setting.
- **Sign-in is limited per account as well as per address** (10 attempts a minute), and the limits hold across
  server processes. Exports, single predictions and CRM syncs have limits of their own; a script that scores more
  than 60 single customers a minute as one user is now refused and should use batch scoring.
- **The web application replaces its session token every hour.** A browser tab left open keeps working; a copied
  token stops working once it has been replaced.
- **The nightly run takes one step longer**, and the first run after the upgrade scores all existing support text
  once (about 2,000 texts a minute with the model, faster with the baseline).
- **Migration `0002`** adds 28 tables and 37 columns on seven existing tables; no existing column or table is
  altered or dropped. `downgrade 0001` takes all of it out again (run on SQLite for this release).

## Not re-verified for 1.1.0

Kept from 1.0.1 without being run again: the image for `linux/arm64`; the load test on PostgreSQL; the CI workflow
on a local runner; Airflow 2; the Airflow run under a scheduler with an executor. Each is listed with what was run
instead in [LIMITATIONS.md](LIMITATIONS.md).
