# 1.3.0 — integration acceptance

"Integration" here means **two or more real components exchanging real requests on this machine**: the platform's own
HTTP API, its database, its worker, its browser application, PostgreSQL, and a real Chromium. It never means a
third-party service. The word is used narrowly on purpose, because the 1.3.0 brief asks for four labels that must not be
merged — LOCALLY VERIFIED, INTEGRATION VERIFIED, PDF COMPLIANT, PRODUCTION ACCEPTED — and a vendor that was never
contacted cannot appear under any of them.

## What was exercised, and how

| Integration | How it was exercised | Where the evidence is | Verdict |
|---|---|---|---|
| Ingest → validate → store | the demo seed runs the real ingestion path (sources, jobs, worker) over the synthetic generator; the suite's template is built from it once per session | `tests/test_ingestion.py`, `tests/test_quality.py`, the template fixture in `tests/conftest.py` | **INTEGRATION VERIFIED** |
| Training → registry → approval → scoring | the seed walks labels → features → training → approval → batch scoring through the services, and the worker executes the jobs | `tests/test_registry_predictions.py`, `tests/test_training_eval.py` | **INTEGRATION VERIFIED** |
| API → database → audit trail | every API test logs in, calls a route and reads the result back; the audit chain is verified by its own test | `tests/test_api.py`, `tests/test_audit_policies.py` | **INTEGRATION VERIFIED** |
| Browser → API | a real Chromium loads the application served by FastAPI, signs in, navigates and reads screens; no mocked network | `tests/e2e/test_ui.py` (Playwright, real browser) | **INTEGRATION VERIFIED** |
| Worker → outbound providers | job handlers call the provider adapters, which in the suite reach a local HTTP stand-in (`RestApi`) or are held in DRY_RUN | `tests/test_outbound.py`, `tests/test_jobs_worker.py` | **INTEGRATION VERIFIED** (locally, against a local stand-in) |
| PostgreSQL migrations | the full migration chain is run against PostgreSQL 17.11, drift-checked against the ORM models, downgraded and re-upgraded | `tests/test_migrations.py`, `tests/test_export_outbox.py` | **INTEGRATION VERIFIED** |
| Export destination pipeline | `deliver()` → outbox → checkpoint against SQLite and PostgreSQL, with a stand-in destination driver | `tests/test_export_outbox.py` | **LOCALLY VERIFIED** — the destination itself is a stand-in |
| Snowflake | nothing: no account, no SDK | — | **BLOCKED** (GATE 12) |
| CRM vendors, e-mail, SMS, push providers, IdP, MLflow server | nothing: the adapters were pointed at a local stand-in or left in DRY_RUN | — | **BLOCKED** (GATES 9–12) |

## What the M1 defect fixes changed about integration

Three of the four fixes are about what happens when a component *disagrees* — the destination refuses a row, the
session is not the configured one, another tenant owns the same customer id. Those paths are now exercised with real
objects (a real database, a real migration, real SQLAlchemy sessions, a real git repository for the release check) and
with a destination driver that is explicitly a stand-in.

The fourth fix is about the evidence itself: `--release` now compares the register with `git` rather than with the
register, which is the only way the sentence "this was verified at this commit" can mean anything.

## What was not integrated, and why

- **No vendor was contacted.** Not for Snowflake, not for Zendesk, Marketo, Salesforce, HubSpot, Intercom, APNs, FCM,
  SMTP, SMS, or an identity provider. Each of those is a gate with a named owner and a BLOCKED result. No test claims
  otherwise, and no report in this release may.
- **No multi-node deployment was run.** The appliance is one API process, one worker and one database. The rate limiter
  and the job queue are database-backed and safe across processes, but nothing was run as two nodes.
- **No load test was run for 1.3.0.** The figures in `docs/1_2_0_PERFORMANCE_REPORT.md` are 1.2.0's, measured on
  2 vCPU / 2 GB, and are quoted as such or not at all.
- **No disaster-recovery drill was run for 1.3.0.** The 1.2.0 drill's results stand for the code it was run against.

## How to re-run what is claimed here

```
# the whole suite, twice, with the release evidence sidecars
TMPDIR=/var/tmp/churn-tmp CHURN_TEST_TEMPLATE_DIR=/var/tmp/churn_test_template CHURN_TEST_STRICT=1 \
CHURN_TEST_POSTGRES_URL=postgresql+psycopg://churn:churn_local_dev@127.0.0.1:5432/churn_test \
CHURN_TEST_SENTIMENT_MODEL_DIR=/var/tmp/sentiment-models/models/sentiment \
python3 -m pytest -q --junitxml=release/run-1.xml
python3 scripts/record_test_run.py release/run-1.xml "python3 -m pytest -q --junitxml=release/run-1.xml"

# the browser integration only
python3 -m playwright install chromium
python3 -m pytest -q tests/e2e

# the migration integration on PostgreSQL only
python3 -m pytest -q tests/test_migrations.py tests/test_export_outbox.py -k postgres
```

A reader who runs those commands gets the same verdicts or a failure. That is the point of naming them.
