# 1.2.0 — reconciliation of the evidence, done at 1.3.0

The 1.2.0 release shipped with five internal disagreements between its own documents. They are listed here with what
each said before, what it says now, why it was wrong, and what evidence settles it. Nothing in this file changes a
result that was observed: the corrections are to summaries, to one status that contradicted its own evidence, and to
stale figures. The 1.2.0 archive is untouched; this file ships with 1.3.0 and points at it.

The rule applied: **fresh execution outranks a CI artefact, which outranks a release artefact, which outranks a
historical report.** Where a document and a run disagreed, the run won, and the document was corrected in the open.

| # | Item | Said before | Says now | Why it was wrong | Settled by |
|---|---|---|---|---|---|
| 1 | `docs/1_2_0_requirements.json` → `meta.counts` | `PASS 23, PARTIAL 16, NOT_IMPLEMENTED 9, BLOCKED 8, NOT_APPLICABLE 2` | `PASS 28, PARTIAL 14, NOT_IMPLEMENTED 6, BLOCKED 8, NOT_APPLICABLE 2` | the block was typed by hand and not updated when M3 and M6 moved entries; both blocks summed to 58, so the disagreement was invisible to a total | the 58 entries themselves; from 1.3.0 the counts are computed by `scripts/build_1_3_0_register.py` and `--check` fails on a mismatch |
| 2 | `docs/1_2_0_requirements.json` → `meta.source_commit` | `443aa03` (the 1.1.1 tag) | `0224654` (the 1.2.0 release commit) | copied from the 1.1.1 register when the file was created and never repointed | `git rev-list -n1 v1.2.0` |
| 3 | R-48, container image | **PASS**, evidence: "Image 1.1.0 built and run with compose … the 1.2.0 image has to be rebuilt and re-verified after these changes" | **PARTIAL**, carrying that evidence and the reason | a PASS whose own evidence says the artefact was not built for this version. The 1.1.0 image is real evidence for 1.1.0 | `docker images` on the build host (no 1.2.0 image), `docs/1_2_0_PRODUCTION_ACCEPTANCE.md` gate 2 ("PARTIAL") |
| 4 | R-46, PostgreSQL runtime | "All **493** tests run against PostgreSQL … migration **0003** verified up/down/re-up" | "**498** tests … migrations **0001–0004** verified up/down/re-up" | the evidence text was written before the 1.2.0 suite grew to 498 and before migration `0004` existed | `pytest --collect-only` → 498; `ls src/churn_platform/migrations/versions` → four revisions; `tests/test_migrations.py` |
| 5 | R-56, regression | "**493**-test baseline re-run twice on the final source" | "**498** tests twice on 3.13.16 with identical ids and outcomes, once each on 3.12.16 and 3.11.18" | same cause as 4: the text was the 1.1.1 figure | the release evidence in `release-evidence/1.2.0/`: `suite_120_a1.txt`, `suite_120_a2.txt`, `suite_120_b_py311.txt`, `suite_120_b_py313.txt`, `suite_120_b_main.txt` |
| 6 | R-55, the 32 screens | **PASS**, evidence resting on 1.1.0 browser evidence | **PARTIAL**: the screens that exist are driven by the in-suite E2E; screens for annotation, quiet hours and backup/restore do not exist | a PASS asserted for a version whose new features have no screen, on browser evidence collected for the previous version | `src/churn_platform/web/js/app.js` (31 routes, no annotation screen); `tests/e2e/test_ui.py` |
| 7 | `GATE 5` in the generated traceability | **NOT_IMPLEMENTED** | **PASS**, with the three commands named | the gate table was a hard-coded tuple in `scripts/build_1_2_0_register.py` and was not updated when the security work landed; the security report and R-44 were already PASS | `bandit -q -r src scripts -x tests -ll` (0 high, 0 medium), `pip-audit --requirement requirements.lock …` (no known vulnerabilities), `python scripts/scan_secrets.py` (no credential) |
| 8 | `docs/1_2_0_SECURITY_REPORT.md` → suppressions | "**six** matches suppressed" | "**nine** matches suppressed, all of them the rule 'password in a URL'" | the count was written from the suppression table's five rules, not from the matches it suppressed; the tree had gained matches since | `python scripts/scan_secrets.py` on `0224654` → "suppressed with a written reason: 9" |
| 9 | R-44, security tooling | "six documented suppressions" | "nine matches suppressed, all of them 'password in a URL', each with a written reason" | same cause as 8 | as above |

## What was deliberately not changed

* The 1.2.0 archive and its manifest. It is a shipped artefact; rewriting it would destroy the only thing a reader can
  check the 1.2.0 claims against.
* Every 1.1.0 and 1.1.1 report. They were true for their commits. Where a 1.2.0 document leaned on them, the lean is
  now stated in the 1.3.0 register's `verified_at` field instead of being quietly inherited.
* The 498 figure itself, anywhere it described the 1.2.0 run. Only the places where it is presented as the count of a
  *different* (1.1.1) run were corrected.
