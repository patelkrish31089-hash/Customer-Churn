# 1.3.0 — data governance report

What 1.3.0 changes about who may see which data, where it goes, and what happens when it must be deleted. The short
version: the delivery layer learned that data belongs to a tenant, and that is the change this document is about. The
governance machinery around it — retention, deletion, correction, audit — is 1.2.0's and is unchanged, and it is cited
rather than re-described.

## 1. What 1.3.0 changed

### The tenant is part of every exported record, and of every key

Until this release the canonical export record had no tenant: its identity was `customer | model | version | day`.
Two consequences, both recorded as defect 3 of the brief:

- **inside one run**, two tenants holding the same external customer id were deduplicated into a single record, so one
  tenant's row silently disappeared and its probability was replaced by the other's;
- **at the warehouse**, the MERGE keyed on the external customer id, so tenant B's export **updated tenant A's row**.

That is a cross-tenant data flow — the most serious class of defect a multi-tenant product can have — and it is now
structurally impossible: `tenant_id` is the record's first required field, it leads the identity, the idempotency key,
the deduplication key, the primary key and the MERGE's `ON` clause, and `from_prediction()` refuses a record whose tenant
cannot be established. `record_run()` refuses a run that mixes tenants.

What a destination receives is therefore per tenant, and a destination that cannot separate tenants cannot be given two
tenants' records by this code.

### The audit of a delivery is the outbox

`export_runs`, `export_outbox` and `export_checkpoints` record, per run, what was selected, what the destination
acknowledged, what failed and what was quarantined with its reasons; and per record, the identity, the payload digest,
the attempts and any error. **No payload is stored**: the outbox holds identities and digests, not customer data, so the
delivery bookkeeping does not become a second copy of the portfolio that retention has to chase.

## 2. What did not change, and is the customer's to rely on

Quoted from 1.2.0, unchanged by this release:

| Obligation | Where it is implemented | Where it is tested |
|---|---|---|
| Erasure of a customer, including derived rows and history | `services/ingestion.py`, the `Correction` and `EntityHistory` models | `tests/test_ingestion.py`, `tests/test_customer360.py` |
| Correction of a canonical record without destroying the history of the correction | `services/quality.py` (approved corrections only) | `tests/test_quality.py` |
| Consent, suppression and channel preferences against every outbound message | `services/notify.py` | `tests/test_outbound.py` |
| Retention and scheduled deletion of derived artefacts | `services/jobs.py`, the maintenance pass in `worker/runner.py` | `tests/test_jobs_worker.py` |
| An append-only, hash-chained audit trail over every consequential action | `services/audit.py` | `tests/test_audit_policies.py` |
| Tenant isolation on every query path | the services, not the routes | every API test, and the tenant fixtures |
| Synthetic data labelled as synthetic, end to end | `is_synthetic` on the generator, the import run, the dataset version, the model and the evaluation | `tests/test_signals.py`, `tests/test_annotations.py` |

## 3. What leaves the platform, and under whose control

| Destination | What would be sent | Under whose control | State |
|---|---|---|---|
| a warehouse (Snowflake) | the canonical record: 20 fields including the tenant, the model version and three reasons | the customer's own account, its role and its grants | implemented, never exercised against an account (GATE 12) |
| a support desk or marketing platform | the risk score and its reasons, through a reverse-ETL sync that a second person approved | the customer's vendor tenant | adapter implemented; no sandbox (GATE 12) |
| a CRM | risk scores and tasks through a connection that starts in `TEST_ONLY` | the customer's OAuth grant | implemented; no sandbox (GATE 9) |
| a file | CSV or JSON lines with a manifest and a digest, in the platform's own storage | the customer's installation | implemented and tested |
| e-mail, SMS, push | approved templates only, subject to consent, suppression and frequency caps | the customer's provider account | implemented; DRY_RUN by default; no sending account (GATES 10, 11) |

Every one of those paths carries the tenant with the row. None of them carries anything to a third party that the
customer has not configured.

## 4. What this release does **not** govern, stated plainly

1. **The delivery layer is not reachable from the product** (R-98). Until a route exists, none of this bookkeeping
   happens in a running installation, and no customer data has been exported by 1.3.0 to anything.
2. **No labelled, non-synthetic data set exists** here. Every accuracy figure in this repository is measured on
   synthetic data and is labelled as such; a model evaluated on it is not evidence about a real portfolio (GATE 13).
3. **No data-processing agreement, retention schedule or residency decision was made** for a destination warehouse.
   Snowflake account settings — encryption at rest, data retention, cross-region replication — are the customer's, and no
   claim is made about them here.
4. **An existing warehouse table is not migrated.** A table created by an earlier 1.3.0 build has no `TENANT_ID` column
   and this release does not alter or backfill it; the upgrade path is manual and is described in
   `docs/1_3_0_KNOWN_LIMITATIONS.md`. Until it is done, such a table must not be used: rows from two tenants would merge.
5. **Quarantine reasons may quote a value.** A validation refusal names the field and the reason and does not include
   the value; a delivery error records the destination's own message, which a vendor could have built from the row it
   refused. The outbox keeps the message (truncated to 300 characters) for diagnosis, and a customer for whom that is
   too much should treat the outbox as they treat the destination's own logs.

## 5. How to check the claims in this document

```
# the tenant is part of the record, the identity and the MERGE
python3 -m pytest -q tests/test_tenant_id_prevents_crm_collisions.py

# the outbox stores identities and digests, not payloads
python3 -m pytest -q tests/test_export_outbox.py

# a run that mixes tenants is refused
python3 -m pytest -q tests/test_export_outbox.py -k mix

# the existing governance paths, unchanged
python3 -m pytest -q tests/test_ingestion.py tests/test_quality.py tests/test_audit_policies.py
```
