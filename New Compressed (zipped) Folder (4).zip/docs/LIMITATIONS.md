# Known limitations

What this release does not do, does differently from the project brief, or has not been proven.
Differences from the brief are also recorded per section in
[`traceability/requirements.toml`](traceability/requirements.toml) (entries with `coverage = "partial"`).

## How far each part was exercised

Parts the test suite cannot prove on its own. Each row says what was run for release 1.1.1 and what was not; the
outputs are kept with the release evidence. "Simulated transport" means a stand-in for the vendor inside the test
suite that records the request and checks it field by field; "third-party software on this machine" means a real
product (a mail server, an identity provider, a CRM built to the vendor's rules) that ran as its own process and
was driven over the network, and is *not* the vendor's hosted service.

| What | What was run | What was not |
|---|---|---|
| Sentiment model | `sentiment-model fetch` downloaded the five pinned files and verified size and SHA-256 of each; a file changed afterwards makes `verify` exit 1 and the platform fall back to the labelled baseline. The reference demo was scored with it: 2,223 texts in four languages, 1,349 of them in the 180 days the screen shows. Measured on 2 CPUs with one inference thread: about 2,000 texts a minute end to end, 430 to 460 MB of memory, the same score for the same text on every run. | **Accuracy on real support text.** **New in 1.2.0: the labelled sample such an evaluation needs can now be produced inside the product** — a batch of support text, two independent reviewers, agreement (exact and Cohen's kappa per pair) reported before any model is scored, adjudication of each disagreement, a freeze, and an export in the shape the evaluation reads; a batch is marked synthetic or real at creation and the result carries that mark. What is still missing is the data and the reviewers, not the mechanism. No labelled sample of real conversations was available; the screen and the API report accuracy as not measured. Languages other than English, Dutch, German, French, Italian and Spanish are not scored. No GPU. |
| Adoption, identity, attribute history | The test suite, and the reference demo: 850 customers measured against a catalogue of 8 features, 11,403 identifiers resolved to 9,679 people, 7,368 attribute periods. | Real telemetry and a mapping exported from a real identity system. |
| MLflow | A real MLflow 3.18.0 tracking server reached over HTTP (SQLite backend, artifacts through the server): the production version was created once, a second sync created nothing, MLflow's own API showed the tags and the aliases `production` and `validated`, the model file downloaded from MLflow had the checksum the platform recorded. With MLflow as the registry of record the model served while both agreed and was refused when the checksum recorded here was changed. | A remote or authenticated MLflow server. Moving the alias by hand in MLflow was run against a file store in the test suite, not against the server (the demo holds one version). Other MLflow versions. |
| Airflow | `deploy/airflow/churn_nightly_dag.py` on Airflow 3.4.0 with `airflow dags test`, twice, against a copy of the reference demo with a platform worker running: 8 tasks succeeded in order each time; the platform recorded the 7 steps of each DAG run under the DAG's run id. Repeating a step command with a run id already used did nothing (no job, exit 0). With `CHURN_ORCHESTRATOR=platform` the step command was refused (exit 2). | The scoring step had nothing to score (the demo's date was scored when it was seeded) and reported "skipped"; scoring driven step by step runs in the test suite, not under Airflow. A scheduler with an executor, Airflow's own retry of a failed task, Airflow 2 and several nights were not run with this DAG (the 1.0.1 DAG ran under a scheduler; this one did not). |
| Salesforce, HubSpot, Intercom | As in 1.0.1 (requests checked against the vendors' published API descriptions; six requests to the live hosts with a token the vendor must reject). **1.1.1: the whole path against a third-party CRM on this machine** (127.0.0.1:9443) built to HubSpot's rules and refusing what HubSpot refuses: consent screen, authorization code good once for 60 s, client secret checked, access token expiring after 120 s, rotating refresh token, revocation endpoint, 401 `EXPIRED_AUTHENTICATION`, 400 `VALIDATION_ERROR` for an unknown property and for a task without `associations`, 429 with `Retry-After`, and signed `propertyChange` events (base64 HMAC-SHA256 of method+URL+body+timestamp). Over real HTTP: 85 of 85 high-risk score updates accepted (85 companies now in the CRM), 85 property-change events stored and each delivery confirmed against the value the CRM holds, a stale and a tampered event refused with 401, a replayed event stored once, a recommendation created as a HubSpot task, the token refreshed when it was due and refreshed again after the vendor reported 401, the 429 retried and delivered, the token revoked at the vendor on disconnect, and a 369-row export verified by SHA-256. | **No vendor account has accepted a request, shown a consent screen to this software or delivered an event to it.** The stand-in is not the vendor: the Salesforce and Intercom request shapes were not driven end to end, only HubSpot's. A paid HubSpot sandbox, Salesforce Developer org or Intercom app is still the only way to prove the vendor's own service works with this software. |
| E-mail, text, push | Requests for SendGrid, Amazon SES, Twilio and Firebase built as the vendors document them and checked against simulated transports; retries, refusals, delivery events and unsubscribe links in the test suite. **New in 1.1.1: Sending through an SMTP server** (provider `smtp`, migration 0003), driven against a real mail server on this machine (Mailpit, port 1025): a test campaign of the reference demo enrolled 73 customers and the mail server accepted **73 of 73 messages** (`SMTPAccepted` 73, `SMTPRejected` 0), each with the rendered subject, body, recipient, `Message-ID` and unsubscribe link; the 12 customers without marketing consent were held back before a request was built. In SANDBOX the same provider only takes the handshake to the mail server (EHLO/NOOP/QUIT): the server received nothing. The test suite also speaks to a small SMTP server it starts itself, including a mail server that is not running (the message waits and is retried). A mail server's address is checked like a provider URL: a name that resolves to a private, loopback or link-local address is refused unless `CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS=true` (DEF-085). | **No messaging vendor has accepted a message** (SendGrid, Amazon SES, Twilio, Firebase). Apple push (APNs) can only be rehearsed: it needs HTTP/2, which is not included. The vendors' own webhook signatures (SendGrid, Twilio, Amazon SNS) are not implemented; events need a relay that verifies them. A mail server that requires STARTTLS or AUTH was not exercised (the flags exist: `starttls`, and `username`/`password` as credentials), and no message was delivered to a mailbox beyond the local server. |
| Single sign-on | An OpenID Connect provider that lives inside the test suite (discovery, signing keys and their rotation, RS256 and ES256, every refusal the platform makes). **1.1.1: a real Keycloak 26.0 server** (realm `churn`, confidential client, PKCE S256, groups as a claim) driven in a real Chromium browser through the product's own sign-in page, and again over HTTP only: an unknown person was provisioned as `analyst` from the identity provider's group, an existing account was linked by its verified e-mail address, a change of group changed the role (audited as `sso.role_updated`), a replayed callback was refused (`sso_state_reused`), an exchange code could be used once, an unverified e-mail address was refused (`sso_email_unverified`), a foreign e-mail domain was refused (`sso_domain_refused`), a wrong password was refused by the identity provider itself, a role that needs a second factor was refused when the provider reported none (`sso_mfa_required`), an identity provider that is not running produced `external_service_error`, and the per-address sign-in limiter answered 429 with `Retry-After` after 30 attempts. | **Not against a hosted provider**: no Entra ID, Okta or Google tenant was available, so their metadata quirks are untested. SAML is not implemented. A second factor inside the provider (Keycloak's own OTP) was not enrolled; only the platform's side of `idp_mfa` (trusting `amr`) is exercised. |
| Forwarded headers | A server started with `churn-platform serve` and requests from 127.0.0.1 that claim HTTPS and another client address: without `CHURN_TRUSTED_PROXIES` no transport-security header was sent and the sign-in limit counted 127.0.0.1; with `CHURN_TRUSTED_PROXIES=127.0.0.1` both headers were believed; `--forwarded-allow-ips` was refused. The release candidate before this fix believed both (DEF-082). | A real reverse proxy in front (nginx, a load balancer); a chain of several proxies outside the test suite. |
| Request limits with several server processes | `serve --workers 2`: 150 sign-in attempts for one account from one address inside one minute, each on a new connection. 10 were answered (the per-account limit), 140 were refused with `Retry-After`. In 1.0.1 the same probe let 60 of 150 through. | More than two processes. |
| Web interface | The 18 browser tests of the suite; in addition 16 screens of the reference demo, among them every screen added in 1.1.0, opened as administrator: no script error, no failed request. | Browsers other than Chromium. |
| Load | [Figures in the README](../README.md#load): the 1.0.1 request mix on the 1.1.0 reference demo, SQLite, one and two server processes, on the release candidate; a repeat and a side-by-side comparison on the released code. The shared build machine varied by a factor of two between runs, so the figures are an indication. | PostgreSQL was not measured again for 1.1.0. Hours of load, more than 1,200 customers, a load generator on a second machine. Feature computation is single-node pandas. |
| GitHub Actions | `actionlint` finds nothing in the workflow, which now fetches and caches the sentiment model. | The workflow has not run on GitHub (no repository), and for 1.1.0 it was not run on a local runner either: the release test runs were started directly, on Python 3.11, 3.12 and 3.13, in strict mode with PostgreSQL. |
| Container image | Built for `linux/amd64`: about 1.2 GB, with the runtime of the sentiment model and without its weights. The compose stack under the `production` profile with PostgreSQL, started for the check without publishing its port: migration, health checks, `CHURN_TRUSTED_PROXIES` and `CHURN_PUBLIC_BASE_URL` from `.env` reaching the containers, `sentiment-model fetch` into the data volume, a demo of 300 customers seeded and scored with the fetched model, sign-in, the audit check; no error-level line in the logs. | `linux/arm64` was not built for 1.1.0 (1.0.1 was, under emulation): whether ONNX Runtime installs and runs there is unchecked. The image variants with `EXTRAS=nlp,mlops` and without extras were not built. |

What these runs showed and did not change:

- **More than one worker.** A step of the nightly chain asks every five seconds whether the job it waits for has
  finished. One worker runs that job first and never waits; with two, the chain takes about five seconds longer
  per step.
- **SQLite with two server processes.** Reads are fine; writes queue. Use PostgreSQL when running more than one
  process.
- **A dry-run campaign leaves a job waiting.** The demo's campaign rehearsal has its second step three days after
  the first; the job for it stays queued until then. It is counted as scheduled, not as running.

## Differences from the brief

- **Sentiment** comes from a model trained on product reviews, not on support conversations, and its thresholds
  were set on synthetic templates. How well it agrees with human judgement on real support text is unknown until a
  labelled sample is evaluated. Two known misses: one of the five mixed templates ("… is great and the team loves it, but the
  export keeps failing and that is really frustrating") comes out neutral instead of mixed, and a short question
  ("how do I configure this") comes out positive.
- **Feature adoption** is measured against the catalogue the tenant maintains. Telemetry that no catalogue entry
  claims is reported and not counted (582 events in the reference demo).
- **Daily active users** counts people only where events name a user. A customer with fewer than half of its
  events attributed has no count; the feature is empty, not zero.
- **Customer attributes** have a history from the day the platform first saw the customer. The first value is
  assumed to have held since the customer began; that assumption is marked as such on every row.
- **Warehouse**: PostgreSQL (SQLite for single-machine use). There is no Snowflake support.
- **Operational tools**: reverse-ETL syncs are built in and deliver to a CRM connection or write a file with a
  checksum. The platform does not talk to Hightouch, Census, Zendesk or Marketo; the file is the hand-over.
- **CRM hand-over** ([`CRM_SETUP.md`](CRM_SETUP.md)): a pasted access token is used as given and never renewed; a
  connection authorised through OAuth refreshes its token. A failed delivery is not sent again. A HubSpot task is
  not linked to its company. Intercom receives an executed recommendation as company attributes, not as a task,
  and creates a company it does not know.
- **E-mails, SMS, push**: the platform builds and sends messages through a provider the tenant configures.
  Providers start in dry-run mode. The e-mail channel can also go out over SMTP (`provider: "smtp"`), which needs
  no vendor at all: a mail server accepted 73 of 73 messages from a test campaign in 1.1.1. For the hosted APIs,
  no vendor has accepted a message from this software (see the table above).
  Campaign screens offer the three prepared campaigns; other campaigns are created through the API.
- **MLflow** follows the platform's registry, or decides what serves when it is made the registry of record. In
  that mode a newly promoted model starts serving when the background job has told MLflow.
- **Orchestration**: the nightly work runs on the platform's own schedule or step by step under Airflow, never
  both.
- **Retraining** triggered by a performance drop produces candidate models. Nothing is promoted without a person
  evaluating and a second person approving, and without passing the promotion gates.

## Modelling

- **Example money figures.** The cost matrix (50 and 5,000 dollars) and the 15% discount come from the brief and are
  marked as examples on screen. Thresholds and offers mean nothing for a real business until real figures are
  entered and approved.
- **Small samples.** In the reference demo (see below) the test split holds 67 churners among 1,622 rows. PR-AUC and
  the threshold move noticeably from seed to seed; the demo shows how the platform works, not how accurate it will
  be on real data.
- **Which model wins.** The brief expects boosted trees to win. The demo registers the run with the best validation
  PR-AUC, and on its small synthetic data that is often logistic regression.
- **Monthly training snapshots.** Training rows are taken on the first day of each month; scoring uses the current
  day. In the reference demo the input-drift report reads `warning`: 18 of the 84 features have a population
  stability index of 0.25 or more against the training period. Nine of them measure age, or cover a period that a
  young customer has not filled yet, in a simulated customer base that is still growing (tenure, subscription age,
  the first-90-days flag, three 90-day counts, invoices in 180 days, lifetime spend, lifetime adoption). The other
  nine are `recency_days`, `inactivity_streak_days`, two month-on-month changes, two 90-day adoption rates,
  `distinct_features_30d`, the last NPS score and the days since the last ticket. No alert is raised: the approved
  rule asks for 30% of the features and 18 of 84 is 21%.
- **Snapshot features.** Six features use a value as it is today, also for past dates: billing period, seats,
  discount, days to card expiry, days to renewal, and active users per seat. A feature contract can exclude them.
  `mrr` and `plan_tier` are reconstructed from subscription events; when an event carries no value the
  subscription's current value is used and the fallback is counted. Industry, size, employees, region and
  acquisition channel are read from their history.
- **Models trained before 1.1.0.** Two features changed their meaning and five attributes are now read from their
  history. A model trained with 1.0 has to be retrained before its scores mean what they did.
- **Ties among the safest customers.** Calibration clips raw scores below one in a million (and above 0.999999) to
  one value, so customers there share a probability and their order among each other is lost. In the test tenant
  this moves the ROC-AUC of the logistic regression from 0.7120 to 0.7115; the risk tiers at the top are not
  affected.
- **Uplift** needs at least 100 matured outcomes per arm from a real experiment. The demo holds only an A/A split in
  which nothing was delivered, so its uplift model fails validation, as it should.
- **Changed churn definition.** After the churn definition changes, the realised performance of a model trained
  under the previous definition is no longer measured. An alert asks for a new model.
- **Demo data.** Four features are constant in the training rows of the reference demo, because the simulator
  produces one subscription per customer and no plan changes, overdue invoices or late payments there:
  `active_subscriptions`, `plan_changes_90d`, `overdue_invoices` and `late_payments_180d`. The demo says nothing
  about how the models use them.

## The reference demo and its A/A experiment

The simulated history ends on the day given by `--end-date` (default: yesterday), so a demo seeded on another day
holds different data and shows different figures. Every figure quoted in this repository belongs to the reference
demo, `seed-demo --seed 42 --end-date 2026-11-09`; that command reproduces them exactly.

The A/A split is derived from the seed and the data, so the reference demo always shows the same result: the two
arms differ "significantly" (p = 0.039) although nothing was delivered. That is chance: about 1 split in 20 crosses
the 5% threshold. The experiment page says so and backs it with 400 fresh random splits of the same customers. It
is left in as a demonstration of why a single significant result is weak evidence.

## Security and access

- Single sign-on uses OpenID Connect; there is no SAML. Without a provider, accounts are local, with optional or
  role-enforced one-time codes (TOTP).
- Request limits count changes, sign-ins, exports, single predictions and CRM syncs. Reads are not limited by the
  platform: put a reverse proxy in front for that.
- Session tokens are replaced by the web application every hour. A client of the API that keeps one token keeps
  it for the session's lifetime.
- Without `CHURN_PUBLIC_BASE_URL` the redirect addresses for single sign-on and CRM OAuth are built from the `Host`
  header of the request. Set it wherever the platform is reached through a proxy or under more than one name.
- A CRM connection is created in the mode an administrator chooses (`TEST_ONLY` by default); no second person
  approves that choice. `PRODUCTION` needs `CHURN_CRM_ALLOW_PRODUCTION=true`; `SANDBOX` needs no setting of the installation.
- An e-mail address is unique across all tenants: one person cannot hold accounts in two tenants with one address.
- Anybody who knows an e-mail address can lock that account for 15 minutes by failing the password five times.
- TLS is not terminated by the platform. Put a reverse proxy in front of it.
- The page may be embedded in a frame unless `CHURN_ALLOW_FRAMING=false`. The `production` profile refuses to start
  without that setting.
- `CHURN_CRM_ALLOW_PRIVATE_HOSTS` and `CHURN_INGEST_ALLOW_PRIVATE_HOSTS` switch off the protection against requests
  to internal addresses. They exist for development against local mock servers and must stay off elsewhere.

## Behaviour to know about

- **Uploads.** The first upload to a source stores a column mapping suggested from the column names. If it
  covers every required field, imports use it without anybody having confirmed it; if not, an import is refused
  until the mapping is completed.
- **Approved recommendations never expire.** An approved action that nobody carries out stays in the work queue
  until it is carried out or withdrawn.
- **Experiments.** A customer in a running experiment cannot be enrolled in another one.
- **Webhooks.** A received event is stored first and loaded by a job. If loading fails, the job queue tries again
  (three attempts in all, with a growing delay); after that the events stay stored and the job is listed as failed.
- **Reports** are exported as CSV. There is no PDF or scheduled e-mail report.
- **Shutdown.** A server started with the embedded worker (development only) can take up to 35 seconds to stop while
  a job finishes.
- **Scoring between two pipeline runs.** The nightly pipeline stores the feature vectors of its date before it
  scores. A batch started by hand for a date the feature store does not hold computes its vectors and does not store
  them. Recommendations, explanations, monitoring and the uplift fit compute them again when they need them (the
  *Input drift* tab says where its values came from), so records that arrived in between can make them differ from
  what the batch saw. Scoring an uplift model for such a date is refused until the date is materialised.
- **Random forest scores on one thread.** That makes its scores identical from call to call (DEF-059); on a very
  large batch it is slower than the other algorithms.
- **One sentiment model.** `sentiment-model --model distilbert-student-multilingual fetch` downloads a second
  pinned model, but no setting makes the platform score with it.
- **Signals are on their own screens.** The customer page shows scores, reasons, recommendations and the timeline
  as before; a customer's sentiment scores, adoption and attribute history are found under *Signals*, not on the
  customer page.
- **Small display gaps.** The number on the *Quarantine* tab is read when the screen opens and does not change
  while rows are corrected on it. The *Actions taken & outcomes* tab names an action by its code (for example
  "csm white glove call") rather than by the label of the playbook.
- **Code style.** Line length is not enforced by the linter.
