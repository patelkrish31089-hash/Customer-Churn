# 1.2.0 — security report

What was checked, with what, and what it found. Nothing here claims a penetration test: that is GATE 14, BLOCKED,
and an independent assessor is the only thing that can move it.

## The three scans, and what they found

| Scan | Command | Result at this commit |
|---|---|---|
| Static analysis | `bandit -q -r src scripts -x tests -ll` | **0 high, 0 medium.** Four medium findings were resolved rather than ignored: one in the new backup module (a `select count(*)` over a constant tuple of table names, annotated `# nosec B608` with that reason) and three pre-existing ones in `scripts/` (`xml.etree` over a JUnit file this job writes; `urllib.request.urlopen` over fixed https URLs), annotated `# nosec` next to the `# noqa` that already explained them |
| Dependencies | `pip-audit --requirement requirements.lock --strict --disable-pip --no-deps` | **no known vulnerabilities** |
| Committed credentials | `python scripts/scan_secrets.py` | **no credential found**; nine matches suppressed, all of them the rule "password in a URL", each with a written reason (a connection-string example in the README, placeholder credentials in the docs, an example environment file, test fixtures, the CI service container's loopback database). Corrected at 1.3.0: the text said six, which counted the suppression rules rather than the matches |

All three are jobs in `.github/workflows/ci.yml` (`security`), and the commands above are exactly what the jobs run.
The workflow itself has never run on GitHub's runners — that is R-58, BLOCKED on a repository and a token — so what is
proven here is the commands, on this tree, today.

## What 1.2.0 changed in the security surface

* **A new permission**, `signals:annotate`, rather than reusing `signals:write`: labelling support text is not
  changing what the product computes, and adjudicating somebody else's label is a third thing again
  (`signals:approve`). The access-rule table in `tests/test_api.py` lists all 202 operations with their rule, and a
  test fails if an operation has no rule.
* **A restore path that does not trust its own archive**: member names are checked for traversal, non-file members
  are skipped, and every checksum is verified before anything is written (`services/backup.py`).
* **No new outbound path.** The quiet-hours work is local; the backup module runs `pg_dump`/`pg_restore` only against
  the configured database URL.
* **The 1.1.1 defect stays fixed**: the mail server's address goes through the outbound guard (DEF-085), and the
  quiet-hours code sits before the request is built, so nothing is sent while a message is held.

## What is not covered here

| Area | State | Why |
|---|---|---|
| Independent penetration test | BLOCKED | needs an assessor (GATE 14) |
| Production TLS termination and certificate policy | BLOCKED | needs a host and a domain (GATE 7, partially) |
| Hosted identity provider | BLOCKED | Keycloak proved the standard; Entry/Okta/Google need a tenant (R-39) |
| Secrets manager integration | NOT_IMPLEMENTED | the platform reads environment variables; a deployment is expected to inject them from a manager |
| Source-level review by a second person | not claimed | this is a single-agent release, and the code review that would close this is not something I can perform on my own work |

## The honest summary

The tooling gate (GATE 5) is now satisfied by commands that run clean and by jobs that would fail a build on a
finding. The parts of security acceptance that need a person — a pen test, a second reviewer, an owner signing a
policy — are untouched and are listed above as such.
