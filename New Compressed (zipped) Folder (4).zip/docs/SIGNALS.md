# Customer signals

Release 1.1.0 adds four signals that the 1.0 releases only approximated. Each has a screen under **Signals**, an
API under `/api/v1/signals/…`, and features in the churn model's feature catalogue. Every feature obeys the same
rule as the rest of the catalogue: a vector for as-of date T uses only what was knowable before T 00:00 UTC.

A signal that cannot be computed is reported as **missing**, never as zero. Where a number has a denominator, the
denominator is stated.

## 1. Support sentiment

**What it does.** Every support interaction with text gets one score from a sentiment model that runs inside the
installation. No text is sent to any external service; the only network access is the operator command that
downloads the model weights.

**The model.** `nlptown/bert-base-multilingual-uncased-sentiment` (MIT licence), in the 8-bit ONNX export
published as `Xenova/bert-base-multilingual-uncased-sentiment`, pinned to revision
`fad9b372f770c208d2efaf00d02f2cb3b61ec450`. Every file is pinned by size and SHA-256
(`services/sentiment.py`, `PINS`); a download or a model directory that does not match is refused. It was trained
on product reviews with one to five stars in English, Dutch, German, French, Italian and Spanish. One and two stars
count as negative, three as neutral, four and five as positive.

```
pip install 'churn-platform[nlp]'            # ONNX Runtime, tokenizers, language detection
churn-platform sentiment-model fetch         # about 170 MB into <data dir>/models/sentiment, verified
churn-platform sentiment-model status
```

Measured on the build machine (2 vCPU, one inference thread, Python 3.12): 0.7 s to load; about 340 MB of memory
in the process once the model is loaded and about 430 MB with language detection (peak 460 MB); 20 ms per short
text for the model alone and 39 ms per scored text end to end, clause scoring included: about 2,000 texts a
minute. A text of 256 tokens, the longest the model is given, takes about 150 ms.

**One text per pass.** Texts are scored one at a time, never in batches. The published weights are quantised
dynamically: value ranges are taken from the whole input, so in a batch a text's score moved with whatever else was
in the batch (measured on the 99 synthetic templates: 48 probabilities moved by more than 0.01, 5 by more than 0.1,
4 labels changed). Alone, a text gets the same score every time, on the same machine and library versions. This
costs about a third of the throughput on short texts.

**A second pinned model that is not used.** The code also pins
`lxyuan/distilbert-base-multilingual-cased-sentiments-student`, and
`churn-platform sentiment-model --model distilbert-student-multilingual fetch` downloads and verifies it. This
release has no setting to score with it: the platform always uses the model above, and with only the second one
installed it falls back to the word list. Scoring with another model is a code change, with thresholds of its
own to set.

**The fallback.** Without the runtime or the weights (`CHURN_SENTIMENT_PROVIDER=auto`, the default) the platform
scores with fixed English word lists. That is a *baseline*, not a trained model: it knows no negation, no context
and no other language. It is labelled as a baseline in the database, in the API and on the screen, with the reason
it stands in. `CHURN_SENTIMENT_PROVIDER=onnx_transformer` turns a missing model into an error instead.

**Before scoring.** Unicode normalisation; removal of e-mail addresses, URLs, phone numbers, IP addresses, IBANs
and card numbers (Luhn-checked) — the stored excerpt is the redacted text; language detection; texts over 4,000
characters keep their beginning and end; identical texts are scored once.

**Labels and states.** `positive`, `negative`, `neutral`, `mixed` (clauses with opposite, clear sentiment),
`uncertain` (no clear side). A text that is not scored has a state saying why: `empty`, `too_short`,
`unsupported_language`, `language_undetermined`, `error`. Unscored texts carry no score and are in no denominator.

**Features.** `negative_ticket_share_90d`, `negative_tickets_30d`, `sentiment_avg_score_30d`,
`sentiment_avg_score_90d`, `sentiment_delta_30d_prev60d`, `last_ticket_sentiment_score`. A score is read through
the interaction's own timestamp, not through the time it was scored.

**Accuracy — read this.** The decision thresholds were set on the SYNTHETIC message templates shipped with the
platform, and the model was trained on product reviews, not on support conversations. Of the 99 templates, 77 are
in a supported language. On those the model gets all 24 negative and all 24 positive ones right, calls 20 of 24
neutral requests neutral and the other 4 "uncertain", and finds 4 of 5 mixed ones: "… is great and the team loves
it, but the export keeps failing and that is really frustrating" comes out neutral, because its second half scores
just under the bar for a clearly negative clause. A short neutral question can come out positive: "how do I
configure this" does. **How well the labels agree with human judgement on your support text is not known** until
you evaluate a labelled sample of it (Support sentiment → Evaluate on labelled texts). Until then the screen shows
accuracy as *not measured*. An evaluation on a synthetic set never changes that.

Not covered: languages outside the six above (Hindi and Turkish in the demo data show the "unsupported language"
state), sarcasm, and edits of a ticket's text over time (the latest text is scored; a changed text is scored again).

## 2. Feature adoption

**The catalogue.** A product feature is an entry that says which telemetry counts as using it
(`event_type` + `feature_name`, matched case-insensitively), how much use counts as adoption (events and distinct
days), from when and until when it exists, and which plan tiers include it. Entries are versioned. A version
counts only after somebody other than its author approved it; the newest approved version of a key is in force
unless it was switched off. Two features may not claim the same telemetry.

**The rate.** For a customer at date T and a window W:

> adopted features ÷ features the customer could use at T

A feature is in the denominator when it was released before T, not retired by T, included in the plan tier the
customer was on at T, **and its telemetry had been seen at least once before T**. The last condition keeps a
feature that is not instrumented from counting as "not adopted". With an empty denominator the rate is missing.
A customer who could use features and used none has a rate of zero — that is a fact, not missing data.

**Features.** `feature_adoption_rate_30d`, `feature_adoption_rate_90d`, `core_feature_adoption_rate_90d`,
`lifetime_feature_adoption_rate`, `feature_adoption_delta_30d_prev30d`. Without an approved catalogue all of them
are missing. The older `distinct_features_30d/90d` stay as the ungoverned count of names seen in telemetry.

**The report.** `Signals → Feature adoption` and the nightly `signals` step measure adoption for all active
customers: per feature (eligible, adopted, rate, new adopters, stopped, median days to first use, users per
adopting customer), per plan tier and tenure band, a trend over measurements, and the telemetry no feature claims.
The report and the model features use the same code (`feature_engine.AdoptionGrid`); a test checks that they agree.

## 3. Active users and identity

**The definition** is a policy (`activity_definition`, under Policies), approved by a second person: which event
types count as activity, the time zone that decides what a day is, patterns for identifiers that are not customers'
people (staff, tests, automation), and the share of events that must name a user before a customer's user counts
are reported at all (default 50 %).

**Who is a user.** Identifiers are compared trimmed and case-folded. An e-mail address names one person everywhere;
any other identifier names a person within one customer. An identifier without a link counts as itself, so nobody
is lost while the mapping is incomplete. A quarantined or rejected link counts for nobody. Links can be limited to
a period. Two people are merged only by a person's decision (the platform proposes candidates, e.g. an e-mail
address whose local part equals another identifier of the same customer); a merge can be undone. A mapping from
your identity system can be imported (`external_user_id`, `person_id`, optional customer and validity).

**Features.** `avg_daily_active_users_30d`, `avg_daily_active_users_7d`, `monthly_active_users_30d`,
`dau_mau_ratio_30d`, `active_user_seat_share_30d`, `dau_delta_7d_30d_pct`. They are missing for a customer whose
events mostly do not name a user. `active_user_seat_share_30d` divides by the seat count of the subscription as it
is today, so it is declared a *snapshot* feature, like `seats`; a feature contract that excludes snapshot features
leaves it out.

**Reconciliation** (`Signals → Active users & identity`) reports daily, weekly and monthly active people, events
without a user, excluded identifiers, customers whose counts are unknown, and open merge candidates.

With a time zone other than UTC, the as-of instant (midnight UTC) falls inside a local day; that local day is
counted up to that instant.

## 4. Attribute history

Industry, company size, head count, region, country and acquisition channel are kept as periods
(`customer_attribute_history`), so that a model trained on last year sees last year's customer.

| Basis | Meaning | Used for an as-of date T when |
| --- | --- | --- |
| `initial` | the first value the platform saw; assumed to hold since the customer began | always (an assumption, shown as such) |
| `effective` | a change whose source gave the date it took effect (`attributes_effective_at`) | the period contains T |
| `observed` | a change noticed at import; dated when it was noticed | the period contains T |
| `backfill` | declared history, entered by a person | the period contains T |
| `correction` | a fix of known history | the period contains T **and** the fix had been recorded by T |

Nothing is edited in place except closing the open period. A rewrite marks old rows as superseded and writes new
ones, so both questions stay answerable: what was true on a date, and what the platform believed on that date
(`GET /signals/attributes/customers/{id}?at=…` returns both).

An installation upgraded from 1.0 has a change log (`entity_history`) and no attribute history; the history is
rebuilt from that log the first time features are computed. The log knows when a change was seen, not when it took
effect, so replayed changes are `observed`. Changes that happened before the platform first saw a customer are
unknown unless backfilled.

## Where the signals come from at night

The nightly pipeline has a `signals` step between data quality and labels: score new support text, give new
customers their attribute timeline, create identity links for new identifiers, and measure adoption at the scoring
date. Feature computation also checks first that nothing is waiting to be scored.
