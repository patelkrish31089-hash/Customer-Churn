# 1.3.0 — file structure

Generated from the tree by `scripts/build_1_3_0_file_structure.py`; run the script after adding a module, or
`--check` fails. Every description is the module's own first docstring line, so the document cannot describe a
file differently from the file itself.

## At a glance

- migrations: **5** (`0001` … `0005`)
- API router modules: **6**
- test modules: **43**, test functions before parametrisation: **546** (the collected count is in docs/1_3_0_TEST_BASELINE.md)
- packages: `api`, `models`, `migrations`, `services`, `services/destinations`, `worker`

## Layout

```
├── .github/
│   └── workflows/
│       └── ci.yml
├── deploy/
│   └── airflow/
│       └── churn_nightly_dag.py
├── docs/
│   ├── brief/
│   ├── traceability/
│   ├── 1_2_0_BASELINE_AUDIT.md
│   ├── 1_2_0_COMPLETE_AUDIT.md
│   ├── 1_2_0_CRM_ACCEPTANCE.md
│   ├── 1_2_0_DISASTER_RECOVERY_REPORT.md
│   ├── 1_2_0_FEATURE_ADOPTION_REPORT.md
│   ├── 1_2_0_IMPLEMENTATION_PLAN.md
│   ├── 1_2_0_IMPLEMENTATION_STATUS.md
│   ├── 1_2_0_MISSING_FEATURES.md
│   ├── 1_2_0_NOTIFICATION_DELIVERY.md
│   ├── 1_2_0_PERFORMANCE_REPORT.md
│   ├── 1_2_0_PRODUCTION_ACCEPTANCE.md
│   ├── 1_2_0_RECONCILIATION.md
│   ├── 1_2_0_REQUIREMENT_TRACEABILITY.md
│   ├── 1_2_0_RISK_REGISTER.md
│   ├── 1_2_0_SECURITY_REPORT.md
│   ├── 1_2_0_SENTIMENT_EVALUATION.md
│   ├── 1_2_0_requirements.json
│   ├── 1_3_0_BASELINE_AUDIT.md
│   ├── 1_3_0_DATA_GOVERNANCE_REPORT.md
│   ├── 1_3_0_EXISTING_FEATURE_REGRESSION.md
│   ├── 1_3_0_FEATURE_INVENTORY.md
│   ├── 1_3_0_FILE_STRUCTURE.md
│   ├── 1_3_0_FINAL_IMPLEMENTATION_REPORT.md
│   ├── 1_3_0_FINAL_TEST_REPORT.md
│   ├── 1_3_0_GATES.md
│   ├── 1_3_0_IMPLEMENTATION_REPORT.md
│   ├── 1_3_0_INTEGRATION_ACCEPTANCE.md
│   ├── 1_3_0_KNOWN_LIMITATIONS.md
│   ├── 1_3_0_MILESTONE_INDEPENDENT_REVIEW.md
│   ├── 1_3_0_MISSING_FEATURE_REGISTER.md
│   ├── 1_3_0_PDF_COMPLIANCE_REPORT.md
│   ├── 1_3_0_PERFORMANCE_REPORT.md
│   ├── 1_3_0_PRODUCTION_ACCEPTANCE.md
│   ├── 1_3_0_PRODUCTION_RISK_REGISTER.md
│   ├── 1_3_0_RELEASE_STATE.md
│   ├── 1_3_0_REQUIREMENT_MATRIX.md
│   ├── 1_3_0_REQUIREMENT_TRACEABILITY.md
│   ├── 1_3_0_SECURITY_REPORT.md
│   ├── 1_3_0_TEST_BASELINE.md
│   ├── 1_3_0_requirements.json
│   ├── CRM_SETUP.md
│   ├── DEFECT_LOG.md
│   ├── ENHANCEMENT_BASELINE.md
│   ├── EXISTING_FEATURE_HEALTH_REPORT.md
│   ├── LIMITATIONS.md
│   ├── MISSING_FEATURE_REGISTER.md
│   ├── ORCHESTRATION.md
│   ├── OUTBOUND.md
│   ├── REQUIREMENT_TRACEABILITY.md
│   ├── SECURITY_OPERATIONS.md
│   └── SIGNALS.md
├── scripts/
│   ├── acceptance_smtp_73.py
│   ├── build_1_2_0_register.py
│   ├── build_1_3_0_feature_inventory.py
│   ├── build_1_3_0_file_structure.py
│   ├── build_1_3_0_matrix.py
│   ├── build_1_3_0_register.py
│   ├── build_manifest.py
│   ├── build_phase2_manifest.py
│   ├── build_traceability.py
│   ├── check_crm_contracts.py
│   ├── check_wheel.py
│   ├── gate_ledger.py
│   ├── load_test.py
│   ├── load_test_delivery.py
│   ├── record_test_run.py
│   ├── reverify_1_3_0_register.py
│   ├── scan_secrets.py
│   ├── snowflake_upgrade_1_3_0.py
│   ├── update_1_3_0_register_defects.py
│   └── update_1_3_0_register_wiring.py
├── src/
│   ├── churn_platform/
│   │   ├── api/
│   │   │   ├── routers/
│   │   │   │   └── __init__.py
│   │   │   ├── __init__.py
│   │   │   ├── app.py
│   │   │   ├── deps.py
│   │   │   ├── routes_core.py
│   │   │   ├── routes_data.py
│   │   │   ├── routes_exports.py
│   │   │   ├── routes_ml.py
│   │   │   ├── routes_platform.py
│   │   │   └── routes_signals.py
│   │   ├── migrations/
│   │   │   ├── versions/
│   │   │   │   ├── 0001_baseline.py
│   │   │   │   ├── 0002_signals_platform.py
│   │   │   │   ├── 0003_smtp_provider.py
│   │   │   │   ├── 0004_annotation.py
│   │   │   │   ├── 0005_export_outbox.py
│   │   │   │   └── __init__.py
│   │   │   ├── __init__.py
│   │   │   ├── env.py
│   │   │   └── script.py.mako
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   ├── core.py
│   │   │   ├── data.py
│   │   │   ├── ml.py
│   │   │   ├── platform.py
│   │   │   └── signals.py
│   │   ├── services/
│   │   │   ├── destinations/
│   │   │   │   ├── __init__.py
│   │   │   │   ├── base.py
│   │   │   │   ├── postgres.py
│   │   │   │   ├── snowflake.py
│   │   │   │   └── snowflake_upgrade.py
│   │   │   ├── __init__.py
│   │   │   ├── adoption.py
│   │   │   ├── analytics.py
│   │   │   ├── annotations.py
│   │   │   ├── attributes.py
│   │   │   ├── audit.py
│   │   │   ├── auth.py
│   │   │   ├── campaigns.py
│   │   │   ├── common.py
│   │   │   ├── crm.py
│   │   │   ├── crm_oauth.py
│   │   │   ├── customer360.py
│   │   │   ├── demo.py
│   │   │   ├── evaluation.py
│   │   │   ├── experiments.py
│   │   │   ├── explain.py
│   │   │   ├── export_outbox.py
│   │   │   ├── export_record.py
│   │   │   ├── exports.py
│   │   │   ├── feature_engine.py
│   │   │   ├── features.py
│   │   │   ├── identity.py
│   │   │   ├── ingestion.py
│   │   │   ├── jobs.py
│   │   │   ├── labels.py
│   │   │   ├── mlflow_mirror.py
│   │   │   ├── mlprep.py
│   │   │   ├── monitoring.py
│   │   │   ├── notify.py
│   │   │   ├── orchestration.py
│   │   │   ├── pipeline.py
│   │   │   ├── policies.py
│   │   │   ├── predictions.py
│   │   │   ├── quality.py
│   │   │   ├── ratelimit.py
│   │   │   ├── readers.py
│   │   │   ├── registry.py
│   │   │   ├── retention.py
│   │   │   ├── retraining.py
│   │   │   ├── reverse_etl.py
│   │   │   ├── schemas.py
│   │   │   ├── sentiment.py
│   │   │   ├── signals.py
│   │   │   ├── sso.py
│   │   │   ├── timeline.py
│   │   │   └── training.py
│   │   ├── web/
│   │   │   ├── js/
│   │   │   │   ├── app.js
│   │   │   │   ├── charts.js
│   │   │   │   ├── core.js
│   │   │   │   ├── views_act.js
│   │   │   │   ├── views_data.js
│   │   │   │   ├── views_ml.js
│   │   │   │   ├── views_ops.js
│   │   │   │   ├── views_platform.js
│   │   │   │   └── views_signals.js
│   │   │   ├── app.css
│   │   │   ├── favicon.svg
│   │   │   └── index.html
│   │   ├── worker/
│   │   │   ├── __init__.py
│   │   │   ├── handlers.py
│   │   │   └── runner.py
│   │   ├── __init__.py
│   │   ├── __main__.py
│   │   ├── backup.py
│   │   ├── cli.py
│   │   ├── config.py
│   │   ├── db.py
│   │   ├── dbadmin.py
│   │   ├── errors.py
│   │   ├── logging_setup.py
│   │   ├── netguard.py
│   │   ├── netpolicy.py
│   │   ├── py.typed
│   │   ├── security.py
│   │   ├── storage.py
│   │   ├── synthetic.py
│   │   └── synthetic_text.py
│   └── churn_platform.egg-info/
│       ├── PKG-INFO
│       ├── SOURCES.txt
│       ├── dependency_links.txt
│       ├── entry_points.txt
│       ├── requires.txt
│       └── top_level.txt
├── tests/
│   ├── e2e/
│   │   ├── __init__.py
│   │   ├── conftest.py
│   │   └── test_ui.py
│   ├── __init__.py
│   ├── builders.py
│   ├── conftest.py
│   ├── fakes.py
│   ├── test_00_template.py
│   ├── test_analytics.py
│   ├── test_annotations.py
│   ├── test_api.py
│   ├── test_audit_policies.py
│   ├── test_auth.py
│   ├── test_backup.py
│   ├── test_cli.py
│   ├── test_crm.py
│   ├── test_destinations_postgres.py
│   ├── test_destinations_snowflake.py
│   ├── test_experiments.py
│   ├── test_explain.py
│   ├── test_export_delivery_api.py
│   ├── test_export_outbox.py
│   ├── test_export_record.py
│   ├── test_failed_first_record_does_not_advance_watermark.py
│   ├── test_features_pit.py
│   ├── test_ingestion.py
│   ├── test_jobs_worker.py
│   ├── test_lifecycle_orchestration.py
│   ├── test_migrations.py
│   ├── test_mlflow_mirror.py
│   ├── test_mlprep.py
│   ├── test_monitoring.py
│   ├── test_outbound.py
│   ├── test_pipeline.py
│   ├── test_quality.py
│   ├── test_readers_schemas.py
│   ├── test_register_130.py
│   ├── test_registry_predictions.py
│   ├── test_release_validator_rejects_stale_evidence.py
│   ├── test_retention.py
│   ├── test_schema_mismatch_fails_validation.py
│   ├── test_security.py
│   ├── test_security_platform.py
│   ├── test_signals.py
│   ├── test_snowflake_upgrade_plan.py
│   ├── test_tenant_id_prevents_crm_collisions.py
│   ├── test_timeline_labels.py
│   ├── test_traceability_tool.py
│   └── test_training_eval.py
├── var/
│   └── churn.db
├── .env.example
├── CHANGELOG.md
├── Dockerfile
├── README.md
├── docker-compose.yml
├── pyproject.toml
└── requirements.lock
```

## The source, area by area

## `src/churn_platform/`

| File | Purpose |
|---|---|
| `__init__.py` | (no module docstring) |
| `__main__.py` | (no module docstring) |
| `backup.py` | Backup and restore of an installation: the database, the data directory and a manifest that proves both. |
| `cli.py` | Command-line interface: ``churn-platform <command>`` (or ``python -m churn_platform``). |
| `config.py` | Centralised configuration. |
| `db.py` | Database engine, session factory and portable column types (SQLite + PostgreSQL). |
| `dbadmin.py` | Schema administration: Alembic migrations and a drift check, usable from an installed package. |
| `errors.py` | Application errors: every failure reaches the client as one consistent JSON envelope. |
| `logging_setup.py` | Structured logging with correlation IDs and secret redaction. |
| `netguard.py` | Outbound HTTP guard against server-side request forgery (SSRF). |
| `netpolicy.py` | Who is on the other end of a request, when the platform sits behind a reverse proxy. |
| `security.py` | Security primitives: password hashing, session tokens, TOTP (RFC 6238), secret encryption, RBAC. |
| `storage.py` | Locations of files the platform owns (raw imports, datasets, model artefacts). |
| `synthetic.py` | Deterministic SYNTHETIC subscription-business data generator. |
| `synthetic_text.py` | SYNTHETIC support messages in several languages, each written to carry one intended sentiment. |

Subdirectories: `api/`, `migrations/`, `models/`, `services/`, `web/`, `worker/`

### `src/churn_platform/api/`

The HTTP API (FastAPI), one router module per area

| File | Purpose |
|---|---|
| `__init__.py` | HTTP API (FastAPI).  ``create_app`` builds the application. |
| `app.py` | Application factory: middleware, error envelope, routers and the static single-page app. |
| `deps.py` | Request plumbing shared by all routers: authentication, permissions, units of work. |
| `routes_core.py` | Core routes: authentication, users, audit trail, jobs, policies and system information. |
| `routes_data.py` | Data routes: sources, uploads, imports, quarantine, data quality, labels, feature store, analytics. |
| `routes_exports.py` | Export routes: start a delivery, watch it, resume it, reconcile it (1.3.0). |
| `routes_ml.py` | Modelling and action routes: datasets, training, evaluation, explanations, registry, predictions, |
| `routes_platform.py` | Platform routes (1.1.0): model lifecycle and promotion gates, external orchestration, the MLflow registry. |
| `routes_signals.py` | Customer-signal routes (1.1.0): support sentiment, the product-feature catalogue and adoption, identity mapping |

Subdirectories: `routers/`

### `src/churn_platform/models/`

The ORM models, split by area; importing the package registers every table

| File | Purpose |
|---|---|
| `__init__.py` | All ORM models (importing this package registers every table on ``Base.metadata``). |
| `base.py` | Column helpers shared by every model module. |
| `core.py` | Foundation tables: tenants, users, sessions, audit trail, jobs, schedules, governed policies. |
| `data.py` | Data catalog, ingestion bookkeeping, canonical (cleaned) entities and data-quality tables. |
| `ml.py` | Labels, feature store, analytics, ML lifecycle, predictions, retention, CRM and monitoring. |
| `platform.py` | Integration and platform tables added in 1.1.0: orchestrator run history, model lifecycle transitions, |
| `signals.py` | Customer signals added in 1.1.0: support sentiment, the governed product-feature catalogue and adoption |

### `src/churn_platform/services/`

The business logic; every service is importable and testable without HTTP

| File | Purpose |
|---|---|
| `__init__.py` | (no module docstring) |
| `adoption.py` | The governed product-feature catalogue and feature adoption. |
| `analytics.py` | Exploratory analytics: portfolio overview, cohort retention heatmap, Kaplan-Meier survival and |
| `annotations.py` | Human labels for support text, so that sentiment accuracy can be measured on something real. |
| `attributes.py` | History of slowly changing customer attributes (industry, company size, employees, geography, channel). |
| `audit.py` | Append-only, hash-chained audit trail. |
| `auth.py` | Authentication, sessions, MFA (TOTP) and user administration. |
| `campaigns.py` | Retention campaigns: who gets which sequence of messages, when, and what happened. |
| `common.py` | Small helpers shared by all services: tenant-scoped lookups, pagination, JSON-safe serialisation. |
| `crm.py` | Reverse ETL to CRM / engagement tools (Salesforce, HubSpot, Intercom) through an outbox. |
| `crm_oauth.py` | CRM connections that sign in with OAuth 2.0 (authorization code), and signed events coming back from the CRM. |
| `customer360.py` | Customer 360: one customer's profile, subscription history, behaviour, risk and actions. |
| `demo.py` | Load the SYNTHETIC demo data set through the real ingestion pipeline (sources -> jobs -> worker). |
| `evaluation.py` | Model evaluation: PR-AUC first, calibration, lift, and cost-matrix threshold optimisation. |
| `experiments.py` | Retention experiments (randomised control) and uplift modelling. |
| `explain.py` | Explainability with SHAP: global importance, per-customer contributions and waterfalls. |
| `export_outbox.py` | The durable side of a delivery: the outbox, the run record and the tenant checkpoint (1.3.0). |
| `export_record.py` | The canonical prediction record every destination writes (1.3.0). |
| `exports.py` | Destination exports: the product path into the delivery layer (1.3.0). |
| `feature_engine.py` | Point-in-time feature engineering (pure functions over DataFrames; no database access). |
| `features.py` | Feature registry, approved feature contracts and the offline / online feature store. |
| `identity.py` | Who is "a user": the identity mapping behind daily active users. |
| `ingestion.py` | Dataset catalog and ingestion pipeline. |
| `jobs.py` | Durable job queue: enqueue, atomic claim with leases, heartbeats, retries, cancellation, recovery. |
| `labels.py` | Churn label generation under a versioned, approved churn definition. |
| `mlflow_mirror.py` | Optional mirror of registered model versions into an MLflow tracking server / model registry. |
| `mlprep.py` | ML dataset preparation: chronological split with purging and embargo, train-only preprocessing, |
| `monitoring.py` | Model and data monitoring: feature drift, prediction drift, realised performance, alert rules |
| `notify.py` | Outbound messages to customers: e-mail, SMS, push and in-app. |
| `orchestration.py` | Running pipeline steps for an external orchestrator (Apache Airflow). |
| `pipeline.py` | Nightly pipeline: data quality -> labels -> feature store -> batch scoring -> recommendations -> |
| `policies.py` | Versioned, independently-approved business policies. |
| `predictions.py` | Prediction engine: batch, scheduled and single-customer scoring with approved models only. |
| `quality.py` | Data validation and cleaning: versioned rules, scorecards, findings and approved corrections. |
| `ratelimit.py` | Rate limits that every server process shares. |
| `readers.py` | Streaming readers for every supported file format, plus schema discovery and mapping suggestions. |
| `registry.py` | Model registry: versions, promotion gates, independent approval, stage transitions.  Only an approved version |
| `retention.py` | Retention engine: turn a scored batch into tiered, reviewable next-best actions. |
| `retraining.py` | Automatic retraining, triggered by monitoring when realised performance breaches the approved |
| `reverse_etl.py` | Reverse ETL: governed syncs of risk scores and recommendations to where the business works. |
| `schemas.py` | Canonical entity schemas and value coercion used by ingestion, validation and reprocessing. |
| `sentiment.py` | Sentiment of support text. |
| `signals.py` | Keeps the derived customer signals in step with the canonical tables. |
| `sso.py` | Single sign-on with OpenID Connect (authorization-code flow with PKCE). |
| `timeline.py` | Point-in-time subscription timelines shared by churn labelling and feature engineering. |
| `training.py` | Model training: baseline + tree ensembles, class-imbalance handling, temporal cross-validation, |

Subdirectories: `destinations/`

### `src/churn_platform/services/destinations/`

Where predictions are delivered (1.3.0)

| File | Purpose |
|---|---|
| `__init__.py` | Where predictions go: a warehouse, a support desk, a marketing platform (1.3.0). |
| `base.py` | Destinations: where a prediction goes once it has been decided (1.3.0). |
| `postgres.py` | The PostgreSQL destination (1.3.0): a real destination that needs no vendor account. |
| `snowflake.py` | The Snowflake destination (1.3.0). |
| `snowflake_upgrade.py` | Upgrading a 1.2.0 warehouse table to the 1.3.0 identity (the plan, not the execution). |

### `src/churn_platform/worker/`

The background worker and its job handlers

| File | Purpose |
|---|---|
| `__init__.py` | (no module docstring) |
| `handlers.py` | Job handlers.  Importing this module registers every handler in ``services.jobs.HANDLERS``. |
| `runner.py` | Background worker process: claims jobs, runs handlers, heartbeats, schedules, graceful shutdown. |

### `src/churn_platform/web/`

The browser application served by FastAPI (no build step, no CDN)

Subdirectories: `js/`

## `scripts/`

Repository tooling: registers, matrices and release evidence

| File | Purpose |
|---|---|
| `acceptance_smtp_73.py` | The 1.2.0 SMTP acceptance, re-run here: 73 messages, one mail server, no vendor. |
| `build_1_2_0_register.py` | Render the 1.2.0 requirement register (Markdown) from its source of truth (JSON). |
| `build_1_3_0_feature_inventory.py` | Build ``docs/1_3_0_FEATURE_INVENTORY.md`` from the register and the source. |
| `build_1_3_0_file_structure.py` | Build ``docs/1_3_0_FILE_STRUCTURE.md`` from the tree as it actually is. |
| `build_1_3_0_matrix.py` | Build ``docs/1_3_0_REQUIREMENT_MATRIX.md`` from the register and the tests. |
| `build_1_3_0_register.py` | Build, validate and check the 1.3.0 requirement register. |
| `build_manifest.py` | Build, verify and package the release manifest. |
| `build_phase2_manifest.py` | Earlier name of ``build_manifest.py``, kept so that existing instructions keep working.  Same options, same result. |
| `build_traceability.py` | Build the requirements traceability matrix from a test run. |
| `check_crm_contracts.py` | Check the CRM requests the platform builds against the API descriptions the vendors publish. |
| `check_wheel.py` | Check that a built wheel carries every file of the package. |
| `gate_ledger.py` | Probe every gate the release declares, and write down what each one actually is at this commit. |
| `load_test.py` | Load test against a running server: throughput and latency of the screens people use, at several levels of |
| `load_test_delivery.py` | What the delivery path costs: records per second, the price of a failure, and a backlog query at size. |
| `record_test_run.py` | Record what a test run was, next to the JUnit file it produced. |
| `reverify_1_3_0_register.py` | Bring the 1.3.0 register's evidence up to the release commit, or refuse and say which entries cannot be. |
| `scan_secrets.py` | Fail when something that looks like a credential is committed. |
| `snowflake_upgrade_1_3_0.py` | Print the statements that upgrade a 1.2.0 Snowflake table to the 1.3.0 identity. |
| `update_1_3_0_register_defects.py` | Record the M1 defect fixes in the 1.3.0 register, from the evidence the runs produced. |
| `update_1_3_0_register_wiring.py` | Record the delivery-layer wiring, the measurements and the warehouse plan in the 1.3.0 register. |

## `deploy/`

Deployment assets (the Airflow DAG)

Subdirectories: `airflow/`

## `tests/`

The suite: one module per area, plus the browser tests in tests/e2e

| File | Purpose |
|---|---|
| `__init__.py` | (no module docstring) |
| `builders.py` | Hand-built point-in-time frames for label and feature tests (no database involved). |
| `conftest.py` | Shared fixtures. |
| `fakes.py` | Stand-ins for systems outside the platform, shared by several test modules. |
| `test_00_template.py` | The seeded template itself: built by migrations + the real seed service. |
| `test_analytics.py` | Descriptive analytics: churn overview, cohort retention, Kaplan-Meier survival, churn-rate profile. |
| `test_annotations.py` | Human labels for support text: two reviewers, the agreement between them, adjudication, freezing, export (1.2.0). |
| `test_api.py` | The HTTP API: access control for every route, the error envelope, tenant isolation and the write flows. |
| `test_audit_policies.py` | Tamper-evident audit log and versioned, four-eyes-approved policies. |
| `test_auth.py` | Sign-in, sessions, lockout, MFA and user administration (service level). |
| `test_backup.py` | Backup and restore, with a real restore (1.2.0). |
| `test_cli.py` | The command line.  Commands run as real subprocesses (``python -m churn_platform ...``), the way an operator, |
| `test_crm.py` | Reverse ETL to CRM tools: request shapes, the outbox, retries, TEST_ONLY / SANDBOX / PRODUCTION modes, SSRF guard. |
| `test_destinations_postgres.py` | A destination that is a real database, exercised against a real server (1.3.0). |
| `test_destinations_snowflake.py` | Destinations: the obligations every one of them shares, and the Snowflake adapter in particular (1.3.0). |
| `test_experiments.py` | Retention experiments (randomised control) and uplift modelling with its guardrails. |
| `test_explain.py` | SHAP explanations: exact additivity, feature-level aggregation, waterfalls that end at the served probability. |
| `test_export_delivery_api.py` | The delivery layer, reachable from the product (1.3.0, R-98). |
| `test_export_outbox.py` | The outbox, the run record and the tenant checkpoint (1.3.0). |
| `test_export_record.py` | The canonical prediction record: one description of a prediction for every destination (1.3.0). |
| `test_failed_first_record_does_not_advance_watermark.py` | A failed record must not advance the watermark, and the checksum must cover what was acknowledged (1.3.0, BUG 1). |
| `test_features_pit.py` | Point-in-time correctness of the feature engine. |
| `test_ingestion.py` | Ingestion: immutable dataset versions, mapping, validation, quarantine, idempotency, reconciliation, |
| `test_jobs_worker.py` | Durable job queue and worker: idempotency, retries, cancellation, leases, schedules. |
| `test_lifecycle_orchestration.py` | Model lifecycle with promotion gates, the MLflow registry as registry of record, and pipeline steps run for an |
| `test_migrations.py` | Schema migrations: upgrade, drift against the ORM models, downgrade, on SQLite and PostgreSQL. |
| `test_mlflow_mirror.py` | MLflow: off by default; with a tracking store, every registry entry is created there once and kept in line (tags and |
| `test_mlprep.py` | Training data assembly: chronological splits, purging, train-only preprocessing, leakage checks, TEST quarantine. |
| `test_monitoring.py` | Monitoring: feature drift (PSI + two-sample tests), prediction drift, realised performance, alert rules, |
| `test_outbound.py` | What leaves the platform (1.1.0): CRM sign-in with OAuth and signed CRM events, governed reverse-ETL syncs, |
| `test_pipeline.py` | The nightly chain (data quality -> labels -> features -> scoring -> recommendations -> monitoring), |
| `test_quality.py` | Data-quality rules, scorecards, and four-eyes corrections with full history. |
| `test_readers_schemas.py` | File readers, schema discovery, mapping suggestions and value coercion. |
| `test_register_130.py` | The 1.3.0 register: one file, generated summaries, and checks that refuse to flatter. |
| `test_registry_predictions.py` | Model registry (approval, promotion) and batch / single scoring with risk tiers and reasons. |
| `test_release_validator_rejects_stale_evidence.py` | The release validator must not pass on evidence from another commit (1.3.0, BUG 4). |
| `test_retention.py` | Retention tiers (white-glove, automated, involuntary), eligibility blocks, review, execution and outcomes. |
| `test_schema_mismatch_fails_validation.py` | The schema the session is in must be the schema the configuration names (1.3.0, BUG 2). |
| `test_security.py` | Credentials, tokens, TOTP, secrets at rest, role model and configuration guard rails. |
| `test_security_platform.py` | Security additions of 1.1.0: request limits shared by all server processes, trust in forwarded headers, |
| `test_signals.py` | Customer signals (1.1.0): support sentiment, feature adoption, identity and active users, attribute history. |
| `test_snowflake_upgrade_plan.py` | The warehouse upgrade plan: statements that can be read before they are run (1.3.0). |
| `test_tenant_id_prevents_crm_collisions.py` | Tenant identity: two tenants' records must never collide (1.3.0, BUG 3). |
| `test_timeline_labels.py` | Churn labels: the target is "churns within [T, T + horizon)", derived from subscription events. |
| `test_traceability_tool.py` | The evidence chain: test markers -> JUnit report -> scripts/build_traceability.py -> traceability matrix. |
| `test_training_eval.py` | Model training (imbalance handling, temporal CV, calibration) and evaluation (PR-AUC first, cost-based threshold). |

Subdirectories: `e2e/`

## `tests/e2e/`

End-to-end tests through a real browser (Playwright)

| File | Purpose |
|---|---|
| `__init__.py` | (no module docstring) |
| `conftest.py` | Browser tests: a real server process (with its embedded worker), a real Chromium, the seeded demo tenant. |
| `test_ui.py` | The web application in a real browser, against a real server. |

## `docs/`

Release documents, the requirement register and the traceability catalogue

Subdirectories: `brief/`, `traceability/`

#### `src/churn_platform/migrations/versions/`

Alembic revisions, one file per release, applied in order

| Revision | Purpose |
|---|---|
| `0001_baseline.py` | Baseline schema of the clean-room rebuild (1.0.0): all 56 tables. |
| `0002_signals_platform.py` | 1.1.0: customer signals and platform integrations. |
| `0003_smtp_provider.py` | 1.1.1: the e-mail channel can be delivered through an SMTP server. |
| `0004_annotation.py` | 1.2.0: people label support text, so that sentiment accuracy can be measured on something other than templates. |
| `0005_export_outbox.py` | 1.3.0: the export outbox, so a delivery run can be resumed instead of guessed at. |

## What is deliberately not in this document

- no file contents: the structure is the map, the code is the territory;
- no `.env`, key, certificate or credential file is read or listed;
- no `release/` artefacts: they are build output, and the manifest of a release is described in
  `docs/1_3_0_FINAL_TEST_REPORT.md` instead.
