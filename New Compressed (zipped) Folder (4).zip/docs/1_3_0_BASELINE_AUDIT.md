# 1.3.0 — baseline audit

Taken at the start of 1.3.0, on the 1.2.0 tree, before any source change. Everything below was read or run on this
machine; nothing is carried over on trust.

| | |
|---|---|
| Repository | `churn-platform`, branch `main` |
| Commit audited | `0224654` ("1.2.0: fix pg_dump/pg_restore URL, measure the release on PostgreSQL, finish the reports"), tree clean |
| Tag | `v1.2.0` on `0224654` |
| Version in the source | `1.2.0` (`pyproject.toml`, `src/churn_platform/__init__.py`, `/healthz`) |
| Tests collected | **498** (`pytest --collect-only`, this machine) |
| Migrations | `0001_baseline`, `0002_signals_platform`, `0003_smtp_provider`, `0004_annotation` |
| API surface | 202 operations in the access-rule table (`tests/test_api.py`), five route modules, 2,610 lines |
| Services | 39 modules under `src/churn_platform/services/` |
| Frontend | one FastAPI-served browser application: 31 routes in `app.js`, 26 navigation entries, 2,836 lines of ES modules, no build step, no React |
| Archive of record | `churn-platform-1.2.0.zip`, 186 files, SHA-256 `56daea5d…d88eac`, manifest inside |
| Register of record (1.2.0) | 58 requirements; counts corrected on 1.3.0, see `docs/1_2_0_RECONCILIATION.md` |
| Register of record (1.3.0) | `docs/1_3_0_requirements.json`, **91 requirements**, counts computed from the entries |

## The machine changed under us

The build sandbox was reset between the 1.2.0 release and this audit. Facts that the 1.2.0 documents state, and what is
true now:

| | 1.2.0 release documents | At this audit |
|---|---|---|
| Python | 3.13.16 (system), plus 3.11.18 and 3.12.16 interpreters | **3.13.18**; the 3.11 and 3.12 interpreters are gone and must be rebuilt |
| PostgreSQL | 16 | **17** |
| Dependencies | installed in `/opt/venvs/*` | gone; reinstalled from `requirements.lock` into the system interpreter for this audit |
| `/var/tmp` helper scripts | the release's run scripts | gone; recreated as needed |
| Browser for the E2E tests | Chromium 1254 with its system libraries | gone; reinstalled (`playwright install chromium` and `install-deps`) |
| Sentiment model | fetched under `<data root>/models/sentiment/<pin>` | fetched again; note that `CHURN_TEST_SENTIMENT_MODEL_DIR` must point at `models/sentiment`, not the data root |

This matters for one reason: **no 1.2.0 result may be presented as a 1.3.0 result.** The suite is 498 tests on the
1.2.0 source, executed on 3.13.16 with PostgreSQL 16. It has not yet been run on 3.13.18 with PostgreSQL 17, on the
1.3.0 source. That run happens before 1.3.0 is released, twice, and the register's `verified_at` fields only move when
it does.

## What is actually here

Read from the source, not from the reports:

| Area | In the code | Honest condition |
|---|---|---|
| Ingestion, quality, identity, attributes, labels | `services/{ingestion,quality,identity,attributes,labels,readers,schemas}.py` | working, tested |
| Sentiment | `services/sentiment.py` (ONNX + lexical baseline), model fetch/verify CLI | working; needs a real labelled set to say anything about accuracy (R-27) |
| Annotation | `services/annotations.py`, migration `0004`, 12 routes, permission `signals:annotate` | working, tested |
| Feature store, adoption, ML prep, training, evaluation, SHAP | `services/{feature_engine,features,adoption,mlprep,training,evaluation,explain}.py` | working, tested |
| Prediction and Customer 360 | `services/{predictions,customer360,retention}.py` | working, tested |
| CRM | `services/{crm,crm_oauth}.py`, three adapters, contract checker | adapters built to the vendors' descriptions; no vendor has accepted a request |
| Reverse ETL | `services/reverse_etl.py` (PostgreSQL analytical, file export) | no Snowflake, Zendesk or Marketo |
| Messaging | `services/{notify,campaigns}.py`: SMTP (real server proven), SendGrid/SES/Twilio/FCM request builders, dry run, quiet hours | no vendor account; no open/click tracking; no APNs; no device-token registry |
| Orchestration | `deploy/airflow/churn_nightly_dag.py`, `services/orchestration.py` | one DAG; a single scheduler execution once |
| MLflow | `services/mlflow_mirror.py`, `services/registry.py` | local tracking only |
| Security | `security.py`, `netguard.py`, `netpolicy.py`, `services/ratelimit.py` | DB-shared limiting, OIDC against local Keycloak, no Redis, no production TLS |
| Operations | `backup.py`, `cli.py`, `scripts/*` | backup and verified restore, on SQLite and PostgreSQL |
| Deployment | `Dockerfile`, `docker-compose.yml` | the 1.1.0 image was built; **no 1.2.0 image exists** |

## The five inconsistencies, confirmed and corrected

Each was checked against the source and the artefacts, not taken from the audit that reported it. Every change is
listed, with its before and after, in `docs/1_2_0_RECONCILIATION.md`; nothing was rewritten silently and no historical
result was altered to make a story tidier.

| # | Claimed problem | What the repository actually showed | Correction |
|---|---|---|---|
| 1 | The register's counts do not reconcile to its entries | `docs/1_2_0_requirements.json` `meta.counts` said **PASS 23, PARTIAL 16, NOT_IMPLEMENTED 9, BLOCKED 8, NOT_APPLICABLE 2** while its entries said **28 / 14 / 6 / 8 / 2**. Both total 58, which is why it survived. `meta.source_commit` also said `443aa03` (the 1.1.1 commit) | counts recomputed from the entries and made a generated field; `meta.source_commit` corrected to `0224654`; the 1.3.0 register computes its counts on every run and `--check` fails if the document disagrees |
| 2 | R-48 is PASS while deployment documents say the image was not built | R-48's own evidence text read "Image 1.1.0 built and run … the 1.2.0 image has to be rebuilt" | R-48 moved to **PARTIAL**; the 1.3.0 register carries the corrected status and the reason |
| 3 | Security gate 5 said both PASS and NOT_IMPLEMENTED | The generated traceability said **GATE 5 NOT_IMPLEMENTED**; `docs/1_2_0_SECURITY_REPORT.md` said the gate was satisfied and R-44 was PASS, with three clean commands behind it | gate table corrected to **PASS**, with the tool results named; the correction is recorded because the generated table was wrong, not the tooling |
| 4 | 493 tests and migrations 0001–0003 quoted against 498 and `0004` | R-46's evidence said "All 493 tests … migration 0003"; the release actually ran **498** tests and migration `0004` is present and tested | R-46's evidence corrected; R-56's "493-test baseline" text corrected to the 498 that ran |
| 5 | Six secret-scan suppressions against a later nine | `scripts/scan_secrets.py` suppresses **nine** matches today, all of them the same rule ("password in a URL"), while the security report said six | the report now says nine and names the rule; R-44's evidence likewise |

The lesson is in the 1.3.0 design rather than in the fixes: **counts and gate tables are now generated from one
machine-readable register** (`docs/1_3_0_requirements.json` → `scripts/build_1_3_0_register.py`), so a second summary
of the same fact cannot drift from the first.

## What this audit did not establish

Nothing in this document is a current result for 1.3.0. The 498-test figure is collection on the 1.3.0 host, not a run.
No 1.3.0 source change exists yet, so there is no 1.3.0 result of any kind. The first real evidence appears in
`docs/1_3_0_EXISTING_FEATURE_REGRESSION.md` once the baseline suite has been executed on this machine, and it is that
run — not the 1.2.0 report — that the 1.3.0 work is built on.
