# 1.2.0 — disaster recovery report

The master prompt is blunt about this and it is right: *a successful backup command does not prove recovery*. So the
deliverable is not the command, it is a restore that was performed and compared.

## What exists now

| Command | What it does |
|---|---|
| `churn-platform backup --to FILE [--data-dir DIR] [--note TEXT]` | writes one `.tar.gz`: the database (SQLite via `VACUUM INTO`, PostgreSQL via `pg_dump --format=custom`), the data directory, and `manifest.json` with the schema revision, the creation time, and the size and SHA-256 of every member |
| `churn-platform restore --from FILE [--force]` | verifies every checksum and the archive's own structure first (traversal-checked member names, non-file members skipped), refuses to overwrite an existing database without `--force`, then restores and runs a health check (revision, row counts for eleven tables, newest audit event) |
| `churn-platform backup-check --from FILE` | says whether an archive matches its manifest, without restoring it |

Exit codes: `0` when the check or the restore is good, `1` when the restored revision does not match the manifest.

## The exercise that was actually run

`tests/test_backup.py::test_an_archive_restores_to_the_same_database_and_a_tampered_one_does_not_restore_at_all`,
against the seeded reference tenant, on the database engine the installation uses:

1. take an archive of a live, seeded database plus its data directory;
2. confirm the archive's own SHA-256 and that `backup-check` reports it valid;
3. **delete the database file and the data directory**;
4. restore from the archive alone, into the empty place;
5. compare: every one of the eleven tables has the same row count as before, the restored revision matches the
   manifest, and the data directory is back;
6. try to restore over the now-existing database without `--force` → refused;
7. restore with `--force` → succeeds, revision matches;
8. truncate the archive to half its length → refused, and the database is unchanged afterwards;
9. replace the `database` member with other bytes while keeping the original manifest → `valid: false`, the checksum
   mismatch is named, the restore is refused, and the database is still unchanged.

That is a restore, a refusal and two kinds of tampering, not a printed file size.

## What this is not

| Requirement | State | Owner |
|---|---|---|
| RPO and RTO agreed with the system owner | BLOCKED | the owner must name the numbers; nothing here can invent them (GATE 15) |
| A schedule that takes backups | NOT_IMPLEMENTED deliberately | cron, a Kubernetes CronJob or a managed service is the deployment's job; the command is the piece only the product can supply |
| Encrypted backups and off-site retention | NOT_IMPLEMENTED deliberately | belongs to the storage layer and a key manager; an archive written to a local disk by a product is not a backup strategy |
| A restore in the authorised staging environment | BLOCKED | needs that environment (GATE 11) |
| Model-artefact and feature-snapshot backup | PARTIAL | the data directory (which holds them) is in the archive; there is no separate manifest for artefacts |
| Secret recovery | BLOCKED | secrets are the deployment's, not the database's |

The runbook below is what an operator needs; it is written to be followed at three in the morning.

## Runbook: restoring after a failure

1. **Stop the writers** — `kubectl scale deploy/churn-api deploy/churn-worker --replicas=0`, or stop the two processes.
2. **Find the newest archive** that passes `churn-platform backup-check --from <file>`. Do not pick by file date; pick
   by what verifies.
3. **Decide the target.** A restore replaces the database: `--force` when the target exists, and the data directory
   with it. Take a copy of the damaged database first — it is evidence.
4. **Restore**: `churn-platform restore --from <file> --force`. Exit code 0 and `revision_matches: true` are the
   acceptance; anything else stops here.
5. **Check the application, not just the database**: `churn-platform db-status` (no drift), `GET /readyz`, then the
   screen the affected team uses.
6. **Restart the writers** and watch the queue: messages and jobs that were in flight resume from the queue, and the
   idempotency keys make a repeated delivery a no-op rather than a second message.
7. **Write down what was lost**: the gap between the last good archive and the failure is the actual RPO achieved on
   that day. It belongs in the incident record, not in a promise.

## A measured PostgreSQL round trip (1.2.0)

Beyond the SQLite exercise in `tests/test_backup.py`, the same commands were run against a live PostgreSQL database
at demo scale on 2026-11-12:

| Step | Time | Result |
|---|---|---|
| `churn-platform backup --to perf_120.backup` | 1.90 s | 3,427,004 bytes, sha256 `f969016…`, engine `pg_dump`, revision `0004`, 21 members |
| `churn-platform backup-check --from …` | < 0.2 s | valid, no member failed its checksum |
| `churn-platform restore --from … --force` into an empty database | 3.37 s | revision `0004`; eleven table counts identical to the source (300 customers, 33,952 usage events, 473 predictions, 228 audit events, …) |

The first attempt at that backup failed — `pg_dump` was being handed a SQLAlchemy URL with a `+psycopg` suffix and
fell back to a local socket and the operating system's user name. The scheme is now translated (`backup.libpq_url`)
before either client tool is called, and a test holds it. A backup command that cannot back up the production engine
is exactly the kind of thing this report is supposed to catch, and only running it did.
