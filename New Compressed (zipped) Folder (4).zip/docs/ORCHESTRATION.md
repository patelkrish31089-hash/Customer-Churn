# Orchestration and the model lifecycle

## Who starts the nightly pipeline

The pipeline has seven steps, in this order:

    data_quality → signals → labels → features → scoring → recommendations → monitoring

Exactly one orchestrator starts it. `CHURN_ORCHESTRATOR` says which:

| Value | Who starts the steps | The other one |
| --- | --- | --- |
| `platform` (default) | the platform's own schedule (Jobs & pipeline) | calls from Airflow are refused with a clear message |
| `airflow` | an Airflow DAG, one task per step | the platform's schedule stands down; its job ends as "skipped" with the reason |

Set the same value for the API, the worker and the Airflow workers. An operator can still run one step by hand on
an installation the platform schedules: `pipeline-step … --force`.

### With Apache Airflow

`deploy/airflow/churn_nightly_dag.py` defines one task per step. Each task runs

    churn-platform pipeline-step --tenant <slug> --step <step> --run-key '{{ dag_run.run_id }}' --wait

The command is idempotent per (tenant, step, run key):

- the step has not run for this key → it is started; the command waits for it (exit 0 succeeded, 1 failed);
- the step is still running (the task was retried while the first attempt was alive) → the command waits for the
  same jobs and starts nothing;
- the step already succeeded → the command does nothing and exits 0;
- the step failed → it is started again (attempt 2, 3 …).

So Airflow may retry or re-run tasks freely; a customer base is never scored twice for one DAG run. Scoring itself
is also idempotent per scoring date: a date that already has scores is not scored again.

A platform worker (`churn-platform worker`) must be running; the task queues the step and waits. Add `--inline` to
execute the jobs inside the task when there is no separate worker. Exit code 3 means "still running" (without
`--wait`, or the wait timed out).

Every run is on record (`Operations → Orchestration`, `GET /api/v1/pipeline/orchestration`): step, run key,
attempts, job ids, the date scored, errors.

### What was run for this release

On Airflow 3.4.0, with `airflow dags test churn_nightly_pipeline`, twice, against a copy of the reference demo
with `CHURN_ORCHESTRATOR=airflow` and a platform worker running:

- all 8 tasks (the schema check and the seven steps) succeeded on the first try, in order;
- the platform recorded the seven steps of each DAG run under that run's id, with the DAG id and the task id;
- the scoring step reported "skipped": the demo's date had been scored when the demo was seeded, and a date is
  scored once. Predictions and recommendations were the same before and after (1,691 and 369);
- repeating `pipeline-step` by hand with a run id that had already run answered "already done" with exit code 0
  and started no job;
- with `CHURN_ORCHESTRATOR=platform` the command was refused with exit code 2 and a message that says why.

Not run for this release: the DAG under a scheduler with an executor, a task retried by Airflow after a failure,
Airflow 2, several nights in a row. A night in which the scoring step has something to score, and the retry of a
failed step, are covered by the automated tests (`tests/test_lifecycle_orchestration.py`), which drive the same
command without Airflow.

## The model lifecycle

    candidate → validated → approved → staging → production → archived        (or: rejected)

| State | How a version gets there |
| --- | --- |
| candidate | a completed training run is registered |
| validated | it passes the promotion gates (`Validate` on the registry screen, or automatically at approval) |
| approved | a second person approves it (never its author); the gates are checked again |
| staging / production | promoted by a person; promoting to production archives the previous production version |
| archived | replaced, or archived by hand; promoting an archived version again is a rollback |
| rejected | the reviewer rejected it; it can never be promoted |

Every attempted transition is written to `model_stage_transitions` — applied or blocked — with the gate results it
was decided on (`History` on the registry screen).

### Promotion gates

A policy of kind `promotion_gates` (Policies screen; a new version needs a second person's approval):

| Gate | Passes when |
| --- | --- |
| `min_test_pr_auc`, `min_test_roc_auc` | the final test evaluation is at least the threshold |
| `max_brier`, `max_calibration_error` | the final test evaluation is at most the threshold |
| `min_test_rows`, `min_test_positives` | the test period is large enough to mean something |
| `max_pr_auc_drop_vs_production` | test PR-AUC is not more than this below the production model's (the two test periods may differ; the gate says so) |
| `require_leakage_checks` | the training dataset's leakage checks passed |
| `require_reproducible_training` | a seed and a dataset fingerprint are recorded and the model file still has its recorded checksum |
| `require_model_card` | the validation evaluation and the final test evaluation both exist |

A threshold left empty is reported as "not checked", not as passed. Without an approved policy the three
`require_…` gates apply and no metric threshold does. A version that fails a gate cannot be approved. These ten are
all the gates; a policy that names any other key is refused. Approval by a second person is not a gate and no
policy can switch it off: it is a rule of the installation (`CHURN_ALLOW_SELF_APPROVAL`, development only).

### MLflow

With `CHURN_MLFLOW_TRACKING_URI` set (package extra `mlops`), every registry entry is created once in the MLflow
Model Registry (parameters, metrics, the model file, a model card) and kept in line afterwards: tags
(`platform.lifecycle_state`, `platform.validated`, `artifact.sha256` …) and three aliases:

- `validated` — the newest version that passed the gates and is neither rejected nor archived
  (`mlflow_mirror.latest_validated`): "the latest validated model" of the brief;
- `staging`, `production` — the versions in those stages.

`CHURN_MODEL_REGISTRY` decides which registry is the registry of record:

| Value | What serves |
| --- | --- |
| `platform` (default) | the platform's production version; MLflow, when configured, follows |
| `mlflow` | the version MLflow's `production` alias names — and only if it is the same version this platform holds as production and the model file here has the checksum MLflow registered. If MLflow cannot be reached, or the two disagree, nothing is served and the error says which. |

A promotion reaches MLflow through a background job, so with `mlflow` as the registry of record a newly promoted
model starts serving when that job has finished.
