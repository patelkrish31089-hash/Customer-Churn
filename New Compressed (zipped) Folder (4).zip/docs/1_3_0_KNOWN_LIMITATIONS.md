# 1.3.0 — known limitations

Written to be read before the release notes, not after. Every line is something a reader could otherwise assume was
finished. Where a limitation has a requirement id, the register carries the same sentence, so the two cannot drift.

The four labels used across this release are kept apart on purpose and are never merged:

| Label | What it means | What it does not mean |
|---|---|---|
| **LOCALLY VERIFIED** | a command was run on this machine, at the commit named, and its result is quoted | that a vendor, a customer or a second machine would see the same |
| **INTEGRATION VERIFIED** | two or more real components exchanged real requests locally (the platform's own API, database, worker, browser) | that a third-party service was involved |
| **PDF COMPLIANT** | the brief's requirement is met by code that exists and is executed | that the brief's *intent* is met in a customer's environment |
| **PRODUCTION ACCEPTED** | a live installation, with real credentials and real data, accepted it | — and **nothing in this release carries this label** |

## The delivery layer delivers to a real database, and has never spoken to a vendor

The canonical record, the destination pipeline, the Snowflake adapter and the outbox have callers: seven routes under
`/exports` behind `customers:read` and `customers:export`, a worker handler that drains `export.run`, and a **Destination
exports** screen that loads for all eight roles in a browser test.

At 1.3.0 the pipeline also delivers to something **real**. `services/destinations/postgres.py` is a destination for the
PostgreSQL this platform already runs; `tests/test_destinations_postgres.py` starts an export through the API, lets the
worker drain it, and finds the rows with an independent connection, plus the run's own row beside them. The identity
constraint is enforced by the server, the upsert is executed by the server, and a column someone added with `NOT NULL`
turns the write into recorded failures rather than a lost batch.

What that still does **not** buy:

- **no vendor has ever received a record.** PostgreSQL is a database, not a warehouse: no `MERGE`, no micro-partitions,
  no time travel. The statement GATE 12 has to accept has never been sent to an account, because there is no account.
- **the failure path is quadratic in destination calls.** Measured, twice, on two machines: ten refused records in a
  10 000-record run turn 20 batch calls into **5 020** single-record calls. At zero latency it costs nothing; against a
  warehouse charging 100 ms per call it costs about eight minutes. Batching is a 1.3.x item.
- **the browser test loads the screen; it does not start a run from it.** Starting, resuming and reconciling are
  covered through the API and, for PostgreSQL, read back from the table.
- **`record_run()` writes one upsert per record**: 835 rows/s on PostgreSQL, so a 100 000-record run spends about two
  minutes writing its own run record after the last acknowledge.

## Every blocked gate is now a probe that ran

Before this release the register's gates were words in a table: "BLOCKED" could mean "we need an account" or "nobody
got to it", and no reader could tell. `scripts/gate_ledger.py` probes all fifteen and `docs/1_3_0_GATES.md` is
generated from the answers, with `--check` refusing to leave it stale. At `3079f49` the probes found:

| State | Gates |
|---|---|
| PASS (decided on this machine) | 1 — a live PostgreSQL 17.12 with the migration and delivery tests passing in both release runs; 6 — ruff, pip-audit and the secret scan clean, bandit with 0 findings at high or medium; 3 — 176 of 176 lock pins installed at the locked version |
| BLOCKED (precondition absent, named) | 11 — no vendor account, no host, no assessor, no Redis, no docker, no airflow |
| NOT_IMPLEMENTED | 1 — there is no deletion path to probe |

A probe may narrow a gate and may never promote one: finding `CHURN_SES_REGION` set is not an acceptance run. GATE 3
stays PARTIAL in the release's own declaration even though the probe passes, because the gate asks for three
interpreters and this machine has one — and the document prints both answers side by side instead of reconciling them.

Two things the probes exposed, both now fixed or stated: `bandit` exits **1** on this tree while reporting **0**
findings, because 95 `# nosec` markers suppress nothing and bandit counts that as a warning; the gate reads the JSON
report and prints the marker count rather than either ignoring it or failing on it.

## The SMTP acceptance can be repeated, and still is not a provider

`R-13` (73 of 73 messages accepted by a real SMTP server) was PASS at 1.1.1, withdrawn to PARTIAL at 1.3.0 because the
server was not in the environment, and is PASS again: `scripts/acceptance_smtp_73.py` sends 73 messages through the
platform's own transport to **aiosmtpd**, an SMTP implementation this repository did not write, and 73 of 73 are
accepted and received with their reference header. GATE 13 stays BLOCKED — a protocol acceptance against a local server
says nothing about a provider's reputation, bounce handling or deliverability.

## Two PASSes from 1.2.0 were withdrawn at 1.3.0

`R-13` (73 of 73 messages accepted by a real SMTP server) and `R-38` (Keycloak 26.0 sign-in) were recorded as PASS
during 1.1.1/1.2.0 on machines that had Mailpit and a Keycloak realm. Neither exists here, so neither can be repeated,
and a PASS that cannot be repeated is history. Both are now PARTIAL, with the original observation kept in the entry and
the next step spelled out. Nothing about the code changed; the register simply stopped claiming a current result it
could not produce.

## No vendor acceptance of any kind

| Vendor | What would be needed | State |
|---|---|---|
| Snowflake | an account, a warehouse, a database, a schema and a role that may write | GATE 12, **BLOCKED** |
| Zendesk, Marketo | a sandbox each, with API credentials | GATE 12, **BLOCKED** |
| Salesforce, HubSpot, Intercom | an OAuth client and a sandbox per vendor | GATES 9, **BLOCKED** |
| Apple APNs, Firebase FCM | a developer account and a key per platform | GATE 11, **BLOCKED** |
| SMTP, SMS | a sending account | GATE 10, **BLOCKED** |
| An identity provider | a tenant and an application registration | GATE 9, **BLOCKED** |

No test in this repository claims otherwise. The Snowflake adapter's stand-in connection is named as a stand-in in the
module docstring and in the test module's header.

## The existing warehouse table is planned for, and not migrated

The destination DDL is `CREATE TABLE IF NOT EXISTS`, and the record schema moved from `1.0.0` to `1.1.0` because
`TENANT_ID` was added as a required column. A warehouse table created by an earlier build **is not altered by the
application**, and no backfill runs on its own.

What exists is a reviewed plan and a printer, not a migration: `services/destinations/snowflake_upgrade.py` emits the
six steps — inspect `INFORMATION_SCHEMA`, `ADD COLUMN IF NOT EXISTS "TENANT_ID"`, `UPDATE … WHERE "TENANT_ID" IS NULL`
with the tenant id **bound as a parameter**, a null count that must be zero before anything else runs, a destructive
replacement of the primary key withheld unless `--destructive` is passed, and a rows-versus-distinct-identities
verification query. 11 tests pin the statements and the withholding. **Nothing has been executed against a warehouse**,
because there is none (GATE 12), and the plan is worth exactly what a plan that has never met a real table is worth.

## Release evidence is bound to a commit, not to a build

`build_1_3_0_register.py --release` refuses evidence from another commit, without a sidecar, with failures, with errors
and with skips, and it requires two runs to agree. It cannot detect a fabricated JUnit file that was given a matching
sidecar by hand, and it cannot tell whether the tests that ran were the right ones: a deleted test file would simply not
appear. `--min-tests` against the recorded baseline is the guard for the size of the suite.

## Higher migrations remain additive but untested upwards

Migration `0005` is additive and its downgrade drops exactly what it created; it is exercised on SQLite (the suite's
working database) and on PostgreSQL 17.11 (one test drops the schema, upgrades to head, inspects, downgrades to `0004`
and checks the 1.2.0 tables are intact). A downgrade across several releases at once — `0005` to `0002` — was not run.

## What the suite does not cover

- the browser tests run one Chromium against the application served by FastAPI; no other browser was used;
- the sentiment transformer test requires a downloaded model directory and is skipped without it — under
  `CHURN_TEST_STRICT=1` a missing prerequisite fails rather than skips, and the release run uses strict mode;
- the 1.3.0 figures in `docs/1_3_0_PERFORMANCE_REPORT.md` were measured on 2 vCPU / 2 GB with the load generator on the
  server's host, at up to 32 concurrent clients, against one API process; nothing above 32 clients, no multi-worker
  topology and no vendor latency is measured;
- there is no penetration test, no third-party security review, and no audit of the encryption at rest beyond what
  `docs/1_2_0_SECURITY_REPORT.md` records.

## Data: synthetic, and labelled as synthetic

Every figure in the demo installation comes from the deterministic synthetic generator, and the records that carry it
say so (`is_synthetic`). No customer data was used. A model trained on this data can be evaluated and compared, and no
accuracy measured on it is evidence about a real portfolio.

## One process, one machine, by default

The installation is a single FastAPI process, a worker and a database. The rate limiter and the job queue are
database-backed and safe across processes, but nothing in this release was run as a multi-node deployment, and no
horizontal-scaling claim is made.
