# What leaves the platform: CRM, reverse ETL, messages, campaigns

Nothing in this document sends anything by default. CRM connections start in `TEST_ONLY`, message providers in
`DRY_RUN`, campaigns as dry runs. Each of the three has to be changed deliberately, and each change is audited:

| To send for real | Who can do it | The installation must allow it |
| --- | --- | --- |
| A CRM connection in `SANDBOX` or `PRODUCTION` mode | an administrator, when creating the connection (a connection's mode cannot be changed afterwards) | `PRODUCTION`: `CHURN_CRM_ALLOW_PRODUCTION=true` |
| A message provider out of `DRY_RUN` | a person with the approval permission for messages (approver, administrator) | `LIVE`: `CHURN_NOTIFY_ALLOW_LIVE=true` |
| A campaign that is not a dry run | a second person approves the campaign (never its author); a person with the approval permission starts it and switches the dry run off | |
| A reverse-ETL sync | a second person approves it (never its author) | |

**Not verified against the vendors.** No vendor credentials or sandboxes were available when this release was
built. Request shapes were written from the vendors' public documentation and are exercised in the test suite
against stand-in transports that check them field by field; no request of this document has been accepted by a
real Salesforce, HubSpot, Intercom, SendGrid, Amazon SES, Twilio, Firebase or Apple endpoint. See
`docs/LIMITATIONS.md` for the status of each.

## CRM sign-in with OAuth

A CRM connection can use an access token you paste (as in 1.0) or OAuth 2.0 (authorization code):

1. `Syncs & exports → Set up OAuth`: client id and secret of the app you registered in the CRM. Redirect address
   to register there: `<CHURN_PUBLIC_BASE_URL>/api/v1/crm/oauth/callback`.
2. `Connect`: the browser goes to the CRM's consent screen and comes back. The platform exchanges the code (with
   PKCE for Salesforce), stores access and refresh token encrypted, and for Salesforce takes the instance URL.
3. Tokens are refreshed 90 seconds before they expire, and once more when the CRM answers 401. If the CRM refuses
   the refresh, the connection is marked "needs a new authorisation", deliveries wait (nothing is sent with a token
   known to be dead), and `Connect` fixes it.
4. `Disconnect` revokes the token at the CRM where the CRM offers that (Salesforce) and always erases it here.

Default endpoints: Salesforce `login.salesforce.com` (use `oauth_endpoints` for a sandbox), HubSpot
`app.hubspot.com/oauth/authorize` and `api.hubapi.com/oauth/v1/token`, Intercom `app.intercom.com/oauth` and
`api.intercom.io/auth/eagle/token`.

## Events from the CRM

`POST /api/v1/crm/webhooks/{connection_id}` accepts signed events and stores each once:

| CRM | Signature that is checked |
| --- | --- |
| HubSpot | `X-HubSpot-Signature-v3` (HMAC-SHA256 of method + URL + body + timestamp with the app's client secret), timestamp at most 5 minutes old |
| Intercom | `X-Hub-Signature` (HMAC-SHA1 of the body with the client secret) |
| anything else | `X-Signature: sha256=<hex>` (HMAC-SHA256 of the body with the connection's webhook secret) — for a relay in front of a CRM without signed webhooks, e.g. Salesforce |

One event type is acted on: a HubSpot property-change event for the risk-score property marks the delivery that
wrote it as *confirmed by the CRM* (and says whether the value matches what was sent). All other events are kept
and marked as ignored.

## Reverse ETL

A **sync** defines what goes out (risk scores or recommendations), under which column names, for which customers
(risk tiers, minimum probability), and where to:

- **export** — a CSV or JSON-lines file under `<data dir>/exports/…` with a manifest (row count, SHA-256). This is
  the hand-over to a reverse-ETL tool such as Hightouch or Census, which loads it into Salesforce, Zendesk, Marketo
  or any other destination it supports. Download: `GET /api/v1/crm/reverse-etl/runs/{id}/download` (needs the
  export permission; refused if the file no longer has its recorded checksum).
- **crm** — one delivery per row through a CRM connection (risk scores only). The connection's mode applies: a
  `TEST_ONLY` connection builds every request and sends none.

A sync runs only after a second person approved it. Each run records the rows selected and what became of them;
`Verify` re-reads the file and its checksum, or counts the deliveries by state (sent, not sent, confirmed by the
CRM). Running a sync twice for the same scores queues nothing twice.

The platform does not talk to Hightouch, Census, Zendesk or Marketo itself.

## Messages

Channels and vendors: e-mail (SendGrid, Amazon SES, or **any SMTP server**), text (Twilio), push (Firebase Cloud
Messaging; Apple APNs can be rehearsed only — it needs HTTP/2, which this build does not include), in-app (an inbox
the product reads).

**SMTP (new in 1.1.1).** A provider with `provider: "smtp"` needs a `host` and a `from_email` (`port` defaults to
2525, `from_name` is optional); `starttls: true` upgrades the connection, and `username`/`password` in the
credentials authenticate when the server wants them. A relay that takes mail without authentication needs no
credential, so such a provider can leave `DRY_RUN` without one; a server that does demand it answers 530 and the
message records that. `SANDBOX` for SMTP takes the conversation only as far as EHLO/NOOP/QUIT — there is no vendor
validation mode to ask, so nothing is transmitted and the message says so. Messages carry `Message-ID` and
`X-Churn-Message-Ref`, and the drop-in `churn-platform`-style mails are plain text with the unsubscribe link for
marketing. Verified against a real mail server: 73 of 73 messages of a test campaign accepted, none rejected.
The mail server's address is checked the way a provider URL is: a name that resolves to a private, loopback or
link-local address is refused unless `CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS=true`, which is what a relay on the same
machine needs. Without `starttls` the connection goes to the address that was checked; with it the name is used
again, because the certificate is verified against the name.

**Modes.** `DRY_RUN` (default): the request is built, checked and stored; the message ends as `dry_run`, which is
never counted as sent or delivered — the database refuses a dry-run message in a sent state. `SANDBOX`: the
vendor's validation mode (SendGrid sandbox mode, the SES mailbox simulator, FCM `validate_only`; Twilio with test
credentials; for SMTP the handshake only). `LIVE`: needs `CHURN_NOTIFY_ALLOW_LIVE=true` as well.

**Before anything is dispatched**, in this order; the first rule that refuses decides, and the refusal with its
reason is the message's final state:

1. the template is approved (written by one person, approved by another; a marketing e-mail must contain
   `{{unsubscribe_url}}`; only listed placeholders are allowed);
2. marketing needs the customer's marketing consent;
3. the customer's own preference for the channel;
4. the suppression list (bounces, complaints, unsubscribes);
5. frequency caps for marketing (`CHURN_NOTIFY_MAX_PER_CUSTOMER_PER_DAY`, `…_PER_WEEK`);
6. a usable recipient (an e-mail address; a phone number in international format; a device token for push);
7. a provider for the channel.

Recipients are stored encrypted, with a masked hint for people to read. Stored requests contain no credentials and
no recipient.

**Delivery.** Temporary failures (timeouts, 429, 5xx) are retried up to five times with a growing delay; a refusal
by the vendor is final. A message is identified by an idempotency key; the same key is never sent twice.

**Events.** `POST /api/v1/notifications/webhooks/{provider_id}` with `X-Signature: sha256=<hex HMAC of the body>`
accepts a JSON list of `{id, type, message_ref | provider_message_id}`. Delivered, bounced and complaint events
update the message; bounces, complaints and unsubscribes put the recipient on the suppression list. The vendors'
own signature schemes (SendGrid's ECDSA signature, Twilio's request signature, Amazon SNS) are **not** implemented:
events need a small relay that verifies the vendor's signature and re-signs with the shared secret.

**Unsubscribe.** The link in a marketing message (`/api/v1/notifications/unsubscribe?t=…`) works without a sign-in;
the token is an HMAC over tenant, customer and channel. It needs `CHURN_PUBLIC_BASE_URL`; without it a real
marketing e-mail is held back, and a dry run shows a placeholder link and says so.

## Campaigns

A campaign is an eligibility rule, a list of steps (wait, then send a template on a channel) and controls: a
control group that receives nothing, A/B variants, a cool-down between campaigns of the same segment (the control
group is held back too), and the message rules above. It needs approved templates and the approval of a second
person, and it starts as a dry run unless that is switched off when starting.

**Who is eligible.** Every key of the rule narrows the selection:

| Key | Selects |
| --- | --- |
| `segments` | customers whose current retention recommendation is in one of the playbook's segments (`high_risk_high_value`, `medium_risk_low_value`, `involuntary`) |
| `action_codes` | of those, the recommendations with one of these playbook actions |
| `risk_tiers`, `min_probability` | customers by the newest risk scores |
| `card_expires_within_days` | customers whose card on file expires within that many days |

A campaign that selects by segment carries out what the approved playbook decided, and nothing else. It takes only
recommendations that are cleared: approved ones, and proposed ones whose action needs no review. It never contacts
a customer whose recommendation the playbook blocked (no consent, contacted recently, an uplift model advising
against), one that still waits for a reviewer, or one somebody dismissed; the start dialog says how many were left
out for each reason. When a message really leaves, the recommendation is closed and the action appears under
*Actions taken & outcomes*, so the same action is not handed to the CRM as well. A dry run changes nothing.

Three campaigns of the project brief are provided as presets:

- **Automated tier: re-engagement e-mails** (brief 9.2, medium risk and lower value): three e-mails over a week,
  content and a webinar invitation, for the customers the playbook put on the re-engagement drip; 10 % control
  group; 60 days cool-down.
- **Automated tier: 15 % offer** (brief 9.2): three e-mails with an offer code for the next billing cycle, for the
  customers whose discount recommendation a person approved. The playbook asks for a review of every discount; the
  campaign does not get round that.
- **Payment card about to expire** (brief 9.3): a text message and an in-app message to the customers the playbook
  flagged for involuntary churn: the card on file expires within the number of days set in the risk policy (15 in
  the default policy), has expired, or the latest payment failed. The message says which of these is on record
  (`{{payment_issue}}`). Transactional: no marketing consent needed, no control group.

The template texts that come with the presets are drafts to be edited: put your own content and links in before a
second person approves them. A campaign with other rules or steps is created through the API (`POST
/api/v1/campaigns`); the screen offers the presets only.

The seeded demo runs the re-engagement e-mails as a dry run: customers are enrolled, the first e-mail of each is
built and checked, and nothing is sent.

Results show enrolment and messages by group, and churn after the start by group once labels exist. A dry run has
no effect to measure, and the results say so.
