# 1.3.0 — final test report

**689 tests. 689 passed. 0 failed, 0 errored, 0 skipped. Twice, at the same commit, on a clean tree.**

This report is the evidence document for the release. Every number below comes from a JUnit file that still exists, and
every claim is reproducible with the command quoted at the bottom. Nothing here is carried over from 1.2.0 or from an
earlier 1.3.0 run.

## The two runs that are the evidence

| | Run 1 | Run 2 |
|---|---|---|
| JUnit file | `/var/tmp/release/r1.xml` | `/var/tmp/release/r2.xml` |
| sidecar | `q1.xml.meta.json` | `q2.xml.meta.json` |
| commit | **`3079f49`** | **`3079f49`** |
| branch | `main` | `main` |
| result | **689 passed** | **689 passed** |
| duration | 760.58 s | 624.58 s |
| failed | 0 | 0 |
| errored | 0 | 0 |
| skipped | **0** | **0** |
| working tree clean at record time | yes | yes |
| SHA-256 of the JUnit file | in the sidecar | in the sidecar |
| interpreter | CPython 3.13.18 | CPython 3.13.18 |
| mode | `CHURN_TEST_STRICT=1` | `CHURN_TEST_STRICT=1` |

The two runs agree test by test: the release check compares the per-test outcomes of the two files and reports any
difference. It found none, which is what makes "twice" a statement about the suite rather than about the weather.

`3079f49` is the last commit at which anything but documentation changed. Above it sit the register that names this
evidence, the reports, and the documents generated from the register; `--release` diffs the evidence commit against the
tree and accepts the claim only while that range holds nothing but documentation.

## Earlier runs, and why they are here rather than hidden

Twenty-seven full runs were made while this release was being finished. Twenty-four of them passed and three did not; the
two that failed are in the table with what they found, because a run that fails and is fixed is evidence of something,
and a report that lists only its passing runs cannot be distinguished from a curation. Twenty-two of the twenty-four
are not used as the evidence, and the reason for each is stated:

| Run | Commit | Result | Why it is not the evidence |
|---|---|---|---|
| preliminary | `0b81cad` | 653 passed, 481.21 s | dirty at record time: two documents were being edited |
| preliminary | `1bee719` | 653 passed, 462.09 s | clean, but the tree moved on afterwards |
| evidence A | `84aee3e` | 653 passed, 435.69 s | the lint pass (`bbd7390`) changed source afterwards |
| evidence B | `84aee3e` | 653 passed, 428.71 s | same |
| corroborating | `2902100` | 653 passed, 465.16 s | dirty at record time |
| corroborating | `84aee3e` | 653 passed, 436.83 s | superseded by the lint pass |
| corroborating | `bbd7390` | 653 passed, 458.10 s | the re-verification script was being written while it ran |
| corroborating | `bbd7390` | 653 passed, 435.33 s | same tree; the version bump came after it |
| evidence C | `49b5bfc` | 653 passed, 446.40 s | the register tooling changed afterwards |
| evidence D | `49b5bfc` | 653 passed, 417.24 s | same |
| evidence E | `d2b4fd2` | 653 passed, 653.47 s | one evidence sentence was corrected afterwards |
| evidence F | `d2b4fd2` | 653 passed, 638.22 s | same |
| evidence G | `d914fca` | 653 passed, 616.37 s | the changelog and the release rule changed afterwards |
| evidence H | `d914fca` | 653 passed, 583.58 s | same |
| evidence I | `682bcc3` | 653 passed, 571.05 s | the documentation-only rule was widened afterwards (`d31e94d`) |
| evidence J | `682bcc3` | 653 passed, 573.45 s | same |
| evidence 1 | `d31e94d` | 653 passed, 572.62 s | the delivery layer was wired into the product afterwards |
| evidence 2 | `d31e94d` | 653 passed, 559.99 s | same |
| **failed** | `f7639e6` | **670 passed, 9 failed, 542.51 s** | 8 tests walked a browser navigation that did not yet contain the new screen; 1 counted the API's operations and found eight undeclared. Both were real omissions in the change, both were fixed in the code and in the tests, and no test was weakened |
| **failed** | `53e79ee` | **678 passed, 1 failed, 585.65 s** | the tenant-isolation test counts the routes it walks; the eight new routes were not enumerated, and its backlog call needed the destination it takes. Fixed by adding them, and by giving the run-detail route a real run of the first tenant so the control half of the test is a control |
| superseded | `42a5801` | 679 passed, 580.96 s | the register tools changed afterwards: the wiring script numbered two entries `R-100`, and the re-verification script refused the three measurement-backed entries |
| superseded | `42a5801` | 679 passed, 589.02 s | same |
| superseded | `0d43b07` | 679 passed, 589.04 s | the delivery layer acquired a real destination afterwards |
| superseded | `0d43b07` | 679 passed, 600.30 s | same |
| discarded | `3079f49` | 671 passed, **18 errored**, 551.70 s | the environment had been rebuilt from nothing and `TMPDIR` pointed at a directory that did not exist, so Playwright could not start. The error was in the environment, and the fix was to create the directory and reinstall the browser build the pinned Playwright asks for — not to relax the test |
| **evidence 1** | **`3079f49`** | **689 passed, 760.58 s** | **used** |
| **evidence 2** | **`3079f49`** | **689 passed, 624.58 s** | **used** |

Twenty-seven full runs of 1.3.0, twenty-four passes, and no test that failed and was then made to pass by weakening it.
The two failures are worth reading: both were tests that had been written to notice exactly the kind of change the
delivery wiring made, and both noticed. What separates the other twenty-two runs from the two used ones is
bookkeeping — a dirty tree at record time, a commit that touched something after the run, or, in the last two cases, a
register tool whose counting was wrong. The list is kept rather than pruned: a report that shows only the two
surviving runs is a curation, and a reader cannot tell a curation from a record.

## What the 689 are

| Group | Tests |
|---|---|
| carried from 1.2.0, unchanged in intent | 498 |
| `tests/test_export_record.py` — the canonical record | 30 |
| `tests/test_destinations_snowflake.py` — the pipeline and the Snowflake statements | 17 |
| `tests/test_register_130.py` — the register tool | 13 |
| `tests/test_schema_mismatch_fails_validation.py` — defect 2 | 29 |
| `tests/test_release_validator_rejects_stale_evidence.py` — defect 4 | 21 |
| `tests/test_failed_first_record_does_not_advance_watermark.py` — defect 1 | 15 |
| `tests/test_tenant_id_prevents_crm_collisions.py` — defect 3 | 14 |
| `tests/test_export_outbox.py` — migration `0005`, the checkpoint, resume, PostgreSQL | 13 |
| `tests/test_export_delivery_api.py` — the delivery layer through the API: start, drain, partial failure, resume, reconcile | 15 |
| `tests/test_snowflake_upgrade_plan.py` — the warehouse upgrade plan, and what it withholds | 11 |
| `tests/test_destinations_postgres.py` — a real destination, against a real PostgreSQL | 10 |
| **total** | **689** |

The eleven new modules hold 188 tests; the baseline of record for 1.3.0 was 558, and the additions beyond it are the
defect work, the delivery surface and its measurement described in the implementation report.

## Skips: there are none, and that is the point

`0 skipped` is the number this report is most careful about. A skipped test did not run, so a suite of "653 tests with
40 skipped" would be a suite of 613, and 1.3.0's own audit had to correct two earlier reports for exactly that
arithmetic. The release check refuses a JUnit file containing a skip rather than counting it as a pass.

The suite has prerequisites that can be missing — the sentiment transformer's model directory, PostgreSQL, Chromium.
Under `CHURN_TEST_STRICT=1` a missing prerequisite **fails** instead of skipping, and this run had all three:

- PostgreSQL 17.11 at `127.0.0.1:5432/churn_test`;
- Chromium installed through Playwright, with its system dependencies;
- the sentiment model at `/var/tmp/sentiment-models/models/sentiment/nlptown-multilingual`.

## What the suite proves, and what it does not

It proves that 689 behaviours hold on one machine at one commit, including the four defect reproductions that fail if
the fixes are undone. It does not prove:

- that a Snowflake account accepts the adapter's statements (GATE 12, BLOCKED);
- that any CRM, message provider, identity provider or MLflow server accepts anything (GATES 9–12, BLOCKED);
- that the installation performs under load beyond 32 concurrent clients on 2 vCPU — the 1.3.0 API and delivery
  measurements in `docs/1_3_0_PERFORMANCE_REPORT.md` are single-process, single-machine figures;
- that a model is accurate on real data — every figure is on synthetic data, labelled as synthetic (GATE 13).

`docs/1_3_0_KNOWN_LIMITATIONS.md` lists these and the rest.

## The exact commands

```bash
# 1. the environment used for these runs
sudo pg_ctlcluster 17 main start                  # PostgreSQL 17.11
python3 -m playwright install chromium            # Chromium for tests/e2e
CHURN_DATA_DIR=/var/tmp/sentiment-models python3 -m churn_platform sentiment-model fetch

# 2. run 1
TMPDIR=/var/tmp/churn-tmp \
CHURN_TEST_TEMPLATE_DIR=/var/tmp/churn_test_template \
CHURN_TEST_STRICT=1 \
CHURN_TEST_POSTGRES_URL=postgresql+psycopg://churn:churn_local_dev@127.0.0.1:5432/churn_test \
CHURN_TEST_SENTIMENT_MODEL_DIR=/var/tmp/sentiment-models/models/sentiment \
python3 -m pytest -q --junitxml=/var/tmp/release/r1.xml
python3 scripts/record_test_run.py /var/tmp/release/r1.xml \
    "python3 -m pytest -q --junitxml=/var/tmp/release/r1.xml"

# 3. run 2, unchanged, at the same commit
#    (same command, q2.xml)

# 4. the register is brought to the release commit, and the archive is built and read back
python3 scripts/reverify_1_3_0_register.py --commit "$(git rev-parse --short HEAD)" \
    --junit /var/tmp/release/r1.xml /var/tmp/release/r2.xml \
    --zip release/churn-platform-1.3.0.zip
python3 scripts/build_manifest.py --junit /var/tmp/release/r1.xml \
    --zip release/churn-platform-1.3.0.zip

# 5. the release check reads both files and refuses anything less
#    (--junit takes one path per flag: two paths after one flag is an argparse error)
python3 scripts/build_1_3_0_register.py --release \
    --junit /var/tmp/release/r1.xml --junit /var/tmp/release/r2.xml
```

A reader who runs steps 2–4 gets the same verdict or a failure with a reason. If the suite has drifted, step 4 fails
before anyone can call it a release.
