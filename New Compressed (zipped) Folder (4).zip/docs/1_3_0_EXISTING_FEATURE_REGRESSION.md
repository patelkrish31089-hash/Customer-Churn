# 1.3.0 — existing-feature regression

What 1.3.0 must not break, and how that is checked. Written before any 1.3.0 source change, against the 1.2.0 tree.

## The rule

1.3.0 extends the 1.2.0 application. Every behaviour that worked at `0224654` must still work at the 1.3.0 commit, and
the way that is established is the same test, unchanged, run on the new source — not a promise, and not a report.

That has two consequences the work is held to:

* **No test is deleted, skipped or weakened to make room for a change.** If a 1.3.0 change needs a different behaviour,
  the test changes in the same commit as the behaviour, with the reason in the message, and the register's entry says
  so. A test that was passing and stops passing is a defect until proven otherwise.
* **The baseline count is a floor.** 498 tests were collected at `0224654`. 1.3.0 adds tests and may not lose any; the
  regression reports the count on both sides.

## What is protected, and by which tests

| Behaviour | Guarded by |
|---|---|
| Sign-in, sessions, roles, the 202-operation access table, tenant isolation, CSRF, security headers | `tests/test_api.py`, `tests/test_auth.py`, `tests/test_security*.py` |
| Ingestion, readers, schemas, quality checks, identity, attribute history | `tests/test_ingestion.py`, `test_readers_schemas.py`, `test_quality.py`, `test_features_pit.py` |
| Labels, timeline, feature store and point-in-time correctness | `tests/test_timeline_labels.py`, `test_mlprep.py`, `test_pipeline.py` |
| Training, evaluation, SHAP, calibration, registry | `tests/test_training_eval.py`, `test_registry_predictions.py`, `test_explain.py` |
| Sentiment: model provider, baseline, preparation, evaluation | `tests/test_signals.py`, `test_annotations.py` |
| Adoption arithmetic | `tests/test_signals.py` (hand-computed cases) |
| Customer 360, recommendations, experiments, uplift | `tests/test_analytics.py`, `test_experiments.py` |
| Campaigns, notifications, SMTP, quiet hours, suppression | `tests/test_outbound.py` |
| CRM adapters, contract checker, SSRF guard, delivery outcomes | `tests/test_crm.py`, `scripts/check_crm_contracts.py` |
| Reverse ETL to PostgreSQL and file, refusal of an unapproved model | `tests/test_pipeline.py`, `test_crm.py` |
| Orchestration and the Airflow DAG | `tests/test_lifecycle_orchestration.py`, `tests/test_jobs_worker.py` |
| MLflow mirror and lifecycle gates | `tests/test_mlflow_mirror.py` |
| Migrations up, down, up | `tests/test_migrations.py` |
| Backup, restore, tamper and truncation refusal | `tests/test_backup.py` |
| Monitoring, drift inputs, retraining candidate rules | `tests/test_monitoring.py`, `test_retention.py` |
| Traceability tooling | `tests/test_traceability_tool.py` |
| The browser application, every screen a role can reach | `tests/e2e/test_ui.py` (18 browser tests) |

## The baseline run, on this machine

The 1.2.0 evidence was produced on Python 3.13.16 with PostgreSQL 16. This machine now has Python 3.13.18 and
PostgreSQL 17, so the baseline was executed again here before any change. The result is recorded in
`docs/1_3_0_FINAL_REGRESSION.md` together with the two end-of-release runs; the number that matters is not that it is
498, but that the 1.3.0 source runs the same tests and passes the same set.

If the baseline run on this machine produces a failure, the failure is investigated before any feature work begins —
a floor that is already cracked is not a floor. What that investigation found (if anything) is written here, not
carried silently.

### What it found

The first baseline attempt here was **497 passed, 1 failed** in 629.75 s. The failure was
`tests/test_signals.py::test_the_transformer_runs_locally_on_pinned_weights_and_scores_several_languages`, which failed
its own prerequisite check rather than an assertion: the pinned ONNX model was not where `CHURN_TEST_SENTIMENT_MODEL_DIR`
pointed. It was not in the repository and not a code defect — `churn-platform sentiment-model fetch` writes under
`<data root>/models/sentiment/<pin>/`, and the variable had been set one directory too high. Pointed at
`/var/tmp/sentiment-models/models/sentiment`, the test passes on its own (54.89 s) and the run is repeated in full.

Two things are worth keeping from that: the prerequisite check did its job — it refused, in strict mode, rather than
skipping and pretending — and a failure caused by the environment is still a failure until it is re-run. The failed run
is recorded here, not deleted.

### The second run, and the guard that caught the new tests

The corrected run — which by then also contained the 60 new tests of M1, M2 (part) and M3 (part) — produced
**557 passed, 1 failed** in 657.67 s. The one failure was `tests/test_traceability_tool.py::
test_the_catalogue_is_consistent_and_knows_every_requirement_named_by_a_test`, and it was right: every test in this
suite must name a catalogued requirement, and 47 of the new tests named none. The fix was to declare their requirement
(`REQ-ACT-02`, "scores and actions are written back to business systems"), not to relax the guard — a guard that can be
satisfied by deleting the test it objects to protects nothing.

That is the baseline of record for 1.3.0: **558 tests** (498 carried plus 60 new), the guard satisfied, run on Python
3.13.18 with PostgreSQL 17 by this machine. The 498 of them that came from 1.2.0 pass unchanged, which is the floor this
release stands on.

## What 1.3.0 will add, and how it is kept honest

New capabilities bring new tests, in the same commit, in the same suite — they are not a separate "new tests" run
that can be green while the old ones are red. The additions are:

| Milestone | Tests that must exist before the milestone is called done |
|---|---|
| M2 | destination contract tests per adapter; a stand-in that answers like the vendor; failure, retry, idempotency, quarantine and reconciliation cases |
| M3 | canonical record: field-by-field, type, nullability, version, checksum, refusal of an unapproved model |
| M4 | e-mail: provider interface per adapter, sender verification, event handling, suppression, state transitions, redirect signing and open-redirect refusal |
| M5 | SMS: E.164, country, consent, STOP, preferences, receipts, unknown state |
| M6 | APNs: JWT signing, HTTP/2 request shape, response mapping, token registry lifecycle, invalid-token cleanup |
| M7 | deletion and correction: every state, every store, residual-data proof, legal hold, audit |
| M8 | DAG structure per concern, single-authority rule, scheduler evidence where a scheduler runs |
| M9 | remote MLflow: auth, artifact, signature, promotion, rollback, restart |
| M10 | OIDC profiles and the full claim/PKCE/logout set; shared-store rate limiting across processes; proxy trust |
| M11 | container build and the fifteen-step exercise |
| M12 | drift set, retraining governance, the real-data validation workflow (with synthetic fixtures only) |
| M13 | performance runs and the DR exercise |
| M14 | the new screens, each driven by a browser test |

## The two runs at the end

After the last source change: the whole suite twice, compared test-by-test — same ids, same outcomes, no new skips —
and only then the manifest and the archive. A single green run proves the code compiles and the tests pass once; two
identical runs prove nothing changed between them, which is the only thing that makes the artefact trustworthy.
