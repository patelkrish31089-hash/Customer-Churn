# 1.3.0 — implementation report

What was built in this release, milestone by milestone, with the evidence for each claim. A milestone is *done* only
when its tests exist and pass on the current source and its documents are written; anything else is reported at the
status it actually has. The authoritative status of every requirement is
`docs/1_3_0_REQUIREMENT_TRACEABILITY.md`, generated from `docs/1_3_0_requirements.json`.

| Milestone | Scope | State |
|---|---|---|
| M1 | Audit and reconcile 1.2.0; canonical register; baseline documents | **done** (this section) |
| M2 | Snowflake, Zendesk, Marketo destinations | **in progress**: the pipeline and the Snowflake adapter exist and are tested; not yet reachable from the API; Zendesk and Marketo not started |
| M3 | Canonical reverse-ETL record and sync-ready contract | **in progress**: the canonical record exists and is tested (R-59); the export path is not routed through it yet |
| M4 | Real e-mail delivery and tracking | not started |
| M5 | Real SMS delivery | not started |
| M6 | APNs and the device-token lifecycle | not started |
| M7 | Customer deletion and correction | not started |
| M8 | Airflow scheduler and multi-cycle execution | not started |
| M9 | Remote authenticated MLflow | not started |
| M10 | OIDC, rate limits, TLS | not started |
| M11 | PostgreSQL and container production runtime | not started |
| M12 | Real-data evaluation, drift, retraining governance | not started |
| M13 | Sustained performance and disaster recovery | not started |
| M14 | Frontend/backend integration, screens, release | not started |
| M15 | Independent security and business acceptance | external |

---

## M1 — audit and reconciliation

**Why it is a milestone and not a preamble.** The 1.2.0 release shipped five internal disagreements between its own
documents, and the ones that matter were not typos: a container requirement marked PASS for a version whose image was
never built, a security gate marked NOT_IMPLEMENTED by the generated table while three clean commands and a written
report said otherwise, and a count block that disagreed with the entries it summarised. A release that starts by
trusting those documents inherits the errors, so the first work was to check every claim against the source and the
runs, and to make the class of error impossible rather than to fix the five instances.

### What was built

**`docs/1_3_0_requirements.json` — one register of record, 91 requirements.** The 58 requirements of 1.2.0 are carried
forward under their original ids (so a citation in a test or a report still means one thing), with their 1.2.0 status
and, where it was wrong, a correction that names itself. 33 new requirements (R-59..R-91) describe the work of this
release: the three missing destinations, the canonical export record, the e-mail, SMS and push systems with their state
machines, deletion and correction, the seventeen DAGs, the remote registry, drift and retraining governance, the
real-data evaluation workflows, OIDC profiles, shared-state rate limiting, TLS and proxy trust, containers, performance,
disaster recovery, governance, the new screens and the release itself.

Every entry carries `verified_at`: the commit at which its evidence was last executed. A PASS from 1.2.0 therefore
reads as *history about `0224654`* until the 1.3.0 suite has run, which is the honest thing for it to read as.

**`scripts/build_1_3_0_register.py` — the counts are computed, and the document is generated.** The 1.2.0 register's
`meta.counts` was typed by hand and drifted from its entries; here the counts are recalculated from the entries on every
run, `--check` fails the build when the Markdown document differs from what the register says, and `--release` adds the
stricter rules: no `NOT_TESTED` entry may survive, and no PASS may be verified at a commit other than the one being
released.

The script also validates the fifteen gates — the right number of them, split ten technical and five external, each
with an owner, an environment, a command, a result and the limitation that remains, and every PASS among them carrying
an evidence statement, a timestamp and a source commit.

**`tests/test_register_130.py` — thirteen tests on the register itself.** They are tests of the rule, not of the data:
a hand-written count is overwritten by the computed one, a PASS without evidence or without a commit is refused, a PASS
from an earlier commit fails a release but not an ordinary run, a BLOCKED entry without a blocker is refused, a status
outside the vocabulary is refused, a requirement that was never executed cannot survive a release, duplicate ids are
refused, the gate numbering and the technical/external split are enforced, a gate without an owner, command or
limitation is refused, a passed gate without evidence, timestamp or commit is refused, the register in the repository
validates and its document is current, and all 58 carried requirements keep their 1.2.0 ids.

**`docs/1_2_0_RECONCILIATION.md` — nine corrections, each with before, after, cause and the evidence that settles it.**
Nothing was rewritten silently and no observed result was changed: the corrections are to summaries, to one status that
contradicted its own evidence, and to figures that had gone stale (493 for 498, migration 0003 for `0004`, six
suppressions for nine). The 1.2.0 archive itself is untouched — rewriting a shipped artefact would destroy the only
thing a reader can check its claims against.

**The four baseline documents**: `docs/1_3_0_BASELINE_AUDIT.md` (what is in the tree, what the machine is, what the
audit did not establish), `docs/1_3_0_MISSING_FEATURE_REGISTER.md` (every gap, with the milestone that closes it and
whether it can be closed here at all), `docs/1_3_0_EXISTING_FEATURE_REGRESSION.md` (what may not break, and by which
tests), `docs/1_3_0_PRODUCTION_RISK_REGISTER.md` (fifteen risks, each with an owner and a mitigation that exists or
explicitly does not).

### What M1 established about the machine

The build sandbox had been reset between the 1.2.0 release and this audit: Python 3.13.16 → **3.13.18**, PostgreSQL
20 → **17**, the three release interpreters and every installed package gone, the browser for the E2E tests gone. The
suite was reinstalled from `requirements.lock`, PostgreSQL 17 was started, Chromium and its system libraries were
reinstalled, and the 1.2.0 source was executed on this host before any change — because every later claim is a
comparison against that run, and a comparison against a machine that no longer exists is not one.

### What M1 did not do

No source file of the platform was changed in M1; the changes are a new register, a new script, a new test file, four
baseline documents, one reconciliation document, and corrections to documents. The first behavioural change of 1.3.0
is the canonical prediction record (M3), which every destination in M2 writes.

---

## M3 (part) — the canonical prediction record

**The problem it solves.** In 1.2.0 a prediction was described three times: the CRM payload carried `probability`,
`risk_tier` and a joined string of reasons; the file export carried whatever columns a sync's field mapping named; the
PostgreSQL destination carried a fourth shape again. Nothing said which model produced a row, against which feature
contract, with which approval — so "what did we tell these customers' owners, and from which model?" could not be
answered afterwards, and a destination could export a prediction from a model nobody had approved.

**What exists now** (`services/export_record.py`, 30 tests): nineteen fields — the eighteen of the specification plus
`approval_status` — with a schema version, a type and a nullability for each, the two enumerations, range checks on the
probability, the decile and the horizon, timestamps that must carry a UTC offset, one canonical JSON line per record
(keys in schema order, no padding) and a SHA-256 over the batch.

Three refusals are the point of it: **an unapproved model** may not produce a record at all (`from_prediction` raises
before the record exists); **a naive datetime** is refused, because it means a different instant to every reader; and
**a string where a number belongs** is refused rather than coerced, because a destination that reads `"0.81"` as zero
would export a customer who is not at risk as though they were safe.

## M2 (part) — destinations and the Snowflake adapter

**The pipeline every destination shares** (`services/destinations/base.py`): validate against the canonical record and
quarantine what fails, deduplicate on the record's identity (customer, model name and version, data cutoff), write in
batches, retry what is transient with backoff and quarantine what is not, take a checksum of exactly what was written,
move the watermark only over written records, and reconcile by asking the destination how many rows it holds — with
"unknown" as an answer the code is allowed to give, because a destination that cannot count is not a destination that
can be trusted with a green tick.

**The Snowflake adapter** (`services/destinations/snowflake.py`) takes the driver as a parameter, so nothing imports the
vendor's SDK and nothing here can pretend to have reached an account. The configuration holds no secret (there is a test
that its `safe()` form contains none), the session is read back and compared with the configuration — a warehouse that
silently fell back to `SYSADMIN` fails the connection test rather than writing with it — the destination table mirrors
the canonical record with the warehouse's own types, and the write is a `MERGE` whose identity is the record's own, so a
retried run corrects instead of duplicating.

**What is not done, and is not claimed:** no Snowflake account has accepted a single statement. The driver in the tests
is a stand-in that records statements and answers two queries. GATE 12 stays BLOCKED with the exact dependency, the
adapter is not reachable from the API or a screen yet, and the run record is not persisted. The honest status of R-60 is
PARTIAL and the register says so.

## M1 (second pass) — the four reproduced defects, fixed

The master prompt names four defects that the 1.3.0 work must fix before anything else, and refuses a plan in place of
a fix. Each was **reproduced against the code first**, in a script, and the transcript is quoted at the top of the test
file that now holds it. The reproduction is the interesting part, so it is kept verbatim:

```
=== BUG 1: watermark and checksum over failed records ===
written: 1  failed: 1
watermark: 2026-11-01T06:00:00+00:00 <- day 1 belongs to the FAILED record C1
checksum == C2 only? False
checksum == C1 only? True

=== BUG 2: schema mismatch accepted ===
configured PUBLIC, session OTHER_SCHEMA -> {'ok': True, 'session': {... 'schema': 'OTHER_SCHEMA'},
                                             'health': 'the session answered and matches the configuration'}

=== BUG 3: two tenants, one identity ===
identity(t1) == identity(t2)? True -> C1|m|1|2026-11-05
tenant_id in the canonical schema? False

=== BUG 4: release validator accepts evidence from another commit ===
actual HEAD: b4fd131  register says source_commit: 0224654
problems reported in --release mode: []
-> a release PASS is possible with evidence from a commit that is not the tree: True
```

### What changed, defect by defect

**1 — the watermark and the checksum came from the selection.** `deliver()` now builds a `RecordOutcome` for every
record: its index, tenant, identity, idempotency key, payload digest, prediction instant, status, attempts, external
reference, submission and acknowledgement times, and the error. `contiguous_watermark()` walks the acknowledged records
in time order, groups them by instant (an instant that is half-delivered does not advance the watermark), and stops at
the first outstanding record; `tenant_watermarks()` applies it per tenant so one tenant's backlog cannot hold another's
export back. The checksum is computed over exactly the acknowledged set, in input order, and is reproducible from the
destination's own stored rows. A batch that fails is retried under the policy and then broken into single-record writes,
so one bad row cannot take its neighbours down. `checkpoint_of()` and `resume()` make a restart a query rather than a
guess.

**2 — the Snowflake session was compared with itself.** `test_connection()` reads back eight session facts and compares
six configured ones — account locator, region, warehouse, database, schema, role — with an unreported value counting as
a mismatch and case sensitivity handled the way Snowflake handles it. Connector exceptions become `ValidationFailed`
with a kind (`timeout`, `connection`), so a wrong key is distinguishable from a wrong schema. `tls=False` is refused
before a connection is attempted. `quote()` validates every configured identifier against a strict grammar and quotes
it; the DDL, MERGE, COUNT and INSERT all use it, so a table called `ORDER` works and `X; DROP TABLE Y` is not a name.

**3 — the tenant was not part of the record.** `tenant_id` is the record's first field, required, and the schema version
moved to `1.1.0`. It leads the identity, the idempotency key, the deduplication, the Snowflake primary key and the
MERGE's `ON` clause; `from_prediction()` refuses a prediction whose tenant cannot be established; `record_run()` refuses
a run that mixes tenants.

**4 — the release validator agreed with itself.** `--release` now compares the register's claim with `git`, requires
every PASS/PARTIAL/FAIL to name that commit, requires a clean tree, requires JUnit evidence with a sidecar naming its
commit and command and a digest that still matches, rejects failures, errors and **skips**, and requires two runs to
agree test by test. The one exception — a documentation-only commit above the evidence commit, because the register
cannot contain the hash of the commit that contains it — is checked by diffing the two commits, not assumed.

### Added with them

- migration `0005` (`export_runs`, `export_outbox`, `export_checkpoints`), additive, with a downgrade that drops exactly
  its own three tables, and one test that runs the whole cycle against PostgreSQL 17 as well as SQLite;
- `services/export_outbox.py`: the durable side — record a run, advance a tenant checkpoint only forwards, answer what is
  outstanding, and refuse a mixed-tenant run;
- `scripts/record_test_run.py`: the sidecar a release's evidence needs;
- four regression modules named for the failures they prevent, plus one for the outbox;
- three generators with `--check` for `docs/1_3_0_FILE_STRUCTURE.md`, `docs/1_3_0_REQUIREMENT_MATRIX.md` and
  `docs/1_3_0_FEATURE_INVENTORY.md`, so those documents cannot describe a tree that no longer exists.

### What is still not done

The delivery layer has no route, no job handler and no screen — register entry R-98, NOT_IMPLEMENTED, and the reason
R-59 and R-60 remain PARTIAL. No Snowflake account exists, so GATE 12 stays BLOCKED. A warehouse table created by an
earlier 1.3.0 build is not altered and no `TENANT_ID` backfill is provided. All of it is in
`docs/1_3_0_KNOWN_LIMITATIONS.md` as well, because a limitation that appears in only one document is a limitation
somebody will miss.
