# Requirement traceability for release 1.1.0

From each thing 1.1.0 set out to do, to the requirement it became, the code that does it, the tests that check it,
and the evidence from running it outside the test suite. The test-by-test matrix is generated from the release
test run and lives in [traceability/TRACEABILITY.md](traceability/TRACEABILITY.md); it fails the build when a
requirement has no passing test. This page is the map on top of it.

Status words are those of [MISSING_FEATURE_REGISTER.md](MISSING_FEATURE_REGISTER.md): **PASS** (built, tested,
exercised as far as the build machine allows), **BLOCKED** (built and tested against stand-ins; the proof that
matters needs a vendor account, a real identity provider or real labelled data).

## The ten work items

| # | Work item | Requirement | Code | Tests | Run outside the suite | Status |
|---|---|---|---|---|---|---|
| 1 | Sentiment of support text from a trained model | REQ-SIG-01 | `services/sentiment.py`, `synthetic_text.py`, `api/routes_signals.py` | `tests/test_signals.py` (9 test cases, one of them on the real model) | Model fetched and verified by the CLI, tampering detected; reference demo scored; throughput, memory and repeatability measured (`sentiment/`) | PASS for the mechanism; **BLOCKED** for accuracy on real support text |
| 2 | Feature adoption rate | REQ-SIG-02 | `services/adoption.py`, `services/timeline.py` | `tests/test_signals.py` (6 test cases) | Reference demo: 850 customers measured against 8 catalogue features | PASS |
| 3 | Identity mapping and active users | REQ-SIG-03 | `services/identity.py`, `services/feature_engine.py` | `tests/test_signals.py` (8 test cases) | Reference demo: 11,403 identifiers, 9,679 people, 87.8% of events attributed | PASS |
| 4 | History of customer attributes | REQ-SIG-04 | `services/attributes.py`, hooks in `ingestion.py` and `quality.py` | `tests/test_signals.py` (6 test cases), `tests/test_features_pit.py` | Reference demo: 7,368 periods for 1,200 customers | PASS |
| 5 | Model lifecycle, promotion gates, MLflow; Airflow step by step | REQ-ML-07, REQ-OPS-07 | `services/registry.py`, `services/mlflow_mirror.py`, `services/orchestration.py`, `cli.py`, `deploy/airflow/churn_nightly_dag.py` | `tests/test_lifecycle_orchestration.py` (5 test cases for each of the two requirements), `tests/test_mlflow_mirror.py`, `tests/test_pipeline.py` | MLflow 3.18.0 tracking server over HTTP (`mlflow/`); Airflow 3.4.0 `dags test`, twice (`airflow/`) | PASS. Not run: a scheduler with an executor; an authenticated MLflow server |
| 6 | CRM OAuth, CRM events, reverse ETL | REQ-ACT-04 | `services/crm_oauth.py`, `services/reverse_etl.py`, `services/crm.py` | `tests/test_outbound.py` (5 test cases) | Reference demo: one approved export sync, 340 rows, checksum verified. The 1.0.1 contract check still passes (4 of 4 requests conform) | **BLOCKED**: no vendor account |
| 7 | Messages and campaigns | REQ-ACT-05 | `services/notify.py`, `services/campaigns.py` | `tests/test_outbound.py` (11 test cases) | Reference demo: 165 customers enrolled in a dry run, 148 e-mails built, none sent | **BLOCKED**: no vendor has accepted a message |
| 8 | Security operations: shared limits, proxies, session rotation, single sign-on | REQ-SEC-07, REQ-SEC-08 | `services/ratelimit.py`, `netpolicy.py`, `services/auth.py`, `services/sso.py`, `api/app.py` | `tests/test_security_platform.py` (6 test cases for the limits, proxies and sessions, 17 for single sign-on), `tests/test_api.py` | Two server processes: 10 of 150 sign-in attempts answered, 140 refused (`limits/`); the limiter on PostgreSQL; forwarded headers against a running server, before and after the fix of DEF-082 (`proxy/`) | PASS; **BLOCKED** for a real identity provider |
| 9 | Performance | (no requirement of its own) | `services/sentiment.py` (one text per pass, memory arena off), `services/identity.py` (join) | regression test of the join in `tests/test_signals.py` | Load test on the 1.1.0 reference demo (`load/`); seed time; sentiment throughput and memory | Measured, see below |
| 10 | Regression, evidence, documents | REQ-QA-01 | `scripts/build_traceability.py`, `scripts/build_manifest.py` | the whole suite; `tests/test_traceability_tool.py` | Baseline run on 1.0.1, release runs on three Python versions, image and compose stack (`baseline/`, `container/`) | PASS |

Paths in the last column but one are directories of the release evidence.

## Performance: what was measured, and what was not done

No performance target was set, so there is nothing to pass or fail; these are the measurements.

- The 1.0.1 request mix on the 1.1.0 reference demo (SQLite, 2 CPUs shared with the load generator): 52 requests a
  second with one client, 85 to 93 with 8 or 32 clients, no failed request. 1.0.1 measured 49 and 77 to 86 on the
  same mix: the new signals did not slow the existing screens down. These figures are from the release candidate.
  The machine is shared and varies by a factor of two from one hour to the next: a repeat of the matrix on the
  released code gave 20 to 67 requests a second, and a comparison of candidate and release in turn, minutes later,
  gave 44 to 45 (one client) and 70 to 79 (eight clients) for both.
- Seeding the reference demo (1,200 customers), sentiment scoring included: 98, 119 and 222 seconds in three runs.
- Sentiment: about 2,000 texts a minute on one thread; 430 to 460 MB of memory in the scoring process.
- Two memory defects were found and fixed on the way (DEF-070, DEF-072).

Not done: PostgreSQL under load on 1.1.0, the new screens under load, larger tenants, any tuning beyond the two
fixes.

## Requirements changed by 1.1.0

| Requirement | Change |
|---|---|
| REQ-ML-02 | 84 features instead of 69; sentiment, adoption and active users named |
| REQ-ML-06 | The MLflow sentence points to REQ-ML-07 |
| REQ-OPS-04 | The nightly chain has seven steps |
| REQ-SIG-01 to 04, REQ-ML-07, REQ-OPS-07, REQ-ACT-04, REQ-ACT-05, REQ-SEC-07, REQ-SEC-08 | New |

## Sections of the brief whose coverage changed

| Section | 1.0.1 | 1.1.0 | Why it is not "full" |
|---|---|---|---|
| 3.1 Four data domains | partial | full | |
| 8.1 Nightly scoring with Airflow and MLflow | partial | full | |
| 2.2 objective 4, Scores written back to the CRM | partial | partial | No vendor account has accepted a request |
| 8.2 Warehouse and operational tools | partial | partial | No Snowflake; Hightouch, Census, Zendesk and Marketo by file only |
| 9.2 Automated e-mail sequence or discount | partial | partial | No vendor has accepted a message |
| 9.3 Text or push for a payment method | partial | partial | No vendor has accepted a message; Apple push is rehearsal only |
