# 1.3.0 — release state

One page, read first. Everything here is a command that was run on this machine and its output, at the commit named.
Nothing here is a plan, an intention, or a claim about a vendor.

## The release

| | |
|---|---|
| version | **1.3.0** — `pyproject.toml`, `src/churn_platform/__init__.py`, `CHANGELOG.md`; `/healthz` reports `1.3.0` |
| evidence commit | **`3079f49`** — the last commit at which anything but documentation changed |
| tree | `main` at `3079f49`, one documentation commit above it, working tree clean |
| suite | **689 passed**, 0 failed, 0 errored, **0 skipped**, twice at `3079f49`: 760.58 s and 624.58 s |
| archive | `release/churn-platform-1.3.0.zip` — 243 files plus `MANIFEST.json`, 1,273,462 bytes, sha256 `6dc6996e…38bd`, read back member by member against `MANIFEST.json` |
| register | 106 requirements: PASS **39**, PARTIAL **21**, NOT_IMPLEMENTED 36, BLOCKED 8, NOT_APPLICABLE 2 |
| gates | 15 probed by `scripts/gate_ledger.py`: **3 PASS**, 11 BLOCKED with the missing precondition named, 1 NOT_IMPLEMENTED — `docs/1_3_0_GATES.md` |
| release check | `build_1_3_0_register.py --release` exits **0** with the two JUnit files and their sidecars |
| performance | API 59.3 / 84.8 / 78.3 req/s at 1 / 8 / 32 clients, p95 47.7 / 223.2 / 652.7 ms, 0 errors; delivery ~2 100 records/s (`docs/1_3_0_PERFORMANCE_REPORT.md`) |

The archive is the tree at **`3079f49`**, the evidence commit: 243 files, each read back against `MANIFEST.json`.
The documents above it — this page, the register, the four generated documents — were written after the archive was
sealed, so the copies inside the archive are the ones that existed at the evidence commit and not these. That is the
only sense in which the archive and the tree differ, and `build_manifest.py --check` says so rather than hiding it.

## The four defects, each held by a test that fails if the fix is undone

| # | Defect | Held by |
|---|---|---|
| 1 | a failed record advanced the export watermark | `tests/test_failed_first_record_does_not_advance_watermark.py` (15) |
| 2 | a Snowflake session in the wrong schema reported healthy | `tests/test_schema_mismatch_fails_validation.py` (29) |
| 3 | two tenants' records collided in the identity and the MERGE | `tests/test_tenant_id_prevents_crm_collisions.py` (14) |
| 4 | `--release` passed on another commit's evidence | `tests/test_release_validator_rejects_stale_evidence.py` (21) |

## The four gates that matter, as they now read

| Gate | Command | Result |
|---|---|---|
| lint | `ruff check .` | **All checks passed** |
| security | `bandit -q -r src scripts -x tests -ll` | **0 findings at high or medium**; the interpolations that remain in `snowflake.py` and `snowflake_upgrade.py` carry `# nosec B608` with their reason on the same line |
| dependencies | `pip-audit --requirement requirements.lock --strict --disable-pip --no-deps` | **No known vulnerabilities found** |
| secrets | `python3 scripts/scan_secrets.py` | **no credential found**, 13 suppressed with a written reason |

The register's earlier GATE 6 claim of "0 high and 0 medium" was **not true of the new code** when this release began:
`bandit` reported 27 high findings, all `B608` from interpolated SQL in `snowflake.py`. That is corrected in `bbd7390`
and the gate now reads the numbers above.

## What is not done, and is not going to be called done

- **A real database now receives the records, and no vendor has.** `services/destinations/postgres.py` delivers to a
  live PostgreSQL instance through the product — an export started by the API, drained by the worker, read back by an
  independent connection (R-105 PASS, 10 tests). PostgreSQL is not a warehouse: GATE 12 is still BLOCKED and R-60 is
  still PARTIAL for the vendors the brief names.
- **No vendor accepted anything.** No Snowflake, CRM, message provider, identity provider or MLflow server. GATES 9–12
  BLOCKED. `docs/1_3_0_PRODUCTION_ACCEPTANCE.md` says why, line by line.
- **Two PASSes from 1.2.0 were withdrawn.** `R-13` (73 of 73 messages accepted by a real SMTP server) and `R-38`
  (Keycloak 26.0) cannot be repeated here, so both are PARTIAL now. A PASS nobody can reproduce is history.
- **The failure path is expensive and measured.** Ten refused records in a 10 000-record run turn 20 destination calls
  into 5 020. At zero latency nobody notices; against a warehouse at 100 ms per call it is ~8 minutes. Batching is a
  1.3.x item.
- **Every gate is a probe, and eleven of them find their precondition missing.** `docs/1_3_0_GATES.md` names what each
  one is missing — an account, a host, an assessor, a sending identity — rather than asking a reader to take the word
  "BLOCKED" on trust.
- **The warehouse upgrade plan has never been executed.** `scripts/snowflake_upgrade_1_3_0.py` prints six steps for
  review; R-103 is PARTIAL because a plan that has not met a real table is a plan.
- **Every ML figure is on synthetic data** (GATE 13).

## The documents

| File | What it answers |
|---|---|
| `docs/1_3_0_FINAL_IMPLEMENTATION_REPORT.md` | what was built, what was fixed, what the evidence covers |
| `docs/1_3_0_FINAL_TEST_REPORT.md` | the two runs, the eighteen runs behind them, and why each was set aside |
| `docs/1_3_0_KNOWN_LIMITATIONS.md` | what a reader would otherwise assume was finished |
| `docs/1_3_0_PRODUCTION_ACCEPTANCE.md` | why nothing carries the PRODUCTION ACCEPTED label |
| `docs/1_3_0_REQUIREMENT_TRACEABILITY.md` | every requirement, its status, its evidence, the commit it was verified at |
| `docs/1_3_0_REQUIREMENT_MATRIX.md` | which module would fail if a requirement regressed |
| `docs/1_3_0_FEATURE_INVENTORY.md`, `docs/1_3_0_FILE_STRUCTURE.md` | what exists, where |
| `docs/1_3_0_requirements.json` | the register itself, machine-readable |

## The commands that reproduce the verdict

```bash
export TMPDIR=/var/tmp/churn-tmp CHURN_TEST_TEMPLATE_DIR=/var/tmp/churn_test_template CHURN_TEST_STRICT=1
export CHURN_TEST_POSTGRES_URL=postgresql+psycopg://churn:churn_local_dev@127.0.0.1:5432/churn_test
export CHURN_TEST_SENTIMENT_MODEL_DIR=/var/tmp/sentiment-models/models/sentiment

python3 -m pytest -q --junitxml=/var/tmp/release/rel-7.xml
python3 scripts/record_test_run.py /var/tmp/release/rel-7.xml "python3 -m pytest -q --junitxml=/var/tmp/release/rel-7.xml"
python3 -m pytest -q --junitxml=/var/tmp/release/rel-8.xml
python3 scripts/record_test_run.py /var/tmp/release/rel-8.xml "python3 -m pytest -q --junitxml=/var/tmp/release/rel-8.xml"

python3 scripts/reverify_1_3_0_register.py --commit "$(git rev-parse --short HEAD)" \
    --junit /var/tmp/release/rel-7.xml /var/tmp/release/rel-8.xml --zip release/churn-platform-1.3.0.zip
python3 scripts/build_1_3_0_register.py --release \
    --junit /var/tmp/release/rel-7.xml --junit /var/tmp/release/rel-8.xml
```

`--release` exits non-zero with a sentence for each problem it finds — a PASS older than the tree, a sidecar that does
not name its commit, a skipped test, a dirty tree, or a commit that moved something other than documentation between
the evidence and the tree.
