# Security operations added in 1.1.0

## Request limits

Limits are counted in the database (`rate_limit_counters`, one row per limit, subject and minute), so every server
process sees the same total. In 1.0 each process counted for itself: with two processes, twice the configured
number of sign-in attempts got through.

| Limit | Per | Default per minute | Setting |
| --- | --- | --- | --- |
| sign-in attempts | client address | 30 | `CHURN_RATE_LIMIT_LOGIN_PER_MINUTE` |
| sign-in attempts | account | 10 | `CHURN_RATE_LIMIT_LOGIN_ACCOUNT_PER_MINUTE` |
| requests that change something | client address | 300 | `CHURN_RATE_LIMIT_IP_PER_MINUTE` |
| requests that change something | session | 600 | `CHURN_RATE_LIMIT_API_PER_MINUTE` |
| exports | user | 20 | `CHURN_RATE_LIMIT_EXPORT_PER_MINUTE` |
| single predictions | user | 60 | `CHURN_RATE_LIMIT_PREDICT_PER_MINUTE` |
| CRM syncs | user | 30 | `CHURN_RATE_LIMIT_SYNC_PER_MINUTE` |

A refused request answers 429 with `Retry-After`. Reads are not counted in the shared store: one database write
per read would cost more than the read. Put a reverse proxy or WAF in front for volumetric protection.

The counters belong to the installation, not to a tenant. `Operations → Security` shows a tenant its own users
against the per-user limits of the current minute; client addresses and account names, which are counted across
all tenants, are not shown to anybody.

If the counter store cannot be reached, `CHURN_RATE_LIMIT_STORE_FAILURE` decides: `local` (default) counts per
process until it is back, `deny` refuses the request. The limiter never switches itself off silently; every such
failure is logged. `CHURN_RATE_LIMIT_ENABLED=false` switches all limits off (load tests).

## Behind a reverse proxy

`X-Forwarded-For` and `X-Forwarded-Proto` are believed only when the TCP peer is listed in
`CHURN_TRUSTED_PROXIES` (addresses or CIDR ranges, comma-separated). The client address is the right-most address
in the chain that is not itself a trusted proxy. Release 1.0 sent `Strict-Transport-Security` to anyone who sent
`X-Forwarded-Proto: https`; now the header is sent on HTTPS connections, on connections a trusted proxy reports as
HTTPS, or always with `CHURN_FORCE_HTTPS=true` (`CHURN_HSTS_SECONDS`, default one year).

`CHURN_TRUSTED_PROXIES` is the only list. `churn-platform serve` switches off the HTTP server's own handling of
forwarded headers, which trusts `127.0.0.1` unless told otherwise, and refuses the 1.0 option
`--forwarded-allow-ips` with a message that names the setting. A proxy on the same machine has to be listed like
any other (`CHURN_TRUSTED_PROXIES=127.0.0.1`). Checked for this release against a running server: without the
setting a request from 127.0.0.1 that claims HTTPS and another address gets no transport-security header and is
counted as 127.0.0.1; with it, both headers are believed.

Set `CHURN_PUBLIC_BASE_URL` to the address users reach the platform at. Redirect addresses for single sign-on and
CRM OAuth, and unsubscribe links, are built from it; in production it must start with `https://`. Without it the
two redirect addresses are built from the `Host` header of the request, which is only right when the platform is
reached directly and under one name (a developer's machine); behind a proxy that terminates TLS they come out as
`http://…` and do not match the address registered with the provider. Unsubscribe links are never built from a
request: without the setting marketing e-mail is held back.

## Sessions

Sessions are bearer tokens in the `Authorization` header (no cookie, so no CSRF surface). The web app replaces its
token every `CHURN_SESSION_ROTATE_MINUTES` (default 60) through `POST /api/v1/auth/rotate`. The replacement ends
when the original session would have; the replaced token keeps working for 30 seconds (requests already on their
way) and never again. If a replaced token is presented after that, every session that descends from it is revoked
and the event is audited: either a stale tab or a stolen copy, and nobody can tell which copy is the thief's.

## Single sign-on (OpenID Connect)

`Operations → Security → Add an identity provider`: issuer, client id and secret, allowed e-mail domains, the claim
that carries groups, a mapping from claim values to roles, whether accounts are created on first sign-in, and
whether the provider's second factor is accepted. Register `<CHURN_PUBLIC_BASE_URL>/api/v1/auth/oidc/callback` as
the redirect address. `Test` reads the provider's discovery document and signing keys.

The flow is authorization code with PKCE. When the browser comes back, in this order:

1. the `state` belongs to a login started here, was not used before, has not expired (10 minutes), and comes back
   in the browser that started it (a cookie bound to the state);
2. the code is exchanged with the PKCE verifier;
3. the ID token is signed with a key the provider publishes, with RS256 or ES256 (`none` and shared-secret
   algorithms are refused); issuer, audience (and authorised party), expiry, issue time and nonce are checked; when
   the key is unknown the keys are fetched once more (key rotation);
4. the e-mail address is verified by the provider and in an allowed domain;
5. the person maps to an account: by the provider's subject, else by e-mail (the account is then linked), else a
   new account if that is switched on and a role maps;
6. second factor: an account with a platform authenticator, or a role that requires one, signs in through the
   provider only if the provider reported a second factor **and** the administrator chose to accept it.

The web app receives a one-time code (90 seconds, same browser) and trades it for its session; the session token is
never in a URL. Secrets are stored encrypted; state, nonce and the one-time code are stored as hashes. Every
refused sign-in is audited with its reason, and its state cannot be tried again.

Tested against an identity provider that lives inside the test suite. **No sign-in against a real provider
(Entra ID, Okta, Google, Keycloak) was performed for this release.**
