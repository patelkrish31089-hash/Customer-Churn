# 1.3.0 — missing-feature register

What is absent from the 1.2.0 source, or present and not finished, with the milestone that closes it. Every row is an
entry in `docs/1_3_0_requirements.json`; the counts there are generated, and this table must agree with them.

Read the last column carefully: it says what can be finished **here**, on a machine with no vendor accounts, and what
cannot. The distinction is the whole point of the register — most of the work below is code, and a small, specific,
non-negotiable remainder is somebody else's account.

## Absent from the source (NOT_IMPLEMENTED)

| # | Feature | Requirement | Milestone | Finishes here? |
|---|---|---|---|---|
| 1 | Snowflake destination | Secure connection (key-pair or OAuth, TLS), connection test and health, documented destination schema, full and incremental upsert with watermark and checkpoint, quarantine, idempotency, read-back reconciliation | M2 | **Code and contract tests: yes.** Vendor acceptance: no — needs an account and warehouse (GATE 12) |
| 2 | Zendesk destination | OAuth/API-token auth, user and organisation mapping, ticket create and update with churn context, custom fields, webhook verification, rate limiting, idempotency, read-back reconciliation | M2 | **Yes, against a local stand-in**; the sandbox round trip needs an account |
| 3 | Marketo destination | Token management, lead lookup and mapping, verified field configuration, risk-score sync, campaign membership with an approved trigger, retry, idempotency | M2 | **Yes, against a local stand-in**; the test environment needs an account |
| 4 | Canonical prediction record | Eighteen named fields, schema version, types, nullability, validation before export, batch checksum | M3 | **Yes, completely** |
| 5 | Sync-ready contract for reverse-ETL tools | Canonical views, watermarks, unique keys, field mapping, freshness, export checksums | M3 | **Yes, completely** — and no claim of a Hightouch or Census product integration (R-11 stays NOT_APPLICABLE) |
| 6 | E-mail provider interface | verify_connection, verify_sender, send, get_delivery_status, handle_event, unsubscribe, suppress, health_check; SES and SendGrid adapters | M4 | **Code and request contract: yes.** Delivery by a vendor: no (GATE 13) |
| 7 | Open and click tracking | Signed, expiring redirects against open redirection; consent and privacy consequences written down; "opened" never presented as engagement | M4 | **Yes, completely** |
| 8 | E-mail delivery states | QUEUED, SUBMITTED, ACCEPTED, DELIVERED, BOUNCED, COMPLAINT, CLICKED, FAILED, UNKNOWN as distinct stored states | M4 | **Yes, completely** (migration) |
| 9 | SMS subsystem | E.164 and country validation, consent, STOP, templates, preferences, quiet hours, frequency limits, receipts, unknown-state reconciliation, cost tracking | M5 | **Yes against a Twilio-compatible local stub**; a real vendor number: no |
| 10 | APNs over HTTP/2 | Token-based auth, payload validation, response handling, retry | M6 | **Yes for the protocol and the signing**; delivery to a real device: no |
| 11 | Device-token registry | Registration, rotation, expiry, invalidation, device association and removal, invalid-token cleanup, FCM and APNs | M6 | **Yes, completely** |
| 12 | Push state vocabulary | PREPARED, QUEUED, SUBMITTED, ACCEPTED, DELIVERED_WHERE_SUPPORTED, OPENED_WHERE_SUPPORTED, FAILED, INVALID_TOKEN, UNKNOWN | M6 | **Yes, completely** |
| 13 | Customer deletion | Request record, the full state path, discovery across every store, hard delete or pseudonymisation, external requests, cache and export reconciliation, legal hold | M7 | **Yes, completely** |
| 14 | Customer correction | Identity, contact, attribute, subscription and source correction with before and after, reason, actor, source, approval, audit | M7 | **Yes, completely** |
| 15 | Residual-data proof | A test that shows no unauthorised customer data survives a completed deletion | M7 | **Yes, completely** |
| 16 | Seventeen Airflow DAGs | One per concern, each with schedule, retries, backoff, timeouts, callbacks, idempotency, checkpoints, backfill, metrics | M8 | **The DAGs: yes.** A supported runtime with a scheduler: only if Airflow can be installed and started here |
| 17 | Single orchestration authority | The application scheduler refuses to run a batch Airflow owns, enforced by configuration and by test | M8 | **Yes, completely** |
| 18 | Scheduler runtime evidence | Several cycles, scheduler restart, worker restart, failed task, native retry, missed schedule, backfill, duplicate prevention | M8 | **Only as far as a locally running scheduler can show** |
| 19 | Remote authenticated MLflow | TLS, authentication, remote artifact store, lineage, signature, checksum; promotion, rollback, server restart | M9 | **A local authenticated server: yes.** A production remote registry: no (GATE 5 stays open on hosting) |
| 20 | Drift monitoring set | Feature, prediction, data-quality, concept and performance drift with reference and current windows, thresholds, alerts, review, action | M12 | **Yes, completely** — except concept drift, which needs mature real labels |
| 21 | Retraining governance | Candidate only, leakage validation, evaluation, calibration, threshold, approval, auditable decision | M12 | **Yes, completely** |
| 22 | Real-data churn validation | The workflow: temporal split, leakage checks, PR-AUC, ROC-AUC, precision, recall, calibration, Brier, financial utility, subgroups, confidence intervals | M12 | **The workflow: yes.** The numbers: no — needs authorised data (GATE 10) |
| 23 | Real-data sentiment evaluation | Language-specific macro and weighted F1, confusion matrix, calibration, intervals | M12 | **The workflow: yes.** The numbers: no (GATE 10) |
| 24 | OIDC profiles | Entra ID, Okta, Google, Keycloak, plus the full PKCE/state/nonce/issuer/audience/JWKS/logout test set | M10 | **Profiles and the local test set: yes.** A hosted tenant: no |
| 25 | Redis-backed rate limiting | Shared state across processes, every limit class named, explicit fail-open or fail-deny | M10 | **Yes, if Redis can be started here; the suite proves the behaviour with the shared store it uses** |
| 26 | Production TLS and trusted proxies | Forwarded headers only from configured proxies, secure cookies, HSTS, documented shape | M10 | **Yes, completely** |
| 27 | Container runtime | Non-root, health checks, volumes, limits, private networks, secret injection, graceful shutdown, restart policy, versioning, scanning, plus the fifteen-step exercise | M11 | **Yes, if a container runtime is available here** — otherwise BLOCKED with that stated |
| 28 | Performance suite | Locust or k6 at four data sizes, six run types, with resource metrics | M13 | **Yes, at the sizes this machine can hold**; a staging verdict: no |
| 29 | Disaster recovery | Scheduled and encrypted backups, retention, integrity, model and feature-store backup, configuration recovery, runbooks, RPO/RTO with the owner, staging restore | M13 | **Mechanism and runbooks: yes.** RPO/RTO and a staging restore: no |
| 30 | Governance controls | Classification, consent, minimisation, retention, export permissions, masking, lineage, external-sharing controls | M7 | **Yes, completely**; no claim of regulatory compliance |
| 31 | New screens | Sixteen new screens wired to real APIs, with validation, loading, error, success and authorisation states | M14 | **Yes, completely** |
| 32 | Canonical evidence register | One register whose counts reconcile, historical inconsistencies corrected with notes, evidence hierarchy | M1 | **Done in this milestone** |
| 33 | 1.3.0 release | Modified application, migrations, DAGs, deployment, tests, documents, manifest, archive, twice-identical regression | M14 | **Yes, completely** |

## Present but unfinished (PARTIAL)

| Requirement | What is there | What is missing | Milestone |
|---|---|---|---|
| R-01..R-03 CRM adapters | Salesforce, HubSpot, Intercom request builders, OAuth, contract checker, stand-in tests | a vendor account that accepts a write | M2 (external) |
| R-06 canonical record | the fifteen fields exist inside the export path | one shared record with eighteen fields, a version and validation | M3 |
| R-12 e-mail adapters | SMTP proven against a real server; SendGrid/SES request builders; dry run and sandbox modes | provider credentials, sender verification, event handling | M4 |
| R-19 SMS | Twilio request builder, E.164, consent, opt-out, callback parsing | provider number, receipts, cost tracking, preferences | M5 |
| R-20 FCM | adapter and payload | a Firebase project; token lifecycle | M6 |
| R-23, R-70 delivery states | `sent` means "accepted by the provider" | the full state split | M4/M5/M6 |
| R-30 adoption scope | customer and cohort level arithmetic verified | account policy, per-user view, velocity, time to first use | M12 |
| R-32..R-34 Airflow | one working DAG, one scheduler execution | the seventeen DAGs, multi-cycle evidence | M8 |
| R-36, R-77 MLflow | local tracking, mirror service, lifecycle gates | a remote authenticated server | M9 |
| R-40 SSO | login flow, groups, role mapping | logout propagation and session revocation verified | M10 |
| R-49, R-50, R-86 performance | closed-loop figures on the build machine | staging, a separate generator, sustained runs, owner thresholds | M13 |
| R-54, R-88 governance | masking, audit, retention policy service | deletion, correction, classification, lineage, sharing controls | M7 |
| R-55, R-89 frontend | 31 routes, all on persisted data | screens for the new capabilities | M14 |

## Not applicable, and why that is not a dodge

* **R-11 Hightouch / Census native integration** — no supported connector interface is offered to this product; what is
  built instead is the *data-source contract* a reverse-ETL tool would consume (M3), and the claim of a product
  integration is not made.
* **R-41 SAML** — the PDF does not require it; only OpenID Connect is in scope.

## Blocked, with the exact dependency

Eight requirements and seven gates need a party who is not at this machine: a CRM sandbox (R-01..R-03), a Snowflake,
Zendesk and Marketo account (R-60..R-62), messaging credentials and an Apple developer account (R-12, R-64..R-70), a
hosted identity provider (R-39, R-82), authorised customer data with mature labels (R-27, R-51, R-80, R-81), an owner
who sets thresholds and RPO/RTO (R-52, R-87), a staging host (R-50, R-86), an independent assessor (R-45) and a GitHub
repository (R-58). These are listed with owner, environment and command in the gate table of
`docs/1_3_0_REQUIREMENT_TRACEABILITY.md`.
