# 1.2.0 — missing features

Derived from `docs/1_2_0_BASELINE_AUDIT.md` (commit `443aa03`). Only what the audit found to be absent, incomplete or
unproven is listed. Items the master prompt assumed missing but that the audit found implemented (feature adoption,
sentiment modelling, distributed rate limiting, the Airflow DAG) are **not** here — they appear in the register as
verification work.

Each entry: what is missing, why it matters, what "done" means, and whether it can be done on this machine.

## A. Absent capabilities — can be built here

| # | Missing | Done when | Tests |
|---|---|---|---|
| M-01 | **Snowflake destination** for reverse ETL. No adapter, no dialect handling. | A destination type `snowflake` that writes the canonical prediction record through a documented interface, with schema mapping, batching, upsert keys, quarantine and a dry-run that cannot claim a write. Against a Snowflake-compatible server started here (or PostgreSQL with the same SQL surface), or marked BLOCKED if no such server can run. | contract + integration |
| M-02 | **Zendesk and Marketo destinations.** | Adapter per provider with the vendor's request shape, field mapping and read-back verification. Vendor acceptance stays BLOCKED. | contract |
| M-03 | **APNs delivery.** Payload is built, the HTTP/2 client is absent, so push to Apple cannot leave the process. | A working APNs client (HTTP/2 with a token or certificate), device-token registration and pruning, and a status that distinguishes *provider accepted* from *device delivered*. A local HTTP/2 server proves the request; Apple remains BLOCKED. | unit + local server |
| M-04 | **Device-token registry.** No table, no endpoint, no expiry. | `device_tokens` (platform, token hash, customer, last seen, invalidated reason), registration and pruning endpoints, FCM `UNREGISTERED`/APNs `410` handled by pruning. | unit + API |
| M-05 | **Quiet hours and send-time policy.** | Per-tenant quiet window with a time zone, messages held (not dropped) and released after it, recorded on the message. | unit |
| M-06 | **Open and click tracking, where lawful and configured.** | Signed, expiring tracking URL; an event that records *opened* / *clicked* only when the tenant has switched it on; never inferred from provider acceptance. | unit + API |
| M-07 | **Annotation workflow for sentiment.** No annotator identity, no disagreement handling, no export. | Annotation tasks over support text with two reviewers, agreement reporting, adjudication of disagreements, a frozen labelled set with a version, and export in the format `sentiment.evaluate()` consumes. | unit + API |
| M-08 | **Customer-data deletion.** No deletion workflow; only audit retention. | A deletion request that removes a customer's personal data across tables, keeps the audit trail in a form that satisfies the integrity requirement, is idempotent, and is recorded. Legal basis and retention are the owner's call. | unit + integration |
| M-09 | **Backup and restore tooling.** A procedure in prose, no command. | `churn-platform backup` / `restore` for PostgreSQL and SQLite plus the model/feature artefacts, checksummed, with a restore that is verified by opening the database and running a health query. A real restore exercise recorded as evidence. | integration |
| M-10 | **Security tooling in CI**: Bandit, pip-audit, secret scanning. | Three jobs that fail the build on a finding, with a documented suppression list. | CI |
| M-11 | **Sustained load and soak testing.** Closed-loop harness only; no k6/Locust, no soak. | A scripted scenario set (smoke, load, stress, soak, recovery) with p50/p95/p99, error rate, queue delay and memory over time; one sustained run recorded, with the hardware stated. | script + run |
| M-12 | **Retention/immature-label operations**: reactivation and immature-label exclusion exist, but there is no report of label maturity per cohort. | A maturity report (cohort, horizon, share mature, expected maturity date) used by the training guard. | unit |

## B. Incomplete capabilities — the code exists, a part is missing

| # | Incomplete | Missing part | Done when |
|---|---|---|---|
| M-13 | **Airflow** | one DAG of seven steps; the prompt asks for a DAG per concern and for multi-night acceptance | the nightly work split into the concerns the product actually has (ingest, quality, signals, labels, features, scoring, recommendations, monitoring, CRM sync, notification scheduling, drift, retraining), each with retries, timeouts, alerts; a scheduler run over consecutive cycles with a forced failure, a retry and a restart, recorded |
| M-14 | **MLflow** | remote authenticated registry round trip never performed | a remote server (started here, over TLS with a token) used for the whole lifecycle — register, alias, promote, roll back, retire — with the checksum, signature and lineage checked before promotion |
| M-15 | **CRM** | vendor acceptance | BLOCKED. Local completion: a provider-neutral contract (`docs/1_2_0_CRM_ACCEPTANCE.md`) with the same twelve-step acceptance script run per adapter against the local stand-in, so that only the credentials are missing |
| M-16 | **Messaging** | SMS and push never reached a real provider; email reached a real server but not a vendor | BLOCKED for vendors. Local completion: delivery states `queued → sent_to_provider → accepted → delivered / bounced / complained / failed / unknown` distinct in the schema, callbacks verified, and a Twilio-compatible local stub driving the status callback path end to end |
| M-17 | **Reverse ETL** | destinations limited to CRM + file/export | M-01/M-02, plus checkpoint and restart-under-partial-failure tests |
| M-18 | **SSO** | hosted provider, SAML, logout propagation | hosted provider BLOCKED; logout and session revocation verified against Keycloak |
| M-19 | **Sentiment accuracy on real text** | labelled data | BLOCKED. Local completion: the annotation workflow (M-07) and a synthetic multi-language evaluation that reports *what it measured*, marked as not evidence of real-world accuracy |
| M-20 | **Performance** | no sustained run, no staging | BLOCKED for staging; local completion: M-11 with the hardware and the reference dataset sizes recorded |
| M-21 | **Disaster recovery** | no verified restore, no RPO/RTO | restore exercise here (M-09); RPO/RTO and owner acceptance BLOCKED |

## C. Not applicable, with reasons

- **Hightouch / Census connectors**: neither product exposes a public connector API for a third-party writer; the
  honest integration is the file/warehouse hand-off the product already offers. Implementing a look-alike and
  calling it a Hightouch integration would be the substitution the master prompt forbids. Register: NOT_APPLICABLE
  for direct integration; the hand-off is covered by M-01.
- **SAML**: no enterprise requirement has been named for it. NOT_APPLICABLE until an owner asks; OpenID Connect
  covers the stated need.
- **Redis**: the requirement is "shared across processes", which the database store already satisfies with tests.
  Adding a second infrastructure dependency would be a regression in operability, not an improvement. NOT_APPLICABLE
  unless a measured limit demands it.

## D. Verification work on things the prompt believes are missing

| # | Item | Work |
|---|---|---|
| M-22 | Feature adoption | independent mathematical cases (eligible denominators, plan and date filtering, two-user aggregation, missing telemetry vs zero), and a demonstration that the same numbers come out of the API, the feature store and the model matrix |
| M-23 | Sentiment | provider ablation on the synthetic language set, per-language table, confidence calibration, and the *not measured* statement surviving into the UI and the API |
| M-24 | Distributed rate limiting | two-process test, store unavailable under both policies, per-IP/user/tenant buckets, `Retry-After` |
| M-25 | 493-test regression | re-run twice after the last source change, plus browser E2E and the full synthetic workflow |
