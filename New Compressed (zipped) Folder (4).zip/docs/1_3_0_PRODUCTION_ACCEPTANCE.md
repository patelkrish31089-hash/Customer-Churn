# 1.3.0 — production acceptance

**Nothing in this release is PRODUCTION ACCEPTED, and this document is the reason it can be said plainly.**

The 1.3.0 brief asks for four labels that are never merged. This one is the fourth, and it is the only one that requires
something no machine in this workspace has: a running installation with real credentials, real data and a named person
who accepts the result. What follows is the checklist that would close it, the state of each line today, and what a
reviewer should refuse to sign without.

## The four labels, restated

| Label | Earned by | This release |
|---|---|---|
| LOCALLY VERIFIED | a command run on this machine at a named commit, with its output quoted | **earned**, for what the test suite and the reproduction scripts cover |
| INTEGRATION VERIFIED | two or more real components exchanging real requests locally | **earned**, for the platform's own API, database, worker, browser and PostgreSQL; **not** for any vendor |
| PDF COMPLIANT | the brief's requirement is met by code that exists and is executed | **partially earned**: 26 PASS, 18 PARTIAL, 37 NOT_IMPLEMENTED, 8 BLOCKED, 2 NOT_APPLICABLE in the register at the time of writing |
| PRODUCTION ACCEPTED | a live installation accepted it | **not earned, and not claimed anywhere in this release** |

## The acceptance checklist, line by line

| # | What must be true | State today | What would close it |
|---|---|---|---|
| 1 | The suite passes twice at the release commit, with no skips | **done** — 689 passed twice at `3079f49`; see `docs/1_3_0_FINAL_TEST_REPORT.md` | — |
| 2 | The register's evidence names the released commit | **done** — `--release` compares the register with `git` | — |
| 3 | Migrations apply to a fresh installation and are reversible | **done locally** — SQLite and PostgreSQL 17.11, tested to `0004` | a rehearsal against a copy of the production database |
| 4 | Migrations apply to an *existing* installation with data | **not done** — no production copy exists here | a restore of a production backup into a staging database, then `churn-platform migrate` |
| 5 | A destination accepts real rows (Snowflake, Zendesk, Marketo) | **BLOCKED** — GATE 12 | a sandbox account per vendor and the acceptance script's output |
| 6 | CRM writes are accepted by the vendor | **BLOCKED** — GATE 9 | an OAuth client and a sandbox per vendor |
| 7 | Messages are delivered by a real provider | **BLOCKED** — GATES 10, 11 | a sending account, and APNs/FCM credentials |
| 8 | Single sign-on works against a real identity provider | **BLOCKED** — GATE 9 | a tenant and an application registration |
| 9 | A labelled, non-synthetic data set exists and the model is re-measured on it | **BLOCKED** — GATE 13 | a customer-supplied labelled sample, under a data-processing agreement |
| 10 | A penetration test has been done and its findings closed | **not done** — GATE 14 | an engagement, a report, and a fix list |
| 11 | Load has been measured on the installation's own hardware | **measured on this project's machine, not on a target** — GATE 15 | a load run on the target hardware; the 1.3.0 figures are 2 vCPU / 2 GB, one process, ≤32 clients (`docs/1_3_0_PERFORMANCE_REPORT.md`) |
| 12 | Backup and restore have been drilled | **done for 1.2.0**, not re-drilled for 1.3.0 | `churn-platform backup` → `restore` → `backup-check` on the target installation |
| 13 | The delivery layer is reachable from the product | **done** — eight `/exports` routes, a worker handler, a screen, and a real PostgreSQL destination that receives the records (R-98, R-99, R-100, R-105 PASS) | — |
| 14 | An operator has signed a runbook and an on-call rotation | **not done** — outside this release | a named operator and a date |

## What a reviewer should refuse without

1. **A green tick over a stand-in.** The Snowflake adapter's driver is injected and the tests inject a stand-in. Any
   claim that "Snowflake works" that rests on `tests/test_destinations_snowflake.py` is false, and the module's own
   docstring says so.
2. **A suite count that includes skips.** The release check refuses a JUnit file containing a skip. This is not
   pedantry: 1.3.0's own audit had to correct two reports where "558 tests" included tests that never ran.
3. **Evidence from another commit.** `--release` now compares the register's claim with `git`, and the first such run
   after the fix failed on 43 problems — including 26 PASSes earned at `0224654` and a register that claimed that
   commit while the source was at `b4fd131`.
4. **A performance number from another machine or another release.** 1.2.0's figures are labelled as 1.2.0's, and
   1.3.0's are labelled as 2 vCPU / 2 GB with the generator on the server's own host. Neither is a capacity claim for
   an installation nobody has run.

## The honest summary

The 1.3.0 code is in a state where a fresh installation can be stood up, seeded, migrated, exercised end to end on one
machine and verified against its own evidence, and where the four defects named in the brief are fixed and held by
tests that fail if they return. It is **not** in a state that any customer could accept, because the things that
require a customer — a vendor account, a labelled sample, a penetration test, the hardware, the operator — are all
missing, and each of them is named here rather than assumed.
