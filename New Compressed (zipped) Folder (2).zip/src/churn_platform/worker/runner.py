"""Background worker process: claims jobs, runs handlers, heartbeats, schedules, graceful shutdown."""

from __future__ import annotations

import os
import signal
import socket
import threading
import time
import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.exc import OperationalError

from ..config import Settings, get_settings
from ..db import get_engine, session_scope, utcnow
from ..logging_setup import correlation_id_var, get_logger
from ..models import Schedule
from ..services import jobs

log = get_logger("worker")


class Worker:
    def __init__(self, settings: Settings | None = None, *, worker_id: str | None = None,
                 job_types: list[str] | None = None) -> None:
        self.settings = settings or get_settings()
        self.engine = get_engine(self.settings)
        jobs.load_handlers()
        self.worker_id = worker_id or f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:8]}"
        self.job_types = job_types
        self._stop = threading.Event()
        self._current: jobs.JobContext | None = None
        self.processed = 0
        self.progress_skipped = 0

    # ------------------------------------------------------------------ lifecycle
    def stop(self, *_: Any) -> None:
        """Stop claiming; give the running job a grace period, then interrupt and requeue it."""
        if not self._stop.is_set():
            log.info("shutdown requested", extra={"ctx": {"worker_id": self.worker_id}})
        self._stop.set()
        ctx = self._current
        if ctx is not None and ctx.shutdown_deadline is None:
            ctx.shutdown_deadline = time.monotonic() + self.settings.worker_shutdown_grace_seconds

    def run_forever(self, *, install_signals: bool = True) -> None:
        if install_signals:
            signal.signal(signal.SIGTERM, self.stop)
            signal.signal(signal.SIGINT, self.stop)
        log.info("worker started", extra={"ctx": {"worker_id": self.worker_id, "job_types": self.job_types}})
        last_maintenance = 0.0
        while not self._stop.is_set():
            try:
                if time.monotonic() - last_maintenance >= max(1.0, self.settings.worker_poll_seconds * 2):
                    self.maintenance()
                    last_maintenance = time.monotonic()
                if not self.run_once():
                    self._stop.wait(self.settings.worker_poll_seconds)
            except Exception:  # the loop must survive transient database errors
                log.exception("worker loop error")
                self._stop.wait(min(5.0, self.settings.worker_poll_seconds * 5))
        log.info("worker stopped", extra={"ctx": {"worker_id": self.worker_id, "processed": self.processed}})

    def maintenance(self) -> dict:
        recovered = jobs.recover_stale(self.engine)
        if recovered["requeued"] or recovered["failed"]:
            log.warning("recovered stale jobs", extra={"ctx": recovered})
        return {**recovered, "scheduled": self.enqueue_due_schedules()}

    # ------------------------------------------------------------------ schedules
    def enqueue_due_schedules(self) -> int:
        """Turn due schedules into jobs exactly once, even with several workers running."""
        now, created = utcnow(), 0
        with session_scope() as s:
            due = s.execute(select(Schedule).where(Schedule.enabled.is_(True), Schedule.next_run_at <= now)).scalars().all()
            for sched in due:
                slot = sched.next_run_at
                missed = int((now - slot).total_seconds() // sched.interval_seconds) + 1
                new_next = slot + timedelta(seconds=sched.interval_seconds * missed)
                won = s.execute(
                    update(Schedule).where(Schedule.id == sched.id, Schedule.next_run_at == slot)
                    .values(next_run_at=new_next, last_run_at=now)
                ).rowcount  # fmt: skip
                if won != 1:
                    continue
                job = jobs.enqueue(s, tenant_id=sched.tenant_id, job_type=sched.job_type, payload=sched.payload,
                                   created_by=sched.created_by, idempotency_key=f"schedule:{sched.id}:{slot.isoformat()}")  # fmt: skip
                s.execute(update(Schedule).where(Schedule.id == sched.id).values(last_job_id=job.id))
                created += 1
        return created

    # ------------------------------------------------------------------ execution
    def run_once(self) -> bool:
        """Claim and execute at most one job.  Returns True if a job was processed."""
        job = jobs.claim_next(self.engine, self.worker_id, self.settings.worker_lease_seconds, self.job_types)
        if job is None:
            return False
        ctx = jobs.JobContext(self.engine, job, self.worker_id)
        self._current = ctx
        if self._stop.is_set():
            ctx.shutdown_deadline = time.monotonic() + self.settings.worker_shutdown_grace_seconds
        token = correlation_id_var.set(f"job-{job['id']}")
        beat_stop = threading.Event()
        beater = threading.Thread(target=self._heartbeat_loop, args=(ctx, beat_stop), daemon=True, name=f"hb-{job['id']}")
        beater.start()
        started = time.monotonic()
        outcome = "succeeded"
        try:
            handler = jobs.HANDLERS.get(job["job_type"])
            if handler is None:
                raise jobs.PermanentJobError(f"no handler registered for job type '{job['job_type']}'")
            result = handler(ctx)
            if not jobs.mark_succeeded(self.engine, job["id"], self.worker_id, result):
                outcome = "lease_lost_result_discarded"
        except jobs.JobCancelled:
            jobs.mark_cancelled(self.engine, job["id"], self.worker_id)
            outcome = "cancelled"
        except jobs.JobInterrupted as exc:
            jobs.release(self.engine, job["id"], self.worker_id, str(exc))
            outcome = "released"
        except jobs.PermanentJobError as exc:
            outcome = jobs.mark_failed(self.engine, job, self.worker_id, exc, permanent=True)
        except Exception as exc:
            log.exception("job failed", extra={"ctx": {"job_id": job["id"], "job_type": job["job_type"]}})
            outcome = jobs.mark_failed(self.engine, job, self.worker_id, exc)
        finally:
            beat_stop.set()
            beater.join(timeout=5)
            self._current = None
            correlation_id_var.reset(token)
        self.processed += 1
        log.info("job finished", extra={"ctx": {"job_id": job["id"], "job_type": job["job_type"], "outcome": outcome,
                                                "attempt": job["attempts"], "seconds": round(time.monotonic() - started, 3),
                                                "progress_skipped": ctx.progress_skipped}})  # fmt: skip
        self.progress_skipped += ctx.progress_skipped
        return True

    def _heartbeat_loop(self, ctx: jobs.JobContext, stop: threading.Event) -> None:
        while not stop.wait(self.settings.worker_heartbeat_seconds):
            try:
                owned, cancel = jobs.heartbeat(self.engine, ctx.job_id, self.worker_id, self.settings.worker_lease_seconds)
            except OperationalError:
                log.debug("heartbeat deferred: database busy", extra={"ctx": {"job_id": ctx.job_id}})
                continue
            except Exception:
                log.exception("heartbeat failed", extra={"ctx": {"job_id": ctx.job_id}})
                continue
            if not owned:
                ctx.lease_lost.set()
                return
            if cancel:
                ctx.cancel_requested.set()

    def drain(self, max_jobs: int = 1000) -> int:
        """Run queued jobs until the queue is empty (used by the CLI ``--once`` mode and tests)."""
        count = 0
        while count < max_jobs and self.run_once():
            count += 1
        return count


_embedded: Worker | None = None
_embedded_thread: threading.Thread | None = None


def start_embedded_worker() -> Worker:
    """Development convenience: run a worker thread inside the API process."""
    global _embedded, _embedded_thread
    if _embedded is None:
        _embedded = Worker(worker_id=f"embedded:{os.getpid()}")
        _embedded_thread = threading.Thread(target=_embedded.run_forever, kwargs={"install_signals": False}, daemon=True,
                                            name="embedded-worker")  # fmt: skip
        _embedded_thread.start()
    return _embedded


def stop_embedded_worker(timeout: float | None = None) -> bool:
    """Ask the embedded worker to stop and wait for it.

    An idle worker ends at once.  A running job gets the usual grace period: it finishes, or it is interrupted at its
    next progress check and re-queued.  Returns False if the thread is still busy after the wait; the process may then
    exit, and the job is recovered through its expired lease like after a crash.
    """
    global _embedded, _embedded_thread
    worker, thread = _embedded, _embedded_thread
    _embedded = _embedded_thread = None
    if worker is None:
        return True
    worker.stop()
    if thread is None:
        return True
    thread.join(worker.settings.worker_shutdown_grace_seconds + 5 if timeout is None else timeout)
    return not thread.is_alive()
