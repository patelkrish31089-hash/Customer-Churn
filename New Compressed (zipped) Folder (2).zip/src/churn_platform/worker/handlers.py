"""Job handlers.  Importing this module registers every handler in ``services.jobs.HANDLERS``."""

from __future__ import annotations

import time

from ..services import jobs
from ..services.jobs import JobContext, PermanentJobError, job_handler


# ----------------------------------------------------------------------------- diagnostics
@job_handler("system.noop")
def _noop(ctx: JobContext) -> dict:
    return {"ok": True, "echo": ctx.payload.get("echo")}


@job_handler("system.sleep")
def _sleep(ctx: JobContext) -> dict:
    """Cooperative sleep used by the worker self-test (progress, cancellation, shutdown)."""
    seconds = float(ctx.payload.get("seconds", 1.0))
    steps = max(1, int(ctx.payload.get("steps", 10)))
    for step in range(steps):
        ctx.progress(step / steps, f"step {step + 1}/{steps}", force=True)
        time.sleep(seconds / steps)
    return {"slept_seconds": seconds}


@job_handler("system.fail")
def _fail(ctx: JobContext) -> dict:
    """Fails ``fail_times`` times (or permanently) so retry/backoff behaviour can be verified."""
    if ctx.payload.get("permanent"):
        raise PermanentJobError("diagnostic permanent failure")
    if ctx.attempt <= int(ctx.payload.get("fail_times", 10**6)):
        raise RuntimeError(f"diagnostic transient failure (attempt {ctx.attempt})")
    return {"succeeded_on_attempt": ctx.attempt}


__all__ = ["jobs"]


# ----------------------------------------------------------------------------- ingestion and quality
@job_handler("ingest.import")
def _ingest_import(ctx: JobContext) -> dict:
    from ..services import ingestion

    return ingestion.run_import(int(ctx.payload["import_run_id"]), ctx)


@job_handler("ingest.rest_pull")
def _ingest_rest_pull(ctx: JobContext) -> dict:
    from ..services import ingestion

    return ingestion.run_rest_pull(int(ctx.payload["source_id"]), ctx.payload.get("mode", "full"), ctx.created_by, ctx)


@job_handler("ingest.webhook_flush")
def _ingest_webhook_flush(ctx: JobContext) -> dict:
    from ..services import ingestion

    return ingestion.run_webhook_flush(int(ctx.payload["source_id"]), ctx)


@job_handler("quality.run")
def _quality_run(ctx: JobContext) -> dict:
    from ..services import quality

    return quality.run_quality(int(ctx.payload["dq_run_id"]), ctx)


# ----------------------------------------------------------------------------- customer signals (1.1.0)
@job_handler("sentiment.score")
def _sentiment_score(ctx: JobContext) -> dict:
    from ..services import sentiment

    return sentiment.run_scoring(int(ctx.payload["sentiment_run_id"]), ctx)


@job_handler("adoption.compute")
def _adoption_compute(ctx: JobContext) -> dict:
    from ..services import adoption

    return adoption.run(int(ctx.payload["adoption_run_id"]), ctx)


@job_handler("identity.reconcile")
def _identity_reconcile(ctx: JobContext) -> dict:
    from ..services import identity

    return identity.run_reconciliation(int(ctx.payload["reconciliation_id"]), ctx)


@job_handler("signals.refresh")
def _signals_refresh(ctx: JobContext) -> dict:
    from datetime import date

    from ..services import signals

    as_of = ctx.payload.get("as_of_date")
    return signals.refresh(ctx.tenant_id, date.fromisoformat(as_of) if as_of else None, ctx)


# ----------------------------------------------------------------------------- labels and feature store
@job_handler("labels.run")
def _labels_run(ctx: JobContext) -> dict:
    from ..services import labels

    return labels.run_labels(int(ctx.payload["label_run_id"]), ctx)


@job_handler("features.materialize")
def _features_materialize(ctx: JobContext) -> dict:
    from ..services import features

    return features.run_materialization(int(ctx.payload["feature_run_id"]), ctx)


# ----------------------------------------------------------------------------- machine learning
@job_handler("ml.build_dataset")
def _ml_build_dataset(ctx: JobContext) -> dict:
    from ..services import mlprep

    return mlprep.run_build(int(ctx.payload["dataset_id"]), ctx)


@job_handler("ml.train")
def _ml_train(ctx: JobContext) -> dict:
    from ..services import training

    return training.run_training([int(i) for i in ctx.payload["run_ids"]], ctx)


@job_handler("predict.batch")
def _predict_batch(ctx: JobContext) -> dict:
    from ..services import predictions

    return predictions.run_batch(int(ctx.payload["batch_id"]), ctx)


@job_handler("predict.scheduled")
def _predict_scheduled(ctx: JobContext) -> dict:
    from ..services import predictions

    return predictions.run_scheduled(ctx.tenant_id, ctx.created_by, ctx)


# ----------------------------------------------------------------------------- analytics, retention, CRM, monitoring
@job_handler("analytics.run")
def _analytics_run(ctx: JobContext) -> dict:
    from ..services import analytics

    return analytics.run(int(ctx.payload["report_id"]), ctx)


@job_handler("retention.generate")
def _retention_generate(ctx: JobContext) -> dict:
    from ..services import retention

    return retention.run_generation(int(ctx.payload["batch_id"]), ctx)


@job_handler("crm.deliver")
def _crm_deliver(ctx: JobContext) -> dict:
    from ..services import crm

    return crm.deliver(int(ctx.payload["delivery_id"]), ctx)


@job_handler("monitoring.run")
def _monitoring_run(ctx: JobContext) -> dict:
    from ..services import monitoring

    version_id = ctx.payload.get("model_version_id")
    return monitoring.run(ctx.tenant_id, int(version_id) if version_id else None, bool(ctx.payload.get("with_evidently")), ctx)


# ----------------------------------------------------------------------------- orchestration and MLOps
@job_handler("pipeline.nightly")
def _pipeline_nightly(ctx: JobContext) -> dict:
    from ..services import pipeline

    return pipeline.run(ctx)


@job_handler("ml.retrain")
def _ml_retrain(ctx: JobContext) -> dict:
    from ..services import retraining

    return retraining.run(ctx)


@job_handler("mlops.mlflow_mirror")
def _mlflow_mirror(ctx: JobContext) -> dict:
    from ..services import mlflow_mirror

    return mlflow_mirror.mirror(int(ctx.payload["version_id"]), ctx)


# ----------------------------------------------------------------------------- notifications, campaigns, reverse ETL (1.1.0)
@job_handler("notify.deliver")
def _notify_deliver(ctx: JobContext) -> dict:
    from ..services import notify

    return notify.deliver(int(ctx.payload["message_id"]), ctx)


@job_handler("campaign.tick")
def _campaign_tick(ctx: JobContext) -> dict:
    from ..services import campaigns

    return campaigns.tick(int(ctx.payload["campaign_id"]), ctx)


@job_handler("export.run")
def _export_run(ctx: JobContext) -> dict:
    """1.3.0: deliver a destination export — the product path into the outbox, the pipeline and the warehouse."""
    from ..services import exports

    return exports.run(int(ctx.payload["export_run_id"]), ctx)


@job_handler("reverse_etl.run")
def _reverse_etl_run(ctx: JobContext) -> dict:
    from ..services import reverse_etl

    return reverse_etl.run(int(ctx.payload["run_id"]), ctx)
