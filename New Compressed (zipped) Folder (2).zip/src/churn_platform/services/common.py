"""Small helpers shared by all services: tenant-scoped lookups, pagination, JSON-safe serialisation."""

from __future__ import annotations

import math
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, TypeVar

from sqlalchemy import Select, func, select
from sqlalchemy.orm import Session

from ..errors import NotFound, ValidationFailed

T = TypeVar("T")
SENSITIVE_COLUMNS = {"password_hash", "mfa_secret_enc", "token_hash", "credentials_enc", "webhook_secret_enc", "client_secret_enc",
                     "refresh_token_enc", "id_token_enc", "code_verifier_enc", "recipient_enc", "recipient_hash", "session_token_enc", "state_hash",
                     "nonce_hash", "browser_hash", "exchange_hash"}  # fmt: skip
MAX_PAGE_SIZE = 500


def json_safe(value: Any) -> Any:
    """Convert numpy / pandas / Decimal / datetime values into strict-JSON-compatible objects."""
    if value is None or isinstance(value, bool | str | int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, datetime | date):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, list | tuple | set | frozenset):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    type_name = type(value).__module__
    if type_name.startswith("numpy"):
        if hasattr(value, "tolist"):
            return json_safe(value.tolist())
        return json_safe(value.item())
    if type_name.startswith("pandas"):
        if hasattr(value, "isoformat"):
            return None if value != value else value.isoformat()  # NaT != NaT
        if hasattr(value, "to_dict"):
            return json_safe(value.to_dict())
        return None  # pd.NA and friends
    return str(value)


def to_dict(obj: Any, *, exclude: set[str] | frozenset[str] = frozenset(), include: dict[str, Any] | None = None) -> dict:
    """Serialise an ORM row to a JSON-safe dict; credential columns are never emitted."""
    out = {
        col.key: json_safe(getattr(obj, col.key))
        for col in obj.__table__.columns
        if col.key not in SENSITIVE_COLUMNS and col.key not in exclude
    }
    if include:
        out.update(json_safe(include))
    return out


def get_owned(session: Session, model: type[T], tenant_id: int, object_id: int, *, label: str | None = None) -> T:
    """Fetch a row by id *within the caller's tenant*; other tenants' rows look non-existent."""
    obj = session.get(model, object_id)
    if obj is None or getattr(obj, "tenant_id", tenant_id) != tenant_id:
        raise NotFound(f"{label or model.__name__} {object_id} was not found")
    return obj


def paginate(session: Session, stmt: Select, *, page: int = 1, page_size: int = 50, serializer: Any = to_dict,
             scalars: bool = True) -> dict:
    if page < 1 or not 1 <= page_size <= MAX_PAGE_SIZE:
        raise ValidationFailed(f"page must be >= 1 and page_size between 1 and {MAX_PAGE_SIZE}")
    total = session.execute(select(func.count()).select_from(stmt.order_by(None).subquery())).scalar_one()
    paged = stmt.limit(page_size).offset((page - 1) * page_size)
    rows = session.execute(paged).scalars().all() if scalars else session.execute(paged).all()
    return {"items": [serializer(r) for r in rows], "total": total, "page": page, "page_size": page_size}


def next_version(session: Session, model: Any, **filters: Any) -> int:
    stmt = select(func.max(model.version)).filter_by(**filters)
    return (session.execute(stmt).scalar() or 0) + 1


def parse_date(value: str | date | None, *, field: str = "date") -> date | None:
    if value is None or (isinstance(value, date) and not isinstance(value, datetime)):
        return value  # type: ignore[return-value]
    if isinstance(value, datetime):
        return value.date()
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError as exc:
        raise ValidationFailed(f"{field} must be an ISO date (YYYY-MM-DD)", details={"field": field}) from exc
