"""Running pipeline steps for an external orchestrator (Apache Airflow).

Airflow owns the schedule, the order of the steps and the retries; the platform owns the work.  Each task of the
DAG calls ``churn-platform pipeline-step`` with a *run key* (the DAG run's id).  One (tenant, step, run key) is
executed at most once: a retried task that finds its step finished does nothing, one that finds it still running
waits for the same jobs, and only a failed step is started again.

Exactly one orchestrator fires the nightly work.  With ``CHURN_ORCHESTRATOR=airflow`` the platform's own schedule
does not start the chain; with ``CHURN_ORCHESTRATOR=platform`` (the default) Airflow's calls are refused.
"""

from __future__ import annotations

import time
from datetime import date
from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import Job, OrchestratorRun
from . import audit, demo, pipeline, predictions
from .common import to_dict

FINISHED = ("succeeded", "failed", "cancelled", "dead")


def run_view(entry: OrchestratorRun) -> dict:
    return to_dict(entry)


def _jobs_state(session: Session, job_ids: list[int]) -> tuple[str, str | None]:
    """State of the current attempt (its job is the last one listed; earlier ones belong to attempts that failed):
    ``running`` while the job is unfinished, else ``succeeded`` or ``failed`` with the error."""
    job_ids = job_ids[-1:]
    if not job_ids:
        return "succeeded", None
    rows = session.execute(select(Job.id, Job.status, Job.error).where(Job.id.in_(job_ids))).all()
    if any(status not in FINISHED for _id, status, _error in rows):
        return "running", None
    bad = [(job_id, status, error) for job_id, status, error in rows if status != "succeeded"]
    if bad:
        job_id, status, error = bad[0]
        return "failed", f"job {job_id} {status}: {(error or '').strip().splitlines()[-1] if error else 'no error message'}"[:1000]
    return "succeeded", None


def claim(tenant_id: int, step: str, run_key: str, *, orchestrator: str = "airflow", dag_id: str | None = None, dag_run_id: str | None = None,
          task_id: str | None = None, force: bool = False) -> dict:
    """Start the step for this run key unless that already happened.  Returns the run and what was done:
    ``started``, ``retried`` (the earlier attempt failed), ``in_progress`` or ``already_done``."""
    settings = get_settings()
    if step not in pipeline.STEPS:
        raise ValidationFailed(f"step must be one of {', '.join(pipeline.STEPS)}", details={"field": "step"})
    run_key = (run_key or "").strip()
    if not run_key or len(run_key) > 250:
        raise ValidationFailed("a run key of 1 to 250 characters is required (use the DAG run id)", details={"field": "run_key"})
    if orchestrator == "airflow" and settings.orchestrator != "airflow" and not force:
        raise Conflict("this installation runs its nightly pipeline itself (CHURN_ORCHESTRATOR=platform). Set CHURN_ORCHESTRATOR=airflow "
                       "before letting Airflow drive it, otherwise every step would run twice.", code="orchestrator_conflict")  # fmt: skip
    for attempt in range(2):
        try:
            with session_scope() as ws:
                entry = ws.execute(select(OrchestratorRun).where(OrchestratorRun.tenant_id == tenant_id, OrchestratorRun.step == step,
                                                                 OrchestratorRun.run_key == run_key).with_for_update()).scalar_one_or_none()  # fmt: skip
                action = "started"
                if entry is not None:
                    if entry.status == "running":
                        state, error = _jobs_state(ws, list(entry.job_ids or []))
                        if state == "running":
                            return {"action": "in_progress", "run": run_view(entry)}
                        entry.status, entry.error, entry.finished_at = state, error, utcnow()
                    if entry.status in ("succeeded", "skipped"):
                        return {"action": "already_done", "run": run_view(entry)}
                    action = "retried"  # the earlier attempt failed: the orchestrator's retry runs the step again
                if pipeline.active_chain(ws, tenant_id, "pipeline.nightly") is not None:
                    raise Conflict("the platform's own nightly chain is running for this tenant; a step cannot be started alongside it",
                                   code="orchestrator_conflict")  # fmt: skip
                principal = demo.system_principal(ws, tenant_id)
                as_of = predictions.default_as_of(ws, tenant_id)
                job, info = pipeline._start_step(ws, principal, step)
                if entry is None:
                    entry = OrchestratorRun(tenant_id=tenant_id, orchestrator=orchestrator, step=step, run_key=run_key, attempts=0, job_ids=[])
                    ws.add(entry)
                entry.dag_id, entry.dag_run_id, entry.task_id, entry.as_of_date = dag_id, dag_run_id, task_id, as_of
                entry.attempts = (entry.attempts or 0) + 1
                entry.job_ids = [*(entry.job_ids or []), job.id] if job is not None else list(entry.job_ids or [])
                entry.detail = {**(entry.detail or {}), f"attempt_{entry.attempts}": info}
                entry.status, entry.error, entry.finished_at = ("running", None, None) if job is not None else ("skipped", None, utcnow())
                ws.flush()
                audit.record(ws, tenant_id=tenant_id, action="orchestrator.step_started", entity_type="orchestrator_run", entity_id=entry.id,
                             detail={"step": step, "run_key": run_key, "orchestrator": orchestrator, "attempt": entry.attempts,
                                     "job_id": job.id if job is not None else None})  # fmt: skip
                return {"action": action if job is not None else "already_done", "run": run_view(entry)}
        except IntegrityError:
            if attempt:  # two tasks claimed the same key at the same moment: the second one reads what the first one wrote
                raise
    raise AssertionError("unreachable")


def refresh(tenant_id: int, run_id: int) -> dict:
    """Bring a run's status in line with its jobs."""
    with session_scope() as ws:
        entry = ws.get(OrchestratorRun, run_id)
        if entry is None or entry.tenant_id != tenant_id:
            raise ValidationFailed("unknown orchestrator run")
        if entry.status == "running":
            state, error = _jobs_state(ws, list(entry.job_ids or []))
            if state != "running":
                entry.status, entry.error, entry.finished_at = state, error, utcnow()
                audit.record(ws, tenant_id=tenant_id, action="orchestrator.step_finished", entity_type="orchestrator_run", entity_id=entry.id,
                             detail={"step": entry.step, "run_key": entry.run_key, "status": state, "error": error})  # fmt: skip
        return run_view(entry)


def run_step(tenant_id: int, step: str, run_key: str, *, wait: bool = True, inline: bool = False, timeout_seconds: float = 7200.0,
             poll_seconds: float = 2.0, **claim_args: Any) -> dict:
    """Claim the step and (with ``wait``) follow it to its end.  ``inline`` also executes the queued jobs in this
    process, for installations without a separate worker."""
    result = claim(tenant_id, step, run_key, **claim_args)
    if not wait or result["run"]["status"] != "running":
        return result
    if inline:
        from ..worker.runner import Worker

        Worker().drain()
    deadline = time.monotonic() + timeout_seconds
    while True:
        run = refresh(tenant_id, result["run"]["id"])
        if run["status"] != "running":
            return {**result, "run": run}
        if time.monotonic() > deadline:
            return {**result, "run": run, "timed_out": True}
        time.sleep(poll_seconds)


def recent(session: Session, tenant_id: int, limit: int = 50) -> list[dict]:
    rows = session.execute(select(OrchestratorRun).where(OrchestratorRun.tenant_id == tenant_id).order_by(OrchestratorRun.id.desc()).limit(limit)).scalars().all()
    return [run_view(r) for r in rows]


def status(session: Session, tenant_id: int) -> dict:
    settings = get_settings()
    return {"orchestrator": settings.orchestrator, "steps": list(pipeline.STEPS),
            "who_fires_the_nightly_run": "Apache Airflow (the platform's own schedule is not used)" if settings.orchestrator == "airflow"
            else "the platform's own schedule", "runs": recent(session, tenant_id, 30)}  # fmt: skip


def latest_as_of(tenant_id: int) -> date | None:
    with read_session() as rs:
        return predictions.default_as_of(rs, tenant_id)
