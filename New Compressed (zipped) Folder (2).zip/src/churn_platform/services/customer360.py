"""Customer 360: one customer's profile, subscription history, behaviour, risk and actions."""

from __future__ import annotations

from datetime import timedelta

import pandas as pd
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..errors import ValidationFailed
from ..models import (
    Account,
    ChurnLabel,
    Customer,
    Intervention,
    Invoice,
    Payment,
    Plan,
    Prediction,
    RetentionRecommendation,
    Subscription,
    SubscriptionEvent,
    SupportInteraction,
    UsageEvent,
)
from . import predictions, timeline
from .common import get_owned, paginate, to_dict

SORTS = {"risk": Prediction.probability.desc().nulls_last(), "name": Customer.name, "external_id": Customer.external_id}


def list_customers(session: Session, tenant_id: int, *, q: str | None = None, tier: str | None = None, sort: str = "risk",
                   page: int = 1, page_size: int = 50) -> dict:
    """Customers with their newest batch prediction (if a batch exists)."""
    if sort not in SORTS:
        raise ValidationFailed(f"sort must be one of {', '.join(SORTS)}", details={"field": "sort"})
    if tier is not None and tier not in predictions.TIERS:
        raise ValidationFailed("tier must be high, medium or low", details={"field": "tier"})
    batch = predictions.latest_batch(session, tenant_id)
    stmt = select(Customer, Prediction).outerjoin(
        Prediction, (Prediction.customer_id == Customer.id) & (Prediction.batch_id == (batch.id if batch else -1))
    ).where(Customer.tenant_id == tenant_id)  # fmt: skip
    if q and q.strip():
        needle = q.strip().lower()  # searched for literally: "%" and "_" typed by a user are not wildcards
        stmt = stmt.where(or_(func.lower(Customer.name).contains(needle, autoescape=True),
                              func.lower(Customer.external_id).contains(needle, autoescape=True)))  # fmt: skip
    if tier:
        stmt = stmt.where(Prediction.risk_tier == tier)
    stmt = stmt.order_by(SORTS[sort], Customer.id)

    def row(pair: tuple) -> dict:
        customer, prediction = pair
        return {"id": customer.id, "external_id": customer.external_id, "name": customer.name, "industry": customer.industry,
                "company_size": customer.company_size, "region": customer.region,
                "probability": prediction.probability if prediction else None, "risk_tier": prediction.risk_tier if prediction else None,
                "risk_decile": prediction.risk_decile if prediction else None, "prediction_id": prediction.id if prediction else None,
                "top_reasons": [r["text"] for r in (prediction.top_reasons or [])] if prediction else []}  # fmt: skip

    out = paginate(session, stmt, page=page, page_size=page_size, serializer=row, scalars=False)
    out["batch"] = {"id": batch.id, "as_of_date": batch.as_of_date.isoformat()} if batch else None
    return out


def detail(session: Session, tenant_id: int, customer_id: int, usage_days: int = 120) -> dict:
    customer = get_owned(session, Customer, tenant_id, customer_id, label="Customer")
    cutoff = timeline.data_cutoff(session, tenant_id)
    accounts = session.execute(select(Account).where(Account.customer_id == customer.id)).scalars().all()
    plans = {p.id: p for p in session.execute(select(Plan).where(Plan.tenant_id == tenant_id)).scalars()}
    subs = session.execute(select(Subscription).where(Subscription.customer_id == customer.id).order_by(Subscription.started_at)).scalars().all()
    events = session.execute(select(SubscriptionEvent).where(SubscriptionEvent.customer_id == customer.id)
                             .order_by(SubscriptionEvent.occurred_at.desc()).limit(100)).scalars().all()  # fmt: skip
    preds = session.execute(select(Prediction).where(Prediction.customer_id == customer.id)
                            .order_by(Prediction.as_of_date.desc(), Prediction.id.desc()).limit(24)).scalars().all()  # fmt: skip
    usage_series: list[dict] = []
    if cutoff is not None:
        since = cutoff - timedelta(days=usage_days)
        rows = session.execute(select(UsageEvent.occurred_at, UsageEvent.event_type, UsageEvent.quantity).where(
            UsageEvent.customer_id == customer.id, UsageEvent.occurred_at >= since)).all()  # fmt: skip
        if rows:
            df = pd.DataFrame(rows, columns=["at", "kind", "qty"])
            df["day"] = pd.to_datetime(df["at"], utc=True).dt.tz_convert(None).dt.normalize()
            df["qty"] = pd.to_numeric(df["qty"], errors="coerce").fillna(1.0)
            days = pd.date_range(timeline.ts(since).normalize(), timeline.ts(cutoff).normalize(), freq="D")
            logins = df[df["kind"].isin(["login", "session"])].groupby("day")["qty"].sum().reindex(days, fill_value=0.0)
            events_per_day = df.groupby("day").size().reindex(days, fill_value=0)
            usage_series = [{"day": d.date().isoformat(), "logins": float(lg), "events": int(ev)}
                            for d, lg, ev in zip(days, logins, events_per_day, strict=True)]  # fmt: skip
    tickets = session.execute(select(SupportInteraction).where(SupportInteraction.customer_id == customer.id)
                              .order_by(SupportInteraction.opened_at.desc()).limit(25)).scalars().all()  # fmt: skip
    invoices = session.execute(select(Invoice).where(Invoice.customer_id == customer.id).order_by(Invoice.issued_at.desc()).limit(12)).scalars().all()
    payments = session.execute(select(Payment).where(Payment.customer_id == customer.id).order_by(Payment.attempted_at.desc()).limit(12)).scalars().all()
    recs = session.execute(select(RetentionRecommendation).where(RetentionRecommendation.customer_id == customer.id)
                           .order_by(RetentionRecommendation.id.desc()).limit(20)).scalars().all()  # fmt: skip
    interventions = session.execute(select(Intervention).where(Intervention.customer_id == customer.id)
                                    .order_by(Intervention.id.desc()).limit(20)).scalars().all()  # fmt: skip
    labels = session.execute(select(ChurnLabel).where(ChurnLabel.customer_id == customer.id)
                             .order_by(ChurnLabel.as_of_date.desc()).limit(24)).scalars().all()  # fmt: skip
    drop = {"dataset_version_id", "source_row", "record_version", "tenant_id"}
    return {
        "customer": to_dict(customer, exclude=drop),
        "accounts": [to_dict(a, exclude=drop) for a in accounts],
        "subscriptions": [to_dict(s, exclude=drop, include={"plan_name": getattr(plans.get(s.plan_id), "name", None),
                                                           "plan_tier": getattr(plans.get(s.plan_id), "tier", None)}) for s in subs],
        "subscription_events": [to_dict(e, exclude=drop) for e in events],
        "predictions": [to_dict(p) for p in preds],
        "usage": usage_series,
        "support": [to_dict(t, exclude=drop | {"body"}, include={"excerpt": (t.body or "")[:200]}) for t in tickets],
        "invoices": [to_dict(i, exclude=drop) for i in invoices],
        "payments": [to_dict(p, exclude=drop) for p in payments],
        "recommendations": [to_dict(r) for r in recs],
        "interventions": [to_dict(i) for i in interventions],
        "labels": [to_dict(x, exclude={"detail"}) for x in labels],
        "data_cutoff": cutoff.isoformat() if cutoff else None,
    }  # fmt: skip
