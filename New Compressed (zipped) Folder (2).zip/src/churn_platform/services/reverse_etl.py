"""Reverse ETL: governed syncs of risk scores and recommendations to where the business works.

A sync is a definition (what, which columns under which names, which customers, where to) that a second person
approves.  Each run records how many rows were selected, what happened to each, and a verification.

Destinations
  crm     one CRM delivery per row through an existing connection (the connection's mode applies: a TEST_ONLY
          connection builds the requests and sends nothing);
  export  a CSV or JSON-lines file with a manifest (row count, SHA-256), for a reverse-ETL tool such as Hightouch
          or Census - or anything else - to pick up and load into Salesforce, Zendesk, Marketo and the like.
"""

from __future__ import annotations

import csv
import hashlib
import json
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, NotFound, ValidationFailed
from ..models import CRMConnection, CRMDelivery, Customer, Prediction, PredictionBatch, RetentionRecommendation, ReverseEtlRun, ReverseEtlSync
from ..security import Principal
from . import audit, crm, jobs
from .common import get_owned, to_dict

FIELDS = {
    "risk_scores": ("customer_external_id", "customer_name", "probability", "risk_tier", "risk_decile", "predicted_label", "as_of_date", "horizon_days",
                    "top_reasons", "model_version_id", "scored_at"),
    "recommendations": ("customer_external_id", "customer_name", "action_code", "channel", "segment", "priority", "status", "probability", "risk_tier",
                        "created_at"),
}  # fmt: skip
FORMATS = ("csv", "jsonl")


def sync_view(sync: ReverseEtlSync) -> dict:
    return to_dict(sync)


def run_view(run: ReverseEtlRun) -> dict:
    return to_dict(run, exclude={"export_path"}, include={"has_file": bool(run.export_path)})


def _clean(session: Session, tenant_id: int, payload: dict) -> dict:
    name = str(payload.get("name") or "").strip()
    entity, destination = payload.get("entity") or "risk_scores", payload.get("destination") or "export"
    if not name:
        raise ValidationFailed("a name is required", details={"field": "name"})
    if entity not in FIELDS:
        raise ValidationFailed(f"entity must be one of {', '.join(FIELDS)}", details={"field": "entity"})
    if destination not in ("crm", "export"):
        raise ValidationFailed("destination must be crm or export", details={"field": "destination"})
    mapping = payload.get("field_mapping") or {field: field for field in FIELDS[entity]}
    if not isinstance(mapping, dict) or not mapping:
        raise ValidationFailed("field_mapping maps an output column to a source field", details={"field": "field_mapping"})
    unknown = sorted({str(v) for v in mapping.values()} - set(FIELDS[entity]))
    if unknown:
        raise ValidationFailed(f"unknown source field(s): {', '.join(unknown)}. Available: {', '.join(FIELDS[entity])}", details={"field": "field_mapping"})
    if "customer_external_id" not in mapping.values():
        raise ValidationFailed("the mapping must include customer_external_id: without a key the destination cannot match rows", details={"field": "field_mapping"})
    filters = payload.get("filters") or {}
    if not isinstance(filters, dict) or set(filters) - {"risk_tiers", "min_probability"}:
        raise ValidationFailed("filters may contain risk_tiers and min_probability", details={"field": "filters"})
    connection_id, export_format = payload.get("connection_id"), payload.get("export_format") or "csv"
    if destination == "crm":
        if entity != "risk_scores":
            raise ValidationFailed("a CRM sync carries risk scores; recommendations reach the CRM as tasks from the Recommendations screen", details={"field": "entity"})
        get_owned(session, CRMConnection, tenant_id, int(connection_id or 0), label="CRM connection")
        export_format = None
    elif export_format not in FORMATS:
        raise ValidationFailed(f"export_format must be one of {', '.join(FORMATS)}", details={"field": "export_format"})
    return {"name": name[:160], "entity": entity, "destination": destination, "connection_id": connection_id if destination == "crm" else None,
            "export_format": export_format, "field_mapping": {str(k)[:80]: str(v) for k, v in mapping.items()}, "filters": filters}  # fmt: skip


def create(session: Session, principal: Principal, payload: dict) -> ReverseEtlSync:
    values = _clean(session, principal.tenant_id, payload)
    if session.execute(select(ReverseEtlSync.id).where(ReverseEtlSync.tenant_id == principal.tenant_id, ReverseEtlSync.name == values["name"])).first():
        raise Conflict("a sync with this name already exists")
    sync = ReverseEtlSync(tenant_id=principal.tenant_id, status="draft", created_by=principal.user_id, **values)
    session.add(sync)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="reverse_etl.sync_drafted", entity_type="reverse_etl_sync", entity_id=sync.id,
                 detail={"name": sync.name, "entity": sync.entity, "destination": sync.destination})  # fmt: skip
    return sync


def submit(session: Session, principal: Principal, sync_id: int) -> ReverseEtlSync:
    sync = get_owned(session, ReverseEtlSync, principal.tenant_id, sync_id, label="Sync")
    if sync.status != "draft":
        raise Conflict(f"only a draft can be submitted (this sync is {sync.status})")
    sync.status, sync.updated_at = "pending", utcnow()
    return sync


def review(session: Session, principal: Principal, sync_id: int, *, approve: bool, note: str | None = None) -> ReverseEtlSync:
    sync = get_owned(session, ReverseEtlSync, principal.tenant_id, sync_id, label="Sync")
    if sync.status != "pending":
        raise Conflict(f"only a submitted sync can be reviewed (this sync is {sync.status})")
    if sync.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a sync cannot be reviewed by the person who defined it", code="self_approval_forbidden")
    sync.status, sync.reviewed_by, sync.reviewed_at, sync.review_note, sync.updated_at = "approved" if approve else "rejected", principal.user_id, utcnow(), note, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="reverse_etl.sync_approved" if approve else "reverse_etl.sync_rejected",
                 entity_type="reverse_etl_sync", entity_id=sync.id, detail={"note": note})  # fmt: skip
    return sync


def set_enabled(session: Session, principal: Principal, sync_id: int, enabled: bool) -> ReverseEtlSync:
    sync = get_owned(session, ReverseEtlSync, principal.tenant_id, sync_id, label="Sync")
    if sync.status not in ("approved", "disabled"):
        raise Conflict("only an approved sync can be switched off or on")
    sync.status, sync.updated_at = "approved" if enabled else "disabled", utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="reverse_etl.sync_enabled" if enabled else "reverse_etl.sync_disabled",
                 entity_type="reverse_etl_sync", entity_id=sync.id)  # fmt: skip
    return sync


def start_run(session: Session, principal: Principal, sync_id: int, batch_id: int | None = None) -> tuple[ReverseEtlRun, Any]:
    sync = get_owned(session, ReverseEtlSync, principal.tenant_id, sync_id, label="Sync")
    if sync.status != "approved":
        raise Conflict("only an approved sync can run", code="sync_not_approved")
    if batch_id is None:
        batch = session.execute(select(PredictionBatch).where(PredictionBatch.tenant_id == principal.tenant_id, PredictionBatch.status == "completed")
                                .order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
        if batch is None:
            raise Conflict("there are no completed risk scores to sync", code="no_scores")
    else:
        batch = get_owned(session, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
        if batch.status != "completed":
            raise Conflict("only a completed batch can be synchronised")
    mode = None
    if sync.destination == "crm":
        mode = session.get(CRMConnection, sync.connection_id).mode
    run = ReverseEtlRun(tenant_id=principal.tenant_id, sync_id=sync.id, batch_id=batch.id, status="pending", mode=mode, rows=0, created_by=principal.user_id)
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="reverse_etl.run", payload={"run_id": run.id}, created_by=principal.user_id)
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="reverse_etl.run_started", entity_type="reverse_etl_run", entity_id=run.id,
                 detail={"sync": sync.name, "batch_id": batch.id, "destination": sync.destination, "mode": mode})  # fmt: skip
    return run, job


def _rows(session: Session, sync: ReverseEtlSync, batch_id: int) -> list[tuple[int, dict]]:
    """``(customer id, source row)`` for every row the sync selects from the batch."""
    filters = sync.filters or {}
    out: list[tuple[int, dict]] = []
    if sync.entity == "risk_scores":
        stmt = select(Prediction, Customer.external_id, Customer.name).join(Customer, Customer.id == Prediction.customer_id).where(Prediction.batch_id == batch_id)
        if filters.get("risk_tiers"):
            stmt = stmt.where(Prediction.risk_tier.in_(filters["risk_tiers"]))
        if filters.get("min_probability") is not None:
            stmt = stmt.where(Prediction.probability >= filters["min_probability"])
        for prediction, external_id, name in session.execute(stmt.order_by(Prediction.probability.desc(), Prediction.id)):
            out.append((prediction.customer_id, {
                "customer_external_id": external_id, "customer_name": name, "probability": round(prediction.probability, 6), "risk_tier": prediction.risk_tier,
                "risk_decile": prediction.risk_decile, "predicted_label": prediction.predicted_label, "as_of_date": prediction.as_of_date.isoformat(),
                "horizon_days": prediction.horizon_days, "top_reasons": "; ".join(r["text"] for r in (prediction.top_reasons or [])),
                "model_version_id": prediction.model_version_id, "scored_at": prediction.created_at.isoformat(), "_prediction_id": prediction.id,
                "_reasons": [r["text"] for r in (prediction.top_reasons or [])]}))  # fmt: skip
        return out
    stmt = (select(RetentionRecommendation, Customer.external_id, Customer.name, Prediction.probability, Prediction.risk_tier)
            .join(Customer, Customer.id == RetentionRecommendation.customer_id).join(Prediction, Prediction.id == RetentionRecommendation.prediction_id)
            .where(RetentionRecommendation.batch_id == batch_id))  # fmt: skip
    if filters.get("risk_tiers"):
        stmt = stmt.where(Prediction.risk_tier.in_(filters["risk_tiers"]))
    if filters.get("min_probability") is not None:
        stmt = stmt.where(Prediction.probability >= filters["min_probability"])
    for rec, external_id, name, probability, tier in session.execute(stmt.order_by(RetentionRecommendation.priority, RetentionRecommendation.id)):
        out.append((rec.customer_id, {"customer_external_id": external_id, "customer_name": name, "action_code": rec.action_code, "channel": rec.channel,
                                      "segment": rec.segment, "priority": rec.priority, "status": rec.status, "probability": round(probability, 6),
                                      "risk_tier": tier, "created_at": rec.created_at.isoformat()}))  # fmt: skip
    return out


def run(run_id: int, ctx: Any = None) -> dict:
    with read_session() as rs:
        entry = rs.get(ReverseEtlRun, run_id)
        if entry is None:
            raise jobs.PermanentJobError(f"reverse-ETL run {run_id} does not exist")
        sync = rs.get(ReverseEtlSync, entry.sync_id)
        rows = _rows(rs, sync, entry.batch_id)
        tenant_id, mapping, destination, export_format, connection_id = entry.tenant_id, dict(sync.field_mapping), sync.destination, sync.export_format, sync.connection_id
    try:
        if destination == "export":
            relative = f"exports/tenant-{tenant_id}/sync-{sync.id}/run-{run_id}.{export_format}"
            path = storage.data_root() / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            columns = list(mapping)
            with open(path, "w", newline="", encoding="utf-8") as handle:
                if export_format == "csv":
                    writer = csv.writer(handle)
                    writer.writerow(columns)
                    for _customer_id, row in rows:
                        writer.writerow(["" if row[mapping[c]] is None else row[mapping[c]] for c in columns])
                else:
                    for _customer_id, row in rows:
                        handle.write(json.dumps({c: row[mapping[c]] for c in columns}, ensure_ascii=False) + "\n")
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            with open(path, encoding="utf-8", newline="") as handle:
                written = sum(1 for _ in handle) - (1 if export_format == "csv" else 0)
            verification = {"rows_selected": len(rows), "rows_in_file": written, "matches": written == len(rows), "sha256": digest, "columns": columns,
                            "checked": "the file was read back and its rows counted"}  # fmt: skip
            (path.with_suffix(path.suffix + ".manifest.json")).write_text(json.dumps({"run_id": run_id, "sync": sync.name, "rows": written, "sha256": digest,
                                                                                         "columns": columns, "created_at": utcnow().isoformat()}, indent=2))  # fmt: skip
            counts, stored_path = {"written": written}, storage.to_stored(path)
        else:
            counts, stored_path, digest = {"queued": 0, "already_queued": 0}, None, None
            with session_scope() as ws:
                connection = ws.get(CRMConnection, connection_id)
                for customer_id, row in rows:
                    payload = {"external_id": row["customer_external_id"], "probability": row["probability"], "risk_tier": row["risk_tier"],
                               "top_reasons": row["_reasons"], "as_of_date": row["as_of_date"]}  # fmt: skip
                    key = f"pred:{row['_prediction_id']}"
                    before = ws.execute(select(CRMDelivery.id).where(CRMDelivery.idempotency_key == f"{connection.id}:risk_score:{key}")).first()
                    delivery = crm.enqueue_delivery(ws, None, connection, customer_id=customer_id, kind="risk_score", payload=payload, key=key)
                    if delivery.sync_run_id is None:
                        delivery.sync_run_id = run_id
                    counts["queued" if before is None else "already_queued"] += 1
            verification = {"rows_selected": len(rows), "deliveries": counts, "checked": "pending: verify after the deliveries have run"}
    except Exception as exc:
        with session_scope() as ws:
            entry = ws.get(ReverseEtlRun, run_id)
            entry.status, entry.error, entry.finished_at = "failed", f"{type(exc).__name__}: {exc}"[:1000], utcnow()
        raise
    with session_scope() as ws:
        entry = ws.get(ReverseEtlRun, run_id)
        entry.status, entry.rows, entry.counts, entry.export_path, entry.export_sha256, entry.verification, entry.finished_at = "completed", len(rows), counts, stored_path, digest, verification, utcnow()
        audit.record(ws, tenant_id=tenant_id, action="reverse_etl.run_completed", entity_type="reverse_etl_run", entity_id=run_id,
                     detail={"rows": len(rows), "destination": destination, "counts": counts})  # fmt: skip
    return {"run_id": run_id, "rows": len(rows), "counts": counts}


def verify(session: Session, principal: Principal, run_id: int) -> ReverseEtlRun:
    """Check a finished run against its destination: the file's checksum, or what became of each CRM delivery."""
    entry = get_owned(session, ReverseEtlRun, principal.tenant_id, run_id, label="Run")
    if entry.status != "completed":
        raise Conflict("only a completed run can be verified")
    if entry.export_path:
        path = storage.resolve(entry.export_path)
        present = path.is_file()
        digest = hashlib.sha256(path.read_bytes()).hexdigest() if present else None
        entry.verification = {**(entry.verification or {}), "file_present": present, "sha256_now": digest, "unchanged": digest == entry.export_sha256,
                              "verified_at": utcnow().isoformat()}  # fmt: skip
    else:
        by_status = dict(session.execute(select(CRMDelivery.status, func.count()).where(CRMDelivery.sync_run_id == entry.id).group_by(CRMDelivery.status)).all())
        confirmed = session.execute(select(func.count()).select_from(CRMDelivery).where(CRMDelivery.sync_run_id == entry.id, CRMDelivery.verified_at.is_not(None))).scalar_one()
        total, unfinished = sum(by_status.values()), by_status.get("pending", 0) + by_status.get("failed", 0)
        entry.verification = {"rows_selected": entry.rows, "deliveries": total, "by_status": by_status, "confirmed_by_the_crm": confirmed,
                              "transmitted": by_status.get("sent", 0), "not_transmitted": by_status.get("skipped", 0),
                              "complete": unfinished == 0 and total == entry.rows, "verified_at": utcnow().isoformat(),
                              "note": "TEST_ONLY connection: requests were built and nothing was transmitted" if entry.mode == "TEST_ONLY" else None}  # fmt: skip
    return entry


def download(session: Session, principal: Principal, run_id: int) -> tuple[bytes, str, str]:
    entry = get_owned(session, ReverseEtlRun, principal.tenant_id, run_id, label="Run")
    if not entry.export_path:
        raise NotFound("this run produced no file")
    path = storage.resolve(entry.export_path)
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != entry.export_sha256:
        raise Conflict("the export file no longer matches the checksum recorded when it was written", code="export_changed")
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="reverse_etl.file_downloaded", entity_type="reverse_etl_run", entity_id=entry.id,
                 detail={"rows": entry.rows, "sha256": entry.export_sha256})  # fmt: skip
    return data, path.name, "text/csv" if path.suffix == ".csv" else "application/x-ndjson"


def overview(session: Session, tenant_id: int) -> dict:
    syncs = session.execute(select(ReverseEtlSync).where(ReverseEtlSync.tenant_id == tenant_id).order_by(ReverseEtlSync.id.desc())).scalars().all()
    runs = session.execute(select(ReverseEtlRun).where(ReverseEtlRun.tenant_id == tenant_id).order_by(ReverseEtlRun.id.desc()).limit(30)).scalars().all()
    return {"syncs": [sync_view(s) for s in syncs], "runs": [run_view(r) for r in runs], "fields": {k: list(v) for k, v in FIELDS.items()}}
