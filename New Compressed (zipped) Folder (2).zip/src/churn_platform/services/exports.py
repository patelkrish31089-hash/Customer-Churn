"""Destination exports: the product path into the delivery layer (1.3.0).

Until this module existed the delivery layer had no caller.  The canonical record, the destination pipeline and the
Snowflake adapter were implemented and tested, the outbox and the checkpoint had a migration behind them, and nothing
in the API, the worker or the browser application reached any of it — a library with a schema behind it.  R-98 said
so in the register, and this is the code that answers it:

* ``POST /api/v1/exports/runs`` starts a run for a prediction batch and a destination, writes the run row and queues
  ``export.run``;
* the worker's ``export.run`` handler drains it — build the canonical records, hand them to the destination, record
  every record's outcome, advance the tenant's checkpoint;
* ``POST /api/v1/exports/runs/{id}/resume`` queues the same run again and sends **only** what was not acknowledged;
* ``POST /api/v1/exports/runs/{id}/reconcile`` asks the destination what it currently holds for the run and compares.

Three decisions are worth stating, because they are the places where "wired up" usually turns out to be a facade:

**The selection is written down.**  A run records the batch, the limit and whether it was a full export in its
``verification`` document, so a resumed job — or a different process, tomorrow — selects exactly what the original run
selected.  A job payload alone would not survive the retry.

**A destination that cannot be built is a refusal, not a crash.**  ``destination_for`` raises
:class:`~churn_platform.errors.ValidationFailed` naming what is missing: the environment variables for Snowflake, the
driver package, or the destination itself.  Nothing in the product pretends a vendor is reachable when it is not, and
``GET /exports/destinations`` reports the same list so an operator can see it without starting a run.

**The vendor boundary stays visible.**  ``snowflake`` is registered here and built from the installation's settings;
this repository cannot prove a warehouse accepts anything (GATE 12) and does not claim to.  A deployment that has the
driver and the credentials gets the real thing; a test registers a stand-in through :func:`register_destination`, which
is the same seam a future CRM or support-desk destination plugs into.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, NotFound, ValidationFailed
from ..models import Customer, ExportRun, FeatureContract, ModelRun, ModelVersion, Prediction, PredictionBatch
from ..security import Principal
from . import audit, export_outbox, export_record, jobs
from .destinations import PostgresConfig, PostgresDestination, SnowflakeConfig, SnowflakeDestination
from .destinations.base import (
    Destination,
    RetryPolicy,
    deliver,
    idempotency_key,
)

JOB_TYPE = "export.run"
DEFAULT_LIMIT = 5000
#: how many records one statement carries; the delivery layer retries and splits a failing batch on its own
DEFAULT_BATCH_SIZE = 500

DestinationFactory = Callable[[], Destination]
_DESTINATIONS: dict[str, DestinationFactory] = {}


# ----------------------------------------------------------------------------- the registry
def register_destination(name: str, factory: DestinationFactory) -> None:
    """Make a destination available to the product.

    Built-in destinations are registered at import; a deployment or a test registers its own here.  The factory is
    called per run rather than once, because a destination holds a connection and a long-lived one would be shared by
    two runs with different tenants.
    """
    if not str(name or "").strip():
        raise ValidationFailed("a destination needs a name", details={"field": "name"})
    _DESTINATIONS[str(name)] = factory


def registered() -> list[str]:
    """The destinations this installation knows about, in a stable order."""
    return sorted(_DESTINATIONS)


def destination_for(name: str) -> Destination:
    """Build the destination, or refuse with the reason.

    A refusal here is the honest answer when a vendor is not configured: the caller learns which environment variables
    are missing instead of a run that fails later with a driver traceback.
    """
    factory = _DESTINATIONS.get(str(name or ""))
    if factory is None:
        raise ValidationFailed(
            f"'{name}' is not a destination this installation knows about",
            details={"destination": name, "known": registered()},
        )
    return factory()


def _close(destination: Any) -> None:
    """Close a destination that was built only to ask it a question.

    A factory may answer without connecting — but one that does connect leaves the connection to whatever the caller
    does with it, and two of the three callers below only wanted to know whether it could be built at all.  A pool that
    leaks one connection per export screen refresh is not a hypothesis worth testing in production.
    """
    closer = getattr(destination, "close", None)
    if callable(closer):
        closer()


def _probe(name: str) -> None:
    """Raise the refusal a destination gives when it is not configured, and close what was built to find out."""
    _close(destination_for(name))


def _snowflake_connect() -> Callable[..., Any]:
    """``snowflake.connector.connect`` with the installation's key, imported only when it is needed."""
    settings = get_settings()
    try:
        import snowflake.connector  # type: ignore[import-not-found]
    except ModuleNotFoundError as exc:  # pragma: no cover - the driver is not a dependency of this repository
        raise ValidationFailed(
            "the Snowflake destination needs snowflake-connector-python, which is not installed in this environment",
            details={"destination": "snowflake", "package": "snowflake-connector-python"},
        ) from exc
    options: dict[str, Any] = {}
    if settings.export_snowflake_private_key_file:
        try:
            options["private_key_file"] = str(settings.export_snowflake_private_key_file)
        except OSError as exc:  # pragma: no cover - depends on a deployed file
            raise ValidationFailed(
                f"the Snowflake private key could not be read: {exc}",
                details={"field": "CHURN_EXPORT_SNOWFLAKE_PRIVATE_KEY_FILE"},
            ) from exc
    return lambda **kwargs: snowflake.connector.connect(**{**options, **kwargs})


def _snowflake_factory() -> Destination:
    settings = get_settings()
    missing = [name for name, value in (
        ("CHURN_EXPORT_SNOWFLAKE_ACCOUNT", settings.export_snowflake_account),
        ("CHURN_EXPORT_SNOWFLAKE_USER", settings.export_snowflake_user),
        ("CHURN_EXPORT_SNOWFLAKE_WAREHOUSE", settings.export_snowflake_warehouse),
        ("CHURN_EXPORT_SNOWFLAKE_DATABASE", settings.export_snowflake_database),
    ) if not str(value or "").strip()]  # fmt: skip
    if missing:
        raise ValidationFailed(
            "the Snowflake destination is not configured on this installation: " + ", ".join(missing) + " are unset",
            details={"destination": "snowflake", "missing": missing},
        )
    config = SnowflakeConfig(
        account=str(settings.export_snowflake_account),
        user=str(settings.export_snowflake_user),
        warehouse=str(settings.export_snowflake_warehouse),
        database=str(settings.export_snowflake_database),
        schema=str(settings.export_snowflake_schema or "PUBLIC"),
        role=settings.export_snowflake_role or None,
        authenticator=str(settings.export_snowflake_authenticator or "snowflake_jwt"),
    )
    return SnowflakeDestination(config=config, connect=_snowflake_connect())


def _postgres_connect() -> Callable[..., Any]:
    """``psycopg.connect``, imported only when a PostgreSQL destination is actually built."""
    try:
        import psycopg
    except ModuleNotFoundError as exc:  # pragma: no cover - psycopg is a dependency of this repository
        raise ValidationFailed(
            "the PostgreSQL destination needs psycopg, which is not installed in this environment",
            details={"destination": "postgres", "package": "psycopg"},
        ) from exc
    return psycopg.connect


def _postgres_factory() -> Destination:
    """A destination that is a real database and needs nobody's account: this installation's own PostgreSQL.

    It exists for two reasons.  A deployment without a warehouse can still export, into a table it already operates;
    and this repository can prove the delivery layer against a system it did not write, which no stand-in can.
    """
    settings = get_settings()
    url = str(settings.export_postgres_url or "").strip()
    if not url:
        raise ValidationFailed(
            "the PostgreSQL destination is not configured on this installation: CHURN_EXPORT_POSTGRES_URL is unset",
            details={"destination": "postgres", "missing": ["CHURN_EXPORT_POSTGRES_URL"]},
        )
    config = PostgresConfig(url=url, schema=str(settings.export_postgres_schema or "public"))
    problems = config.problems()
    if problems:
        raise ValidationFailed(
            f"the PostgreSQL destination is not usable: {problems[0]}", details={"destination": "postgres", "problems": problems}
        )
    return PostgresDestination(config=config, connect=_postgres_connect())


register_destination("snowflake", _snowflake_factory)
register_destination("postgres", _postgres_factory)


# ----------------------------------------------------------------------------- records for a run
def _selection(batch_id: int | None, *, limit: int | None, full: bool) -> dict[str, Any]:
    return {"batch_id": batch_id, "limit": limit, "full": bool(full)}


def _batch(session: Session, tenant_id: int, batch_id: int | None) -> PredictionBatch:
    """The batch a run exports: the one asked for, or the tenant's latest completed one."""
    stmt = select(PredictionBatch).where(PredictionBatch.tenant_id == tenant_id, PredictionBatch.status == "completed")
    if batch_id is not None:
        stmt = stmt.where(PredictionBatch.id == batch_id)
    batch = session.execute(stmt.order_by(PredictionBatch.id.desc()).limit(1)).scalar_one_or_none()
    if batch is None:
        raise NotFound(
            f"batch {batch_id} does not exist for this tenant" if batch_id is not None
            else "there is no completed prediction batch to export yet"
        )  # fmt: skip
    return batch


def records_for(session: Session, tenant_id: int, selection: dict[str, Any]) -> list[dict[str, Any]]:
    """The canonical records a run selects, newest last, without the destination's watermark applied.

    Every record is built by :func:`churn_platform.services.export_record.from_prediction`, so a model that is not
    approved, a missing artefact digest or a naive timestamp is refused here rather than at the destination.
    """
    batch = _batch(session, tenant_id, selection.get("batch_id"))
    limit = int(selection.get("limit") or 0)
    stmt = (
        select(Prediction, Customer, ModelVersion, FeatureContract, ModelRun)
        .join(Customer, Customer.id == Prediction.customer_id)
        .join(ModelVersion, ModelVersion.id == Prediction.model_version_id)
        .join(FeatureContract, FeatureContract.id == Prediction.contract_id)
        .join(ModelRun, ModelRun.id == ModelVersion.model_run_id, isouter=True)
        .where(Prediction.tenant_id == tenant_id, Prediction.batch_id == batch.id)
        .order_by(Prediction.created_at, Prediction.id)
    )
    rows = session.execute(stmt).all()
    if limit:
        rows = rows[:limit]
    out: list[dict[str, Any]] = []
    for prediction, customer, version, contract, run in rows:
        checksum = getattr(run, "artifact_sha256", None) or ""
        if not checksum:
            raise ValidationFailed(
                f"model version {version.name} v{version.version} has no artefact digest, so a record cannot say which "
                "model produced it",
                details={"field": "model_checksum", "model_version_id": version.id},
            )
        out.append(
            export_record.from_prediction(
                prediction, customer, version,
                feature_version=f"{contract.name}-v{contract.version}", model_checksum=checksum,
                tenant_id=tenant_id,
            )
        )  # fmt: skip
    return out


def _pending(session: Session, tenant_id: int, destination: str, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Drop what this tenant's deliveries have already had acknowledged, so a resume sends only the rest."""
    done = export_outbox.acknowledged_keys(session, tenant_id, destination)
    return [record for record in records if idempotency_key(destination, record) not in done]


# ----------------------------------------------------------------------------- the API side
def start(session: Session, principal: Principal, payload: dict[str, Any]) -> tuple[ExportRun, Any]:
    """Start an export run and queue it.  The run row exists before the job does, so a job that never starts is visible."""
    destination = str(payload.get("destination") or "").strip()
    if not destination:
        raise ValidationFailed("an export needs a destination", details={"field": "destination"})
    _probe(destination)  # refuse an unknown or unconfigured destination before writing anything
    limit = payload.get("limit")
    if limit is not None:
        limit = int(limit)
        if limit <= 0:
            raise ValidationFailed("limit must be positive", details={"field": "limit"})
    # resolve the batch now and write its id down: a retried job tomorrow must select what this run selected
    batch = _batch(session, principal.tenant_id, payload.get("batch_id"))
    selection = _selection(batch.id, limit=limit or DEFAULT_LIMIT, full=bool(payload.get("full")))
    records = records_for(session, principal.tenant_id, selection)
    if not selection["full"]:
        from .destinations.base import filter_after

        watermark = export_outbox.watermark_for(session, principal.tenant_id, destination)
        records = filter_after(records, watermark)
    if not records:
        behind = export_outbox.watermark_for(session, principal.tenant_id, destination)
        raise Conflict(
            "there is nothing to export: every record of that batch is at or behind this destination's watermark",
            details={"destination": destination, "watermark": behind.isoformat() if behind else None},
        )
    run_id = f"{utcnow().strftime('%Y%m%dT%H%M%S')}Z-{uuid4().hex[:8]}"
    run = ExportRun(tenant_id=principal.tenant_id, destination=destination, run_id=run_id, status="pending",
                    records_selected=len(records), started_at=utcnow(),
                    verification={"selection": selection, "state": "queued"})
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type=JOB_TYPE, payload={"export_run_id": run.id},
                       created_by=principal.user_id, idempotency_key=f"export-run:{run.id}")  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, action="export.run_requested", actor=principal,
                 entity_type="export_run", entity_id=run.id,
                 detail={"destination": destination, "batch_id": selection["batch_id"], "selected": len(records)})  # fmt: skip
    return run, job


def resume(session: Session, principal: Principal, export_run_id: int) -> tuple[ExportRun, Any]:
    """Queue a finished-with-failures run again.  Only the records that were not acknowledged are sent."""
    run = get_owned_run(session, principal.tenant_id, export_run_id)
    if run.status in ("pending", "running"):
        raise Conflict(f"run {run.run_id} is still {run.status}; there is nothing to resume")
    outstanding = export_outbox.outstanding(session, principal.tenant_id, run.destination)
    if not outstanding:
        raise Conflict(f"run {run.run_id} has nothing outstanding: every record it selected was acknowledged")
    run.status, run.finished_at = "pending", None
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type=JOB_TYPE, payload={"export_run_id": run.id},
                       created_by=principal.user_id)  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, action="export.run_resumed", actor=principal,
                 entity_type="export_run", entity_id=run.id,
                 detail={"destination": run.destination, "outstanding": len(outstanding)})  # fmt: skip
    return run, job


def reconcile_run(session: Session, principal: Principal, export_run_id: int) -> dict[str, Any]:
    """Ask the destination what it holds for a finished run, and compare it with what was recorded."""
    run = get_owned_run(session, principal.tenant_id, export_run_id)
    if run.status in ("pending", "running"):
        raise Conflict(f"run {run.run_id} has not finished, so there is nothing to reconcile yet")
    destination = destination_for(run.destination)
    try:
        stored = destination.count_stored(run_id=run.run_id)
    except Exception as exc:  # the destination is allowed to be unreachable; that is a result, not a crash
        result = {"checked": "unknown", "reason": f"{type(exc).__name__}: {str(exc)[:200]}", "expected": run.records_acknowledged}
    else:
        if stored is None:
            result = {"checked": "unknown", "reason": "the destination cannot count rows for a run", "expected": run.records_acknowledged}
        else:
            result = {"checked": "counted", "expected": run.records_acknowledged, "stored": stored,
                      "matches": stored >= run.records_acknowledged}  # fmt: skip
    finally:
        _close(destination)
    audit.record(session, tenant_id=principal.tenant_id, action="export.run_reconciled", actor=principal,
                 entity_type="export_run", entity_id=run.id, detail=result)  # fmt: skip
    return {"run": run_view(run), "reconciliation": result}


def get_owned_run(session: Session, tenant_id: int, export_run_id: int) -> ExportRun:
    run = session.get(ExportRun, export_run_id)
    if run is None or run.tenant_id != tenant_id:
        raise NotFound(f"export run {export_run_id} does not exist")
    return run


def list_runs(session: Session, tenant_id: int, *, limit: int = 25) -> list[dict[str, Any]]:
    runs = session.execute(
        select(ExportRun).where(ExportRun.tenant_id == tenant_id).order_by(ExportRun.id.desc()).limit(max(1, min(limit, 200)))
    ).scalars()  # fmt: skip
    return [run_view(run) for run in runs]


def overview(session: Session, tenant_id: int) -> dict[str, Any]:
    """What the exports screen shows: the destinations, where each tenant's watermark stands, and the backlog."""
    destinations = []
    for name in registered():
        checkpoint = export_outbox.checkpoint_for(session, tenant_id, name)
        try:
            _probe(name)
        except ValidationFailed as refused:
            state, reason = "unconfigured", refused.message
        else:
            state, reason = "configured", None
        destinations.append({
            "name": name, "state": state, "reason": reason,
            "watermark": checkpoint.watermark.isoformat() if checkpoint and checkpoint.watermark else None,
            "last_run_id": checkpoint.last_run_id if checkpoint else None,
            "outstanding": len(export_outbox.outstanding(session, tenant_id, name)),
        })  # fmt: skip
    runs = list_runs(session, tenant_id)
    by_status: dict[str, int] = {}
    for run in runs:
        by_status[run["status"]] = by_status.get(run["status"], 0) + 1
    return {
        "destinations": destinations,
        "runs": runs,
        "by_status": by_status,
        "note": ("A run selects the canonical record for every prediction of a batch, hands it to the destination, "
                 "records each record's own outcome and advances the tenant's watermark only over the acknowledged, "
                 "contiguous prefix. A vendor is reachable only when it is configured on this installation."),
    }


def outstanding_view(session: Session, tenant_id: int, destination: str, *, limit: int = 100) -> dict[str, Any]:
    rows = export_outbox.outstanding(session, tenant_id, destination)[:limit]
    return {
        "destination": destination,
        "outstanding": len(export_outbox.outstanding(session, tenant_id, destination)),
        "items": [{
            "identity": row.identity_key, "status": row.status, "attempts": row.attempts,
            "prediction_timestamp": row.prediction_timestamp.isoformat() if row.prediction_timestamp else None,
            "error": row.error_description, "error_code": row.error_code,
        } for row in rows],
    }


# ----------------------------------------------------------------------------- the worker side
def run(export_run_id: int, ctx: Any = None) -> dict[str, Any]:
    """Deliver a run: build the records, hand them to the destination, write down what happened.

    Safe to call twice for the same run.  The outbox decides what is left to send, so a resumed or retried job sends
    exactly the records that were not acknowledged — not the batch again.
    """
    with read_session() as session:
        run_row = session.get(ExportRun, export_run_id)
        if run_row is None:
            raise jobs.PermanentJobError(f"export run {export_run_id} does not exist")
        tenant_id, destination_name = run_row.tenant_id, run_row.destination
        selection = dict((run_row.verification or {}).get("selection") or {})
        run_key = run_row.run_id
    destination = None
    try:
        started_at = utcnow()
        destination = destination_for(destination_name)
        destination.ensure_schema()
        with read_session() as session:
            records = records_for(session, tenant_id, selection)
            pending = _pending(session, tenant_id, destination_name, records)
        if ctx is not None:
            ctx.progress(0.1, f"delivering {len(pending)} record(s) to {destination_name}")
        result = deliver(destination, pending, run_id=run_key, batch_size=DEFAULT_BATCH_SIZE,
                         policy=RetryPolicy())  # fmt: skip
        # The destination's own run row, written while its connection is still open and before this database is
        # touched again: a warehouse that refuses the row must not turn a delivered run into a failed one, so the
        # failure is recorded rather than raised.
        recorded_where = None
        writer = getattr(destination, "record_run", None)
        if callable(writer):
            try:
                writer(run_id=run_key, tenant_id=tenant_id, expected=result.selected, written=result.written,
                       checksum=result.checksum, watermark=result.watermark, actor=None, started_at=started_at)
            except Exception as exc:
                recorded_where = f"not recorded: {type(exc).__name__}: {str(exc)[:200]}"
            else:
                recorded_where = f"recorded in {destination_name}"
    except Exception as exc:
        with session_scope() as session:
            run_row = session.get(ExportRun, export_run_id)
            run_row.status, run_row.finished_at = "failed", utcnow()
            run_row.verification = {**(run_row.verification or {}), "error": f"{type(exc).__name__}: {str(exc)[:500]}",
                                    "state": "failed"}  # fmt: skip
            audit.record(session, tenant_id=tenant_id, action="export.run_failed", entity_type="export_run",
                         entity_id=export_run_id, detail={"destination": destination_name, "error": str(exc)[:300]})  # fmt: skip
        if isinstance(exc, ValidationFailed):
            raise jobs.PermanentJobError(str(exc)) from exc
        raise
    finally:
        # a run does not leave a connection to a warehouse open: the next run opens its own, and a worker that drains a
        # hundred runs must not hold a hundred connections.
        closer = getattr(destination, "close", None)
        if callable(closer):
            closer()

    with session_scope() as session:
        run_row = session.get(ExportRun, export_run_id)
        export_outbox.record_run(session, result, tenant_id=tenant_id)  # sets the delivery's own verification document
        if recorded_where:
            run_row.verification = {**(run_row.verification or {}), "destination_run_row": recorded_where}
        run_row.verification = {"selection": selection, "delivery": dict(run_row.verification or {}), "state": "recorded"}
        audit.record(session, tenant_id=tenant_id, action="export.run_completed", entity_type="export_run",
                     entity_id=export_run_id,
                     detail={"destination": destination_name, "selected": result.selected, "written": result.written,
                             "failed": result.failed, "quarantined": len(result.quarantined)})  # fmt: skip
        payload = {"run_id": export_run_id, "destination": destination_name, "selected": result.selected,
                   "acknowledged": result.written, "failed": result.failed, "quarantined": len(result.quarantined),
                   "checksum": result.checksum, "verification": result.verification}  # fmt: skip
    if ctx is not None:
        ctx.progress(1.0, f"delivered {result.written} of {result.selected}", force=True)
    return payload


def run_view(run: ExportRun) -> dict[str, Any]:
    """The run as the API returns it: the delivery counters plus what the run was asked to select."""
    view = export_outbox.run_view(run)
    view["selection"] = dict((run.verification or {}).get("selection") or {})
    view["state"] = str((run.verification or {}).get("state") or run.status)
    view["error"] = dict(run.verification or {}).get("error")
    return view


__all__ = [
    "JOB_TYPE",
    "destination_for",
    "get_owned_run",
    "list_runs",
    "outstanding_view",
    "overview",
    "reconcile_run",
    "records_for",
    "register_destination",
    "registered",
    "resume",
    "run",
    "run_view",
    "start",
]
