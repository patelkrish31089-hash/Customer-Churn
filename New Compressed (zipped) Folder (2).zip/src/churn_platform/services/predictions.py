"""Prediction engine: batch, scheduled and single-customer scoring with approved models only.

Batch output per customer: churn probability, risk tier, risk decile and the top three
risk-raising factors (SHAP), ready for reverse ETL into a CRM.
"""

from __future__ import annotations

import csv
import io
import math
from collections import Counter
from datetime import date, timedelta
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, insert, select, update
from sqlalchemy.orm import Session

from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, NotFound, ValidationFailed
from ..models import Customer, Explanation, FeatureContract, MLDataset, ModelRun, ModelVersion, Policy, Prediction, PredictionBatch
from ..security import Principal
from . import audit, explain, features, jobs, labels, policies, registry, timeline, training
from .common import get_owned, json_safe, parse_date, to_dict
from .policies import RiskPolicy

TIERS = ("high", "medium", "low")


def default_as_of(session: Session, tenant_id: int) -> date:
    cutoff = timeline.data_cutoff(session, tenant_id)
    if cutoff is None:
        raise Conflict("no data has been ingested yet", code="no_data")
    return cutoff.date() + timedelta(days=1)  # the first instant after the last observed day


def risk_policy_for(session: Session, tenant_id: int) -> tuple[RiskPolicy, dict]:
    policy = policies.get_active(session, tenant_id, "risk_policy", required=False)
    if policy is None:
        return RiskPolicy(), {"source": "structural default (not an approved policy)", "policy_id": None}
    return policies.parse(policy), {"source": "approved policy", "policy_id": policy.id, "version": policy.version}


def assign_tiers(prob: np.ndarray, policy: RiskPolicy) -> tuple[list[str], np.ndarray, dict]:
    """Rank-based tiers (top share = high) and deciles (1 = highest risk)."""
    n = len(prob)
    order = np.argsort(-prob, kind="stable")
    rank = np.empty(n, dtype=int)
    rank[order] = np.arange(n)
    n_high = math.ceil(n * policy.high_risk_top_share) if n else 0
    n_medium = math.ceil(n * policy.medium_risk_top_share) if n else 0
    tiers = np.where(rank < n_high, "high", np.where(rank < n_medium, "medium", "low")).tolist()
    deciles = np.minimum(rank * 10 // max(n, 1) + 1, 10)
    sorted_p = prob[order]
    cut = {"high_min_probability": float(sorted_p[n_high - 1]) if n_high else None,
           "medium_min_probability": float(sorted_p[n_medium - 1]) if n_medium else None,
           "decile_min_probability": [float(sorted_p[min(n - 1, math.ceil(n * k / 10) - 1)]) for k in range(1, 11)] if n else []}  # fmt: skip
    return tiers, deciles, cut


def place(probability: float, cutpoints: dict) -> tuple[str, int]:
    """Tier/decile of a single score relative to a reference batch's cut points."""
    tier = "low"
    if cutpoints.get("high_min_probability") is not None and probability >= cutpoints["high_min_probability"]:
        tier = "high"
    elif cutpoints.get("medium_min_probability") is not None and probability >= cutpoints["medium_min_probability"]:
        tier = "medium"
    decile = next((k for k, bound in enumerate(cutpoints.get("decile_min_probability") or [], start=1) if probability >= bound), 10)
    return tier, decile


def model_definition(session: Session, run: ModelRun) -> Policy:
    """The churn definition a model was trained under (its dataset's policy), which also defines whom it may score."""
    return session.get(Policy, session.get(MLDataset, run.dataset_id).policy_id)


def _servable(session: Session, tenant_id: int, model_version_id: int | None) -> tuple[ModelVersion, ModelRun, FeatureContract]:
    version = registry.production_version(session, tenant_id, version_id=model_version_id)
    run = session.get(ModelRun, version.model_run_id)
    contract = features.require_usable(session.get(FeatureContract, version.contract_id))
    return version, run, contract


def start_batch(session: Session, principal: Principal | None, *, tenant_id: int, model_version_id: int | None = None,
                as_of_date: Any = None, kind: str = "batch", created_by: int | None = None) -> tuple[PredictionBatch, Any]:
    version, _run, _contract = _servable(session, tenant_id, model_version_id)
    as_of = parse_date(as_of_date, field="as_of_date") or default_as_of(session, tenant_id)
    if as_of > default_as_of(session, tenant_id):
        raise ValidationFailed("as_of_date cannot be later than the day after the data cutoff", details={"field": "as_of_date"})
    key = f"batch:{version.id}:{as_of.isoformat()}"
    batch = session.execute(select(PredictionBatch).where(PredictionBatch.tenant_id == tenant_id,
                                                          PredictionBatch.idempotency_key == key)).scalar_one_or_none()  # fmt: skip
    if batch is not None and batch.status in ("running", "completed"):
        return batch, None  # idempotent: the same model + as-of date is never scored twice
    user_id = principal.user_id if principal else created_by
    if batch is None:
        batch = PredictionBatch(tenant_id=tenant_id, model_version_id=version.id, as_of_date=as_of, kind=kind, status="running",
                                idempotency_key=key, created_by=user_id)  # fmt: skip
        session.add(batch)
        session.flush()
    else:
        batch.status = "running"
    job = jobs.enqueue(session, tenant_id=tenant_id, job_type="predict.batch", payload={"batch_id": batch.id}, created_by=user_id)
    batch.job_id = job.id
    audit.record(session, tenant_id=tenant_id, actor=principal, action="predict.batch_started", entity_type="prediction_batch",
                 entity_id=batch.id, detail={"model_version_id": version.id, "as_of_date": as_of.isoformat(), "kind": kind})  # fmt: skip
    return batch, job


def score_frame(bundle: dict, frame: pd.DataFrame) -> tuple[np.ndarray, dict]:
    prob = training.predict_proba(bundle, frame)
    return prob, explain.explain_rows(bundle, frame)


def run_batch(batch_id: int, ctx: Any = None) -> dict:
    try:
        with read_session() as rs:
            batch = rs.get(PredictionBatch, batch_id)
            if batch is None:
                raise jobs.PermanentJobError(f"prediction batch {batch_id} does not exist")
            tenant_id, as_of = batch.tenant_id, batch.as_of_date
            try:
                version, run, contract = _servable(rs, tenant_id, batch.model_version_id)
            except (Conflict, NotFound) as exc:
                raise jobs.PermanentJobError(exc.message) from exc
            bundle = training.load_bundle(run)
            if bundle["features"] != list(contract.features) or bundle.get("contract_schema_hash") != contract.schema_hash:
                raise jobs.PermanentJobError("the model was trained under a different feature contract than the one registered")
            risk_policy, risk_source = risk_policy_for(rs, tenant_id)
            threshold, horizon = version.threshold, int(bundle.get("horizon_days", 30))
            stored = features.offline_frame(rs, tenant_id, contract, dates=[as_of])
            definition = model_definition(rs, run)
            label_frames = timeline.load_frames(rs, tenant_id, tables=labels.LABEL_TABLES)
        if ctx is not None:
            ctx.progress(0.1, "model loaded", force=True)
        if stored.empty:
            frame = features.compute_for(tenant_id, list(contract.features), [as_of],
                                         progress=(lambda f, m: ctx.progress(0.1 + 0.5 * f, m, force=True)) if ctx else None)  # fmt: skip
            feature_source = "computed for this batch"
        else:
            frame, feature_source = stored, "offline feature store"
        if frame.empty:
            raise jobs.PermanentJobError(f"no customer has an active subscription on {as_of.isoformat()}")
        # The feature store holds every customer with an active subscription, trials included.  The model is asked
        # about the population it was trained on: the customers its churn definition covers at this date.
        covered, left_out = labels.covered_population(label_frames, policies.parse(definition), as_of)
        in_scope = frame["customer_id"].isin(covered)
        not_scored = Counter(left_out.get(int(c), "not_covered") for c in frame.loc[~in_scope, "customer_id"])
        frame = frame[in_scope].reset_index(drop=True)
        if frame.empty:
            raise jobs.PermanentJobError(f"no customer is covered by the churn definition on {as_of.isoformat()}")
        prob, explanation = score_frame(bundle, frame)
        if ctx is not None:
            ctx.progress(0.8, f"{len(frame):,} customers scored", force=True)
        tiers, deciles, cut = assign_tiers(prob, risk_policy)
        reasons = explanation["top_reasons"] if explanation["status"] == "available" else [None] * len(frame)
        now = utcnow()
        records = [
            {"tenant_id": tenant_id, "batch_id": batch_id, "customer_id": int(cid), "model_version_id": version.id,
             "contract_id": contract.id, "as_of_date": as_of, "horizon_days": horizon, "probability": float(p),
             "threshold": threshold, "predicted_label": None if threshold is None else int(p >= threshold), "risk_tier": tier,
             "risk_decile": int(dec), "top_reasons": json_safe(why), "created_at": now}
            for cid, p, tier, dec, why in zip(frame["customer_id"], prob, tiers, deciles, reasons, strict=True)
        ]  # fmt: skip
        summary = {
            "customers_scored": len(records), "mean_probability": float(prob.mean()), "max_probability": float(prob.max()),
            "tiers": {t: tiers.count(t) for t in TIERS}, "flagged_at_threshold": None if threshold is None else int((prob >= threshold).sum()),
            "risk_policy": risk_source, "feature_source": feature_source, "horizon_days": horizon,
            "population": {"rule": "customers covered by the churn definition the model was trained under",
                           "churn_definition_policy_id": definition.id, "churn_definition_version": definition.version,
                           "not_scored": dict(sorted(not_scored.items()))},
            "explanations": {"status": explanation["status"], "method": explanation.get("method"), "reason": explanation.get("reason"),
                             "max_additivity_error": float(explanation["additivity_error"].max()) if explanation["status"] == "available" else None},
            "model": {"name": version.name, "version": version.version, "algorithm": run.algorithm},
        }  # fmt: skip
        with session_scope() as ws:
            # A customer scored individually ("score now") before this batch already owns the one row
            # allowed per model, customer and date.  The batch adopts that row instead of skipping it,
            # so the batch (ranking, export, recommendations) always contains every scored customer.
            existing = {cid: (pid, bid) for cid, pid, bid in ws.execute(select(Prediction.customer_id, Prediction.id, Prediction.batch_id).where(
                Prediction.tenant_id == tenant_id, Prediction.model_version_id == version.id, Prediction.as_of_date == as_of))}  # fmt: skip
            fresh = [r for r in records if r["customer_id"] not in existing]
            for start in range(0, len(fresh), 2000):
                ws.execute(insert(Prediction.__table__), fresh[start : start + 2000])
            adopted = [(existing[r["customer_id"]], r) for r in records if r["customer_id"] in existing]
            for (prediction_id, _previous_batch), r in adopted:
                ws.execute(update(Prediction).where(Prediction.id == prediction_id).values(
                    batch_id=batch_id, probability=r["probability"], threshold=r["threshold"], predicted_label=r["predicted_label"],
                    risk_tier=r["risk_tier"], risk_decile=r["risk_decile"], top_reasons=r["top_reasons"], contract_id=r["contract_id"]))  # fmt: skip
            if adopted:
                # cached waterfalls belong to the previous values; they are rebuilt on demand
                ws.execute(delete(Explanation).where(Explanation.scope == "local",
                                                     Explanation.prediction_id.in_([pid for (pid, _b), _r in adopted])))  # fmt: skip
                for single in ws.execute(select(PredictionBatch).where(
                        PredictionBatch.id.in_({b for (_p, b), _r in adopted if b != batch_id}))).scalars():  # fmt: skip
                    single.summary = {**(single.summary or {}), "adopted_by_batch_id": batch_id}
            summary["adopted_single_predictions"] = sum(1 for (_p, b), _r in adopted if b != batch_id)
            ws.execute(update(PredictionBatch).where(PredictionBatch.id == batch_id).values(
                status="completed", total=len(records), succeeded=len(records), failed=0, decile_cutpoints=cut,
                summary=json_safe(summary), finished_at=now))  # fmt: skip
            audit.record(ws, tenant_id=tenant_id, action="predict.batch_completed", entity_type="prediction_batch", entity_id=batch_id,
                         detail={"customers": len(records), "tiers": summary["tiers"], "model_version_id": version.id})  # fmt: skip
        return {"batch_id": batch_id, **{k: summary[k] for k in ("customers_scored", "tiers", "mean_probability")}}
    except Exception as exc:
        if not isinstance(exc, jobs.JobCancelled | jobs.JobInterrupted):
            with session_scope() as ws:
                ws.execute(update(PredictionBatch).where(PredictionBatch.id == batch_id).values(
                    status="failed", finished_at=utcnow(), summary={"error": str(exc)[:1000]}))  # fmt: skip
        raise


def run_scheduled(tenant_id: int, created_by: int | None, ctx: Any = None) -> dict:
    """Scheduled scoring: score the current production model for the newest as-of date."""
    with session_scope() as s:
        batch, job = start_batch(s, None, tenant_id=tenant_id, kind="scheduled", created_by=created_by)
        batch_id, already = batch.id, job is None
    if already:
        return {"batch_id": batch_id, "status": "already_scored"}
    return {"batch_id": batch_id, "status": "queued"}


def latest_batch(session: Session, tenant_id: int, model_version_id: int | None = None) -> PredictionBatch | None:
    stmt = select(PredictionBatch).where(PredictionBatch.tenant_id == tenant_id, PredictionBatch.status == "completed",
                                         PredictionBatch.kind != "single")  # fmt: skip
    if model_version_id:
        stmt = stmt.where(PredictionBatch.model_version_id == model_version_id)
    return session.execute(stmt.order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc())).scalars().first()


def predict_single(session: Session, principal: Principal, customer_id: int, model_version_id: int | None = None) -> dict:
    """Score one customer now (features computed point-in-time for the newest as-of date) and persist it."""
    customer = get_owned(session, Customer, principal.tenant_id, customer_id, label="Customer")
    version, run, contract = _servable(session, principal.tenant_id, model_version_id)
    as_of = default_as_of(session, principal.tenant_id)
    existing = session.execute(select(Prediction).where(
        Prediction.tenant_id == principal.tenant_id, Prediction.model_version_id == version.id,
        Prediction.customer_id == customer.id, Prediction.as_of_date == as_of)).scalar_one_or_none()  # fmt: skip
    if existing is not None:
        return {**prediction_view(existing, customer), "source": "existing prediction for this model and date"}
    bundle = training.load_bundle(run)
    frame = features.offline_frame(session, principal.tenant_id, contract, dates=[as_of], customer_ids=[customer.id])
    source = "offline feature store"
    if frame.empty:
        from . import attributes, sentiment

        # computed on request: this customer's signals are brought in step first, inside this transaction
        sentiment.score_customer(session, principal.tenant_id, customer.id)
        attributes.ensure_initial(session, principal.tenant_id)
        frames = timeline.load_frames(session, principal.tenant_id, customer_ids=[customer.id])
        from . import feature_engine

        frame = feature_engine.compute_features(frames, [as_of], grace_days=features.grace_days_for(session, principal.tenant_id))
        source = "computed on request"
    if frame.empty:
        raise Conflict("this customer has no active subscription, so there is nothing to predict", code="customer_not_active")
    label_frames = timeline.load_frames(session, principal.tenant_id, customer_ids=[customer.id], tables=labels.LABEL_TABLES)
    covered, left_out = labels.covered_population(label_frames, policies.parse(model_definition(session, run)), as_of)
    if customer.id not in covered:
        reason = left_out.get(customer.id, "not_covered")
        raise Conflict(f"no prediction is made for this customer: {labels.NOT_COVERED.get(reason, reason)}", code="customer_not_in_scope",
                       details={"reason": reason})  # fmt: skip
    frame = frame.reset_index(drop=True)
    prob, explanation = score_frame(bundle, frame)
    reference = latest_batch(session, principal.tenant_id, version.id)
    tier, decile = place(float(prob[0]), reference.decile_cutpoints) if reference and reference.decile_cutpoints else (None, None)
    key = f"single:{version.id}:{customer.id}:{as_of.isoformat()}"
    batch = PredictionBatch(tenant_id=principal.tenant_id, model_version_id=version.id, as_of_date=as_of, kind="single",
                            status="completed", total=1, succeeded=1, idempotency_key=key, created_by=principal.user_id,
                            finished_at=utcnow(), summary={"feature_source": source,
                                                           "tier_reference_batch_id": reference.id if reference else None})  # fmt: skip
    session.add(batch)
    session.flush()
    prediction = Prediction(
        tenant_id=principal.tenant_id, batch_id=batch.id, customer_id=customer.id, model_version_id=version.id,
        contract_id=contract.id, as_of_date=as_of, horizon_days=int(bundle.get("horizon_days", 30)), probability=float(prob[0]),
        threshold=version.threshold, predicted_label=None if version.threshold is None else int(prob[0] >= version.threshold),
        risk_tier=tier, risk_decile=decile,
        top_reasons=json_safe(explanation["top_reasons"][0]) if explanation["status"] == "available" else None)  # fmt: skip
    session.add(prediction)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="predict.single", entity_type="prediction",
                 entity_id=prediction.id, detail={"customer_id": customer.id, "model_version_id": version.id})  # fmt: skip
    return {**prediction_view(prediction, customer), "source": source,
            "tier_note": None if tier else "no completed batch exists yet, so a relative risk tier cannot be assigned"}  # fmt: skip


def local_explanation(session: Session, principal: Principal, prediction_id: int) -> dict:
    """Full SHAP waterfall for one stored prediction (recomputed point-in-time, then cached)."""
    prediction = get_owned(session, Prediction, principal.tenant_id, prediction_id, label="Prediction")
    cached = session.execute(select(Explanation).where(Explanation.prediction_id == prediction.id, Explanation.scope == "local")
                             .order_by(Explanation.id.desc())).scalars().first()  # fmt: skip
    if cached is not None:
        return to_dict(cached, include={"probability": prediction.probability})
    version = session.get(ModelVersion, prediction.model_version_id)
    run = session.get(ModelRun, version.model_run_id)
    contract = session.get(FeatureContract, prediction.contract_id)
    bundle = training.load_bundle(run)
    frame = features.offline_frame(session, principal.tenant_id, contract, dates=[prediction.as_of_date], customer_ids=[prediction.customer_id])
    if frame.empty:
        from . import feature_engine

        frames = timeline.load_frames(session, principal.tenant_id, customer_ids=[prediction.customer_id])
        frame = feature_engine.compute_features(frames, [prediction.as_of_date], grace_days=features.grace_days_for(session, principal.tenant_id))
    common = {"tenant_id": principal.tenant_id, "scope": "local", "model_run_id": run.id, "model_version_id": version.id,
              "prediction_id": prediction.id, "customer_id": prediction.customer_id, "as_of_date": prediction.as_of_date,
              "contract_version": f"{contract.name} v{contract.version}"}  # fmt: skip
    if frame.empty:
        record = Explanation(**common, status="unavailable", reason="the customer's features for this date can no longer be reconstructed")
    else:
        result = explain.explain_one(bundle, frame.reset_index(drop=True))
        if result["status"] != "available":
            record = Explanation(**common, status="unavailable", reason=result["reason"])
        else:
            drift = abs(result["waterfall"]["final_probability"] - prediction.probability)
            record = Explanation(**common, status="available", method=result["method"], space=result["space"],
                                 base_value=result["base_value"], output_value=result["output_value"],
                                 additivity_error=result["additivity_error"],
                                 contributions=json_safe({"values": result["contributions"], "waterfall": result["waterfall"],
                                                          "reproduces_stored_probability": bool(drift < 1e-6),
                                                          "probability_difference": drift}))  # fmt: skip
    session.add(record)
    session.flush()
    return to_dict(record, include={"probability": prediction.probability})


def prediction_view(prediction: Prediction, customer: Customer | None = None) -> dict:
    view = to_dict(prediction)
    if customer is not None:
        view["customer_external_id"], view["customer_name"] = customer.external_id, customer.name
    return view


EXPORT_COLUMNS = ["user_id", "customer_name", "as_of_date", "churn_probability", "risk_tier", "risk_decile", "top_reason_1",
                  "top_reason_2", "top_reason_3", "model_version_id"]  # fmt: skip


def export_csv(session: Session, tenant_id: int, batch_id: int) -> str:
    """The batch output file: user id, probability, risk tier and top three reasons."""
    batch = get_owned(session, PredictionBatch, tenant_id, batch_id, label="Prediction batch")
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(EXPORT_COLUMNS)
    stmt = (select(Prediction, Customer.external_id, Customer.name).join(Customer, Customer.id == Prediction.customer_id)
            .where(Prediction.batch_id == batch.id).order_by(Prediction.probability.desc(), Prediction.id))  # fmt: skip
    for prediction, external_id, name in session.execute(stmt):
        reasons = [r["text"] for r in (prediction.top_reasons or [])][:3]
        reasons += [""] * (3 - len(reasons))
        # leading apostrophe neutralises spreadsheet formula injection from free-text source fields
        safe_name = f"'{name}" if name and name[0] in "=+-@\t\r" else (name or "")
        writer.writerow([external_id, safe_name, prediction.as_of_date.isoformat(), f"{prediction.probability:.6f}",
                         prediction.risk_tier or "", prediction.risk_decile or "", *reasons, prediction.model_version_id])  # fmt: skip
    return buffer.getvalue()


def export(session: Session, principal: Principal, batch_id: int) -> str:
    """Hand the batch output file to a user.  Customer-level data leaves the platform here, so it is audited."""
    text = export_csv(session, principal.tenant_id, batch_id)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="predictions.exported", entity_type="prediction_batch",
                 entity_id=batch_id, detail={"rows": max(0, text.count("\n") - 1), "format": "csv", "columns": EXPORT_COLUMNS})  # fmt: skip
    return text


def distribution(session: Session, tenant_id: int, batch_id: int) -> dict:
    batch = get_owned(session, PredictionBatch, tenant_id, batch_id, label="Prediction batch")
    probs = np.array(session.execute(select(Prediction.probability).where(Prediction.batch_id == batch.id)).scalars().all())
    hist, edges = np.histogram(probs, bins=20, range=(0.0, 1.0)) if len(probs) else (np.zeros(20, dtype=int), np.linspace(0, 1, 21))
    tiers = dict(session.execute(select(Prediction.risk_tier, func.count()).where(Prediction.batch_id == batch.id)
                                 .group_by(Prediction.risk_tier)).all())  # fmt: skip
    return {"batch": to_dict(batch), "histogram": {"edges": edges.tolist(), "counts": hist.tolist()}, "tiers": tiers}
