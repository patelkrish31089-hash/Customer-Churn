"""The canonical prediction record every destination writes (1.3.0).

Before 1.3.0 each destination described a prediction in its own words: the CRM payload carried ``probability`` and
``top_reasons``, the file export carried whatever columns the sync's field mapping named, and the PostgreSQL
destination carried something else again.  Three descriptions of one fact drift, and the one that matters — "what did
we tell this customer's owners, and from which model?" — cannot be answered from any of them afterwards.

So one record, defined once, eighteen fields, with a version:

============================  =========  ==============================================================
field                          type       meaning
============================  =========  ==============================================================
customer_id                    integer    the platform's customer id
account_id                     string?    the account the customer belongs to, when the source has one
external_customer_id           string     the id the customer has in the customer's own system
crm_contact_id                 string?    the record in the CRM, once one is known
churn_probability              number     0..1, the model's probability of churn in the horizon
risk_tier                      string     high | medium | low
risk_decile                    integer    1..10, 1 being the riskiest tenth
prediction_horizon_days        integer    the horizon the probability refers to
prediction_timestamp           timestamp  when the score was produced (UTC)
data_cutoff_timestamp          timestamp  the last day of data the features were built from (UTC)
model_name                     string     registry name
model_version                  string     registry version
feature_version                string     the feature contract the model was trained and scored with
model_checksum                 string     SHA-256 of the model artefact
top_reason_1                   string?    the strongest reason, in the words the customer would read
top_reason_2                   string?
top_reason_3                   string?
recommended_intervention       string?    the action the retention service recommends
approval_status                string     the model version's approval status — must be ``approved``
============================  =========  ==============================================================

Rules that are enforced here rather than trusted downstream:

* **No record leaves the platform for a model version that is not approved.** ``approval_status`` is part of the
  record and a non-approved value is a validation failure, so a destination cannot export a pending model by accident.
* **A timestamp is a UTC instant with an offset.** A naive datetime is refused, because a destination in another zone
  will read it as something else.
* **Null is not zero.** An absent reason is ``None``; a probability is never defaulted, never coerced from a string,
  and never rounded beyond six places silently — ``normalise`` does the rounding and says so.
* **The tenant is part of the identity, not a label.** Two tenants may legitimately have a customer ``C000123`` with the
  same model version and the same data cutoff. Without ``tenant_id`` in the record and in every key derived from it, one
  tenant's row would overwrite the other's in a warehouse whose primary key is the customer-day, and a deduplication
  inside one export run would silently drop a direct competitor's row. It is the first field for that reason.
* **The batch has one checksum.** ``checksum`` over the canonical JSON lines is what a destination reconciles against.

This module has no database dependency: it takes plain mappings, so it can be tested without a session and reused by
the Snowflake, Zendesk, Marketo, file and PostgreSQL writers alike.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any

from ..errors import ValidationFailed

SCHEMA_VERSION = "1.1.0"  # 1.1.0 adds tenant_id: an identity change, so a major-looking bump is deliberate
RISK_TIERS = ("high", "medium", "low")
APPROVAL_STATUSES = ("pending", "approved", "rejected")
# only a record whose model is approved may be exported
EXPORTABLE_APPROVAL = ("approved",)
PROBABILITY_DECIMALS = 6


@dataclass(frozen=True)
class Field:
    name: str
    kind: str  # integer | number | string | timestamp | date
    nullable: bool
    note: str


FIELDS: tuple[Field, ...] = (
    Field("tenant_id", "integer", False, "the tenant that owns the customer; part of every identity key"),
    Field("customer_id", "integer", False, "the platform's customer id"),
    Field("account_id", "string", True, "the account the customer belongs to"),
    Field("external_customer_id", "string", False, "the customer id in the customer's own system"),
    Field("crm_contact_id", "string", True, "the record in the CRM, once known"),
    Field("churn_probability", "number", False, "probability of churn in the horizon, 0..1"),
    Field("risk_tier", "string", False, "high | medium | low"),
    Field("risk_decile", "integer", False, "1..10, 1 being the riskiest tenth"),
    Field("prediction_horizon_days", "integer", False, "the horizon the probability refers to"),
    Field("prediction_timestamp", "timestamp", False, "when the score was produced, UTC"),
    Field("data_cutoff_timestamp", "timestamp", False, "the last day of data behind the features, UTC"),
    Field("model_name", "string", False, "registry name"),
    Field("model_version", "string", False, "registry version"),
    Field("feature_version", "string", False, "the feature contract the model was trained and scored with"),
    Field("model_checksum", "string", False, "SHA-256 of the model artefact"),
    Field("top_reason_1", "string", True, "the strongest reason, in words the customer would read"),
    Field("top_reason_2", "string", True, "the second reason"),
    Field("top_reason_3", "string", True, "the third reason"),
    Field("recommended_intervention", "string", True, "the action the retention service recommends"),
    Field("approval_status", "string", False, "the model version's approval status; must be approved"),
)
FIELD_NAMES: tuple[str, ...] = tuple(field.name for field in FIELDS)
REQUIRED_FIELDS = tuple(field.name for field in FIELDS if not field.nullable)
OPTIONAL_FIELDS = tuple(field.name for field in FIELDS if field.nullable)


def describe() -> dict[str, Any]:
    """The schema as data: what a destination is handed, and what it may rely on."""
    return {
        "schema_version": SCHEMA_VERSION,
        "fields": [{"name": field.name, "type": field.kind, "nullable": field.nullable, "note": field.note} for field in FIELDS],
        "required": list(REQUIRED_FIELDS),
        "optional": list(OPTIONAL_FIELDS),
        "enumerations": {"risk_tier": list(RISK_TIERS), "approval_status": list(APPROVAL_STATUSES)},
        "exportable_approval": list(EXPORTABLE_APPROVAL),
        "checksum": "sha256 over the canonical JSON lines of the records, in the order given",
    }


def explain() -> str:
    """The field-mapping document a reverse-ETL tool or a destination owner needs, as text."""
    lines = [f"canonical prediction record, schema {SCHEMA_VERSION}", ""]
    for field in FIELDS:
        lines.append(f"{field.name:<26} {field.kind:<10} {'nullable' if field.nullable else 'required':<9} {field.note}")
    lines += ["", "A destination must not export a record whose approval_status is not 'approved'."]
    return "\n".join(lines)


def _timestamp_problem(name: str, value: Any) -> str | None:
    if not isinstance(value, datetime):
        return f"{name} must be a datetime, not {type(value).__name__}"
    if value.tzinfo is None or value.utcoffset() is None:
        return f"{name} must carry a UTC offset; a naive datetime means a different instant to every reader"
    return None


def validate(record: Mapping[str, Any]) -> list[str]:
    """Every reason this record may not be exported; empty when it may."""
    problems: list[str] = []
    for name in FIELD_NAMES:
        if name not in record:
            problems.append(f"{name} is missing")
    for name in record:
        if name.startswith("_"):
            continue  # an internal column of the caller's own, never exported
        if name not in FIELD_NAMES:
            problems.append(f"{name} is not part of schema {SCHEMA_VERSION}")
    kinds = {field.name: field.kind for field in FIELDS}
    nullable = {field.name: field.nullable for field in FIELDS}
    for name, kind in kinds.items():
        if name not in record:
            continue
        value = record[name]
        if value is None:
            if not nullable[name]:
                problems.append(f"{name} is required and was null")
            continue
        if kind == "integer":
            if isinstance(value, bool) or not isinstance(value, int):
                problems.append(f"{name} must be an integer, not {type(value).__name__}")
        elif kind == "number":
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                problems.append(f"{name} must be a number, not {type(value).__name__}")
        elif kind == "string":
            if not isinstance(value, str):
                problems.append(f"{name} must be a string, not {type(value).__name__}")
            elif not value.strip():
                problems.append(f"{name} must not be blank")
        elif kind == "timestamp":
            problem = _timestamp_problem(name, value)
            if problem:
                problems.append(problem)
    probability = record.get("churn_probability")
    if isinstance(probability, (int, float)) and not isinstance(probability, bool) and not 0.0 <= float(probability) <= 1.0:
        problems.append(f"churn_probability must be between 0 and 1, not {probability!r}")
    decile = record.get("risk_decile")
    if isinstance(decile, int) and not isinstance(decile, bool) and not 1 <= decile <= 10:
        problems.append(f"risk_decile must be between 1 and 10, not {decile}")
    horizon = record.get("prediction_horizon_days")
    if isinstance(horizon, int) and not isinstance(horizon, bool) and horizon <= 0:
        problems.append(f"prediction_horizon_days must be positive, not {horizon}")
    tier = record.get("risk_tier")
    if isinstance(tier, str) and tier not in RISK_TIERS:
        problems.append(f"risk_tier must be one of {', '.join(RISK_TIERS)}, not {tier!r}")
    approval = record.get("approval_status")
    if isinstance(approval, str):
        if approval not in APPROVAL_STATUSES:
            problems.append(f"approval_status must be one of {', '.join(APPROVAL_STATUSES)}, not {approval!r}")
        elif approval not in EXPORTABLE_APPROVAL:
            problems.append(f"a prediction from a model that is {approval} may not be exported")
    checksum = record.get("model_checksum")
    if isinstance(checksum, str) and not (len(checksum) == 64 and all(character in "0123456789abcdef" for character in checksum.lower())):
        problems.append("model_checksum must be the 64 hexadecimal characters of a SHA-256")
    return problems


def ensure_valid(record: Mapping[str, Any]) -> dict[str, Any]:
    """``record`` normalised, or a validation failure that names every problem at once."""
    normalised = normalise(record)
    problems = validate(normalised)
    if problems:
        raise ValidationFailed(f"the prediction record is not valid for export: {problems[0]}",
                               details={"problems": problems, "schema_version": SCHEMA_VERSION})  # fmt: skip
    return normalised


def normalise(record: Mapping[str, Any]) -> dict[str, Any]:
    """Copy the schema's own columns only, rounding the probability to six places and timestamps to UTC.

    Rounding here, in one place, is the reason a destination and the database can be reconciled byte for byte: the
    export says 0.812345 because this function said so, not because two float-to-string conversions agreed.
    """
    out: dict[str, Any] = {}
    for field in FIELDS:
        if field.name not in record:
            continue
        value = record[field.name]
        if field.kind == "number" and isinstance(value, (int, float)) and not isinstance(value, bool):
            out[field.name] = round(float(value), PROBABILITY_DECIMALS)
        elif field.kind == "timestamp" and isinstance(value, datetime) and value.tzinfo is not None:
            out[field.name] = value.astimezone(UTC)
        elif field.kind == "date" and isinstance(value, date) and not isinstance(value, datetime):
            out[field.name] = value.isoformat()
        elif field.kind == "integer" and isinstance(value, str) and value.isdigit():
            out[field.name] = int(value)
        else:
            out[field.name] = value
    return out


def as_row(record: Mapping[str, Any]) -> dict[str, Any]:
    """The record as the JSON-safe row a file or a warehouse gets: timestamps as ISO-8601 with an offset."""
    row = normalise(record)
    for field in FIELDS:
        value = row.get(field.name)
        if field.kind == "timestamp" and isinstance(value, datetime):
            row[field.name] = value.isoformat()
    return row


def canonical_lines(records: Iterable[Mapping[str, Any]]) -> list[str]:
    """One JSON line per record, keys in schema order: the bytes a checksum is taken over."""
    return [json.dumps(as_row(record), ensure_ascii=False, separators=(",", ":"), sort_keys=False) for record in records]


def checksum(records: Iterable[Mapping[str, Any]]) -> str:
    """SHA-256 of the canonical lines, so a destination can prove it stored what was sent."""
    digest = hashlib.sha256()
    for line in canonical_lines(records):
        digest.update(line.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def reasons_from(prediction: Any, limit: int = 3) -> list[str | None]:
    """The top reasons of a stored prediction, padded to ``limit`` with ``None`` and never with an empty string."""
    raw = getattr(prediction, "top_reasons", None) or []
    texts: list[str] = []
    for item in raw:
        text = item.get("text") if isinstance(item, dict) else (str(item) if item else "")
        if text and str(text).strip():
            texts.append(str(text).strip())
    padded: list[str | None] = texts[:limit]
    return padded + [None] * (limit - len(padded))


def from_prediction(prediction: Any, customer: Any, model_version: Any, *, feature_version: str, model_checksum: str,
                    recommended_intervention: str | None = None, account_id: str | None = None,
                    crm_contact_id: str | None = None, tenant_id: int | None = None) -> dict[str, Any]:
    """Build a record from the stored rows; raises when the model version is not approved.

    ``feature_version`` and ``model_checksum`` are arguments rather than lookups on purpose: the feature contract and
    the artefact digest live in different tables, and a caller that cannot name them has no business exporting.
    """
    approval = getattr(model_version, "approval_status", None)
    if approval not in EXPORTABLE_APPROVAL:
        raise ValidationFailed(
            f"model version {getattr(model_version, 'name', '?')} v{getattr(model_version, 'version', '?')} is {approval} and may not be exported",
            details={"field": "approval_status", "approval_status": approval},
        )  # fmt: skip
    owner = tenant_id if tenant_id is not None else getattr(prediction, "tenant_id", None) or getattr(customer, "tenant_id", None)
    if owner is None:
        raise ValidationFailed("a prediction cannot be exported without its tenant: the record identity is tenant-scoped",
                               details={"field": "tenant_id"})  # fmt: skip
    reasons = reasons_from(prediction)
    cutoff = prediction.as_of_date
    if isinstance(cutoff, date) and not isinstance(cutoff, datetime):
        cutoff = datetime(cutoff.year, cutoff.month, cutoff.day, tzinfo=UTC)
    scored_at = prediction.created_at
    if isinstance(scored_at, datetime) and scored_at.tzinfo is None:
        scored_at = scored_at.replace(tzinfo=UTC)
    return ensure_valid({
        "tenant_id": owner,
        "customer_id": customer.id,
        "account_id": account_id,
        "external_customer_id": customer.external_id,
        "crm_contact_id": crm_contact_id,
        "churn_probability": prediction.probability,
        "risk_tier": prediction.risk_tier,
        "risk_decile": prediction.risk_decile,
        "prediction_horizon_days": prediction.horizon_days,
        "prediction_timestamp": scored_at,
        "data_cutoff_timestamp": cutoff,
        "model_name": model_version.name,
        "model_version": str(model_version.version),
        "feature_version": feature_version,
        "model_checksum": model_checksum,
        "top_reason_1": reasons[0],
        "top_reason_2": reasons[1],
        "top_reason_3": reasons[2],
        "recommended_intervention": recommended_intervention,
        "approval_status": approval,
    })


__all__ = [
    "APPROVAL_STATUSES",
    "FIELDS",
    "FIELD_NAMES",
    "OPTIONAL_FIELDS",
    "REQUIRED_FIELDS",
    "RISK_TIERS",
    "SCHEMA_VERSION",
    "as_row",
    "canonical_lines",
    "checksum",
    "describe",
    "ensure_valid",
    "explain",
    "from_prediction",
    "normalise",
    "reasons_from",
    "validate",
]  # fmt: skip
