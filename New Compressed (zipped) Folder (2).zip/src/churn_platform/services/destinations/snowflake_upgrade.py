"""Upgrading a 1.2.0 warehouse table to the 1.3.0 identity (the plan, not the execution).

1.2.0 wrote ``CHURN_PREDICTIONS`` with a primary key of ``(EXTERNAL_CUSTOMER_ID, MODEL_NAME, MODEL_VERSION,
DATA_CUTOFF_TIMESTAMP)`` and no tenant, because the platform did not put a tenant in the record.  Two tenants holding
the same customer id therefore collided at the warehouse: the second tenant's MERGE updated the first tenant's row in
place.  The adapter fixes the statements; the *table already in a customer's warehouse* still has the old shape, and a
1.3.0 MERGE against it would fail on a column that does not exist.

This module produces the plan that closes that gap: the statements, in order, each with what it does, whether it is
destructive, and the guard that stops it running twice.  It deliberately does not run anything.  There is no warehouse
in this repository (GATE 12 is BLOCKED), so the SQL here is reviewed and asserted against, not executed — and a module
that quietly connected somewhere would be a worse lie than the one it replaced.

The plan is conservative on purpose:

* **adding the column is separate from filling it** — ``ADD COLUMN IF NOT EXISTS`` is fast and reversible; the ``UPDATE``
  is a full-table write and is stated as such;
* **the fill takes a tenant id as a bound parameter**, because an upgrade cannot guess which tenant a row belonged to.
  An installation that wrote for two tenants must not run this: the statement refuses to continue while any row is
  still null, rather than picking one;
* **dropping the old key is marked destructive** and needs ``--destructive``.  Changing a primary key on a large table
  is a rebuild, and a person must decide to do it;
* **the verification comes last** and is a query whose answer is a number a person compares, not a green tick.
"""

from __future__ import annotations

from typing import Any

from ...errors import ValidationFailed
from . import snowflake
from .snowflake import quote

#: the columns the 1.3.0 identity needs and 1.2.0 did not write
ADDED_COLUMNS = (("TENANT_ID", "NUMBER(38,0)"),)


def _table(table: str, schema: str | None) -> str:
    """``"SCHEMA"."TABLE"`` when a schema is given, ``"TABLE"`` otherwise — every part validated and quoted."""
    parts = [quote(part) for part in (schema, table) if part]
    if not parts:
        raise ValidationFailed("an upgrade plan needs a table name", details={"field": "table"})
    return ".".join(parts)


def plan(*, table: str = snowflake.TABLE, schema: str | None = None, runs_table: str = snowflake.RUNS_TABLE,
         tenant_id: int | None = None) -> dict[str, Any]:
    """Every statement the upgrade needs, in the order it must run, with its guard and its risk."""
    target = _table(table, schema)
    if schema:
        _table(runs_table, schema)  # validated here so a bad runs-table name cannot surface half-way through a run
    identity = ", ".join(quote(column) for column in snowflake._IDENTITY_COLUMNS)
    steps: list[dict[str, Any]] = []

    catalogue = f"{quote(schema)}.INFORMATION_SCHEMA.COLUMNS" if schema else "INFORMATION_SCHEMA.COLUMNS"
    steps.append({
        "step": "1. inspect the table",
        "destructive": False,
        "why": "the plan is only valid for a 1.2.0 table; this says whether the column is already there",
        "sql": (f"SELECT {quote('COLUMN_NAME')}, {quote('DATA_TYPE')} FROM {catalogue} "  # noqa: S608 - identifiers are validated and quoted; values are parameters  # nosec B608 - identifiers validated and quoted; values bound as parameters
                f"WHERE {quote('TABLE_SCHEMA')} = %(schema)s AND {quote('TABLE_NAME')} = %(table)s"),
        "parameters": {"schema": (schema or "").upper() or None, "table": table.upper()},
    })
    for name, kind in ADDED_COLUMNS:
        steps.append({
            "step": f"2. add {name}",
            "destructive": False,
            "why": "additive and idempotent: existing rows keep a null until step 3 fills them",
            "sql": f"ALTER TABLE {target} ADD COLUMN IF NOT EXISTS {quote(name)} {kind}",
        })
    steps.append({
        "step": "3. fill the tenant",
        "destructive": False,
        "why": ("a full-table write; the tenant id is a parameter because the table never recorded one. An installation "
                "that exported for two tenants cannot use this step and must re-export instead"),
        "sql": f"UPDATE {target} SET {quote('TENANT_ID')} = %(tenant_id)s WHERE {quote('TENANT_ID')} IS NULL",  # noqa: S608 - identifiers are validated and quoted; values are parameters  # nosec B608 - identifiers validated and quoted; values bound as parameters
        "parameters": {"tenant_id": tenant_id},
        "refuses_when": "tenant_id is None",
    })
    steps.append({
        "step": "4. prove the fill",
        "destructive": False,
        "why": "a key cannot be added over nulls; this is the number that decides whether step 5 may run",
        "sql": f"SELECT COUNT(*) FROM {target} WHERE {quote('TENANT_ID')} IS NULL",  # noqa: S608 - identifiers are validated and quoted; values are parameters  # nosec B608 - identifiers validated and quoted; values bound as parameters
        "must_return": 0,
    })
    steps.append({
        "step": "5. replace the primary key",
        "destructive": True,
        "why": ("the 1.2.0 key is (customer, model, version, cutoff) and lets two tenants collide; the 1.3.0 key leads "
                "with the tenant. Replacing a primary key rebuilds the table, so this needs --destructive"),
        "sql": [
            f"ALTER TABLE {target} DROP PRIMARY KEY",
            f"ALTER TABLE {target} ADD CONSTRAINT {quote(table + '_IDENTITY')} PRIMARY KEY ({identity})",
        ],
    })
    steps.append({
        "step": "6. verify the identity",
        "destructive": False,
        "why": "one row per identity, and no duplicate identity left behind by the old key",
        "sql": (
            f"SELECT COUNT(*) AS {quote('ROWS')}, COUNT(DISTINCT {identity.replace(', ', ' || ')}) AS "  # noqa: S608 - identifiers are validated and quoted; values are parameters  # nosec B608 - identifiers validated and quoted; values bound as parameters
            f"{quote('IDENTITIES')} FROM {target}"
        ),
        "must_match": ["ROWS", "IDENTITIES"],
    })
    if tenant_id is not None and (not isinstance(tenant_id, int) or tenant_id <= 0):
        raise ValidationFailed("tenant_id must be a positive integer", details={"field": "tenant_id"})
    return {
        "table": target,
        "runs_table": _table(runs_table, schema),
        "identity": list(snowflake._IDENTITY_COLUMNS),
        "steps": steps,
        "note": (
            "This plan is not executed by the platform: there is no warehouse in this environment and GATE 12 is "
            "BLOCKED. It is produced so the upgrade is reviewable, and so an installation with a warehouse runs "
            "statements that were read before they ran."
        ),
    }


def statements(plan_document: dict[str, Any], *, destructive: bool = False, tenant_id: int | None = None) -> list[dict[str, Any]]:
    """The steps as runnable statements, refusing a destructive one without ``destructive`` and a fill without a tenant."""
    out: list[dict[str, Any]] = []
    for step in plan_document["steps"]:
        if step["destructive"] and not destructive:
            continue
        if step.get("refuses_when") and (tenant_id is None):
            continue
        sql = step["sql"] if isinstance(step["sql"], list) else [step["sql"]]
        parameters = dict(step.get("parameters") or {})
        if "tenant_id" in parameters:
            parameters["tenant_id"] = tenant_id
        for statement in sql:
            out.append({"step": step["step"], "sql": statement, "parameters": parameters,
                        "destructive": bool(step["destructive"])})  # fmt: skip
    return out


__all__ = ["ADDED_COLUMNS", "plan", "statements"]
