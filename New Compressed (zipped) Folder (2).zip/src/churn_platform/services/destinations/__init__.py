"""Where predictions go: a warehouse, a support desk, a marketing platform (1.3.0).

Each destination implements :class:`churn_platform.services.destinations.base.Destination` — a connection test, a
schema, an upsert and a count — and inherits everything else from ``base.deliver``: validation against the canonical
prediction record, deduplication, batched writes, retries, quarantine and reconciliation.
"""

from .base import DeliveryResult, Destination, Quarantined, RetryPolicy, deliver, filter_after, reconcile
from .postgres import PostgresConfig, PostgresDestination
from .snowflake import SnowflakeConfig, SnowflakeDestination

__all__ = [
    "DeliveryResult",
    "Destination",
    "PostgresConfig",
    "PostgresDestination",
    "Quarantined",
    "RetryPolicy",
    "SnowflakeConfig",
    "SnowflakeDestination",
    "deliver",
    "filter_after",
    "reconcile",
]
