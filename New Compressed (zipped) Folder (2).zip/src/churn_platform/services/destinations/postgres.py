"""The PostgreSQL destination (1.3.0): a real destination that needs no vendor account.

The Snowflake adapter is the one the brief asks for, and it cannot be proved here: there is no account, so GATE 12 is
BLOCKED and every statement it emits has been seen by a stand-in and by nothing else.  That left the delivery layer in
an awkward position — implemented, wired, and never once connected to a system that was not written for it.

PostgreSQL is not Snowflake.  It is, however, a real database, running as a separate process, with its own SQL engine,
its own constraints and its own transaction semantics, and it is the database this platform already requires.  A
destination for it means the delivery layer can be exercised against something that does not share its assumptions:
the identity constraint is enforced by the server, the upsert is executed rather than recorded, and the row that comes
back out is read with a different connection that never heard of this module.

What this destination does **not** do, stated plainly:

* it is not a warehouse.  There is no clustering, no micro-partition pruning, no time travel, and none of Snowflake's
  MERGE semantics — the upsert is ``INSERT … ON CONFLICT``, which PostgreSQL 9.5 and later implement and which is a
  different statement from the one GATE 12 has to accept;
* it does not make GATE 12 any less BLOCKED.  A row in PostgreSQL proves the pipeline, the record and the outbox; it
  proves nothing about a Snowflake account, and the register says so in R-08 and R-60;
* it writes one statement per record, the same shape the Snowflake adapter uses, so it inherits the same cost: a batch
  that fails is retried record by record (measured in ``docs/1_3_0_PERFORMANCE_REPORT.md``).

The driver is injected for the same reason it is injected in ``snowflake.py``: this module never imports ``psycopg``,
so it can be exercised with any DB-API connection, and the installation supplies ``psycopg.connect`` at the seam.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ...errors import ValidationFailed
from .. import export_record

TABLE = "churn_predictions"
RUNS_TABLE = "churn_export_runs"
#: what a schema, table or column name may be before it is quoted
IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]{0,62}$")
#: the record's field kinds as PostgreSQL types.  Text is unbounded: a reason is prose and its length is not a fact
#: about the record that a destination should be allowed to reject.
TYPES = {"integer": "BIGINT", "number": "DOUBLE PRECISION", "string": "TEXT", "timestamp": "TIMESTAMPTZ", "date": "DATE"}
#: the columns that make one row unique.  The tenant leads, for the reason R-60 gives: two tenants may hold the same
#: customer id, and a warehouse that deduplicates on the customer alone loses one of them.
IDENTITY_COLUMNS = ("tenant_id", "external_customer_id", "model_name", "model_version", "data_cutoff_timestamp")


def quote(name: str) -> str:
    """Validate a configured name and return it quoted, or refuse it with the rule it broke.

    The same decision as :func:`churn_platform.services.destinations.snowflake.quote`, for the same reason: a schema or
    table name is configuration, configuration is input, and input does not get to become SQL.  Values never come
    through here — they are bound as parameters.
    """
    text = str(name or "")
    if not IDENTIFIER.fullmatch(text):
        raise ValidationFailed(
            f"{text!r} is not a usable PostgreSQL identifier",
            details={"identifier": text, "rule": "a letter or underscore, then up to 62 letters, digits, '_' or '$'"},
        )
    return f'"{text}"'


def _qualified(config: PostgresConfig, table: str) -> str:  # the dataclass is declared below, as in snowflake.py
    return f"{quote(config.schema)}.{quote(table)}"


def ddl(config: PostgresConfig) -> str:
    """The destination table: one row per identity, with the identity enforced by the server, not by this module."""
    columns = []
    for definition in export_record.FIELDS:
        column = f"{quote(definition.name)} {TYPES[definition.kind]}"
        if not definition.nullable:
            column += " NOT NULL"
        columns.append(column)
    columns += [
        f'{quote("sync_run_id")} TEXT NOT NULL',
        f'{quote("exported_at")} TIMESTAMPTZ NOT NULL',
        f"CONSTRAINT {quote(config.table + '_identity')} PRIMARY KEY ("
        + ", ".join(quote(column) for column in IDENTITY_COLUMNS)
        + ")",
    ]
    return f"CREATE TABLE IF NOT EXISTS {_qualified(config, config.table)} (\n  " + ",\n  ".join(columns) + "\n)"


def runs_ddl(config: PostgresConfig) -> str:
    """One row per export run, so a reconciliation can be made by anyone who can read the database."""
    columns = [
        ("run_id", "TEXT PRIMARY KEY"), ("tenant_id", "BIGINT NOT NULL"), ("destination", "TEXT NOT NULL"),
        ("rows_expected", "BIGINT NOT NULL"), ("rows_written", "BIGINT NOT NULL"), ("checksum", "TEXT NOT NULL"),
        ("watermark", "TIMESTAMPTZ"), ("actor", "TEXT"), ("started_at", "TIMESTAMPTZ NOT NULL"),
        ("finished_at", "TIMESTAMPTZ"),
    ]  # fmt: skip
    body = ",\n".join(f"  {quote(name)} {kind}" for name, kind in columns)
    return f"CREATE TABLE IF NOT EXISTS {_qualified(config, config.runs_table)} (\n{body}\n)"


def upsert_statement(config: PostgresConfig) -> str:
    """Upsert one record: on a matching identity every column is refreshed, otherwise the row is inserted.

    ``ON CONFLICT`` is what the identity constraint above is for.  The alternative — delete then insert, or select then
    decide — reintroduces exactly the two-rows-for-one-customer failure that defect 3 was about.
    """
    names = [quote(definition.name) for definition in export_record.FIELDS] + [quote("sync_run_id"), quote("exported_at")]
    placeholders = ", ".join(f"%({_parameter(index)})s" for index in range(len(names)))
    identity = [quote(column) for column in IDENTITY_COLUMNS]
    updates = ", ".join(f"{name} = EXCLUDED.{name}" for name in names if name not in identity)
    return (
        f"INSERT INTO {_qualified(config, config.table)} ({', '.join(names)}) VALUES ({placeholders}) "  # noqa: S608 - the identifiers are validated and quoted; the values are bound parameters  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
        f"ON CONFLICT ({', '.join(identity)}) DO UPDATE SET {updates}"  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
    )


def _parameter(index: int) -> str:
    return f"v{index}"


@dataclass(frozen=True)
class PostgresConfig:
    """Where to write, and what to call the two tables.  The password, if any, stays in the URL the caller supplies."""

    url: str
    schema: str = "public"
    table: str = TABLE
    runs_table: str = RUNS_TABLE
    connect_timeout_seconds: int = 10

    def safe(self) -> dict[str, Any]:
        """The configuration as it may be logged: the URL with its password removed, never the URL itself."""
        return {"url": _redact(self.url), "schema": self.schema, "table": self.table, "runs_table": self.runs_table}

    def problems(self) -> list[str]:
        problems = [] if str(self.url or "").strip() else ["a connection URL is required"]
        for attribute in ("schema", "table", "runs_table"):
            try:
                quote(getattr(self, attribute))
            except ValidationFailed:
                problems.append(f"{attribute} {getattr(self, attribute)!r} is not a usable PostgreSQL identifier")
        return problems


def _redact(url: str) -> str:
    """Put asterisks where the password was, and leave the rest of the connection string readable.

    A log, an audit event or an error's details are all places a connection string ends up, and a connection string
    carries the password.  What is kept is the scheme, the user and the host, which is what a person needs in order to
    recognise the connection; what is dropped is the only part that is a secret.
    """
    text = str(url or "")
    if "@" not in text or "://" not in text:
        return text
    scheme, rest = text.split("://", 1)
    credentials, host = rest.split("@", 1)
    if ":" not in credentials:
        return text
    user = credentials.split(":", 1)[0]
    return f"{scheme}://{user}:***@{host}"


@dataclass
class PostgresDestination:
    """The adapter.  ``connect`` is ``psycopg.connect`` in production and any DB-API connection factory in a test."""

    config: PostgresConfig
    connect: Callable[..., Any]
    name: str = "postgres"
    _connection: Any = field(default=None, repr=False)

    # ------------------------------------------------------------------ plumbing
    def _conn(self):
        """Connect once, and put the session in the destination's schema.

        The schema is created when it is not ``public``: a destination that cannot be written to is not a configured
        destination, and failing at the first write instead of at the first connection makes the refusal arrive late
        and in the wrong place.  ``SET search_path`` is what makes ``test_connection`` able to compare the session with
        the configuration at all — without it a connection that was told to use ``analytics`` still reports ``public``,
        which is the 1.2.0 schema-mismatch defect in a different dialect.
        """
        if self._connection is None:
            connection = self.connect(self.config.url, connect_timeout=self.config.connect_timeout_seconds)
            connection.autocommit = True  # each record is its own acknowledgement; a rollback must not undo the rest
            self._connection = connection
            if self.config.schema != "public":
                self._execute(f"CREATE SCHEMA IF NOT EXISTS {quote(self.config.schema)}")  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
                self._execute(f"SET search_path TO {quote(self.config.schema)}")  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
        return self._connection

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def _execute(self, statement: str, parameters: Any = None) -> Any:
        cursor = self._conn().cursor()
        try:
            if parameters is None:
                cursor.execute(statement)
            else:
                cursor.execute(statement, parameters)
            return cursor.fetchall() if cursor.description else []
        finally:
            cursor.close()

    # ------------------------------------------------------------------ the destination contract
    def test_connection(self) -> dict[str, Any]:
        """Prove the connection, and report the session rather than assuming it."""
        problems = self.config.problems()
        if problems:
            raise ValidationFailed(f"the PostgreSQL configuration is incomplete: {problems[0]}", details={"problems": problems})
        try:
            rows = self._execute("SELECT current_database(), current_schema(), current_user, version()")
        except Exception as exc:
            raise ValidationFailed(
                f"PostgreSQL refused the connection ({type(exc).__name__}): {str(exc)[:200]}",
                details={"kind": "connection", "url": _redact(self.config.url)},
            ) from exc
        database, schema, user, version = (list(rows[0]) + [None] * 4)[:4] if rows else (None, None, None, None)
        if str(schema or "") != self.config.schema:
            raise ValidationFailed(
                f"the session is in schema {schema}, configured {self.config.schema}",
                details={"session": {"database": database, "schema": schema, "user": user}, "configured": self.config.safe()},
            )
        return {"ok": True, "session": {"database": database, "schema": schema, "user": user,
                                        "version": str(version or "").split(" on ")[0][:80]}, "configured": self.config.safe(),
                "health": "the session answered and is the configured one"}  # fmt: skip

    def health(self) -> dict[str, Any]:
        try:
            rows = self._execute(f"SELECT COUNT(*) FROM {_qualified(self.config, self.config.table)}")  # noqa: S608 - identifiers validated and quoted  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:300]}
        return {"ok": True, "table": self.config.table, "rows": int(rows[0][0]) if rows else 0}

    def ensure_schema(self) -> None:
        """Create the two tables.  Idempotent, additive, and it never drops anything."""
        self._execute(ddl(self.config))
        self._execute(runs_ddl(self.config))

    def write(self, records: Sequence[dict[str, Any]], *, run_id: str) -> int:
        """Upsert every record, then say how many rows the table holds for this run."""
        if not records:
            return self.count_stored(run_id=run_id) or 0
        statement = upsert_statement(self.config)
        exported_at = datetime.now().astimezone()
        for record in records:
            parameters: dict[str, Any] = {}
            for index, definition in enumerate(export_record.FIELDS):
                parameters[_parameter(index)] = record.get(definition.name)
            parameters[_parameter(len(export_record.FIELDS))] = run_id
            parameters[_parameter(len(export_record.FIELDS) + 1)] = exported_at
            self._execute(statement, parameters)
        return self.count_stored(run_id=run_id) or 0

    def count_stored(self, *, run_id: str) -> int | None:
        try:
            rows = self._execute(
                f"SELECT COUNT(*) FROM {_qualified(self.config, self.config.table)} WHERE {quote('sync_run_id')} = %(run_id)s",  # noqa: S608 - identifiers validated and quoted  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
                {"run_id": run_id},
            )
        except Exception:
            return None
        return int(rows[0][0]) if rows else 0

    def record_run(self, *, run_id: str, tenant_id: int, expected: int, written: int, checksum: str,
                   watermark: datetime | None, actor: str | None, started_at: datetime) -> None:  # fmt: skip
        """The run's own row: an operator who can read the database can reconcile without this platform."""
        self._execute(
            f"INSERT INTO {_qualified(self.config, self.config.runs_table)} ("  # noqa: S608 - identifiers validated and quoted  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
            + ", ".join(quote(name) for name in ("run_id", "tenant_id", "destination", "rows_expected", "rows_written",
                                                 "checksum", "watermark", "actor", "started_at"))
            + ") VALUES (%(run_id)s, %(tenant_id)s, %(destination)s, %(expected)s, %(written)s, %(checksum)s,"
            " %(watermark)s, %(actor)s, %(started_at)s)"
            " ON CONFLICT (run_id) DO UPDATE SET rows_expected = EXCLUDED.rows_expected,"
            " rows_written = EXCLUDED.rows_written, checksum = EXCLUDED.checksum, watermark = EXCLUDED.watermark",
            {"run_id": run_id, "tenant_id": tenant_id, "destination": self.name, "expected": expected, "written": written,
             "checksum": checksum, "watermark": watermark, "actor": actor, "started_at": started_at},
        )  # fmt: skip


__all__ = [
    "IDENTITY_COLUMNS",
    "RUNS_TABLE",
    "TABLE",
    "PostgresConfig",
    "PostgresDestination",
    "ddl",
    "quote",
    "runs_ddl",
    "upsert_statement",
]


def _unused(_: Mapping[str, Any]) -> None:  # pragma: no cover - keeps the typing import honest
    return None
