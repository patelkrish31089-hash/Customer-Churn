"""Destinations: where a prediction goes once it has been decided (1.3.0).

A destination is a place the platform writes predictions to — a warehouse table, a CRM, a support desk.  Every one of
them shares the same obligations, so they share the same skeleton here and differ only in the statement they issue:

* **nothing leaves for an unapproved model.**  ``deliver`` validates every record with
  :mod:`churn_platform.services.export_record` before the destination sees it, and a record that fails validation is
  quarantined with its reasons rather than being written or silently dropped;
* **the same record twice is written once.**  Records are deduplicated on their identity — tenant, customer, model
  version and the day the score refers to — so a retried run corrects rather than duplicates, and two tenants with the
  same customer id never collide;
* **each record has an outcome of its own.**  1.2.0 inferred success from *selection*: it counted the first N selected
  records as written and took the checksum and the watermark from them.  When the first record failed and the second
  succeeded, the watermark came from the failure and the checksum covered a record the destination had never seen.  Here
  every record carries a state and only an acknowledged record counts;
* **the watermark is contiguous.**  It advances over acknowledged records in time order and stops at the first
  outstanding one, per tenant.  A record that failed is never stepped over, because stepping over it would resume
  tomorrow's export past it and it would never be sent;
* **a failure is not a loss.**  A batch that fails is retried; a batch that keeps failing is broken into single-record
  writes, so one bad row does not take its neighbours down.  A transient error is retried with backoff; a permanent one
  is recorded with its code and description;
* **the result is checkable.**  Every run returns the SHA-256 of exactly the acknowledged records, a per-record
  outcome list, and a checkpoint that a restarted process can resume from without re-sending what was accepted;
* **the destination is asked what it holds.**  ``reconcile`` compares the recorded acknowledgement with a read-back,
  and is allowed to answer "unknown" — a destination that cannot count is not a destination that can be trusted with a
  green tick.

The outbox is in-process: :func:`checkpoint_of` produces the durable part (per-tenant watermarks plus the idempotency
keys already acknowledged), which the caller stores and passes to :func:`resume`.  Persisting it in the platform's own
database is the job of the service that owns the sync, and it is what makes a restart safe.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from ...errors import Conflict, ValidationFailed
from .. import export_record

RETRYABLE = ("TimeoutError", "ConnectionError", "OperationalError", "InterfaceError", "ServiceUnavailable", "InternalError")
ACKNOWLEDGED = "ACKNOWLEDGED"
FAILED = "FAILED"
QUARANTINED = "QUARANTINED"
PENDING = "PENDING"


@dataclass(frozen=True)
class RetryPolicy:
    """How many times a statement is attempted, and how long the waits are between attempts."""

    attempts: int = 3
    backoff_seconds: float = 0.0  # the adapter in tests sets this to zero; production leaves it at the default
    multiply: float = 2.0

    def wait(self, attempt: int) -> float:
        return self.backoff_seconds * (self.multiply ** (attempt - 1))


@dataclass
class Quarantined:
    """A record that was not written, with the reason a person needs to fix it."""

    identity: str
    problems: list[str]
    attempts: int = 1

    def as_dict(self) -> dict[str, Any]:
        return {"identity": self.identity, "problems": list(self.problems), "attempts": self.attempts}


@dataclass
class RecordOutcome:
    """One record's journey: what was sent, how many times, and what the destination said.

    This is the record the 1.2.0 code did not have, and its absence is why a failed record could advance a watermark.
    """

    index: int
    tenant_id: int | None
    idempotency_key: str
    payload_checksum: str
    prediction_timestamp: datetime | None
    status: str = PENDING
    attempts: int = 0
    external_reference: str | None = None
    submitted_at: datetime | None = None
    acknowledged_at: datetime | None = None
    error_code: str | None = None
    error_description: str | None = None
    identity_key: str = ""

    @property
    def acknowledged(self) -> bool:
        return self.status == ACKNOWLEDGED

    def as_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "tenant_id": self.tenant_id,
            "idempotency_key": self.idempotency_key,
            "payload_checksum": self.payload_checksum,
            "prediction_timestamp": self.prediction_timestamp.isoformat() if self.prediction_timestamp else None,
            "status": self.status,
            "attempts": self.attempts,
            "external_reference": self.external_reference,
            "submitted_at": self.submitted_at.isoformat() if self.submitted_at else None,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            "error_code": self.error_code,
            "error_description": self.error_description,
            "identity_key": self.identity_key,
        }


@dataclass
class DeliveryResult:
    """What a run did, in numbers a reconciliation can be held to."""

    destination: str
    run_id: str
    selected: int = 0
    written: int = 0
    duplicates_within_batch: int = 0
    quarantined: list[Quarantined] = field(default_factory=list)
    checksum: str = ""
    watermark: datetime | None = None
    watermarks: dict[int | None, datetime] = field(default_factory=dict)
    batches: int = 0
    retries: int = 0
    outcomes: list[RecordOutcome] = field(default_factory=list)
    verification: dict[str, Any] = field(default_factory=dict)

    @property
    def failed(self) -> int:
        return sum(1 for outcome in self.outcomes if outcome.status == FAILED)

    @property
    def acknowledged_keys(self) -> list[str]:
        return [outcome.idempotency_key for outcome in self.outcomes if outcome.acknowledged]

    def as_dict(self) -> dict[str, Any]:
        return {
            "destination": self.destination,
            "run_id": self.run_id,
            "selected": self.selected,
            "written": self.written,
            "failed": self.failed,
            "duplicates_within_batch": self.duplicates_within_batch,
            "quarantined": [item.as_dict() for item in self.quarantined],
            "checksum": self.checksum,
            "watermark": self.watermark.isoformat() if self.watermark else None,
            "watermarks": {str(tenant): stamp.isoformat() for tenant, stamp in self.watermarks.items()},
            "batches": self.batches,
            "retries": self.retries,
            "outcomes": [outcome.as_dict() for outcome in self.outcomes],
            "verification": self.verification,
        }


@runtime_checkable
class Destination(Protocol):
    """What a destination must be able to do.  Small on purpose: everything else is in ``deliver``."""

    name: str

    def test_connection(self) -> dict[str, Any]:
        """Prove the credentials and the shape of the target; raise when they do not."""

    def ensure_schema(self) -> None:
        """Create or verify the objects a write needs."""

    def write(self, records: Sequence[dict[str, Any]], *, run_id: str) -> int:
        """Upsert ``records``; return how many rows the destination now holds for ``run_id``."""

    def count_stored(self, *, run_id: str) -> int | None:
        """How many rows the destination holds for ``run_id``, or ``None`` when it cannot say."""


def identity(record: Mapping[str, Any]) -> str:
    """The key two records must not both be written under: tenant, customer, model version, day of the score."""
    cutoff = record.get("data_cutoff_timestamp")
    day = cutoff.date().isoformat() if isinstance(cutoff, datetime) else str(cutoff)[:10]
    return f"{record.get('tenant_id')}|{record.get('external_customer_id')}|{record.get('model_name')}|{record.get('model_version')}|{day}"


def idempotency_key(destination: str, record: Mapping[str, Any]) -> str:
    """The key a duplicate delivery is recognised by: the destination, the identity, and the payload's checksum.

    The payload digest is in the key on purpose.  A retry of the same statement is the same key and must be swallowed;
    a corrected statement about the same customer-day is a different key and must be written.
    """
    return f"{destination}:{identity(record)}:{export_record.checksum([record])[:16]}"


def watermark_of(records: Iterable[Mapping[str, Any]]) -> datetime | None:
    """The newest ``prediction_timestamp`` among records that carry one."""
    newest: datetime | None = None
    for record in records:
        value = record.get("prediction_timestamp")
        if isinstance(value, datetime) and (newest is None or value > newest):
            newest = value
    return newest


def filter_after(records: Iterable[Mapping[str, Any]], watermark: datetime | None) -> list[dict[str, Any]]:
    """The records newer than ``watermark`` — an incremental export that is safe to retry."""
    out = []
    for record in records:
        if watermark is None:
            out.append(dict(record))
            continue
        value = record.get("prediction_timestamp")
        if not isinstance(value, datetime) or value > watermark:
            out.append(dict(record))
    return out


def deduplicate(records: Sequence[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    """One record per identity, the last one winning (it is the newest statement about that customer-day)."""
    seen: dict[str, dict[str, Any]] = {}
    for record in records:
        seen[identity(record)] = record
    return list(seen.values()), len(records) - len(seen)


def contiguous_watermark(outcomes: Sequence[RecordOutcome]) -> datetime | None:
    """The newest instant by which **every** record of a stream was acknowledged.

    Records are grouped by their ``prediction_timestamp`` and the groups walked in time order.  A group advances the
    watermark only when every record in it was acknowledged; the first group with an outstanding record ends the walk.
    Grouping matters because the watermark is compared with ``>`` when the next export is selected: an instant at which
    one record was accepted and another was not is not an instant that has been delivered, so the watermark must stay
    behind it — otherwise the resumed export would step over the failure and it would never be sent.
    """
    grouped: dict[datetime, list[RecordOutcome]] = {}
    for outcome in outcomes:
        if outcome.prediction_timestamp is not None:
            grouped.setdefault(outcome.prediction_timestamp, []).append(outcome)
    watermark: datetime | None = None
    for stamp in sorted(grouped):
        group = grouped[stamp]
        if not all(outcome.acknowledged for outcome in group):
            break
        watermark = stamp
    return watermark


def tenant_watermarks(outcomes: Sequence[RecordOutcome]) -> dict[int | None, datetime]:
    """``contiguous_watermark`` per tenant: one tenant's backlog must not hold another tenant's export back."""
    grouped: dict[int | None, list[RecordOutcome]] = {}
    for outcome in outcomes:
        grouped.setdefault(outcome.tenant_id, []).append(outcome)
    out: dict[int | None, datetime] = {}
    for tenant, group in grouped.items():
        stamp = contiguous_watermark(group)
        if stamp is not None:
            out[tenant] = stamp
    return out


def checkpoint_of(result: DeliveryResult) -> dict[str, Any]:
    """The durable part of a run: what was acknowledged, and where each tenant's watermark stands."""
    return {
        "destination": result.destination,
        "run_id": result.run_id,
        "acknowledged_keys": result.acknowledged_keys,
        "watermarks": {str(tenant): stamp.isoformat() for tenant, stamp in result.watermarks.items()},
        "checksum": result.checksum,
    }


def resume(records: Sequence[Mapping[str, Any]], checkpoint: Mapping[str, Any] | None, *, destination: str) -> list[dict[str, Any]]:
    """The records a restarted run still has to deliver: everything whose idempotency key was not acknowledged."""
    if not checkpoint:
        return [dict(record) for record in records]
    done = set(checkpoint.get("acknowledged_keys") or [])
    return [dict(record) for record in records if idempotency_key(destination, record) not in done]


def _is_retryable(exc: BaseException) -> bool:
    return type(exc).__name__ in RETRYABLE


def _attempt_write(destination: Destination, batch: Sequence[dict[str, Any]], outcomes: dict[int, RecordOutcome],
                   policy: RetryPolicy, sleep: Callable[[float], None], result: DeliveryResult) -> None:  # fmt: skip
    """Write a batch; on a failure that will not go away, try each record on its own so one row cannot sink the rest."""
    attempt = 0
    while True:
        attempt += 1
        for outcome in (outcomes[record["_index"]] for record in batch):
            outcome.attempts = max(outcome.attempts, attempt)
            outcome.submitted_at = outcome.submitted_at or datetime.now().astimezone()
        try:
            destination.write([{key: value for key, value in record.items() if key != "_index"} for record in batch],
                              run_id=result.run_id)  # fmt: skip
            now = datetime.now().astimezone()
            for record in batch:
                outcome = outcomes[record["_index"]]
                outcome.status, outcome.acknowledged_at, outcome.error_code, outcome.error_description = ACKNOWLEDGED, now, None, None
            return
        except Exception as exc:
            if _is_retryable(exc) and attempt < policy.attempts:
                result.retries += 1
                sleep(policy.wait(attempt))
                continue
            if len(batch) > 1:
                # the batch failed as a whole: isolate the record that did it rather than losing its neighbours
                for record in batch:
                    _attempt_write(destination, [record], outcomes, RetryPolicy(attempts=1), sleep, result)
                return
            outcome = outcomes[batch[0]["_index"]]
            outcome.status = FAILED
            outcome.error_code = type(exc).__name__
            outcome.error_description = str(exc)[:300] or type(exc).__name__
            return


def deliver(
    destination: Destination,
    records: Sequence[Mapping[str, Any]],
    *,
    run_id: str,
    batch_size: int = 500,
    policy: RetryPolicy | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> DeliveryResult:
    """Validate, deduplicate, write in batches, record each record's outcome, and reconcile what arrived.

    The order matters.  Validation comes before anything is counted, so a record that may not be exported never
    reaches the destination and never inflates a number.  Deduplication comes before batching, so the same
    customer-day is not written twice within one run.  Acknowledgement is per record, and only acknowledged records
    make a checksum or move a watermark.  Reconciliation is last and is allowed to say "unknown".
    """
    if batch_size <= 0:
        raise ValidationFailed("batch_size must be positive", details={"field": "batch_size"})
    retry = policy or RetryPolicy()
    result = DeliveryResult(destination=destination.name, run_id=run_id, selected=len(records))

    outcomes: dict[int, RecordOutcome] = {}
    valid: list[dict[str, Any]] = []
    for index, record in enumerate(records):
        try:
            checked = export_record.ensure_valid(record)
        except ValidationFailed as refused:
            result.quarantined.append(Quarantined(identity=identity(record) or f"record-{index}",
                                                  problems=list(refused.details.get("problems") or [refused.message])))  # fmt: skip
            continue
        checked["_index"] = index
        valid.append(checked)
        stamp = checked.get("prediction_timestamp")
        outcomes[index] = RecordOutcome(index=index, tenant_id=checked.get("tenant_id"),
                                        idempotency_key=idempotency_key(destination.name, checked),
                                        payload_checksum=export_record.checksum([checked]),
                                        prediction_timestamp=stamp if isinstance(stamp, datetime) else None,
                                        identity_key=identity(checked))  # fmt: skip

    valid, duplicates = deduplicate(valid)
    result.duplicates_within_batch = duplicates

    for start in range(0, len(valid), batch_size):
        batch = valid[start : start + batch_size]
        if not batch:
            continue
        _attempt_write(destination, batch, outcomes, retry, sleep, result)
        result.batches += 1

    ordered = sorted(outcomes.values(), key=lambda outcome: outcome.index)
    result.outcomes = ordered
    acknowledged = [outcome for outcome in ordered if outcome.acknowledged]

    # the checksum covers what the destination acknowledged, in the order it was acknowledged -- not the first N selected
    acked_records = [valid[[record["_index"] for record in valid].index(outcome.index)] for outcome in acknowledged]
    result.checksum = export_record.checksum([{key: value for key, value in record.items() if key != "_index"} for record in acked_records])
    result.written = len(acknowledged)
    result.watermarks = tenant_watermarks(ordered)
    result.watermark = contiguous_watermark(ordered)

    stored = destination.count_stored(run_id=run_id)
    if stored is None:
        result.verification = {"checked": "unknown", "reason": "the destination cannot count what it holds for this run",
                               "expected": result.written}  # fmt: skip
    else:
        result.verification = {"checked": "counted the rows the destination holds for this run", "expected": result.written,
                               "stored": stored, "matches": stored == result.written}  # fmt: skip
    return result


def reconcile(result: DeliveryResult, stored: int | None) -> dict[str, Any]:
    """Re-read the destination later and say whether the run is still there, and unchanged."""
    if stored is None:
        return {"checked": "unknown", "expected": result.written, "reason": "the destination cannot count rows"}
    if stored < result.written:
        raise Conflict(f"{result.written - stored} of {result.written} rows are missing at the destination",
                       details={"expected": result.written, "stored": stored, "run_id": result.run_id})  # fmt: skip
    return {"checked": "counted", "expected": result.written, "stored": stored, "matches": stored == result.written}


__all__ = [
    "ACKNOWLEDGED",
    "FAILED",
    "PENDING",
    "QUARANTINED",
    "Checkpoint",
    "DeliveryResult",
    "Destination",
    "Quarantined",
    "RecordOutcome",
    "RetryPolicy",
    "checkpoint_of",
    "contiguous_watermark",
    "deduplicate",
    "deliver",
    "filter_after",
    "idempotency_key",
    "identity",
    "reconcile",
    "resume",
    "tenant_watermarks",
    "watermark_of",
]  # fmt: skip

Checkpoint = dict[str, Any]
