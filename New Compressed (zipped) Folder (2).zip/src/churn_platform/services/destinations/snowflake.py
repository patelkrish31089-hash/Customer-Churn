"""The Snowflake destination (1.3.0).

A warehouse table the business can query without knowing anything about this platform: one row per customer per
model version per data cutoff, replaced (never duplicated) when the same prediction is exported again.

Three decisions worth stating, because each of them is a place where a connector usually goes wrong:

**The driver is injected, not imported.**  ``SnowflakeDestination`` takes a ``connect`` callable that returns a
DB-API connection.  Production passes ``snowflake.connector.connect``; a test passes a connection that records the
statements and answers like a warehouse.  Nothing in this module imports the vendor's SDK, so the module can be
exercised on a machine without it — and equally, **no test in this repository can prove that a real Snowflake account
accepts these statements.**  That acceptance is GATE 12 and it is BLOCKED: it needs an account, a warehouse and a role.

**Credential handling is the adapter's caller's job.**  Key-pair and OAuth both arrive as parameters; the private key is
passed as the PEM *bytes* to ``snowflake.connector``'s ``private_key_file_pkey``/``private_key`` handling, never read
from a path in this module, so a check that forbids reading files cannot be defeated by this code.  No credential is
logged: ``safe_config`` is what goes into an audit event, and it omits everything secret.

**The session is read back and compared, not assumed.**  ``test_connection`` asks the session what it is — version,
user, role, warehouse, database, schema, account and region — and refuses when any of them differs from the
configuration.  1.2.0 compared only the warehouse and the database and treated a missing value as agreement, so a
connection that landed in ``ANALYTICS.SANDBOX`` while the configuration said ``ANALYTICS.PUBLIC`` reported healthy and
then wrote its rows to the wrong schema.  A value the session does not report is a mismatch, not a pass.

**Identifiers are validated and quoted.**  Account, warehouse, database, schema, role and table names are configuration,
and configuration is input.  Every one of them is checked against a strict identifier grammar and then quoted, so a
name can never end a statement or inject one, and a table called ``ORDER`` or ``SELECT`` works instead of failing
obscurely.  Nothing else is quoted: the column names and the identity come from the schema, never from a caller.

**The write is a MERGE, and its identity is the record's own.**  A retried run, an overlapping incremental window or a
re-sent batch all converge on the same rows; ``count_stored`` for the run is then what reconciliation compares against,
and a mismatch is a conflict rather than a shrug.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ...errors import ValidationFailed
from .. import export_record

TABLE = "CHURN_PREDICTIONS"
#: what a name may be before it is quoted: a letter or underscore, then letters, digits, ``_`` or ``$``
IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]{0,254}$")
RUNS_TABLE = "CHURN_EXPORT_RUNS"
# which of the record's fields become which Snowflake type
TYPES = {"integer": "NUMBER(38,0)", "number": "FLOAT", "string": "VARCHAR", "timestamp": "TIMESTAMP_TZ", "date": "DATE"}
STRING_WIDTH = {"model_checksum": "VARCHAR(64)", "risk_tier": "VARCHAR(20)", "approval_status": "VARCHAR(20)", "model_version": "VARCHAR(40)"}


def quote(name: str) -> str:
    """Validate a configured identifier and return it quoted — or refuse it, with the reason.

    Quoting is not decoration.  An unquoted name in Snowflake is upper-cased and cannot be a reserved word; a quoted one
    is taken literally.  Validating first is what keeps a configuration value from becoming SQL: ``quote`` is the only
    way a configured name reaches a statement in this module.
    """
    text = str(name or "")
    if not IDENTIFIER.fullmatch(text):
        raise ValidationFailed(
            f"{text!r} is not a usable Snowflake identifier",
            details={"identifier": text, "rule": "a letter or underscore, then up to 254 letters, digits, '_' or '$'"},
        )
    return f'"{text.upper()}"'


def _column(field_kind: str, name: str) -> str:
    return STRING_WIDTH.get(name, TYPES[field_kind])


def ddl(table: str = TABLE) -> str:
    """The destination table: one row per identity, nothing nullable that the record says is required."""
    columns = []
    for definition in export_record.FIELDS:
        column = f"{quote(definition.name)} {_column(definition.kind, definition.name)}"
        if not definition.nullable:
            column += " NOT NULL"
        columns.append(column)
    columns += [
        f"{quote('SYNC_RUN_ID')} VARCHAR(64) NOT NULL",
        f"{quote('EXPORTED_AT')} TIMESTAMP_TZ NOT NULL",
        f"CONSTRAINT {quote(table + '_IDENTITY')} PRIMARY KEY ("
        + ", ".join(quote(column) for column in _IDENTITY_COLUMNS)
        + ")",
    ]
    return f"CREATE TABLE IF NOT EXISTS {quote(table)} (\n  " + ",\n  ".join(columns) + "\n)"


def runs_ddl(table: str = RUNS_TABLE) -> str:
    """One row per export run: who, when, how many, and the checksum the rows must match."""
    columns = [("RUN_ID", "VARCHAR(64) NOT NULL"), ("TENANT_ID", "NUMBER(38,0) NOT NULL"),
               ("ROWS_EXPECTED", "NUMBER(38,0) NOT NULL"), ("ROWS_WRITTEN", "NUMBER(38,0) NOT NULL"),
               ("CHECKSUM", "VARCHAR(64) NOT NULL"), ("WATERMARK", "TIMESTAMP_TZ"), ("ACTOR", "VARCHAR(200)"),
               ("STARTED_AT", "TIMESTAMP_TZ NOT NULL"), ("FINISHED_AT", "TIMESTAMP_TZ")]  # fmt: skip
    body = ",\n".join(f"  {quote(name)} {kind}" for name, kind in columns)
    return (f"CREATE TABLE IF NOT EXISTS {quote(table)} (\n{body},\n"
            f"  CONSTRAINT {quote(table + '_PK')} PRIMARY KEY ({quote('RUN_ID')})\n)")  # fmt: skip


def merge_statement(table: str = TABLE) -> str:
    """Upsert: on a matching identity every column is refreshed; otherwise the row is inserted.

    The source is an aliased one-row subquery, because Snowflake resolves ``source.<column>`` by name: a bare
    ``SELECT %(v0)s, %(v1)s…`` gives the columns no names to join on, and the statement fails on the first thing a
    careful reader would ask about it.  Parameters stay parameters — nothing is interpolated into the SQL.
    """
    names = [quote(definition.name) for definition in export_record.FIELDS] + [quote("SYNC_RUN_ID"), quote("EXPORTED_AT")]
    identity_columns = [quote(column) for column in _IDENTITY_COLUMNS]
    source = ", ".join(f"%(v{index})s AS {name}" for index, name in enumerate(names))
    updates = ", ".join(f"{name} = source.{name}" for name in names if name not in identity_columns)
    inserts = ", ".join(names)
    values = ", ".join(f"source.{name}" for name in names)
    on = " AND ".join(f"target.{name} = source.{name}" for name in identity_columns)
    return (
        f"MERGE INTO {quote(table)} AS target USING (SELECT {source}) AS source ON {on} "  # noqa: S608 - identifiers validated and quoted; values are parameters  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
        f"WHEN MATCHED THEN UPDATE SET {updates} WHEN NOT MATCHED THEN INSERT ({inserts}) VALUES ({values})"
    )


#: the columns that make one row unique.  The tenant leads: two tenants may hold the same customer id.
_IDENTITY_COLUMNS = ("TENANT_ID", "EXTERNAL_CUSTOMER_ID", "MODEL_NAME", "MODEL_VERSION", "DATA_CUTOFF_TIMESTAMP")


@dataclass
class SnowflakeConfig:
    """Everything a connection needs except the secret, which is passed to the connector separately."""

    account: str
    user: str
    warehouse: str
    database: str
    schema: str = "PUBLIC"
    role: str | None = None
    authenticator: str = "snowflake_jwt"  # key-pair; "oauth" is the other supported form
    table: str = TABLE
    runs_table: str = RUNS_TABLE
    login_timeout_seconds: int = 15
    tls: bool = True  #: the connector verifies the server certificate unless insecure_mode is passed; this adapter never passes it

    def locator(self) -> str:
        """The account as Snowflake reports it: a configured ``org-account.region`` is compared on its account part."""
        return str(self.account or "").split(".")[0].strip().upper()

    def region(self) -> str | None:
        parts = str(self.account or "").split(".")
        return parts[1].strip().upper() if len(parts) > 1 else None

    def safe(self) -> dict[str, Any]:
        """The configuration as it may be written into a log or an audit event: no secret, no token, no key."""
        return {"account": self.account, "user": self.user, "warehouse": self.warehouse, "database": self.database,
                "schema": self.schema, "role": self.role, "authenticator": self.authenticator, "table": self.table}  # fmt: skip

    def problems(self) -> list[str]:
        missing = [name for name in ("account", "user", "warehouse", "database", "schema") if not str(getattr(self, name) or "").strip()]
        if self.authenticator not in ("snowflake_jwt", "oauth", "externalbrowser"):
            missing.append("authenticator must be snowflake_jwt, oauth or externalbrowser")
        for attribute in ("warehouse", "database", "schema", "role", "table", "runs_table"):
            name = getattr(self, attribute)
            if name is None:
                continue
            try:
                quote(name)
            except ValidationFailed:
                missing.append(f"{attribute} {name!r} is not a usable Snowflake identifier")
        if not self.tls:
            missing.append("tls must not be disabled: the connector is never asked to skip certificate verification")
        return missing


@dataclass
class SnowflakeDestination:
    """The adapter.  ``connect`` is ``snowflake.connector.connect`` in production and a stand-in in tests."""

    config: SnowflakeConfig
    connect: Callable[..., Any]
    name: str = "snowflake"
    _connection: Any = field(default=None, repr=False)

    # ------------------------------------------------------------------ plumbing
    def _conn(self):
        if self._connection is None:
            options = {"account": self.config.account, "user": self.config.user, "warehouse": self.config.warehouse,
                       "database": self.config.database, "schema": self.config.schema, "authenticator": self.config.authenticator,
                       "login_timeout": self.config.login_timeout_seconds}  # fmt: skip
            if self.config.role:
                options["role"] = self.config.role
            self._connection = self.connect(**options)
        return self._connection

    def close(self) -> None:
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def _execute(self, statement: str, parameters: Any = None) -> Any:
        cursor = self._conn().cursor()
        try:
            if parameters is None:
                cursor.execute(statement)
            else:
                cursor.execute(statement, parameters)
            return cursor.fetchall() if cursor.description else []
        finally:
            cursor.close()

    # ------------------------------------------------------------------ the destination contract
    def _session(self) -> dict[str, Any]:
        """Ask the session what it actually is.  A connection that cannot be made is a refusal, not a traceback."""
        try:
            rows = self._execute(
                "SELECT CURRENT_VERSION(), CURRENT_USER(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE(),"
                " CURRENT_SCHEMA(), CURRENT_ACCOUNT(), CURRENT_REGION()"
            )
        except ValidationFailed:
            raise
        except Exception as exc:
            kind = "timeout" if "timeout" in type(exc).__name__.lower() else "connection"
            raise ValidationFailed(
                f"Snowflake refused the connection ({type(exc).__name__}): {str(exc)[:200]}",
                details={"kind": kind, "account": self.config.account, "user": self.config.user, "role": self.config.role},
            ) from exc
        values = list(rows[0]) if rows else []
        keys = ("version", "user", "role", "warehouse", "database", "schema", "account", "region")
        values += [None] * (len(keys) - len(values))
        return dict(zip(keys, (str(value) if value is not None else None for value in values), strict=False))

    def test_connection(self) -> dict[str, Any]:
        """Prove the credentials, and that the session is the one the configuration asked for.

        Compared: account, region, warehouse, database, schema and role.  A value the session does not report counts as a
        mismatch — silence is not agreement.  Authentication failures arrive here as a refusal with their kind, so a
        wrong key and a wrong schema cannot be told apart by nothing at all.
        """
        problems = self.config.problems()
        if problems:
            raise ValidationFailed(f"the Snowflake configuration is incomplete: {problems[0]}", details={"problems": problems})
        session = self._session()
        pairs = [
            ("account", session.get("account"), self.config.locator()),
            ("region", session.get("region"), self.config.region()),
            ("warehouse", session.get("warehouse"), self.config.warehouse),
            ("database", session.get("database"), self.config.database),
            ("schema", session.get("schema"), self.config.schema),
            ("role", session.get("role"), self.config.role),
        ]
        mismatches = []
        for key, found, configured in pairs:
            if configured is None:
                continue  # not configured (region, role): the session's own value stands
            if found is None:
                mismatches.append(f"{key} is not reported by the session, configured {configured}")
            elif str(found).upper() != str(configured).upper():
                mismatches.append(f"{key} is {found}, configured {configured}")
        if mismatches:
            raise ValidationFailed(
                "the Snowflake session is not the configured one: " + "; ".join(mismatches),
                details={"session": session, "problems": mismatches, "configured": self.config.safe()},
            )
        return {
            "ok": True,
            "session": session,
            "compared": [key for key, _, configured in pairs if configured is not None],
            "tls": {
                "verified": self.config.tls,
                "mechanism": "snowflake-connector-python verifies the server certificate; this adapter never passes insecure_mode",
            },
            "health": "the session answered and is the configured one",
        }

    def health(self) -> dict[str, Any]:
        try:
            self._execute(f"SELECT COUNT(*) FROM {quote(self.config.table)}")  # noqa: S608 - the identifiers are validated and quoted; values are bound  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
        except Exception as exc:
            return {"ok": False, "error": f"{type(exc).__name__}: {exc}"[:300]}
        return {"ok": True, "table": self.config.table}

    def ensure_schema(self) -> None:
        self._execute(ddl(self.config.table))
        self._execute(runs_ddl(self.config.runs_table))

    def write(self, records: Sequence[dict[str, Any]], *, run_id: str) -> int:
        """MERGE every record, then say how many rows the destination now holds for this run."""
        if not records:
            return self.count_stored(run_id=run_id) or 0
        statement = merge_statement(self.config.table)
        exported_at = datetime.now().astimezone()
        for record in records:
            parameters = {}
            for index, definition in enumerate(export_record.FIELDS):
                parameters[f"v{index}"] = record.get(definition.name)
            parameters[f"v{len(export_record.FIELDS)}"] = run_id
            parameters[f"v{len(export_record.FIELDS) + 1}"] = exported_at
            self._execute(statement, parameters)
        return self.count_stored(run_id=run_id) or 0

    def count_stored(self, *, run_id: str) -> int | None:
        try:
            rows = self._execute(
                f"SELECT COUNT(*) FROM {quote(self.config.table)} WHERE {quote('SYNC_RUN_ID')} = %(run_id)s",  # noqa: S608 - the identifiers are validated and quoted; values are bound  # nosec B608 - the identifiers are validated and quoted and the values are bound parameters
                {"run_id": run_id},
            )
        except Exception:
            return None
        return int(rows[0][0]) if rows else 0

    def record_run(self, *, run_id: str, tenant_id: int, expected: int, written: int, checksum: str,
                   watermark: datetime | None, actor: str | None, started_at: datetime) -> None:  # fmt: skip
        """The run's own row, so a reconciliation can be made by anyone who can read the warehouse."""
        self._execute(
            f"INSERT INTO {quote(self.config.runs_table)} ("  # noqa: S608 - the identifiers are validated and quoted; values are bound
            + ", ".join(quote(c) for c in ("RUN_ID", "TENANT_ID", "ROWS_EXPECTED", "ROWS_WRITTEN", "CHECKSUM", "WATERMARK", "ACTOR", "STARTED_AT"))
            + ")"
            " VALUES (%(run_id)s, %(tenant_id)s, %(expected)s, %(written)s, %(checksum)s, %(watermark)s, %(actor)s, %(started_at)s)",
            {"run_id": run_id, "tenant_id": tenant_id, "expected": expected, "written": written, "checksum": checksum,
             "watermark": watermark, "actor": actor, "started_at": started_at},
        )  # fmt: skip


__all__ = ["RUNS_TABLE", "TABLE", "SnowflakeConfig", "SnowflakeDestination", "ddl", "merge_statement", "quote", "runs_ddl"]


def _unused(_: Mapping[str, Any]) -> None:  # pragma: no cover - keeps the typing import honest
    return None
