"""Nightly pipeline: data quality -> labels -> feature store -> batch scoring -> recommendations ->
monitoring, run as an ordered chain on the platform's own job queue.

The platform scheduler (``schedules`` table) or an external orchestrator (see ``deploy/airflow``)
triggers ``pipeline.nightly``.  Each step is a normal job; the pipeline job waits for a step to
finish before queueing the next one and stops at the first failure.

``run_chain`` is the generic "ordered chain of jobs" runner; automatic retraining
(``services.retraining``) uses it as well.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import date, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import AppError, Conflict
from ..models import ChurnLabel, FeatureContract, Job, PredictionBatch, Schedule, User
from ..security import ROLE_PERMISSIONS, Principal
from . import audit, features, jobs, labels, monitoring, policies, predictions, quality, registry, retention, signals

STEPS = ("data_quality", "signals", "labels", "features", "scoring", "recommendations", "monitoring")
POLL_SECONDS = 5
LABEL_REFRESH_MONTHS = 4  # labels of recent as-of dates mature later, so they are recomputed nightly


def owner_principal(session: Session, tenant_id: int, user_id: int | None) -> Principal:
    """Who scheduled work runs as: the user that started it, else the tenant's first active admin."""
    user = session.get(User, user_id) if user_id else None
    if user is None or user.tenant_id != tenant_id or not user.is_active:
        user = session.execute(select(User).where(User.tenant_id == tenant_id, User.role == "admin", User.is_active.is_(True))
                               .order_by(User.id).limit(1)).scalar_one_or_none()  # fmt: skip
    if user is None:
        raise jobs.PermanentJobError("the tenant has no active admin user to own scheduled work")
    return Principal(user_id=user.id, tenant_id=tenant_id, email=user.email, role=user.role, session_id=0,
                     permissions=ROLE_PERMISSIONS[user.role])  # fmt: skip


def scored_dates_due(session: Session, tenant_id: int, as_of: date) -> list[date]:
    """Scoring dates whose outcome window has closed but whose outcomes are not labelled yet (newest first).

    Training labels are taken at month starts, but the nightly batch is scored for the day after the newest data.
    Without labels for those dates the realised performance of the production model - and with it the retraining
    trigger - would only ever see batches scored exactly on the first of a month.
    """
    policy = policies.get_active(session, tenant_id, "churn_definition", required=False)
    if policy is None:
        return []
    defn = policies.parse(policy)
    closed = as_of - timedelta(days=defn.horizon_days + defn.reactivation_window_days)
    scored = set(session.execute(select(PredictionBatch.as_of_date).where(
        PredictionBatch.tenant_id == tenant_id, PredictionBatch.status == "completed", PredictionBatch.kind != "single",
        PredictionBatch.as_of_date <= closed).distinct()).scalars())  # fmt: skip
    if not scored:
        return []
    rows = session.execute(select(ChurnLabel.as_of_date, ChurnLabel.status).where(
        ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.as_of_date >= min(scored),
        ChurnLabel.as_of_date <= closed).distinct()).all()  # fmt: skip
    labelled, still_open = {d for d, _ in rows}, {d for d, status in rows if status == "immature"}
    return sorted((scored - labelled) | (scored & still_open), reverse=True)


def _start_step(session: Session, principal: Principal, step: str) -> tuple[Any, dict]:
    """Queue one step.  Returns (job or None when there is nothing to do, info)."""
    tenant_id = principal.tenant_id
    as_of = predictions.default_as_of(session, tenant_id)
    if step == "data_quality":
        run, job = quality.start_run(session, principal)
        return job, {"dq_run_id": run.id}
    if step == "signals":  # sentiment of new support text, attribute history, identity links, adoption at the as-of date
        return signals.start_refresh(session, principal, as_of), {"as_of_date": as_of.isoformat()}
    if step == "labels":
        month = as_of
        for _ in range(LABEL_REFRESH_MONTHS - 1):
            month = (month.replace(day=1) - timedelta(days=1)).replace(day=1)
        months = labels.month_starts(month, as_of)  # the training grid: recent month starts mature later, so refresh them
        due = [d for d in scored_dates_due(session, tenant_id, as_of) if d not in months][: labels.MAX_AS_OF_DATES - len(months)]
        run, job = labels.start_run(session, principal, as_of_dates=sorted({*months, *due}))
        return job, {"label_run_id": run.id, "from": month.isoformat(), "to": as_of.isoformat(),
                     "scored_dates_labelled": [d.isoformat() for d in sorted(due)]}  # fmt: skip
    version = registry.production_version(session, tenant_id)
    if step == "features":
        contract = session.get(FeatureContract, version.contract_id)
        run, job = features.start_materialization(session, principal, contract_id=contract.id, as_of_dates=[as_of])
        return job, {"feature_run_id": run.id, "as_of_date": as_of.isoformat()}
    if step == "scoring":
        batch, job = predictions.start_batch(session, principal, tenant_id=tenant_id, kind="scheduled")
        return job, {"batch_id": batch.id, "already_scored": job is None}
    if step == "recommendations":
        batch = predictions.latest_batch(session, tenant_id, version.id)
        if batch is None:
            return None, {"skipped": "no completed batch"}
        return retention.start_generation(session, principal, batch.id), {"batch_id": batch.id}
    return monitoring.start(session, principal, tenant_id=tenant_id), {}


def active_chain(session: Session, tenant_id: int, job_type: str, *, started_before: int | None = None) -> Job | None:
    """The live tick of a chain of this type that is under way for the tenant, if any.

    Every tick of a chain carries the id of the job that started it (``root_job_id``; the first tick is its own
    root).  With ``started_before``, only chains whose root is older than that job id count, which lets a newly
    started chain ask "was somebody here before me?" without seeing itself.
    """
    live = session.execute(select(Job).where(Job.tenant_id == tenant_id, Job.job_type == job_type, Job.status.in_(("queued", "running")))
                           .order_by(Job.id)).scalars().all()  # fmt: skip
    for job in live:
        root = int((job.payload or {}).get("root_job_id") or job.id)
        if started_before is None or root < started_before:
            return job
    return None


def start(session: Session, principal: Principal) -> tuple[Job, bool]:
    """Start the nightly chain now.  Returns ``(job, started)``: when a run is already under way nothing new
    is queued and that run's live job is returned, so pressing the button twice does not do the night's work twice."""
    running = active_chain(session, principal.tenant_id, "pipeline.nightly")
    if running is not None:
        return running, False
    from ..models import OrchestratorRun

    if session.execute(select(OrchestratorRun.id).where(OrchestratorRun.tenant_id == principal.tenant_id, OrchestratorRun.status == "running").limit(1)).first():
        raise Conflict("an external orchestrator is running a pipeline step for this tenant; wait for it to finish", code="orchestrator_conflict")
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="pipeline.nightly", payload={"step": 0, "log": [], "manual": True},
                       created_by=principal.user_id)  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="pipeline.started", entity_type="job", entity_id=job.id)
    return job, True


def run_chain(ctx: Any, *, job_type: str, steps: tuple[str, ...], start_step: Callable[[Session, Principal, str, dict], tuple[Any, dict]],
              name: str, audit_action: str, on_complete: Callable[[Session, Any, dict, list], dict] | None = None) -> dict:
    """One tick of an ordered chain: check the awaited step, then queue the next step and a continuation.

    ``start_step(session, principal, step, payload)`` queues the work for one step and returns
    ``(job or None when there is nothing to do, info)``.

    Jobs are delivered at least once (a worker can die after committing and before reporting success), so a tick
    must be safe to run twice: the continuation carries an idempotency key per chain and step, and a tick that
    finds its continuation already queued does nothing.  A chain that stops raises a critical alert, because
    nobody watches a nightly job.
    """
    payload = dict(ctx.payload or {})
    index, log, waiting = int(payload.get("step", 0)), list(payload.get("log", [])), payload.get("wait_job_id")
    root = int(payload.get("root_job_id") or ctx.job_id)

    def stop(reason: str, step: str) -> jobs.PermanentJobError:
        with session_scope() as ws:
            monitoring.raise_alert(ws, ctx.tenant_id, kind=f"{job_type.replace('.', '_')}_failed", severity="critical", source_type="job",
                                   source_id=ctx.job_id, title=f"The {name} stopped at step '{step}'", message=reason,
                                   detail={"step": step, "steps": log, "root_job_id": root})  # fmt: skip
        return jobs.PermanentJobError(reason)

    if index == 0 and not waiting and "root_job_id" not in payload and job_type == "pipeline.nightly" and not payload.get("manual") \
            and get_settings().orchestrator != "platform":
        # Exactly one orchestrator: with CHURN_ORCHESTRATOR=airflow the platform's own schedule does not start the chain.
        return {"state": "skipped", "reason": f"the nightly pipeline is orchestrated by {get_settings().orchestrator}; the platform's schedule stands down"}
    if index == 0 and not waiting and "root_job_id" not in payload:
        # First tick of a new chain.  A schedule firing while a manual run is under way (or the other way round)
        # must not run every step a second time alongside it: the chain that started first wins.
        with read_session() as rs:
            earlier = active_chain(rs, ctx.tenant_id, job_type, started_before=ctx.job_id)
            earlier_root = int((earlier.payload or {}).get("root_job_id") or earlier.id) if earlier is not None else None
        if earlier_root is not None:
            return {"state": "skipped", "reason": f"another {name} run is under way (started by job {earlier_root})", "active_root_job_id": earlier_root}
    if waiting:
        with read_session() as rs:
            awaited = rs.get(Job, waiting)
            status, error = awaited.status, awaited.error
        if status in ("queued", "running"):
            with session_scope() as ws:
                jobs.enqueue(ws, tenant_id=ctx.tenant_id, job_type=job_type, payload=payload, created_by=ctx.created_by,
                             run_after=utcnow() + timedelta(seconds=POLL_SECONDS))  # fmt: skip
            return {"state": "waiting", "step": steps[index - 1], "job_id": waiting}
        log[-1]["status"] = status
        if status != "succeeded":
            raise stop(f"{name} stopped: step '{steps[index - 1]}' {status}: {(error or '')[:300]}", steps[index - 1])
    if index >= len(steps):
        with session_scope() as ws:
            extra = on_complete(ws, ctx, payload, log) if on_complete else {}
            audit.record(ws, tenant_id=ctx.tenant_id, action=audit_action, entity_type="job", entity_id=ctx.job_id, detail={"steps": log, **extra})
        return {"state": "completed", "steps": log, **extra}
    step = steps[index]
    advance_key = f"{job_type}:chain:{root}:step:{index + 1}"
    failure = None
    with session_scope() as ws:
        if ws.execute(select(Job.id).where(Job.tenant_id == ctx.tenant_id, Job.idempotency_key == advance_key)).first() is not None:
            return {"state": "already_advanced", "step": step}  # this tick was delivered twice: never start a step a second time
        principal = owner_principal(ws, ctx.tenant_id, ctx.created_by)
        try:
            job, info = start_step(ws, principal, step, {**payload, "log": log})
        except AppError as exc:  # e.g. no production model yet: nothing sensible can run, stop with a clear reason
            failure = f"{name} stopped at '{step}': {exc.message}"
            ws.rollback()
        else:
            log.append({"step": step, "job_id": job.id if job is not None else None, "status": "queued" if job is not None else "skipped", **info})
            jobs.enqueue(ws, tenant_id=ctx.tenant_id, job_type=job_type, created_by=ctx.created_by, idempotency_key=advance_key,
                         payload={**payload, "root_job_id": root, "step": index + 1, "log": log,
                                  "wait_job_id": job.id if job is not None else None})  # fmt: skip
    if failure:
        raise stop(failure, step)
    return {"state": "queued", "step": step}


def run(ctx: Any) -> dict:
    """One tick of the nightly chain (see ``run_chain``)."""
    return run_chain(ctx, job_type="pipeline.nightly", steps=STEPS, start_step=lambda session, principal, step, _payload: _start_step(session, principal, step),
                     name="nightly pipeline", audit_action="pipeline.completed")  # fmt: skip


def ensure_schedule(session: Session, principal: Principal, *, hour_utc: int = 2, enabled: bool = True) -> Schedule:
    """Create (or update) the tenant's nightly schedule: one run every 24 h at ``hour_utc``:00 UTC."""
    if not 0 <= hour_utc <= 23:
        from ..errors import ValidationFailed

        raise ValidationFailed("hour_utc must be between 0 and 23", details={"field": "hour_utc"})
    now = utcnow()
    first = now.replace(hour=hour_utc, minute=0, second=0, microsecond=0)
    if first <= now:
        first += timedelta(days=1)
    schedule = session.execute(select(Schedule).where(Schedule.tenant_id == principal.tenant_id, Schedule.name == "nightly-pipeline")).scalar_one_or_none()
    if schedule is None:
        schedule = Schedule(tenant_id=principal.tenant_id, name="nightly-pipeline", job_type="pipeline.nightly", payload={"step": 0, "log": []},
                            interval_seconds=86400, next_run_at=first, enabled=enabled, created_by=principal.user_id)  # fmt: skip
        session.add(schedule)
    else:
        schedule.next_run_at, schedule.enabled = first, enabled
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="pipeline.schedule_saved", entity_type="schedule",
                 entity_id=schedule.id, detail={"hour_utc": hour_utc, "enabled": enabled})  # fmt: skip
    return schedule


def last_runs(session: Session, tenant_id: int, limit: int = 10) -> list[dict]:
    rows = session.execute(select(Job).where(Job.tenant_id == tenant_id, Job.job_type == "pipeline.nightly", Job.status != "queued")
                           .order_by(Job.id.desc()).limit(limit * 8)).scalars().all()  # fmt: skip
    out = [jobs.job_view(j) for j in rows if j.status == "failed" or (j.result or {}).get("state") == "completed"]
    return out[:limit]


__all__ = ["STEPS", "active_chain", "ensure_schedule", "last_runs", "owner_principal", "run", "run_chain", "scored_dates_due", "start"]
