"""Retention engine: turn a scored batch into tiered, reviewable next-best actions.

Tiers follow the playbook policy:
  * high risk + high value   -> human, high-touch action (CRM task for a senior CSM);
  * medium risk + low value  -> low-cost automated action (content / webinar drip, discount);
  * involuntary risk         -> transactional payment-method reminder (card expiring / failed payment).
Customers outside these tiers get no recommendation and are counted as "not covered".

Recommendations are decision support.  A risk score is not evidence that an action will work;
effects are only measured by a randomised experiment (see ``experiments``).
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, insert, select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, ValidationFailed
from ..models import (
    Account,
    CRMConnection,
    Customer,
    FeatureContract,
    Intervention,
    Prediction,
    PredictionBatch,
    RetentionRecommendation,
    UpliftModel,
)
from ..security import Principal
from . import audit, feature_engine, features, jobs, policies
from .common import get_owned, json_safe, paginate, to_dict

PLAYBOOK_GROUP = {"usage": "usage", "trend": "usage", "inactivity": "usage", "support": "support", "billing": "financial",
                  "rfm": "rfm", "customer": "customer", "subscription": "customer", "adoption": "usage"}  # fmt: skip
PRIORITY = {"high_risk_high_value": 1, "involuntary": 2, "medium_risk_low_value": 3}
NEEDED = ("mrr", "days_to_card_expiry", "failed_payments_30d", "days_since_last_failed_payment", "last_payment_failed")


def playbook_for(session: Session, tenant_id: int) -> tuple[policies.RetentionPlaybook, dict]:
    policy = policies.get_active(session, tenant_id, "retention_playbook", required=False)
    if policy is None:
        return (policies.RetentionPlaybook.model_validate(policies.DEFAULT_PLAYBOOK),
                {"source": "structural default (not an approved policy)", "policy_id": None})  # fmt: skip
    return policies.parse(policy), {"source": "approved policy", "policy_id": policy.id, "version": policy.version}


def classify(frame: pd.DataFrame, risk: policies.RiskPolicy) -> pd.DataFrame:
    """Add value percentile, high-value flag, involuntary trigger and segment to scored customers.

    Segments, in order of precedence:

    * ``involuntary``: the payment method is about to expire or the latest payment failed;
    * ``high_risk_high_value``: top risk tier and high value (personal outreach);
    * ``medium_risk_low_value``: the automated tier, "rising risk but not enough revenue to justify
      human intervention", i.e. medium *or* high risk without high value;
    * none: low risk, or medium risk with high value (no play is defined; counted and reported).
    """
    out = frame.copy()
    mrr = pd.to_numeric(out["mrr"], errors="coerce").fillna(0.0)
    out["value_percentile"] = mrr.rank(pct=True, method="average")
    out["high_value"] = out["value_percentile"] >= risk.high_value_percentile
    expiry = pd.to_numeric(out["days_to_card_expiry"], errors="coerce")
    failed_recent = pd.to_numeric(out["days_since_last_failed_payment"], errors="coerce") <= risk.involuntary_failed_payment_lookback_days
    out["card_expiring"] = expiry.notna() & (expiry <= risk.involuntary_payment_expiry_days)
    out["payment_failing"] = failed_recent.fillna(False) & (pd.to_numeric(out["last_payment_failed"], errors="coerce").fillna(0) >= 0.5)
    involuntary = out["card_expiring"] | out["payment_failing"]
    tier = out["risk_tier"]
    out["segment"] = np.where(involuntary, "involuntary",
                              np.where((tier == "high") & out["high_value"], "high_risk_high_value",
                                       np.where(tier.isin(["high", "medium"]) & ~out["high_value"], "medium_risk_low_value", None)))  # fmt: skip
    return out


def choose_action(playbook: policies.RetentionPlaybook, segment: str, top_group: str | None) -> policies.PlaybookAction | None:
    options = [a for a in playbook.actions if a.segment == segment]
    if not options:
        return None
    if segment == "medium_risk_low_value" and top_group == "financial":
        offers = [a for a in options if a.offer]
        if offers:
            return offers[0]
    plain = [a for a in options if not a.offer]
    return (plain or options)[0]


def start_generation(session: Session, principal: Principal, batch_id: int) -> Any:
    batch = get_owned(session, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
    if batch.status != "completed" or batch.kind == "single":
        raise Conflict("recommendations need a completed batch prediction run")
    if batch.kind == "backtest":  # scored after the fact to measure the model: acting on it would mean acting on old data
        raise Conflict("a back-test batch scores a past date for evaluation; recommendations are generated from live scoring batches",
                       code="backtest_batch")  # fmt: skip
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="retention.generate", payload={"batch_id": batch.id},
                       created_by=principal.user_id)  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="retention.generation_started",
                 entity_type="prediction_batch", entity_id=batch.id)  # fmt: skip
    return job


def run_generation(batch_id: int, ctx: Any = None) -> dict:
    with read_session() as rs:
        batch = rs.get(PredictionBatch, batch_id)
        if batch is None:
            raise jobs.PermanentJobError(f"prediction batch {batch_id} does not exist")
        tenant_id, as_of = batch.tenant_id, batch.as_of_date
        preds = rs.execute(select(Prediction).where(Prediction.batch_id == batch_id)).scalars().all()
        if not preds:
            raise jobs.PermanentJobError("the batch has no predictions")
        contract = rs.get(FeatureContract, preds[0].contract_id)
        vectors = features.offline_frame(rs, tenant_id, contract, dates=[as_of])
        if vectors.empty:
            vectors = features.compute_for(tenant_id, list(contract.features), [as_of])
        risk, risk_source = _risk_policy(rs, tenant_id)
        playbook, playbook_source = playbook_for(rs, tenant_id)
        customers = {c.id: c for c in rs.execute(select(Customer).where(Customer.tenant_id == tenant_id)).scalars()}
        owners = dict(rs.execute(select(Account.customer_id, Account.csm_owner).where(Account.tenant_id == tenant_id)).all())
        cooldown_from = utcnow() - timedelta(days=risk.contact_cooldown_days)
        recent = set(rs.execute(select(Intervention.customer_id).where(Intervention.tenant_id == tenant_id,
                                                                       Intervention.delivered_at >= cooldown_from)).scalars())  # fmt: skip
        from . import experiments

        # The uplift model in force steers targeting.  It is scored for this batch's date here, so that a nightly
        # batch never falls back to risk-only targeting just because nobody pressed "score" for the new date.
        uplift_model = experiments.approved_model(rs, tenant_id)
        uplift_segments: dict[int, str] = {}
        uplift_frame, uplift_features = None, []
        if uplift_model is not None:
            uplift_segments = experiments.stored_segments(rs, uplift_model.id, as_of)
            if not uplift_segments:
                uplift_contract = rs.get(FeatureContract, uplift_model.contract_id)
                uplift_features = list(uplift_contract.features)
                uplift_frame = vectors if uplift_contract.id == contract.id else features.offline_frame(rs, tenant_id, uplift_contract, dates=[as_of])
        decided = {r.customer_id for r in rs.execute(select(RetentionRecommendation).where(
            RetentionRecommendation.batch_id == batch_id, RetentionRecommendation.status.in_(("approved", "dismissed", "executed")))).scalars()}  # fmt: skip
        # approved for an earlier scoring date and still waiting to be carried out: that decision stands
        carried = set(rs.execute(select(RetentionRecommendation.customer_id).where(
            RetentionRecommendation.tenant_id == tenant_id, RetentionRecommendation.batch_id != batch_id,
            RetentionRecommendation.status == "approved")).scalars())  # fmt: skip
    missing = [c for c in NEEDED if c not in vectors.columns]
    if missing:
        raise jobs.PermanentJobError(f"the feature contract lacks features needed for tiering: {', '.join(missing)}")
    uplift_scores = None
    if uplift_model is not None and not uplift_segments:
        if uplift_frame is None or uplift_frame.empty:
            uplift_frame = features.compute_for(tenant_id, uplift_features, [as_of])
        try:
            uplift_scores = experiments.compute_scores(uplift_model, uplift_frame)
        except Conflict as exc:  # a modified artefact must stop targeting, not silently switch it off
            raise jobs.PermanentJobError(f"the approved uplift model #{uplift_model.id} cannot be used: {exc.message}") from exc
        uplift_segments = dict(zip(uplift_scores["customer_id"].astype(int), uplift_scores["segment"], strict=True))
    frame = pd.DataFrame([{"prediction_id": p.id, "customer_id": p.customer_id, "probability": p.probability, "risk_tier": p.risk_tier,
                           "top_reasons": p.top_reasons or []} for p in preds])  # fmt: skip
    frame = classify(frame.merge(vectors[["customer_id", *NEEDED]], on="customer_id", how="left"), risk)
    records, uncovered, no_action, carried_over = [], {}, 0, 0
    now = utcnow()
    for row in frame.itertuples(index=False):
        if row.customer_id in decided:
            continue
        if row.customer_id in carried:
            carried_over += 1
            continue
        if row.segment is None:
            why = "low_risk" if row.risk_tier == "low" else f"{row.risk_tier}_risk_high_value"
            uncovered[why] = uncovered.get(why, 0) + 1
            continue
        reasons = list(row.top_reasons)
        group = PLAYBOOK_GROUP.get(reasons[0]["group"]) if reasons else None
        action = choose_action(playbook, row.segment, group)
        if action is None:
            no_action += 1
            continue
        customer = customers[row.customer_id]
        blocked = None
        if action.requires_marketing_consent and customer.consent_marketing is not True:
            blocked = "marketing consent is not recorded for this customer"
        elif row.customer_id in recent:
            blocked = f"contacted within the last {risk.contact_cooldown_days} days (cool-down)"
        uplift_segment = uplift_segments.get(row.customer_id)
        if blocked is None and uplift_segment == "sleeping_dog" and row.segment != "involuntary":
            blocked = "approved uplift model: contacting this customer is predicted to reduce retention (sleeping dog)"
        triggers = [t for t, on in (("payment method expires soon or has expired", row.card_expiring),
                                    ("most recent payment failed", row.payment_failing)) if on]  # fmt: skip
        rationale = {
            "probability": float(row.probability), "risk_tier": row.risk_tier, "mrr": None if pd.isna(row.mrr) else float(row.mrr),
            "value_percentile": float(row.value_percentile), "high_value": bool(row.high_value), "top_reasons": reasons,
            "talking_points": [playbook.reason_plays[g] for g in dict.fromkeys(PLAYBOOK_GROUP.get(r["group"]) for r in reasons)
                               if g in playbook.reason_plays],
            "payment_triggers": triggers, "offer": action.offer, "action_name": action.name, "uplift_segment": uplift_segment,
            "requires_human_review": action.requires_human_review,
            "disclaimer": "Decision support only: the score ranks risk; it does not show that this action will change the outcome.",
        }  # fmt: skip
        records.append({"tenant_id": tenant_id, "customer_id": row.customer_id, "prediction_id": int(row.prediction_id),
                        "batch_id": batch_id, "playbook_policy_id": playbook_source["policy_id"], "segment": row.segment,
                        "action_code": action.code, "channel": action.channel,
                        "priority": 0 if uplift_segment == "persuadable" else PRIORITY[row.segment],
                        "rationale": json_safe(rationale), "status": "blocked" if blocked else "proposed", "blocked_reason": blocked,
                        "eligibility": {"consent_required": action.requires_marketing_consent,
                                        "consent_marketing": customer.consent_marketing, "in_cooldown": row.customer_id in recent},
                        "assigned_to": owners.get(row.customer_id), "created_at": now})  # fmt: skip
    with session_scope() as ws:
        if uplift_scores is not None:
            experiments.store_scores(ws, ws.get(UpliftModel, uplift_model.id), as_of, uplift_scores, automatic=True)
        ws.execute(delete(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id,
                                                         RetentionRecommendation.status.in_(("proposed", "blocked"))))  # fmt: skip
        for start in range(0, len(records), 2000):
            ws.execute(insert(RetentionRecommendation.__table__), records[start : start + 2000])
        by_segment = pd.Series([r["segment"] for r in records]).value_counts().to_dict() if records else {}
        summary = {"created": len(records), "by_segment": {k: int(v) for k, v in by_segment.items()},
                   "blocked": sum(r["status"] == "blocked" for r in records), "not_covered_by_playbook": sum(uncovered.values()),
                   "not_covered_detail": uncovered,
                   "carried_over": carried_over,
                   "no_action_defined": no_action, "risk_policy": risk_source, "playbook": playbook_source,
                   "uplift": {"applied": uplift_model is not None, "model_id": uplift_model.id if uplift_model is not None else None,
                              "scored_for_this_batch": uplift_scores is not None,
                              "note": (f"approved uplift model #{uplift_model.id} applied" if uplift_model is not None
                                       else "no approved uplift model: targeting is by risk and value only")}}  # fmt: skip
        audit.record(ws, tenant_id=tenant_id, action="retention.recommendations_generated", entity_type="prediction_batch",
                     entity_id=batch_id, detail=summary)  # fmt: skip
    return {"batch_id": batch_id, **summary}


def _risk_policy(session: Session, tenant_id: int) -> tuple[policies.RiskPolicy, dict]:
    from .predictions import risk_policy_for

    return risk_policy_for(session, tenant_id)


def review(session: Session, principal: Principal, recommendation_id: int, *, approve: bool, note: str | None = None) -> RetentionRecommendation:
    rec = get_owned(session, RetentionRecommendation, principal.tenant_id, recommendation_id, label="Recommendation")
    withdrawing = rec.status == "approved" and not approve  # approved earlier, not carried out, no longer wanted
    if rec.status != "proposed" and not withdrawing:
        raise Conflict(f"only a proposed recommendation can be reviewed (status: {rec.status})")
    needs_approver = bool((rec.rationale or {}).get("requires_human_review"))
    if approve and needs_approver and not principal.can("retention:approve"):
        raise Forbidden("this action requires approval by a user with the retention:approve permission", code="approval_required")
    rec.status = "approved" if approve else "dismissed"
    rec.reviewed_by, rec.reviewed_at = principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, entity_type="retention_recommendation", entity_id=rec.id,
                 action="retention.recommendation_approved" if approve else "retention.recommendation_dismissed",
                 detail={"customer_id": rec.customer_id, "action_code": rec.action_code, "note": note, "withdrawn": withdrawing})  # fmt: skip
    return rec


def execute(session: Session, principal: Principal, recommendation_id: int, *, connection_id: int | None = None) -> dict:
    """Hand an approved recommendation over for delivery: via the CRM outbox when a connection is
    given, otherwise recorded for manual follow-up.  The platform itself never contacts customers."""
    from . import crm

    rec = get_owned(session, RetentionRecommendation, principal.tenant_id, recommendation_id, label="Recommendation")
    needs_review = bool((rec.rationale or {}).get("requires_human_review"))
    if rec.status == "executed":
        raise Conflict("this recommendation has already been executed")
    if rec.status != "approved" and not (rec.status == "proposed" and not needs_review):
        raise Conflict(f"a recommendation must be approved before execution (status: {rec.status})", code="not_approved")
    delivery = None
    if connection_id is not None:
        connection = get_owned(session, CRMConnection, principal.tenant_id, connection_id, label="CRM connection")
        kind = "task" if rec.channel in ("crm_task", "phone") else "action"
        delivery = crm.enqueue_delivery(session, principal, connection, customer_id=rec.customer_id, kind=kind,
                                        payload=crm.recommendation_payload(session, rec), key=f"rec:{rec.id}")  # fmt: skip
        rec.crm_delivery_id = delivery.id
    intervention = Intervention(tenant_id=rec.tenant_id, customer_id=rec.customer_id, recommendation_id=rec.id, campaign_id=rec.campaign_id,
                                action_code=rec.action_code, channel=rec.channel, delivered_at=utcnow(), created_by=principal.user_id,
                                status="queued_for_crm" if delivery else "recorded",
                                note=None if delivery else "No CRM connection selected: recorded for manual follow-up; nothing was sent.")  # fmt: skip
    session.add(intervention)
    rec.status = "executed"
    if rec.reviewed_by is None:
        rec.reviewed_by, rec.reviewed_at = principal.user_id, utcnow()
    session.flush()
    audit.record(session, tenant_id=rec.tenant_id, actor=principal, action="retention.recommendation_executed",
                 entity_type="retention_recommendation", entity_id=rec.id,
                 detail={"customer_id": rec.customer_id, "intervention_id": intervention.id, "crm_delivery_id": delivery.id if delivery else None})  # fmt: skip
    return {"recommendation": view(rec), "intervention": to_dict(intervention), "crm_delivery_id": delivery.id if delivery else None}


def record_outcome(session: Session, principal: Principal, intervention_id: int, outcome: str, note: str | None = None) -> Intervention:
    item = get_owned(session, Intervention, principal.tenant_id, intervention_id, label="Intervention")
    if outcome not in ("retained", "churned", "unknown"):
        raise ValidationFailed("outcome must be retained, churned or unknown", details={"field": "outcome"})
    item.outcome, item.outcome_at = outcome, utcnow()
    if note:
        item.note = note
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="retention.outcome_recorded",
                 entity_type="intervention", entity_id=item.id, detail={"outcome": outcome})  # fmt: skip
    return item


def view(rec: RetentionRecommendation, customer: Customer | None = None) -> dict:
    out = to_dict(rec)
    if customer is not None:
        out["customer_external_id"], out["customer_name"] = customer.external_id, customer.name
    return out


SCOPES = ("current", "all")


def current_batch(session: Session, tenant_id: int) -> PredictionBatch | None:
    """The newest scoring date for which recommendations exist: today's work queue."""
    return session.execute(
        select(PredictionBatch).where(PredictionBatch.tenant_id == tenant_id, PredictionBatch.id.in_(
            select(RetentionRecommendation.batch_id).where(RetentionRecommendation.tenant_id == tenant_id)))
        .order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip


def _scope_filter(session: Session, tenant_id: int, batch_id: int | None, scope: str) -> tuple[list, dict]:
    """SQL conditions for a view of the recommendations, and a description of that view.

    ``current`` (the default) is the work queue: the newest scoring date, plus anything approved for an earlier
    date that is still waiting to be carried out.  Without it, nightly scoring would bury today's work under
    every proposal ever made.
    """
    if scope not in SCOPES:
        raise ValidationFailed("scope must be current or all", details={"field": "scope"})
    if batch_id is not None:
        batch = get_owned(session, PredictionBatch, tenant_id, batch_id, label="Prediction batch")
        return [RetentionRecommendation.batch_id == batch.id], {"mode": "batch", "batch_id": batch.id, "as_of_date": batch.as_of_date.isoformat()}
    if scope == "all":
        return [], {"mode": "all", "batch_id": None, "as_of_date": None}
    batch = current_batch(session, tenant_id)
    if batch is None:
        return [], {"mode": "current", "batch_id": None, "as_of_date": None}
    return ([(RetentionRecommendation.batch_id == batch.id) | (RetentionRecommendation.status == "approved")],
            {"mode": "current", "batch_id": batch.id, "as_of_date": batch.as_of_date.isoformat()})  # fmt: skip


def listing(session: Session, tenant_id: int, *, batch_id: int | None = None, scope: str = "current", segment: str | None = None,
            status: str | None = None, page: int = 1, page_size: int = 50) -> dict:
    conditions, described = _scope_filter(session, tenant_id, batch_id, scope)
    stmt = select(RetentionRecommendation, Customer).join(Customer, Customer.id == RetentionRecommendation.customer_id).where(
        RetentionRecommendation.tenant_id == tenant_id, *conditions)  # fmt: skip
    if segment:
        stmt = stmt.where(RetentionRecommendation.segment == segment)
    if status:
        stmt = stmt.where(RetentionRecommendation.status == status)
    stmt = stmt.order_by(RetentionRecommendation.priority, RetentionRecommendation.id)
    out = paginate(session, stmt, page=page, page_size=page_size, scalars=False, serializer=lambda r: view(r[0], r[1]))
    out["scope"] = described
    out["summary"] = summary(session, tenant_id, batch_id, scope)
    return out


def summary(session: Session, tenant_id: int, batch_id: int | None = None, scope: str = "current") -> dict:
    from . import experiments

    conditions, _ = _scope_filter(session, tenant_id, batch_id, scope)
    stmt = select(RetentionRecommendation.segment, RetentionRecommendation.status, func.count()).where(
        RetentionRecommendation.tenant_id == tenant_id, *conditions)  # fmt: skip
    rows = session.execute(stmt.group_by(RetentionRecommendation.segment, RetentionRecommendation.status)).all()
    out: dict[str, dict[str, int]] = {}
    for segment, status, n in rows:
        out.setdefault(segment, {})[status] = n
    outcomes = dict(session.execute(select(func.coalesce(Intervention.outcome, "pending"), func.count())
                                    .where(Intervention.tenant_id == tenant_id).group_by(Intervention.outcome)).all())  # fmt: skip
    uplift = experiments.approved_model(session, tenant_id)
    return {"by_segment": out, "interventions_by_outcome": outcomes,
            "uplift_model_in_force": None if uplift is None else {"id": uplift.id, "approved_at": json_safe(uplift.reviewed_at)},
            "note": "Outcome counts are observational. Only a randomised experiment can attribute retention to an action."}  # fmt: skip


FEATURE_GROUPS = {name: PLAYBOOK_GROUP.get(spec.group) for name, spec in feature_engine.SPECS.items()}
