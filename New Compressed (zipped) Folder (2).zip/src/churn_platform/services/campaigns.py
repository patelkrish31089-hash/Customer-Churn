"""Retention campaigns: who gets which sequence of messages, when, and what happened.

A campaign is a list of steps (wait, then send a template on a channel), an eligibility rule and a few controls:
a control group that receives nothing (so the effect can be measured), A/B variants, a cool-down between campaigns
for the same customer, and the frequency caps of the notification service.  A campaign needs approval by a second
person before it can start, starts in dry-run, and can be paused, resumed and cancelled.

A campaign can select customers by the retention segment of their current recommendation.  It then carries out
what the approved playbook decided and nothing else: only recommendations that are cleared (approved, or proposed
for an action that needs no review) are taken, and when a message really leaves, the recommendation is closed and
the action is on record, so that the same action is not handed to the CRM a second time.

The campaigns of the project brief are provided as presets: for the automated tier (medium risk, lower value;
brief 9.2) an e-mail sequence with content and a webinar invitation, and one with a 15 % offer; for involuntary
churn (brief 9.3) a text message and an in-app reminder for a payment card that is about to expire.
"""

from __future__ import annotations

import hashlib
from datetime import timedelta
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import session_scope, utcnow
from ..errors import Conflict, Forbidden, ValidationFailed
from ..models import (
    Account,
    Campaign,
    CampaignEnrollment,
    CampaignStep,
    Customer,
    Intervention,
    NotificationMessage,
    Prediction,
    PredictionBatch,
    RetentionRecommendation,
)
from ..security import Principal
from . import audit, jobs, notify, predictions, retention
from .common import get_owned, to_dict

TIERS = ("high", "medium", "low")
SEGMENTS = ("high_risk_high_value", "medium_risk_low_value", "involuntary")  # the segments of the retention playbook
RULE_KEYS = ("segments", "action_codes", "risk_tiers", "min_probability", "card_expires_within_days")
PRESETS: dict[str, dict[str, Any]] = {
    "automated_tier_drip": {
        "name": "Automated tier: re-engagement e-mails", "segment": "medium_risk_low_value", "action_code": "reengagement_drip", "channel": "email",
        "description": "Brief 9.2 (medium risk, lower value): three e-mails with content and a webinar invitation for the customers "
                       "the playbook put on the re-engagement drip.",
        "offer": None, "requires_consent": True, "eligibility": {"segments": ["medium_risk_low_value"], "action_codes": ["reengagement_drip"]},
        "cooldown_days": 60, "ab_test": {"control_share": 0.1, "variants": {"A": 1.0}},
        "steps": [{"delay_hours": 0, "channel": "email", "template_code": "reengage_content"},
                  {"delay_hours": 72, "channel": "email", "template_code": "reengage_webinar"},
                  {"delay_hours": 168, "channel": "email", "template_code": "reengage_check_in"}],
    },
    "automated_tier_offer": {
        "name": "Automated tier: 15 % offer", "segment": "medium_risk_low_value", "action_code": "retention_discount_offer", "channel": "email",
        "description": "Brief 9.2 (medium risk, lower value): three e-mails with a 15 % offer on the next billing cycle, for the customers "
                       "whose discount recommendation a reviewer approved.",
        "offer": {"offer_percent": 15, "offer_code": "STAY15", "offer_valid_days": 14}, "requires_consent": True,
        "eligibility": {"segments": ["medium_risk_low_value"], "action_codes": ["retention_discount_offer"]},
        "cooldown_days": 60, "ab_test": {"control_share": 0.1, "variants": {"A": 1.0}},
        "steps": [{"delay_hours": 0, "channel": "email", "template_code": "offer_intro"},
                  {"delay_hours": 72, "channel": "email", "template_code": "offer_reminder"},
                  {"delay_hours": 168, "channel": "email", "template_code": "offer_last_call"}],
    },
    "card_expiry_reminder": {
        "name": "Payment card about to expire", "segment": "involuntary", "action_code": "payment_method_reminder", "channel": "sms",
        "description": "Brief 9.3 (involuntary churn): a text message and an in-app reminder for the customers the playbook flagged "
                       "because their card is about to expire, has expired, or a payment failed.",
        "offer": None, "requires_consent": False, "eligibility": {"segments": ["involuntary"]}, "cooldown_days": 25,
        "ab_test": {"control_share": 0.0, "variants": {"A": 1.0}},
        "steps": [{"delay_hours": 0, "channel": "sms", "template_code": "card_expiring"},
                  {"delay_hours": 0, "channel": "in_app", "template_code": "card_expiring"}],
    },
}  # fmt: skip
# Draft texts.  They are starting points: a second person has to approve each before a campaign can use it.
PRESET_TEMPLATES = (
    ("reengage_content", "email", "marketing", "Getting more out of {{product_name}}",
     "Hello {{customer_name}},\n\nYou have been using {{product_name}} less than before. Our short guides show the features that teams like yours "
     "rely on most and how to set each one up in a few minutes. Reply to this e-mail and we will send you the ones that fit your account.\n\n"
     "To stop receiving these e-mails: {{unsubscribe_url}}"),
    ("reengage_webinar", "email", "marketing", "An invitation: {{product_name}} in practice",
     "Hello {{customer_name}},\n\nWe run a short online session in which we show how other teams work with {{product_name}} and answer questions. "
     "Reply to this e-mail and we will send you the next dates.\n\nTo stop receiving these e-mails: {{unsubscribe_url}}"),
    ("reengage_check_in", "email", "marketing", "Is {{product_name}} still doing its job for you?",
     "Hello {{customer_name}},\n\nIf something is in your way, tell us: reply to this e-mail and a person will answer.\n\n"
     "To stop receiving these e-mails: {{unsubscribe_url}}"),
    ("offer_intro", "email", "marketing", "{{customer_name}}: 15% off your next renewal",
     "Hello {{customer_name}},\n\nWe would like to keep working with you. Use code {{offer_code}} for {{offer_percent}}% off your next renewal, "
     "valid until {{offer_valid_until}}.\n\nTo stop receiving offers: {{unsubscribe_url}}"),
    ("offer_reminder", "email", "marketing", "Your {{offer_percent}}% offer is waiting",
     "Hello {{customer_name}},\n\nYour code {{offer_code}} for {{offer_percent}}% off is still valid until {{offer_valid_until}}.\n\n"
     "To stop receiving offers: {{unsubscribe_url}}"),
    ("offer_last_call", "email", "marketing", "Last days for your {{offer_percent}}% offer",
     "Hello {{customer_name}},\n\nCode {{offer_code}} expires on {{offer_valid_until}}.\n\nTo stop receiving offers: {{unsubscribe_url}}"),
    ("card_expiring", "sms", "transactional", None,
     "{{product_name}}, {{customer_name}}: {{payment_issue}}. Update the payment method to avoid an interruption: {{update_payment_url}}"),
    ("card_expiring", "in_app", "transactional", "Your payment method needs attention",
     "{{payment_issue}}. Update the payment method under Billing to avoid an interruption."),
)  # fmt: skip


def campaign_view(session: Session, campaign: Campaign) -> dict:
    steps = session.execute(select(CampaignStep).where(CampaignStep.campaign_id == campaign.id).order_by(CampaignStep.step_index, CampaignStep.variant)).scalars().all()
    counts = dict(session.execute(select(CampaignEnrollment.status, func.count()).where(CampaignEnrollment.campaign_id == campaign.id)
                                  .group_by(CampaignEnrollment.status)).all())  # fmt: skip
    messages = dict(session.execute(select(NotificationMessage.status, func.count()).where(NotificationMessage.campaign_id == campaign.id)
                                    .group_by(NotificationMessage.status)).all())  # fmt: skip
    return to_dict(campaign, include={"steps": [to_dict(s) for s in steps], "enrollments": counts, "messages": messages})


def _steps(steps: Any) -> list[dict]:
    if not isinstance(steps, list) or not 1 <= len(steps) <= 12:
        raise ValidationFailed("a campaign has between 1 and 12 steps", details={"field": "steps"})
    cleaned = []
    for n, step in enumerate(steps):
        if not isinstance(step, dict) or step.get("channel") not in notify.CHANNELS or not str(step.get("template_code") or "").strip():
            raise ValidationFailed(f"step {n + 1} needs a channel ({', '.join(notify.CHANNELS)}) and a template_code", details={"field": "steps"})
        delay = step.get("delay_hours", 0)
        if not isinstance(delay, int | float) or isinstance(delay, bool) or not 0 <= delay <= 24 * 90:
            raise ValidationFailed(f"step {n + 1}: delay_hours must be between 0 and 2160", details={"field": "steps"})
        cleaned.append({"delay_hours": float(delay), "channel": step["channel"], "template_code": str(step["template_code"]).strip().lower(),
                        "variant": str(step.get("variant") or "A")[:20]})  # fmt: skip
    return cleaned


def _eligibility(rule: Any) -> dict:
    rule = rule or {}
    if not isinstance(rule, dict) or set(rule) - set(RULE_KEYS):
        raise ValidationFailed(f"eligibility may contain: {', '.join(RULE_KEYS)}", details={"field": "eligibility"})
    if "segments" in rule and (not isinstance(rule["segments"], list) or not rule["segments"] or any(x not in SEGMENTS for x in rule["segments"])):
        raise ValidationFailed(f"segments is a list of: {', '.join(SEGMENTS)}", details={"field": "eligibility"})
    if "action_codes" in rule:
        codes = rule["action_codes"]
        if "segments" not in rule:
            raise ValidationFailed("action_codes narrows a selection by segments; give segments as well", details={"field": "eligibility"})
        if not isinstance(codes, list) or not codes or any(not isinstance(x, str) or not x.strip() for x in codes):
            raise ValidationFailed("action_codes is a list of action codes of the retention playbook", details={"field": "eligibility"})
    if "risk_tiers" in rule and (not isinstance(rule["risk_tiers"], list) or any(t not in TIERS for t in rule["risk_tiers"]) or not rule["risk_tiers"]):
        raise ValidationFailed(f"risk_tiers is a list of: {', '.join(TIERS)}", details={"field": "eligibility"})
    if "min_probability" in rule and not (isinstance(rule["min_probability"], int | float) and 0 <= rule["min_probability"] <= 1):
        raise ValidationFailed("min_probability must be between 0 and 1", details={"field": "eligibility"})
    if "card_expires_within_days" in rule and not (isinstance(rule["card_expires_within_days"], int) and 1 <= rule["card_expires_within_days"] <= 365):
        raise ValidationFailed("card_expires_within_days must be a whole number from 1 to 365", details={"field": "eligibility"})
    if not rule:
        raise ValidationFailed("a campaign needs an eligibility rule: it may not address every customer by default", details={"field": "eligibility"})
    return rule


def _ab(ab_test: Any) -> dict:
    ab_test = ab_test or {"control_share": 0.0, "variants": {"A": 1.0}}
    share, variants = ab_test.get("control_share", 0.0), ab_test.get("variants") or {"A": 1.0}
    if not isinstance(share, int | float) or not 0 <= share <= 0.5:
        raise ValidationFailed("control_share must be between 0 and 0.5", details={"field": "ab_test"})
    if not isinstance(variants, dict) or not variants or any(not isinstance(w, int | float) or w <= 0 for w in variants.values()):
        raise ValidationFailed("variants maps a variant name to a positive weight", details={"field": "ab_test"})
    return {"control_share": float(share), "variants": {str(k)[:20]: float(v) for k, v in variants.items()}}


def create(session: Session, principal: Principal, payload: dict) -> Campaign:
    name = str(payload.get("name") or "").strip()
    if not name:
        raise ValidationFailed("a name is required", details={"field": "name"})
    steps, eligibility, ab_test = _steps(payload.get("steps")), _eligibility(payload.get("eligibility")), _ab(payload.get("ab_test"))
    unknown = {s["variant"] for s in steps} - set(ab_test["variants"])
    if unknown:
        raise ValidationFailed(f"steps name variant(s) that the A/B test does not define: {', '.join(sorted(unknown))}", details={"field": "steps"})
    if session.execute(select(Campaign.id).where(Campaign.tenant_id == principal.tenant_id, Campaign.name == name[:200])).first():
        raise Conflict("a campaign with this name already exists", code="name_taken")
    cooldown = payload.get("cooldown_days", 30)
    if not isinstance(cooldown, int) or isinstance(cooldown, bool) or not 0 <= cooldown <= 365:
        raise ValidationFailed("cooldown_days must be between 0 and 365", details={"field": "cooldown_days"})
    campaign = Campaign(tenant_id=principal.tenant_id, name=name[:200], segment=str(payload.get("segment") or "custom")[:60],
                        action_code=str(payload.get("action_code") or "message")[:60], channel=steps[0]["channel"], offer=payload.get("offer"),
                        requires_consent=bool(payload.get("requires_consent", True)), status="draft", run_state="idle", dry_run=True,
                        description=payload.get("description"), eligibility=eligibility, cooldown_days=cooldown, ab_test=ab_test,
                        created_by=principal.user_id)  # fmt: skip
    session.add(campaign)
    session.flush()
    for index, step in enumerate(steps):
        session.add(CampaignStep(tenant_id=principal.tenant_id, campaign_id=campaign.id, step_index=index, **step))
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="campaign.drafted", entity_type="campaign", entity_id=campaign.id,
                 detail={"name": campaign.name, "steps": len(steps)})  # fmt: skip
    return campaign


def create_preset(session: Session, principal: Principal, preset: str) -> Campaign:
    """One of the brief's campaigns, as a draft, with draft templates for every step that has none yet."""
    if preset not in PRESETS:
        raise ValidationFailed(f"preset must be one of: {', '.join(PRESETS)}", details={"field": "preset"})
    from ..models import NotificationTemplate

    needed = {(s["template_code"], s["channel"]) for s in PRESETS[preset]["steps"]}
    for code, channel, category, subject, body in PRESET_TEMPLATES:
        if (code, channel) in needed and not session.execute(select(NotificationTemplate.id).where(
                NotificationTemplate.tenant_id == principal.tenant_id, NotificationTemplate.code == code, NotificationTemplate.channel == channel)).first():  # fmt: skip
            notify.create_template(session, principal, code=code, channel=channel, subject=subject, body=body, category=category)
    values = dict(PRESETS[preset])
    taken = set(session.execute(select(Campaign.name).where(Campaign.tenant_id == principal.tenant_id, Campaign.name.like(values["name"] + "%"))).scalars())
    number = 2
    while values["name"] in taken:  # the preset can be used again: "... (2)", "... (3)"
        values["name"] = f"{PRESETS[preset]['name']} ({number})"
        number += 1
    return create(session, principal, values)


def submit(session: Session, principal: Principal, campaign_id: int) -> Campaign:
    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    if campaign.status != "draft":
        raise Conflict(f"only a draft can be submitted (this campaign is {campaign.status})")
    steps = session.execute(select(CampaignStep).where(CampaignStep.campaign_id == campaign.id)).scalars().all()
    missing = sorted({f"{s.template_code} ({s.channel})" for s in steps if notify.approved_template(session, campaign.tenant_id, s.template_code, s.channel) is None})
    if missing:
        raise Conflict("these templates are not approved yet: " + ", ".join(missing), code="template_not_approved", details=missing)
    campaign.status, campaign.submitted_at = "pending", utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="campaign.submitted", entity_type="campaign", entity_id=campaign.id)
    return campaign


def review(session: Session, principal: Principal, campaign_id: int, *, approve: bool, note: str | None = None) -> Campaign:
    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    if campaign.status != "pending":
        raise Conflict(f"only a submitted campaign can be reviewed (this campaign is {campaign.status})")
    if campaign.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a campaign cannot be reviewed by the person who wrote it", code="self_approval_forbidden")
    campaign.status, campaign.reviewed_by, campaign.reviewed_at, campaign.review_note = "approved" if approve else "rejected", principal.user_id, utcnow(), note
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="campaign.approved" if approve else "campaign.rejected",
                 entity_type="campaign", entity_id=campaign.id, detail={"note": note})  # fmt: skip
    return campaign


# ----------------------------------------------------------------------------- who is eligible
def eligible_customers(session: Session, campaign: Campaign) -> tuple[list[dict], dict]:
    """Customers that match the campaign's rule today, with why each was picked, and counts of who was left out.

    Every key of the rule narrows the selection.  ``segments`` reads the retention recommendations of the newest
    scoring date - the approved playbook's decision on who gets which action - and takes only the ones that are
    cleared to be carried out: approved, or proposed for an action that needs no review (the rule the work queue
    itself applies).  A campaign never overrides a recommendation the playbook blocked, one that waits for a
    reviewer, or one somebody dismissed; one that was carried out already is not carried out again.
    """
    rule, now = campaign.eligibility or {}, utcnow()
    info: dict[str, Any] = {"rule": rule}
    selected: dict[int, dict] | None = None

    def narrow(found: dict[int, dict]) -> None:
        nonlocal selected
        selected = found if selected is None else {k: {**selected[k], **v} for k, v in found.items() if k in selected}

    if "segments" in rule:
        current = retention.current_batch(session, campaign.tenant_id)
        if current is None:
            raise Conflict("there are no retention recommendations yet: run the recommendation step before starting a campaign that selects by segment",
                           code="no_recommendations")  # fmt: skip
        stmt = select(RetentionRecommendation).where(RetentionRecommendation.tenant_id == campaign.tenant_id, RetentionRecommendation.batch_id == current.id,
                                                    RetentionRecommendation.segment.in_(rule["segments"]))  # fmt: skip
        if rule.get("action_codes"):
            stmt = stmt.where(RetentionRecommendation.action_code.in_(rule["action_codes"]))
        cleared: dict[int, dict] = {}
        left_out = {"blocked_by_playbook": 0, "waiting_for_review": 0, "dismissed": 0, "already_carried_out": 0}
        for rec in session.execute(stmt.order_by(RetentionRecommendation.id)).scalars():
            needs_review = bool((rec.rationale or {}).get("requires_human_review"))
            if rec.status == "approved" or (rec.status == "proposed" and not needs_review):
                cleared[rec.customer_id] = {"recommendation_id": rec.id, "segment": rec.segment, "action_code": rec.action_code, "batch_id": current.id}
                if rec.segment == "involuntary":
                    cleared[rec.customer_id]["payment_triggers"] = (rec.rationale or {}).get("payment_triggers") or []
            else:
                left_out[{"blocked": "blocked_by_playbook", "proposed": "waiting_for_review", "dismissed": "dismissed"}.get(rec.status, "already_carried_out")] += 1
        info["recommendations"] = {"batch_id": current.id, "as_of_date": current.as_of_date.isoformat(), "cleared": len(cleared), "left_out": left_out}
        narrow(cleared)
    if "risk_tiers" in rule or "min_probability" in rule:
        batch = session.execute(select(PredictionBatch).where(PredictionBatch.tenant_id == campaign.tenant_id, PredictionBatch.status == "completed")
                                .order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
        if batch is None:
            raise Conflict("there are no risk scores yet: score the customers before starting a campaign that selects by risk", code="no_scores")
        stmt = select(Prediction.customer_id, Prediction.probability, Prediction.risk_tier).where(Prediction.batch_id == batch.id)
        if "risk_tiers" in rule:
            stmt = stmt.where(Prediction.risk_tier.in_(rule["risk_tiers"]))
        if "min_probability" in rule:
            stmt = stmt.where(Prediction.probability >= rule["min_probability"])
        narrow({customer_id: {"probability": round(float(probability), 4), "risk_tier": tier, "batch_id": batch.id}
                for customer_id, probability, tier in session.execute(stmt)})  # fmt: skip
        info["score_batch"] = {"id": batch.id, "as_of_date": batch.as_of_date.isoformat()}
    if "card_expires_within_days" in rule:
        today = now.date()
        horizon = today + timedelta(days=rule["card_expires_within_days"])
        narrow({customer_id: {"card_expiry_date": expires.isoformat(), "days_left": (expires - today).days} for customer_id, expires in session.execute(
            select(Account.customer_id, Account.payment_method_expires_on).where(
                Account.tenant_id == campaign.tenant_id, Account.payment_method_expires_on.is_not(None), Account.payment_method_expires_on >= today,
                Account.payment_method_expires_on <= horizon, Account.status != "closed"))})  # fmt: skip
    candidates = selected or {}
    _payment_details(session, campaign.tenant_id, candidates, now.date())
    excluded = {"already_enrolled": 0, "in_cooldown": 0, "no_marketing_consent": 0}
    enrolled = set(session.execute(select(CampaignEnrollment.customer_id).where(CampaignEnrollment.campaign_id == campaign.id)).scalars())
    cooling: set[int] = set()
    if campaign.cooldown_days:
        cooling = set(session.execute(select(CampaignEnrollment.customer_id).join(Campaign, Campaign.id == CampaignEnrollment.campaign_id).where(
            CampaignEnrollment.tenant_id == campaign.tenant_id, CampaignEnrollment.campaign_id != campaign.id, Campaign.segment == campaign.segment,
            # the control group is held back too: contacting it soon after would spoil the comparison it exists for
            CampaignEnrollment.status.in_(("active", "completed", "control")), CampaignEnrollment.enrolled_at >= now - timedelta(days=campaign.cooldown_days))).scalars())  # fmt: skip
    consent = dict(session.execute(select(Customer.id, Customer.consent_marketing).where(Customer.tenant_id == campaign.tenant_id, Customer.id.in_(list(candidates) or [0]))).all())
    picked = []
    for customer_id, source in sorted(candidates.items()):
        if customer_id in enrolled:
            excluded["already_enrolled"] += 1
        elif customer_id in cooling:
            excluded["in_cooldown"] += 1
        elif campaign.requires_consent and consent.get(customer_id) is not True:
            excluded["no_marketing_consent"] += 1
        else:
            picked.append({"customer_id": customer_id, "source": source})
    info.update({"matched": len(candidates), "eligible": len(picked), "excluded": excluded})
    return picked, info


def _payment_details(session: Session, tenant_id: int, candidates: dict[int, dict], today: Any) -> None:
    """What a payment reminder may say to each customer (``payment_issue``): the expiry date of the card on file where
    that is why the customer was picked, otherwise that a payment failed.  Nothing is claimed that is not on record."""
    flagged = [customer_id for customer_id, source in candidates.items() if source.get("segment") == "involuntary" and "card_expiry_date" not in source]
    for start in range(0, len(flagged), 500):
        for customer_id, expires in session.execute(select(Account.customer_id, func.min(Account.payment_method_expires_on)).where(
                Account.tenant_id == tenant_id, Account.customer_id.in_(flagged[start : start + 500]), Account.payment_method_expires_on.is_not(None),
                Account.status != "closed").group_by(Account.customer_id)):  # fmt: skip
            candidates[customer_id].update({"card_expiry_date": expires.isoformat(), "days_left": (expires - today).days})
    for source in candidates.values():
        triggers = source.get("payment_triggers")
        about_the_card = triggers is None or any("expire" in trigger for trigger in triggers)
        if about_the_card and source.get("card_expiry_date"):
            source["payment_issue"] = f"The payment card on file {'expired' if source['days_left'] < 0 else 'expires'} on {source['card_expiry_date']}"
        elif triggers and any("failed" in trigger for trigger in triggers):
            source["payment_issue"] = "The latest payment did not go through"
        # otherwise nothing is on record to say: the message is held back for a missing value, and says so


def _assign(campaign: Campaign, customer_id: int) -> tuple[str, str]:
    """``(status, variant)`` for a newly enrolled customer: control or one of the variants, decided by a hash of
    the campaign and the customer (stable, and independent of the order of enrolment)."""
    ab_test = campaign.ab_test or {"control_share": 0.0, "variants": {"A": 1.0}}
    draw = int(hashlib.sha256(f"campaign:{campaign.id}:customer:{customer_id}".encode()).hexdigest()[:12], 16) / 16**12
    if draw < ab_test["control_share"]:
        return "control", "control"
    position, total = (draw - ab_test["control_share"]) / (1 - ab_test["control_share"]), sum(ab_test["variants"].values())
    cumulative = 0.0
    for name, weight in ab_test["variants"].items():
        cumulative += weight / total
        if position < cumulative:
            return "active", name
    return "active", list(ab_test["variants"])[-1]


def preview(session: Session, principal: Principal, campaign_id: int) -> dict:
    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    picked, info = eligible_customers(session, campaign)
    groups: dict[str, int] = {}
    for item in picked:
        _status, variant = _assign(campaign, item["customer_id"])
        groups[variant] = groups.get(variant, 0) + 1
    return {**info, "groups": groups, "dry_run": campaign.dry_run}


def start(session: Session, principal: Principal, campaign_id: int, *, dry_run: bool = True) -> dict:
    """Enrol the eligible customers and begin.  ``dry_run`` (the default) runs the whole campaign with every message
    built and checked and none sent, whatever mode the providers are in."""
    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    if campaign.status not in ("approved", "running"):
        raise Conflict("only an approved campaign can be started", code="campaign_not_approved")
    if campaign.run_state in ("cancelled", "completed"):
        raise Conflict(f"this campaign is {campaign.run_state}; create a new one")
    picked, info = eligible_customers(session, campaign)
    now = utcnow()
    campaign.dry_run, campaign.status, campaign.run_state, campaign.started_at = dry_run, "running", "running", campaign.started_at or now
    first = session.execute(select(CampaignStep.delay_hours).where(CampaignStep.campaign_id == campaign.id, CampaignStep.step_index == 0).limit(1)).scalar() or 0.0
    groups: dict[str, int] = {}
    for item in picked:
        status, variant = _assign(campaign, item["customer_id"])
        groups[variant] = groups.get(variant, 0) + 1
        session.add(CampaignEnrollment(tenant_id=campaign.tenant_id, campaign_id=campaign.id, customer_id=item["customer_id"], variant=variant, status=status,
                                       current_step=0, next_step_at=now + timedelta(hours=first) if status == "active" else None, source=item["source"],
                                       status_reason="control group: receives nothing, so that the campaign's effect can be measured" if status == "control" else None))  # fmt: skip
    session.flush()
    job = jobs.enqueue(session, tenant_id=campaign.tenant_id, job_type="campaign.tick", payload={"campaign_id": campaign.id}, created_by=principal.user_id)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="campaign.started", entity_type="campaign", entity_id=campaign.id,
                 detail={"dry_run": dry_run, "enrolled": len(picked), "groups": groups, "excluded": info["excluded"]})  # fmt: skip
    return {"campaign": campaign_view(session, campaign), "enrolled": len(picked), "groups": groups, "excluded": info["excluded"], "job_id": job.id}


def set_run_state(session: Session, principal: Principal, campaign_id: int, action: str) -> Campaign:
    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    allowed = {"pause": ("running", "paused"), "resume": ("paused", "running"), "cancel": (None, "cancelled")}
    if action not in allowed:
        raise ValidationFailed("action must be pause, resume or cancel", details={"field": "action"})
    needed, target = allowed[action]
    if (needed is not None and campaign.run_state != needed) or (action == "cancel" and campaign.run_state not in ("running", "paused", "scheduled")):
        raise Conflict(f"a campaign that is {campaign.run_state} cannot be {action}d")
    campaign.run_state = target
    now = utcnow()
    if action == "pause":
        campaign.paused_at = now
    elif action == "cancel":
        campaign.finished_at, campaign.status = now, "completed"
        for enrollment in session.execute(select(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign.id, CampaignEnrollment.status == "active")).scalars():
            enrollment.status, enrollment.status_reason, enrollment.completed_at, enrollment.next_step_at = "cancelled", "campaign cancelled", now, None
    else:
        jobs.enqueue(session, tenant_id=campaign.tenant_id, job_type="campaign.tick", payload={"campaign_id": campaign.id}, created_by=principal.user_id)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action=f"campaign.{action}d" if action != "cancel" else "campaign.cancelled",
                 entity_type="campaign", entity_id=campaign.id)  # fmt: skip
    return campaign


# ----------------------------------------------------------------------------- running
def _carried_out(session: Session, campaign: Campaign, enrollment: CampaignEnrollment, channel: str, message: NotificationMessage) -> None:
    """A message really left for a customer whose recommendation this campaign carries out.  The action goes on
    record and the recommendation is closed - once: nobody hands the same action to the CRM afterwards.  (Like a
    hand-over to the CRM, this records that the message was handed to the provider; whether it arrived is the
    message's own state.)  A dry run never gets here."""
    rec = session.get(RetentionRecommendation, (enrollment.source or {}).get("recommendation_id") or 0)
    if rec is None or rec.tenant_id != campaign.tenant_id or rec.status not in ("proposed", "approved"):
        return
    now = utcnow()
    intervention = Intervention(tenant_id=rec.tenant_id, customer_id=rec.customer_id, recommendation_id=rec.id, campaign_id=campaign.id,
                                action_code=rec.action_code, channel=channel, delivered_at=now, created_by=campaign.created_by, status="sent_by_campaign",
                                note=f"Message {message.id} of the campaign '{campaign.name}' was handed to the provider; "
                                     "whether it arrived is shown on the Messages screen.")  # fmt: skip
    session.add(intervention)
    rec.status, rec.campaign_id = "executed", campaign.id
    if rec.reviewed_by is None:
        rec.reviewed_by, rec.reviewed_at = campaign.reviewed_by, now
    session.flush()
    audit.record(session, tenant_id=rec.tenant_id, action="retention.recommendation_executed", entity_type="retention_recommendation", entity_id=rec.id,
                 detail={"customer_id": rec.customer_id, "intervention_id": intervention.id, "campaign_id": campaign.id, "message_id": message.id})  # fmt: skip


def tick(campaign_id: int, ctx: Any = None) -> dict:
    """Send every step that is due, then come back when the next one is.  Safe to run twice: a step's message has an
    idempotency key of its own."""
    sent = waiting = 0
    with session_scope() as ws:
        campaign = ws.get(Campaign, campaign_id)
        if campaign is None:
            raise jobs.PermanentJobError(f"campaign {campaign_id} does not exist")
        if campaign.run_state != "running":
            return {"state": campaign.run_state, "skipped": "the campaign is not running"}
        now = utcnow()
        steps: dict[tuple[int, str], CampaignStep] = {}
        for step in ws.execute(select(CampaignStep).where(CampaignStep.campaign_id == campaign.id)).scalars():
            steps[(step.step_index, step.variant)] = step
        last_index = max(index for index, _variant in steps)
        offer = campaign.offer or {}
        for _round in range(13):  # a step without a delay goes out in the same tick as the step before it
            due = ws.execute(select(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign.id, CampaignEnrollment.status == "active",
                                                              CampaignEnrollment.next_step_at <= now).order_by(CampaignEnrollment.id).limit(2000)).scalars().all()  # fmt: skip
            if not due:
                break
            for enrollment in due:
                step = steps.get((enrollment.current_step, enrollment.variant)) or steps.get((enrollment.current_step, "A"))
                if step is None:
                    enrollment.status, enrollment.completed_at, enrollment.next_step_at = "completed", now, None
                    continue
                source = enrollment.source or {}
                variables = {"offer_percent": offer.get("offer_percent"), "offer_code": offer.get("offer_code"),
                             "offer_valid_until": (enrollment.enrolled_at + timedelta(days=int(offer.get("offer_valid_days", 14)))).date().isoformat() if offer else None,
                             "card_expiry_date": source.get("card_expiry_date"), "days_left": source.get("days_left"), "payment_issue": source.get("payment_issue"),
                             "update_payment_url": (get_settings().public_base_url or "https://example.invalid").rstrip("/") + "/billing"}  # fmt: skip
                key = f"campaign:{campaign.id}:enrollment:{enrollment.id}:step:{enrollment.current_step}"
                message = notify.send(ws, tenant_id=campaign.tenant_id, customer_id=enrollment.customer_id, channel=step.channel, template_code=step.template_code,
                                      variables={k: v for k, v in variables.items() if v is not None}, idempotency_key=key, campaign_id=campaign.id,
                                      enrollment_id=enrollment.id, step_index=enrollment.current_step, variant=enrollment.variant, created_by=campaign.created_by,
                                      dry_run=campaign.dry_run)  # fmt: skip
                sent += 1
                if not message.is_dry_run and message.status in ("queued", "sent", "delivered"):
                    _carried_out(ws, campaign, enrollment, step.channel, message)
                outcome = dict(enrollment.outcome or {})
                outcome[f"step_{enrollment.current_step}"] = {"message_id": message.id, "status": message.status, "reason": message.status_reason}
                enrollment.outcome = outcome
                if message.status == "suppressed" or (message.status == "blocked" and "opted out" in (message.status_reason or "")):
                    enrollment.status, enrollment.status_reason, enrollment.completed_at, enrollment.next_step_at = "suppressed", message.status_reason, now, None
                    continue
                if enrollment.current_step >= last_index:
                    enrollment.status, enrollment.completed_at, enrollment.next_step_at = "completed", now, None
                else:
                    enrollment.current_step += 1
                    following = steps.get((enrollment.current_step, enrollment.variant)) or steps.get((enrollment.current_step, "A"))
                    enrollment.next_step_at = now + timedelta(hours=following.delay_hours if following else 0)
        ws.flush()
        waiting = ws.execute(select(func.count()).select_from(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign.id,
                                                                                         CampaignEnrollment.status == "active")).scalar_one()  # fmt: skip
        next_at = ws.execute(select(func.min(CampaignEnrollment.next_step_at)).where(CampaignEnrollment.campaign_id == campaign.id,
                                                                                      CampaignEnrollment.status == "active")).scalar()  # fmt: skip
        if waiting == 0:
            campaign.run_state, campaign.status, campaign.finished_at = "completed", "completed", now
            audit.record(ws, tenant_id=campaign.tenant_id, action="campaign.completed", entity_type="campaign", entity_id=campaign.id, detail={"dry_run": campaign.dry_run})
        else:
            run_after = max(next_at, now + timedelta(seconds=1))
            jobs.enqueue(ws, tenant_id=campaign.tenant_id, job_type="campaign.tick", payload={"campaign_id": campaign.id}, run_after=run_after,
                         idempotency_key=f"campaign.tick:{campaign.id}:{int(run_after.timestamp())}")  # fmt: skip
        return {"state": campaign.run_state, "steps_processed": sent, "still_enrolled": waiting, "next_step_at": next_at.isoformat() if next_at and waiting else None}


def results(session: Session, principal: Principal, campaign_id: int) -> dict:
    """What happened, by group.  The retention outcome of each group is read from the newest churn labels and is
    only as good as they are; a dry run sent nothing, so it has no effect to measure."""
    from ..models import ChurnLabel

    campaign = get_owned(session, Campaign, principal.tenant_id, campaign_id, label="Campaign")
    enrollments = session.execute(select(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign.id)).scalars().all()
    by_group: dict[str, dict[str, Any]] = {}
    for enrollment in enrollments:
        group = by_group.setdefault(enrollment.variant, {"customers": 0, "by_status": {}, "customer_ids": []})
        group["customers"] += 1
        group["by_status"][enrollment.status] = group["by_status"].get(enrollment.status, 0) + 1
        group["customer_ids"].append(enrollment.customer_id)
    messages = session.execute(select(NotificationMessage.variant, NotificationMessage.status, func.count()).where(NotificationMessage.campaign_id == campaign.id)
                               .group_by(NotificationMessage.variant, NotificationMessage.status)).all()  # fmt: skip
    for variant, status, count in messages:
        by_group.setdefault(variant or "A", {"customers": 0, "by_status": {}, "customer_ids": []}).setdefault("messages", {})[status] = count
    start_date = campaign.started_at.date() if campaign.started_at else None
    for group in by_group.values():
        ids = group.pop("customer_ids")
        group["churned_after_start"] = None
        if ids and start_date is not None:
            base = (ChurnLabel.tenant_id == campaign.tenant_id, ChurnLabel.customer_id.in_(ids), ChurnLabel.as_of_date >= start_date, ChurnLabel.label.is_not(None))
            labelled = session.execute(select(func.count(func.distinct(ChurnLabel.customer_id))).where(*base)).scalar_one()
            churned = session.execute(select(func.count(func.distinct(ChurnLabel.customer_id))).where(*base, ChurnLabel.label == 1)).scalar_one()
            if labelled:
                group["churned_after_start"] = {"labelled_customers": int(labelled), "churned": int(churned)}
    return {"campaign": campaign_view(session, campaign), "groups": by_group,
            "effect": "not measurable: this campaign ran as a dry run, so no customer received anything" if campaign.dry_run
            else "compare churn in the control group with the other groups once labels for dates after the start exist",
            "as_of": predictions.default_as_of(session, campaign.tenant_id).isoformat()}  # fmt: skip


def list_campaigns(session: Session, tenant_id: int) -> list[dict]:
    rows = session.execute(select(Campaign).where(Campaign.tenant_id == tenant_id).order_by(Campaign.id.desc())).scalars().all()
    return [campaign_view(session, c) for c in rows]


def enrollments_query(tenant_id: int, campaign_id: int):  # type: ignore[no-untyped-def]
    return (select(CampaignEnrollment, Customer.external_id, Customer.name).join(Customer, Customer.id == CampaignEnrollment.customer_id)
            .where(CampaignEnrollment.tenant_id == tenant_id, CampaignEnrollment.campaign_id == campaign_id).order_by(CampaignEnrollment.id))  # fmt: skip


def enrollment_view(row: Any) -> dict:
    enrollment, external_id, name = row
    return to_dict(enrollment, include={"customer_external_id": external_id, "customer_name": name})
