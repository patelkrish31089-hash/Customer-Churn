"""Single sign-on with OpenID Connect (authorization-code flow with PKCE).

What is checked, in order, when a user comes back from the identity provider:
  * the ``state`` belongs to a login this installation started, was not used before, has not expired, and comes
    back in the browser that started it (a binding cookie; stops login CSRF and session fixation);
  * the authorization code is exchanged at the provider's token endpoint with the PKCE verifier;
  * the ID token is signed by a key from the provider's published key set, with an asymmetric algorithm
    (RS256 / ES256 - ``none`` and shared-secret algorithms are refused), and its issuer, audience, expiry,
    issue time and nonce are the expected ones;
  * the e-mail is verified and, when domains are configured, in an allowed domain;
  * the person maps to a user of the provider's tenant and to a role.

Secrets (client secret, PKCE verifier, the ID token, the session token on its way to the browser) are stored
encrypted; state, nonce and the one-time exchange code are stored as hashes.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
from datetime import timedelta
from typing import Any
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import netguard
from ..config import get_settings
from ..db import utcnow
from ..errors import Conflict, ExternalServiceError, Forbidden, NotFound, Unauthorized, ValidationFailed
from ..models import AuthSession, IdentityProvider, OidcLoginState, Tenant, User
from ..security import ROLES, Principal, SecretBox, hash_token, new_token
from . import audit
from .common import get_owned, to_dict

ALGORITHMS = ("RS256", "ES256")
STATE_TTL = timedelta(minutes=10)
EXCHANGE_TTL = timedelta(seconds=90)
CACHE_TTL = timedelta(hours=1)
LEEWAY_SECONDS = 60
MFA_METHODS = {"mfa", "otp", "hwk", "swk", "fpt", "sms", "pin"}
_transport: httpx.BaseTransport | None = None  # tests put a fake identity provider here


def set_transport(transport: httpx.BaseTransport | None) -> None:
    global _transport
    _transport = transport


class LoginRefused(Unauthorized):
    """A sign-in that reached the platform and was turned down; the reason is safe to show."""


# ----------------------------------------------------------------------------- small JOSE helpers
def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def b64url_decode(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _public_key(jwk: dict) -> Any:
    from cryptography.hazmat.primitives.asymmetric import ec, rsa

    number = lambda name: int.from_bytes(b64url_decode(jwk[name]), "big")  # noqa: E731
    if jwk.get("kty") == "RSA":
        return rsa.RSAPublicNumbers(number("e"), number("n")).public_key()
    if jwk.get("kty") == "EC" and jwk.get("crv") == "P-256":
        return ec.EllipticCurvePublicNumbers(number("x"), number("y"), ec.SECP256R1()).public_key()
    raise LoginRefused("the identity provider's signing key has a type this platform does not accept", code="sso_key_unsupported")


def verify_jws(token: str, keys: list[dict]) -> tuple[dict, dict]:
    """Verify a compact JWS against a key set.  Returns (header, claims) or raises ``LoginRefused``."""
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import ec, padding
    from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

    try:
        head64, body64, sig64 = token.split(".")
        header, claims, signature = json.loads(b64url_decode(head64)), json.loads(b64url_decode(body64)), b64url_decode(sig64)
    except (ValueError, json.JSONDecodeError) as exc:
        raise LoginRefused("the identity provider returned a token that cannot be read", code="sso_token_malformed") from exc
    algorithm = header.get("alg")
    if algorithm not in ALGORITHMS:
        raise LoginRefused(f"the ID token is signed with '{algorithm}', which is not accepted (only {', '.join(ALGORITHMS)})", code="sso_algorithm_refused")
    kid = header.get("kid")
    candidates = [k for k in keys if (kid is None or k.get("kid") == kid) and k.get("use", "sig") == "sig"
                  and k.get("kty") == ("RSA" if algorithm == "RS256" else "EC")]  # fmt: skip
    if not candidates:
        raise LoginRefused("the ID token was signed with a key the identity provider does not publish", code="sso_key_unknown")
    signed = f"{head64}.{body64}".encode()
    for jwk in candidates:
        key = _public_key(jwk)
        try:
            if algorithm == "RS256":
                key.verify(signature, signed, padding.PKCS1v15(), hashes.SHA256())
            else:
                if len(signature) != 64:
                    raise InvalidSignature
                r, s = int.from_bytes(signature[:32], "big"), int.from_bytes(signature[32:], "big")
                key.verify(encode_dss_signature(r, s), signed, ec.ECDSA(hashes.SHA256()))
            return header, claims
        except InvalidSignature:
            continue
    raise LoginRefused("the signature of the ID token is not valid", code="sso_signature_invalid")


# ----------------------------------------------------------------------------- provider configuration
def provider_view(provider: IdentityProvider) -> dict:
    view = to_dict(provider, exclude={"metadata_cache", "jwks_cache"})
    view["has_client_secret"] = bool(provider.client_secret_enc)
    view["endpoints"] = {k: (provider.metadata_cache or {}).get(k) for k in ("authorization_endpoint", "token_endpoint", "jwks_uri")}
    view["signing_keys_cached"] = len((provider.jwks_cache or {}).get("keys", []))
    return view


def _clean(values: dict, *, partial: bool = False) -> dict:
    out: dict[str, Any] = {}
    settings = get_settings()
    if "issuer" in values or not partial:
        issuer = str(values.get("issuer") or "").strip().rstrip("/")
        if not issuer.startswith("https://") and not (settings.oidc_allow_insecure_http and issuer.startswith("http://")):
            raise ValidationFailed("the issuer must be an https:// URL", details={"field": "issuer"})
        out["issuer"] = issuer
    for field in ("name", "client_id"):
        if field in values or not partial:
            text = str(values.get(field) or "").strip()
            if not text:
                raise ValidationFailed(f"{field} is required", details={"field": field})
            out[field] = text
    if values.get("scopes") is not None:
        scopes = str(values["scopes"]).split()
        if "openid" not in scopes:
            raise ValidationFailed("scopes must include 'openid'", details={"field": "scopes"})
        out["scopes"] = " ".join(scopes)
    if values.get("role_claim") is not None:
        out["role_claim"] = str(values["role_claim"]).strip() or "groups"
    if values.get("role_mapping") is not None:
        mapping = values["role_mapping"]
        if not isinstance(mapping, dict) or any(role not in ROLES for role in mapping.values()):
            raise ValidationFailed(f"role_mapping maps a claim value to one of: {', '.join(ROLES)}", details={"field": "role_mapping"})
        out["role_mapping"] = {str(k): v for k, v in mapping.items()}
    if "default_role" in values:
        if values["default_role"] not in (None, "", *ROLES):
            raise ValidationFailed(f"default_role must be one of: {', '.join(ROLES)}", details={"field": "default_role"})
        out["default_role"] = values["default_role"] or None
    if values.get("allowed_email_domains") is not None:
        domains = [str(d).strip().lower().lstrip("@") for d in values["allowed_email_domains"] if str(d).strip()]
        out["allowed_email_domains"] = domains
    for flag in ("auto_provision", "trust_idp_mfa", "enabled"):
        if values.get(flag) is not None:
            out[flag] = bool(values[flag])
    return out


def create_provider(session: Session, principal: Principal, values: dict) -> IdentityProvider:
    cleaned = _clean(values)
    if session.execute(select(IdentityProvider.id).where(IdentityProvider.tenant_id == principal.tenant_id, IdentityProvider.name == cleaned["name"])).first():
        raise Conflict("an identity provider with this name already exists")
    secret = values.get("client_secret")
    provider = IdentityProvider(tenant_id=principal.tenant_id, protocol="oidc", created_by=principal.user_id,
                                client_secret_enc=SecretBox().encrypt(secret) if secret else None,
                                **{"scopes": "openid email profile", "role_claim": "groups", "role_mapping": {}, "allowed_email_domains": [],
                                   "auto_provision": False, "trust_idp_mfa": False, "enabled": True, **cleaned})  # fmt: skip
    session.add(provider)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="sso.provider_created", entity_type="identity_provider",
                 entity_id=provider.id, detail={"name": provider.name, "issuer": provider.issuer})  # fmt: skip
    return provider


def update_provider(session: Session, principal: Principal, provider_id: int, values: dict) -> IdentityProvider:
    provider = get_owned(session, IdentityProvider, principal.tenant_id, provider_id, label="Identity provider")
    cleaned = _clean(values, partial=True)
    for key, value in cleaned.items():
        setattr(provider, key, value)
    if values.get("client_secret"):
        provider.client_secret_enc = SecretBox().encrypt(values["client_secret"])
    if "issuer" in cleaned:
        provider.metadata_cache, provider.jwks_cache, provider.cache_fetched_at = None, None, None
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="sso.provider_updated", entity_type="identity_provider",
                 entity_id=provider.id, detail={"changed": sorted([*cleaned, *(["client_secret"] if values.get("client_secret") else [])])})  # fmt: skip
    return provider


def _get(url: str, what: str) -> dict:
    settings = get_settings()
    if not url.startswith("https://") and not (settings.oidc_allow_insecure_http and url.startswith("http://")):
        raise ExternalServiceError(f"the identity provider's {what} is not an https:// URL")
    target = netguard.vet(url, allow_private=settings.oidc_allow_private_hosts, field_name=what, resolve=_transport is None)
    try:
        with httpx.Client(timeout=settings.oidc_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
            response = client.get(target.url, headers={"Accept": "application/json", **target.headers}, extensions=target.extensions)
    except httpx.HTTPError as exc:
        raise ExternalServiceError(f"the identity provider's {what} could not be reached ({type(exc).__name__})") from exc
    if response.status_code != 200:
        raise ExternalServiceError(f"the identity provider's {what} answered HTTP {response.status_code}")
    try:
        document = response.json()
    except ValueError as exc:
        raise ExternalServiceError(f"the identity provider's {what} is not JSON") from exc
    if not isinstance(document, dict):
        raise ExternalServiceError(f"the identity provider's {what} is not a JSON object")
    return document


def discover(session: Session, provider: IdentityProvider, *, force: bool = False) -> dict:
    """The provider's metadata and signing keys, fetched from its discovery document and cached for an hour."""
    fresh = provider.cache_fetched_at is not None and utcnow() - provider.cache_fetched_at < CACHE_TTL
    if fresh and not force and provider.metadata_cache and provider.jwks_cache:
        return provider.metadata_cache
    try:
        metadata = _get(f"{provider.issuer}/.well-known/openid-configuration", "discovery document")
        if str(metadata.get("issuer", "")).rstrip("/") != provider.issuer:
            raise ExternalServiceError("the discovery document names a different issuer than the one configured")
        for key in ("authorization_endpoint", "token_endpoint", "jwks_uri"):
            if not isinstance(metadata.get(key), str):
                raise ExternalServiceError(f"the discovery document has no {key}")
        keys = _get(metadata["jwks_uri"], "signing keys")
        if not isinstance(keys.get("keys"), list) or not keys["keys"]:
            raise ExternalServiceError("the identity provider publishes no signing keys")
    except ExternalServiceError as exc:
        provider.last_error = exc.message[:500]
        session.flush()
        raise
    provider.metadata_cache = {k: metadata.get(k) for k in ("issuer", "authorization_endpoint", "token_endpoint", "jwks_uri", "end_session_endpoint",
                                                            "id_token_signing_alg_values_supported", "token_endpoint_auth_methods_supported")}  # fmt: skip
    provider.jwks_cache, provider.cache_fetched_at, provider.last_error = {"keys": keys["keys"]}, utcnow(), None
    session.flush()
    return provider.metadata_cache


def test_provider(session: Session, principal: Principal, provider_id: int) -> dict:
    provider = get_owned(session, IdentityProvider, principal.tenant_id, provider_id, label="Identity provider")
    metadata = discover(session, provider, force=True)
    return {"ok": True, "issuer": metadata["issuer"], "authorization_endpoint": metadata["authorization_endpoint"],
            "token_endpoint": metadata["token_endpoint"], "signing_keys": len(provider.jwks_cache["keys"]),
            "algorithms": [a for a in (metadata.get("id_token_signing_alg_values_supported") or []) if a in ALGORITHMS]}  # fmt: skip


def public_providers(session: Session, tenant_slug: str) -> list[dict]:
    """What the sign-in page may show before anybody is signed in: names only."""
    rows = session.execute(select(IdentityProvider.id, IdentityProvider.name).join(Tenant, Tenant.id == IdentityProvider.tenant_id)
                           .where(Tenant.slug == tenant_slug.strip().lower(), IdentityProvider.enabled.is_(True)).order_by(IdentityProvider.name)).all()  # fmt: skip
    return [{"id": provider_id, "name": name} for provider_id, name in rows]


# ----------------------------------------------------------------------------- the login flow
def redirect_uri(request_base: str) -> str:
    settings = get_settings()
    base = (settings.public_base_url or request_base).rstrip("/")
    return f"{base}/api/v1/auth/oidc/callback"


def begin(session: Session, provider_id: int, *, request_base: str) -> dict:
    """Start a login: returns the provider's authorization URL and the value for the browser's binding cookie."""
    provider = session.get(IdentityProvider, provider_id)
    if provider is None or not provider.enabled:
        raise NotFound("this sign-in method does not exist or is switched off")
    metadata = discover(session, provider)
    state, nonce, binding = secrets.token_urlsafe(32), secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    uri = redirect_uri(request_base)
    session.add(OidcLoginState(tenant_id=provider.tenant_id, provider_id=provider.id, state_hash=hash_token(state), nonce_hash=hash_token(nonce),
                               code_verifier_enc=SecretBox().encrypt(verifier), browser_hash=hash_token(binding), redirect_uri=uri,
                               expires_at=utcnow() + STATE_TTL))  # fmt: skip
    query = {"response_type": "code", "client_id": provider.client_id, "redirect_uri": uri, "scope": provider.scopes, "state": state, "nonce": nonce,
             "code_challenge": b64url(hashlib.sha256(verifier.encode()).digest()), "code_challenge_method": "S256"}  # fmt: skip
    separator = "&" if "?" in metadata["authorization_endpoint"] else "?"
    return {"authorization_url": metadata["authorization_endpoint"] + separator + urlencode(query), "binding": binding, "state": state}


def _token_request(provider: IdentityProvider, metadata: dict, code: str, verifier: str, uri: str) -> dict:
    settings = get_settings()
    endpoint = metadata["token_endpoint"]
    if not endpoint.startswith("https://") and not (settings.oidc_allow_insecure_http and endpoint.startswith("http://")):
        raise ExternalServiceError("the identity provider's token endpoint is not an https:// URL")
    target = netguard.vet(endpoint, allow_private=settings.oidc_allow_private_hosts, field_name="token endpoint", resolve=_transport is None)
    form = {"grant_type": "authorization_code", "code": code, "redirect_uri": uri, "client_id": provider.client_id, "code_verifier": verifier}
    headers = {"Accept": "application/json", **target.headers}
    auth = None
    if provider.client_secret_enc:
        secret = SecretBox().decrypt(provider.client_secret_enc)
        if "client_secret_basic" in (metadata.get("token_endpoint_auth_methods_supported") or ["client_secret_basic"]):
            auth = (provider.client_id, secret)
        else:
            form["client_secret"] = secret
    try:
        with httpx.Client(timeout=settings.oidc_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
            response = client.post(target.url, data=form, headers=headers, auth=auth, extensions=target.extensions)
    except httpx.HTTPError as exc:
        raise ExternalServiceError(f"the identity provider's token endpoint could not be reached ({type(exc).__name__})") from exc
    if response.status_code != 200:
        raise LoginRefused("the identity provider did not accept the sign-in (the authorization code was refused)", code="sso_code_refused")
    try:
        return response.json()
    except ValueError as exc:
        raise ExternalServiceError("the identity provider's token response is not JSON") from exc


def check_claims(claims: dict, *, issuer: str, client_id: str, nonce_hash: str, now: float | None = None) -> None:
    moment = time.time() if now is None else now
    if str(claims.get("iss", "")).rstrip("/") != issuer:
        raise LoginRefused("the ID token was issued by somebody else", code="sso_issuer_mismatch")
    audience = claims.get("aud")
    audiences = audience if isinstance(audience, list) else [audience]
    if client_id not in audiences:
        raise LoginRefused("the ID token was issued for a different application", code="sso_audience_mismatch")
    if len(audiences) > 1 and claims.get("azp") != client_id:
        raise LoginRefused("the ID token names several audiences and this application is not the authorised party", code="sso_audience_mismatch")
    if not isinstance(claims.get("exp"), int | float) or claims["exp"] + LEEWAY_SECONDS < moment:
        raise LoginRefused("the ID token has expired", code="sso_token_expired")
    if isinstance(claims.get("iat"), int | float) and claims["iat"] - LEEWAY_SECONDS > moment:
        raise LoginRefused("the ID token is dated in the future", code="sso_token_not_yet_valid")
    if isinstance(claims.get("nbf"), int | float) and claims["nbf"] - LEEWAY_SECONDS > moment:
        raise LoginRefused("the ID token is not valid yet", code="sso_token_not_yet_valid")
    if not claims.get("nonce") or not secrets.compare_digest(hash_token(str(claims["nonce"])), nonce_hash):
        raise LoginRefused("the ID token does not belong to this sign-in attempt", code="sso_nonce_mismatch")
    if not claims.get("sub"):
        raise LoginRefused("the ID token names nobody", code="sso_subject_missing")


def _role_for(provider: IdentityProvider, claims: dict) -> str | None:
    values = claims.get(provider.role_claim)
    values = values if isinstance(values, list) else [values] if values is not None else []
    for value, role in (provider.role_mapping or {}).items():  # the mapping's order is its priority
        if value in [str(v) for v in values]:
            return role
    return provider.default_role


def _user_for(session: Session, provider: IdentityProvider, claims: dict) -> User:
    email = str(claims.get("email") or "").strip().lower()
    if not email or claims.get("email_verified") is not True:
        raise LoginRefused("the identity provider did not confirm a verified e-mail address for this account", code="sso_email_unverified")
    domains = provider.allowed_email_domains or []
    if domains and email.rsplit("@", 1)[-1] not in domains:
        raise LoginRefused("this e-mail domain is not allowed to sign in here", code="sso_domain_refused")
    role = _role_for(provider, claims)
    subject = str(claims["sub"])
    user = session.execute(select(User).where(User.identity_provider_id == provider.id, User.external_subject == subject)).scalar_one_or_none()
    if user is None:
        user = session.execute(select(User).where(User.email == email)).scalar_one_or_none()
        if user is not None:
            if user.tenant_id != provider.tenant_id:
                raise LoginRefused("this account belongs to another organisation", code="sso_wrong_tenant")
            if user.external_subject and user.identity_provider_id not in (None, provider.id):
                raise LoginRefused("this account is linked to another sign-in method", code="sso_linked_elsewhere")
            user.identity_provider_id, user.external_subject = provider.id, subject
            audit.record(session, tenant_id=provider.tenant_id, action="sso.account_linked", actor_label=email, entity_type="user", entity_id=user.id,
                         detail={"provider": provider.name})  # fmt: skip
    if user is None:
        if not provider.auto_provision:
            raise LoginRefused("no account exists for this person; ask an administrator to create one", code="sso_no_account")
        if role is None:
            raise LoginRefused("the identity provider assigned no role this platform knows; ask an administrator", code="sso_no_role")
        user = User(tenant_id=provider.tenant_id, email=email, full_name=str(claims.get("name") or email)[:200], role=role, is_active=True,
                    password_hash=None, identity_provider_id=provider.id, external_subject=subject)  # fmt: skip
        session.add(user)
        session.flush()
        audit.record(session, tenant_id=provider.tenant_id, action="sso.user_provisioned", actor_label=email, entity_type="user", entity_id=user.id,
                     detail={"provider": provider.name, "role": role})  # fmt: skip
    elif user.tenant_id != provider.tenant_id:
        raise LoginRefused("this account belongs to another organisation", code="sso_wrong_tenant")
    if not user.is_active:
        raise LoginRefused("this account is disabled", code="account_disabled")
    if provider.role_mapping and role is not None and role != user.role:
        audit.record(session, tenant_id=provider.tenant_id, action="sso.role_updated", actor_label=email, entity_type="user", entity_id=user.id,
                     detail={"from": user.role, "to": role, "provider": provider.name})  # fmt: skip
        user.role = role
    return user


def callback(session: Session, *, state: str | None, code: str | None, binding: str | None, error: str | None = None, ip: str | None = None,
             user_agent: str | None = None) -> str:
    """The provider sent the browser back.  Returns the one-time code the web app exchanges for its session."""
    settings = get_settings()
    now = utcnow()
    entry = session.execute(select(OidcLoginState).where(OidcLoginState.state_hash == hash_token(state or ""))).scalar_one_or_none()
    if entry is None:
        raise LoginRefused("this sign-in was not started here, or was already completed", code="sso_state_unknown")
    if entry.used_at is not None:
        raise LoginRefused("this sign-in was already completed", code="sso_state_reused")
    entry.used_at = now  # single use, whatever happens next
    session.flush()
    if entry.expires_at <= now:
        raise LoginRefused("this sign-in took too long; start again", code="sso_state_expired")
    if not binding or not secrets.compare_digest(hash_token(binding), entry.browser_hash):
        raise LoginRefused("this sign-in was started in another browser", code="sso_browser_mismatch")
    provider = session.get(IdentityProvider, entry.provider_id)
    if provider is None or not provider.enabled:
        raise LoginRefused("this sign-in method is switched off", code="sso_provider_disabled")
    if error or not code:
        raise LoginRefused("the identity provider did not complete the sign-in", code="sso_provider_error")
    metadata = discover(session, provider)
    tokens = _token_request(provider, metadata, code, SecretBox().decrypt(entry.code_verifier_enc), entry.redirect_uri)
    id_token = tokens.get("id_token")
    if not isinstance(id_token, str):
        raise LoginRefused("the identity provider returned no ID token", code="sso_token_missing")
    try:
        _header, claims = verify_jws(id_token, provider.jwks_cache["keys"])
    except LoginRefused as exc:
        if exc.code != "sso_key_unknown":
            raise
        discover(session, provider, force=True)  # the provider may have rotated its keys since they were cached
        _header, claims = verify_jws(id_token, provider.jwks_cache["keys"])
    check_claims(claims, issuer=provider.issuer, client_id=provider.client_id, nonce_hash=entry.nonce_hash)
    user = _user_for(session, provider, claims)
    amr = claims.get("amr") if isinstance(claims.get("amr"), list) else []
    idp_mfa = provider.trust_idp_mfa and bool(MFA_METHODS & {str(m).lower() for m in amr})
    if user.mfa_enabled and not idp_mfa:
        raise LoginRefused("this account is protected by a one-time code: sign in with password and code, or ask an administrator to "
                           "accept the identity provider's second factor", code="sso_mfa_required")  # fmt: skip
    if user.role in settings.mfa_required_role_set and not (user.mfa_enabled or idp_mfa):
        raise LoginRefused("this role requires a second factor, and the identity provider did not report one", code="sso_mfa_required")
    token, token_hash = new_token()
    auth_session = AuthSession(tenant_id=user.tenant_id, user_id=user.id, token_hash=token_hash, auth_method="oidc", mfa_verified=bool(idp_mfa or user.mfa_enabled),
                               ip=(ip or "")[:64] or None, user_agent=(user_agent or "")[:300] or None, last_seen_at=now,
                               expires_at=now + timedelta(minutes=settings.session_ttl_minutes), identity_provider_id=provider.id,
                               id_token_enc=SecretBox().encrypt(id_token))  # fmt: skip
    session.add(auth_session)
    user.last_login_at, user.failed_logins, user.locked_until = now, 0, None
    exchange = secrets.token_urlsafe(32)
    entry.exchange_hash, entry.session_token_enc, entry.expires_at = hash_token(exchange), SecretBox().encrypt(token), now + EXCHANGE_TTL
    session.flush()
    audit.record(session, tenant_id=user.tenant_id, action="auth.login", actor_label=user.email, entity_type="user", entity_id=user.id,
                 detail={"session_id": auth_session.id, "method": "oidc", "provider": provider.name, "idp_mfa": bool(idp_mfa)})  # fmt: skip
    return exchange


def exchange(session: Session, code: str, binding: str | None) -> dict:
    """The web app trades the one-time code for its session token (once, within 90 seconds, in the same browser)."""
    from .auth import user_view

    entry = session.execute(select(OidcLoginState).where(OidcLoginState.exchange_hash == hash_token(code or ""))).scalar_one_or_none()
    now = utcnow()
    if entry is None or entry.exchanged_at is not None or entry.session_token_enc is None or entry.expires_at <= now:
        raise Unauthorized("this sign-in code is not valid any more; sign in again", code="sso_exchange_invalid")
    if not binding or not secrets.compare_digest(hash_token(binding), entry.browser_hash):
        raise Unauthorized("this sign-in was started in another browser", code="sso_browser_mismatch")
    token = SecretBox().decrypt(entry.session_token_enc)
    entry.exchanged_at, entry.session_token_enc = now, None  # the token leaves the database with this response
    auth_session = session.execute(select(AuthSession).where(AuthSession.token_hash == hash_token(token))).scalar_one()
    user = session.get(User, auth_session.user_id)
    settings = get_settings()
    return {"token": token, "expires_at": auth_session.expires_at.isoformat(), "user": user_view(user),
            "mfa_enrollment_required": user.role in settings.mfa_required_role_set and not user.mfa_enabled and not auth_session.mfa_verified}  # fmt: skip


def record_refusal(session: Session, state: str | None, reason: str) -> None:
    """A refused sign-in is audited under the provider's tenant (when the state is known)."""
    entry = session.execute(select(OidcLoginState).where(OidcLoginState.state_hash == hash_token(state or ""))).scalar_one_or_none()
    if entry is not None:
        if entry.used_at is None:
            entry.used_at = utcnow()
        audit.record(session, tenant_id=entry.tenant_id, action="auth.login_failed", actor_label="single sign-on", entity_type="identity_provider",
                     entity_id=entry.provider_id, detail={"reason": reason, "method": "oidc"})  # fmt: skip


def list_providers(session: Session, tenant_id: int) -> list[dict]:
    rows = session.execute(select(IdentityProvider).where(IdentityProvider.tenant_id == tenant_id).order_by(IdentityProvider.name)).scalars().all()
    return [provider_view(p) for p in rows]


def delete_provider(session: Session, principal: Principal, provider_id: int) -> None:
    provider = get_owned(session, IdentityProvider, principal.tenant_id, provider_id, label="Identity provider")
    if session.execute(select(User.id).where(User.identity_provider_id == provider.id).limit(1)).first():
        raise Forbidden("accounts are linked to this identity provider; switch it off instead of deleting it", code="provider_in_use")
    session.execute(OidcLoginState.__table__.delete().where(OidcLoginState.provider_id == provider.id))
    session.delete(provider)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="sso.provider_deleted", entity_type="identity_provider",
                 entity_id=provider_id, detail={"name": provider.name})  # fmt: skip
