"""Point-in-time subscription timelines shared by churn labelling and feature engineering.

Everything here works on tz-naive UTC pandas timestamps.  An *as-of date* ``T`` denotes the instant
``T 00:00:00 UTC``: features may only use records strictly before that instant and the prediction
target is whether the customer churns in ``[T, T + horizon)``.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import (
    Account,
    Customer,
    CustomerAttributeHistory,
    EntityHistory,
    IdentityLink,
    Invoice,
    Payment,
    Plan,
    Policy,
    ProductFeature,
    SentimentModel,
    SentimentScore,
    Subscription,
    SubscriptionEvent,
    SupportInteraction,
    UsageEvent,
)

ENDED_STATUSES = {"ended", "cancelled", "canceled", "churned", "expired", "terminated"}
FRAME_COLUMNS: dict[str, tuple[Any, list[str]]] = {
    "customers": (Customer, ["id", "external_id", "name", "employee_count", "company_size", "industry", "region", "country",
                             "acquisition_channel", "acquired_at", "consent_marketing"]),
    "accounts": (Account, ["id", "customer_id", "payment_method_expires_on", "csm_owner"]),
    "plans": (Plan, ["id", "external_id", "tier", "billing_period"]),
    "subscriptions": (Subscription, ["id", "customer_id", "plan_id", "status", "billing_period", "started_at", "trial_end_at",
                                     "ended_at", "end_reason", "mrr", "discount_pct", "quantity"]),
    "sub_events": (SubscriptionEvent, ["id", "subscription_id", "customer_id", "event_type", "occurred_at", "plan_id", "mrr", "reason"]),
    "usage": (UsageEvent, ["customer_id", "occurred_at", "event_type", "feature_name", "duration_seconds", "quantity", "user_ref"]),
    "support": (SupportInteraction, ["id", "customer_id", "kind", "opened_at", "resolved_at", "escalated", "csat", "nps_score", "body"]),
    "invoices": (Invoice, ["id", "customer_id", "issued_at", "due_at", "paid_at", "amount"]),
    "payments": (Payment, ["id", "customer_id", "attempted_at", "status", "amount"]),
}  # fmt: skip
_TIME_COLS = {"acquired_at", "started_at", "trial_end_at", "ended_at", "occurred_at", "opened_at", "resolved_at", "issued_at",
              "due_at", "paid_at", "attempted_at", "payment_method_expires_on", "changed_at"}  # fmt: skip
_FLOAT_COLS = {"mrr", "amount", "discount_pct", "duration_seconds", "csat", "nps_score", "employee_count", "quantity"}


def ts(value: date | datetime | str) -> pd.Timestamp:
    """Naive-UTC timestamp for an as-of date (midnight) or datetime."""
    stamp = pd.Timestamp(value)
    return stamp.tz_convert(None) if stamp.tzinfo is not None else stamp


def _frame(session: Session, model: Any, columns: list[str], tenant_id: int, customer_ids: list[int] | None,
           before: pd.Timestamp | None = None) -> pd.DataFrame:
    table = model.__table__
    stmt = select(*[table.c[c] for c in columns]).where(table.c.tenant_id == tenant_id)
    if customer_ids is not None:
        key = table.c.id if model is Customer else table.c.customer_id if "customer_id" in table.c else None
        if key is not None:
            stmt = stmt.where(key.in_(customer_ids))
    rows = session.execute(stmt).all()
    df = pd.DataFrame(rows, columns=columns)
    for col in columns:
        if col in _TIME_COLS:
            df[col] = pd.to_datetime(df[col], utc=True).dt.tz_convert(None).astype("datetime64[ns]")
        elif col in _FLOAT_COLS:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
    return df


def load_frames(session: Session, tenant_id: int, customer_ids: list[int] | None = None,
                tables: tuple[str, ...] | None = None) -> dict[str, pd.DataFrame]:
    """Load the canonical tables needed for timelines/features as DataFrames (optionally one customer chunk)."""
    frames = {}
    for name, (model, columns) in FRAME_COLUMNS.items():
        if tables is None or name in tables:
            frames[name] = _frame(session, model, columns, tenant_id, customer_ids)
    if tables is None or "accounts" in tables:
        # Bitemporal reconstruction for the one snapshot attribute used as a feature: when the
        # platform saw the card-expiry value change, remember the previous value and when it changed.
        stmt = select(EntityHistory.entity_id, EntityHistory.changed_at, EntityHistory.before).where(
            EntityHistory.tenant_id == tenant_id, EntityHistory.entity_type == "accounts")  # fmt: skip
        rows = [(eid, changed, before.get("payment_method_expires_on")) for eid, changed, before in session.execute(stmt)
                if isinstance(before, dict) and "payment_method_expires_on" in before]  # fmt: skip
        hist = pd.DataFrame(rows, columns=["account_id", "changed_at", "previous_expiry"])
        hist["changed_at"] = pd.to_datetime(hist["changed_at"], utc=True).dt.tz_convert(None).astype("datetime64[ns]")
        hist["previous_expiry"] = pd.to_datetime(hist["previous_expiry"]).astype("datetime64[ns]")
        frames["account_history"] = hist
    if tables is None:
        frames.update(load_signal_frames(session, tenant_id, customer_ids))
    return frames


def _naive(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, utc=True).dt.tz_convert(None).astype("datetime64[ns]")


def catalog_frame(features: list[Any], first_seen: dict[tuple[str, str], Any] | None = None) -> pd.DataFrame:
    """The engine's view of catalogue entries: what counts as use of each feature, and who could use it when.

    ``first_seen`` maps (event type, feature name) to the first time that telemetry was ever recorded.  A feature
    whose telemetry has not been seen yet cannot be told apart from one that is not instrumented, so it stays out
    of every denominator until then.  Without the argument the frame carries no such restriction.
    """
    rows = []
    for feature in features:
        mapping = [m for m in (feature.event_mapping or []) if isinstance(m, dict) and m.get("feature_name")]
        rule, eligibility = feature.adoption_rule or {}, feature.eligibility or {}
        tiers = eligibility.get("plan_tiers") or ([feature.required_plan] if feature.required_plan else None)
        rows.append({
            "feature_key": feature.feature_key, "name": feature.name, "is_core": bool(feature.is_core),
            "release_date": feature.release_date, "retired_date": feature.retired_date,
            "plan_tiers": tuple(tiers) if tiers else None,
            "names": tuple(sorted({str(m["feature_name"]).strip().casefold() for m in mapping})),
            "event_types": tuple(sorted({m.get("event_type") or "feature_use" for m in mapping})) or ("feature_use",),
            "min_events": int(rule.get("min_events", 1)), "min_days": int(rule.get("min_days", 1)),
        })  # fmt: skip
        if first_seen is not None:
            seen = [first_seen[(etype, name)] for name in rows[-1]["names"] for etype in rows[-1]["event_types"] if (etype, name) in first_seen]
            rows[-1]["first_seen"] = min(seen) if seen else None
    columns = ["feature_key", "name", "is_core", "release_date", "retired_date", "plan_tiers", "names", "event_types", "min_events", "min_days"]
    frame = pd.DataFrame(rows, columns=columns + (["first_seen"] if first_seen is not None else []))
    for col in ("release_date", "retired_date"):
        frame[col] = pd.to_datetime(frame[col]).astype("datetime64[ns]")
    if first_seen is not None:
        frame["first_seen"] = _naive(frame["first_seen"])
    return frame


def telemetry_first_seen(session: Session, tenant_id: int, features: list[Any]) -> dict[tuple[str, str], Any]:
    """When each telemetry name the catalogue maps was first recorded for the tenant."""
    names = sorted({str(m["feature_name"]).strip().casefold() for f in features for m in (f.event_mapping or []) if isinstance(m, dict) and m.get("feature_name")})
    if not names:
        return {}
    lowered = func.lower(UsageEvent.feature_name)
    rows = session.execute(select(UsageEvent.event_type, lowered, func.min(UsageEvent.occurred_at)).where(
        UsageEvent.tenant_id == tenant_id, lowered.in_(names)).group_by(UsageEvent.event_type, lowered)).all()  # fmt: skip
    return {(etype, str(name).strip()): first for etype, name, first in rows}


def approved_catalog(session: Session, tenant_id: int) -> list[ProductFeature]:
    """The catalogue that counts: for every feature key, its newest approved version, unless switched off."""
    rows = session.execute(select(ProductFeature).where(ProductFeature.tenant_id == tenant_id, ProductFeature.status == "approved")
                           .order_by(ProductFeature.feature_key, ProductFeature.version.desc())).scalars().all()  # fmt: skip
    newest: dict[str, ProductFeature] = {}
    for row in rows:
        newest.setdefault(row.feature_key, row)
    return [row for row in newest.values() if row.is_active]


def activity_definition(session: Session, tenant_id: int) -> dict | None:
    """The tenant's approved definition of an active user (None: the engine's default applies)."""
    policy = session.execute(select(Policy).where(Policy.tenant_id == tenant_id, Policy.kind == "activity_definition", Policy.status == "approved")
                             .order_by(Policy.version.desc(), Policy.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
    return dict(policy.payload) if policy is not None else None


def load_signal_frames(session: Session, tenant_id: int, customer_ids: list[int] | None = None) -> dict[str, Any]:
    """Derived signals that feed features: sentiment scores (of the active model), the approved product-feature
    catalogue, identity links, customer attribute history, and the approved activity definition."""
    out: dict[str, Any] = {}
    model_id = session.execute(select(SentimentModel.id).where(SentimentModel.tenant_id == tenant_id, SentimentModel.is_active.is_(True))).scalar()
    stmt = select(SentimentScore.interaction_id, SentimentScore.label, SentimentScore.score, SentimentScore.state).where(
        SentimentScore.tenant_id == tenant_id, SentimentScore.sentiment_model_id == model_id)  # fmt: skip
    if customer_ids is not None:
        stmt = stmt.where(SentimentScore.customer_id.in_(customer_ids))
    rows = session.execute(stmt).all() if model_id is not None else []
    out["sentiment"] = pd.DataFrame(rows, columns=["interaction_id", "label", "score", "state"]) if model_id is not None else None
    entries = approved_catalog(session, tenant_id)
    out["catalog"] = catalog_frame(entries, telemetry_first_seen(session, tenant_id, entries))

    link = IdentityLink.__table__
    stmt = select(link.c.id, link.c.external_user_id, link.c.user_key, link.c.status, link.c.customer_id, link.c.valid_from, link.c.valid_to).where(
        link.c.tenant_id == tenant_id, link.c.status != "merged")  # fmt: skip
    if customer_ids is not None:
        stmt = stmt.where(link.c.customer_id.is_(None) | link.c.customer_id.in_(customer_ids))
    links = pd.DataFrame(session.execute(stmt).all(), columns=["link_id", "external_user_id", "user_key", "status", "customer_id", "valid_from", "valid_to"])
    links["customer_id"] = pd.to_numeric(links["customer_id"], errors="coerce").astype("float64")
    for col in ("valid_from", "valid_to"):
        links[col] = _naive(links[col])
    out["identity"] = links

    hist = CustomerAttributeHistory.__table__
    stmt = select(hist.c.id, hist.c.customer_id, hist.c.attribute, hist.c.value, hist.c.valid_from, hist.c.valid_to, hist.c.basis,
                  hist.c.recorded_at, hist.c.superseded_at).where(hist.c.tenant_id == tenant_id)  # fmt: skip
    if customer_ids is not None:
        stmt = stmt.where(hist.c.customer_id.in_(customer_ids))
    history = pd.DataFrame(session.execute(stmt).all(), columns=["id", "customer_id", "attribute", "value", "valid_from", "valid_to", "basis",
                                                                 "recorded_at", "superseded_at"])  # fmt: skip
    for col in ("valid_from", "valid_to", "recorded_at", "superseded_at"):
        history[col] = _naive(history[col])
    # declared history is trusted from its start; what the platform merely observed is known from when it was recorded
    history["known_from"] = history["recorded_at"].where(history["basis"].isin(["observed", "correction"]), pd.NaT)
    out["attributes"] = history if len(history) else None
    out["activity"] = activity_definition(session, tenant_id)
    return out


def data_cutoff(session: Session, tenant_id: int) -> datetime | None:
    """Latest event timestamp the platform has observed for the tenant (the observation horizon)."""
    candidates = [
        session.execute(select(func.max(col)).where(model.tenant_id == tenant_id)).scalar()
        for model, col in ((UsageEvent, UsageEvent.occurred_at), (SubscriptionEvent, SubscriptionEvent.occurred_at),
                           (Payment, Payment.attempted_at), (Invoice, Invoice.issued_at))
    ]  # fmt: skip
    candidates = [c for c in candidates if c is not None]
    return max(candidates) if candidates else None


def known_before(frames: dict[str, pd.DataFrame], t0: pd.Timestamp) -> dict[str, pd.DataFrame]:
    """The subscription history as it was knowable strictly before ``t0`` (subscriptions, their events, payments)."""
    out = dict(frames)
    out["sub_events"] = frames["sub_events"][frames["sub_events"]["occurred_at"] < t0]
    out["payments"] = frames["payments"][frames["payments"]["attempted_at"] < t0]
    subs = frames["subscriptions"][frames["subscriptions"]["started_at"] < t0].copy()
    future_end = subs["ended_at"] >= t0
    subs.loc[future_end, "ended_at"] = pd.NaT
    subs.loc[future_end, "end_reason"] = None
    subs["status"] = None  # a current-state column: it says nothing about the state at t0
    out["subscriptions"] = subs
    return out


def build_intervals(frames: dict[str, pd.DataFrame], grace_days: int, cutoff: pd.Timestamp) -> pd.DataFrame:
    """Reconstruct every subscription's active intervals from its lifecycle events.

    Returns one row per interval: subscription_id, customer_id, start, end (NaT while open),
    end_reason, trial_end, state_source ('events' | 'events+row_start' | 'subscription_row'), problem.

    Involuntary churn honours the grace period: a failed payment that is not recovered (by a
    ``recovered`` event or a later successful payment) within ``grace_days`` ends the interval at
    failure + grace, unless the subscription was explicitly ended earlier.
    """
    subs, events = frames["subscriptions"], frames["sub_events"]
    grace = pd.Timedelta(days=grace_days)
    paid = frames["payments"]
    paid = paid[paid["status"] == "succeeded"]
    paid_by_customer = {cid: np.sort(grp["attempted_at"].to_numpy()) for cid, grp in paid.groupby("customer_id")}
    by_sub: dict[int, list[tuple]] = {}
    for row in events.sort_values(["occurred_at", "id"]).itertuples(index=False):
        by_sub.setdefault(row.subscription_id, []).append((row.event_type, row.occurred_at, row.reason))
    out: list[tuple] = []
    for sub in subs.itertuples(index=False):
        evs = by_sub.get(sub.id)
        trial_end = sub.trial_end_at
        source = "events"
        if evs and not any(e[0] == "started" for e in evs):
            # The event history begins mid-life (for example a truncated export).  The start comes from
            # the subscription row and the events that do exist are honoured: silently ignoring an
            # ``ended`` or ``payment_failed`` event would keep a churned customer looking subscribed.
            if pd.isna(sub.started_at) or sub.started_at > evs[0][1]:
                out.append((sub.id, sub.customer_id, sub.started_at, sub.ended_at, sub.end_reason if pd.notna(sub.ended_at) else None,
                            trial_end, "subscription_row", True))  # fmt: skip
                continue  # events that predate the recorded start contradict the row: flagged as a problem
            evs, source = [("started", sub.started_at, None), *evs], "events+row_start"
        if not evs:
            problem = pd.isna(sub.ended_at) and str(sub.status or "").lower() in ENDED_STATUSES
            out.append((sub.id, sub.customer_id, sub.started_at, sub.ended_at, sub.end_reason if pd.notna(sub.ended_at) else None,
                        trial_end, "subscription_row", bool(problem)))  # fmt: skip
            continue
        payments = paid_by_customer.get(sub.customer_id)

        def recovered_by_payment(failed_at: pd.Timestamp, payments: Any = payments) -> bool:
            if payments is None:
                return False
            lo = np.searchsorted(payments, np.datetime64(failed_at), side="right")
            return bool(lo < len(payments) and payments[lo] <= np.datetime64(failed_at + grace))

        start, dunning = None, None
        for kind, when, reason in evs:
            if kind == "trial_converted":
                trial_end = when
            if start is not None and dunning is not None and when > dunning + grace and kind != "recovered":
                # grace period expired before this event: the subscription lapsed at failure + grace
                out.append((sub.id, sub.customer_id, start, dunning + grace, "payment_failure", trial_end, source, False))
                start, dunning = None, None
            if kind in ("started", "reactivated"):
                if start is None:
                    start = when
                dunning = None
            elif kind == "ended":
                if start is not None:
                    out.append((sub.id, sub.customer_id, start, when, reason or "unknown", trial_end, source, False))
                start, dunning = None, None
            elif kind == "payment_failed":
                if start is not None and dunning is None and not recovered_by_payment(when):
                    dunning = when
            elif kind == "recovered":
                if start is not None and dunning is not None and when > dunning + grace:
                    out.append((sub.id, sub.customer_id, start, dunning + grace, "payment_failure", trial_end, source, False))
                    start = when
                dunning = None
        if start is not None:
            if dunning is not None and dunning + grace <= cutoff:
                out.append((sub.id, sub.customer_id, start, dunning + grace, "payment_failure", trial_end, source, False))
            else:
                out.append((sub.id, sub.customer_id, start, pd.NaT, None, trial_end, source, False))
    cols = ["subscription_id", "customer_id", "start", "end", "end_reason", "trial_end", "state_source", "problem"]
    df = pd.DataFrame(out, columns=cols)
    for col in ("start", "end", "trial_end"):
        df[col] = pd.to_datetime(df[col]).astype("datetime64[ns]")
    return df


def paid_intervals(intervals: pd.DataFrame, include_trials: bool) -> pd.DataFrame:
    """Clip intervals to their paid portion (after the trial) unless trials count as subscriptions."""
    if include_trials or intervals.empty:
        return intervals.assign(paid_start=intervals["start"])
    paid_start = intervals["start"].where(intervals["trial_end"].isna() | (intervals["trial_end"] <= intervals["start"]),
                                          intervals["trial_end"])  # fmt: skip
    df = intervals.assign(paid_start=paid_start)
    return df[df["end"].isna() | (df["end"] > df["paid_start"])]


def merge_blocks(df: pd.DataFrame, key: str, gap_days: int) -> pd.DataFrame:
    """Merge each key's intervals into blocks, bridging gaps of at most ``gap_days`` (reactivations)."""
    far = pd.Timestamp.max.floor("D")
    gap = pd.Timedelta(days=gap_days)
    rows: list[tuple] = []
    ordered = df.assign(_end=df["end"].fillna(far)).sort_values([key, "paid_start", "_end"])
    for k, grp in ordered.groupby(key, sort=False):
        cur_start = cur_end = cur_reason = None
        for start, end, reason in zip(grp["paid_start"], grp["_end"], grp["end_reason"], strict=True):
            if cur_start is None:
                cur_start, cur_end, cur_reason = start, end, reason
            elif start <= (cur_end + gap if cur_end < far - gap else far):
                if end > cur_end:
                    cur_end, cur_reason = end, reason
            else:
                rows.append((k, cur_start, cur_end, cur_reason))
                cur_start, cur_end, cur_reason = start, end, reason
        if cur_start is not None:
            rows.append((k, cur_start, cur_end, cur_reason))
    out = pd.DataFrame(rows, columns=[key, "start", "end", "end_reason"])
    out["end"] = out["end"].where(out["end"] < far, pd.NaT)
    for col in ("start", "end"):
        out[col] = pd.to_datetime(out[col]).astype("datetime64[ns]")
    return out


def active_at(df: pd.DataFrame, instant: pd.Timestamp, start_col: str = "start") -> pd.DataFrame:
    return df[(df[start_col] <= instant) & (df["end"].isna() | (df["end"] > instant))]
