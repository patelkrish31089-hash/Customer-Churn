"""Model and data monitoring: feature drift, prediction drift, realised performance, alert rules
and the retraining trigger (a breached retraining rule starts ``services.retraining``).

PSI thresholds (0.10 / 0.25) are the customary rules of thumb, not statistical guarantees; each
feature also gets a two-sample test (Kolmogorov-Smirnov or chi-square) so both views are visible.
"""

from __future__ import annotations

import operator
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope
from ..errors import Conflict, NotFound
from ..models import (
    Alert,
    ChurnLabel,
    DQRun,
    DriftReport,
    FeatureContract,
    MLDataset,
    ModelRun,
    ModelVersion,
    Prediction,
    PredictionBatch,
)
from ..security import Principal
from . import audit, feature_engine, features, jobs, mlprep, policies, registry, training
from .common import get_owned, json_safe, to_dict

PSI_WARNING, PSI_ALERT = 0.10, 0.25
MIN_ROWS = 30
MATURE = ("churned", "retained")
MAX_MEASURED_BATCHES = 12  # newest scoring dates with known outcomes per report
MAX_PENDING_BATCHES = 6  # newest scoring dates still waiting for their outcome window to close
_OPS = {">": operator.gt, ">=": operator.ge, "<": operator.lt, "<=": operator.le}


def psi_from_shares(ref: np.ndarray, cur: np.ndarray, eps: float = 1e-4) -> float:
    ref, cur = np.clip(ref, eps, None), np.clip(cur, eps, None)
    ref, cur = ref / ref.sum(), cur / cur.sum()
    return float(np.sum((cur - ref) * np.log(cur / ref)))


def psi_numeric(reference: np.ndarray, current: np.ndarray, bins: int = 10) -> float:
    """Population Stability Index with bin edges taken from the reference quantiles (+ a missing bin)."""
    reference, current = np.asarray(reference, dtype="float64"), np.asarray(current, dtype="float64")
    ref_ok, cur_ok = reference[~np.isnan(reference)], current[~np.isnan(current)]
    if len(ref_ok) == 0 or len(cur_ok) == 0:
        return psi_from_shares(np.array([np.isnan(reference).mean(), 1 - np.isnan(reference).mean()]),
                               np.array([np.isnan(current).mean(), 1 - np.isnan(current).mean()]))  # fmt: skip
    edges = np.unique(np.quantile(ref_ok, np.linspace(0, 1, bins + 1)))
    if len(edges) == 1:
        # the reference is constant (say, "0 overdue invoices" for everyone in training): bins are below / equal / above
        # that value, so any current value that differs from it counts as drift instead of falling into one catch-all bin
        inner = np.array([edges[0], np.nextafter(edges[0], np.inf)])
    elif len(edges) == 2:
        inner = np.array([(edges[0] + edges[1]) / 2])
    else:
        inner = edges[1:-1]
    ref_counts = np.bincount(np.searchsorted(inner, ref_ok, side="right"), minlength=len(inner) + 1).astype("float64")
    cur_counts = np.bincount(np.searchsorted(inner, cur_ok, side="right"), minlength=len(inner) + 1).astype("float64")
    ref_share = np.append(ref_counts, np.isnan(reference).sum()) / len(reference)
    cur_share = np.append(cur_counts, np.isnan(current).sum()) / len(current)
    return psi_from_shares(ref_share, cur_share)


def psi_categorical(reference: pd.Series, current: pd.Series) -> float:
    ref = reference.astype(object).where(reference.notna(), "(missing)").astype(str).value_counts(normalize=True)
    cur = current.astype(object).where(current.notna(), "(missing)").astype(str).value_counts(normalize=True)
    keys = sorted(set(ref.index) | set(cur.index))
    return psi_from_shares(ref.reindex(keys).fillna(0).to_numpy(), cur.reindex(keys).fillna(0).to_numpy())


def sample_of(as_of: str, split_end: dict[str, str]) -> str:
    """Where a scoring date sits relative to the model's data (ISO dates; the newest date of each split)."""
    if as_of <= split_end.get("train", ""):
        return "in_sample_training"
    if as_of <= split_end.get("valid", ""):
        return "validation_period"
    if as_of <= split_end.get("test", ""):
        return "test_period"
    return "after_model_data"


def status_for(psi: float) -> str:
    return "alert" if psi >= PSI_ALERT else "warning" if psi >= PSI_WARNING else "ok"


def feature_drift(reference: pd.DataFrame, current: pd.DataFrame, feature_names: list[str]) -> dict:
    from scipy import stats

    if len(reference) < MIN_ROWS or len(current) < MIN_ROWS:
        return {"status": "insufficient_data", "rows": {"reference": int(len(reference)), "current": int(len(current))},
                "reason": f"at least {MIN_ROWS} rows are needed on each side", "features": []}  # fmt: skip
    rows = []
    for name in feature_names:
        spec = feature_engine.SPECS[name]
        ref, cur = reference[name], current[name]
        entry: dict[str, Any] = {"feature": name, "label": spec.label, "group": spec.group,
                                 "missing_reference": float(ref.isna().mean()), "missing_current": float(cur.isna().mean())}  # fmt: skip
        if spec.dtype == "category":
            entry["psi"] = psi_categorical(ref, cur)
            keys = sorted(set(ref.dropna().astype(str)) | set(cur.dropna().astype(str)))
            table = np.array([[(ref.astype(str) == k).sum() for k in keys], [(cur.astype(str) == k).sum() for k in keys]])
            table = table[:, table.sum(axis=0) > 0]
            if table.shape[1] > 1:
                chi2, p, _dof, _exp = stats.chi2_contingency(table)
                entry.update({"test": "chi-square", "statistic": float(chi2), "p_value": float(p)})
        else:
            r, c = pd.to_numeric(ref, errors="coerce").to_numpy(dtype="float64"), pd.to_numeric(cur, errors="coerce").to_numpy(dtype="float64")
            entry["psi"] = psi_numeric(r, c)
            r_ok, c_ok = r[~np.isnan(r)], c[~np.isnan(c)]
            if len(r_ok) >= 5 and len(c_ok) >= 5:
                ks = stats.ks_2samp(r_ok, c_ok)
                entry.update({"test": "Kolmogorov-Smirnov", "statistic": float(ks.statistic), "p_value": float(ks.pvalue),
                              "mean_reference": float(r_ok.mean()), "mean_current": float(c_ok.mean())})  # fmt: skip
        entry["status"] = status_for(entry["psi"])
        entry["missing_rate_increase"] = entry["missing_current"] - entry["missing_reference"]
        rows.append(entry)
    rows.sort(key=lambda e: -e["psi"])
    drifted = sum(e["status"] == "alert" for e in rows)
    share = drifted / len(rows) if rows else 0.0
    return {"status": "alert" if share >= 0.3 else "warning" if drifted else "ok", "features": rows, "drifted_features": drifted,
            "drifted_share": share, "max_missing_rate_increase": max((e["missing_rate_increase"] for e in rows), default=0.0),
            "rows": {"reference": int(len(reference)), "current": int(len(current))},
            "thresholds": {"psi_warning": PSI_WARNING, "psi_alert": PSI_ALERT, "basis": "customary rule of thumb"}}  # fmt: skip


def realised_performance(y: np.ndarray, p: np.ndarray, reference_pr_auc: float | None) -> dict:
    from .evaluation import core_metrics

    metrics = core_metrics(y, p, bootstrap=0)
    if metrics["pr_auc"] is None:
        return {"status": "insufficient_data", "reason": metrics.get("note"), **metrics}
    drop = None if reference_pr_auc is None else reference_pr_auc - metrics["pr_auc"]
    return {"status": "ok", **metrics, "reference_pr_auc": reference_pr_auc, "pr_auc_drop": drop}


def evidently_summary(reference: pd.DataFrame, current: pd.DataFrame) -> dict:
    """Optional second opinion from Evidently's DataDriftPreset.  Never required for monitoring to work."""
    import warnings

    # Evidently refuses a column that is entirely empty on either side (for example "days since reactivation" when
    # nobody in the training period had reactivated).  Such columns are left out here and listed in the summary;
    # the platform's own PSI report above still covers them through its missing-value bin.
    empty = [c for c in reference.columns if reference[c].isna().all() or current[c].isna().all()]
    reference, current = reference.drop(columns=empty), current.drop(columns=empty)
    if reference.shape[1] == 0:
        return {"status": "unavailable", "engine": "evidently", "reason": "every column is empty on at least one side", "excluded_columns": empty}
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")  # evidently emits import-time deprecation warnings from its dependencies
            from evidently import Report
            from evidently.presets import DataDriftPreset

            snapshot = Report([DataDriftPreset()]).run(current, reference)
            result = snapshot.dict()
        metrics = result.get("metrics", [])
        head = next((m for m in metrics if "DriftedColumnsCount" in str(m.get("metric_id", m.get("metric_name", "")))), None)
        return {"status": "available", "engine": "evidently", "metrics": len(metrics), "columns": int(reference.shape[1]),
                "excluded_columns": empty, "drifted_columns": json_safe(head.get("value")) if head else None}  # fmt: skip
    except Exception as exc:  # optional integration: report, never fail the monitoring job
        return {"status": "unavailable", "engine": "evidently", "reason": f"{type(exc).__name__}: {exc}"[:300], "excluded_columns": empty}


def start(session: Session, principal: Principal | None, *, tenant_id: int, model_version_id: int | None = None,
          with_evidently: bool = False, created_by: int | None = None) -> Any:
    registry.production_version(session, tenant_id, version_id=model_version_id)  # raises if nothing is servable
    job = jobs.enqueue(session, tenant_id=tenant_id, job_type="monitoring.run", created_by=principal.user_id if principal else created_by,
                       payload={"model_version_id": model_version_id, "with_evidently": with_evidently})  # fmt: skip
    audit.record(session, tenant_id=tenant_id, actor=principal, action="monitoring.started", entity_type="model_version",
                 entity_id=model_version_id)  # fmt: skip
    return job


def run(tenant_id: int, model_version_id: int | None, with_evidently: bool = False, ctx: Any = None) -> dict:
    with read_session() as rs:
        try:
            version = registry.production_version(rs, tenant_id, version_id=model_version_id)
        except (NotFound, Conflict) as exc:
            raise jobs.PermanentJobError(exc.message) from exc
        run_row = rs.get(ModelRun, version.model_run_id)
        dataset = rs.get(MLDataset, run_row.dataset_id)
        contract = rs.get(FeatureContract, version.contract_id)
        names = list(contract.features)
        bundle = training.load_bundle(run_row)
        train, valid = mlprep.load_split(dataset, "train"), mlprep.load_split(dataset, "valid")
        batches = rs.execute(select(PredictionBatch).where(
            PredictionBatch.tenant_id == tenant_id, PredictionBatch.model_version_id == version.id, PredictionBatch.status == "completed",
            PredictionBatch.kind != "single").order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc())).scalars().all()  # fmt: skip
        latest = batches[0] if batches else None
        scored = rs.execute(select(Prediction.customer_id, Prediction.probability).where(Prediction.batch_id == latest.id)).all() if latest else []
        cur_probs = np.array([p for _, p in scored], dtype="float64")
        # the feature store also holds customers the model does not cover (trials): compare the scored population only
        current = features.offline_frame(rs, tenant_id, contract, dates=[latest.as_of_date]) if latest else pd.DataFrame(columns=names)
        feature_source = "offline feature store"
        if latest and scored and current.empty:
            # scored on a date the store was never materialised for: the batch computed its vectors and did not keep them
            current = features.computed_frame(tenant_id, contract, latest.as_of_date, [c for c, _ in scored])
            feature_source = "computed for this report"
        current = current[current["customer_id"].isin({c for c, _ in scored})].reset_index(drop=True) if len(current) else current
        # With nightly scoring the list of batches grows by one a day, so the report is bounded: the newest scoring
        # dates whose outcomes are known, plus the newest ones still waiting for their outcome window to close.
        known_dates: set = set()
        if batches:
            known_dates = set(rs.execute(select(ChurnLabel.as_of_date).where(
                ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == dataset.policy_id, ChurnLabel.status.in_(MATURE),
                ChurnLabel.as_of_date >= batches[-1].as_of_date).distinct()).scalars())  # fmt: skip
        with_outcomes = [b for b in batches if b.as_of_date in known_dates]
        pending = [b for b in batches if b.as_of_date not in known_dates]
        realised = []
        for batch in with_outcomes[:MAX_MEASURED_BATCHES]:
            rows = rs.execute(select(Prediction.probability, ChurnLabel.label).join(ChurnLabel, (ChurnLabel.customer_id == Prediction.customer_id)
                              & (ChurnLabel.as_of_date == Prediction.as_of_date)).where(
                Prediction.batch_id == batch.id, ChurnLabel.policy_id == dataset.policy_id, ChurnLabel.tenant_id == tenant_id,
                ChurnLabel.status.in_(MATURE))).all()  # fmt: skip
            realised.append((batch.id, batch.as_of_date, rows))
        realised.extend((batch.id, batch.as_of_date, []) for batch in pending[:MAX_PENDING_BATCHES])
        realised.sort(key=lambda item: (item[1], item[0]), reverse=True)
        batch_counts = {"scored": len(batches), "with_outcomes": len(with_outcomes), "awaiting_outcomes": len(pending),
                        "shown": len(realised)}  # fmt: skip
        active_definition = policies.get_active(rs, tenant_id, "churn_definition", required=False)
        definition = {"model_policy_id": dataset.policy_id, "active_policy_id": active_definition.id if active_definition else None}
        definition["changed"] = active_definition is not None and active_definition.id != dataset.policy_id
        dq = rs.execute(select(DQRun).where(DQRun.tenant_id == tenant_id, DQRun.status == "completed").order_by(DQRun.id.desc()).limit(1)).scalar_one_or_none()
        rules_policy = policies.get_active(rs, tenant_id, "alert_rules", required=False)
        rules = policies.parse(rules_policy) if rules_policy else policies.AlertRules.model_validate(policies.DEFAULT_ALERT_RULES)
        rules_source = f"approved policy v{rules_policy.version}" if rules_policy else "structural default (not an approved policy)"
        test_pr_auc = (run_row.test_metrics or {}).get("pr_auc")
        split_end = {split: max(info.get("as_of_dates") or [""]) for split, info in (dataset.class_balance or {}).items()}
        version_id, dq_score, dq_id = version.id, (dq.score if dq else None), (dq.id if dq else None)
        latest_info = {"batch_id": latest.id, "as_of_date": latest.as_of_date.isoformat()} if latest else None
    reference_info = {"source": "training split", "rows": int(len(train)), "dataset_id": dataset.id}
    feat = feature_drift(train[names], current[names] if len(current) else current, names)
    if with_evidently and feat["status"] != "insufficient_data":
        feat["evidently"] = evidently_summary(train[names], current[names])  # every contract feature, numeric and categorical
    ref_probs = training.predict_proba(bundle, valid)
    if len(cur_probs) >= MIN_ROWS:
        value = psi_numeric(ref_probs, cur_probs)
        pred = {"status": status_for(value), "psi": value, "mean_reference": float(ref_probs.mean()), "mean_current": float(cur_probs.mean()),
                "rows": {"reference": int(len(ref_probs)), "current": int(len(cur_probs))}, "reference": "validation-split scores"}  # fmt: skip
    else:
        pred = {"status": "insufficient_data", "reason": f"a completed batch with at least {MIN_ROWS} scored customers is needed", "psi": None,
                "rows": {"reference": int(len(ref_probs)), "current": int(len(cur_probs))}}  # fmt: skip
    perf_rows = []
    for batch_id, as_of, rows in realised:
        if len(rows) < MIN_ROWS:
            perf_rows.append({"batch_id": batch_id, "as_of_date": as_of.isoformat(), "status": "insufficient_data", "labelled": len(rows),
                              "reason": "outcomes for this scoring date are not mature yet (or labels have not been regenerated)"})  # fmt: skip
            continue
        y, p = np.array([r[1] for r in rows]), np.array([r[0] for r in rows])
        sample = sample_of(as_of.isoformat(), split_end)
        perf_rows.append({"batch_id": batch_id, "as_of_date": as_of.isoformat(), "labelled": len(rows), "sample": sample,
                          **realised_performance(y, p, test_pr_auc)})  # fmt: skip
    # dates the model was fitted or tuned on would flatter it, so they never drive alert rules
    measured = [r for r in perf_rows if r["status"] == "ok" and r["sample"] in ("test_period", "after_model_data")]
    newest = measured[0] if measured else None
    concept = {"status": "insufficient_data" if not newest else "ok", "batches": perf_rows, "reference_pr_auc": test_pr_auc,
               "latest": newest, "reason": None if newest else "no scored batch has mature outcomes yet",
               "batch_counts": batch_counts, "churn_definition": definition,
               "sample_legend": {"test_period": "back-test on a date that was part of the final test evaluation (out of sample "
                                                "for fitting, not new evidence)",
                                 "after_model_data": "scored after the model's data window: genuine post-deployment evidence",
                                 "in_sample_training": "the model was fitted on this date: shown for completeness, never alerts on it",
                                 "validation_period": "used for model selection and threshold tuning: never alerts on it"}}  # fmt: skip
    observed = {"feature_drift_share": feat.get("drifted_share"), "prediction_psi": pred.get("psi"),
                "pr_auc_drop": newest["pr_auc_drop"] if newest else None, "pr_auc_min": newest["pr_auc"] if newest else None,
                "dq_score_min": dq_score, "missing_rate_increase": feat.get("max_missing_rate_increase")}  # fmt: skip
    fired = []
    for rule in rules.rules:
        value = observed.get(rule.metric)
        if value is not None and _OPS[rule.operator](value, rule.threshold):
            fired.append({"metric": rule.metric, "operator": rule.operator, "threshold": rule.threshold, "value": float(value), "severity": rule.severity})
    retrain = sorted({f["metric"] for f in fired} & set(rules.retrain_on))
    if concept["status"] == "ok" and any(f["metric"] in ("pr_auc_drop", "pr_auc_min") for f in fired):
        concept["status"] = "alert"
    with session_scope() as ws:
        ids = {}
        for kind, result in (("feature", feat), ("prediction", pred), ("concept", concept)):
            current_info = {**latest_info, "feature_source": feature_source} if kind == "feature" and latest_info else latest_info
            report = DriftReport(tenant_id=tenant_id, kind=kind, engine="native", model_version_id=version_id, status=result["status"],
                                 reference=reference_info, current=current_info, result=json_safe(result), job_id=ctx.job_id if ctx else None)  # fmt: skip
            ws.add(report)
            ws.flush()
            ids[kind] = report.id
        source = {"feature_drift_share": "feature", "missing_rate_increase": "feature", "prediction_psi": "prediction",
                  "pr_auc_drop": "concept", "pr_auc_min": "concept"}  # fmt: skip
        created = 0
        for item in fired:
            created += raise_alert(ws, tenant_id, kind=f"rule:{item['metric']}", severity=item["severity"],
                                    title=f"{item['metric'].replace('_', ' ')} {item['operator']} {item['threshold']} (observed {item['value']:.4f})",
                                    source_type="dq_run" if item["metric"] == "dq_score_min" else "drift_report",
                                    source_id=dq_id if item["metric"] == "dq_score_min" else ids[source[item["metric"]]], detail=item)  # fmt: skip
        if definition["changed"]:
            created += raise_alert(ws, tenant_id, kind="churn_definition_changed", severity="warning", source_type="model_version",
                                   source_id=version_id, detail=definition, title="The production model predates the active churn definition",
                                   message="The production model was trained under an earlier churn definition. Outcomes are now labelled "
                                           "under the active definition, so this model's realised performance can no longer be measured. "
                                           "Train and approve a model under the active definition.")  # fmt: skip
        retraining = None
        if retrain:
            from . import retraining as retraining_service  # imported here: retraining builds on the pipeline, which imports this module

            retraining = retraining_service.trigger(ws, tenant_id=tenant_id, model_version_id=version_id, triggered_by=retrain,
                                                    created_by=ctx.created_by if ctx else None, enabled=rules.auto_retrain,
                                                    source_report_id=ids["concept"])  # fmt: skip
            if retraining["triggered"]:
                created += raise_alert(ws, tenant_id, kind="retraining_started", severity="critical", title="Automatic retraining started",
                                       source_type="job", source_id=retraining["job_id"], detail={"triggered_by": retrain, **retraining},
                                       message="Realised model performance breached the retraining rule, so new candidates are being "
                                               "trained on the latest outcomes. They must be evaluated and approved by a second person; "
                                               "nothing is promoted automatically.")  # fmt: skip
            else:
                created += raise_alert(ws, tenant_id, kind="retraining_recommended", severity="critical", title="Retraining recommended",
                                       source_type="drift_report", source_id=ids["concept"], detail={"triggered_by": retrain, **retraining},
                                       message="Realised model performance breached the retraining rule. No automatic retraining was "
                                               f"started: {retraining['reason']}. Train a new model version and submit it for approval; "
                                               "nothing is promoted automatically.")  # fmt: skip
        audit.record(ws, tenant_id=tenant_id, action="monitoring.completed", entity_type="model_version", entity_id=version_id,
                     detail={"reports": ids, "rules_fired": len(fired), "retraining_recommended": bool(retrain), "retraining": retraining})  # fmt: skip
    return {"reports": ids, "statuses": {"feature": feat["status"], "prediction": pred["status"], "concept": concept["status"]},
            "rules": rules_source, "rules_fired": fired, "alerts_created": created, "retraining_recommended": bool(retrain),
            "retraining": retraining}  # fmt: skip


def raise_alert(session: Session, tenant_id: int, *, kind: str, severity: str, title: str, source_type: str, source_id: int | None,
                detail: dict, message: str | None = None) -> int:
    """Open an alert, or refresh the active alert of the same kind.  Returns the number of alerts created (0 or 1).

    An acknowledged alert stays acknowledged while its condition persists (acknowledging silences it,
    it does not make it come back every night); only a resolved alert is raised afresh."""
    existing = session.execute(select(Alert).where(Alert.tenant_id == tenant_id, Alert.kind == kind, Alert.status.in_(("open", "acknowledged")))
                               .order_by(Alert.id.desc())).scalars().first()  # fmt: skip
    if existing is not None:  # one active alert per kind: refresh it instead of piling up duplicates
        existing.title, existing.detail, existing.source_type, existing.source_id = title[:200], json_safe(detail), source_type, source_id
        if message is not None:
            existing.message = message
        return 0
    session.add(Alert(tenant_id=tenant_id, kind=kind, severity=severity, title=title[:200], message=message, source_type=source_type,
                      source_id=source_id, detail=json_safe(detail)))  # fmt: skip
    return 1


def acknowledge(session: Session, principal: Principal, alert_id: int, resolve: bool = False) -> Alert:
    from ..db import utcnow

    alert = get_owned(session, Alert, principal.tenant_id, alert_id, label="Alert")
    if alert.status == "resolved":
        raise Conflict("this alert is already resolved")
    alert.status = "resolved" if resolve else "acknowledged"
    alert.acknowledged_by, alert.acknowledged_at = principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action=f"alert.{alert.status}", entity_type="alert", entity_id=alert.id)
    return alert


def latest_reports(session: Session, tenant_id: int) -> dict:
    out = {}
    for kind in ("feature", "prediction", "concept"):
        report = session.execute(select(DriftReport).where(DriftReport.tenant_id == tenant_id, DriftReport.kind == kind)
                                 .order_by(DriftReport.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
        out[kind] = to_dict(report) if report else None
    return out


def model_version_or_none(session: Session, tenant_id: int) -> ModelVersion | None:
    try:
        return registry.production_version(session, tenant_id)
    except (NotFound, Conflict):
        return None
