"""Model training: baseline + tree ensembles, class-imbalance handling, temporal cross-validation,
out-of-fold calibration, hash-verified artifacts.  The TEST split is never read here."""

from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import time
import uuid
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import read_session, session_scope
from ..errors import ValidationFailed
from ..logging_setup import get_logger
from ..models import MLDataset, ModelRun
from ..security import Principal
from . import audit, jobs, mlprep
from .common import get_owned, json_safe, to_dict

log = get_logger("training")
ALGORITHMS = ("logistic_regression", "random_forest", "xgboost", "lightgbm")
IMBALANCE = ("auto", "class_weight", "smote", "none")
_MODULE = {"logistic_regression": "sklearn", "random_forest": "sklearn", "xgboost": "xgboost", "lightgbm": "lightgbm"}
_DIST = {"sklearn": "scikit-learn", "xgboost": "xgboost-cpu", "lightgbm": "lightgbm"}
N_JOBS = 2

SEARCH_SPACE: dict[str, dict[str, list]] = {
    "logistic_regression": {"C": [0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0]},
    "random_forest": {"n_estimators": [200, 400], "max_depth": [4, 6, 8, None], "min_samples_leaf": [5, 10, 20], "max_features": ["sqrt", 0.3]},
    "xgboost": {"n_estimators": [150, 300], "max_depth": [2, 3, 4], "learning_rate": [0.03, 0.06, 0.1], "subsample": [0.7, 0.9],
                "colsample_bytree": [0.6, 0.8], "min_child_weight": [1, 5], "reg_lambda": [1.0, 5.0]},
    "lightgbm": {"n_estimators": [150, 300], "num_leaves": [7, 15], "learning_rate": [0.03, 0.06, 0.1], "min_child_samples": [10, 20],
                 "subsample": [0.7, 0.9], "colsample_bytree": [0.6, 0.8], "reg_lambda": [1.0, 5.0]},
}  # fmt: skip
DEFAULTS: dict[str, dict] = {
    "logistic_regression": {"C": 0.1},
    "random_forest": {"n_estimators": 300, "max_depth": 6, "min_samples_leaf": 10, "max_features": "sqrt"},
    "xgboost": {"n_estimators": 200, "max_depth": 3, "learning_rate": 0.06, "subsample": 0.9, "colsample_bytree": 0.8,
                "min_child_weight": 1, "reg_lambda": 1.0},
    "lightgbm": {"n_estimators": 200, "num_leaves": 7, "learning_rate": 0.06, "min_child_samples": 20, "subsample": 0.9,
                 "colsample_bytree": 0.8, "reg_lambda": 1.0},
}  # fmt: skip


def algorithm_status() -> dict[str, dict]:
    """Which algorithms can run in this installation (missing optional libraries are reported, not hidden)."""
    out = {}
    for algo, module in _MODULE.items():
        try:
            importlib.import_module(module)
            dist = _DIST[module]
            try:
                version = importlib.metadata.version(dist)
            except importlib.metadata.PackageNotFoundError:
                version = importlib.metadata.version(module)
            out[algo] = {"available": True, "version": version, "reason": None}
        except Exception as exc:  # any import failure makes the algorithm unavailable
            out[algo] = {"available": False, "version": None, "reason": f"{module} cannot be imported: {exc}"}
    return out


def resolve_imbalance(algorithm: str, imbalance: str) -> str:
    if imbalance != "auto":
        return imbalance
    return "class_weight"  # scale_pos_weight for the boosters, class_weight='balanced' for sklearn models


def build_estimator(algorithm: str, params: dict, imbalance: str, y: np.ndarray, seed: int, sampler: Any = None) -> Any:
    """Build an unfitted estimator.  With ``smote`` the sampler is a pipeline step, so it only ever
    resamples the data passed to ``fit`` (the training fold) and never the data being scored."""
    n_pos = int(y.sum())
    n_neg = int(len(y) - n_pos)
    weighted = imbalance == "class_weight"
    spw = (n_neg / max(n_pos, 1)) if weighted else 1.0
    if algorithm == "logistic_regression":
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler

        model = LogisticRegression(C=params["C"], class_weight="balanced" if weighted else None, max_iter=3000, random_state=seed)
        steps = [("scale", StandardScaler()), ("model", model)]
    elif algorithm == "random_forest":
        from sklearn.ensemble import RandomForestClassifier

        model = RandomForestClassifier(**params, class_weight="balanced_subsample" if weighted else None, n_jobs=N_JOBS,
                                       random_state=seed)  # fmt: skip
        steps = [("model", model)]
    elif algorithm == "xgboost":
        from xgboost import XGBClassifier

        model = XGBClassifier(**params, scale_pos_weight=spw, tree_method="hist", n_jobs=N_JOBS, random_state=seed,
                              eval_metric="aucpr", verbosity=0)  # fmt: skip
        steps = [("model", model)]
    elif algorithm == "lightgbm":
        from lightgbm import LGBMClassifier

        model = LGBMClassifier(**params, subsample_freq=1, scale_pos_weight=spw, n_jobs=N_JOBS, random_state=seed, verbose=-1,
                               deterministic=True, force_row_wise=True)  # fmt: skip
        steps = [("model", model)]
    else:
        raise ValueError(f"unknown algorithm {algorithm}")
    if imbalance == "smote":
        from imblearn.over_sampling import SMOTE
        from imblearn.pipeline import Pipeline as ImbPipeline

        if n_pos < 2:
            raise ValueError("SMOTE needs at least two positive examples in the training fold")
        smote = sampler if sampler is not None else SMOTE(random_state=seed, k_neighbors=min(5, n_pos - 1))
        return ImbPipeline([*steps[:-1], ("smote", smote), steps[-1]])
    from sklearn.pipeline import Pipeline

    return Pipeline(steps)


def sample_candidates(algorithm: str, n_iter: int, seed: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    space = SEARCH_SPACE[algorithm]
    out, seen = [dict(DEFAULTS[algorithm])], {repr(sorted(DEFAULTS[algorithm].items(), key=str))}
    attempts = 0
    while len(out) < n_iter and attempts < 200:
        attempts += 1
        cand = {k: v[int(rng.integers(0, len(v)))] for k, v in space.items()}
        key = repr(sorted(cand.items(), key=str))
        if key not in seen:
            seen.add(key)
            out.append(cand)
    return out


def _fit_calibrator(scores: np.ndarray, y: np.ndarray) -> dict:
    """Map raw scores to calibrated probabilities using out-of-fold predictions from the train split."""
    from sklearn.isotonic import IsotonicRegression
    from sklearn.linear_model import LogisticRegression

    if int(y.sum()) >= 300:
        iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0).fit(scores, y)
        return {"method": "isotonic", "model": iso}
    platt = LogisticRegression(C=1e6, max_iter=1000).fit(_logit(scores).reshape(-1, 1), y)
    return {"method": "sigmoid", "model": platt}


def _logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def apply_calibrator(calibrator: dict | None, scores: np.ndarray) -> np.ndarray:
    if not calibrator:
        return scores
    if calibrator["method"] == "isotonic":
        return np.clip(calibrator["model"].predict(scores), 0.0, 1.0)
    return calibrator["model"].predict_proba(_logit(scores).reshape(-1, 1))[:, 1]


def raw_scores(bundle: dict, raw: pd.DataFrame) -> tuple[np.ndarray, pd.DataFrame]:
    X = mlprep.transform(bundle["prep"], raw[bundle["features"]])
    return bundle["model"].predict_proba(X.to_numpy())[:, 1], X


def predict_proba(bundle: dict, raw: pd.DataFrame) -> np.ndarray:
    """Calibrated churn probability for raw (contract-ordered) feature rows."""
    scores, _ = raw_scores(bundle, raw)
    return apply_calibrator(bundle.get("calibrator"), scores)


# ----------------------------------------------------------------------------- artifacts
def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        while chunk := fh.read(1 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def save_bundle(tenant_id: int, run_id: int, bundle: dict) -> tuple[str, str]:
    folder = get_settings().data_dir / "models" / str(tenant_id)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"run-{run_id}.joblib"
    joblib.dump(bundle, path, compress=3)
    return storage.to_stored(path), sha256_path(path)


_BUNDLE_CACHE: dict[tuple[str, str], dict] = {}


def load_bundle(run: ModelRun) -> dict:
    """Load a model artifact only after verifying it is byte-identical to what training produced.

    Artifacts are joblib/pickle files written exclusively by this platform; the SHA-256 recorded in
    the database at training time is checked before deserialisation so a modified file is refused.
    """
    if not run.artifact_path or not run.artifact_sha256:
        raise RuntimeError(f"model run {run.id} has no artifact")
    path = storage.resolve(run.artifact_path)
    key = (str(path), run.artifact_sha256)
    if key not in _BUNDLE_CACHE:
        if not path.is_file():
            raise RuntimeError(f"model artifact for run {run.id} is missing from storage")
        if sha256_path(path) != run.artifact_sha256:
            raise RuntimeError(f"model artifact for run {run.id} failed its SHA-256 integrity check; refusing to load it")
        if len(_BUNDLE_CACHE) >= 8:
            _BUNDLE_CACHE.pop(next(iter(_BUNDLE_CACHE)))
        # Deserialised only after the SHA-256 check above: the file is byte-identical to what this platform wrote.
        _BUNDLE_CACHE[key] = joblib.load(path)  # nosec B301
    return _BUNDLE_CACHE[key]


# ----------------------------------------------------------------------------- training
def start_training(session: Session, principal: Principal, *, dataset_id: int, algorithms: list[str] | None = None,
                   imbalance: str = "auto", n_iter: int = 6, cv_folds: int = 3, seed: int = 42) -> tuple[list[ModelRun], Any]:
    dataset = mlprep.require_ready(get_owned(session, MLDataset, principal.tenant_id, dataset_id, label="Dataset"))
    algorithms = list(algorithms or ALGORITHMS)
    unknown = [a for a in algorithms if a not in ALGORITHMS]
    if unknown or not algorithms:
        raise ValidationFailed(f"algorithms must be chosen from {', '.join(ALGORITHMS)}", details={"field": "algorithms"})
    if imbalance not in IMBALANCE:
        raise ValidationFailed(f"imbalance must be one of {', '.join(IMBALANCE)}", details={"field": "imbalance"})
    if not 1 <= n_iter <= 40 or not 2 <= cv_folds <= 6:
        raise ValidationFailed("n_iter must be 1-40 and cv_folds 2-6", details={"field": "n_iter"})
    group = uuid.uuid4().hex[:12]
    status = algorithm_status()
    runs = []
    for algo in dict.fromkeys(algorithms):
        ok = status[algo]["available"]
        run = ModelRun(tenant_id=principal.tenant_id, dataset_id=dataset.id, group_id=group, algorithm=algo, seed=seed,
                       imbalance_strategy=resolve_imbalance(algo, imbalance), is_baseline=algo == "logistic_regression",
                       status="running" if ok else "unavailable", error=None if ok else status[algo]["reason"],
                       search={"n_iter": n_iter, "cv_folds": cv_folds}, created_by=principal.user_id)  # fmt: skip
        session.add(run)
        runs.append(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="ml.train", created_by=principal.user_id,
                       payload={"group_id": group, "run_ids": [r.id for r in runs if r.status == "running"]})  # fmt: skip
    for run in runs:
        run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="ml.training_started", entity_type="ml_dataset",
                 entity_id=dataset.id, detail={"group_id": group, "algorithms": algorithms, "imbalance": imbalance, "seed": seed})  # fmt: skip
    return runs, job


def fit_estimator(estimator: Any, X: np.ndarray, y: np.ndarray) -> Any:
    """Fit an estimator built by ``build_estimator`` and make its predictions independent of thread timing.

    scikit-learn's random forest adds up the votes of its trees in the order its worker threads finish.
    With more than one thread the last bits of a probability therefore change from call to call, which is
    enough to move a customer across a calibration step or a tier boundary.  Fitting is reproducible on any
    number of threads, so the forest is fitted in parallel and then predicts on one thread, in tree order.
    """
    from sklearn.ensemble import RandomForestClassifier

    estimator.fit(X, y)
    model = estimator.named_steps["model"]
    if isinstance(model, RandomForestClassifier):
        model.set_params(n_jobs=1)
    return estimator


def fit_one(algorithm: str, imbalance: str, train: pd.DataFrame, valid: pd.DataFrame, prep: dict, feature_names: list[str],
            horizon_days: int, embargo_days: int, n_iter: int, cv_folds: int, seed: int, check: Any = None) -> dict:
    """Search, cross-validate, calibrate and fit one algorithm.  Uses TRAIN and VALIDATION only."""
    from sklearn.metrics import average_precision_score

    from . import evaluation

    X_train = mlprep.transform(prep, train[feature_names]).to_numpy()
    y_train = train["label"].to_numpy()
    folds = mlprep.temporal_folds(sorted(train["as_of_date"].unique()), cv_folds, horizon_days, embargo_days)
    fold_idx = []
    for fit_dates, val_dates in folds:
        fit_mask, val_mask = train["as_of_date"].isin(fit_dates).to_numpy(), train["as_of_date"].isin(val_dates).to_numpy()
        if y_train[fit_mask].sum() >= 2 and 0 < y_train[val_mask].sum() < val_mask.sum():
            fold_idx.append((fit_mask, val_mask, fit_dates, val_dates))
    if not fold_idx:
        raise jobs.PermanentJobError("temporal cross-validation is impossible: no fold has churners on both sides")
    candidates, best = [], None
    for params in sample_candidates(algorithm, n_iter, seed):
        scores, oof_y, oof_p = [], [], []
        for fit_mask, val_mask, _fd, _vd in fold_idx:
            if check is not None:
                check()
            est = fit_estimator(build_estimator(algorithm, params, imbalance, y_train[fit_mask], seed), X_train[fit_mask], y_train[fit_mask])
            p = est.predict_proba(X_train[val_mask])[:, 1]
            scores.append(float(average_precision_score(y_train[val_mask], p)))
            oof_y.append(y_train[val_mask])
            oof_p.append(p)
        entry = {"params": params, "cv_pr_auc_mean": float(np.mean(scores)), "cv_pr_auc_std": float(np.std(scores)), "folds": scores}
        candidates.append(entry)
        if best is None or entry["cv_pr_auc_mean"] > best[0]["cv_pr_auc_mean"] + 1e-12:
            best = (entry, np.concatenate(oof_y), np.concatenate(oof_p))
    entry, oof_y, oof_p = best
    calibrator = _fit_calibrator(oof_p, oof_y)
    model = fit_estimator(build_estimator(algorithm, entry["params"], imbalance, y_train, seed), X_train, y_train)
    bundle = {"algorithm": algorithm, "imbalance": imbalance, "model": model, "calibrator": calibrator, "prep": prep,
              "features": list(feature_names), "columns": list(prep["columns"]), "seed": seed, "params": entry["params"],
              "background_mean": X_train.mean(axis=0)}  # fmt: skip
    raw_valid, _ = raw_scores(bundle, valid)
    cal_valid = apply_calibrator(calibrator, raw_valid)
    y_valid = valid["label"].to_numpy()
    valid_metrics = evaluation.core_metrics(y_valid, cal_valid, seed=seed)
    uncal = evaluation.core_metrics(y_valid, raw_valid, seed=seed, bootstrap=0)
    return {
        "bundle": bundle, "params": entry["params"], "valid_metrics": valid_metrics,
        "search": {"n_iter": len(candidates), "cv_folds": len(fold_idx), "candidates": candidates,
                   "folds": [{"fit_dates": [d.isoformat() for d in fd], "validate_dates": [d.isoformat() for d in vd]}
                             for _f, _v, fd, vd in fold_idx],
                   "selection_metric": "mean PR-AUC (average precision) over temporal folds of the TRAIN split"},
        "cv_metrics": {"pr_auc_mean": entry["cv_pr_auc_mean"], "pr_auc_std": entry["cv_pr_auc_std"], "folds": entry["folds"]},
        "calibration": {"method": calibrator["method"], "fitted_on": "out-of-fold predictions of the TRAIN split",
                        "valid_brier_raw": uncal["brier"], "valid_brier_calibrated": valid_metrics["brier"],
                        "valid_ece_raw": uncal["ece"], "valid_ece_calibrated": valid_metrics["ece"]},
    }  # fmt: skip


def run_training(run_ids: list[int], ctx: Any = None) -> dict:
    """Train every requested algorithm in turn; one failure never hides the others."""
    summary = []
    for n, run_id in enumerate(run_ids):
        started = time.monotonic()
        with read_session() as rs:
            run = rs.get(ModelRun, run_id)
            dataset = rs.get(MLDataset, run.dataset_id)
            cfg, prep, tenant_id = dict(dataset.config), dataset.preprocessing, run.tenant_id
            algorithm, imbalance, seed, search = run.algorithm, run.imbalance_strategy, run.seed, dict(run.search or {})
            train = mlprep.load_split(dataset, "train")
            valid = mlprep.load_split(dataset, "valid")
            fingerprint, contract_id = dataset.fingerprint, dataset.contract_id
        if ctx is not None:
            ctx.progress(n / max(1, len(run_ids)), f"training {algorithm} ({n + 1}/{len(run_ids)})", force=True)
        try:
            feature_names = [c for c in train.columns if c not in mlprep.META_COLUMNS]
            result = fit_one(algorithm, imbalance, train, valid, prep, feature_names, int(cfg["horizon_days"]),
                             int(cfg["embargo_days"]), int(search.get("n_iter", 6)), int(search.get("cv_folds", 3)), seed,
                             check=ctx.check if ctx is not None else None)  # fmt: skip
            bundle = result["bundle"]
            bundle.update({"dataset_id": run.dataset_id, "dataset_fingerprint": fingerprint, "contract_id": contract_id,
                           "contract_schema_hash": cfg["contract_schema_hash"], "horizon_days": int(cfg["horizon_days"]),
                           "library_versions": {k: v["version"] for k, v in algorithm_status().items()}, "run_id": run_id})  # fmt: skip
            path, digest = save_bundle(tenant_id, run_id, bundle)
            duration = round(time.monotonic() - started, 3)
            with session_scope() as ws:
                ws.execute(update(ModelRun).where(ModelRun.id == run_id).values(
                    status="completed", params=json_safe(result["params"]), search=json_safe(result["search"]),
                    cv_metrics=json_safe(result["cv_metrics"]), valid_metrics=json_safe(result["valid_metrics"]),
                    calibration=json_safe(result["calibration"]), artifact_path=path, artifact_sha256=digest,
                    duration_seconds=duration, error=None))  # fmt: skip
                audit.record(ws, tenant_id=tenant_id, action="ml.model_trained", entity_type="model_run", entity_id=run_id,
                             detail={"algorithm": algorithm, "valid_pr_auc": result["valid_metrics"]["pr_auc"],
                                     "artifact_sha256": digest})  # fmt: skip
            summary.append({"run_id": run_id, "algorithm": algorithm, "status": "completed",
                            "valid_pr_auc": result["valid_metrics"]["pr_auc"]})  # fmt: skip
        except (jobs.JobCancelled, jobs.JobInterrupted):
            raise
        except Exception as exc:
            log.exception("training failed", extra={"ctx": {"run_id": run_id, "algorithm": algorithm}})
            with session_scope() as ws:
                ws.execute(update(ModelRun).where(ModelRun.id == run_id).values(
                    status="failed", error=f"{type(exc).__name__}: {exc}"[:2000], duration_seconds=round(time.monotonic() - started, 3)))  # fmt: skip
            summary.append({"run_id": run_id, "algorithm": algorithm, "status": "failed", "error": str(exc)[:300]})
    if summary and all(s["status"] == "failed" for s in summary):
        raise jobs.PermanentJobError("every requested algorithm failed to train: " + "; ".join(s["error"] for s in summary))
    return {"runs": summary}


def run_view(run: ModelRun, *, full: bool = False) -> dict:
    view = to_dict(run, exclude={"artifact_path"} | (set() if full else {"search"}))
    view["valid_pr_auc"] = (run.valid_metrics or {}).get("pr_auc")
    view["valid_roc_auc"] = (run.valid_metrics or {}).get("roc_auc")
    view["test_pr_auc"] = (run.test_metrics or {}).get("pr_auc")
    return view


def leaderboard(session: Session, tenant_id: int, dataset_id: int | None = None) -> list[dict]:
    """Runs ranked by VALIDATION PR-AUC (the test split plays no part in ranking)."""
    stmt = select(ModelRun).where(ModelRun.tenant_id == tenant_id)
    if dataset_id:
        stmt = stmt.where(ModelRun.dataset_id == dataset_id)
    runs = session.execute(stmt.order_by(ModelRun.id.desc()).limit(500)).scalars().all()
    ranked = sorted(runs, key=lambda r: (r.status != "completed", -((r.valid_metrics or {}).get("pr_auc") or 0.0), r.id))
    return [run_view(r) for r in ranked]
