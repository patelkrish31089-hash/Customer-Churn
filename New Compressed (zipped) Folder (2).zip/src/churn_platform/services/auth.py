"""Authentication, sessions, MFA (TOTP) and user administration."""

from __future__ import annotations

from datetime import timedelta

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, NotFound, Unauthorized, ValidationFailed
from ..models import AuthSession, Tenant, User
from ..security import (
    ROLE_PERMISSIONS,
    ROLES,
    Principal,
    SecretBox,
    burn_password_check,
    hash_password,
    hash_token,
    new_token,
    password_problems,
    totp_new_secret,
    totp_uri,
    totp_verify,
    verify_password,
)
from . import audit
from .common import get_owned, to_dict

SYSTEM_TENANT_SLUG = "system"
_TOUCH_INTERVAL = timedelta(seconds=60)


def ensure_system_tenant(session: Session) -> Tenant:
    tenant = session.execute(select(Tenant).where(Tenant.slug == SYSTEM_TENANT_SLUG)).scalar_one_or_none()
    if tenant is None:
        tenant = Tenant(slug=SYSTEM_TENANT_SLUG, name="System", is_system=True)
        session.add(tenant)
        session.flush()
    return tenant


def create_tenant(session: Session, slug: str, name: str) -> Tenant:
    slug = slug.strip().lower()
    if not slug or not slug.replace("-", "").isalnum():
        raise ValidationFailed("tenant slug must be alphanumeric (dashes allowed)")
    if session.execute(select(Tenant).where(Tenant.slug == slug)).scalar_one_or_none():
        raise Conflict(f"tenant '{slug}' already exists")
    ensure_system_tenant(session)
    tenant = Tenant(slug=slug, name=name)
    session.add(tenant)
    session.flush()
    audit.record(session, tenant_id=tenant.id, action="tenant.created", entity_type="tenant", entity_id=tenant.id,
                 detail={"slug": slug})  # fmt: skip
    return tenant


def create_user(session: Session, *, tenant_id: int, email: str, full_name: str, role: str, password: str | None,
                actor: Principal | None = None) -> User:
    email = email.strip().lower()
    if role not in ROLES:
        raise ValidationFailed(f"role must be one of {', '.join(ROLES)}", details={"field": "role"})
    if "@" not in email or len(email) > 320:
        raise ValidationFailed("a valid email address is required", details={"field": "email"})
    if not full_name.strip():
        raise ValidationFailed("full name is required", details={"field": "full_name"})
    if password is not None:
        problems = password_problems(password, get_settings().password_min_length)
        if problems:
            raise ValidationFailed("password " + "; ".join(problems), details={"field": "password"})
    if session.execute(select(User.id).where(User.email == email)).first():
        raise Conflict("a user with this email already exists")
    user = User(tenant_id=tenant_id, email=email, full_name=full_name.strip(), role=role,
                password_hash=hash_password(password) if password else None, password_changed_at=utcnow())  # fmt: skip
    session.add(user)
    session.flush()
    audit.record(session, tenant_id=tenant_id, actor=actor, action="user.created", entity_type="user",
                 entity_id=user.id, detail={"email": email, "role": role})  # fmt: skip
    return user


def _fail(session: Session, tenant_id: int, email: str, reason: str, *, code: str = "invalid_credentials",
          message: str = "Invalid email or password") -> Unauthorized:
    audit.record(session, tenant_id=tenant_id, action="auth.login_failed", actor_label=email[:320],
                 entity_type="user", detail={"reason": reason})  # fmt: skip
    session.commit()  # failed-login bookkeeping must survive the error response
    return Unauthorized(message, code=code)


def login(session: Session, *, email: str, password: str, otp: str | None = None, ip: str | None = None,
          user_agent: str | None = None) -> dict:
    settings = get_settings()
    email = (email or "").strip().lower()
    now = utcnow()
    user = session.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if user is None:
        burn_password_check(password or "")
        raise _fail(session, ensure_system_tenant(session).id, email, "unknown_user")
    if user.locked_until and user.locked_until > now:
        burn_password_check(password or "")
        raise _fail(session, user.tenant_id, email, "locked", code="account_locked",
                    message="Account is temporarily locked after repeated failed sign-ins")  # fmt: skip
    ok = verify_password(password or "", user.password_hash)
    mfa_ok = True
    if ok and user.is_active and user.mfa_enabled:
        if not otp:
            raise Unauthorized("A one-time code is required", code="mfa_required")
        secret = SecretBox().decrypt(user.mfa_secret_enc)
        counter = totp_verify(secret, otp.strip(), last_counter=user.mfa_last_counter)
        mfa_ok = counter is not None
        if mfa_ok:
            user.mfa_last_counter = counter
    if not ok or not mfa_ok:
        user.failed_logins += 1
        if user.failed_logins >= settings.login_max_failures:
            user.locked_until = now + timedelta(minutes=settings.login_lockout_minutes)
            user.failed_logins = 0
        raise _fail(session, user.tenant_id, email, "bad_password" if not ok else "bad_otp")
    if not user.is_active:
        raise _fail(session, user.tenant_id, email, "inactive")

    token, token_hash = new_token()
    enrollment_required = user.role in settings.mfa_required_role_set and not user.mfa_enabled
    auth_session = AuthSession(
        tenant_id=user.tenant_id, user_id=user.id, token_hash=token_hash, auth_method="password",
        mfa_verified=bool(user.mfa_enabled), ip=(ip or "")[:64] or None, user_agent=(user_agent or "")[:300] or None,
        last_seen_at=now, expires_at=now + timedelta(minutes=settings.session_ttl_minutes),
    )  # fmt: skip
    session.add(auth_session)
    user.failed_logins, user.locked_until, user.last_login_at = 0, None, now
    session.flush()
    audit.record(session, tenant_id=user.tenant_id, action="auth.login", actor_label=user.email, entity_type="user",
                 entity_id=user.id, detail={"session_id": auth_session.id, "mfa": bool(user.mfa_enabled)})  # fmt: skip
    return {"token": token, "expires_at": auth_session.expires_at.isoformat(), "user": user_view(user),
            "mfa_enrollment_required": enrollment_required}  # fmt: skip


def authenticate(session: Session, token: str | None) -> Principal:
    if not token:
        raise Unauthorized("Authentication is required")
    settings = get_settings()
    row = session.execute(
        select(AuthSession, User).join(User, User.id == AuthSession.user_id).where(AuthSession.token_hash == hash_token(token))
    ).first()  # fmt: skip
    if row is None:
        raise Unauthorized("Session is not valid", code="session_invalid")
    auth_session, user = row
    now = utcnow()
    if auth_session.revoked_at is not None:
        raise Unauthorized("Session has been revoked", code="session_revoked")
    if auth_session.expires_at <= now:
        if auth_session.revoked_reason == "rotated":
            # a token that was replaced is being presented after its grace period: either a stale tab or a stolen copy
            raise RotatedTokenReused(auth_session.id, auth_session.tenant_id, user.email)
        raise Unauthorized("Session has expired", code="session_expired")
    idle_limit = timedelta(minutes=settings.session_idle_minutes)
    if auth_session.last_seen_at and auth_session.last_seen_at + idle_limit < now:
        raise Unauthorized("Session expired after inactivity", code="session_expired")
    if not user.is_active:
        raise Unauthorized("Account is disabled", code="account_disabled")
    if user.mfa_enabled and not auth_session.mfa_verified:
        # opened with the password alone: worthless once the account is protected by a second factor
        raise Unauthorized("Sign in again with a one-time code", code="mfa_required")
    # a second factor verified by a trusted identity provider satisfies the role's requirement for this session
    idp_second_factor = auth_session.auth_method == "oidc" and auth_session.mfa_verified
    enrollment_required = user.role in settings.mfa_required_role_set and not user.mfa_enabled and not idp_second_factor
    return Principal(
        user_id=user.id, tenant_id=user.tenant_id, email=user.email, role=user.role, session_id=auth_session.id,
        mfa_enrollment_required=enrollment_required,
        permissions=frozenset() if enrollment_required else ROLE_PERMISSIONS.get(user.role, frozenset()),
    )  # fmt: skip


def authenticate_token(token: str | None) -> Principal:
    """Resolve a bearer token to a principal.

    The lookup runs in its own read-only transaction and the (rate-limited) activity timestamp is
    written afterwards in a separate short transaction, so authentication never nests a write
    inside the request's own transaction.
    """
    try:
        with read_session() as s:
            principal = authenticate(s, token)
            last_seen = s.execute(select(AuthSession.last_seen_at).where(AuthSession.id == principal.session_id)).scalar()
    except RotatedTokenReused as reuse:
        with session_scope() as s:
            revoked, cursor = 0, [reuse.session_id]
            while cursor:  # everything that descends from the replaced token is revoked: nobody can tell which copy is the thief's
                children = s.execute(select(AuthSession).where(AuthSession.rotated_from.in_(cursor))).scalars().all()
                for child in children:
                    if child.revoked_at is None:
                        _revoke(child, "rotated_token_reused")
                        revoked += 1
                cursor = [c.id for c in children]
            audit.record(s, tenant_id=reuse.tenant_id, action="auth.rotated_token_reused", actor_label=reuse.email, entity_type="auth_session",
                         entity_id=reuse.session_id, detail={"sessions_revoked": revoked})  # fmt: skip
        raise Unauthorized("Session has expired", code="session_expired") from None
    now = utcnow()
    if last_seen is None or now - last_seen > _TOUCH_INTERVAL:
        with session_scope() as s:
            s.execute(update(AuthSession).where(AuthSession.id == principal.session_id).values(last_seen_at=now))
    return principal


class RotatedTokenReused(Exception):
    def __init__(self, session_id: int, tenant_id: int, email: str) -> None:
        super().__init__("rotated token reused")
        self.session_id, self.tenant_id, self.email = session_id, tenant_id, email


ROTATION_GRACE = timedelta(seconds=30)


def session_info(session: Session, principal: Principal) -> dict:
    """What the web app needs to know about its own session: when to replace the token and when it ends."""
    row = session.get(AuthSession, principal.session_id)
    rotate_after = row.created_at + timedelta(minutes=get_settings().session_rotate_minutes)
    return {"auth_method": row.auth_method, "expires_at": row.expires_at.isoformat(), "rotate_after": min(rotate_after, row.expires_at).isoformat(),
            "identity_provider_id": row.identity_provider_id}  # fmt: skip


def rotate(session: Session, principal: Principal) -> dict:
    """Replace the session's token.  The new session ends when the old one would have; the old token keeps working
    for a few seconds (requests already on their way) and never again after that."""
    old = session.get(AuthSession, principal.session_id)
    now = utcnow()
    token, token_hash = new_token()
    new = AuthSession(tenant_id=old.tenant_id, user_id=old.user_id, token_hash=token_hash, auth_method=old.auth_method, mfa_verified=old.mfa_verified,
                      ip=old.ip, user_agent=old.user_agent, last_seen_at=now, expires_at=old.expires_at, rotated_from=old.id,
                      identity_provider_id=old.identity_provider_id, id_token_enc=old.id_token_enc)  # fmt: skip
    session.add(new)
    old.expires_at, old.revoked_reason = min(old.expires_at, now + ROTATION_GRACE), "rotated"
    session.flush()
    audit.record(session, tenant_id=old.tenant_id, actor=principal, action="auth.session_rotated", entity_type="auth_session", entity_id=new.id,
                 detail={"replaces": old.id})  # fmt: skip
    rotate_after = now + timedelta(minutes=get_settings().session_rotate_minutes)
    return {"token": token, "expires_at": new.expires_at.isoformat(), "rotate_after": min(rotate_after, new.expires_at).isoformat()}


def _revoke(auth_session: AuthSession, reason: str) -> None:
    if auth_session.revoked_at is None:
        auth_session.revoked_at, auth_session.revoked_reason = utcnow(), reason


def logout(session: Session, principal: Principal) -> None:
    _revoke(session.get(AuthSession, principal.session_id), "logout")
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="auth.logout", entity_type="user",
                 entity_id=principal.user_id)  # fmt: skip


def revoke_session(session: Session, principal: Principal, session_id: int) -> AuthSession:
    target = get_owned(session, AuthSession, principal.tenant_id, session_id, label="Session")
    if target.user_id != principal.user_id and not principal.can("admin:sessions"):
        raise Forbidden("You can only revoke your own sessions")
    _revoke(target, "revoked_by_admin" if target.user_id != principal.user_id else "revoked_by_user")
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="auth.session_revoked",
                 entity_type="session", entity_id=session_id, detail={"user_id": target.user_id})  # fmt: skip
    return target


def revoke_user_sessions(session: Session, user_id: int, reason: str, *, except_session_id: int | None = None) -> int:
    stmt = select(AuthSession).where(AuthSession.user_id == user_id, AuthSession.revoked_at.is_(None))
    count = 0
    for auth_session in session.execute(stmt).scalars():
        if auth_session.id != except_session_id:
            _revoke(auth_session, reason)
            count += 1
    return count


def change_password(session: Session, principal: Principal, current: str, new: str) -> None:
    user = session.get(User, principal.user_id)
    if not verify_password(current, user.password_hash):
        raise ValidationFailed("current password is incorrect", details={"field": "current_password"})
    problems = password_problems(new, get_settings().password_min_length)
    if problems:
        raise ValidationFailed("password " + "; ".join(problems), details={"field": "new_password"})
    user.password_hash, user.password_changed_at = hash_password(new), utcnow()
    revoked = revoke_user_sessions(session, user.id, "password_changed", except_session_id=principal.session_id)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="user.password_changed",
                 entity_type="user", entity_id=user.id, detail={"other_sessions_revoked": revoked})  # fmt: skip


def mfa_begin(session: Session, principal: Principal) -> dict:
    user = session.get(User, principal.user_id)
    if user.mfa_enabled:
        raise Conflict("MFA is already enabled")
    secret = totp_new_secret()
    user.mfa_secret_enc = SecretBox().encrypt(secret)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="user.mfa_enrollment_started",
                 entity_type="user", entity_id=user.id)  # fmt: skip
    return {"secret": secret, "otpauth_uri": totp_uri(secret, user.email)}


def mfa_confirm(session: Session, principal: Principal, code: str) -> None:
    user = session.get(User, principal.user_id)
    if user.mfa_enabled or not user.mfa_secret_enc:
        raise Conflict("Start MFA enrolment first")
    counter = totp_verify(SecretBox().decrypt(user.mfa_secret_enc), (code or "").strip())
    if counter is None:
        raise ValidationFailed("The one-time code is not valid", details={"field": "code"})
    user.mfa_enabled, user.mfa_last_counter = True, counter
    # This session has just proven possession of the second factor.  Every other session of the user was opened
    # with the password alone (possibly by someone else who knows it), so none of them survives the enrolment.
    session.get(AuthSession, principal.session_id).mfa_verified = True
    revoked = revoke_user_sessions(session, user.id, "mfa_enabled", except_session_id=principal.session_id)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="user.mfa_enabled",
                 entity_type="user", entity_id=user.id, detail={"other_sessions_revoked": revoked})  # fmt: skip


def mfa_disable(session: Session, principal: Principal, password: str) -> None:
    user = session.get(User, principal.user_id)
    if not verify_password(password, user.password_hash):
        raise ValidationFailed("password is incorrect", details={"field": "password"})
    user.mfa_enabled, user.mfa_secret_enc, user.mfa_last_counter = False, None, None
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="user.mfa_disabled",
                 entity_type="user", entity_id=user.id)  # fmt: skip


def update_user(session: Session, principal: Principal, user_id: int, *, role: str | None = None,
                is_active: bool | None = None, password: str | None = None) -> User:
    user = get_owned(session, User, principal.tenant_id, user_id, label="User")
    changes: dict = {}
    if role is not None and role != user.role:
        if role not in ROLES:
            raise ValidationFailed(f"role must be one of {', '.join(ROLES)}", details={"field": "role"})
        if user.id == principal.user_id:
            raise Forbidden("You cannot change your own role")
        changes["role"] = [user.role, role]
        user.role = role
    if is_active is not None and is_active != user.is_active:
        if user.id == principal.user_id:
            raise Forbidden("You cannot deactivate yourself")
        changes["is_active"] = [user.is_active, is_active]
        user.is_active = is_active
    if password is not None:
        problems = password_problems(password, get_settings().password_min_length)
        if problems:
            raise ValidationFailed("password " + "; ".join(problems), details={"field": "password"})
        user.password_hash, user.password_changed_at = hash_password(password), utcnow()
        user.failed_logins, user.locked_until = 0, None
        changes["password_reset"] = True
    if changes:
        revoked = revoke_user_sessions(session, user.id, "account_changed", except_session_id=principal.session_id)
        audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="user.updated",
                     entity_type="user", entity_id=user.id, detail={**changes, "sessions_revoked": revoked})  # fmt: skip
    return user


def user_view(user: User) -> dict:
    view = to_dict(user, exclude={"failed_logins", "mfa_last_counter"})
    view["permissions"] = sorted(ROLE_PERMISSIONS.get(user.role, frozenset()))
    return view


def get_user_or_404(session: Session, tenant_id: int, user_id: int) -> User:
    user = session.get(User, user_id)
    if user is None or user.tenant_id != tenant_id:
        raise NotFound(f"User {user_id} was not found")
    return user
