"""Append-only, hash-chained audit trail.

Every event stores the SHA-256 of its own canonical content plus the previous event's hash for the
same tenant, so any edit, deletion or re-ordering is detectable with :func:`verify_chain`.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..logging_setup import correlation_id_var, redact
from ..models import AuditEvent, Tenant
from ..security import Principal
from .common import json_safe

GENESIS = "0" * 64


def _digest(tenant_id: int, seq: int, actor_user_id: int | None, actor_label: str, action: str,
            entity_type: str | None, entity_id: str | None, detail: Any, correlation_id: str | None,
            created_at_iso: str, prev_hash: str) -> str:
    body = json.dumps(
        [tenant_id, seq, actor_user_id, actor_label, action, entity_type, entity_id, detail, correlation_id,
         created_at_iso, prev_hash],
        sort_keys=True, separators=(",", ":"), ensure_ascii=True,
    )  # fmt: skip
    return hashlib.sha256(body.encode()).hexdigest()


def record(session: Session, *, tenant_id: int, action: str, actor: Principal | None = None,
           actor_label: str | None = None, entity_type: str | None = None, entity_id: Any = None,
           detail: dict | None = None) -> AuditEvent:
    """Append one audit event inside the caller's transaction."""
    # Serialise appends per tenant so the chain cannot fork (row lock on PostgreSQL; SQLite writers
    # are already serialised by BEGIN IMMEDIATE).
    session.execute(select(Tenant.id).where(Tenant.id == tenant_id).with_for_update())
    last = session.execute(
        select(AuditEvent.seq, AuditEvent.hash).where(AuditEvent.tenant_id == tenant_id)
        .order_by(AuditEvent.seq.desc()).limit(1)
    ).first()  # fmt: skip
    seq, prev_hash = (last.seq + 1, last.hash) if last else (1, GENESIS)
    safe_detail = json.loads(json.dumps(json_safe(redact(detail or {})), sort_keys=True))
    created_at = utcnow()
    label = actor_label or (actor.email if actor else "system")
    user_id = actor.user_id if actor else None
    ent_id = None if entity_id is None else str(entity_id)
    correlation_id = correlation_id_var.get()
    event = AuditEvent(
        tenant_id=tenant_id, seq=seq, actor_user_id=user_id, actor_label=label, action=action,
        entity_type=entity_type, entity_id=ent_id, detail=safe_detail, correlation_id=correlation_id,
        created_at=created_at, prev_hash=prev_hash,
        hash=_digest(tenant_id, seq, user_id, label, action, entity_type, ent_id, safe_detail, correlation_id,
                     created_at.isoformat(), prev_hash),
    )  # fmt: skip
    session.add(event)
    session.flush()
    return event


def verify_chain(session: Session, tenant_id: int) -> dict:
    """Recompute the whole chain for a tenant and report the first inconsistency, if any."""
    prev_hash, expected_seq, checked = GENESIS, 1, 0
    stmt = select(AuditEvent).where(AuditEvent.tenant_id == tenant_id).order_by(AuditEvent.seq)
    for ev in session.execute(stmt).scalars():
        problem = None
        if ev.seq != expected_seq:
            problem = f"sequence gap: expected {expected_seq}, found {ev.seq}"
        elif ev.prev_hash != prev_hash:
            problem = "previous-hash link is broken"
        else:
            digest = _digest(ev.tenant_id, ev.seq, ev.actor_user_id, ev.actor_label, ev.action, ev.entity_type,
                             ev.entity_id, ev.detail, ev.correlation_id, ev.created_at.isoformat(), ev.prev_hash)
            if digest != ev.hash:
                problem = "event content does not match its hash"
        if problem:
            return {"valid": False, "checked": checked, "first_invalid_seq": ev.seq, "problem": problem}
        prev_hash, expected_seq, checked = ev.hash, expected_seq + 1, checked + 1
    total = session.execute(select(func.count()).select_from(AuditEvent).where(AuditEvent.tenant_id == tenant_id)).scalar_one()
    return {"valid": True, "checked": checked, "total": total, "head_hash": prev_hash}
