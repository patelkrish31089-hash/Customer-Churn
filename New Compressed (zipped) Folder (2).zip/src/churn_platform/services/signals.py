"""Keeps the derived customer signals in step with the canonical tables.

Signals are computed from imported data (sentiment from support text, attribute history from customer rows,
identity links from telemetry, adoption from telemetry and the catalogue).  ``ensure_ready`` is the cheap check
that runs before anything reads features; ``refresh`` is the nightly step that also rebuilds the reports.
"""

from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope, utcnow
from ..models import AdoptionRun, Job
from ..security import Principal
from . import adoption, attributes, identity, jobs, sentiment, timeline


def ensure_ready(tenant_id: int, customer_ids: list[int] | None = None) -> dict:
    """Nothing may be computed from a half-built signal: score support text that has no score yet and give
    customers without attribute history their timeline.

    When everything is in step - the normal case after an import or the nightly step - this only reads (a few
    lookups in read-only sessions) and never opens a write transaction.  That matters: features are also computed
    inside a caller's write transaction (fitting an uplift model), where a second writer would wait for the first
    on SQLite until it times out."""
    model = sentiment.ensure_scored(tenant_id, customer_ids)
    history = {"customers": 0, "rows": 0, "replayed_changes": 0}
    with read_session() as rs:
        missing = attributes.any_without_history(rs, tenant_id)
    if missing:
        with session_scope() as ws:
            history = attributes.ensure_initial(ws, tenant_id)
    return {"sentiment_model": model, "attribute_history": history}


def start_refresh(session: Session, principal: Principal, as_of: date | None = None) -> Job:
    return jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="signals.refresh", created_by=principal.user_id,
                        payload={"as_of_date": as_of.isoformat() if as_of else None})  # fmt: skip


def refresh(tenant_id: int, as_of: date | None, ctx: Any = None) -> dict:
    """The nightly signals step: sentiment, attribute history, identity links, and adoption at the as-of date."""
    out: dict[str, Any] = {}
    progress = ctx.progress if ctx is not None else (lambda *_a, **_k: None)
    scored = sentiment.score_pending(tenant_id, progress=lambda fraction, message: progress(0.5 * fraction, f"sentiment: {message}"))
    out["sentiment"] = {k: scored[k] for k in ("scored", "by_label", "by_state", "model", "fallback_reason")}
    with session_scope() as ws:
        out["attribute_history"] = attributes.ensure_initial(ws, tenant_id)
        out["identity"] = identity.ensure_links(ws, tenant_id)
    progress(0.6, "attribute history and identity links up to date")
    with session_scope() as ws:
        has_catalog = bool(timeline.approved_catalog(ws, tenant_id))
        if as_of is None:
            cutoff = timeline.data_cutoff(ws, tenant_id)
            as_of = cutoff.date() + timedelta(days=1) if cutoff is not None else None  # the same as-of date the nightly scoring uses
        run_id = None
        if has_catalog and as_of is not None:
            existing = ws.execute(select(AdoptionRun).where(AdoptionRun.tenant_id == tenant_id, AdoptionRun.as_of_date == as_of, AdoptionRun.window_days == 30,
                                                            AdoptionRun.status == "completed").order_by(AdoptionRun.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
            current = adoption.catalog_hash(timeline.approved_catalog(ws, tenant_id))
            if existing is not None and existing.catalog_hash == current and existing.finished_at is not None:
                out["adoption"] = {"adoption_run_id": existing.id, "reused": True}
            else:
                entry = AdoptionRun(tenant_id=tenant_id, as_of_date=as_of, window_days=30, status="pending", job_id=ctx.job_id if ctx is not None else None)
                ws.add(entry)
                ws.flush()
                run_id = entry.id
    if run_id is not None:
        out["adoption"] = adoption.run(run_id)
    elif "adoption" not in out:
        out["adoption"] = {"skipped": "no approved product-feature catalogue" if not has_catalog else "no data"}
    out["finished_at"] = utcnow().isoformat()
    return out
