"""Automatic retraining, triggered by monitoring when realised performance breaches the approved
alert rules ("if performance drops below the PR-AUC threshold, retraining is triggered").

The chain refreshes the churn labels, fills the feature store for every labelled date, builds a
new version of the production model's dataset and trains new candidates on it:

    labels -> features -> dataset -> training

What is deliberately NOT automated: evaluation on the sealed TEST split, registration, approval
and promotion.  A retrained candidate replaces the production model only after a person has
evaluated it and a second person has approved it, exactly like a manually trained model.

Guard rails
  * the trigger can be switched off in the approved ``alert_rules`` policy (``auto_retrain``);
  * at most one automatic retraining per production model version and newest labelled date:
    while no new outcomes have matured, a nightly monitoring run cannot start another one.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import ChurnLabel, FeatureContract, FeatureVector, Job, MLDataset, ModelRun, ModelVersion, Subscription
from ..security import Principal
from . import audit, features, jobs, labels, mlprep, monitoring, pipeline, policies, predictions, registry, training

STEPS = ("labels", "features", "dataset", "training")
MATURE = ("churned", "retained")


def newest_labelled_date(session: Session, tenant_id: int) -> date | None:
    """Newest training (month-start) as-of date with mature outcomes under the active churn definition."""
    policy = policies.get_active(session, tenant_id, "churn_definition", required=False)
    if policy is None:
        return None
    dates = session.execute(select(ChurnLabel.as_of_date).where(
        ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.status.in_(MATURE)).distinct()).scalars()  # fmt: skip
    return max((d for d in dates if d.day == 1), default=None)  # month starts: the dates a retrained model can learn from


def trigger(session: Session, *, tenant_id: int, model_version_id: int, triggered_by: list[str], created_by: int | None,
            enabled: bool, source_report_id: int | None = None) -> dict:
    """Queue the retraining chain for the production model (called by monitoring inside its write transaction)."""
    if not enabled:
        return {"triggered": False, "job_id": None, "reason": "automatic retraining is switched off in the alert rules policy"}
    newest = newest_labelled_date(session, tenant_id)
    key = f"ml.retrain:auto:v{model_version_id}:{newest.isoformat() if newest else 'none'}"
    existing = session.execute(select(Job).where(Job.tenant_id == tenant_id, Job.idempotency_key == key)).scalar_one_or_none()
    if existing is not None:
        return {"triggered": False, "job_id": existing.id,
                "reason": f"already retrained for this model version on the outcomes available (newest labelled date {newest}); "
                          "a new run starts once newer outcomes have matured"}  # fmt: skip
    job = jobs.enqueue(session, tenant_id=tenant_id, job_type="ml.retrain", created_by=created_by, idempotency_key=key,
                       payload={"step": 0, "log": [], "model_version_id": model_version_id, "triggered_by": triggered_by,
                                "source_report_id": source_report_id})  # fmt: skip
    audit.record(session, tenant_id=tenant_id, action="retraining.triggered", entity_type="model_version", entity_id=model_version_id,
                 detail={"job_id": job.id, "triggered_by": triggered_by, "newest_labelled_date": newest.isoformat() if newest else None})  # fmt: skip
    return {"triggered": True, "job_id": job.id, "reason": "realised performance breached: " + ", ".join(triggered_by)}


def _logged(payload: dict, step: str) -> dict:
    return next((entry for entry in payload.get("log", []) if entry.get("step") == step), {})


def _start_step(session: Session, principal: Principal, step: str, payload: dict) -> tuple[Any, dict]:
    tenant_id = principal.tenant_id
    version = registry.production_version(session, tenant_id, version_id=payload.get("model_version_id"))
    production_run = session.get(ModelRun, version.model_run_id)
    production_dataset = session.get(MLDataset, production_run.dataset_id)
    contract = session.get(FeatureContract, version.contract_id)
    if step == "labels":
        # every as-of date from the first subscription on, under the churn definition that is active NOW
        first = session.execute(select(func.min(Subscription.started_at)).where(Subscription.tenant_id == tenant_id)).scalar()
        end = predictions.default_as_of(session, tenant_id)
        months = labels.month_starts(first.date(), end)[-labels.MAX_AS_OF_DATES :]
        run, job = labels.start_run(session, principal, as_of_dates=months)
        return job, {"label_run_id": run.id, "from": months[0].isoformat(), "to": months[-1].isoformat()}
    policy = policies.get_active(session, tenant_id, "churn_definition")
    if step == "features":
        labelled = {d for d in session.execute(select(ChurnLabel.as_of_date).where(
            ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.status.in_(MATURE)).distinct()).scalars()
                    if d.day == 1}  # the training grid is month starts (see mlprep.assemble)  # fmt: skip
        stored = set(session.execute(select(FeatureVector.as_of_date).where(
            FeatureVector.tenant_id == tenant_id, FeatureVector.contract_id == contract.id).distinct()).scalars())  # fmt: skip
        missing = sorted(labelled - stored)
        if not missing:
            return None, {"skipped": "the feature store already covers every labelled date", "labelled_dates": len(labelled)}
        # historical dates only: the online store keeps serving the newest scoring date
        run, job = features.start_materialization(session, principal, contract_id=contract.id, as_of_dates=missing, publish_online=False)
        return job, {"feature_run_id": run.id, "dates": [d.isoformat() for d in missing]}
    if step == "dataset":
        config = production_dataset.config or {}
        dataset, job = mlprep.start_build(session, principal, name=production_dataset.name, contract_id=contract.id,
                                          valid_dates=int(config.get("valid_dates", 2)), test_dates=int(config.get("test_dates", 2)),
                                          embargo_days=int(config.get("embargo_days", 0)), target=config.get("target", "all"))  # fmt: skip
        return job, {"dataset_id": dataset.id, "dataset_version": dataset.version, "replaces_dataset_version": production_dataset.version}
    search = production_run.search or {}
    runs, job = training.start_training(session, principal, dataset_id=int(_logged(payload, "dataset")["dataset_id"]),
                                        n_iter=int(search.get("n_iter", 6)), cv_folds=int(search.get("cv_folds", 3)), seed=production_run.seed)  # fmt: skip
    return job, {"group_id": runs[0].group_id, "run_ids": [r.id for r in runs], "algorithms": [r.algorithm for r in runs]}


def _completed(session: Session, ctx: Any, payload: dict, log: list) -> dict:
    """Tell people that candidates are waiting; nothing is evaluated on TEST, registered or promoted here."""
    entry = next((e for e in log if e.get("step") == "training"), {})
    runs = session.execute(select(ModelRun).where(ModelRun.id.in_(entry.get("run_ids", [])))).scalars().all()
    done = sorted((r for r in runs if r.status == "completed"), key=lambda r: -((r.valid_metrics or {}).get("pr_auc") or 0.0))
    candidates = [{"run_id": r.id, "algorithm": r.algorithm, "valid_pr_auc": (r.valid_metrics or {}).get("pr_auc")} for r in done]
    version = session.get(ModelVersion, payload.get("model_version_id"))
    result = {"candidates": candidates, "dataset_id": _logged({"log": log}, "dataset").get("dataset_id"),
              "production_model_version_id": version.id if version else None}  # fmt: skip
    best = candidates[0] if candidates else None
    monitoring.raise_alert(
        session, ctx.tenant_id, kind="retraining_completed", severity="warning", source_type="job", source_id=ctx.job_id, detail=result,
        title="Retrained candidates await review" if best else "Automatic retraining produced no usable candidate",
        message=(f"Automatic retraining finished: {len(candidates)} candidate(s); best on validation: {best['algorithm']} "
                 f"(run {best['run_id']}, PR-AUC {best['valid_pr_auc']:.4f}). Evaluate it, register it and submit it for approval. "
                 "The production model stays in place until a second person approves a replacement.") if best
        else "No algorithm finished training. Check the training runs; the production model stays in place.")  # fmt: skip
    return result


def run(ctx: Any) -> dict:
    """One tick of the retraining chain (see ``pipeline.run_chain``)."""
    return pipeline.run_chain(ctx, job_type="ml.retrain", steps=STEPS, start_step=_start_step, name="automatic retraining",
                              audit_action="retraining.completed", on_complete=_completed)  # fmt: skip


__all__ = ["STEPS", "newest_labelled_date", "run", "trigger"]
