"""Durable job queue: enqueue, atomic claim with leases, heartbeats, retries, cancellation, recovery.

The same SQL works on SQLite and PostgreSQL.  Claiming is a single ``UPDATE ... RETURNING`` whose
candidate sub-select uses ``FOR UPDATE SKIP LOCKED`` on PostgreSQL, so two workers can never run
the same job; every state change made by a worker is guarded by ``lease_owner = <worker>`` so a
worker that lost its lease cannot overwrite the job's new owner.
"""

from __future__ import annotations

import threading
import time
import traceback
from collections.abc import Callable
from datetime import timedelta
from typing import Any

from sqlalchemy import select, update
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_control_engine, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import Job
from ..security import Principal
from . import audit
from .common import get_owned, json_safe

J = Job.__table__
JobHandler = Callable[["JobContext"], dict | None]
HANDLERS: dict[str, JobHandler] = {}


class JobCancelled(Exception):
    """Raised inside a handler when cancellation was requested."""


class JobInterrupted(Exception):
    """Raised inside a handler when the worker is shutting down or lost its lease (job is requeued)."""


class PermanentJobError(Exception):
    """A failure that retrying cannot fix (bad input, missing prerequisite)."""


def job_handler(job_type: str) -> Callable[[JobHandler], JobHandler]:
    def register(fn: JobHandler) -> JobHandler:
        HANDLERS[job_type] = fn
        return fn

    return register


class JobContext:
    """What a handler receives: its payload plus cooperative progress / cancellation hooks."""

    def __init__(self, engine: Engine, job: dict, worker_id: str) -> None:
        self._engine = engine
        self.job_id: int = job["id"]
        self.tenant_id: int = job["tenant_id"]
        self.job_type: str = job["job_type"]
        self.payload: dict = job["payload"] or {}
        self.created_by: int | None = job["created_by"]
        self.attempt: int = job["attempts"]
        self.worker_id = worker_id
        self.cancel_requested = threading.Event()
        self.lease_lost = threading.Event()
        self.shutdown_deadline: float | None = None
        self.progress_skipped = 0
        self._last_progress = 0.0

    def check(self) -> None:
        """Call regularly from long loops; raises if the job must stop."""
        if self.lease_lost.is_set():
            raise JobInterrupted("lease lost")
        if self.cancel_requested.is_set():
            raise JobCancelled("cancellation requested")
        if self.shutdown_deadline is not None and time.monotonic() >= self.shutdown_deadline:
            raise JobInterrupted("worker shutting down")

    def progress(self, fraction: float, message: str | None = None, *, force: bool = False) -> None:
        self.check()
        now = time.monotonic()
        if not force and now - self._last_progress < 0.5:
            return
        self._last_progress = now
        try:
            with get_control_engine().begin() as conn:
                conn.execute(
                    update(J).where(J.c.id == self.job_id, J.c.lease_owner == self.worker_id, J.c.status == "running")
                    .values(progress=max(0.0, min(1.0, float(fraction))), progress_message=(message or "")[:300] or None)
                )  # fmt: skip
        except OperationalError:
            # Advisory only: the database was busy (on SQLite, typically because this job itself
            # holds the write lock).  Counted so tests can prove handlers report outside transactions.
            self.progress_skipped += 1


def load_handlers() -> None:
    """Register every job handler (idempotent).  Called lazily so that any process that enqueues
    or runs jobs knows the full set of job types without import-order requirements."""
    import importlib

    importlib.import_module("churn_platform.worker.handlers")


# ----------------------------------------------------------------------------- API-side operations
def enqueue(session: Session, *, tenant_id: int, job_type: str, payload: dict | None = None,
            created_by: int | None = None, idempotency_key: str | None = None, priority: int = 0,
            run_after: Any = None, max_attempts: int | None = None) -> Job:
    """Queue a job.  With an idempotency key, a repeated request returns the original job."""
    if job_type not in HANDLERS:
        load_handlers()
    if job_type not in HANDLERS:
        raise ValidationFailed(f"unknown job type '{job_type}'")
    if idempotency_key:
        existing = session.execute(
            select(Job).where(Job.tenant_id == tenant_id, Job.idempotency_key == idempotency_key)
        ).scalar_one_or_none()
        if existing is not None:
            return existing
    job = Job(tenant_id=tenant_id, job_type=job_type, payload=json_safe(payload or {}), status="queued",
              priority=priority, run_after=run_after or utcnow(), idempotency_key=idempotency_key,
              max_attempts=max_attempts or get_settings().job_max_attempts, created_by=created_by)  # fmt: skip
    try:
        with session.begin_nested():
            session.add(job)
            session.flush()
    except IntegrityError:  # lost a race on the idempotency key: return the winner
        return session.execute(
            select(Job).where(Job.tenant_id == tenant_id, Job.idempotency_key == idempotency_key)
        ).scalar_one()
    return job


def request_cancel(session: Session, principal: Principal, job_id: int) -> Job:
    job = get_owned(session, Job, principal.tenant_id, job_id, label="Job")
    if job.status == "queued":
        job.status, job.finished_at, job.cancel_requested = "cancelled", utcnow(), True
    elif job.status == "running":
        job.cancel_requested = True
    else:
        raise Conflict(f"job is already {job.status}")
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="job.cancel_requested",
                 entity_type="job", entity_id=job.id, detail={"job_type": job.job_type})  # fmt: skip
    return job


def retry(session: Session, principal: Principal, job_id: int) -> Job:
    job = get_owned(session, Job, principal.tenant_id, job_id, label="Job")
    if job.status not in ("failed", "cancelled"):
        raise Conflict(f"only failed or cancelled jobs can be retried (status: {job.status})")
    job.status, job.attempts, job.run_after, job.cancel_requested = "queued", 0, utcnow(), False
    job.error, job.finished_at, job.lease_owner, job.lease_expires_at, job.progress = None, None, None, None, 0.0
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="job.retried", entity_type="job",
                 entity_id=job.id, detail={"job_type": job.job_type})  # fmt: skip
    return job


# ----------------------------------------------------------------------------- worker-side operations
def claim_next(engine: Engine, worker_id: str, lease_seconds: float, job_types: list[str] | None = None) -> dict | None:
    now = utcnow()
    candidate = select(J.c.id).where(J.c.status == "queued", J.c.run_after <= now)
    if job_types:
        candidate = candidate.where(J.c.job_type.in_(job_types))
    candidate = candidate.order_by(J.c.priority.desc(), J.c.id).limit(1).with_for_update(skip_locked=True)
    stmt = (
        update(J).where(J.c.id == candidate.scalar_subquery(), J.c.status == "queued")
        .values(status="running", lease_owner=worker_id, lease_expires_at=now + timedelta(seconds=lease_seconds),
                heartbeat_at=now, started_at=now, attempts=J.c.attempts + 1, progress=0.0, progress_message=None)
        .returning(J.c.id, J.c.tenant_id, J.c.job_type, J.c.payload, J.c.created_by, J.c.attempts, J.c.max_attempts)
    )  # fmt: skip
    with engine.begin() as conn:
        row = conn.execute(stmt).mappings().first()
    return dict(row) if row else None


def heartbeat(engine: Engine, job_id: int, worker_id: str, lease_seconds: float) -> tuple[bool, bool]:
    """Extend the lease.  Returns (still_owner, cancel_requested)."""
    now = utcnow()
    stmt = (
        update(J).where(J.c.id == job_id, J.c.lease_owner == worker_id, J.c.status == "running")
        .values(heartbeat_at=now, lease_expires_at=now + timedelta(seconds=lease_seconds))
        .returning(J.c.cancel_requested)
    )  # fmt: skip
    with get_control_engine().begin() as conn:
        row = conn.execute(stmt).first()
    return (row is not None, bool(row[0]) if row else False)


def _finish(engine: Engine, job_id: int, worker_id: str, **values: Any) -> bool:
    values.setdefault("lease_owner", None)
    values.setdefault("lease_expires_at", None)
    stmt = update(J).where(J.c.id == job_id, J.c.lease_owner == worker_id, J.c.status == "running").values(**values)
    with engine.begin() as conn:
        return conn.execute(stmt).rowcount == 1


def mark_succeeded(engine: Engine, job_id: int, worker_id: str, result: dict | None) -> bool:
    return _finish(engine, job_id, worker_id, status="succeeded", result=json_safe(result or {}), progress=1.0,
                   finished_at=utcnow(), error=None)  # fmt: skip


def mark_cancelled(engine: Engine, job_id: int, worker_id: str) -> bool:
    return _finish(engine, job_id, worker_id, status="cancelled", finished_at=utcnow(), error="cancelled by request")


def release(engine: Engine, job_id: int, worker_id: str, reason: str) -> bool:
    """Give an interrupted job back to the queue without consuming one of its attempts."""
    return _finish(engine, job_id, worker_id, status="queued", run_after=utcnow(), attempts=J.c.attempts - 1,
                   error=f"released: {reason}")  # fmt: skip


def mark_failed(engine: Engine, job: dict, worker_id: str, exc: BaseException, *, permanent: bool = False) -> str:
    """Retry with exponential backoff until attempts are exhausted, then park the job as failed."""
    error = "".join(traceback.format_exception_only(type(exc), exc)).strip()[:4000]
    if not permanent and job["attempts"] < job["max_attempts"]:
        delay = get_settings().job_backoff_base_seconds * (2 ** (job["attempts"] - 1))
        _finish(engine, job["id"], worker_id, status="queued", run_after=utcnow() + timedelta(seconds=delay), error=error)
        return "retry_scheduled"
    _finish(engine, job["id"], worker_id, status="failed", finished_at=utcnow(), error=error)
    return "failed"


def recover_stale(engine: Engine) -> dict:
    """Requeue (or fail, if attempts are exhausted) jobs whose worker stopped heart-beating."""
    now = utcnow()
    expired = [J.c.status == "running", J.c.lease_expires_at < now]
    with engine.begin() as conn:
        requeued = conn.execute(
            update(J).where(*expired, J.c.attempts < J.c.max_attempts)
            .values(status="queued", lease_owner=None, lease_expires_at=None, run_after=now,
                    error="lease expired (worker lost); requeued")
        ).rowcount  # fmt: skip
        failed = conn.execute(
            update(J).where(*expired, J.c.attempts >= J.c.max_attempts)
            .values(status="failed", lease_owner=None, lease_expires_at=None, finished_at=now,
                    error="lease expired (worker lost); attempts exhausted")
        ).rowcount  # fmt: skip
    return {"requeued": requeued, "failed": failed}


def job_view(job: Job) -> dict:
    return json_safe({c.key: getattr(job, c.key) for c in J.columns})
