"""ML dataset preparation: chronological split with purging and embargo, train-only preprocessing,
fingerprints, a leakage report, and a guarded TEST split that training code cannot read."""

from __future__ import annotations

import hashlib
import json
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import read_session, session_scope
from ..errors import Conflict, ValidationFailed
from ..models import ChurnLabel, FeatureContract, FeatureVector, MLDataset, Policy
from ..security import Principal
from . import audit, feature_engine, features, jobs, policies
from .common import get_owned, json_safe, next_version, to_dict

SPLITS = ("train", "valid", "test")
META_COLUMNS = ["customer_id", "as_of_date", "label", "churn_type"]
MAX_CATEGORIES = 20
TEST_PURPOSE = "final_evaluation"


class TestSplitAccessError(RuntimeError):
    """Raised when code tries to read the TEST split for anything but the final evaluation."""

    __test__ = False  # not a pytest class


# ----------------------------------------------------------------------------- splitting
def chronological_split(dates: list[date], valid_dates: int, test_dates: int) -> dict[str, list[date]]:
    dates = sorted(set(dates))
    if valid_dates < 1 or test_dates < 1:
        raise ValidationFailed("valid_dates and test_dates must each be at least 1")
    if len(dates) < valid_dates + test_dates + 2:
        raise ValidationFailed(
            f"need at least {valid_dates + test_dates + 2} mature as-of dates to split chronologically, found {len(dates)}",
            code="not_enough_history")  # fmt: skip
    return {"train": dates[: -(valid_dates + test_dates)], "valid": dates[-(valid_dates + test_dates) : -test_dates],
            "test": dates[-test_dates:]}  # fmt: skip


def purge(dates: list[date], boundary: date, horizon_days: int, embargo_days: int) -> tuple[list[date], list[date]]:
    """Keep only as-of dates whose label window (plus embargo) closes on or before ``boundary``."""
    span = timedelta(days=horizon_days + embargo_days)
    kept = [d for d in dates if d + span <= boundary]
    return kept, [d for d in dates if d not in kept]


def temporal_folds(dates: list[date], n_folds: int, horizon_days: int, embargo_days: int = 0) -> list[tuple[list[date], list[date]]]:
    """Expanding-window folds over the TRAIN as-of dates (each fold validates on later dates only)."""
    dates = sorted(set(dates))
    n_folds = max(1, min(n_folds, len(dates) - 1))
    blocks = [list(b) for b in np.array_split(np.array(dates, dtype=object), n_folds + 1)]
    folds = []
    for i in range(1, len(blocks)):
        fit = [d for block in blocks[:i] for d in block]
        fit, _ = purge(fit, min(blocks[i]), horizon_days, embargo_days)
        if fit and blocks[i]:
            folds.append((fit, blocks[i]))
    return folds


# ----------------------------------------------------------------------------- preprocessing (fit on TRAIN only)
def fit_preprocessor(train: pd.DataFrame, feature_names: list[str]) -> dict:
    spec: dict[str, Any] = {"numeric": {}, "categorical": {}, "columns": [], "source": {}}
    for name in feature_names:
        if feature_engine.SPECS[name].dtype == "category":
            counts = train[name].dropna().astype(str).value_counts()
            cats = sorted(counts.index[:MAX_CATEGORIES].tolist())
            spec["categorical"][name] = cats
            for cat in [*cats, "__other__", "__missing__"]:
                column = f"{name}={cat}"
                spec["columns"].append(column)
                spec["source"][column] = name
        else:
            values = pd.to_numeric(train[name], errors="coerce")
            median = float(values.median()) if values.notna().any() else 0.0
            indicator = bool(values.isna().mean() >= 0.01)
            spec["numeric"][name] = {"median": median, "indicator": indicator}
            spec["columns"].append(name)
            spec["source"][name] = name
            if indicator:
                spec["columns"].append(f"{name}__missing")
                spec["source"][f"{name}__missing"] = name
    return spec


def transform(spec: dict, df: pd.DataFrame) -> pd.DataFrame:
    """Apply a fitted preprocessing spec (identical code path for training and inference)."""
    out: dict[str, np.ndarray] = {}
    for name, cfg in spec["numeric"].items():
        values = pd.to_numeric(df[name], errors="coerce").astype("float64")
        missing = values.isna().to_numpy()
        out[name] = np.where(missing, cfg["median"], values.to_numpy())
        if cfg["indicator"]:
            out[f"{name}__missing"] = missing.astype("float64")
    for name, cats in spec["categorical"].items():
        raw = df[name]
        text = raw.astype(object).where(raw.notna(), None)
        text = np.array([None if v is None else str(v) for v in text], dtype=object)
        known = np.zeros(len(df), dtype=bool)
        for cat in cats:
            hit = text == cat
            out[f"{name}={cat}"] = hit.astype("float64")
            known |= hit
        is_missing = np.array([v is None for v in text])
        out[f"{name}=__missing__"] = is_missing.astype("float64")
        out[f"{name}=__other__"] = (~known & ~is_missing).astype("float64")
    return pd.DataFrame({c: out[c] for c in spec["columns"]}, index=df.index)


# ----------------------------------------------------------------------------- storage
def dataset_dir(tenant_id: int, dataset_id: int) -> Path:
    path = get_settings().data_dir / "ml_datasets" / str(tenant_id) / str(dataset_id)
    path.mkdir(parents=True, exist_ok=True)
    return path


def fingerprint_frame(df: pd.DataFrame) -> str:
    ordered = df.sort_values(["as_of_date", "customer_id"]).reset_index(drop=True)
    body = ordered.to_csv(index=False, float_format="%.10g", date_format="%Y-%m-%d", na_rep="")
    return hashlib.sha256(body.encode()).hexdigest()


def load_split(dataset: MLDataset, split: str, *, purpose: str = "training") -> pd.DataFrame:
    """Read one split.  The TEST split is only released for the explicit final-evaluation purpose."""
    if split not in SPLITS:
        raise ValueError(f"unknown split '{split}'")
    if split == "test" and purpose != TEST_PURPOSE:
        raise TestSplitAccessError("the TEST split may only be read for the final evaluation, never for training or selection")
    path = storage.resolve(dataset.storage_path) / f"{split}.parquet"
    df = pd.read_parquet(path)
    expected = (dataset.row_counts or {}).get("fingerprints", {}).get(split)
    if expected and fingerprint_frame(df) != expected:
        raise RuntimeError(f"{split} split of dataset {dataset.id} does not match its recorded fingerprint")
    df["as_of_date"] = pd.to_datetime(df["as_of_date"]).dt.date
    return df


# ----------------------------------------------------------------------------- build
def start_build(session: Session, principal: Principal, *, name: str, contract_id: int, policy_id: int | None = None,
                valid_dates: int = 2, test_dates: int = 2, embargo_days: int = 0, target: str = "all") -> tuple[MLDataset, Any]:
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if target not in ("all", "voluntary", "involuntary"):
        raise ValidationFailed("target must be all, voluntary or involuntary", details={"field": "target"})
    if not 0 <= embargo_days <= 365:
        raise ValidationFailed("embargo_days must be between 0 and 365", details={"field": "embargo_days"})
    if valid_dates < 1 or test_dates < 1:
        raise ValidationFailed("valid_dates and test_dates must each be at least 1", details={"field": "valid_dates"})
    contract = features.require_usable(get_owned(session, FeatureContract, principal.tenant_id, contract_id, label="Feature contract"))
    policy = (policies.get_approved(session, principal.tenant_id, policy_id, "churn_definition") if policy_id
              else policies.get_active(session, principal.tenant_id, "churn_definition"))  # fmt: skip
    dataset = MLDataset(
        tenant_id=principal.tenant_id, name=name, version=next_version(session, MLDataset, tenant_id=principal.tenant_id, name=name),
        contract_id=contract.id, policy_id=policy.id, status="building", created_by=principal.user_id,
        config={"valid_dates": valid_dates, "test_dates": test_dates, "embargo_days": embargo_days, "target": target,
                "horizon_days": policies.parse(policy).horizon_days, "contract_schema_hash": contract.schema_hash,
                "policy_version": policy.version})  # fmt: skip
    session.add(dataset)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="ml.build_dataset", created_by=principal.user_id,
                       payload={"dataset_id": dataset.id})  # fmt: skip
    dataset.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="ml.dataset_build_started",
                 entity_type="ml_dataset", entity_id=dataset.id, detail={"name": name, "version": dataset.version, **dataset.config})  # fmt: skip
    return dataset, job


def assemble(session: Session, tenant_id: int, contract: FeatureContract, policy: Policy, target: str) -> pd.DataFrame:
    """Join mature labels with the offline feature store (inner join; nothing is imputed here)."""
    rows = session.execute(
        select(ChurnLabel.customer_id, ChurnLabel.as_of_date, ChurnLabel.label, ChurnLabel.churn_type)
        .where(ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.status.in_(("churned", "retained")))
    ).all()  # fmt: skip
    labels = pd.DataFrame(rows, columns=META_COLUMNS)
    # Training rows are monthly snapshots.  Labels for other dates exist too (the nightly pipeline labels every scored
    # date so that realised performance can be measured); they would add near-duplicate rows with overlapping outcome
    # windows and turn "the last two as-of dates" of a split into two consecutive days, so they are left out here.
    labels = labels[[d.day == 1 for d in labels["as_of_date"]]].reset_index(drop=True)
    if labels.empty:
        raise jobs.PermanentJobError("no mature churn labels exist at month-start as-of dates for this churn definition; generate labels first")
    if target != "all":
        other = labels["label"].eq(1) & labels["churn_type"].ne(target)
        labels = labels[~other]  # a competing churn type is neither a positive nor a clean negative
    feats = features.offline_frame(session, tenant_id, contract, dates=sorted(labels["as_of_date"].unique()))
    if feats.empty:
        raise jobs.PermanentJobError("the feature store has no vectors for the labelled as-of dates; materialise features first")
    data = labels.merge(feats, on=["customer_id", "as_of_date"], how="inner")
    data["label"] = data["label"].astype("int64")
    return data.sort_values(["as_of_date", "customer_id"]).reset_index(drop=True)


def leakage_report(parts: dict[str, pd.DataFrame], dropped: dict[str, list[date]], horizon: int, embargo: int,
                   feature_names: list[str], max_source_ok: bool) -> dict:
    spans = {k: (min(v["as_of_date"]), max(v["as_of_date"])) for k, v in parts.items() if len(v)}
    span = timedelta(days=horizon + embargo)
    checks = [
        {"check": "chronological_order", "passed": spans["train"][1] < spans["valid"][0] <= spans["valid"][1] < spans["test"][0],
         "detail": {k: [a.isoformat(), b.isoformat()] for k, (a, b) in spans.items()}},
        {"check": "train_label_windows_close_before_validation", "passed": spans["train"][1] + span <= spans["valid"][0],
         "detail": {"purged_as_of_dates": [d.isoformat() for d in dropped["train"]]}},
        {"check": "validation_label_windows_close_before_test", "passed": spans["valid"][1] + span <= spans["test"][0],
         "detail": {"purged_as_of_dates": [d.isoformat() for d in dropped["valid"]]}},
        {"check": "no_duplicate_rows", "passed": all(not v.duplicated(["customer_id", "as_of_date"]).any() for v in parts.values()),
         "detail": {}},
        {"check": "features_strictly_before_as_of_date", "passed": bool(max_source_ok),
         "detail": {"rule": "every feature vector's newest source record precedes its as-of date"}},
        {"check": "no_outcome_columns_in_features",
         "passed": not set(feature_names) & set(feature_engine.FORBIDDEN_SOURCE_COLUMNS),
         "detail": {"forbidden": list(feature_engine.FORBIDDEN_SOURCE_COLUMNS)}},
    ]  # fmt: skip
    train = parts["train"]
    suspicious = []
    y = train["label"].to_numpy()
    if 0 < y.sum() < len(y):
        from sklearn.metrics import roc_auc_score

        for name in feature_names:
            if feature_engine.SPECS[name].dtype == "category":
                continue
            x = pd.to_numeric(train[name], errors="coerce")
            if x.notna().sum() > 30 and x.nunique() > 1:
                auc = roc_auc_score(y[x.notna()], x[x.notna()]) if 0 < y[x.notna()].sum() < x.notna().sum() else 0.5
                if max(auc, 1 - auc) >= 0.98:
                    suspicious.append({"feature": name, "single_feature_auc": round(float(max(auc, 1 - auc)), 4)})
    checks.append({"check": "no_single_feature_separates_classes", "passed": not suspicious, "detail": {"suspicious": suspicious}})
    overlap = len(set(train["customer_id"]) & set(parts["test"]["customer_id"]))
    return {"passed": all(c["passed"] for c in checks), "checks": checks,
            "information": {"customers_in_both_train_and_test": overlap,
                            "note": "the same customer is observed at different as-of dates (panel data); "
                                    "splits are separated in time, not by customer"}}  # fmt: skip


def run_build(dataset_id: int, ctx: Any = None) -> dict:
    try:
        with read_session() as rs:
            dataset = rs.get(MLDataset, dataset_id)
            if dataset is None:
                raise jobs.PermanentJobError(f"dataset {dataset_id} does not exist")
            contract, policy = rs.get(FeatureContract, dataset.contract_id), rs.get(Policy, dataset.policy_id)
            cfg, tenant_id = dict(dataset.config), dataset.tenant_id
            data = assemble(rs, tenant_id, contract, policy, cfg["target"])
            stamps = rs.execute(select(FeatureVector.as_of_date, FeatureVector.max_source_ts).where(
                FeatureVector.tenant_id == tenant_id, FeatureVector.contract_id == contract.id,
                FeatureVector.max_source_ts.is_not(None))).all()  # fmt: skip
        max_source_ok = all(m.replace(tzinfo=None) < pd.Timestamp(d) for d, m in stamps)
        feature_names = list(contract.features)
        horizon, embargo = int(cfg["horizon_days"]), int(cfg["embargo_days"])
        split = chronological_split(list(data["as_of_date"].unique()), cfg["valid_dates"], cfg["test_dates"])
        dropped: dict[str, list[date]] = {}
        split["train"], dropped["train"] = purge(split["train"], min(split["valid"]), horizon, embargo)
        split["valid"], dropped["valid"] = purge(split["valid"], min(split["test"]), horizon, embargo)
        if not split["train"] or not split["valid"]:
            raise jobs.PermanentJobError("purging/embargo removed an entire split; use more history or a smaller embargo")
        parts = {k: data[data["as_of_date"].isin(v)].reset_index(drop=True) for k, v in split.items()}
        if ctx is not None:
            ctx.progress(0.5, "splits assembled", force=True)
        balance = {k: {"rows": int(len(v)), "positives": int(v["label"].sum()),
                       "positive_rate": round(float(v["label"].mean()), 6) if len(v) else None,
                       "as_of_dates": [d.isoformat() for d in sorted(v["as_of_date"].unique())],
                       "by_churn_type": {str(a): int(b) for a, b in v.loc[v["label"] == 1, "churn_type"].value_counts().items()}}
                   for k, v in parts.items()}  # fmt: skip
        for name in ("train", "valid", "test"):
            if balance[name]["positives"] < (10 if name == "train" else 2) or balance[name]["positives"] == balance[name]["rows"]:
                raise jobs.PermanentJobError(
                    f"the {name} split has {balance[name]['positives']} churned customers out of {balance[name]['rows']} rows, "
                    "which is too few to train or evaluate a model honestly")  # fmt: skip
        prep = fit_preprocessor(parts["train"], feature_names)
        report = leakage_report(parts, dropped, horizon, embargo, feature_names, max_source_ok)
        out_dir = dataset_dir(tenant_id, dataset_id)
        fingerprints = {}
        for name, frame in parts.items():
            fingerprints[name] = fingerprint_frame(frame)
            frame.assign(as_of_date=pd.to_datetime(frame["as_of_date"])).to_parquet(out_dir / f"{name}.parquet", index=False)
        overall = hashlib.sha256(json.dumps({"config": cfg, "splits": fingerprints, "features": feature_names,
                                             "prep": prep}, sort_keys=True, default=str).encode()).hexdigest()  # fmt: skip
        with session_scope() as ws:
            ws.execute(update(MLDataset).where(MLDataset.id == dataset_id).values(
                status="ready" if report["passed"] else "leakage_detected", fingerprint=overall, storage_path=storage.to_stored(out_dir),
                row_counts={"fingerprints": fingerprints, **{k: balance[k]["rows"] for k in SPLITS}},
                class_balance=balance, leakage_report=json_safe(report), preprocessing=prep, error=None))  # fmt: skip
            audit.record(ws, tenant_id=tenant_id, action="ml.dataset_built", entity_type="ml_dataset", entity_id=dataset_id,
                         detail={"fingerprint": overall, "leakage_checks_passed": report["passed"],
                                 **{k: balance[k]["rows"] for k in SPLITS}})  # fmt: skip
        return {"dataset_id": dataset_id, "fingerprint": overall, "rows": {k: balance[k]["rows"] for k in SPLITS},
                "leakage_checks_passed": report["passed"]}  # fmt: skip
    except Exception as exc:
        if not isinstance(exc, jobs.JobCancelled | jobs.JobInterrupted):
            with session_scope() as ws:
                ws.execute(update(MLDataset).where(MLDataset.id == dataset_id).values(status="failed", error=str(exc)[:2000]))
        if isinstance(exc, ValidationFailed | Conflict):
            raise jobs.PermanentJobError(exc.message) from exc
        raise


def require_ready(dataset: MLDataset) -> MLDataset:
    if dataset.status != "ready":
        raise Conflict(f"dataset {dataset.name} v{dataset.version} is not ready (status: {dataset.status})", code="dataset_not_ready")
    return dataset


def dataset_view(dataset: MLDataset) -> dict:
    return to_dict(dataset, exclude={"preprocessing", "storage_path"},
                   include={"encoded_columns": len((dataset.preprocessing or {}).get("columns", []))})  # fmt: skip
