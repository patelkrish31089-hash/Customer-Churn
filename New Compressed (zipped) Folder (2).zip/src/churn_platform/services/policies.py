"""Versioned, independently-approved business policies.

Nothing in this module supplies real business numbers: defaults are structural (e.g. the 30-day
horizon from the specification) and monetary assumptions must be entered and approved by people.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import utcnow
from ..errors import Conflict, Forbidden, NotFound, ValidationFailed
from ..models import POLICY_KINDS, Policy
from ..security import Principal
from . import audit
from .common import get_owned, next_version, to_dict


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ChurnDefinition(_Strict):
    """What counts as churn.  Default target: churn within 30 days of the as-of time T."""

    horizon_days: int = Field(30, ge=1, le=365)
    grace_period_days: int = Field(14, ge=0, le=180)
    reactivation_window_days: int = Field(0, ge=0, le=180)
    voluntary_reasons: list[str] = ["cancellation", "non_renewal"]
    involuntary_reasons: list[str] = ["payment_failure", "suspension"]
    excluded_reasons: list[str] = []
    multi_subscription_rule: Literal["all", "any", "primary"] = "all"
    include_trials: bool = False
    min_tenure_days: int = Field(0, ge=0, le=3650)
    description: str = ""

    @model_validator(mode="after")
    def _disjoint(self) -> ChurnDefinition:
        groups = [set(self.voluntary_reasons), set(self.involuntary_reasons), set(self.excluded_reasons)]
        if len(set().union(*groups)) != sum(len(g) for g in groups):
            raise ValueError("a reason may appear in only one of voluntary / involuntary / excluded")
        return self


class CostMatrix(_Strict):
    """Financial assumptions for threshold optimisation.  All amounts are exact decimals."""

    currency: str = Field(min_length=3, max_length=3)
    intervention_cost: Decimal = Field(ge=0)
    clv_mode: Literal["fixed", "mrr_multiple"] = "fixed"
    clv: Decimal | None = Field(None, gt=0)
    clv_months: Decimal | None = Field(None, gt=0)
    contribution_margin: Decimal = Field(gt=0, le=1)
    save_rate: Decimal = Field(gt=0, le=1)
    campaign_fixed_cost: Decimal = Field(Decimal("0"), ge=0)
    capacity: int | None = Field(None, ge=1)
    evidence: str = Field(min_length=10)
    is_example: bool = False

    @model_validator(mode="after")
    def _mode(self) -> CostMatrix:
        if self.clv_mode == "fixed" and self.clv is None:
            raise ValueError("clv is required when clv_mode is 'fixed'")
        if self.clv_mode == "mrr_multiple" and self.clv_months is None:
            raise ValueError("clv_months is required when clv_mode is 'mrr_multiple'")
        return self


class RiskPolicy(_Strict):
    high_risk_top_share: float = Field(0.10, gt=0, lt=1)
    medium_risk_top_share: float = Field(0.40, gt=0, le=1)
    high_value_percentile: float = Field(0.70, gt=0, lt=1)
    involuntary_payment_expiry_days: int = Field(15, ge=1, le=120)
    involuntary_failed_payment_lookback_days: int = Field(30, ge=1, le=180)
    contact_cooldown_days: int = Field(14, ge=0, le=365)

    @model_validator(mode="after")
    def _ordered(self) -> RiskPolicy:
        if self.medium_risk_top_share <= self.high_risk_top_share:
            raise ValueError("medium_risk_top_share must be larger than high_risk_top_share")
        return self


class PlaybookAction(_Strict):
    code: str = Field(min_length=2, max_length=60, pattern=r"^[a-z0-9_]+$")
    name: str = Field(min_length=2, max_length=160)
    segment: Literal["high_risk_high_value", "medium_risk_low_value", "involuntary"]
    channel: Literal["crm_task", "email", "sms", "in_app", "phone"]
    requires_human_review: bool = False
    requires_marketing_consent: bool = True
    offer: dict[str, Any] | None = None
    description: str = ""


class RetentionPlaybook(_Strict):
    actions: list[PlaybookAction] = Field(min_length=1)
    reason_plays: dict[str, str] = {}

    @model_validator(mode="after")
    def _unique_codes(self) -> RetentionPlaybook:
        codes = [a.code for a in self.actions]
        if len(codes) != len(set(codes)):
            raise ValueError("action codes must be unique")
        return self


class AlertRule(_Strict):
    metric: Literal["feature_drift_share", "prediction_psi", "pr_auc_drop", "pr_auc_min", "dq_score_min",
                    "missing_rate_increase"]  # fmt: skip
    operator: Literal[">", ">=", "<", "<="]
    threshold: float
    severity: Literal["info", "warning", "critical"] = "warning"


class AlertRules(_Strict):
    rules: list[AlertRule] = Field(min_length=1)
    retrain_on: list[str] = ["pr_auc_min", "pr_auc_drop"]  # rules whose breach calls for retraining
    auto_retrain: bool = True  # start the retraining chain automatically; False = raise the alert only


class ActivityDefinition(_Strict):
    """What "an active user" means (DAU / WAU / MAU and everything that counts users)."""

    active_event_types: list[Literal["login", "session", "feature_use", "key_action"]] = ["login", "session", "feature_use", "key_action"]
    timezone: str = Field("UTC", max_length=60)
    # identifiers that are not customers' people: staff, test accounts, automation ("*" matches any run of characters)
    exclude_user_patterns: list[str] = Field(default_factory=list, max_length=50)
    # a customer's user counts are reported as unknown when fewer of its events than this identify a user
    min_identified_share: float = Field(0.5, ge=0, le=1)
    description: str = ""

    @model_validator(mode="after")
    def _checks(self) -> ActivityDefinition:
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        if not self.active_event_types:
            raise ValueError("at least one event type must count as activity")
        try:
            ZoneInfo(self.timezone)
        except (ZoneInfoNotFoundError, ValueError) as exc:
            raise ValueError(f"unknown time zone '{self.timezone}'") from exc
        if any(not p.strip() or len(p) > 120 for p in self.exclude_user_patterns):
            raise ValueError("exclusion patterns must be non-empty and at most 120 characters")
        return self


class PromotionGates(_Strict):
    """What a model version must show before it may be validated and promoted.  Every gate that is set must pass;
    a gate left empty is not checked and is reported as such."""

    min_test_pr_auc: float | None = Field(None, ge=0, le=1)
    min_test_roc_auc: float | None = Field(None, ge=0, le=1)
    max_brier: float | None = Field(None, gt=0, le=1)
    max_calibration_error: float | None = Field(None, gt=0, le=1)
    max_pr_auc_drop_vs_production: float | None = Field(None, ge=0, le=1)
    min_test_rows: int | None = Field(None, ge=1)
    min_test_positives: int | None = Field(None, ge=1)
    require_leakage_checks: bool = True
    require_reproducible_training: bool = True
    require_model_card: bool = True
    description: str = ""


SCHEMAS: dict[str, type[BaseModel]] = {
    "churn_definition": ChurnDefinition,
    "cost_matrix": CostMatrix,
    "risk_policy": RiskPolicy,
    "retention_playbook": RetentionPlaybook,
    "alert_rules": AlertRules,
    "promotion_gates": PromotionGates,
    "activity_definition": ActivityDefinition,
}

DEFAULT_PLAYBOOK = {
    "actions": [
        {"code": "csm_white_glove_call", "name": "Senior CSM call (white-glove)", "segment": "high_risk_high_value",
         "channel": "crm_task", "requires_human_review": True, "requires_marketing_consent": False,
         "description": "High-priority CRM task for a senior Customer Success Manager; the conversation is tailored "
                        "with the model's top contributing factors."},
        {"code": "reengagement_drip", "name": "Re-engagement content and webinar drip", "segment": "medium_risk_low_value",
         "channel": "email", "requires_human_review": False, "requires_marketing_consent": True,
         "description": "Automated content/webinar sequence for accounts with rising risk."},
        {"code": "retention_discount_offer", "name": "Retention discount offer", "segment": "medium_risk_low_value",
         "channel": "email", "requires_human_review": True, "requires_marketing_consent": True,
         "offer": {"discount_pct": 15, "is_example": True},
         "description": "Targeted discount (the 15% figure is the example from the project brief; set the real "
                        "offer in an approved playbook version). Used when the top risk factor is financial."},
        {"code": "payment_method_reminder", "name": "Payment-method update reminder", "segment": "involuntary",
         "channel": "in_app", "requires_human_review": False, "requires_marketing_consent": False,
         "description": "Transactional prompt to update an expiring or failing payment method before the billing date."},
    ],
    "reason_plays": {
        "usage": "Offer a guided training / enablement session focused on the features that have gone quiet.",
        "support": "Escalate open tickets to a support lead and schedule a service review.",
        "financial": "Review billing issues and plan fit with the account owner.",
        "rfm": "Schedule a check-in to re-establish regular engagement.",
        "customer": "Confirm the plan and contract still match the customer's profile.",
    },
}  # fmt: skip
DEFAULT_ALERT_RULES = {
    "rules": [
        {"metric": "feature_drift_share", "operator": ">=", "threshold": 0.3, "severity": "warning"},
        {"metric": "prediction_psi", "operator": ">=", "threshold": 0.25, "severity": "warning"},
        {"metric": "pr_auc_drop", "operator": ">=", "threshold": 0.1, "severity": "critical"},
        {"metric": "dq_score_min", "operator": "<", "threshold": 0.9, "severity": "warning"},
    ],
    "retrain_on": ["pr_auc_min", "pr_auc_drop"],
    "auto_retrain": True,
}


def default_payload(kind: str) -> dict:
    """Structural defaults only.  ``cost_matrix`` has none: money must come from the business."""
    if kind not in SCHEMAS:
        raise ValidationFailed(f"kind must be one of {', '.join(POLICY_KINDS)}", details={"field": "kind"})
    if kind == "churn_definition":
        return ChurnDefinition(horizon_days=get_settings().default_horizon_days).model_dump(mode="json")
    if kind == "risk_policy":
        return RiskPolicy().model_dump(mode="json")
    if kind == "retention_playbook":
        return RetentionPlaybook.model_validate(DEFAULT_PLAYBOOK).model_dump(mode="json")
    if kind == "alert_rules":
        return AlertRules.model_validate(DEFAULT_ALERT_RULES).model_dump(mode="json")
    if kind == "activity_definition":
        return ActivityDefinition().model_dump(mode="json")
    if kind == "promotion_gates":
        return PromotionGates().model_dump(mode="json")
    raise ValidationFailed(f"no default exists for policy kind '{kind}'; values must be supplied explicitly")


def validate_payload(kind: str, payload: dict) -> dict:
    if kind not in SCHEMAS:
        raise ValidationFailed(f"kind must be one of {', '.join(POLICY_KINDS)}", details={"field": "kind"})
    try:
        return SCHEMAS[kind].model_validate(payload).model_dump(mode="json")
    except ValidationError as exc:
        details = [{"field": ".".join(str(p) for p in e["loc"]), "message": e["msg"]} for e in exc.errors()]
        raise ValidationFailed(f"invalid {kind} policy", details=details) from exc


def parse(policy: Policy) -> Any:
    return SCHEMAS[policy.kind].model_validate(policy.payload)


def create(session: Session, principal: Principal, *, kind: str, name: str, payload: dict, note: str | None = None) -> Policy:
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    clean = validate_payload(kind, payload)
    policy = Policy(tenant_id=principal.tenant_id, kind=kind, name=name, payload=clean, note=note, status="draft",
                    version=next_version(session, Policy, tenant_id=principal.tenant_id, kind=kind, name=name),
                    created_by=principal.user_id)  # fmt: skip
    session.add(policy)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="policy.created", entity_type="policy",
                 entity_id=policy.id, detail={"kind": kind, "name": name, "version": policy.version})  # fmt: skip
    return policy


def submit(session: Session, principal: Principal, policy_id: int) -> Policy:
    policy = get_owned(session, Policy, principal.tenant_id, policy_id, label="Policy")
    if policy.status != "draft":
        raise Conflict(f"only a draft can be submitted (current status: {policy.status})")
    policy.status, policy.submitted_at = "pending", utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="policy.submitted",
                 entity_type="policy", entity_id=policy.id)  # fmt: skip
    return policy


def review(session: Session, principal: Principal, policy_id: int, *, approve: bool, note: str | None = None) -> Policy:
    policy = get_owned(session, Policy, principal.tenant_id, policy_id, label="Policy")
    if policy.status != "pending":
        raise Conflict(f"only a pending policy can be reviewed (current status: {policy.status})")
    if policy.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a policy cannot be approved or rejected by its author",
                        code="self_approval_forbidden")  # fmt: skip
    policy.status = "approved" if approve else "rejected"
    policy.reviewed_by, policy.reviewed_at, policy.review_note = principal.user_id, utcnow(), note
    if approve:
        older = select(Policy).where(Policy.tenant_id == policy.tenant_id, Policy.kind == policy.kind,
                                     Policy.name == policy.name, Policy.status == "approved", Policy.id != policy.id)  # fmt: skip
        for previous in session.execute(older).scalars():
            previous.status = "retired"
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, entity_type="policy", entity_id=policy.id,
                 action="policy.approved" if approve else "policy.rejected",
                 detail={"kind": policy.kind, "name": policy.name, "version": policy.version, "note": note})  # fmt: skip
    return policy


def get_active(session: Session, tenant_id: int, kind: str, *, name: str | None = None, required: bool = True) -> Policy | None:
    stmt = select(Policy).where(Policy.tenant_id == tenant_id, Policy.kind == kind, Policy.status == "approved")
    if name:
        stmt = stmt.where(Policy.name == name)
    policy = session.execute(stmt.order_by(Policy.reviewed_at.desc(), Policy.id.desc()).limit(1)).scalar_one_or_none()
    if policy is None and required:
        raise NotFound(f"No approved {kind.replace('_', ' ')} policy exists yet; create one and have it approved",
                       code="policy_not_approved")  # fmt: skip
    return policy


def get_approved(session: Session, tenant_id: int, policy_id: int, kind: str) -> Policy:
    policy = get_owned(session, Policy, tenant_id, policy_id, label="Policy")
    if policy.kind != kind:
        raise ValidationFailed(f"policy {policy_id} is a {policy.kind}, not a {kind}")
    if policy.status not in ("approved", "retired"):
        raise Conflict(f"{kind.replace('_', ' ')} v{policy.version} is not approved (status: {policy.status})",
                       code="policy_not_approved")  # fmt: skip
    return policy


def view(policy: Policy) -> dict:
    return to_dict(policy)
