"""Optional mirror of registered model versions into an MLflow tracking server / model registry.

The platform's own registry stays the source of truth for approval and serving.  When
``CHURN_MLFLOW_TRACKING_URI`` is set, each registered version is also logged to MLflow (parameters,
metrics, the model artifact and a model card) and created in the MLflow Model Registry; the
``production`` alias follows the platform stage.  When it is not set, nothing happens.
"""

from __future__ import annotations

import json
import os
import tempfile
import time
import warnings
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import read_session, session_scope
from ..models import FeatureContract, MLDataset, ModelRun, ModelVersion
from . import audit, jobs


def enabled() -> bool:
    return bool(get_settings().mlflow_tracking_uri)


def enqueue_if_enabled(session: Session, version: ModelVersion) -> Any:
    if not enabled():
        return None
    return jobs.enqueue(session, tenant_id=version.tenant_id, job_type="mlops.mlflow_mirror", payload={"version_id": version.id},
                        created_by=version.created_by)  # fmt: skip


def _flat(prefix: str, value: Any, out: dict[str, float]) -> None:
    if isinstance(value, bool):
        return
    if isinstance(value, int | float):
        out[prefix] = float(value)
    elif isinstance(value, dict):
        for key, item in value.items():
            _flat(f"{prefix}.{key}" if prefix else str(key), item, out)


class RegistryUnavailable(RuntimeError):
    """The MLflow server did not answer (as opposed to answering that something does not exist)."""


def registered_name(tenant_id: int, name: str) -> str:
    return f"{get_settings().mlflow_experiment}.tenant-{tenant_id}.{name}"


def _client() -> tuple[Any, Any]:
    settings = get_settings()
    # an unreachable registry must fail in seconds, not after MLflow's default of minutes of retries
    os.environ.setdefault("MLFLOW_HTTP_REQUEST_TIMEOUT", str(int(settings.mlflow_http_timeout_seconds)))
    os.environ.setdefault("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "1")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # MLflow and its dependencies emit deprecation warnings on import
        import mlflow
        from mlflow.tracking import MlflowClient

        mlflow.set_tracking_uri(settings.mlflow_tracking_uri)
        return mlflow, MlflowClient()


_alias_cache: dict[tuple, tuple[float, dict | None]] = {}
ALIAS_CACHE_SECONDS = 20.0


def resolve_alias(tenant_id: int, name: str, alias: str, *, use_cache: bool = True) -> dict | None:
    """Which model version an MLflow alias (``production``, ``validated``, ``staging``) names, or None when the
    alias does not exist.  Raises ``RegistryUnavailable`` when the server cannot be asked."""
    if not enabled():
        raise RegistryUnavailable("CHURN_MLFLOW_TRACKING_URI is not set")
    key = (get_settings().mlflow_tracking_uri, tenant_id, name, alias)
    cached = _alias_cache.get(key)
    if use_cache and cached is not None and time.monotonic() - cached[0] < ALIAS_CACHE_SECONDS:
        return cached[1]
    _mlflow, client = _client()
    from mlflow.exceptions import MlflowException

    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mv = client.get_model_version_by_alias(registered_name(tenant_id, name), alias)
    except MlflowException as exc:
        if getattr(exc, "error_code", "") in ("RESOURCE_DOES_NOT_EXIST", "INVALID_PARAMETER_VALUE"):
            _alias_cache[key] = (time.monotonic(), None)
            return None
        raise RegistryUnavailable(str(exc)[:300]) from exc
    except Exception as exc:  # connection refused, DNS, timeouts: requests exceptions wrapped or not
        raise RegistryUnavailable(f"{type(exc).__name__}: {exc}"[:300]) from exc
    tags = dict(mv.tags or {})
    found = {"mlflow_version": str(mv.version), "registered_model": mv.name, "run_id": mv.run_id,
             "platform_version_id": int(tags["platform.model_version_id"]) if tags.get("platform.model_version_id", "").isdigit() else None,
             "artifact_sha256": tags.get("artifact.sha256"), "lifecycle_state": tags.get("platform.lifecycle_state"), "tags": tags}  # fmt: skip
    _alias_cache[key] = (time.monotonic(), found)
    return found


def reset_cache() -> None:
    _alias_cache.clear()


def latest_validated(tenant_id: int, name: str = "churn-model") -> dict | None:
    """The newest model version that passed the promotion gates, as the MLflow registry reports it."""
    return resolve_alias(tenant_id, name, "validated", use_cache=False)


def mirror(version_id: int, ctx: Any = None) -> dict:
    """Bring MLflow in line with one registry entry.  Safe to run any number of times: the MLflow run and model
    version are created once; afterwards only tags and aliases move."""
    if not enabled():
        return {"status": "disabled", "reason": "CHURN_MLFLOW_TRACKING_URI is not set"}
    settings = get_settings()
    from .registry import lifecycle_of

    with read_session() as rs:
        version = rs.get(ModelVersion, version_id)
        if version is None:
            raise jobs.PermanentJobError(f"model version {version_id} does not exist")
        run = rs.get(ModelRun, version.model_run_id)
        dataset = rs.get(MLDataset, run.dataset_id)
        contract = rs.get(FeatureContract, version.contract_id)
        name = registered_name(version.tenant_id, version.name)
        params = {"algorithm": run.algorithm, "imbalance_strategy": run.imbalance_strategy, "seed": run.seed,
                  **{f"hp.{k}": v for k, v in (run.params or {}).items()}}  # fmt: skip
        metrics: dict[str, float] = {}
        for split, values in (("valid", run.valid_metrics), ("test", run.test_metrics), ("cv", run.cv_metrics)):
            _flat(split, {k: v for k, v in (values or {}).items() if k in ("pr_auc", "roc_auc", "brier", "ece", "log_loss", "pr_auc_mean", "pr_auc_std")}, metrics)
        state = lifecycle_of(version)
        tags = {"platform.model_version_id": str(version.id), "platform.version": str(version.version), "platform.stage": version.stage,
                "platform.approval_status": version.approval_status, "platform.lifecycle_state": state,
                "platform.validated": "true" if version.validated_at is not None else "false",
                "platform.validated_at": version.validated_at.isoformat() if version.validated_at is not None else "",
                "dataset.fingerprint": dataset.fingerprint or "", "feature_contract.schema_hash": contract.schema_hash,
                "artifact.sha256": run.artifact_sha256 or ""}  # fmt: skip
        card = {"name": version.name, "version": version.version, "algorithm": run.algorithm, "threshold": version.threshold,
                "threshold_basis": version.threshold_basis, "features": list(contract.features), "valid_metrics": run.valid_metrics,
                "test_metrics": run.test_metrics, "calibration": run.calibration, "dataset_fingerprint": dataset.fingerprint,
                "approval_status": version.approval_status, "stage": version.stage}  # fmt: skip
        artifact, tenant_id, model_name = storage.resolve(run.artifact_path), version.tenant_id, version.name
        existing_version, run_id = version.mlflow_model_version, version.mlflow_run_id
    mlflow, client = _client()
    created = False
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if existing_version is None:
            mlflow.set_experiment(settings.mlflow_experiment)
            with mlflow.start_run(run_name=f"{card['name']}-v{card['version']}") as active, tempfile.TemporaryDirectory() as tmp:
                mlflow.log_params({k: str(v)[:500] for k, v in params.items()})
                if metrics:
                    mlflow.log_metrics(metrics)
                mlflow.set_tags(tags)
                card_path = Path(tmp) / "model_card.json"
                card_path.write_text(json.dumps(card, indent=2, default=str))
                mlflow.log_artifact(str(card_path), artifact_path="model")
                mlflow.log_artifact(str(artifact), artifact_path="model")
                run_id = active.info.run_id
            if not client.search_registered_models(filter_string=f"name = '{name}'"):
                client.create_registered_model(name, description="Model versions of the churn platform; lifecycle tags and aliases follow the platform's registry.")
            existing_version = str(client.create_model_version(name, source=f"runs:/{run_id}/model", run_id=run_id, tags=tags).version)
            created = True
            with session_scope() as ws:
                row = ws.get(ModelVersion, version_id)
                row.mlflow_model_version, row.mlflow_registered_name, row.mlflow_run_id = existing_version, name, run_id
        for key, value in tags.items():
            client.set_model_version_tag(name, existing_version, key, value)
        # aliases follow the platform's state for every version of this model (one source for all three)
        with read_session() as rs:
            from sqlalchemy import select

            siblings = rs.execute(select(ModelVersion).where(ModelVersion.tenant_id == tenant_id, ModelVersion.name == model_name,
                                                             ModelVersion.mlflow_model_version.is_not(None)).order_by(ModelVersion.version.desc())).scalars().all()  # fmt: skip
            wanted = {
                "production": next((v.mlflow_model_version for v in siblings if v.stage == "production" and v.approval_status == "approved"), None),
                "staging": next((v.mlflow_model_version for v in siblings if v.stage == "staging" and v.approval_status == "approved"), None),
                "validated": next((v.mlflow_model_version for v in siblings if v.validated_at is not None and v.approval_status != "rejected"
                                   and v.stage != "archived"), None),
            }  # fmt: skip
        current = dict(client.get_registered_model(name).aliases or {})
        for alias, target in wanted.items():
            if target is not None and str(current.get(alias)) != str(target):
                client.set_registered_model_alias(name, alias, target)
            elif target is None and alias in current:
                client.delete_registered_model_alias(name, alias)
    reset_cache()
    with session_scope() as ws:
        audit.record(ws, tenant_id=tenant_id, action="mlflow.mirrored" if created else "mlflow.synchronised", entity_type="model_version",
                     entity_id=version_id, detail={"registered_model": name, "mlflow_version": existing_version, "run_id": run_id,
                                                   "lifecycle_state": state, "aliases": wanted})  # fmt: skip
    return {"status": "mirrored" if created else "synchronised", "registered_model": name, "mlflow_version": existing_version, "run_id": run_id,
            "lifecycle_state": state, "aliases": wanted, "production_alias": wanted["production"] == existing_version}  # fmt: skip
