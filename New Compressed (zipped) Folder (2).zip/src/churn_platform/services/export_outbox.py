"""The durable side of a delivery: the outbox, the run record and the tenant checkpoint (1.3.0).

:mod:`churn_platform.services.destinations.base` decides *what happened* to each record while the process is running.
This module writes that decision down, so that a process that stops halfway can be resumed without guessing, and so
that "what did we send, and what did the destination accept" is a question the database can answer afterwards.

Three things are recorded, and each of them exists because its absence caused a defect:

**The run** (``export_runs``) — selected, acknowledged, failed, quarantined, the checksum of the acknowledged set, the
watermark.  The unique key is ``(tenant_id, destination, run_id)``, so a job that retries the same run updates its row
instead of recording a second, contradictory history of it.

**The outbox** (``export_outbox``) — one row per record, with its identity, its idempotency key, its payload digest, its
state, its attempts and its error.  This is what makes a restart safe: :func:`outstanding` is the list of records that
were not acknowledged, and it is a query rather than a re-derivation.  1.2.0 had nothing here, so a resumed export
either re-sent the whole window or skipped the part it had not sent.

**The checkpoint** (``export_checkpoints``) — one row per tenant and destination holding the contiguous acknowledged
watermark.  It is advanced by :func:`record_run` from the *acknowledgements* of that run, and it only ever moves
forward: a run that acknowledges an older record cannot push it back, because everything behind it has already been
accepted and re-sending it would be a no-op at best.

The watermark stored here is per tenant.  Two tenants share a table, and one tenant's failure must not hold the other's
export back — that is the same tenant-collision defect seen from the resume side.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import utcnow
from ..errors import ValidationFailed
from ..models import ExportCheckpoint, ExportOutboxRecord, ExportRun
from .destinations.base import ACKNOWLEDGED, DeliveryResult


def _aware(value: datetime | None) -> datetime | None:
    """SQLite hands timestamps back naive; the platform's timestamps are UTC and are compared as such."""
    if value is None:
        return None
    return value if value.tzinfo is not None else value.replace(tzinfo=UTC)


def record_run(session: Session, result: DeliveryResult, *, tenant_id: int) -> ExportRun:
    """Write the run, its per-record states and the tenant's checkpoint; return the run row.

    Idempotent by construction: a second call for the same ``(tenant, destination, run_id)`` finds the existing run row
    and the existing outbox rows (unique on the idempotency key) and updates them rather than adding a second copy.
    """
    if not result.destination:
        raise ValidationFailed("a delivery result must name its destination", details={"field": "destination"})
    foreign = sorted({outcome.tenant_id for outcome in result.outcomes if outcome.tenant_id != tenant_id})
    if foreign:
        # a run belongs to one tenant; mixing them here is how one tenant's watermark would start moving another's export
        raise ValidationFailed(
            f"run {result.run_id} carries records for tenant(s) {foreign} but is being recorded for tenant {tenant_id}",
            details={"field": "tenant_id", "tenant_id": tenant_id, "foreign_tenants": foreign},
        )
    run = session.execute(
        select(ExportRun).where(ExportRun.tenant_id == tenant_id, ExportRun.destination == result.destination,
                                ExportRun.run_id == result.run_id)
    ).scalar_one_or_none()  # fmt: skip
    if run is None:
        run = ExportRun(tenant_id=tenant_id, destination=result.destination, run_id=result.run_id,
                        started_at=utcnow(), records_selected=result.selected)  # fmt: skip
        session.add(run)
        session.flush()

    run.records_selected = result.selected
    run.records_acknowledged = result.written
    run.records_failed = result.failed
    run.records_quarantined = len(result.quarantined)
    run.checksum = result.checksum or None
    run.watermark = result.watermark
    run.verification = result.verification
    run.finished_at = utcnow()
    if result.failed:
        run.status = "partial" if result.written else "failed"
    else:
        run.status = "completed"

    for outcome in result.outcomes:
        row = session.execute(
            select(ExportOutboxRecord).where(ExportOutboxRecord.destination == result.destination,
                                             ExportOutboxRecord.idempotency_key == outcome.idempotency_key)
        ).scalar_one_or_none()  # fmt: skip
        if row is None:
            row = ExportOutboxRecord(tenant_id=tenant_id, export_run_id=run.id, destination=result.destination,
                                     identity_key=outcome.identity_key,
                                     idempotency_key=outcome.idempotency_key, payload_checksum=outcome.payload_checksum,
                                     created_at=utcnow())  # fmt: skip
            session.add(row)
        row.export_run_id = run.id
        row.prediction_timestamp = outcome.prediction_timestamp
        row.status = outcome.status
        row.attempts = outcome.attempts
        row.external_reference = outcome.external_reference
        row.submitted_at = outcome.submitted_at
        row.acknowledged_at = outcome.acknowledged_at
        row.error_code = outcome.error_code
        row.error_description = outcome.error_description

    checkpoint = session.execute(
        select(ExportCheckpoint).where(ExportCheckpoint.tenant_id == tenant_id,
                                       ExportCheckpoint.destination == result.destination)
    ).scalar_one_or_none()  # fmt: skip
    if checkpoint is None:
        checkpoint = ExportCheckpoint(tenant_id=tenant_id, destination=result.destination, acknowledged_keys=[])
        session.add(checkpoint)
    moved = result.watermarks.get(tenant_id)
    current = _aware(checkpoint.watermark)
    if moved is not None and (current is None or moved > current):
        checkpoint.watermark = moved
        checkpoint.last_run_id = result.run_id
        checkpoint.acknowledged_keys = sorted(set(checkpoint.acknowledged_keys or []) | set(result.acknowledged_keys))[-500:]
    checkpoint.updated_at = utcnow()
    session.flush()
    return run


def checkpoint_for(session: Session, tenant_id: int, destination: str) -> ExportCheckpoint | None:
    """The tenant's checkpoint for a destination, or ``None`` when nothing has been delivered yet."""
    return session.execute(
        select(ExportCheckpoint).where(ExportCheckpoint.tenant_id == tenant_id, ExportCheckpoint.destination == destination)
    ).scalar_one_or_none()  # fmt: skip


def watermark_for(session: Session, tenant_id: int, destination: str) -> datetime | None:
    """The instant an incremental export for this tenant may start after.  ``None`` means "nothing yet, send it all"."""
    checkpoint = checkpoint_for(session, tenant_id, destination)
    return _aware(checkpoint.watermark) if checkpoint else None


def outstanding(session: Session, tenant_id: int, destination: str, *, keys: list[str] | None = None) -> list[ExportOutboxRecord]:
    """Records that were not acknowledged: the backlog a resumed run has to deliver, oldest first.

    A quarantine is included.  A record refused by validation was not sent and must be looked at; hiding it would make
    the backlog look shorter than the work.
    """
    stmt = (
        select(ExportOutboxRecord)
        .where(ExportOutboxRecord.tenant_id == tenant_id, ExportOutboxRecord.destination == destination,
               ExportOutboxRecord.status != ACKNOWLEDGED)
        .order_by(ExportOutboxRecord.prediction_timestamp, ExportOutboxRecord.id)
    )
    if keys is not None:
        stmt = stmt.where(ExportOutboxRecord.idempotency_key.in_(keys))
    return list(session.execute(stmt).scalars())


def acknowledged_keys(session: Session, tenant_id: int, destination: str, *, limit: int = 5000) -> set[str]:
    """The idempotency keys this tenant's deliveries have already had accepted."""
    rows = session.execute(
        select(ExportOutboxRecord.idempotency_key)
        .where(ExportOutboxRecord.tenant_id == tenant_id, ExportOutboxRecord.destination == destination,
               ExportOutboxRecord.status == ACKNOWLEDGED)
        .order_by(ExportOutboxRecord.id.desc())
        .limit(limit)
    ).scalars()
    return set(rows)


def run_view(run: ExportRun) -> dict[str, Any]:
    """A run as the API and the browser show it."""
    return {
        "id": run.id,
        "destination": run.destination,
        "run_id": run.run_id,
        "status": run.status,
        "selected": run.records_selected,
        "acknowledged": run.records_acknowledged,
        "failed": run.records_failed,
        "quarantined": run.records_quarantined,
        "checksum": run.checksum,
        "watermark": run.watermark.isoformat() if run.watermark else None,
        "verification": run.verification,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
    }


__all__ = [
    "acknowledged_keys", "checkpoint_for", "outstanding", "record_run", "run_view", "watermark_for",
]
