"""Data validation and cleaning: versioned rules, scorecards, findings and approved corrections.

Raw files are never modified.  Corrections change only the cleaned (canonical) layer, need an
independent approval, bump the row's ``record_version`` and leave a before/after image in
``entity_history`` so every cleaned value can be traced back to who changed it and why.
"""

from __future__ import annotations

import re
from datetime import timedelta
from typing import Any

from sqlalchemy import and_, delete, func, insert, or_, select, update
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, NotFound, ValidationFailed
from ..models import ENTITY_MODELS, ENTITY_TYPES, Correction, DQFinding, DQRule, DQRun, EntityHistory
from ..security import Principal
from . import attributes, audit, jobs
from .common import get_owned, json_safe, to_dict
from .schemas import ENTITY_SCHEMAS, CoercionError, coerce, is_missing

DIMENSIONS = ("completeness", "uniqueness", "validity", "consistency", "timeliness", "integrity")
SEVERITY_WEIGHT = {"error": 3.0, "warning": 2.0, "info": 1.0}
MAX_FINDINGS_PER_RULE = 100
NAMED_PATTERNS = {
    "email": re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
    "currency_code": re.compile(r"^[A-Z]{3}$"),
    "no_surrounding_whitespace": re.compile(r"^\S(.*\S)?$"),
}
RULE_TYPES: dict[str, dict[str, Any]] = {
    "not_null": {"dimension": "completeness", "params": ["field"]},
    "unique": {"dimension": "uniqueness", "params": ["fields"]},
    "range": {"dimension": "validity", "params": ["field"], "optional": ["min", "max"]},
    "allowed_values": {"dimension": "validity", "params": ["field", "values"]},
    "pattern": {"dimension": "validity", "params": ["field", "pattern"]},
    "date_order": {"dimension": "consistency", "params": ["earlier", "later"]},
    "not_future": {"dimension": "timeliness", "params": ["field"]},
    "freshness": {"dimension": "timeliness", "params": ["field", "max_age_days"]},
    "has_related": {"dimension": "integrity", "params": ["related_entity"]},
}
_RELATED_FK = {"customers": "customer_id", "subscriptions": "subscription_id", "invoices": "invoice_id",
               "accounts": "account_id", "plans": "plan_id"}  # fmt: skip

DEFAULT_RULES: list[dict] = [
    {"name": "customer_email_present", "entity_type": "customers", "rule_type": "not_null", "severity": "warning", "params": {"field": "email"}},
    {"name": "customer_email_format", "entity_type": "customers", "rule_type": "pattern", "severity": "warning", "params": {"field": "email", "pattern": "email"}},
    {"name": "customer_industry_present", "entity_type": "customers", "rule_type": "not_null", "severity": "info", "params": {"field": "industry"}},
    {"name": "customer_has_subscription", "entity_type": "customers", "rule_type": "has_related", "severity": "warning", "params": {"related_entity": "subscriptions"}},
    {"name": "customer_email_unique", "entity_type": "customers", "rule_type": "unique", "severity": "warning", "params": {"fields": ["email"]}},
    {"name": "subscription_mrr_present", "entity_type": "subscriptions", "rule_type": "not_null", "severity": "error", "params": {"field": "mrr"}},
    {"name": "subscription_mrr_range", "entity_type": "subscriptions", "rule_type": "range", "severity": "error", "params": {"field": "mrr", "min": 0}},
    {"name": "subscription_dates_ordered", "entity_type": "subscriptions", "rule_type": "date_order", "severity": "error", "params": {"earlier": "started_at", "later": "ended_at"}},
    {"name": "subscription_billing_period_valid", "entity_type": "subscriptions", "rule_type": "allowed_values", "severity": "warning", "params": {"field": "billing_period", "values": ["monthly", "quarterly", "annual"]}},
    {"name": "subscription_plan_present", "entity_type": "subscriptions", "rule_type": "not_null", "severity": "warning", "params": {"field": "plan_id"}},
    {"name": "invoice_amount_range", "entity_type": "invoices", "rule_type": "range", "severity": "error", "params": {"field": "amount", "min": 0}},
    {"name": "invoice_due_after_issue", "entity_type": "invoices", "rule_type": "date_order", "severity": "warning", "params": {"earlier": "issued_at", "later": "due_at"}},
    {"name": "payment_not_in_future", "entity_type": "payments", "rule_type": "not_future", "severity": "error", "params": {"field": "attempted_at"}},
    {"name": "usage_not_in_future", "entity_type": "usage_events", "rule_type": "not_future", "severity": "error", "params": {"field": "occurred_at"}},
    {"name": "usage_duration_range", "entity_type": "usage_events", "rule_type": "range", "severity": "error", "params": {"field": "duration_seconds", "min": 0, "max": 86400}},
    {"name": "usage_data_fresh", "entity_type": "usage_events", "rule_type": "freshness", "severity": "warning", "params": {"field": "occurred_at", "max_age_days": 7}},
    {"name": "support_resolution_ordered", "entity_type": "support_interactions", "rule_type": "date_order", "severity": "error", "params": {"earlier": "opened_at", "later": "resolved_at"}},
    {"name": "support_nps_range", "entity_type": "support_interactions", "rule_type": "range", "severity": "error", "params": {"field": "nps_score", "min": 0, "max": 10}},
]  # fmt: skip


# ----------------------------------------------------------------------------- rules
def _validate_rule(entity_type: str, rule_type: str, params: dict) -> dict:
    if entity_type not in ENTITY_TYPES:
        raise ValidationFailed(f"entity_type must be one of {', '.join(ENTITY_TYPES)}", details={"field": "entity_type"})
    spec = RULE_TYPES.get(rule_type)
    if spec is None:
        raise ValidationFailed(f"rule_type must be one of {', '.join(RULE_TYPES)}", details={"field": "rule_type"})
    params = dict(params or {})
    missing = [p for p in spec["params"] if is_missing(params.get(p)) and params.get(p) != 0]
    if missing:
        raise ValidationFailed(f"rule parameters missing: {', '.join(missing)}", details={"field": "params"})
    unknown = set(params) - set(spec["params"]) - set(spec.get("optional", ()))
    if unknown:
        raise ValidationFailed(f"unknown rule parameters: {', '.join(sorted(unknown))}", details={"field": "params"})
    columns = set(ENTITY_MODELS[entity_type].__table__.c.keys())
    names = [params[k] for k in ("field", "earlier", "later") if k in params] + list(params.get("fields") or [])
    for name in names:
        if name not in columns:
            raise ValidationFailed(f"'{name}' is not a column of {entity_type}", details={"field": "params"})
    if rule_type == "range":
        if params.get("min") is None and params.get("max") is None:
            raise ValidationFailed("a range rule needs min and/or max", details={"field": "params"})
        for bound in ("min", "max"):
            if params.get(bound) is not None and not isinstance(params[bound], int | float):
                raise ValidationFailed(f"{bound} must be a number", details={"field": "params"})
    if rule_type == "allowed_values" and not (isinstance(params["values"], list) and params["values"]):
        raise ValidationFailed("values must be a non-empty list", details={"field": "params"})
    if rule_type == "pattern" and params["pattern"] not in NAMED_PATTERNS:
        raise ValidationFailed(f"pattern must be one of {', '.join(NAMED_PATTERNS)}", details={"field": "params"})
    if rule_type == "freshness" and not (isinstance(params["max_age_days"], int | float) and params["max_age_days"] > 0):
        raise ValidationFailed("max_age_days must be a positive number", details={"field": "params"})
    if rule_type == "has_related":
        related = params["related_entity"]
        fk_col = _RELATED_FK.get(entity_type)
        if related not in ENTITY_MODELS or fk_col is None or fk_col not in ENTITY_MODELS[related].__table__.c:
            raise ValidationFailed(f"{related} rows do not reference {entity_type}", details={"field": "params"})
    return params


def save_rule(session: Session, principal: Principal | None, *, tenant_id: int, name: str, entity_type: str, rule_type: str,
              params: dict, severity: str = "error", description: str | None = None) -> DQRule:
    """Create a rule, or a new version of it if the name exists (older versions are deactivated)."""
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if severity not in SEVERITY_WEIGHT:
        raise ValidationFailed("severity must be info, warning or error", details={"field": "severity"})
    params = _validate_rule(entity_type, rule_type, params)
    latest = session.execute(select(func.max(DQRule.version)).where(DQRule.tenant_id == tenant_id, DQRule.name == name)).scalar()
    session.execute(update(DQRule).where(DQRule.tenant_id == tenant_id, DQRule.name == name).values(is_active=False))
    rule = DQRule(tenant_id=tenant_id, name=name, version=(latest or 0) + 1, entity_type=entity_type, rule_type=rule_type,
                  dimension=RULE_TYPES[rule_type]["dimension"], severity=severity, params=params, description=description,
                  is_active=True, created_by=principal.user_id if principal else None)  # fmt: skip
    session.add(rule)
    session.flush()
    audit.record(session, tenant_id=tenant_id, actor=principal, action="dq.rule_saved", entity_type="dq_rule",
                 entity_id=rule.id, detail={"name": name, "version": rule.version, "rule_type": rule_type})  # fmt: skip
    return rule


def set_rule_active(session: Session, principal: Principal, rule_id: int, active: bool) -> DQRule:
    rule = get_owned(session, DQRule, principal.tenant_id, rule_id, label="Rule")
    if active:
        session.execute(update(DQRule).where(DQRule.tenant_id == rule.tenant_id, DQRule.name == rule.name).values(is_active=False))
    rule.is_active = active
    audit.record(session, tenant_id=rule.tenant_id, actor=principal, action="dq.rule_toggled", entity_type="dq_rule",
                 entity_id=rule.id, detail={"active": active, "version": rule.version})  # fmt: skip
    return rule


def seed_default_rules(session: Session, tenant_id: int, principal: Principal | None = None) -> int:
    existing = set(session.execute(select(DQRule.name).where(DQRule.tenant_id == tenant_id)).scalars())
    created = 0
    for spec in DEFAULT_RULES:
        if spec["name"] not in existing:
            save_rule(session, principal, tenant_id=tenant_id, **spec)
            created += 1
    return created


# ----------------------------------------------------------------------------- evaluation
def _evaluate(session: Session, rule: DQRule) -> dict:
    """Return {total, failed, samples:[(entity_id, external_id, detail)], note} for one rule."""
    table = ENTITY_MODELS[rule.entity_type].__table__
    tenant = table.c.tenant_id == rule.tenant_id
    p, kind = rule.params, rule.rule_type
    total = session.execute(select(func.count()).select_from(table).where(tenant)).scalar_one()
    note = None
    cond = None
    value_col = None
    if kind == "not_null":
        col = table.c[p["field"]]
        cond = col.is_(None) if not hasattr(col.type, "length") else or_(col.is_(None), col == "")
    elif kind == "range":
        value_col = col = table.c[p["field"]]
        bounds = ([col < p["min"]] if p.get("min") is not None else []) + ([col > p["max"]] if p.get("max") is not None else [])
        cond = and_(col.is_not(None), or_(*bounds))
        total = session.execute(select(func.count()).select_from(table).where(tenant, col.is_not(None))).scalar_one()
    elif kind == "allowed_values":
        value_col = col = table.c[p["field"]]
        cond = and_(col.is_not(None), col.not_in([str(v) for v in p["values"]]))
        total = session.execute(select(func.count()).select_from(table).where(tenant, col.is_not(None))).scalar_one()
    elif kind == "date_order":
        a, b = table.c[p["earlier"]], table.c[p["later"]]
        cond = and_(a.is_not(None), b.is_not(None), b < a)
        total = session.execute(select(func.count()).select_from(table).where(tenant, a.is_not(None), b.is_not(None))).scalar_one()
    elif kind == "not_future":
        value_col = col = table.c[p["field"]]
        cond = col > utcnow() + timedelta(hours=1)
    elif kind == "has_related":
        related = ENTITY_MODELS[p["related_entity"]].__table__
        fk_col = related.c[_RELATED_FK[rule.entity_type]]
        cond = ~select(related.c.id).where(fk_col == table.c.id).exists()
    elif kind == "unique":
        cols = [table.c[f] for f in p["fields"]]
        present = and_(*[c.is_not(None) for c in cols])
        dup = select(*cols).where(tenant, present).group_by(*cols).having(func.count() > 1).subquery()
        failed = session.execute(
            select(func.count()).select_from(table.join(dup, and_(*[table.c[c.key] == dup.c[c.key] for c in cols]))).where(tenant)
        ).scalar_one()
        rows = session.execute(
            select(table.c.id, table.c.external_id, *cols).select_from(table.join(dup, and_(*[table.c[c.key] == dup.c[c.key] for c in cols])))
            .where(tenant).order_by(*cols, table.c.id).limit(MAX_FINDINGS_PER_RULE)
        ).all()  # fmt: skip
        total = session.execute(select(func.count()).select_from(table).where(tenant, present)).scalar_one()
        samples = [(r[0], r[1], {"duplicate_of": {c.key: json_safe(r[2 + n]) for n, c in enumerate(cols)}}) for r in rows]
        return {"total": total, "failed": failed, "samples": samples, "note": note}
    elif kind == "pattern":
        col = table.c[p["field"]]
        regex = NAMED_PATTERNS[p["pattern"]]
        failed, samples, total = 0, [], 0
        stmt = select(table.c.id, table.c.external_id, col).where(tenant, col.is_not(None)).execution_options(yield_per=5000)
        for row_id, ext, value in session.execute(stmt):
            total += 1
            if not regex.match(str(value)[:1000]):
                failed += 1
                if len(samples) < MAX_FINDINGS_PER_RULE:
                    samples.append((row_id, ext, {"value": str(value)[:120], "expected": p["pattern"]}))
        return {"total": total, "failed": failed, "samples": samples, "note": note}
    elif kind == "freshness":
        newest = session.execute(select(func.max(table.c[p["field"]])).where(tenant)).scalar()
        if newest is None:
            return {"total": 0, "failed": 0, "samples": [], "note": "no rows to assess"}
        if getattr(newest, "tzinfo", True) is None:
            from datetime import UTC

            newest = newest.replace(tzinfo=UTC)
        age_days = (utcnow() - newest).total_seconds() / 86400
        stale = age_days > float(p["max_age_days"])
        detail = {"newest": newest.isoformat(), "age_days": round(age_days, 2), "max_age_days": p["max_age_days"]}
        return {"total": 1, "failed": int(stale), "samples": [(None, None, detail)] if stale else [],
                "note": f"newest record is {age_days:.1f} days old", "table_level": True}  # fmt: skip
    failed = session.execute(select(func.count()).select_from(table).where(tenant, cond)).scalar_one()
    cols = [table.c.id, table.c.external_id] + ([value_col] if value_col is not None else [])
    rows = session.execute(select(*cols).where(tenant, cond).order_by(table.c.id).limit(MAX_FINDINGS_PER_RULE)).all()
    samples = [(r[0], r[1], {"value": json_safe(r[2])} if value_col is not None else {}) for r in rows]
    return {"total": total, "failed": failed, "samples": samples, "note": note}


def run_quality(run_id: int, ctx: Any = None) -> dict:
    """Evaluate all active rules in scope and persist a scorecard plus sample findings."""
    try:
        with read_session() as rs:  # read phase: never blocks writers
            run = rs.get(DQRun, run_id)
            if run is None:
                raise jobs.PermanentJobError(f"quality run {run_id} does not exist")
            tenant_id, scope = run.tenant_id, run.scope or {}
            stmt = select(DQRule).where(DQRule.tenant_id == tenant_id, DQRule.is_active.is_(True)).order_by(DQRule.entity_type, DQRule.name)
            if scope.get("entity_types"):
                stmt = stmt.where(DQRule.entity_type.in_(scope["entity_types"]))
            rules = rs.execute(stmt).scalars().all()
            results, pending = [], []
            for n, rule in enumerate(rules):
                if ctx is not None:
                    ctx.progress(n / max(1, len(rules)), f"rule {n + 1}/{len(rules)}: {rule.name}", force=True)
                outcome = _evaluate(rs, rule)
                total, failed = outcome["total"], outcome["failed"]
                pass_rate = None if total == 0 else round(1 - failed / total, 6)
                results.append({"rule_id": rule.id, "name": rule.name, "version": rule.version, "entity_type": rule.entity_type,
                                "rule_type": rule.rule_type, "dimension": rule.dimension, "severity": rule.severity,
                                "rows_checked": total, "rows_failed": failed, "pass_rate": pass_rate, "note": outcome["note"],
                                "status": "no_data" if total == 0 else "pass" if failed == 0 else "fail"})  # fmt: skip
                pending.extend({"tenant_id": tenant_id, "run_id": run_id, "rule_id": rule.id, "rule_name": rule.name,
                                "rule_version": rule.version, "entity_type": rule.entity_type, "entity_id": entity_id,
                                "entity_ref": ext, "severity": rule.severity, "detail": detail, "status": "open"}
                               for entity_id, ext, detail in outcome["samples"])  # fmt: skip
        scored = [r for r in results if r["pass_rate"] is not None]
        weight_sum = sum(SEVERITY_WEIGHT[r["severity"]] for r in scored)
        score = round(sum(SEVERITY_WEIGHT[r["severity"]] * r["pass_rate"] for r in scored) / weight_sum, 6) if scored else None

        def _mean(items: list[dict]) -> float | None:
            return round(sum(i["pass_rate"] for i in items) / len(items), 6) if items else None

        scorecard = {
            "overall": score,
            "scoring": "severity-weighted mean of rule pass rates (error=3, warning=2, info=1); rules with no rows are excluded",
            "dimensions": {d: _mean([r for r in scored if r["dimension"] == d]) for d in DIMENSIONS},
            "entities": {e: _mean([r for r in scored if r["entity_type"] == e]) for e in sorted({r["entity_type"] for r in scored})},
            "rules": results,
            "findings_stored_per_rule_limit": MAX_FINDINGS_PER_RULE,
        }
        with session_scope() as ws:  # short write phase
            ws.execute(delete(DQFinding).where(DQFinding.run_id == run_id))
            if pending:
                ws.execute(insert(DQFinding.__table__), pending)
            ws.execute(update(DQRun).where(DQRun.id == run_id).values(
                scorecard=scorecard, score=score, rules_evaluated=len(rules), findings_count=len(pending),
                status="completed", finished_at=utcnow()))  # fmt: skip
            audit.record(ws, tenant_id=tenant_id, action="dq.run_completed", entity_type="dq_run", entity_id=run_id,
                         detail={"score": score, "rules": len(rules), "failed_rules": sum(1 for r in results if r["status"] == "fail")})  # fmt: skip
        return {"dq_run_id": run_id, "score": score, "rules_evaluated": len(rules), "findings": len(pending)}
    except Exception as exc:
        if not isinstance(exc, jobs.JobCancelled | jobs.JobInterrupted):
            with session_scope() as ws:
                ws.execute(update(DQRun).where(DQRun.id == run_id).values(status="failed", finished_at=utcnow()))
        raise


def start_run(session: Session, principal: Principal, entity_types: list[str] | None = None) -> tuple[DQRun, Any]:
    bad = [e for e in (entity_types or []) if e not in ENTITY_TYPES]
    if bad:
        raise ValidationFailed(f"unknown entity types: {', '.join(bad)}", details={"field": "entity_types"})
    seed_default_rules(session, principal.tenant_id, principal)
    run = DQRun(tenant_id=principal.tenant_id, status="running", scope={"entity_types": entity_types or []},
                created_by=principal.user_id)  # fmt: skip
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="quality.run", payload={"dq_run_id": run.id},
                       created_by=principal.user_id)  # fmt: skip
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="dq.run_started", entity_type="dq_run",
                 entity_id=run.id, detail={"entity_types": entity_types or "all"})  # fmt: skip
    return run, job


# ----------------------------------------------------------------------------- corrections
def _correctable(entity_type: str) -> dict[str, Any]:
    return {s.attr: s for s in ENTITY_SCHEMAS[entity_type] if s.ref is None and s.name != "external_id"}


def propose_correction(session: Session, principal: Principal, *, entity_type: str, entity_id: int, field: str,
                       new_value: Any, reason: str, finding_id: int | None = None) -> Correction:
    if entity_type not in ENTITY_MODELS:
        raise ValidationFailed(f"entity_type must be one of {', '.join(ENTITY_TYPES)}", details={"field": "entity_type"})
    if not (reason or "").strip() or len(reason.strip()) < 5:
        raise ValidationFailed("a reason of at least 5 characters is required", details={"field": "reason"})
    spec = _correctable(entity_type).get(field)
    if spec is None:
        raise ValidationFailed(f"'{field}' cannot be corrected; allowed: {', '.join(sorted(_correctable(entity_type)))}",
                               details={"field": "field"})  # fmt: skip
    row = get_owned(session, ENTITY_MODELS[entity_type], principal.tenant_id, entity_id, label=entity_type.rstrip("s").title())
    if is_missing(new_value):
        if spec.required or not ENTITY_MODELS[entity_type].__table__.c[field].nullable:
            raise ValidationFailed(f"'{field}' is required and cannot be cleared", details={"field": "new_value"})
        clean = None
    else:
        try:
            clean = coerce(spec, new_value)
        except CoercionError as exc:
            raise ValidationFailed(f"new value is not valid for {field}: {exc}", details={"field": "new_value"}) from exc
    old = getattr(row, field)
    if json_safe(old) == json_safe(clean):
        raise ValidationFailed("the new value is identical to the current value", details={"field": "new_value"})
    if finding_id is not None:
        get_owned(session, DQFinding, principal.tenant_id, finding_id, label="Finding")
    correction = Correction(tenant_id=principal.tenant_id, entity_type=entity_type, entity_id=entity_id, field=field,
                            old_value=json_safe(old), new_value=json_safe(clean), reason=reason.strip(), status="proposed",
                            finding_id=finding_id, proposed_by=principal.user_id)  # fmt: skip
    session.add(correction)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="dq.correction_proposed",
                 entity_type="correction", entity_id=correction.id,
                 detail={"target": f"{entity_type}:{entity_id}", "field": field})  # fmt: skip
    return correction


def review_correction(session: Session, principal: Principal, correction_id: int, *, approve: bool, note: str | None = None) -> Correction:
    correction = get_owned(session, Correction, principal.tenant_id, correction_id, label="Correction")
    if correction.status != "proposed":
        raise Conflict(f"correction is already {correction.status}")
    if correction.proposed_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a correction cannot be reviewed by the person who proposed it",
                        code="self_approval_forbidden")  # fmt: skip
    now = utcnow()
    correction.reviewed_by, correction.reviewed_at, correction.review_note = principal.user_id, now, note
    if not approve:
        correction.status = "rejected"
        audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="dq.correction_rejected",
                     entity_type="correction", entity_id=correction.id, detail={"note": note})  # fmt: skip
        return correction
    model = ENTITY_MODELS[correction.entity_type]
    row = session.get(model, correction.entity_id)
    if row is None or row.tenant_id != principal.tenant_id:
        raise NotFound("the record this correction targets no longer exists")
    spec = _correctable(correction.entity_type)[correction.field]
    before = getattr(row, correction.field)
    if json_safe(before) != correction.old_value:
        raise Conflict("the record changed after this correction was proposed; propose it again against the current value",
                       code="stale_correction")  # fmt: skip
    value = None if correction.new_value is None else coerce(spec, correction.new_value)
    setattr(row, correction.field, value)
    row.record_version += 1
    row.updated_at = now
    session.add(EntityHistory(tenant_id=row.tenant_id, entity_type=correction.entity_type, entity_id=row.id,
                              record_version=row.record_version, change_source="correction", correction_id=correction.id,
                              dataset_version_id=row.dataset_version_id, changed_by=principal.user_id, changed_at=now,
                              before={correction.field: json_safe(before)}, after={correction.field: correction.new_value}))  # fmt: skip
    if correction.entity_type == "customers" and correction.field in attributes.TRACKED:
        # a reviewed correction is a fix of known history: it holds from now on, and what was believed before stays on record
        attributes.ensure_initial(session, row.tenant_id)
        attributes.apply(session, row.tenant_id, row.id, correction.field, value, valid_from=now, basis="correction", source="correction",
                         recorded_by=principal.user_id, note=f"data-quality correction {correction.id}", now=now)  # fmt: skip
    correction.status, correction.applied_at = "applied", now
    if correction.finding_id:
        session.execute(update(DQFinding).where(DQFinding.id == correction.finding_id).values(status="corrected"))
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="dq.correction_applied",
                 entity_type="correction", entity_id=correction.id,
                 detail={"target": f"{correction.entity_type}:{row.id}", "field": correction.field,
                         "record_version": row.record_version, "note": note})  # fmt: skip
    return correction


def record_history(session: Session, tenant_id: int, entity_type: str, entity_id: int) -> dict:
    """Current cleaned values, raw provenance and the full change history of one canonical row."""
    model = ENTITY_MODELS.get(entity_type)
    if model is None:
        raise ValidationFailed(f"entity_type must be one of {', '.join(ENTITY_TYPES)}")
    row = get_owned(session, model, tenant_id, entity_id, label=entity_type.rstrip("s").title())
    history = session.execute(
        select(EntityHistory).where(EntityHistory.tenant_id == tenant_id, EntityHistory.entity_type == entity_type,
                                    EntityHistory.entity_id == entity_id).order_by(EntityHistory.record_version)
    ).scalars().all()  # fmt: skip
    return {"record": to_dict(row), "history": [to_dict(h) for h in history]}
