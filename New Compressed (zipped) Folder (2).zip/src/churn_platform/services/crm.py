"""Reverse ETL to CRM / engagement tools (Salesforce, HubSpot, Intercom) through an outbox.

Modes
  * TEST_ONLY   - no network I/O at all: the exact request is built and stored, the delivery is
                  marked ``skipped``.  This is the default and what the demo uses.
  * SANDBOX     - real HTTP calls to the vendor sandbox URL configured on the connection.
  * PRODUCTION  - real HTTP calls; additionally requires ``CHURN_CRM_ALLOW_PRODUCTION=true``.

The request shapes are configurable through ``field_mapping``.  Those for HubSpot and Intercom are checked against
the API descriptions the vendors publish (``scripts/check_crm_contracts.py``), Salesforce's against its documented
resource patterns.  The connectors have been exercised against a mock transport and, with a credential the vendor
rejects, against the vendors' live hosts.  No live vendor account has accepted a request: see docs/CRM_SETUP.md.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import quote

import httpx
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .. import netguard
from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import CRMConnection, CRMDelivery, Customer, Prediction, PredictionBatch, RetentionRecommendation
from ..security import Principal, SecretBox
from . import audit, jobs
from .common import get_owned, json_safe, to_dict

PROVIDERS = ("salesforce", "hubspot", "intercom")
MODES = ("TEST_ONLY", "SANDBOX", "PRODUCTION")
MAX_ATTEMPTS = 5
SALESFORCE_MIN_API = 61
DEFAULT_MAPPING: dict[str, dict[str, str]] = {
    "salesforce": {"object": "Account", "external_id_field": "External_Id__c", "probability": "Churn_Probability__c",
                   "risk_tier": "Churn_Risk_Tier__c", "reasons": "Churn_Top_Reasons__c", "scored_on": "Churn_Scored_On__c",
                   "api_version": "v61.0"},
    "hubspot": {"object": "companies", "id_property": "external_customer_id", "probability": "churn_probability",
                "risk_tier": "churn_risk_tier", "reasons": "churn_top_reasons", "scored_on": "churn_scored_on"},
    "intercom": {"probability": "churn_probability", "risk_tier": "churn_risk_tier", "reasons": "churn_top_reasons",
                 "scored_on": "churn_scored_on", "action": "churn_recommended_action", "action_subject": "churn_action_subject",
                 "action_segment": "churn_action_segment", "action_at": "churn_action_recommended_at", "api_version": "2.14"},
}  # fmt: skip
_transport: httpx.BaseTransport | None = None  # tests inject httpx.MockTransport here


def set_transport(transport: httpx.BaseTransport | None) -> None:
    global _transport
    _transport = transport


def _box() -> SecretBox:
    return SecretBox(get_settings().secret_key.get_secret_value())


def create_connection(session: Session, principal: Principal, *, provider: str, name: str, base_url: str, mode: str = "TEST_ONLY",
                      access_token: str | None = None, field_mapping: dict | None = None, auth_type: str = "token") -> CRMConnection:
    name = (name or "").strip()
    if provider not in PROVIDERS:
        raise ValidationFailed(f"provider must be one of {', '.join(PROVIDERS)}", details={"field": "provider"})
    if mode not in MODES:
        raise ValidationFailed(f"mode must be one of {', '.join(MODES)}", details={"field": "mode"})
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if not base_url.startswith("https://") and not (mode == "TEST_ONLY" or get_settings().env in ("development", "test")):
        raise ValidationFailed("base_url must use https", details={"field": "base_url"})
    # SSRF guard.  A TEST_ONLY connection never transmits anything, so only its syntax is checked;
    # every real delivery is vetted again (and pinned to the vetted address) at send time.
    netguard.vet(base_url, allow_private=get_settings().crm_allow_private_hosts, field_name="base_url", resolve=mode != "TEST_ONLY")
    if mode == "PRODUCTION" and not get_settings().crm_allow_production:
        raise Conflict("PRODUCTION CRM connections are disabled (set CHURN_CRM_ALLOW_PRODUCTION=true to allow them)",
                       code="crm_production_disabled")  # fmt: skip
    if auth_type not in ("token", "oauth"):
        raise ValidationFailed("auth_type must be token or oauth", details={"field": "auth_type"})
    if mode != "TEST_ONLY" and not access_token and auth_type == "token":
        raise ValidationFailed("an access token is required for SANDBOX and PRODUCTION connections", details={"field": "access_token"})
    unknown = set(field_mapping or {}) - set(DEFAULT_MAPPING[provider])
    if unknown:
        raise ValidationFailed(f"unknown mapping keys: {', '.join(sorted(unknown))}", details={"field": "field_mapping"})
    version = (field_mapping or {}).get("api_version")
    if version is not None and provider == "salesforce":
        # the score update relies on updateOnly, which Salesforce honours from API version 61.0 (Summer '24)
        match = re.fullmatch(r"v(\d{2,3})\.0", str(version))
        if not match or int(match.group(1)) < SALESFORCE_MIN_API:
            raise ValidationFailed(f"api_version must look like v61.0 and be v{SALESFORCE_MIN_API}.0 or later", details={"field": "field_mapping"})
    if version is not None and provider == "intercom" and not re.fullmatch(r"\d\.\d{1,2}", str(version)):
        raise ValidationFailed("api_version must look like 2.14", details={"field": "field_mapping"})
    if session.execute(select(CRMConnection.id).where(CRMConnection.tenant_id == principal.tenant_id, CRMConnection.name == name)).first():
        raise Conflict("a CRM connection with this name already exists")
    connection = CRMConnection(tenant_id=principal.tenant_id, provider=provider, name=name, mode=mode, base_url=base_url.rstrip("/"),
                               credentials_enc=_box().encrypt(access_token) if access_token else None,
                               field_mapping={**DEFAULT_MAPPING[provider], **(field_mapping or {})}, created_by=principal.user_id,
                               auth_type=auth_type)  # fmt: skip
    session.add(connection)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="crm.connection_created", entity_type="crm_connection",
                 entity_id=connection.id, detail={"provider": provider, "mode": mode, "name": name})  # fmt: skip
    return connection


def connection_view(connection: CRMConnection) -> dict:
    return to_dict(connection, include={"has_credentials": bool(connection.credentials_enc)})


def build_request(connection: CRMConnection, kind: str, payload: dict) -> dict:
    """Vendor-specific HTTP request for one delivery (no secrets inside; auth is added at send time)."""
    # defaults first: a connection saved by an earlier release has no entry for a mapping key added since
    m, base, ext = {**DEFAULT_MAPPING[connection.provider], **(connection.field_mapping or {})}, connection.base_url, payload["external_id"]
    reasons = "; ".join(payload.get("top_reasons") or [])[:255]

    def seg(value: Any) -> str:
        """One URL path segment.  Customer ids come from imported data and mapping values from
        configuration: neither may add path segments, a query string or a fragment to the request."""
        text = str(value)
        if not text.strip() or set(text) <= {"."}:  # "", "." and ".." would address the parent resource
            raise ValidationFailed(f"'{text}' cannot be used as an identifier in a CRM request path", details={"field": "external_id"})
        return quote(text, safe="")

    if connection.provider == "salesforce":
        root = f"{base}/services/data/{seg(m['api_version'])}/sobjects"
        if kind == "risk_score":
            # updateOnly (API version 61.0 and later): without it this resource is an upsert, and a customer the CRM
            # does not know would be created there as a new record.  A score is only ever written to an existing one.
            return {"method": "PATCH", "url": f"{root}/{seg(m['object'])}/{seg(m['external_id_field'])}/{seg(ext)}", "params": {"updateOnly": "true"},
                    "json": {m["probability"]: payload["probability"], m["risk_tier"]: payload["risk_tier"], m["reasons"]: reasons,
                             m["scored_on"]: payload["as_of_date"]}}  # fmt: skip
        return {"method": "POST", "url": f"{root}/Task",
                "json": {"Subject": payload["subject"], "Description": payload["body"], "Priority": "High" if payload.get("priority") == 1 else "Normal",
                         "Status": "Not Started", "What": {"attributes": {"type": m["object"]}, m["external_id_field"]: ext}}}  # fmt: skip
    if connection.provider == "hubspot":
        # HubSpot's API description types every property value as a string, numbers and dates included.
        if kind == "risk_score":
            probability = f"{payload['probability']:.6f}".rstrip("0").rstrip(".")
            return {"method": "PATCH", "url": f"{base}/crm/v3/objects/{seg(m['object'])}/{seg(ext)}", "params": {"idProperty": m["id_property"]},
                    "json": {"properties": {m["probability"]: probability, m["risk_tier"]: payload["risk_tier"],
                                            m["reasons"]: reasons, m["scored_on"]: payload["as_of_date"]}}}  # fmt: skip
        # "associations" is a required member of a create request.  It stays empty: linking the task to the company
        # needs HubSpot's own record id, which the platform does not hold; the customer id travels as a task property.
        due = datetime.fromtimestamp(payload["created_epoch"], UTC).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        return {"method": "POST", "url": f"{base}/crm/v3/objects/tasks",
                "json": {"properties": {"hs_task_subject": payload["subject"], "hs_task_body": payload["body"], "hs_task_status": "NOT_STARTED",
                                        "hs_task_priority": "HIGH" if payload.get("priority") == 1 else "MEDIUM",
                                        "hs_timestamp": due, "churn_platform_customer_id": str(ext)},
                         "associations": []}}  # fmt: skip
    # Intercom.  Both kinds write attributes of the company ("create or update a company", matched on company_id).
    # A recommended action is NOT sent as an event: Intercom records events against a contact (id, user_id or email is
    # required) and the platform knows companies, not their contacts.  Attributes ending in "_at" hold Unix time.
    if kind == "risk_score":
        attributes = {m["probability"]: payload["probability"], m["risk_tier"]: payload["risk_tier"], m["reasons"]: reasons,
                      m["scored_on"]: payload["as_of_date"]}  # fmt: skip
    else:
        attributes = {m["action"]: payload.get("action_code", kind), m["action_subject"]: payload["subject"][:255],
                      m["action_at"]: payload["created_epoch"], **({m["action_segment"]: payload["segment"]} if payload.get("segment") else {})}  # fmt: skip
    return {"method": "POST", "url": f"{base}/companies", "headers": {"Intercom-Version": m["api_version"]},
            "json": {"company_id": str(ext), "custom_attributes": attributes}}


def recommendation_payload(session: Session, rec: RetentionRecommendation) -> dict:
    customer = session.get(Customer, rec.customer_id)
    rationale = rec.rationale or {}
    reasons = [r["text"] for r in rationale.get("top_reasons", [])]
    now = utcnow()
    lines = [f"Churn probability: {rationale.get('probability', 0):.1%} (tier: {rationale.get('risk_tier')})",
             "Top model factors: " + ("; ".join(reasons) or "n/a"), *[f"Talking point: {t}" for t in rationale.get("talking_points", [])],
             *[f"Payment trigger: {t}" for t in rationale.get("payment_triggers", [])],
             "Model factors describe the prediction; they are not established causes."]  # fmt: skip
    return {"external_id": customer.external_id, "subject": f"[Churn risk] {rationale.get('action_name', rec.action_code)} - {customer.name or customer.external_id}",
            "body": "\n".join(lines), "priority": rec.priority, "segment": rec.segment, "action_code": rec.action_code,
            "top_reasons": reasons, "created_at": now.isoformat(), "created_epoch": int(now.timestamp())}  # fmt: skip


def enqueue_delivery(session: Session, principal: Principal | None, connection: CRMConnection, *, customer_id: int | None, kind: str,
                     payload: dict, key: str) -> CRMDelivery:
    idem = f"{connection.id}:{kind}:{key}"
    existing = session.execute(select(CRMDelivery).where(CRMDelivery.tenant_id == connection.tenant_id,
                                                         CRMDelivery.idempotency_key == idem)).scalar_one_or_none()  # fmt: skip
    if existing is not None:
        return existing
    delivery = CRMDelivery(tenant_id=connection.tenant_id, connection_id=connection.id, customer_id=customer_id, kind=kind,
                           payload=json_safe(payload), idempotency_key=idem, status="pending", next_attempt_at=utcnow(),
                           created_by=principal.user_id if principal else None)  # fmt: skip
    session.add(delivery)
    session.flush()
    jobs.enqueue(session, tenant_id=connection.tenant_id, job_type="crm.deliver", payload={"delivery_id": delivery.id},
                 created_by=delivery.created_by, idempotency_key=f"crm.deliver:{delivery.id}:0")  # fmt: skip
    return delivery


def sync_risk_scores(session: Session, principal: Principal, connection_id: int, batch_id: int, tiers: tuple[str, ...] = ("high", "medium")) -> dict:
    """Queue one risk-score update per customer of a batch (reverse ETL of the batch output)."""
    connection = get_owned(session, CRMConnection, principal.tenant_id, connection_id, label="CRM connection")
    batch = get_owned(session, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
    if batch.status != "completed":
        raise Conflict("only a completed batch can be synchronised")
    rows = session.execute(select(Prediction, Customer.external_id).join(Customer, Customer.id == Prediction.customer_id)
                           .where(Prediction.batch_id == batch.id, Prediction.risk_tier.in_(tiers))).all()  # fmt: skip
    queued = 0
    for prediction, external_id in rows:
        payload = {"external_id": external_id, "probability": round(prediction.probability, 6), "risk_tier": prediction.risk_tier,
                   "top_reasons": [r["text"] for r in (prediction.top_reasons or [])], "as_of_date": prediction.as_of_date.isoformat()}  # fmt: skip
        before = session.execute(select(CRMDelivery.id).where(CRMDelivery.idempotency_key == f"{connection.id}:risk_score:pred:{prediction.id}")).first()
        enqueue_delivery(session, principal, connection, customer_id=prediction.customer_id, kind="risk_score", payload=payload,
                         key=f"pred:{prediction.id}")  # fmt: skip
        queued += before is None
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="crm.risk_sync_queued", entity_type="crm_connection",
                 entity_id=connection.id, detail={"batch_id": batch.id, "queued": queued, "already_queued": len(rows) - queued, "mode": connection.mode})  # fmt: skip
    return {"queued": queued, "already_queued": len(rows) - queued, "mode": connection.mode}


def deliver(delivery_id: int, ctx: Any = None) -> dict:
    from . import crm_oauth

    with read_session() as rs:
        pending = rs.get(CRMDelivery, delivery_id)
        connection_id = pending.connection_id if pending is not None else None
    if connection_id is not None:
        crm_oauth.ensure_fresh_token(connection_id)  # an OAuth token that is about to expire is replaced first
    with read_session() as rs:
        delivery = rs.get(CRMDelivery, delivery_id)
        if delivery is None:
            raise jobs.PermanentJobError(f"CRM delivery {delivery_id} does not exist")
        if delivery.status in ("sent", "skipped", "dead"):
            return {"delivery_id": delivery_id, "status": delivery.status, "note": "already final"}
        connection = rs.get(CRMConnection, delivery.connection_id)
        oauth, connection_status = connection.auth_type == "oauth", connection.status
        attempts, key, tenant_id = delivery.attempts + 1, delivery.idempotency_key, delivery.tenant_id
        try:
            request, unusable = build_request(connection, delivery.kind, delivery.payload), None
        except ValidationFailed as exc:
            request, unusable = None, exc.message
        mode, token = connection.mode, _box().decrypt(connection.credentials_enc) if connection.credentials_enc else None
    now = utcnow()
    if unusable:
        values = {"status": "dead", "attempts": attempts, "last_error": f"request not built: {unusable}"[:400], "next_attempt_at": None}
    elif mode == "TEST_ONLY":
        values = {"status": "skipped", "attempts": attempts, "sent_at": None, "last_error": None,
                  "response": {"mode": "TEST_ONLY", "sent": False, "request": request,
                               "note": "TEST_ONLY connection: the request was built but not transmitted."}}  # fmt: skip
    elif mode == "PRODUCTION" and not get_settings().crm_allow_production:
        values = {"status": "dead", "attempts": attempts, "last_error": "PRODUCTION deliveries are disabled by configuration"}
    elif token is None or (oauth and connection_status in ("reauthorisation_required", "disconnected")):
        # no usable credentials: nothing is sent; the delivery waits for the connection to be authorised again
        final = attempts >= MAX_ATTEMPTS
        values = {"status": "dead" if final else "failed", "attempts": attempts, "next_attempt_at": None if final else now + timedelta(minutes=15),
                  "last_error": "the CRM connection is not authorised (connect it again under CRM sync)"}  # fmt: skip
    else:
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json", "Idempotency-Key": key}
        retry_at = now + timedelta(seconds=min(3600, 30 * 2 ** attempts))  # fmt: skip
        try:
            # vetted at send time and pinned to the vetted address (no second DNS lookup by the HTTP client)
            target = netguard.vet(request["url"], allow_private=get_settings().crm_allow_private_hosts, field_name="base_url")
            with httpx.Client(timeout=get_settings().crm_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
                response = client.request(request["method"], target.url, json=request["json"], params=request.get("params"),
                                          headers={**headers, **request.get("headers", {}), **target.headers}, extensions=target.extensions)  # fmt: skip
            if response.status_code < 300:
                try:  # the request has been accepted: an unreadable response body must not cause a second delivery
                    body = response.json() if response.headers.get("content-type", "").startswith("application/json") and response.content else {}
                except ValueError:
                    body = {}
                values = {"status": "sent", "attempts": attempts, "sent_at": now, "last_error": None,
                          "external_id": str(body.get("id"))[:120] if isinstance(body, dict) and body.get("id") else None,
                          "response": {"status_code": response.status_code, "mode": mode}}  # fmt: skip
            else:
                if response.status_code == 401 and oauth:
                    crm_oauth.ensure_fresh_token(connection_id, force=True)  # the vendor says the token is dead: replace it, then try again
                retryable = response.status_code in (408, 425, 429) or response.status_code >= 500 or (response.status_code == 401 and oauth)
                final = not retryable or attempts >= MAX_ATTEMPTS
                values = {"status": "dead" if final else "failed", "attempts": attempts,
                          "last_error": f"HTTP {response.status_code}: {response.text[:300]}",
                          "next_attempt_at": None if final else retry_at}  # fmt: skip
        except ValidationFailed as exc:  # refused by the SSRF guard; only a failed DNS lookup is worth retrying
            final = exc.details.get("reason") != "unresolvable" or attempts >= MAX_ATTEMPTS
            values = {"status": "dead" if final else "failed", "attempts": attempts, "last_error": f"request refused: {exc.message}"[:400],
                      "next_attempt_at": None if final else retry_at}  # fmt: skip
        except httpx.InvalidURL as exc:
            values = {"status": "dead", "attempts": attempts, "last_error": f"InvalidURL: {exc}"[:400], "next_attempt_at": None}
        except httpx.HTTPError as exc:
            final = attempts >= MAX_ATTEMPTS
            values = {"status": "dead" if final else "failed", "attempts": attempts, "last_error": f"{type(exc).__name__}: {exc}"[:400],
                      "next_attempt_at": None if final else retry_at}  # fmt: skip
    with session_scope() as ws:
        ws.execute(update(CRMDelivery).where(CRMDelivery.id == delivery_id).values(**json_safe_values(values)))
        if values["status"] == "failed":
            jobs.enqueue(ws, tenant_id=tenant_id, job_type="crm.deliver", payload={"delivery_id": delivery_id},
                         run_after=values["next_attempt_at"], idempotency_key=f"crm.deliver:{delivery_id}:{attempts}")  # fmt: skip
        health = {"sent": "ok", "skipped": "test_only"}.get(values["status"], "error")
        keep = (CRMConnection.status.not_in(("reauthorisation_required", "disconnected")),) if health == "error" else ()
        ws.execute(update(CRMConnection).where(CRMConnection.id == connection.id, *keep).values(
            last_checked_at=now, last_error=values.get("last_error"), status=health))  # fmt: skip
    return {"delivery_id": delivery_id, "status": values["status"], "attempts": attempts}


def json_safe_values(values: dict) -> dict:
    return {k: (json_safe(v) if k == "response" else v) for k, v in values.items()}


def delivery_view(delivery: CRMDelivery) -> dict:
    return to_dict(delivery)
