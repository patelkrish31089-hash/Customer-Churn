"""Canonical entity schemas and value coercion used by ingestion, validation and reprocessing."""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Any

NULL_TOKENS = {"", "null", "none", "nan", "n/a", "nat"}
SUBSCRIPTION_EVENT_TYPES = (
    "started", "trial_converted", "plan_changed", "cancel_requested", "cancel_revoked", "payment_failed",
    "suspended", "recovered", "reactivated", "ended", "payment_method_updated",
)  # fmt: skip
USAGE_EVENT_TYPES = ("login", "session", "feature_use", "key_action")


@dataclass(frozen=True)
class FieldSpec:
    name: str
    type: str = "str"  # str | int | float | decimal | bool | datetime | date | json
    required: bool = False
    ref: str | None = None  # entity type whose external_id this value refers to
    column: str | None = None  # ORM attribute to write (defaults to ``name``)
    choices: tuple[str, ...] | None = None
    max_length: int | None = None
    event_time: bool = False  # must not lie in the future

    @property
    def attr(self) -> str:
        return self.column or self.name


def _f(name: str, type: str = "str", **kw: Any) -> FieldSpec:
    return FieldSpec(name=name, type=type, **kw)


_CUST = _f("customer_external_id", required=True, ref="customers", column="customer_id")

ENTITY_SCHEMAS: dict[str, tuple[FieldSpec, ...]] = {
    "customers": (
        _f("external_id", required=True, max_length=120), _f("name", max_length=300), _f("email", max_length=320),
        _f("industry", max_length=80), _f("company_size", max_length=40), _f("employee_count", "int"),
        _f("country", max_length=80), _f("region", max_length=80), _f("acquisition_channel", max_length=80),
        _f("acquisition_campaign", max_length=120), _f("acquired_at", "datetime"), _f("consent_marketing", "bool"),
        _f("consent_updated_at", "datetime"), _f("attributes_effective_at", "datetime"), _f("phone", max_length=40),
    ),
    "accounts": (
        _f("external_id", required=True, max_length=120), _CUST, _f("status", max_length=30),
        _f("currency", max_length=3), _f("billing_email", max_length=320), _f("payment_method_type", max_length=40),
        _f("payment_method_expires_on", "date"), _f("csm_owner", max_length=200), _f("opened_at", "datetime"),
        _f("closed_at", "datetime"),
    ),
    "plans": (
        _f("external_id", required=True, max_length=120), _f("name", max_length=200), _f("product", max_length=120),
        _f("tier", max_length=40), _f("billing_period", choices=("monthly", "quarterly", "annual")),
        _f("list_price", "decimal"), _f("currency", max_length=3), _f("is_active", "bool"),
    ),
    "subscriptions": (
        _f("external_id", required=True, max_length=120), _CUST,
        _f("account_external_id", ref="accounts", column="account_id"),
        _f("plan_external_id", ref="plans", column="plan_id"), _f("status", max_length=30),
        _f("billing_period", choices=("monthly", "quarterly", "annual")), _f("started_at", "datetime", required=True),
        _f("trial_end_at", "datetime"), _f("current_period_end", "datetime"), _f("cancel_requested_at", "datetime"),
        _f("ended_at", "datetime"), _f("end_reason", max_length=40), _f("mrr", "decimal"), _f("discount_pct", "float"),
        _f("auto_renew", "bool"), _f("quantity", "int"),
    ),
    "subscription_events": (
        _f("external_id", required=True, max_length=120),
        _f("subscription_external_id", required=True, ref="subscriptions", column="subscription_id"),
        _f("event_type", required=True, choices=SUBSCRIPTION_EVENT_TYPES),
        _f("occurred_at", "datetime", required=True, event_time=True),
        _f("plan_external_id", ref="plans", column="plan_id"), _f("mrr", "decimal"), _f("reason", max_length=40),
        _f("detail", "json"),
    ),
    "invoices": (
        _f("external_id", required=True, max_length=120), _CUST,
        _f("subscription_external_id", ref="subscriptions", column="subscription_id"),
        _f("issued_at", "datetime", required=True, event_time=True), _f("due_at", "datetime"),
        _f("paid_at", "datetime"), _f("amount", "decimal", required=True), _f("discount_amount", "decimal"),
        _f("currency", max_length=3), _f("status", max_length=20),
    ),
    "payments": (
        _f("external_id", required=True, max_length=120), _CUST,
        _f("invoice_external_id", ref="invoices", column="invoice_id"),
        _f("attempted_at", "datetime", required=True, event_time=True), _f("amount", "decimal", required=True),
        _f("status", required=True, choices=("succeeded", "failed", "refunded")), _f("failure_reason", max_length=80),
        _f("method", max_length=40),
    ),
    "usage_events": (
        _f("external_id", max_length=120), _CUST, _f("occurred_at", "datetime", required=True, event_time=True),
        _f("event_type", required=True, choices=USAGE_EVENT_TYPES), _f("feature_name", max_length=80),
        _f("duration_seconds", "float"), _f("quantity", "int"), _f("user_ref", max_length=120),
    ),
    "support_interactions": (
        _f("external_id", required=True, max_length=120), _CUST, _f("kind", choices=("ticket", "chat", "nps_survey")),
        _f("opened_at", "datetime", required=True, event_time=True), _f("first_response_at", "datetime"),
        _f("resolved_at", "datetime"), _f("priority", max_length=20), _f("status", max_length=20),
        _f("escalated", "bool"), _f("category", max_length=80), _f("channel", max_length=40), _f("csat", "float"),
        _f("nps_score", "int"), _f("body"),
    ),
    "acquisitions": (
        _f("external_id", required=True, max_length=120), _CUST, _f("channel", max_length=80),
        _f("campaign", max_length=120), _f("acquired_at", "datetime"), _f("cac", "decimal"),
    ),
}  # fmt: skip

# Columns written with a default when the source omits them.
ENTITY_DEFAULTS: dict[str, dict[str, Any]] = {
    "usage_events": {"quantity": 1},
    "support_interactions": {"kind": "ticket", "escalated": False},
    "plans": {"is_active": True},
}

# Dependency order for loading a full data set (parents before children).
LOAD_ORDER = ("customers", "plans", "accounts", "subscriptions", "subscription_events", "invoices", "payments",
              "usage_events", "support_interactions", "acquisitions")  # fmt: skip

SYNONYMS: dict[str, tuple[str, ...]] = {
    "external_id": ("id", "external_id", "uid", "key"),
    "customer_external_id": ("customer_id", "customer", "cust_id", "customer_external_id", "account_owner_id", "company_id"),
    "account_external_id": ("account_id", "account", "billing_account_id"),
    "plan_external_id": ("plan_id", "plan", "plan_code", "product_plan"),
    "subscription_external_id": ("subscription_id", "subscription", "sub_id"),
    "invoice_external_id": ("invoice_id", "invoice"),
    "occurred_at": ("occurred_at", "timestamp", "event_time", "ts", "time", "event_timestamp", "created_at"),
    "attempted_at": ("attempted_at", "payment_date", "paid_on", "timestamp", "created_at"),
    "issued_at": ("issued_at", "invoice_date", "issue_date", "created_at"),
    "opened_at": ("opened_at", "created_at", "created", "submitted_at"),
    "started_at": ("started_at", "start_date", "start", "activated_at"),
    "ended_at": ("ended_at", "end_date", "churned_at", "cancelled_at", "canceled_at"),
    "mrr": ("mrr", "monthly_recurring_revenue", "monthly_revenue"),
    "employee_count": ("employee_count", "employees", "headcount"),
    "event_type": ("event_type", "event", "type", "action"),
    "duration_seconds": ("duration_seconds", "duration", "session_length", "session_seconds"),
    "nps_score": ("nps_score", "nps"),
    "body": ("body", "text", "message", "description", "content"),
    "name": ("name", "company", "company_name", "customer_name"),
}


class CoercionError(ValueError):
    pass


def is_missing(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    if isinstance(value, str) and value.strip().lower() in NULL_TOKENS:
        return True
    return type(value).__name__ in ("NaTType", "NAType")


_DT_FORMATS = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d", "%Y%m%d")


def to_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        dt = value
    elif isinstance(value, date):
        dt = datetime(value.year, value.month, value.day)
    elif hasattr(value, "to_pydatetime"):
        dt = value.to_pydatetime()
    elif isinstance(value, int | float) and not isinstance(value, bool):
        if not 0 < value < 1e14:
            raise CoercionError(f"'{value}' is not a plausible epoch timestamp")
        dt = datetime.fromtimestamp(value / 1000 if value > 1e11 else value, UTC)
    else:
        text = str(value).strip()
        dt = None
        try:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00") if text.endswith("Z") else text)
        except ValueError:
            for fmt in _DT_FORMATS:
                try:
                    dt = datetime.strptime(text, fmt)
                    break
                except ValueError:
                    continue
        if dt is None:
            raise CoercionError(f"'{text[:40]}' is not a recognised date/time")
    dt = dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)
    if not 1970 <= dt.year <= 2200:
        raise CoercionError(f"year {dt.year} is outside the supported range")
    return dt


def to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("true", "t", "yes", "y", "1", "1.0"):
        return True
    if text in ("false", "f", "no", "n", "0", "0.0"):
        return False
    raise CoercionError(f"'{str(value)[:40]}' is not a boolean")


_THOUSANDS = re.compile(r"^-?\d{1,3}(,\d{3})+(\.\d+)?$")


def to_decimal_value(value: Any) -> Decimal:
    if isinstance(value, bool):
        raise CoercionError("boolean is not a number")
    try:
        if isinstance(value, Decimal):
            number = value
        elif isinstance(value, float):
            number = Decimal(repr(value))
        else:
            text = str(value).strip()
            number = Decimal(text.replace(",", "") if _THOUSANDS.match(text) else text)
    except InvalidOperation as exc:
        raise CoercionError(f"'{str(value)[:40]}' is not a number") from exc
    if not number.is_finite():
        raise CoercionError("number must be finite")
    return number


def to_float(value: Any) -> float:
    return float(to_decimal_value(value))


def to_int(value: Any) -> int:
    number = to_decimal_value(value)
    if number != number.to_integral_value():
        raise CoercionError(f"'{str(value)[:40]}' is not a whole number")
    return int(number)


def to_str(value: Any) -> str:
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def coerce(spec: FieldSpec, value: Any) -> Any:
    """Convert one raw value to the canonical Python type or raise ``CoercionError``."""
    kind = spec.type
    if kind == "str":
        out = to_str(value)
        if spec.max_length and len(out) > spec.max_length:
            raise CoercionError(f"longer than {spec.max_length} characters")
        if spec.choices:
            out = out.lower()
            if out not in spec.choices:
                raise CoercionError(f"'{out[:40]}' is not one of {', '.join(spec.choices)}")
        return out
    if kind == "datetime":
        return to_datetime(value)
    if kind == "date":
        return value if isinstance(value, date) and not isinstance(value, datetime) else to_datetime(value).date()
    if kind == "bool":
        return to_bool(value)
    if kind == "int":
        return to_int(value)
    if kind == "float":
        return to_float(value)
    if kind == "decimal":
        return to_decimal_value(value).quantize(Decimal("0.0001"))
    if kind == "json":
        if isinstance(value, dict | list):
            return value
        try:
            return json.loads(value) if isinstance(value, str) else value
        except ValueError as exc:
            raise CoercionError("not valid JSON") from exc
    raise CoercionError(f"unsupported type {kind}")


def row_rule_violations(entity_type: str, row: dict, now: datetime) -> list[str]:
    """Hard validity rules (mirroring database constraints) checked before a row is loaded."""
    v: list[str] = []
    horizon = now + timedelta(days=1)
    for spec in ENTITY_SCHEMAS[entity_type]:
        value = row.get(spec.name)
        if spec.event_time and value is not None and value > horizon:
            v.append(f"{spec.name} is in the future")

    def before(a: str, b: str) -> None:
        if row.get(a) is not None and row.get(b) is not None and row[b] < row[a]:
            v.append(f"{b} is earlier than {a}")

    def non_negative(name: str) -> None:
        if row.get(name) is not None and row[name] < 0:
            v.append(f"{name} must not be negative")

    if entity_type == "customers":
        non_negative("employee_count")  # e-mail format is a soft data-quality rule, not a load blocker
    elif entity_type == "plans":
        non_negative("list_price")
    elif entity_type == "subscriptions":
        before("started_at", "ended_at")
        non_negative("mrr")
        if row.get("discount_pct") is not None and not 0 <= row["discount_pct"] <= 100:
            v.append("discount_pct must be between 0 and 100")
        if row.get("ended_at") is None and row.get("end_reason"):
            v.append("end_reason given without ended_at")
    elif entity_type == "subscription_events":
        non_negative("mrr")
    elif entity_type == "invoices":
        non_negative("amount")
        non_negative("discount_amount")
    elif entity_type == "payments":
        non_negative("amount")
    elif entity_type == "usage_events":
        non_negative("duration_seconds")
        if row.get("quantity") is not None and row["quantity"] < 1:
            v.append("quantity must be at least 1")
    elif entity_type == "support_interactions":
        before("opened_at", "resolved_at")
        before("opened_at", "first_response_at")
        if row.get("nps_score") is not None and not 0 <= row["nps_score"] <= 10:
            v.append("nps_score must be between 0 and 10")
        if row.get("csat") is not None and not 0 <= row["csat"] <= 5:
            v.append("csat must be between 0 and 5")
    elif entity_type == "acquisitions":
        non_negative("cac")
    return v
