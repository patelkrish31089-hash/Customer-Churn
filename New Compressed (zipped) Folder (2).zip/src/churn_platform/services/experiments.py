"""Retention experiments (randomised control) and uplift modelling.

A churn score says who is likely to leave, not who can be *persuaded* to stay.  Only a randomised
experiment measures the effect of an action; the uplift model then estimates, per customer,
P(retained | treated) - P(retained | control) and assigns the four classic segments:

    persuadable   - retention improves when treated            (target these)
    sure_thing    - stays either way                            (do not spend budget)
    lost_cause    - leaves either way                           (do not spend budget)
    sleeping_dog  - retention gets WORSE when treated           (do not disturb)

Analysis is intention-to-treat (as assigned).  An uplift model is only eligible for targeting after
it beats random targeting out-of-fold (bootstrap lower bound of the Qini coefficient > 0) AND is
approved by a second person.
"""

from __future__ import annotations

import hashlib
import math
import secrets
from datetime import date
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, insert, select
from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import utcnow
from ..errors import Conflict, Forbidden, ValidationFailed
from ..models import (
    ChurnLabel,
    Experiment,
    ExperimentAssignment,
    FeatureContract,
    Prediction,
    PredictionBatch,
    UpliftModel,
    UpliftScore,
)
from ..security import Principal
from . import audit, features, mlprep, policies, training
from .common import get_owned, json_safe, to_dict

SRM_ALPHA = 0.001
MIN_PER_ARM = 30
MIN_UPLIFT_PER_ARM, MIN_CLASS_PER_ARM = 100, 10
SEGMENTS = ("persuadable", "sure_thing", "lost_cause", "sleeping_dog")
ORIGINS = ("platform", "imported", "aa_backtest")
# A/A re-split check: up to 400 fresh splits, fewer for very large populations (one hash per customer and split)
RESPLITS, RESPLITS_MIN, RESPLIT_HASH_BUDGET, RESPLIT_TOLERANCE = 400, 20, 1_000_000, 1.5


# ----------------------------------------------------------------------------- pure statistics
def sample_size(baseline_rate: float, mde: float, alpha: float = 0.05, power: float = 0.8, treatment_share: float = 0.5) -> dict:
    """Customers needed to detect an absolute change ``mde`` in the churn rate (two-sided z-test)."""
    from scipy.stats import norm

    p1, p2 = baseline_rate, baseline_rate - mde
    if not (0 < p1 < 1 and 0 < p2 < 1 and mde != 0):
        raise ValidationFailed("baseline_rate and baseline_rate - min_detectable_effect must both be strictly between 0 and 1",
                               details={"field": "min_detectable_effect"})  # fmt: skip
    k = treatment_share / (1 - treatment_share)  # treated per control
    pooled = (p1 + k * p2) / (1 + k)
    z_a, z_b = norm.ppf(1 - alpha / 2), norm.ppf(power)
    n_control = (z_a * math.sqrt(pooled * (1 - pooled) * (1 + 1 / k)) + z_b * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2) / k)) ** 2 / (p1 - p2) ** 2
    n_control = math.ceil(n_control)
    return {"control": n_control, "treatment": math.ceil(n_control * k), "total": n_control + math.ceil(n_control * k)}


def arm_for(salt: str, customer_id: int, treatment_share: float) -> str:
    """Deterministic assignment: the same customer always lands in the same arm of an experiment."""
    digest = hashlib.sha256(f"{salt}:{customer_id}".encode()).digest()
    return "treatment" if int.from_bytes(digest[:8], "big") / 2**64 < treatment_share else "control"


def srm_check(n_treatment: int, n_control: int, treatment_share: float) -> dict:
    """Sample-ratio mismatch: is the observed split consistent with the designed split?"""
    from scipy.stats import chisquare

    total = n_treatment + n_control
    if total == 0:
        return {"status": "insufficient_data", "p_value": None}
    stat, p = chisquare([n_treatment, n_control], [total * treatment_share, total * (1 - treatment_share)])
    return {"status": "mismatch" if p < SRM_ALPHA else "ok", "p_value": float(p), "statistic": float(stat), "alpha": SRM_ALPHA,
            "observed_share": n_treatment / total, "designed_share": treatment_share}  # fmt: skip


def _wilson(x: int, n: int, z: float) -> tuple[float, float]:
    p, denom = x / n, 1 + z * z / n
    centre, half = (p + z * z / (2 * n)) / denom, z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return centre - half, centre + half


def compare_arms(churn_t: int, n_t: int, churn_c: int, n_c: int, alpha: float = 0.05) -> dict:
    """Difference in churn rate (treatment - control): Newcombe interval and two-sided z-test."""
    from scipy.stats import norm

    if n_t < MIN_PER_ARM or n_c < MIN_PER_ARM:
        return {"status": "insufficient_data", "reason": f"at least {MIN_PER_ARM} matured outcomes are needed in each arm",
                "n_treatment": n_t, "n_control": n_c}  # fmt: skip
    p_t, p_c, z = churn_t / n_t, churn_c / n_c, norm.ppf(1 - alpha / 2)
    lt, ut = _wilson(churn_t, n_t, z)
    lc, uc = _wilson(churn_c, n_c, z)
    diff = p_t - p_c
    low = diff - math.sqrt((p_t - lt) ** 2 + (uc - p_c) ** 2)
    high = diff + math.sqrt((ut - p_t) ** 2 + (p_c - lc) ** 2)
    pooled = (churn_t + churn_c) / (n_t + n_c)
    se = math.sqrt(pooled * (1 - pooled) * (1 / n_t + 1 / n_c))
    p_value = 1.0 if se == 0 else float(2 * (1 - norm.cdf(abs(diff) / se)))
    significant = p_value < alpha
    return {"status": "ok", "n_treatment": n_t, "n_control": n_c, "churned_treatment": churn_t, "churned_control": churn_c,
            "churn_rate_treatment": p_t, "churn_rate_control": p_c, "difference": diff, "ci_low": low, "ci_high": high,
            "confidence": 1 - alpha, "p_value": p_value, "significant": significant, "method": "Newcombe interval; pooled two-proportion z-test",
            "relative_change": None if p_c == 0 else diff / p_c,
            "reading": ("treatment churn is lower" if diff < 0 else "treatment churn is higher") if significant
                       else "no statistically significant difference"}  # fmt: skip


def resplit_check(outcomes: dict[int, bool], salt: str, treatment_share: float, alpha: float, splits: int | None = None) -> dict:
    """Repeat an A/A comparison on fresh random splits of the same customers.

    One A/A split is a single draw: with nothing delivered it still crosses the significance threshold for about
    ``alpha`` of all splits.  Splitting the same matured outcomes again and again with the real assignment rule
    measures that rate.  Near ``alpha``: assignment and comparison behave, and a significant single split was
    chance.  Well above ``alpha``: they are biased.  ``outcomes`` maps customer id -> churned.
    """
    from scipy.stats import binom

    ids = sorted(outcomes)
    if splits is None:  # bounded work: one hash per customer and split
        splits = int(min(RESPLITS, max(RESPLITS_MIN, RESPLIT_HASH_BUDGET // max(len(ids), 1))))
    churned = np.array([bool(outcomes[c]) for c in ids])
    evaluated = significant = 0
    for k in range(splits):
        treated = np.fromiter((arm_for(f"{salt}:resplit:{k}", c, treatment_share) == "treatment" for c in ids), dtype=bool, count=len(ids))
        result = compare_arms(int(churned[treated].sum()), int(treated.sum()), int(churned[~treated].sum()), int((~treated).sum()), alpha)
        if result["status"] == "ok":
            evaluated += 1
            significant += bool(result["significant"])
    if not evaluated:
        return {"status": "insufficient_data", "splits": splits, "evaluated": 0, "alpha": alpha}
    # The z-test is approximate when churn is rare, so "well above alpha" means: more significant splits than a
    # test of true size 1.5 x alpha would give in 999 of 1000 runs of this check.
    limit = int(binom.ppf(0.999, evaluated, min(1.0, RESPLIT_TOLERANCE * alpha)))
    return {"status": "ok" if significant <= limit else "excess", "splits": splits, "evaluated": evaluated, "significant": significant,
            "rate": significant / evaluated, "alpha": alpha, "limit": limit,
            "method": "the same customers split again with fresh salts by the assignment rule; pooled two-proportion z-test"}  # fmt: skip


def _aa_notes(comparison: dict, resplit: dict | None, alpha: float) -> list[str]:
    """What an A/A result means, in words that hold whichever way the single split fell."""
    one_in = round(1 / alpha) if alpha else 0
    if comparison.get("status") != "ok":
        return ["A/A back-test: NO treatment was delivered, so there is no effect to find."]
    if comparison["significant"]:
        first = (f"A/A back-test: NO treatment was delivered, so this difference is not an effect. With nothing delivered, about 1 split "
                 f"in {one_in} still crosses the {alpha:.0%} threshold by chance.")  # fmt: skip
    else:
        first = "A/A back-test: NO treatment was delivered and the arms do not differ significantly, which is the expected result."
    if not resplit or resplit.get("status") == "insufficient_data":
        return [first]
    measured = (f"Splitting the same customers again {resplit['evaluated']} times with fresh random splits called "
                f"{resplit['significant']} of them ({resplit['rate']:.1%}) significant")  # fmt: skip
    if resplit["status"] == "ok":
        tail = ", in line with chance: assignment and comparison behave" + (", and this split is one of the unlucky ones." if comparison["significant"] else ".")
    else:
        tail = (f", well above the {alpha:.0%} that chance produces: assignment or outcome measurement is biased and must be "
                f"investigated before a real experiment is run.")  # fmt: skip
    return [first, measured + tail]


def classify_segments(p_treated: np.ndarray, p_control: np.ndarray, delta: float) -> np.ndarray:
    p_treated, p_control = np.asarray(p_treated, dtype=float), np.asarray(p_control, dtype=float)
    uplift = p_treated - p_control
    return np.where(uplift >= delta, "persuadable",
                    np.where(uplift <= -delta, "sleeping_dog", np.where(p_control >= 0.5, "sure_thing", "lost_cause")))  # fmt: skip


def qini(uplift: np.ndarray, treated: np.ndarray, retained: np.ndarray) -> dict:
    """Qini curve of incremental retained customers when targeting by predicted uplift, descending.

    The coefficient is the mean gap between the curve and random targeting, per customer; above 0
    means the ranking finds incremental retention faster than chance."""
    uplift, treated, retained = np.asarray(uplift, dtype=float), np.asarray(treated), np.asarray(retained)
    order = np.argsort(-uplift, kind="stable")
    t, y = treated[order].astype(float), retained[order].astype(float)
    n_t, n_c = np.cumsum(t), np.cumsum(1 - t)
    y_t, y_c = np.cumsum(y * t), np.cumsum(y * (1 - t))
    curve = y_t - np.divide(y_c * n_t, n_c, out=np.zeros_like(y_c), where=n_c > 0)
    n = len(curve)
    random_line = curve[-1] * np.arange(1, n + 1) / n
    step = max(1, n // 100)
    return {"coefficient": float((curve - random_line).mean() / n), "incremental_at_full_targeting": float(curve[-1]),
            "curve": [{"share": float((i + 1) / n), "incremental": float(curve[i]), "random": float(random_line[i])}
                      for i in list(range(step - 1, n, step)) + ([n - 1] if (n - 1) % step != step - 1 else [])]}  # fmt: skip


def _fit_arm(frame: pd.DataFrame, y: np.ndarray, names: list[str], seed: int) -> tuple[dict, Any]:
    prep = mlprep.fit_preprocessor(frame, names)
    # same standardised, regularised logistic regression as the churn model's linear baseline
    model = training.build_estimator("logistic_regression", training.DEFAULTS["logistic_regression"], "none", y, seed)
    return prep, model.fit(mlprep.transform(prep, frame), y)


def _predict_arm(fitted: tuple[dict, Any], frame: pd.DataFrame) -> np.ndarray:
    prep, model = fitted
    return model.predict_proba(mlprep.transform(prep, frame))[:, 1]


def t_learner_oof(frame: pd.DataFrame, treated: np.ndarray, retained: np.ndarray, names: list[str], folds: int = 5, seed: int = 0) -> np.ndarray:
    """Cross-fitted T-learner: every customer's uplift is predicted by models that never saw them."""
    from sklearn.model_selection import StratifiedKFold

    treated, retained = np.asarray(treated).astype(int), np.asarray(retained).astype(int)
    frame = frame.reset_index(drop=True)
    strata = treated * 2 + retained
    out = np.zeros((len(frame), 2))
    for train_idx, test_idx in StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed).split(frame, strata):
        tr, te = frame.iloc[train_idx], frame.iloc[test_idx]
        for column, arm in ((0, 1), (1, 0)):
            mask = treated[train_idx] == arm
            out[test_idx, column] = _predict_arm(_fit_arm(tr[mask], retained[train_idx][mask], names, seed), te)
    return out


def validate_uplift(oof: np.ndarray, treated: np.ndarray, retained: np.ndarray, seed: int = 0, bootstrap: int = 200) -> dict:
    treated, retained = np.asarray(treated).astype(int), np.asarray(retained).astype(int)
    uplift = oof[:, 0] - oof[:, 1]
    point = qini(uplift, treated, retained)
    rng, n, draws = np.random.default_rng(seed), len(uplift), []
    for _ in range(bootstrap):
        idx = rng.integers(0, n, n)
        if 0 < treated[idx].sum() < n:
            draws.append(qini(uplift[idx], treated[idx], retained[idx])["coefficient"])
    low, high = (float(np.quantile(draws, 0.05)), float(np.quantile(draws, 0.95))) if draws else (None, None)
    deciles = []
    for rank, chunk in enumerate(np.array_split(np.argsort(-uplift, kind="stable"), 5), start=1):
        t = treated[chunk] == 1
        if t.sum() and (~t).sum():
            deciles.append({"bucket": rank, "n": int(len(chunk)), "predicted_uplift": float(uplift[chunk].mean()),
                            "observed_uplift": float(retained[chunk][t].mean() - retained[chunk][~t].mean())})  # fmt: skip
    passed = low is not None and low > 0
    return {"qini_coefficient": point["coefficient"], "qini_ci90": [low, high], "qini_curve": point["curve"], "buckets": deciles,
            "passed": passed, "rule": "the bootstrap 5th percentile of the out-of-fold Qini coefficient must be above 0",
            "method": "T-learner (two logistic regressions), 5-fold cross-fitting"}  # fmt: skip


# ----------------------------------------------------------------------------- experiment lifecycle
def create(session: Session, principal: Principal, *, name: str, hypothesis: str | None = None, treatment_share: float = 0.5,
           baseline_rate: float | None = None, min_detectable_effect: float | None = None, alpha: float = 0.05, power: float = 0.8,
           outcome_window_days: int | None = None, origin: str = "platform", assignment_salt: str | None = None) -> Experiment:
    """``assignment_salt`` is for reproducible fixtures only (the demo seed); real experiments get a random secret salt,
    so that nobody can predict or steer which arm a customer lands in.  The HTTP API cannot set it."""
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if origin not in ORIGINS:
        raise ValidationFailed(f"origin must be one of {', '.join(ORIGINS)}", details={"field": "origin"})
    if not 0.05 <= treatment_share <= 0.95:
        raise ValidationFailed("treatment_share must be between 0.05 and 0.95", details={"field": "treatment_share"})
    if not (0 < alpha < 0.5 and 0.5 <= power < 1):
        raise ValidationFailed("alpha must be in (0, 0.5) and power in [0.5, 1)", details={"field": "alpha"})
    if session.execute(select(Experiment.id).where(Experiment.tenant_id == principal.tenant_id, Experiment.name == name)).first():
        raise Conflict("an experiment with this name already exists")
    design = None
    if baseline_rate is not None and min_detectable_effect is not None:
        design = sample_size(baseline_rate, min_detectable_effect, alpha, power, treatment_share)
    experiment = Experiment(
        tenant_id=principal.tenant_id, name=name, hypothesis=hypothesis, origin=origin, treatment_share=treatment_share, alpha=alpha,
        power=power, baseline_rate=baseline_rate, min_detectable_effect=min_detectable_effect,
        required_per_arm=max(design["control"], design["treatment"]) if design else None,
        outcome_window_days=outcome_window_days or get_settings().default_horizon_days,
        assignment_salt=assignment_salt or secrets.token_hex(16),
        results={"design": design}, created_by=principal.user_id)  # fmt: skip
    session.add(experiment)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="experiment.created", entity_type="experiment",
                 entity_id=experiment.id, detail={"name": name, "origin": origin, "design": design})  # fmt: skip
    return experiment


def submit(session: Session, principal: Principal, experiment_id: int) -> Experiment:
    experiment = get_owned(session, Experiment, principal.tenant_id, experiment_id, label="Experiment")
    if experiment.status != "draft":
        raise Conflict(f"only a draft can be submitted (status: {experiment.status})")
    experiment.status = "pending"
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="experiment.submitted", entity_type="experiment",
                 entity_id=experiment.id)  # fmt: skip
    return experiment


def review(session: Session, principal: Principal, experiment_id: int, *, approve: bool) -> Experiment:
    experiment = get_owned(session, Experiment, principal.tenant_id, experiment_id, label="Experiment")
    if experiment.status != "pending":
        raise Conflict(f"only a pending experiment can be reviewed (status: {experiment.status})")
    if experiment.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: an experiment cannot be approved or rejected by its author", code="self_approval_forbidden")
    experiment.status = "approved" if approve else "rejected"
    experiment.reviewed_by, experiment.reviewed_at = principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, entity_type="experiment", entity_id=experiment.id,
                 action="experiment.approved" if approve else "experiment.rejected")  # fmt: skip
    return experiment


def assign(session: Session, principal: Principal, experiment_id: int, batch_id: int, tiers: tuple[str, ...] = ("high", "medium")) -> dict:
    """Randomise the customers of a scored batch (selected risk tiers) into treatment and control."""
    from .predictions import TIERS

    experiment = get_owned(session, Experiment, principal.tenant_id, experiment_id, label="Experiment")
    if experiment.status in ("running", "completed"):
        raise Conflict(f"customers were already assigned to this experiment (status: {experiment.status}); assignment happens once",
                       code="already_assigned")  # fmt: skip
    if experiment.status != "approved":
        raise Conflict(f"an experiment must be approved before assignment (status: {experiment.status})", code="not_approved")
    tiers = tuple(dict.fromkeys(tiers))
    if not tiers or not set(tiers) <= set(TIERS):
        raise ValidationFailed(f"tiers must be chosen from {', '.join(TIERS)}", details={"field": "tiers"})
    batch = get_owned(session, PredictionBatch, principal.tenant_id, batch_id, label="Prediction batch")
    if batch.status != "completed":
        raise Conflict("assignment needs a completed prediction batch")
    eligible = session.execute(select(Prediction.customer_id).where(Prediction.batch_id == batch.id, Prediction.risk_tier.in_(tiers))
                               .order_by(Prediction.customer_id)).scalars().all()  # fmt: skip
    # A customer in two experiments at once would get two treatments, and neither result could be read.
    busy = set(session.execute(select(ExperimentAssignment.customer_id).join(Experiment, Experiment.id == ExperimentAssignment.experiment_id).where(
        Experiment.tenant_id == experiment.tenant_id, Experiment.status == "running", Experiment.id != experiment.id)).scalars())  # fmt: skip
    customer_ids = [cid for cid in eligible if cid not in busy]
    if not customer_ids:
        raise Conflict("the batch has no customers in the selected risk tiers" if not eligible
                       else "every customer in the selected risk tiers is already enrolled in another running experiment")  # fmt: skip
    now = utcnow()
    rows = [{"tenant_id": experiment.tenant_id, "experiment_id": experiment.id, "customer_id": cid,
             "arm": arm_for(experiment.assignment_salt, cid, experiment.treatment_share), "assigned_at": now} for cid in customer_ids]  # fmt: skip
    session.execute(insert(ExperimentAssignment.__table__), rows)
    n_t = sum(r["arm"] == "treatment" for r in rows)
    srm = srm_check(n_t, len(rows) - n_t, experiment.treatment_share)
    experiment.status, experiment.assigned_at = "running", now
    experiment.results = json_safe({**(experiment.results or {}), "assignment": {
        "batch_id": batch.id, "as_of_date": batch.as_of_date.isoformat(), "tiers": list(tiers), "treatment": n_t,
        "control": len(rows) - n_t, "srm": srm, "method": "sha256(salt:customer_id) < treatment_share",
        "excluded_in_other_experiment": len(eligible) - len(customer_ids)}})  # fmt: skip
    audit.record(session, tenant_id=experiment.tenant_id, actor=principal, action="experiment.assigned", entity_type="experiment",
                 entity_id=experiment.id, detail={"batch_id": batch.id, "treatment": n_t, "control": len(rows) - n_t, "srm": srm["status"]})  # fmt: skip
    return view(experiment)


def analyse(session: Session, principal: Principal | None, experiment_id: int, tenant_id: int | None = None) -> dict:
    """Pull matured churn outcomes from the label store and compare the arms (intention-to-treat)."""
    experiment = get_owned(session, Experiment, principal.tenant_id if principal else tenant_id, experiment_id, label="Experiment")
    assignment = (experiment.results or {}).get("assignment")
    if experiment.status not in ("running", "completed") or not assignment:
        raise Conflict("the experiment has no assignment yet")
    as_of = date.fromisoformat(assignment["as_of_date"])
    policy = policies.get_active(session, experiment.tenant_id, "churn_definition")
    matured = dict(session.execute(select(ChurnLabel.customer_id, ChurnLabel.status).where(
        ChurnLabel.tenant_id == experiment.tenant_id, ChurnLabel.policy_id == policy.id, ChurnLabel.as_of_date == as_of,
        ChurnLabel.status.in_(("churned", "retained")))).all())  # fmt: skip
    rows = session.execute(select(ExperimentAssignment).where(ExperimentAssignment.experiment_id == experiment.id)).scalars().all()
    counts = {"treatment": [0, 0], "control": [0, 0]}  # [matured, churned]
    for row in rows:
        outcome = matured.get(row.customer_id)
        if outcome and row.outcome != outcome:
            row.outcome, row.outcome_at = outcome, utcnow()
        if row.outcome:
            counts[row.arm][0] += 1
            counts[row.arm][1] += row.outcome == "churned"
    total, done = len(rows), counts["treatment"][0] + counts["control"][0]
    comparison = compare_arms(counts["treatment"][1], counts["treatment"][0], counts["control"][1], counts["control"][0], experiment.alpha)
    notes = ["Intention-to-treat: customers are analysed in the arm they were assigned to."]
    resplit = None
    if experiment.origin == "aa_backtest":
        if comparison.get("status") == "ok":
            resplit = resplit_check({row.customer_id: row.outcome == "churned" for row in rows if row.outcome}, experiment.assignment_salt,
                                    experiment.treatment_share, experiment.alpha)  # fmt: skip
            # nothing was delivered: "treatment churn is lower" would read like an effect
            comparison["reading"] = ("the arms differ although no treatment was delivered" if comparison["significant"]
                                     else "no statistically significant difference, as expected without a treatment")  # fmt: skip
        notes += _aa_notes(comparison, resplit, experiment.alpha)
    if assignment["srm"]["status"] == "mismatch":
        notes.append("Sample-ratio mismatch detected: the result is not trustworthy until the cause is found.")
    required = experiment.required_per_arm
    if required and comparison.get("status") == "ok" and min(counts["treatment"][0], counts["control"][0]) < required:
        notes.append(f"Under-powered: the design called for {required} matured outcomes per arm.")
    analysis = {"as_of_date": as_of.isoformat(), "outcome_window_days": experiment.outcome_window_days, "assigned": total,
                "matured": done, "mature_share": done / total if total else 0.0, "comparison": comparison, "resplit": resplit, "notes": notes,
                "churn_definition": f"{policy.name} v{policy.version}", "analysed_at": utcnow().isoformat()}  # fmt: skip
    experiment.results = json_safe({**(experiment.results or {}), "analysis": analysis})
    if total and done == total:
        experiment.status = "completed"
    audit.record(session, tenant_id=experiment.tenant_id, actor=principal, action="experiment.analysed", entity_type="experiment",
                 entity_id=experiment.id, detail={"matured": done, "assigned": total, "status": comparison.get("status")})  # fmt: skip
    return view(experiment)


def view(experiment: Experiment) -> dict:
    return to_dict(experiment, exclude={"assignment_salt"})


# ----------------------------------------------------------------------------- uplift model
def _training_frame(session: Session, experiment: Experiment, contract: FeatureContract) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    as_of = date.fromisoformat(experiment.results["assignment"]["as_of_date"])
    rows = session.execute(select(ExperimentAssignment.customer_id, ExperimentAssignment.arm, ExperimentAssignment.outcome).where(
        ExperimentAssignment.experiment_id == experiment.id, ExperimentAssignment.outcome.is_not(None))).all()  # fmt: skip
    assigned = pd.DataFrame(rows, columns=["customer_id", "arm", "outcome"])
    frame = features.offline_frame(session, experiment.tenant_id, contract, dates=[as_of]) if len(assigned) else pd.DataFrame()
    if len(assigned) and frame.empty:
        # assigned from a batch scored on a date the store was never materialised for
        frame = features.computed_frame(experiment.tenant_id, contract, as_of, assigned["customer_id"].tolist())
    data = assigned.merge(frame, on="customer_id") if len(frame) else assigned.iloc[0:0]
    return data, (data["arm"] == "treatment").to_numpy().astype(int), (data["outcome"] == "retained").to_numpy().astype(int)


def fit_uplift(session: Session, principal: Principal, experiment_id: int, contract_id: int, delta: float = 0.02, seed: int = 0) -> UpliftModel:
    experiment = get_owned(session, Experiment, principal.tenant_id, experiment_id, label="Experiment")
    contract = features.require_usable(get_owned(session, FeatureContract, principal.tenant_id, contract_id, label="Feature contract"))
    if not (experiment.results or {}).get("analysis"):
        raise Conflict("analyse the experiment before fitting an uplift model")
    if not 0 < delta < 0.5:
        raise ValidationFailed("delta must be between 0 and 0.5", details={"field": "delta"})
    data, treated, retained = _training_frame(session, experiment, contract)
    names = list(contract.features)
    problems = []
    for arm, label in ((1, "treatment"), (0, "control")):
        y = retained[treated == arm]
        if len(y) < MIN_UPLIFT_PER_ARM:
            problems.append(f"{label} arm has {len(y)} matured outcomes with features (minimum {MIN_UPLIFT_PER_ARM})")
        elif min(y.sum(), len(y) - y.sum()) < MIN_CLASS_PER_ARM:
            problems.append(f"{label} arm has fewer than {MIN_CLASS_PER_ARM} customers in one outcome class")
    if problems:
        raise Conflict("not enough experiment data for an uplift model: " + "; ".join(problems), code="insufficient_data")
    oof = t_learner_oof(data, treated, retained, names, seed=seed)
    validation = validate_uplift(oof, treated, retained, seed=seed)
    segments = pd.Series(classify_segments(oof[:, 0], oof[:, 1], delta)).value_counts().to_dict()
    bundle = {"features": names, "delta": delta, "treated": _fit_arm(data[treated == 1], retained[treated == 1], names, seed),
              "control": _fit_arm(data[treated == 0], retained[treated == 0], names, seed)}  # fmt: skip
    model = UpliftModel(tenant_id=experiment.tenant_id, experiment_id=experiment.id, contract_id=contract.id, method="t_learner_logistic",
                        status="validated" if validation["passed"] else "validation_failed", delta=delta, created_by=principal.user_id,
                        metrics={"rows": int(len(data)), "treated": int(treated.sum()), "control": int((1 - treated).sum()),
                                 "out_of_fold_segments": {k: int(v) for k, v in segments.items()},
                                 "origin": experiment.origin}, validation=json_safe(validation))  # fmt: skip
    session.add(model)
    session.flush()
    path = get_settings().data_dir / "uplift" / str(experiment.tenant_id) / f"uplift-{model.id}.joblib"
    path.parent.mkdir(parents=True, exist_ok=True)
    import joblib

    joblib.dump(bundle, path)
    model.artifact_path, model.artifact_sha256 = storage.to_stored(path), training.sha256_path(path)
    audit.record(session, tenant_id=experiment.tenant_id, actor=principal, action="uplift.fitted", entity_type="uplift_model",
                 entity_id=model.id, detail={"experiment_id": experiment.id, "status": model.status,
                                             "qini": validation["qini_coefficient"], "qini_ci90": validation["qini_ci90"]})  # fmt: skip
    return model


def review_uplift(session: Session, principal: Principal, model_id: int, *, approve: bool) -> UpliftModel:
    model = get_owned(session, UpliftModel, principal.tenant_id, model_id, label="Uplift model")
    if model.status != "validated":
        raise Conflict(f"only an uplift model that passed validation can be reviewed (status: {model.status})", code="not_validated")
    if model.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: an uplift model cannot be approved or rejected by its author", code="self_approval_forbidden")
    model.status = "approved" if approve else "rejected"
    model.reviewed_by, model.reviewed_at = principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, entity_type="uplift_model", entity_id=model.id,
                 action="uplift.approved" if approve else "uplift.rejected")  # fmt: skip
    return model


def compute_scores(model: UpliftModel, frame: pd.DataFrame) -> pd.DataFrame:
    """Predicted retention with and without the action, and the resulting segment, for every row of ``frame``.

    Pure apart from reading the model artefact, whose checksum is verified first.
    """
    import joblib

    path = storage.resolve(model.artifact_path)
    if training.sha256_path(path) != model.artifact_sha256:
        raise Conflict("the uplift model artifact failed its integrity check", code="artifact_integrity")
    bundle = joblib.load(path)
    p_t, p_c = _predict_arm(bundle["treated"], frame), _predict_arm(bundle["control"], frame)
    return pd.DataFrame({"customer_id": frame["customer_id"].to_numpy(dtype="int64"), "p_retain_treated": p_t, "p_retain_control": p_c,
                         "uplift": p_t - p_c, "segment": classify_segments(p_t, p_c, model.delta)})  # fmt: skip


def store_scores(session: Session, model: UpliftModel, as_of: date, scores: pd.DataFrame, *, actor: Principal | None = None,
                 automatic: bool = False) -> dict:
    """Replace the model's scores for one date and record who (or what) produced them."""
    session.execute(delete(UpliftScore).where(UpliftScore.uplift_model_id == model.id, UpliftScore.as_of_date == as_of))
    now = utcnow()
    session.execute(insert(UpliftScore.__table__), [
        {"tenant_id": model.tenant_id, "uplift_model_id": model.id, "customer_id": int(r.customer_id), "as_of_date": as_of,
         "p_retain_treated": float(r.p_retain_treated), "p_retain_control": float(r.p_retain_control), "uplift": float(r.uplift),
         "segment": str(r.segment), "created_at": now}
        for r in scores.itertuples(index=False)])  # fmt: skip
    counts = {seg: int((scores["segment"] == seg).sum()) for seg in SEGMENTS}
    diagnostic = model.status != "approved"
    audit.record(session, tenant_id=model.tenant_id, actor=actor, action="uplift.scored", entity_type="uplift_model", entity_id=model.id,
                 detail={"as_of_date": as_of.isoformat(), "segments": counts, "diagnostic": diagnostic, "automatic": automatic})  # fmt: skip
    return {"uplift_model_id": model.id, "as_of_date": as_of.isoformat(), "customers": len(scores), "segments": counts,
            "diagnostic": diagnostic, "mean_uplift": float(scores["uplift"].mean())}  # fmt: skip


def score(session: Session, principal: Principal, model_id: int, as_of_date: Any = None) -> dict:
    """Score customers from the feature store.  Models that are not approved can still be scored,
    but the result is flagged DIAGNOSTIC and is never used by the recommendation engine."""
    from .common import parse_date
    from .predictions import default_as_of

    model = get_owned(session, UpliftModel, principal.tenant_id, model_id, label="Uplift model")
    contract = session.get(FeatureContract, model.contract_id)
    as_of = parse_date(as_of_date, field="as_of_date") or default_as_of(session, model.tenant_id)
    frame = features.offline_frame(session, model.tenant_id, contract, dates=[as_of])
    if frame.empty:
        raise Conflict(f"no materialised features exist for {as_of.isoformat()}", code="features_missing")
    return store_scores(session, model, as_of, compute_scores(model, frame), actor=principal)


def segment_summary(session: Session, tenant_id: int, model_id: int) -> dict:
    model = get_owned(session, UpliftModel, tenant_id, model_id, label="Uplift model")
    latest = session.execute(select(func.max(UpliftScore.as_of_date)).where(UpliftScore.uplift_model_id == model.id)).scalar()
    out = {"model": uplift_view(model), "as_of_date": latest.isoformat() if latest else None, "segments": {}, "points": [],
           "usable_for_targeting": model.status == "approved",
           "warning": None if model.status == "approved" else
           "DIAGNOSTIC ONLY: this uplift model is not approved" + (" and did not beat random targeting in validation"
                                                                    if model.status == "validation_failed" else "") +
           ". Segments must not drive targeting."}  # fmt: skip
    if latest is None:
        return out
    rows = session.execute(select(UpliftScore.p_retain_control, UpliftScore.p_retain_treated, UpliftScore.segment, UpliftScore.uplift)
                           .where(UpliftScore.uplift_model_id == model.id, UpliftScore.as_of_date == latest)).all()  # fmt: skip
    for segment in SEGMENTS:
        values = [r[3] for r in rows if r[2] == segment]
        out["segments"][segment] = {"customers": len(values), "mean_uplift": float(np.mean(values)) if values else None}
    step = max(1, len(rows) // 600)
    out["points"] = [{"p_control": float(r[0]), "p_treated": float(r[1]), "segment": r[2]} for r in rows[::step]]
    return out


def approved_model(session: Session, tenant_id: int) -> UpliftModel | None:
    """The uplift model in force: the one approved most recently."""
    return session.execute(select(UpliftModel).where(UpliftModel.tenant_id == tenant_id, UpliftModel.status == "approved")
                           .order_by(UpliftModel.reviewed_at.desc(), UpliftModel.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip


def stored_segments(session: Session, model_id: int, as_of: date) -> dict[int, str]:
    return dict(session.execute(select(UpliftScore.customer_id, UpliftScore.segment).where(
        UpliftScore.uplift_model_id == model_id, UpliftScore.as_of_date == as_of)).all())  # fmt: skip


def approved_segments(session: Session, tenant_id: int, as_of: date) -> dict[int, str]:
    """Customer -> uplift segment from the model in force, if it has been scored for this date."""
    model = approved_model(session, tenant_id)
    return stored_segments(session, model.id, as_of) if model is not None else {}


def uplift_view(model: UpliftModel) -> dict:
    return to_dict(model, exclude={"artifact_path"})

