"""Feature registry, approved feature contracts and the offline / online feature store."""

from __future__ import annotations

import hashlib
import json
from datetime import date
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, insert, select, update
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, Forbidden, NotFound, ValidationFailed
from ..models import Customer, FeatureContract, FeatureDefinition, FeatureRun, FeatureVector, OnlineFeature
from ..security import Principal
from . import audit, feature_engine, jobs, labels, policies, signals, timeline
from .common import get_owned, json_safe, next_version, to_dict

CUSTOMER_CHUNK = 2000
DEFAULT_CONTRACT = "churn_core"


# ----------------------------------------------------------------------------- registry
def sync_registry(session: Session) -> dict:
    """Mirror the code catalog into ``feature_definitions`` (new row whenever the logic hash changes)."""
    code_hash = feature_engine.engine_hash()
    existing = {(d.name, d.version, d.code_hash): d for d in session.execute(select(FeatureDefinition)).scalars()}
    added = 0
    for spec in feature_engine.CATALOG:
        if (spec.name, feature_engine.FEATURE_VERSION, code_hash) in existing:
            continue
        stale = [d for (name, _v, _h), d in existing.items() if name == spec.name]
        for d in stale:
            d.is_active = False
        version = max([d.version for d in stale], default=0) + 1 if stale else feature_engine.FEATURE_VERSION
        session.add(FeatureDefinition(
            name=spec.name, version=version, group=spec.group, dtype=spec.dtype, description=spec.description,
            sources=list(spec.sources), window_days=spec.window_days, code_hash=code_hash, is_active=True,
            pit_rule=("uses only records strictly before T 00:00 UTC" if spec.pit == "event_time"
                      else "snapshot attribute: value as loaded (change history applied where recorded)")))  # fmt: skip
        added += 1
    session.flush()
    return {"definitions_added": added, "engine_hash": code_hash}


def registry_is_current(session: Session) -> bool:
    """True when ``feature_definitions`` already mirrors the code catalog (so a reader does not need to write)."""
    current = session.execute(select(func.count()).select_from(FeatureDefinition).where(
        FeatureDefinition.is_active.is_(True), FeatureDefinition.code_hash == feature_engine.engine_hash())).scalar_one()  # fmt: skip
    return current == len(feature_engine.CATALOG)


def catalog_view(session: Session) -> list[dict]:
    rows = session.execute(select(FeatureDefinition).where(FeatureDefinition.is_active.is_(True))
                           .order_by(FeatureDefinition.group, FeatureDefinition.name)).scalars().all()  # fmt: skip
    return [to_dict(r, include={"label": feature_engine.SPECS[r.name].label, "pit_class": feature_engine.SPECS[r.name].pit})
            for r in rows if r.name in feature_engine.SPECS]  # fmt: skip


def schema_hash(features: list[str]) -> str:
    body = json.dumps({"features": [[n, feature_engine.SPECS[n].dtype] for n in features],
                       "engine": feature_engine.engine_hash(), "version": feature_engine.FEATURE_VERSION}, sort_keys=True)  # fmt: skip
    return hashlib.sha256(body.encode()).hexdigest()


# ----------------------------------------------------------------------------- contracts
def create_contract(session: Session, principal: Principal, *, name: str = DEFAULT_CONTRACT, features: list[str] | None = None,
                    exclude_snapshot: bool = False) -> FeatureContract:
    sync_registry(session)
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    chosen = list(features) if features else [f.name for f in feature_engine.CATALOG if not (exclude_snapshot and f.pit == "snapshot")]
    unknown = [f for f in chosen if f not in feature_engine.SPECS]
    if unknown:
        raise ValidationFailed(f"unknown features: {', '.join(unknown)}", details={"field": "features"})
    if len(set(chosen)) != len(chosen) or len(chosen) < 2:
        raise ValidationFailed("a contract needs at least two distinct features", details={"field": "features"})
    ordered = [f for f in feature_engine.FEATURE_NAMES if f in set(chosen)]  # canonical, stable order
    contract = FeatureContract(tenant_id=principal.tenant_id, name=name, features=ordered, schema_hash=schema_hash(ordered),
                               version=next_version(session, FeatureContract, tenant_id=principal.tenant_id, name=name),
                               status="pending", created_by=principal.user_id)  # fmt: skip
    session.add(contract)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="features.contract_created",
                 entity_type="feature_contract", entity_id=contract.id,
                 detail={"name": name, "version": contract.version, "features": len(ordered), "schema_hash": contract.schema_hash})  # fmt: skip
    return contract


def review_contract(session: Session, principal: Principal, contract_id: int, *, approve: bool) -> FeatureContract:
    contract = get_owned(session, FeatureContract, principal.tenant_id, contract_id, label="Feature contract")
    if contract.status != "pending":
        raise Conflict(f"contract is already {contract.status}")
    if contract.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a feature contract cannot be reviewed by its author", code="self_approval_forbidden")
    contract.status = "approved" if approve else "rejected"
    contract.reviewed_by, contract.reviewed_at = principal.user_id, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, entity_type="feature_contract", entity_id=contract.id,
                 action="features.contract_approved" if approve else "features.contract_rejected",
                 detail={"name": contract.name, "version": contract.version})  # fmt: skip
    return contract


def require_usable(contract: FeatureContract) -> FeatureContract:
    """A contract may feed training/serving only if approved and its feature logic is unchanged."""
    if contract.status != "approved":
        raise Conflict(f"feature contract {contract.name} v{contract.version} is not approved (status: {contract.status})",
                       code="contract_not_approved")  # fmt: skip
    if contract.schema_hash != schema_hash(contract.features):
        raise Conflict(f"feature logic changed after contract {contract.name} v{contract.version} was approved; "
                       "create and approve a new contract version", code="contract_stale")  # fmt: skip
    return contract


def contract_view(contract: FeatureContract) -> dict:
    return to_dict(contract, include={"feature_count": len(contract.features),
                                      "logic_current": contract.schema_hash == schema_hash(contract.features)})  # fmt: skip


# ----------------------------------------------------------------------------- materialisation
def start_materialization(session: Session, principal: Principal, *, contract_id: int, as_of_dates: list | None = None,
                          start: Any = None, end: Any = None, publish_online: bool = True) -> tuple[FeatureRun, Any]:
    contract = require_usable(get_owned(session, FeatureContract, principal.tenant_id, contract_id, label="Feature contract"))
    cutoff = timeline.data_cutoff(session, principal.tenant_id)
    if cutoff is None:
        raise Conflict("no data has been ingested yet", code="no_data")
    dates = labels.resolve_dates(as_of_dates, start, end, cutoff)
    run = FeatureRun(tenant_id=principal.tenant_id, contract_id=contract.id, kind="materialize", status="running",
                     as_of_dates=[d.isoformat() for d in dates], data_cutoff=cutoff, created_by=principal.user_id,
                     stats={"publish_online": publish_online})  # fmt: skip
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="features.materialize", created_by=principal.user_id,
                       payload={"feature_run_id": run.id})  # fmt: skip
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="features.materialize_started",
                 entity_type="feature_run", entity_id=run.id, detail={"contract_id": contract.id, "dates": len(dates)})  # fmt: skip
    return run, job


def _records(df: pd.DataFrame, features: list[str]) -> list[dict]:
    values = df[features].astype(object).where(df[features].notna(), None).to_dict(orient="records")
    return [json_safe(v) for v in values]


def grace_days_for(session: Session, tenant_id: int) -> int:
    policy = policies.get_active(session, tenant_id, "churn_definition", required=False)
    return policies.parse(policy).grace_period_days if policy else policies.ChurnDefinition().grace_period_days


def compute_for(tenant_id: int, features: list[str], dates: list[date], customer_ids: list[int] | None = None,
                progress: Any = None) -> pd.DataFrame:
    """Compute feature vectors straight from the canonical tables, one customer chunk at a time."""
    signals.ensure_ready(tenant_id, customer_ids if customer_ids is not None and len(customer_ids) <= 500 else None)
    with read_session() as rs:
        ids = customer_ids if customer_ids is not None else list(rs.execute(
            select(Customer.id).where(Customer.tenant_id == tenant_id).order_by(Customer.id)).scalars())  # fmt: skip
        grace = grace_days_for(rs, tenant_id)
    parts = []
    row_fallback = {"mrr": 0, "plan_tier": 0, "attributes": 0}
    for n, start in enumerate(range(0, len(ids), CUSTOMER_CHUNK)):
        chunk = ids[start : start + CUSTOMER_CHUNK]
        with read_session() as rs:
            frames = timeline.load_frames(rs, tenant_id, customer_ids=chunk)
        part = feature_engine.compute_features(frames, dates, grace_days=grace)
        for key, count in part.attrs.get("row_fallback", {}).items():
            row_fallback[key] += count
        parts.append(part)
        if progress is not None:
            progress(min(0.85, 0.05 + 0.8 * (n + 1) / max(1, -(-len(ids) // CUSTOMER_CHUNK))), f"{min(start + CUSTOMER_CHUNK, len(ids)):,} customers")
    df = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    df = df if df.empty else df[["customer_id", "as_of_date", "max_source_ts", *features]]
    df.attrs["row_fallback"] = row_fallback
    return df


def computed_frame(tenant_id: int, contract: FeatureContract, as_of: date, customer_ids: list[int]) -> pd.DataFrame:
    """Vectors of one date computed for the given customers, in the shape ``offline_frame`` returns.

    A batch can be scored for a date the store was never materialised for (an ad-hoc run between two pipeline
    runs).  It computes its vectors and does not keep them, so a reader that looks at that batch afterwards has to
    compute them again.  Numeric columns come back as float64 and missing categories as None, exactly as the
    store returns them, so that nothing downstream can tell the two sources apart.
    """
    names = list(contract.features)
    df = compute_for(tenant_id, names, [as_of], customer_ids=sorted({int(c) for c in customer_ids})) if customer_ids else pd.DataFrame()
    if df.empty:
        return pd.DataFrame(columns=["customer_id", "as_of_date", *names])
    out = df[["customer_id", "as_of_date", *names]].sort_values(["as_of_date", "customer_id"]).reset_index(drop=True)
    for name in names:
        if feature_engine.SPECS[name].dtype != "category":
            out[name] = pd.to_numeric(out[name], errors="coerce").astype("float64")
        else:
            out[name] = out[name].astype(object).where(out[name].notna(), None)
    out["customer_id"] = out["customer_id"].astype("int64")
    return out


def run_materialization(feature_run_id: int, ctx: Any = None) -> dict:
    try:
        with read_session() as rs:
            run = rs.get(FeatureRun, feature_run_id)
            if run is None:
                raise jobs.PermanentJobError(f"feature run {feature_run_id} does not exist")
            contract = rs.get(FeatureContract, run.contract_id)
            try:
                require_usable(contract)
            except Conflict as exc:
                raise jobs.PermanentJobError(exc.message) from exc
            tenant_id, features = run.tenant_id, list(contract.features)
            dates = [date.fromisoformat(d) for d in run.as_of_dates]
            publish = bool((run.stats or {}).get("publish_online", True))
        df = compute_for(tenant_id, features, dates, progress=(lambda f, m: ctx.progress(f, m, force=True)) if ctx else None)
        now = utcnow()
        rows = 0
        null_rates: dict[str, float] = {}
        if not df.empty:
            null_rates = {k: round(float(v), 6) for k, v in df[features].isna().mean().items() if v > 0}
            if (pd.to_datetime(df["max_source_ts"]) >= pd.to_datetime(df["as_of_date"])).any():
                raise jobs.PermanentJobError("point-in-time violation: a feature vector used a record at or after its as-of date")
        with session_scope() as ws:
            ws.execute(delete(FeatureVector).where(FeatureVector.tenant_id == tenant_id, FeatureVector.contract_id == contract.id,
                                                   FeatureVector.as_of_date.in_(dates)))  # fmt: skip
            if not df.empty:
                payload = _records(df, features)
                stamps = [None if pd.isna(x) else x.to_pydatetime() for x in pd.to_datetime(df["max_source_ts"])]
                records = [{"tenant_id": tenant_id, "contract_id": contract.id, "customer_id": int(c), "as_of_date": d, "values": v,
                            "max_source_ts": m, "run_id": feature_run_id, "computed_at": now}
                           for c, d, v, m in zip(df["customer_id"], df["as_of_date"], payload, stamps, strict=True)]  # fmt: skip
                for start in range(0, len(records), 2000):
                    ws.execute(insert(FeatureVector.__table__), records[start : start + 2000])
                rows = len(records)
                if publish:
                    latest = max(dates)
                    newest_online = ws.execute(select(func.max(OnlineFeature.as_of_date)).where(
                        OnlineFeature.tenant_id == tenant_id, OnlineFeature.contract_id == contract.id)).scalar()  # fmt: skip
                    if newest_online is None or latest >= newest_online:
                        ws.execute(delete(OnlineFeature).where(OnlineFeature.tenant_id == tenant_id, OnlineFeature.contract_id == contract.id))
                        online = [{"tenant_id": tenant_id, "contract_id": contract.id, "customer_id": r["customer_id"],
                                   "as_of_date": latest, "values": r["values"], "updated_at": now}
                                  for r in records if r["as_of_date"] == latest]  # fmt: skip
                        for start in range(0, len(online), 2000):
                            ws.execute(insert(OnlineFeature.__table__), online[start : start + 2000])
            ws.execute(update(FeatureRun).where(FeatureRun.id == feature_run_id).values(
                status="completed", row_count=rows, finished_at=now,
                stats={"publish_online": publish, "null_rates": null_rates, "features": len(features),
                       "row_fallback": df.attrs.get("row_fallback", {}),
                       "rows_by_date": {str(k): int(v) for k, v in df.groupby("as_of_date").size().items()} if rows else {}}))  # fmt: skip
            audit.record(ws, tenant_id=tenant_id, action="features.materialize_completed", entity_type="feature_run",
                         entity_id=feature_run_id, detail={"rows": rows, "dates": len(dates)})  # fmt: skip
        return {"feature_run_id": feature_run_id, "rows": rows, "dates": len(dates), "features": len(features)}
    except Exception as exc:
        if not isinstance(exc, jobs.JobCancelled | jobs.JobInterrupted):
            with session_scope() as ws:
                ws.execute(update(FeatureRun).where(FeatureRun.id == feature_run_id).values(status="failed", finished_at=utcnow(),
                                                                                           stats={"error": str(exc)[:1000]}))  # fmt: skip
        raise


# ----------------------------------------------------------------------------- retrieval
def offline_frame(session: Session, tenant_id: int, contract: FeatureContract, dates: list[date] | None = None,
                  customer_ids: list[int] | None = None) -> pd.DataFrame:
    """Offline store read: one row per (customer, as-of date) with the contract's columns."""
    stmt = select(FeatureVector.customer_id, FeatureVector.as_of_date, FeatureVector.values).where(
        FeatureVector.tenant_id == tenant_id, FeatureVector.contract_id == contract.id)  # fmt: skip
    if dates is not None:
        stmt = stmt.where(FeatureVector.as_of_date.in_(dates))
    if customer_ids is not None:
        stmt = stmt.where(FeatureVector.customer_id.in_(customer_ids))
    rows = session.execute(stmt.order_by(FeatureVector.as_of_date, FeatureVector.customer_id)).all()
    features = list(contract.features)
    if not rows:
        return pd.DataFrame(columns=["customer_id", "as_of_date", *features])
    df = pd.DataFrame([r[2] for r in rows], columns=features)
    for name in features:
        if feature_engine.SPECS[name].dtype != "category":
            df[name] = pd.to_numeric(df[name], errors="coerce").astype("float64")
    df.insert(0, "as_of_date", [r[1] for r in rows])
    df.insert(0, "customer_id", np.array([r[0] for r in rows], dtype="int64"))
    return df


def online_vector(session: Session, tenant_id: int, contract_id: int, customer_id: int) -> dict:
    get_owned(session, Customer, tenant_id, customer_id, label="Customer")
    row = session.execute(select(OnlineFeature).where(OnlineFeature.tenant_id == tenant_id, OnlineFeature.contract_id == contract_id,
                                                      OnlineFeature.customer_id == customer_id)).scalar_one_or_none()  # fmt: skip
    if row is None:
        raise NotFound("no online feature vector for this customer under this contract", code="online_features_missing")
    age = (utcnow() - row.updated_at).total_seconds() / 3600
    return {"customer_id": customer_id, "contract_id": contract_id, "as_of_date": row.as_of_date.isoformat(),
            "updated_at": row.updated_at.isoformat(), "age_hours": round(age, 2), "values": row.values}  # fmt: skip


def store_status(session: Session, tenant_id: int) -> dict:
    offline = session.execute(
        select(FeatureVector.contract_id, FeatureVector.as_of_date, func.count()).where(FeatureVector.tenant_id == tenant_id)
        .group_by(FeatureVector.contract_id, FeatureVector.as_of_date).order_by(FeatureVector.contract_id, FeatureVector.as_of_date)
    ).all()  # fmt: skip
    online = session.execute(
        select(OnlineFeature.contract_id, func.count(), func.max(OnlineFeature.as_of_date), func.max(OnlineFeature.updated_at))
        .where(OnlineFeature.tenant_id == tenant_id).group_by(OnlineFeature.contract_id)
    ).all()  # fmt: skip
    cutoff = timeline.data_cutoff(session, tenant_id)
    return {
        "data_cutoff": cutoff.isoformat() if cutoff else None,
        "offline": [{"contract_id": c, "as_of_date": d.isoformat(), "rows": n} for c, d, n in offline],
        "online": [{"contract_id": c, "rows": n, "as_of_date": d.isoformat(), "updated_at": u.isoformat(),
                    "lag_days": (cutoff.date() - d).days if cutoff else None} for c, n, d, u in online],
    }  # fmt: skip
