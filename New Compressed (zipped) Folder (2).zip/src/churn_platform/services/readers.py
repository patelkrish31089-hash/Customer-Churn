"""Streaming readers for every supported file format, plus schema discovery and mapping suggestions.

All readers are generators that keep memory bounded regardless of file size:
CSV / TSV / TXT (delimiter sniffed), JSON (top-level array is stream-parsed), JSONL, XLSX
(openpyxl read-only mode) and Parquet (record-batch iteration).
"""

from __future__ import annotations

import csv
import json
import os
import re
import warnings
from collections.abc import Iterator
from pathlib import Path
from typing import Any

from ..errors import ValidationFailed
from .schemas import ENTITY_SCHEMAS, SYNONYMS, is_missing, to_bool, to_datetime, to_decimal_value

FORMATS = ("csv", "tsv", "txt", "json", "jsonl", "xlsx", "parquet")
_EXTENSIONS = {".csv": "csv", ".tsv": "tsv", ".tab": "tsv", ".txt": "txt", ".json": "json", ".jsonl": "jsonl",
               ".ndjson": "jsonl", ".xlsx": "xlsx", ".parquet": "parquet", ".pq": "parquet"}  # fmt: skip
MAX_WRAPPED_JSON_BYTES = 64 * 1024 * 1024
_WRAPPER_KEYS = ("data", "items", "records", "results", "rows", "value")
csv.field_size_limit(16 * 1024 * 1024)


class ReaderError(ValidationFailed):
    code = "unreadable_file"


def detect_format(file_name: str, override: str | None = None) -> str:
    if override:
        if override not in FORMATS:
            raise ReaderError(f"unsupported format '{override}'; supported: {', '.join(FORMATS)}")
        return override
    fmt = _EXTENSIONS.get(Path(file_name).suffix.lower())
    if fmt is None:
        raise ReaderError(f"cannot determine the format of '{file_name}'; supported: {', '.join(FORMATS)}")
    return fmt


def _sniff_delimiter(path: Path) -> str:
    with open(path, encoding="utf-8-sig", newline="") as fh:
        sample = fh.read(65536)
    try:
        return csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
    except csv.Error:
        first = sample.splitlines()[0] if sample else ""
        return max(",\t;|", key=first.count) if first else ","


def _iter_delimited(path: Path, delimiter: str) -> Iterator[dict]:
    with open(path, encoding="utf-8-sig", newline="") as fh:
        reader = csv.reader(fh, delimiter=delimiter)
        try:
            header = [h.strip() for h in next(reader)]
        except StopIteration:
            return
        if not any(header) or len(set(header)) != len(header) or "" in header:
            raise ReaderError("the header row must contain unique, non-empty column names")
        width = len(header)
        for line_no, values in enumerate(reader, start=2):
            if not values or all(v == "" for v in values):
                continue
            if len(values) > width:
                raise ReaderError(f"line {line_no} has {len(values)} fields but the header has {width}")
            yield dict(zip(header, values + [""] * (width - len(values)), strict=True))


def _stream_json_array(fh: Any) -> Iterator[Any]:
    """Incrementally parse a (possibly huge) top-level JSON array."""
    decoder = json.JSONDecoder()
    buf, pos, eof, started = "", 0, False, False
    while True:
        while pos < len(buf) and (buf[pos].isspace() or buf[pos] == ","):
            pos += 1
        if pos >= len(buf):
            if eof:
                raise ReaderError("unexpected end of JSON array")
            chunk = fh.read(1 << 20)
            eof = not chunk
            buf, pos = buf[pos:] + chunk, 0
            continue
        if not started:
            if buf[pos] != "[":
                raise ReaderError("expected a JSON array")
            started, pos = True, pos + 1
            continue
        if buf[pos] == "]":
            return
        try:
            obj, end = decoder.raw_decode(buf, pos)
        except json.JSONDecodeError as exc:
            if eof:
                raise ReaderError(f"invalid JSON near character {exc.pos}") from exc
            chunk = fh.read(1 << 20)
            eof = not chunk
            buf, pos = buf[pos:] + chunk, 0
            continue
        yield obj
        pos = end
        if pos > (1 << 20):
            buf, pos = buf[pos:], 0


def _iter_json(path: Path) -> Iterator[dict]:
    with open(path, encoding="utf-8-sig") as fh:
        head = fh.read(4096).lstrip()
        fh.seek(0)
        if head.startswith("["):
            records: Any = _stream_json_array(fh)
        else:
            if os.path.getsize(path) > MAX_WRAPPED_JSON_BYTES:
                raise ReaderError("JSON documents this large must be a top-level array or JSON Lines")
            try:
                doc = json.load(fh)
            except json.JSONDecodeError as exc:
                raise ReaderError(f"invalid JSON: {exc.msg} (line {exc.lineno})") from exc
            records = [doc]
            if isinstance(doc, dict):
                lists = [k for k in _WRAPPER_KEYS if isinstance(doc.get(k), list)] or \
                        [k for k, v in doc.items() if isinstance(v, list)]  # fmt: skip
                if lists:
                    records = doc[lists[0]]
        for idx, rec in enumerate(records, start=1):
            if not isinstance(rec, dict):
                raise ReaderError(f"JSON record {idx} is not an object")
            yield rec


def _iter_jsonl(path: Path) -> Iterator[dict]:
    with open(path, encoding="utf-8-sig") as fh:
        for line_no, line in enumerate(fh, start=1):
            if not line.strip():
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ReaderError(f"line {line_no} is not valid JSON: {exc.msg}") from exc
            if not isinstance(rec, dict):
                raise ReaderError(f"line {line_no} is not a JSON object")
            yield rec


def _iter_xlsx(path: Path, sheet: str | None = None) -> Iterator[dict]:
    from openpyxl import load_workbook

    with warnings.catch_warnings():
        # openpyxl warns about cosmetic workbook features (styles, validations) it does not model;
        # irrelevant for reading cell values from a user-supplied file.
        warnings.simplefilter("ignore", UserWarning)
        wb = load_workbook(path, read_only=True, data_only=True)
    try:
        if sheet and sheet not in wb.sheetnames:
            raise ReaderError(f"worksheet '{sheet}' not found; available: {', '.join(wb.sheetnames)}")
        ws = wb[sheet] if sheet else wb[wb.sheetnames[0]]
        rows = ws.iter_rows(values_only=True)
        try:
            header = [str(h).strip() if h is not None else "" for h in next(rows)]
        except StopIteration:
            return
        while header and header[-1] == "":
            header.pop()
        if not header or "" in header or len(set(header)) != len(header):
            raise ReaderError("the first worksheet row must contain unique, non-empty column names")
        for values in rows:
            values = list(values[: len(header)])
            if all(v is None or v == "" for v in values):
                continue
            yield dict(zip(header, values + [None] * (len(header) - len(values)), strict=True))
    finally:
        wb.close()


def _iter_parquet(path: Path) -> Iterator[dict]:
    import pyarrow.parquet as pq

    try:
        pf = pq.ParquetFile(path)
    except Exception as exc:  # pyarrow raises several unrelated types for corrupt files
        raise ReaderError(f"not a readable Parquet file: {str(exc)[:200]}") from exc
    for batch in pf.iter_batches(batch_size=5000):
        yield from batch.to_pylist()


def iter_rows(path: str | Path, fmt: str, options: dict | None = None) -> Iterator[dict]:
    """Yield one ``dict`` per source record."""
    path, options = Path(path), options or {}
    try:
        if fmt == "csv":
            yield from _iter_delimited(path, options.get("delimiter") or ",")
        elif fmt == "tsv":
            yield from _iter_delimited(path, "\t")
        elif fmt == "txt":
            yield from _iter_delimited(path, options.get("delimiter") or _sniff_delimiter(path))
        elif fmt == "json":
            yield from _iter_json(path)
        elif fmt == "jsonl":
            yield from _iter_jsonl(path)
        elif fmt == "xlsx":
            yield from _iter_xlsx(path, options.get("sheet"))
        elif fmt == "parquet":
            yield from _iter_parquet(path)
        else:
            raise ReaderError(f"unsupported format '{fmt}'")
    except UnicodeDecodeError as exc:
        raise ReaderError("text files must be UTF-8 encoded") from exc
    except csv.Error as exc:
        raise ReaderError(f"malformed delimited file: {exc}") from exc


# ----------------------------------------------------------------------------- schema discovery
def _infer(value: Any) -> str:
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    if hasattr(value, "isoformat"):
        return "datetime"
    if isinstance(value, dict | list):
        return "json"
    if type(value).__name__ == "Decimal":
        return "decimal"
    text = str(value).strip()
    if re.fullmatch(r"-?\d+", text):
        return "int"
    try:
        to_decimal_value(text)
        return "float"
    except ValueError:
        pass
    if text.lower() in ("true", "false", "yes", "no"):
        try:
            to_bool(text)
            return "bool"
        except ValueError:
            pass
    if re.match(r"^\d{4}[-/]\d{2}[-/]\d{2}", text):
        try:
            to_datetime(text)
            return "datetime"
        except ValueError:
            pass
    return "str"


_WIDEN = {frozenset(("int", "float")): "float", frozenset(("int", "decimal")): "decimal",
          frozenset(("float", "decimal")): "decimal"}  # fmt: skip


def discover_schema(path: str | Path, fmt: str, options: dict | None = None, sample_rows: int = 1000) -> dict:
    """Profile the file: column names, inferred types, null counts, examples and total row count."""
    columns: dict[str, dict] = {}
    total = 0
    for row in iter_rows(path, fmt, options):
        total += 1
        if total > sample_rows:
            continue  # keep counting rows, stop profiling
        for name, value in row.items():
            col = columns.setdefault(str(name), {"name": str(name), "types": {}, "nulls": 0, "examples": []})
            if is_missing(value):
                col["nulls"] += 1
                continue
            kind = _infer(value)
            col["types"][kind] = col["types"].get(kind, 0) + 1
            if len(col["examples"]) < 3:
                col["examples"].append(str(value)[:80])
    out = []
    for col in columns.values():
        kinds = set(col["types"])
        inferred = next(iter(kinds)) if len(kinds) == 1 else _WIDEN.get(frozenset(kinds), "str") if kinds else "unknown"
        out.append({"name": col["name"], "inferred_type": inferred, "nulls_in_sample": col["nulls"],
                    "examples": col["examples"]})  # fmt: skip
    return {"columns": out, "row_count": total, "sampled_rows": min(total, sample_rows)}


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.strip().lower()).strip("_")


def suggest_mapping(entity_type: str, column_names: list[str]) -> dict:
    """Propose canonical-field -> source-column pairs from names and common synonyms."""
    by_norm = {_norm(c): c for c in column_names}
    mapping: dict[str, str] = {}
    used: set[str] = set()
    for spec in ENTITY_SCHEMAS[entity_type]:
        candidates = (spec.name, *SYNONYMS.get(spec.name, ()))
        if spec.name == "external_id":
            singular = entity_type.rstrip("s")
            candidates = (*candidates, f"{singular}_id", f"{_norm(entity_type)}_id", f"{singular}_external_id")
        for cand in candidates:
            source = by_norm.get(_norm(cand))
            if source is not None and source not in used:
                mapping[spec.name] = source
                used.add(source)
                break
    return mapping
