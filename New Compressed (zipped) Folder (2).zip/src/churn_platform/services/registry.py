"""Model registry: versions, promotion gates, independent approval, stage transitions.  Only an approved version
in the ``production`` stage may serve predictions.

Lifecycle (1.1.0): ``candidate -> validated -> approved -> staging -> production -> archived`` (or ``rejected``).
A version becomes *validated* when it passes the tenant's promotion gates; every attempted transition - applied or
blocked - is written to ``model_stage_transitions`` with the gate results it was decided on.  When the MLflow
registry is the registry of record (``CHURN_MODEL_REGISTRY=mlflow``), the version that serves is the one MLflow's
``production`` alias names, and it must be the same one this registry holds.
"""

from __future__ import annotations

import hashlib
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import storage
from ..config import get_settings
from ..db import utcnow
from ..errors import Conflict, Forbidden, NotFound, ServiceUnavailable, ValidationFailed
from ..models import MLDataset, ModelEvaluation, ModelRun, ModelStageTransition, ModelVersion, Policy
from ..security import Principal
from . import audit, mlflow_mirror
from .common import get_owned, next_version, to_dict

STAGES = ("none", "staging", "production", "archived")
DEFAULT_GATES = {"min_test_pr_auc": None, "min_test_roc_auc": None, "max_brier": None, "max_calibration_error": None,
                 "max_pr_auc_drop_vs_production": None, "min_test_rows": None, "min_test_positives": None, "require_leakage_checks": True,
                 "require_reproducible_training": True, "require_model_card": True}  # fmt: skip


def lifecycle_of(version: ModelVersion) -> str:
    """The lifecycle state that follows from a version's stage, approval and validation."""
    if version.stage in ("production", "staging", "archived"):
        return version.stage
    if version.approval_status == "rejected":
        return "rejected"
    if version.approval_status == "approved":
        return "approved"
    return "validated" if version.validated_at is not None else "candidate"


def _transition(session: Session, version: ModelVersion, principal: Principal | None, before: str, *, decision: str = "applied",
                gates: list[dict] | None = None, note: str | None = None, to_state: str | None = None) -> ModelStageTransition:
    version.lifecycle_state = lifecycle_of(version)
    entry = ModelStageTransition(tenant_id=version.tenant_id, model_version_id=version.id, from_state=before,
                                 to_state=to_state or version.lifecycle_state, decision=decision, gates=gates, note=note,
                                 actor_user_id=principal.user_id if principal is not None else None)  # fmt: skip
    session.add(entry)
    session.flush()
    return entry


def promotion_gates(session: Session, tenant_id: int) -> tuple[dict, int | None]:
    """The gates in force: the tenant's approved ``promotion_gates`` policy, or the structural defaults."""
    policy = session.execute(select(Policy).where(Policy.tenant_id == tenant_id, Policy.kind == "promotion_gates", Policy.status == "approved")
                             .order_by(Policy.version.desc(), Policy.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
    if policy is None:
        return dict(DEFAULT_GATES), None
    return {**DEFAULT_GATES, **{k: v for k, v in policy.payload.items() if k in DEFAULT_GATES}}, policy.id


def artifact_matches(run: ModelRun) -> bool:
    """The stored model file still has the checksum recorded when it was trained."""
    if not run.artifact_path or not run.artifact_sha256:
        return False
    try:
        path = storage.resolve(run.artifact_path)
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1 << 20), b""):
                digest.update(block)
    except OSError:
        return False
    return digest.hexdigest() == run.artifact_sha256


def check_gates(session: Session, version: ModelVersion) -> tuple[list[dict], int | None]:
    """Every promotion gate with its outcome: ``pass``, ``fail`` or ``not_checked`` (no threshold set)."""
    gates, policy_id = promotion_gates(session, version.tenant_id)
    run = session.get(ModelRun, version.model_run_id)
    dataset = session.get(MLDataset, run.dataset_id)
    test = run.test_metrics or {}
    results: list[dict] = []

    def add(gate: str, status: str, value: Any = None, threshold: Any = None, detail: str | None = None) -> None:
        results.append({"gate": gate, "status": status, "value": value, "threshold": threshold, "detail": detail})

    def bound(gate: str, value: Any, *, at_least: bool) -> None:
        threshold = gates[gate]
        if threshold is None:
            add(gate, "not_checked", value, None, "no threshold set in the promotion-gate policy")
        elif value is None:
            add(gate, "fail", None, threshold, "the model has no final test evaluation, so the value does not exist")
        else:
            add(gate, "pass" if (value >= threshold if at_least else value <= threshold) else "fail", value, threshold)

    bound("min_test_pr_auc", test.get("pr_auc"), at_least=True)
    bound("min_test_roc_auc", test.get("roc_auc"), at_least=True)
    bound("max_brier", test.get("brier"), at_least=False)
    bound("max_calibration_error", test.get("ece"), at_least=False)
    bound("min_test_rows", test.get("n"), at_least=True)
    bound("min_test_positives", test.get("positives"), at_least=True)
    allowed_drop = gates["max_pr_auc_drop_vs_production"]
    current = session.execute(select(ModelVersion).where(ModelVersion.tenant_id == version.tenant_id, ModelVersion.name == version.name,
                                                         ModelVersion.stage == "production", ModelVersion.id != version.id)).scalars().first()  # fmt: skip
    if allowed_drop is None:
        add("max_pr_auc_drop_vs_production", "not_checked", None, None, "no threshold set in the promotion-gate policy")
    elif current is None:
        add("max_pr_auc_drop_vs_production", "pass", None, allowed_drop, "there is no production model to compare with")
    else:
        reference = (session.get(ModelRun, current.model_run_id).test_metrics or {}).get("pr_auc")
        if reference is None or test.get("pr_auc") is None:
            add("max_pr_auc_drop_vs_production", "fail", None, allowed_drop, "one of the two models has no final test evaluation")
        else:
            drop = round(reference - test["pr_auc"], 6)
            add("max_pr_auc_drop_vs_production", "pass" if drop <= allowed_drop else "fail", drop, allowed_drop,
                f"production v{current.version} has test PR-AUC {reference:.4f}; the two test sets may differ")  # fmt: skip
    if gates["require_leakage_checks"]:
        report = dataset.leakage_report or {}
        add("require_leakage_checks", "pass" if report.get("passed") is True else "fail", report.get("passed"), True,
            None if report.get("passed") is True else "the training dataset's leakage checks did not pass (or were never run)")  # fmt: skip
    else:
        add("require_leakage_checks", "not_checked", None, False, "switched off in the promotion-gate policy")
    if gates["require_reproducible_training"]:
        ok = run.seed is not None and bool(dataset.fingerprint) and artifact_matches(run)
        add("require_reproducible_training", "pass" if ok else "fail", ok, True,
            None if ok else "needs a recorded seed, a dataset fingerprint and a model file whose checksum still matches")  # fmt: skip
    else:
        add("require_reproducible_training", "not_checked", None, False, "switched off in the promotion-gate policy")
    if gates["require_model_card"]:
        splits = set(session.execute(select(ModelEvaluation.split).where(ModelEvaluation.model_run_id == run.id)).scalars())
        ok = {"valid", "test"} <= splits and run.test_evaluated_at is not None
        add("require_model_card", "pass" if ok else "fail", sorted(splits), ["valid", "test"],
            None if ok else "the model card needs the validation evaluation and the final test evaluation")  # fmt: skip
    else:
        add("require_model_card", "not_checked", None, False, "switched off in the promotion-gate policy")
    return results, policy_id


def validate(session: Session, principal: Principal, version_id: int) -> dict:
    """Check a version against the promotion gates.  Passing makes it ``validated``; failing is recorded as a
    blocked transition.  Either way the gate results are returned and kept."""
    version = get_owned(session, ModelVersion, principal.tenant_id, version_id, label="Model version")
    if version.approval_status == "rejected":
        raise Conflict("a rejected model version cannot be validated; register a new version")
    before = lifecycle_of(version)
    gates, policy_id = check_gates(session, version)
    failed = [g for g in gates if g["status"] == "fail"]
    if failed:
        entry = _transition(session, version, principal, before, decision="blocked", gates=gates, to_state="validated",
                            note="; ".join(f"{g['gate']}: {g['detail'] or 'outside the threshold'}" for g in failed)[:1000])  # fmt: skip
    else:
        version.validated_at = utcnow()
        entry = _transition(session, version, principal, before, gates=gates, to_state="validated" if before == "candidate" else None)
    audit.record(session, tenant_id=version.tenant_id, actor=principal, action="ml.model_validated" if not failed else "ml.model_validation_blocked",
                 entity_type="model_version", entity_id=version.id,
                 detail={"name": version.name, "version": version.version, "policy_id": policy_id, "failed_gates": [g["gate"] for g in failed]})  # fmt: skip
    if not failed:
        mlflow_mirror.enqueue_if_enabled(session, version)
    return {"decision": entry.decision, "version": version_view(version), "gates": gates, "policy_id": policy_id, "transition_id": entry.id}


def transitions(session: Session, tenant_id: int, version_id: int) -> list[dict]:
    get_owned(session, ModelVersion, tenant_id, version_id, label="Model version")
    rows = session.execute(select(ModelStageTransition).where(ModelStageTransition.model_version_id == version_id)
                           .order_by(ModelStageTransition.id)).scalars().all()  # fmt: skip
    return [to_dict(r) for r in rows]


def register(session: Session, principal: Principal, run_id: int, name: str = "churn-model") -> ModelVersion:
    run = get_owned(session, ModelRun, principal.tenant_id, run_id, label="Model run")
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if run.status != "completed":
        raise Conflict(f"only completed runs can be registered (status: {run.status})")
    if session.execute(select(ModelVersion.id).where(ModelVersion.model_run_id == run.id)).first():
        raise Conflict("this model run is already registered")
    dataset = session.get(MLDataset, run.dataset_id)
    evaluation = session.execute(select(ModelEvaluation).where(ModelEvaluation.model_run_id == run.id, ModelEvaluation.split == "valid")
                                 .order_by(ModelEvaluation.id.desc())).scalars().first()  # fmt: skip
    if evaluation is None:
        raise Conflict("evaluate the run on the validation split first so an operating threshold exists", code="not_evaluated")
    analysis = evaluation.threshold_analysis or {}
    version = ModelVersion(tenant_id=run.tenant_id, name=name, version=next_version(session, ModelVersion, tenant_id=run.tenant_id, name=name),
                           model_run_id=run.id, contract_id=dataset.contract_id, stage="none", approval_status="pending",
                           threshold=analysis.get("threshold"), cost_policy_id=evaluation.cost_policy_id,
                           threshold_basis={"basis": analysis.get("basis"), "evaluation_id": evaluation.id,
                                            "selected_on": "validation split", "is_example": analysis.get("is_example", False)},
                           created_by=principal.user_id)  # fmt: skip
    session.add(version)
    session.flush()
    _transition(session, version, principal, "unregistered", note="registered from a completed training run")
    audit.record(session, tenant_id=run.tenant_id, actor=principal, action="ml.model_registered", entity_type="model_version",
                 entity_id=version.id, detail={"name": name, "version": version.version, "run_id": run.id})  # fmt: skip
    mlflow_mirror.enqueue_if_enabled(session, version)
    return version


def review(session: Session, principal: Principal, version_id: int, *, approve: bool, note: str | None = None) -> ModelVersion:
    version = get_owned(session, ModelVersion, principal.tenant_id, version_id, label="Model version")
    if version.approval_status != "pending":
        raise Conflict(f"model version is already {version.approval_status}")
    if version.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a model cannot be approved or rejected by the person who registered it",
                        code="self_approval_forbidden")  # fmt: skip
    run = session.get(ModelRun, version.model_run_id)
    if approve and run.test_evaluated_at is None:
        raise Conflict("run the final TEST evaluation before approving this model", code="test_evaluation_required")
    before = lifecycle_of(version)
    if approve:
        # approval is decided on gate results: a version that was never validated is checked now, and a version
        # whose gates fail cannot be approved (use "Validate" to see and record why)
        gates, _policy_id = check_gates(session, version)
        failed = [g for g in gates if g["status"] == "fail"]
        if failed:
            raise Conflict("this model version does not pass the promotion gates: " + "; ".join(g["gate"] for g in failed),
                           code="promotion_gates_failed", details=failed)  # fmt: skip
        if version.validated_at is None:
            version.validated_at = utcnow()
            _transition(session, version, principal, before, gates=gates, to_state="validated", note="validated as part of the approval")
            before = "validated"
    version.approval_status = "approved" if approve else "rejected"
    version.reviewed_by, version.reviewed_at, version.review_note = principal.user_id, utcnow(), note
    _transition(session, version, principal, before, note=note)
    mlflow_mirror.enqueue_if_enabled(session, version)  # the registry's tags and aliases follow the decision
    audit.record(session, tenant_id=version.tenant_id, actor=principal, entity_type="model_version", entity_id=version.id,
                 action="ml.model_approved" if approve else "ml.model_rejected",
                 detail={"name": version.name, "version": version.version, "note": note,
                         "test_pr_auc": (run.test_metrics or {}).get("pr_auc")})  # fmt: skip
    return version


def set_stage(session: Session, principal: Principal, version_id: int, stage: str) -> ModelVersion:
    version = get_owned(session, ModelVersion, principal.tenant_id, version_id, label="Model version")
    if stage not in STAGES:
        raise ValidationFailed(f"stage must be one of {', '.join(STAGES)}", details={"field": "stage"})
    if stage in ("staging", "production") and version.approval_status != "approved":
        raise Conflict("only an approved model version can be promoted", code="model_not_approved")
    previous, before = version.stage, lifecycle_of(version)
    if stage == "production":
        current = select(ModelVersion).where(ModelVersion.tenant_id == version.tenant_id, ModelVersion.name == version.name,
                                             ModelVersion.stage == "production", ModelVersion.id != version.id)  # fmt: skip
        for other in session.execute(current).scalars():
            other.stage = "archived"
            _transition(session, other, principal, "production", note=f"replaced by v{version.version}")
            mlflow_mirror.enqueue_if_enabled(session, other)
    version.stage = stage
    _transition(session, version, principal, before, note="rolled back to this version" if before == "archived" and stage == "production" else None)
    audit.record(session, tenant_id=version.tenant_id, actor=principal, action="ml.model_stage_changed", entity_type="model_version",
                 entity_id=version.id, detail={"name": version.name, "version": version.version, "from": previous, "to": stage})  # fmt: skip
    mlflow_mirror.enqueue_if_enabled(session, version)
    return version


def production_version(session: Session, tenant_id: int, name: str | None = None, version_id: int | None = None) -> ModelVersion:
    """The model allowed to serve: explicitly requested or the current production version."""
    if version_id is not None:
        version = get_owned(session, ModelVersion, tenant_id, version_id, label="Model version")
    else:
        stmt = select(ModelVersion).where(ModelVersion.tenant_id == tenant_id, ModelVersion.stage == "production",
                                          ModelVersion.approval_status == "approved")  # fmt: skip
        if name:
            stmt = stmt.where(ModelVersion.name == name)
        version = session.execute(stmt.order_by(ModelVersion.reviewed_at.desc(), ModelVersion.id.desc())).scalars().first()
        if version is None:
            raise NotFound("no approved model is in production yet", code="no_production_model")
    if version.approval_status != "approved" or version.stage != "production":
        raise Conflict(f"model {version.name} v{version.version} cannot serve predictions: approval is "
                       f"'{version.approval_status}' and stage is '{version.stage}' (needs approved + production)",
                       code="model_not_servable")  # fmt: skip
    if get_settings().model_registry == "mlflow":
        _confirm_with_mlflow(session, version)
    return version


def _confirm_with_mlflow(session: Session, version: ModelVersion) -> None:
    """With MLflow as the registry of record, the serving version must be the one its ``production`` alias names,
    and the model file here must be the file MLflow registered.  Any doubt stops serving."""
    run = session.get(ModelRun, version.model_run_id)
    try:
        named = mlflow_mirror.resolve_alias(version.tenant_id, version.name, "production")
    except mlflow_mirror.RegistryUnavailable as exc:
        raise ServiceUnavailable(f"the MLflow model registry cannot be reached, so no model is cleared to serve: {exc}", code="registry_unavailable") from exc
    if named is None:
        raise Conflict("the MLflow registry has no 'production' alias for this model; promote it again or wait for the registry sync",
                       code="registry_mismatch")  # fmt: skip
    if named["platform_version_id"] != version.id:
        raise Conflict(f"the MLflow registry names a different production model (MLflow version {named['mlflow_version']}) than this "
                       f"platform ({version.name} v{version.version}); nothing is served until the two agree", code="registry_mismatch")  # fmt: skip
    if named["artifact_sha256"] != run.artifact_sha256:
        raise Conflict(f"the model file of {version.name} v{version.version} recorded here does not have the checksum MLflow registered "
                       f"for it (MLflow version {named['mlflow_version']}); nothing is served until the two agree", code="registry_mismatch")  # fmt: skip


def version_view(version: ModelVersion, run: ModelRun | None = None) -> dict:
    view = to_dict(version)
    view["lifecycle_state"] = lifecycle_of(version)
    if run is not None:
        view.update({"algorithm": run.algorithm, "valid_pr_auc": (run.valid_metrics or {}).get("pr_auc"),
                     "test_pr_auc": (run.test_metrics or {}).get("pr_auc"), "test_evaluated_at": run.test_evaluated_at and run.test_evaluated_at.isoformat()})  # fmt: skip
    return view
