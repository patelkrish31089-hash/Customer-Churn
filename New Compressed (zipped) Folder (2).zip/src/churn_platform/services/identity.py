"""Who is "a user": the identity mapping behind daily active users.

Telemetry names people by whatever identifier the source uses.  This module keeps the mapping from those
identifiers to the platform's own key for a person (``user_key``), and reports how good that mapping is.

Rules (all of them visible on the Identity screen)
  * identifiers are compared trimmed and case-folded;
  * an e-mail address names one person everywhere; any other identifier names a person *within one customer*
    (the same "17" under two customers is two people);
  * an identifier that has no link yet counts as itself, so nobody is lost while the mapping is incomplete;
  * a quarantined or rejected link counts for nobody; identifiers matching the activity definition's exclusion
    patterns (staff, tests, automation) count for nobody;
  * two keys are merged only by a person's decision; the platform proposes candidates and never merges on its own.

The counting itself is ``feature_engine.resolve_users``; features and this module's series use the same function.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, NotFound, ValidationFailed
from ..models import Customer, IdentityLink, IdentityMergeCandidate, IdentityReconciliation, UsageEvent
from ..security import Principal
from . import audit, feature_engine, jobs, timeline
from .common import get_owned, to_dict

SOURCE = "usage_events"


def is_email(ref: str) -> bool:
    return "@" in ref and "." in ref.rsplit("@", 1)[-1]


def user_key(tenant_id: int, ref: str, customer_id: int | None) -> str:
    """The platform's key for the person behind a normalised identifier."""
    scope = "global" if is_email(ref) else f"customer:{customer_id}"
    return "u_" + hashlib.sha256(f"{tenant_id}|{scope}|{ref}".encode()).hexdigest()[:28]


def person_key(tenant_id: int, person_id: str) -> str:
    """Key for a person named by the customer's own identity system (imported mappings)."""
    return "p_" + hashlib.sha256(f"{tenant_id}|person|{person_id.strip().casefold()}".encode()).hexdigest()[:28]


def link_view(link: IdentityLink) -> dict:
    return to_dict(link)


# ----------------------------------------------------------------------------- reconciliation
def start_reconciliation(session: Session, principal: Principal, *, window_days: int = 90) -> tuple[IdentityReconciliation, Any]:
    if not 7 <= window_days <= 730:
        raise ValidationFailed("window_days must be between 7 and 730", details={"field": "window_days"})
    entry = IdentityReconciliation(tenant_id=principal.tenant_id, status="pending", window_days=window_days, created_by=principal.user_id)
    session.add(entry)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="identity.reconcile", payload={"reconciliation_id": entry.id},
                       created_by=principal.user_id)  # fmt: skip
    entry.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.reconciliation_started", entity_type="identity_reconciliation",
                 entity_id=entry.id, detail={"window_days": window_days})  # fmt: skip
    return entry, job


def ensure_links(session: Session, tenant_id: int) -> dict:
    """Create a link for every identifier seen in telemetry that has none, and propose merge candidates."""
    pairs = session.execute(select(UsageEvent.customer_id, UsageEvent.user_ref, func.count(), func.min(UsageEvent.occurred_at))
                            .where(UsageEvent.tenant_id == tenant_id, UsageEvent.user_ref.is_not(None))
                            .group_by(UsageEvent.customer_id, UsageEvent.user_ref)).all()  # fmt: skip
    seen: dict[tuple[int, str], dict] = {}
    for customer_id, raw, count, first in pairs:
        ref = feature_engine.normalise_ref(raw)
        if ref is None:
            continue
        entry = seen.setdefault((customer_id, ref), {"events": 0, "raw": set(), "first": first})
        entry["events"] += int(count)
        entry["raw"].add(raw)
        entry["first"] = min(entry["first"], first)
    existing = {(link.customer_id, link.external_user_id) for link in session.execute(
        select(IdentityLink).where(IdentityLink.tenant_id == tenant_id, IdentityLink.source == SOURCE)).scalars()}  # fmt: skip
    global_links = {ref for customer_id, ref in existing if customer_id is None}
    created = 0
    for (customer_id, ref), _info in seen.items():
        if (customer_id, ref) in existing or ref in global_links:
            continue
        session.add(IdentityLink(tenant_id=tenant_id, user_key=user_key(tenant_id, ref, customer_id), source=SOURCE, external_user_id=ref,
                                 customer_id=customer_id, confidence=1.0, match_rule="email" if is_email(ref) else "source_id", status="active"))  # fmt: skip
        created += 1
    session.flush()
    # --- candidates: within one customer, an e-mail address whose local part equals another identifier of that customer
    by_customer: dict[int, list[str]] = {}
    for customer_id, ref in seen:
        by_customer.setdefault(customer_id, []).append(ref)
    known_pairs = {(c.user_key_a, c.user_key_b) for c in session.execute(select(IdentityMergeCandidate).where(IdentityMergeCandidate.tenant_id == tenant_id)).scalars()}
    keys = {(link.customer_id, link.external_user_id): link.user_key for link in session.execute(
        select(IdentityLink).where(IdentityLink.tenant_id == tenant_id, IdentityLink.status == "active")).scalars()}  # fmt: skip
    proposed = 0
    for customer_id, refs in by_customer.items():
        plain = {ref for ref in refs if not is_email(ref)}
        for ref in refs:
            local = ref.split("@", 1)[0] if is_email(ref) else None
            if local and local in plain:
                a, b = keys.get((customer_id, ref)) or keys.get((None, ref)), keys.get((customer_id, local))
                if a and b and a != b and (min(a, b), max(a, b)) not in known_pairs:
                    known_pairs.add((min(a, b), max(a, b)))
                    session.add(IdentityMergeCandidate(tenant_id=tenant_id, user_key_a=min(a, b), user_key_b=max(a, b), reason="email_local_part_matches_id",
                                                       evidence={"customer_id": customer_id, "identifiers": sorted([ref, local])}, confidence=0.6))  # fmt: skip
                    proposed += 1
    scopes: dict[str, set[int]] = {}
    for customer_id, ref in seen:
        if not is_email(ref):
            scopes.setdefault(ref, set()).add(customer_id)
    return {"identifiers_seen": len(seen), "links_created": created, "merge_candidates_proposed": proposed,
            "raw_variants_folded": sum(len(info["raw"]) - 1 for info in seen.values()),
            "non_email_identifiers_under_several_customers": sum(1 for customers in scopes.values() if len(customers) > 1)}  # fmt: skip


def activity_series(tenant_id: int, window_days: int) -> dict:
    """Daily / weekly / monthly active people over the window, with what the mapping changed and what is missing."""
    with read_session() as rs:
        cutoff = timeline.data_cutoff(rs, tenant_id)
        if cutoff is None:
            return {"days": [], "note": "no data"}
        signals = timeline.load_signal_frames(rs, tenant_id)
        activity = {**feature_engine.DEFAULT_ACTIVITY, **(signals.get("activity") or {})}
        end = cutoff + timedelta(seconds=1)
        start = end - timedelta(days=window_days + 30)  # 30 extra days so that the first monthly figure is complete
        rows = rs.execute(select(UsageEvent.customer_id, UsageEvent.user_ref, UsageEvent.occurred_at, UsageEvent.event_type).where(
            UsageEvent.tenant_id == tenant_id, UsageEvent.occurred_at >= start, UsageEvent.occurred_at < end,
            UsageEvent.event_type.in_(activity["active_event_types"]))).all()  # fmt: skip
    usage = pd.DataFrame(rows, columns=["customer_id", "user_ref", "occurred_at", "event_type"])
    if usage.empty:
        return {"days": [], "note": "no activity events in the window", "definition": activity}
    usage["occurred_at"] = pd.to_datetime(usage["occurred_at"], utc=True)
    usage["day"] = usage["occurred_at"].dt.tz_convert(activity["timezone"]).dt.tz_localize(None).dt.normalize()
    usage["occurred_at"] = usage["occurred_at"].dt.tz_convert(None)
    usage["user"] = feature_engine.resolve_users(usage, signals.get("identity"), activity["exclude_user_patterns"])
    raw = usage["user_ref"].map(feature_engine.normalise_ref)
    pattern = feature_engine.exclusion_pattern(activity["exclude_user_patterns"])
    excluded = raw.map(lambda ref: bool(pattern.match(ref)) if pattern is not None and isinstance(ref, str) else False)
    usage = usage.assign(raw=raw, excluded=excluded)
    known = usage[usage["user"].notna()]
    per_day = known.groupby("day")["user"].agg(set)
    raw_per_day = usage[usage["raw"].notna()].groupby("day")["raw"].nunique()
    events_per_day = usage.groupby("day").size()
    unidentified_per_day = usage[usage["user_ref"].isna()].groupby("day").size()
    days = pd.date_range(per_day.index.max() - pd.Timedelta(days=window_days - 1), per_day.index.max(), freq="D")
    series = []
    for day in days:
        week = set().union(*[per_day.get(day - pd.Timedelta(days=d), set()) for d in range(7)])
        month = set().union(*[per_day.get(day - pd.Timedelta(days=d), set()) for d in range(30)])
        dau = len(per_day.get(day, set()))
        series.append({"day": day.date().isoformat(), "dau": dau, "wau": len(week), "mau": len(month),
                       "stickiness": round(dau / len(month), 4) if month else None, "raw_identifiers": int(raw_per_day.get(day, 0)),
                       "events": int(events_per_day.get(day, 0)), "events_without_user": int(unidentified_per_day.get(day, 0))})  # fmt: skip
    inside = usage[usage["day"] >= days[0]]
    by_customer = inside.groupby("customer_id").agg(events=("user_ref", "size"), identified=("user_ref", "count"))
    by_customer["share"] = by_customer["identified"] / by_customer["events"]
    threshold = float(activity["min_identified_share"])
    return {
        "definition": activity, "window_days": window_days, "days": series,
        "totals": {
            "events": int(len(inside)), "events_without_user": int(inside["user_ref"].isna().sum()),
            "identified_event_share": round(float(inside["user_ref"].notna().mean()), 4),
            "raw_identifiers": int(inside["raw"].nunique()), "people": int(inside["user"].nunique()),
            "excluded_identifiers": int(inside.loc[inside["excluded"], "raw"].nunique()), "excluded_events": int(inside["excluded"].sum()),
            "events_counting_for_nobody_after_review": int((inside["user"].isna() & inside["user_ref"].notna() & ~inside["excluded"]).sum()),
            "customers_with_activity": int(len(by_customer)),
            "customers_below_identified_threshold": int((by_customer["share"] < threshold).sum()),
            "customers_without_any_user": int((by_customer["identified"] == 0).sum()),
        },
        "last_day": series[-1] if series else None,
    }  # fmt: skip


def run_reconciliation(reconciliation_id: int, ctx: Any = None) -> dict:
    with session_scope() as ws:
        entry = ws.get(IdentityReconciliation, reconciliation_id)
        if entry is None:
            raise jobs.PermanentJobError(f"identity reconciliation {reconciliation_id} does not exist")
        entry.status = "running"
        tenant_id, window = entry.tenant_id, entry.window_days
    try:
        with session_scope() as ws:
            links = ensure_links(ws, tenant_id)
        if ctx is not None:
            ctx.progress(0.4, "links up to date")
        series = activity_series(tenant_id, window)
    except Exception as exc:
        with session_scope() as ws:
            entry = ws.get(IdentityReconciliation, reconciliation_id)
            entry.status, entry.error, entry.finished_at = "failed", f"{type(exc).__name__}: {exc}"[:1000], utcnow()
        raise
    with session_scope() as ws:
        entry = ws.get(IdentityReconciliation, reconciliation_id)
        entry.status, entry.result, entry.finished_at = "completed", {"links": links, **series}, utcnow()
        audit.record(ws, tenant_id=tenant_id, action="identity.reconciliation_completed", entity_type="identity_reconciliation", entity_id=reconciliation_id,
                     detail={**links, "people": (series.get("totals") or {}).get("people")})  # fmt: skip
    return {"reconciliation_id": reconciliation_id, **links, "people": (series.get("totals") or {}).get("people")}


def latest(session: Session, tenant_id: int) -> IdentityReconciliation | None:
    return session.execute(select(IdentityReconciliation).where(IdentityReconciliation.tenant_id == tenant_id, IdentityReconciliation.status == "completed")
                           .order_by(IdentityReconciliation.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip


def overview(session: Session, tenant_id: int) -> dict:
    counts = dict(session.execute(select(IdentityLink.status, func.count()).where(IdentityLink.tenant_id == tenant_id).group_by(IdentityLink.status)).all())
    rules = dict(session.execute(select(IdentityLink.match_rule, func.count()).where(IdentityLink.tenant_id == tenant_id, IdentityLink.status == "active")
                                 .group_by(IdentityLink.match_rule)).all())  # fmt: skip
    people = session.execute(select(func.count(func.distinct(IdentityLink.user_key))).where(IdentityLink.tenant_id == tenant_id, IdentityLink.status == "active")).scalar_one()
    open_candidates = session.execute(select(func.count()).select_from(IdentityMergeCandidate).where(IdentityMergeCandidate.tenant_id == tenant_id,
                                                                                                    IdentityMergeCandidate.status == "open")).scalar_one()  # fmt: skip
    entry = latest(session, tenant_id)
    return {"links_by_status": counts, "active_links_by_rule": rules, "people": people, "open_merge_candidates": open_candidates,
            "definition": {**feature_engine.DEFAULT_ACTIVITY, **(timeline.activity_definition(session, tenant_id) or {})},
            "definition_is_default": timeline.activity_definition(session, tenant_id) is None,
            "reconciliation": to_dict(entry) if entry is not None else None}  # fmt: skip


# ----------------------------------------------------------------------------- decisions by people
def _link(session: Session, tenant_id: int, link_id: int) -> IdentityLink:
    return get_owned(session, IdentityLink, tenant_id, link_id, label="Identity link")


def set_status(session: Session, principal: Principal, link_id: int, status: str, note: str | None = None) -> IdentityLink:
    """Quarantine a link (it counts for nobody), reject it for good, or put it back in force."""
    if status not in ("active", "quarantined", "rejected"):
        raise ValidationFailed("status must be active, quarantined or rejected", details={"field": "status"})
    link = _link(session, principal.tenant_id, link_id)
    if link.status == "merged":
        raise Conflict("this link was replaced by a merge; undo the merge instead")
    before, link.status, link.note, link.updated_at = link.status, status, note or link.note, utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.link_status_changed", entity_type="identity_link",
                 entity_id=link.id, detail={"from": before, "to": status, "note": note})  # fmt: skip
    return link


def merge(session: Session, principal: Principal, keep_key: str, merge_key: str, *, note: str | None = None, rule: str = "manual_merge") -> dict:
    """The person ``merge_key`` is the person ``keep_key``.  The old links stay on record as merged."""
    if keep_key == merge_key:
        raise ValidationFailed("a person cannot be merged with itself")
    links = session.execute(select(IdentityLink).where(IdentityLink.tenant_id == principal.tenant_id, IdentityLink.user_key == merge_key,
                                                       IdentityLink.status.in_(("active", "quarantined")))).scalars().all()  # fmt: skip
    if not links:
        raise NotFound("no link in force carries the key to merge")
    if session.execute(select(IdentityLink.id).where(IdentityLink.tenant_id == principal.tenant_id, IdentityLink.user_key == keep_key,
                                                     IdentityLink.status == "active").limit(1)).first() is None:  # fmt: skip
        raise NotFound("no active link carries the key to keep")
    now = utcnow()
    for link in links:
        session.add(IdentityLink(tenant_id=link.tenant_id, user_key=keep_key, source=link.source, external_user_id=link.external_user_id,
                                 customer_id=link.customer_id, account_id=link.account_id, crm_contact_id=link.crm_contact_id, email_hash=link.email_hash,
                                 confidence=1.0, match_rule=rule, status="active", valid_from=link.valid_from, valid_to=link.valid_to, note=note,
                                 created_by=principal.user_id))  # fmt: skip
        link.status, link.merged_into, link.updated_at = "merged", keep_key, now
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.people_merged", entity_type="identity_link",
                 entity_id=keep_key, detail={"kept": keep_key, "merged": merge_key, "links": len(links), "note": note})  # fmt: skip
    return {"kept": keep_key, "merged": merge_key, "links_moved": len(links)}


def unmerge(session: Session, principal: Principal, merged_key: str, *, note: str | None = None) -> dict:
    """Undo a merge: the replaced links come back and the links the merge created are removed."""
    old = session.execute(select(IdentityLink).where(IdentityLink.tenant_id == principal.tenant_id, IdentityLink.user_key == merged_key,
                                                     IdentityLink.status == "merged")).scalars().all()  # fmt: skip
    if not old:
        raise NotFound("nothing was merged away under this key")
    now, restored = utcnow(), 0
    for link in old:
        created = session.execute(select(IdentityLink).where(
            IdentityLink.tenant_id == principal.tenant_id, IdentityLink.user_key == link.merged_into, IdentityLink.external_user_id == link.external_user_id,
            IdentityLink.customer_id.is_(link.customer_id) if link.customer_id is None else IdentityLink.customer_id == link.customer_id,
            IdentityLink.match_rule.in_(("manual_merge", "candidate_merge")), IdentityLink.status == "active")).scalars().all()  # fmt: skip
        for replacement in created:  # the links the merge created go away again (the audit trail keeps what happened)
            session.delete(replacement)
        link.status, link.merged_into, link.updated_at = "active", None, now
        restored += 1
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.merge_undone", entity_type="identity_link",
                 entity_id=merged_key, detail={"restored": restored, "note": note})  # fmt: skip
    return {"restored": restored}


def review_candidate(session: Session, principal: Principal, candidate_id: int, *, merge_them: bool, note: str | None = None) -> IdentityMergeCandidate:
    candidate = get_owned(session, IdentityMergeCandidate, principal.tenant_id, candidate_id, label="Merge candidate")
    if candidate.status != "open":
        raise Conflict(f"this candidate was already decided ({candidate.status})")
    if merge_them:
        merge(session, principal, candidate.user_key_a, candidate.user_key_b, note=note or f"candidate {candidate.id}: {candidate.reason}", rule="candidate_merge")
    candidate.status, candidate.reviewed_by, candidate.reviewed_at, candidate.review_note = "merged" if merge_them else "rejected", principal.user_id, utcnow(), note
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.candidate_reviewed", entity_type="identity_merge_candidate",
                 entity_id=candidate.id, detail={"decision": candidate.status, "note": note})  # fmt: skip
    return candidate


def import_links(session: Session, principal: Principal, rows: list[dict]) -> dict:
    """A mapping supplied by the customer's identity system: ``{external_user_id, person_id, customer_external_id?,
    valid_from?, valid_to?}``.  Identifiers that share a person_id become one person."""
    if not rows or len(rows) > 50000:
        raise ValidationFailed("between 1 and 50,000 rows are required", details={"field": "rows"})
    customers = dict(session.execute(select(Customer.external_id, Customer.id).where(Customer.tenant_id == principal.tenant_id)).all())
    created, replaced, problems = 0, 0, []
    now = utcnow()
    for n, row in enumerate(rows, start=1):
        ref, person = feature_engine.normalise_ref(row.get("external_user_id")), str(row.get("person_id") or "").strip()
        if ref is None or not person:
            problems.append({"row": n, "problem": "external_user_id and person_id are required"})
            continue
        customer_id = None
        if row.get("customer_external_id") not in (None, ""):
            customer_id = customers.get(str(row["customer_external_id"]))
            if customer_id is None:
                problems.append({"row": n, "problem": f"unknown customer '{row['customer_external_id']}'"})
                continue
        elif not is_email(ref):
            problems.append({"row": n, "problem": "an identifier that is not an e-mail address needs customer_external_id (it names a person within one customer)"})
            continue
        try:
            start, end = _moment(row.get("valid_from")), _moment(row.get("valid_to"))
        except ValueError:
            problems.append({"row": n, "problem": "valid_from / valid_to must be ISO dates or date-times"})
            continue
        if start and end and end <= start:
            problems.append({"row": n, "problem": "valid_to must be after valid_from"})
            continue
        key = person_key(principal.tenant_id, person)
        same = IdentityLink.customer_id.is_(None) if customer_id is None else IdentityLink.customer_id == customer_id
        for old in session.execute(select(IdentityLink).where(IdentityLink.tenant_id == principal.tenant_id, IdentityLink.external_user_id == ref, same,
                                                              IdentityLink.status.in_(("active", "quarantined")))).scalars():  # fmt: skip
            if old.user_key == key and old.valid_from == start and old.valid_to == end:
                break
            if start is None and end is None:  # an unbounded imported link replaces what was derived before
                old.status, old.merged_into, old.updated_at = "merged", key, now
                replaced += 1
        else:
            session.add(IdentityLink(tenant_id=principal.tenant_id, user_key=key, source=SOURCE, external_user_id=ref, customer_id=customer_id,
                                     confidence=1.0, match_rule="import", status="active", valid_from=start, valid_to=end, created_by=principal.user_id))  # fmt: skip
            created += 1
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="identity.links_imported", entity_type="tenant",
                 entity_id=principal.tenant_id, detail={"rows": len(rows), "created": created, "replaced": replaced, "rejected_rows": len(problems)})  # fmt: skip
    return {"rows": len(rows), "created": created, "replaced": replaced, "problems": problems[:100], "rejected_rows": len(problems)}


def _moment(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=ZoneInfo("UTC"))


def links_query(tenant_id: int, *, status: str | None = None, q: str | None = None, customer_id: int | None = None, user_key_value: str | None = None):  # type: ignore[no-untyped-def]
    stmt = select(IdentityLink, Customer.external_id, Customer.name).outerjoin(Customer, Customer.id == IdentityLink.customer_id).where(IdentityLink.tenant_id == tenant_id)
    if status:
        stmt = stmt.where(IdentityLink.status == status)
    if customer_id:
        stmt = stmt.where(IdentityLink.customer_id == customer_id)
    if user_key_value:
        stmt = stmt.where(IdentityLink.user_key == user_key_value)
    if q:
        like = f"%{q.strip().casefold()}%"
        stmt = stmt.where(IdentityLink.external_user_id.like(like) | IdentityLink.user_key.like(like) | Customer.external_id.ilike(like))
    return stmt.order_by(IdentityLink.id.desc())


def link_row_view(row: Any) -> dict:
    link, external_id, name = row
    return to_dict(link, include={"customer_external_id": external_id, "customer_name": name})


def candidates(session: Session, tenant_id: int, status: str = "open") -> list[dict]:
    rows = session.execute(select(IdentityMergeCandidate).where(IdentityMergeCandidate.tenant_id == tenant_id, IdentityMergeCandidate.status == status)
                           .order_by(IdentityMergeCandidate.id.desc()).limit(200)).scalars().all()  # fmt: skip
    return [to_dict(c) for c in rows]
