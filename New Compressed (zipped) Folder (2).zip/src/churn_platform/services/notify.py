"""Outbound messages to customers: e-mail, SMS, push and in-app.

Nothing leaves the platform by default.  A provider starts in ``DRY_RUN``: the request that would be sent is built,
checked and stored, and the message ends in the state ``dry_run`` - which is never counted as sent or delivered
(the database refuses a dry-run message in a sent state).  ``SANDBOX`` calls the vendor's validation mode;
``LIVE`` additionally needs ``CHURN_NOTIFY_ALLOW_LIVE=true``.

Before anything is dispatched, in this order: the template must be approved; marketing needs the customer's
consent; the customer's own preferences; the suppression list (bounces, complaints, unsubscribes); frequency caps;
a usable recipient; a configured provider.  Each refusal is a final state of the message with its reason.

Recipients are stored encrypted, with a hash for suppression matching and a masked hint for people to read.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import smtplib
from datetime import UTC, datetime, timedelta
from typing import Any
from urllib.parse import quote
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import netguard
from ..config import get_settings
from ..db import session_scope, utcnow
from ..errors import Conflict, ExternalServiceError, Forbidden, NotFound, Unauthorized, ValidationFailed
from ..models import (
    Customer,
    NotificationEvent,
    NotificationMessage,
    NotificationPreference,
    NotificationProvider,
    NotificationSuppression,
    NotificationTemplate,
)
from ..security import Principal, SecretBox
from . import audit, jobs
from .common import get_owned, next_version, to_dict

CHANNELS = ("email", "sms", "push", "in_app")
PROVIDERS = {"email": ("sendgrid", "ses", "smtp"), "sms": ("twilio",), "push": ("fcm", "apns"), "in_app": ("inbox",)}
MODES = ("DRY_RUN", "SANDBOX", "LIVE")
VARIABLES = ("customer_name", "product_name", "offer_percent", "offer_code", "offer_valid_until", "card_expiry_date", "days_left", "payment_issue",
             "csm_name", "update_payment_url", "unsubscribe_url")  # fmt: skip
PLACEHOLDER = re.compile(r"\{\{\s*([a-z_]+)\s*\}\}")
EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE = re.compile(r"^\+[1-9]\d{6,14}$")
MAX_ATTEMPTS = 5
COUNTED = ("queued", "dry_run", "sent", "delivered")  # states that count towards a customer's frequency cap
_transport: httpx.BaseTransport | None = None  # tests put a fake vendor here


def set_transport(transport: httpx.BaseTransport | None) -> None:
    global _transport
    _transport = transport


# ----------------------------------------------------------------------------- recipients
def recipient_hash(channel: str, recipient: str) -> str:
    return hashlib.sha256(f"{channel}|{recipient.strip().lower()}".encode()).hexdigest()


def mask(channel: str, recipient: str) -> str:
    if channel == "email" and "@" in recipient:
        local, domain = recipient.split("@", 1)
        return f"{local[:1]}***@{domain}"
    if channel == "sms":
        return f"{recipient[:3]}***{recipient[-2:]}"
    return f"{recipient[:4]}***"


def recipient_for(customer: Customer, channel: str, explicit: str | None = None) -> tuple[str | None, str | None]:
    """``(recipient, why there is none)``."""
    value = (explicit or "").strip() or None
    if channel == "email":
        value = value or (customer.email or "").strip() or None
        if value is None:
            return None, "no e-mail address on record"
        return (value, None) if EMAIL.match(value) else (None, "the e-mail address on record is not valid")
    if channel == "sms":
        value = value or (customer.phone or "").strip() or None
        if value is None:
            return None, "no phone number on record"
        return (value, None) if PHONE.match(value) else (None, "the phone number on record is not in international format (+country number)")
    if channel == "push":
        return (value, None) if value else (None, "no device token: the product has to supply one for push messages")
    return customer.external_id, None  # in_app: addressed to the customer's account in the product


# ----------------------------------------------------------------------------- providers
def provider_view(provider: NotificationProvider) -> dict:
    view = to_dict(provider)
    view["has_credentials"] = bool(provider.credentials_enc)
    view["live_allowed_by_configuration"] = get_settings().notify_allow_live
    return view


def _provider_config(channel: str, provider: str, config: dict | None, credentials: dict | None) -> tuple[dict, dict]:
    config, credentials = dict(config or {}), dict(credentials or {})
    need_config = {"sendgrid": ("from_email",), "ses": ("from_email", "region"), "smtp": ("from_email", "host"), "twilio": ("account_sid",),
                   "fcm": ("project_id",), "apns": ("bundle_id", "team_id", "key_id"), "inbox": ()}[provider]  # fmt: skip
    missing = [k for k in need_config if not str(config.get(k) or "").strip()]
    if missing:
        raise ValidationFailed(f"the {provider} provider needs: {', '.join(missing)}", details={"field": "config"})
    if provider == "twilio" and not (config.get("from_number") or config.get("messaging_service_sid")):
        raise ValidationFailed("the twilio provider needs from_number or messaging_service_sid", details={"field": "config"})
    if config.get("from_email") and not EMAIL.match(str(config["from_email"])):
        raise ValidationFailed("from_email is not a valid address", details={"field": "config"})
    return config, credentials


def create_provider(session: Session, principal: Principal, *, name: str, channel: str, provider: str, config: dict | None = None,
                    credentials: dict | None = None, webhook_secret: str | None = None, is_default: bool = True) -> NotificationProvider:
    if channel not in CHANNELS or provider not in PROVIDERS.get(channel, ()):
        raise ValidationFailed(f"channel '{channel}' supports: {', '.join(PROVIDERS.get(channel, ())) or 'nothing'}", details={"field": "provider"})
    config, credentials = _provider_config(channel, provider, config, credentials)
    if session.execute(select(NotificationProvider.id).where(NotificationProvider.tenant_id == principal.tenant_id, NotificationProvider.name == name)).first():
        raise Conflict("a provider with this name already exists")
    entry = NotificationProvider(tenant_id=principal.tenant_id, name=name.strip(), channel=channel, provider=provider, mode="DRY_RUN", config=config,
                                 credentials_enc=SecretBox().encrypt(json.dumps(credentials)) if credentials else None,
                                 webhook_secret_enc=SecretBox().encrypt(webhook_secret) if webhook_secret else None, status="configured",
                                 is_default=False, created_by=principal.user_id)  # fmt: skip
    session.add(entry)
    session.flush()
    if is_default:
        _make_default(session, entry)
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="notify.provider_created", entity_type="notification_provider",
                 entity_id=entry.id, detail={"name": entry.name, "channel": channel, "provider": provider, "mode": "DRY_RUN"})  # fmt: skip
    return entry


def _make_default(session: Session, entry: NotificationProvider) -> None:
    for other in session.execute(select(NotificationProvider).where(NotificationProvider.tenant_id == entry.tenant_id,
                                                                    NotificationProvider.channel == entry.channel)).scalars():  # fmt: skip
        other.is_default = other.id == entry.id


def set_mode(session: Session, principal: Principal, provider_id: int, mode: str) -> NotificationProvider:
    """Change what a provider does with a message.  Leaving DRY_RUN needs credentials; LIVE needs the installation's
    permission as well and is audited."""
    entry = get_owned(session, NotificationProvider, principal.tenant_id, provider_id, label="Notification provider")
    if mode not in MODES:
        raise ValidationFailed(f"mode must be one of {', '.join(MODES)}", details={"field": "mode"})
    if mode != "DRY_RUN":
        # inbox needs none, and an SMTP relay may accept mail without authentication (a mail server that does
        # require it answers 530, which is recorded on the message).  Every vendor API needs a credential.
        if entry.provider not in ("inbox", "smtp") and not entry.credentials_enc:
            raise Conflict("this provider has no credentials; it can only run in DRY_RUN", code="credentials_missing")
        if entry.provider == "apns":
            raise Conflict("the Apple push service needs HTTP/2, which this build does not include; APNs can only run in DRY_RUN", code="not_supported")
    if mode == "LIVE" and not get_settings().notify_allow_live:
        raise Forbidden("live delivery is switched off for this installation (CHURN_NOTIFY_ALLOW_LIVE)", code="live_not_allowed")
    before, entry.mode = entry.mode, mode
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="notify.provider_mode_changed", entity_type="notification_provider",
                 entity_id=entry.id, detail={"from": before, "to": mode})  # fmt: skip
    return entry


def default_provider(session: Session, tenant_id: int, channel: str) -> NotificationProvider | None:
    return session.execute(select(NotificationProvider).where(NotificationProvider.tenant_id == tenant_id, NotificationProvider.channel == channel,
                                                              NotificationProvider.is_default.is_(True))).scalar_one_or_none()  # fmt: skip


# ----------------------------------------------------------------------------- templates
def template_view(template: NotificationTemplate) -> dict:
    return to_dict(template)


def variables_in(*texts: str | None) -> list[str]:
    return sorted({name for text in texts if text for name in PLACEHOLDER.findall(text)})


def create_template(session: Session, principal: Principal, *, code: str, channel: str, subject: str | None, body: str, category: str = "marketing",
                    locale: str = "en") -> NotificationTemplate:
    code = (code or "").strip().lower()
    if not re.match(r"^[a-z][a-z0-9_]{1,79}$", code):
        raise ValidationFailed("code must be lower-case letters, digits and underscores", details={"field": "code"})
    if channel not in CHANNELS:
        raise ValidationFailed(f"channel must be one of {', '.join(CHANNELS)}", details={"field": "channel"})
    if category not in ("marketing", "transactional"):
        raise ValidationFailed("category must be marketing or transactional", details={"field": "category"})
    if not (body or "").strip():
        raise ValidationFailed("a body is required", details={"field": "body"})
    if channel == "email" and not (subject or "").strip():
        raise ValidationFailed("an e-mail needs a subject", details={"field": "subject"})
    used = variables_in(subject, body)
    unknown = [name for name in used if name not in VARIABLES]
    if unknown:
        raise ValidationFailed(f"unknown placeholder(s): {', '.join(unknown)}. Available: {', '.join(VARIABLES)}", details={"field": "body"})
    if channel == "email" and category == "marketing" and "unsubscribe_url" not in used:
        raise ValidationFailed("a marketing e-mail must contain {{unsubscribe_url}}", details={"field": "body"})
    if channel == "sms" and len(body) > 480:
        raise ValidationFailed("a text message template may have at most 480 characters (three segments)", details={"field": "body"})
    version = next_version(session, NotificationTemplate, tenant_id=principal.tenant_id, code=code, channel=channel, locale=locale)
    template = NotificationTemplate(tenant_id=principal.tenant_id, code=code, version=version, channel=channel, locale=locale, category=category,
                                    subject=(subject or None), body=body, variables=used, status="draft", created_by=principal.user_id)  # fmt: skip
    session.add(template)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="notify.template_drafted", entity_type="notification_template",
                 entity_id=template.id, detail={"code": code, "channel": channel, "version": version})  # fmt: skip
    return template


def submit_template(session: Session, principal: Principal, template_id: int) -> NotificationTemplate:
    template = get_owned(session, NotificationTemplate, principal.tenant_id, template_id, label="Template")
    if template.status != "draft":
        raise Conflict(f"only a draft can be submitted (this version is {template.status})")
    template.status = "pending"
    return template


def review_template(session: Session, principal: Principal, template_id: int, *, approve: bool, note: str | None = None) -> NotificationTemplate:
    template = get_owned(session, NotificationTemplate, principal.tenant_id, template_id, label="Template")
    if template.status != "pending":
        raise Conflict(f"only a submitted version can be reviewed (this version is {template.status})")
    if template.created_by == principal.user_id and not get_settings().allow_self_approval:
        raise Forbidden("Four-eyes control: a message template cannot be reviewed by the person who wrote it", code="self_approval_forbidden")
    template.status, template.reviewed_by, template.reviewed_at, template.review_note = "approved" if approve else "rejected", principal.user_id, utcnow(), note
    if approve:  # one approved version per (code, channel, locale): the earlier one is retired
        for older in session.execute(select(NotificationTemplate).where(
                NotificationTemplate.tenant_id == template.tenant_id, NotificationTemplate.code == template.code, NotificationTemplate.channel == template.channel,
                NotificationTemplate.locale == template.locale, NotificationTemplate.status == "approved", NotificationTemplate.id != template.id)).scalars():  # fmt: skip
            older.status = "retired"
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="notify.template_approved" if approve else "notify.template_rejected",
                 entity_type="notification_template", entity_id=template.id, detail={"code": template.code, "version": template.version, "note": note})  # fmt: skip
    return template


def approved_template(session: Session, tenant_id: int, code: str, channel: str, locale: str = "en") -> NotificationTemplate | None:
    stmt = select(NotificationTemplate).where(NotificationTemplate.tenant_id == tenant_id, NotificationTemplate.code == code,
                                              NotificationTemplate.channel == channel, NotificationTemplate.status == "approved")  # fmt: skip
    rows = session.execute(stmt.order_by(NotificationTemplate.version.desc())).scalars().all()
    return next((t for t in rows if t.locale == locale), rows[0] if rows else None)


def render(template: NotificationTemplate, variables: dict) -> tuple[str | None, str]:
    missing = [name for name in (template.variables or []) if variables.get(name) in (None, "")]
    if missing:
        raise ValidationFailed(f"the template needs a value for: {', '.join(missing)}", details={"field": "variables"})
    fill = lambda text: PLACEHOLDER.sub(lambda m: str(variables[m.group(1)]), text)  # noqa: E731
    return (fill(template.subject) if template.subject else None), fill(template.body)


# ----------------------------------------------------------------------------- unsubscribe links
def _sign(payload: str) -> str:
    key = hashlib.sha256(b"churn-platform/unsubscribe/v1:" + get_settings().secret_key.get_secret_value().encode()).digest()
    return base64.urlsafe_b64encode(hmac.new(key, payload.encode(), hashlib.sha256).digest()[:18]).decode().rstrip("=")


def unsubscribe_token(tenant_id: int, customer_id: int, channel: str) -> str:
    payload = f"{tenant_id}.{customer_id}.{channel}"
    return f"{payload}.{_sign(payload)}"


def unsubscribe_url(tenant_id: int, customer_id: int, channel: str) -> str | None:
    base = get_settings().public_base_url
    return f"{base.rstrip('/')}/api/v1/notifications/unsubscribe?t={quote(unsubscribe_token(tenant_id, customer_id, channel))}" if base else None


def unsubscribe(session: Session, token: str) -> dict:
    """The link in a marketing message: stops marketing on that channel for that customer.  No sign-in needed."""
    try:
        tenant, customer, channel, signature = token.split(".")
        payload = f"{int(tenant)}.{int(customer)}.{channel}"
    except ValueError as exc:
        raise Unauthorized("this unsubscribe link is not valid", code="unsubscribe_invalid") from exc
    if channel not in CHANNELS or not hmac.compare_digest(signature, _sign(payload)):
        raise Unauthorized("this unsubscribe link is not valid", code="unsubscribe_invalid")
    row = session.get(Customer, int(customer))
    if row is None or row.tenant_id != int(tenant):
        raise Unauthorized("this unsubscribe link is not valid", code="unsubscribe_invalid")
    set_preference(session, row.tenant_id, row.id, channel, "marketing", False, source="unsubscribe link")
    recipient, _ = recipient_for(row, channel)
    if recipient:
        suppress(session, row.tenant_id, channel, recipient, reason="unsubscribe", source="unsubscribe link", customer_id=row.id)
    audit.record(session, tenant_id=row.tenant_id, action="notify.unsubscribed", actor_label="customer (unsubscribe link)", entity_type="customer",
                 entity_id=row.id, detail={"channel": channel})  # fmt: skip
    return {"unsubscribed": True, "channel": channel}


# ----------------------------------------------------------------------------- preferences and suppression
def set_preference(session: Session, tenant_id: int, customer_id: int, channel: str, category: str, allowed: bool, *, source: str) -> NotificationPreference:
    row = session.execute(select(NotificationPreference).where(NotificationPreference.customer_id == customer_id, NotificationPreference.channel == channel,
                                                               NotificationPreference.category == category)).scalar_one_or_none()  # fmt: skip
    if row is None:
        row = NotificationPreference(tenant_id=tenant_id, customer_id=customer_id, channel=channel, category=category)
        session.add(row)
    row.allowed, row.source, row.updated_at = allowed, source[:60], utcnow()
    session.flush()
    return row


def suppress(session: Session, tenant_id: int, channel: str, recipient: str, *, reason: str, source: str, customer_id: int | None = None,
             created_by: int | None = None) -> NotificationSuppression:
    digest = recipient_hash(channel, recipient)
    row = session.execute(select(NotificationSuppression).where(NotificationSuppression.tenant_id == tenant_id, NotificationSuppression.channel == channel,
                                                                NotificationSuppression.recipient_hash == digest)).scalar_one_or_none()  # fmt: skip
    if row is None:
        row = NotificationSuppression(tenant_id=tenant_id, channel=channel, recipient_hash=digest, recipient_hint=mask(channel, recipient),
                                      customer_id=customer_id, reason=reason, source=source[:60], created_by=created_by)  # fmt: skip
        session.add(row)
    else:
        row.reason, row.source, row.lifted_at = reason, source[:60], None
    session.flush()
    return row


def lift_suppression(session: Session, principal: Principal, suppression_id: int, note: str) -> NotificationSuppression:
    row = get_owned(session, NotificationSuppression, principal.tenant_id, suppression_id, label="Suppression")
    if row.reason in ("complaint", "unsubscribe"):
        raise Forbidden("a complaint or an unsubscribe is the customer's decision and cannot be lifted here", code="suppression_permanent")
    row.lifted_at = utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="notify.suppression_lifted", entity_type="notification_suppression",
                 entity_id=row.id, detail={"reason": row.reason, "note": note})  # fmt: skip
    return row


# ----------------------------------------------------------------------------- vendor requests
def build_request(provider: NotificationProvider, credentials: dict, *, recipient: str, subject: str | None, body: str, message_ref: str,
                  validate_only: bool) -> dict:
    """The HTTP request for one message, as the vendor's API expects it.  ``validate_only`` asks the vendor to check
    and not deliver (SANDBOX), where the vendor offers that."""
    config = provider.config or {}
    if provider.provider == "sendgrid":
        payload: dict[str, Any] = {"personalizations": [{"to": [{"email": recipient}], "custom_args": {"message_ref": message_ref}}],
                                   "from": {"email": config["from_email"], **({"name": config["from_name"]} if config.get("from_name") else {})},
                                   "subject": subject or "", "content": [{"type": "text/plain", "value": body}]}  # fmt: skip
        if validate_only:
            payload["mail_settings"] = {"sandbox_mode": {"enable": True}}
        return {"method": "POST", "url": "https://api.sendgrid.com/v3/mail/send", "json": payload,
                "headers": {"Authorization": f"Bearer {credentials.get('api_key', '')}"}, "ok": (200, 202)}  # fmt: skip
    if provider.provider == "smtp":
        # A mail submission server, over SMTP proper.  There is no vendor here to ask "is this valid?", so a
        # SANDBOX message is only taken as far as the handshake (EHLO/NOOP/QUIT) and never transmitted.
        host, port = str(config["host"]).strip(), int(config.get("port") or 2525)
        return {"method": "SMTP", "url": f"smtp://{host}:{port}",
                "json": {"to": recipient, "from": config["from_email"], "from_name": config.get("from_name") or None,
                         "subject": subject or "", "body": body, "message_ref": message_ref, "validate_only": validate_only},
                "headers": {}, "ok": (250,),
                "smtp": {"host": host, "port": port, "starttls": str(config.get("starttls") or "").lower() in ("1", "true", "yes", "on"),
                         "username": credentials.get("username") or None, "password": credentials.get("password") or None}}  # fmt: skip
    if provider.provider == "ses":
        to = "success@simulator.amazonses.com" if validate_only else recipient
        payload = {"FromEmailAddress": config["from_email"], "Destination": {"ToAddresses": [to]},
                   "Content": {"Simple": {"Subject": {"Data": subject or "", "Charset": "UTF-8"}, "Body": {"Text": {"Data": body, "Charset": "UTF-8"}}}},
                   "EmailTags": [{"Name": "message_ref", "Value": message_ref}]}  # fmt: skip
        url = f"https://email.{config['region']}.amazonaws.com/v2/email/outbound-emails"
        return {"method": "POST", "url": url, "json": payload, "headers": {}, "ok": (200,),
                "sigv4": {"region": config["region"], "service": "ses", "access_key": credentials.get("access_key_id", ""),
                          "secret_key": credentials.get("secret_access_key", "")}}  # fmt: skip
    if provider.provider == "twilio":
        form = {"To": recipient, "Body": body}
        form.update({"MessagingServiceSid": config["messaging_service_sid"]} if config.get("messaging_service_sid") else {"From": config["from_number"]})
        return {"method": "POST", "url": f"https://api.twilio.com/2010-04-01/Accounts/{config['account_sid']}/Messages.json", "form": form,
                "headers": {}, "basic_auth": (config["account_sid"], credentials.get("auth_token", "")), "ok": (200, 201)}  # fmt: skip
    if provider.provider == "fcm":
        payload = {"message": {"token": recipient, "notification": {"title": subject or config.get("default_title", ""), "body": body},
                               "data": {"message_ref": message_ref}}, **({"validate_only": True} if validate_only else {})}  # fmt: skip
        return {"method": "POST", "url": f"https://fcm.googleapis.com/v1/projects/{config['project_id']}/messages:send", "json": payload,
                "headers": {"Authorization": f"Bearer {credentials.get('access_token', '')}"}, "ok": (200,)}  # fmt: skip
    if provider.provider == "apns":
        host = "api.sandbox.push.apple.com" if validate_only else "api.push.apple.com"
        return {"method": "POST", "url": f"https://{host}/3/device/{recipient}", "json": {"aps": {"alert": {"title": subject or "", "body": body}}},
                "headers": {"apns-topic": config["bundle_id"], "apns-push-type": "alert", "apns-id": message_ref}, "ok": (200,), "http2": True}  # fmt: skip
    return {"method": "INTERNAL", "url": "in-app inbox", "json": {"customer": recipient, "title": subject, "body": body}, "headers": {}, "ok": ()}


def sigv4_headers(method: str, url: str, body: bytes, *, region: str, service: str, access_key: str, secret_key: str, now: datetime | None = None) -> dict[str, str]:
    """AWS Signature Version 4 for a JSON request (used for Amazon SES)."""
    from urllib.parse import urlsplit

    moment = (now or datetime.now(UTC)).strftime("%Y%m%dT%H%M%SZ")
    date_stamp, parts = moment[:8], urlsplit(url)
    payload_hash = hashlib.sha256(body).hexdigest()
    headers = {"content-type": "application/json", "host": parts.netloc, "x-amz-content-sha256": payload_hash, "x-amz-date": moment}
    signed = ";".join(sorted(headers))
    canonical = "\n".join([method, quote(parts.path or "/", safe="/-_.~"), parts.query, "".join(f"{k}:{headers[k]}\n" for k in sorted(headers)), signed, payload_hash])
    scope = f"{date_stamp}/{region}/{service}/aws4_request"
    to_sign = "\n".join(["AWS4-HMAC-SHA256", moment, scope, hashlib.sha256(canonical.encode()).hexdigest()])
    key = f"AWS4{secret_key}".encode()
    for part in (date_stamp, region, service, "aws4_request"):
        key = hmac.new(key, part.encode(), hashlib.sha256).digest()
    signature = hmac.new(key, to_sign.encode(), hashlib.sha256).hexdigest()
    return {"Content-Type": "application/json", "X-Amz-Date": moment, "X-Amz-Content-Sha256": payload_hash,
            "Authorization": f"AWS4-HMAC-SHA256 Credential={access_key}/{scope}, SignedHeaders={signed}, Signature={signature}"}  # fmt: skip


def redacted(request: dict) -> dict:
    """The request as it is stored: no credentials, and the recipient replaced by a marker."""
    out = {"method": request["method"], "url": re.sub(r"/device/[^/]+$", "/device/[RECIPIENT]", request["url"])}
    text = json.dumps(request.get("json") or request.get("form") or {})
    out["body_sha256"], out["body_bytes"] = hashlib.sha256(text.encode()).hexdigest(), len(text)
    out["headers"] = sorted(k for k in request.get("headers", {}) if k.lower() != "authorization")
    out["auth"] = "sigv4" if request.get("sigv4") else "basic" if request.get("basic_auth") else "bearer" if "Authorization" in request.get("headers", {}) else "none"
    return out


# ----------------------------------------------------------------------------- sending
def message_view(message: NotificationMessage) -> dict:
    return to_dict(message)


def quiet_hours(now: datetime) -> datetime | None:
    """If ``now`` falls inside the configured quiet window, the moment the window ends; otherwise None.

    ``CHURN_NOTIFY_QUIET_HOURS`` is ``HH:MM-HH:MM`` in ``CHURN_NOTIFY_QUIET_TIMEZONE``.  A window may wrap
    midnight (``21:00-08:00``).  Empty means the rule is off, and an unparsable value is reported rather than
    silently ignored: an installation that thinks it is quiet may not be.
    """
    settings = get_settings()
    window = (settings.notify_quiet_hours or "").strip()
    if not window:
        return None
    try:
        start_text, end_text = [part.strip() for part in window.split("-", 1)]
        start_h, start_m = (int(part) for part in start_text.split(":", 1))
        end_h, end_m = (int(part) for part in end_text.split(":", 1))
        if not (0 <= start_h <= 23 and 0 <= end_h <= 24 and 0 <= start_m <= 59 and 0 <= end_m <= 59):
            raise ValueError(window)
    except ValueError as exc:  # a misconfigured window must be loud, not a quiet no-op
        raise ValidationFailed(f"CHURN_NOTIFY_QUIET_HOURS must look like 21:00-08:00, not '{window}'", details={"field": "quiet_hours"}) from exc
    try:
        zone = ZoneInfo(settings.notify_quiet_timezone or "UTC")
    except ZoneInfoNotFoundError as exc:
        raise ValidationFailed(f"unknown time zone '{settings.notify_quiet_timezone}'", details={"field": "quiet_timezone"}) from exc
    local = now.astimezone(zone)
    start = local.replace(hour=start_h % 24, minute=start_m, second=0, microsecond=0)
    end = local.replace(hour=end_h % 24, minute=end_m, second=0, microsecond=0)
    if end <= start:  # the window wraps midnight
        if local >= start:
            end = end + timedelta(days=1)
        elif local < end:
            start = start - timedelta(days=1)
        else:
            return None
    if start <= local < end:
        return end.astimezone(UTC)
    return None


def _final(message: NotificationMessage, status: str, reason: str | None) -> NotificationMessage:
    message.status, message.status_reason = status, (reason or None) and reason[:200]
    return message


def send(session: Session, *, tenant_id: int, customer_id: int, channel: str, template_code: str, variables: dict | None = None,
         idempotency_key: str, recipient: str | None = None, campaign_id: int | None = None, enrollment_id: int | None = None,
         step_index: int | None = None, variant: str | None = None, created_by: int | None = None, locale: str = "en",
         dry_run: bool = False) -> NotificationMessage:
    """Create one message and take it as far as the rules allow.  Never raises for a refusal that concerns the
    customer (consent, suppression, caps ...): those are final states of the message.  ``dry_run`` keeps the
    message inside the platform whatever mode the provider is in."""
    existing = session.execute(select(NotificationMessage).where(NotificationMessage.tenant_id == tenant_id,
                                                                 NotificationMessage.idempotency_key == idempotency_key)).scalar_one_or_none()  # fmt: skip
    if existing is not None:
        return existing
    settings = get_settings()
    customer = session.get(Customer, customer_id)
    if customer is None or customer.tenant_id != tenant_id:
        raise NotFound("Customer not found")  # the same answer for a customer of another tenant and one that does not exist
    template = approved_template(session, tenant_id, template_code, channel, locale)
    if template is None:
        raise Conflict(f"there is no approved '{template_code}' template for {channel}", code="template_not_approved")
    provider = default_provider(session, tenant_id, channel)
    address, problem = recipient_for(customer, channel, recipient)
    values = {"customer_name": customer.name or customer.external_id, "product_name": "the product", **(variables or {})}
    rehearsal = dry_run or provider is None or provider.mode == "DRY_RUN"
    placeholder_link = False
    if "unsubscribe_url" in (template.variables or []) and not values.get("unsubscribe_url"):
        values["unsubscribe_url"] = unsubscribe_url(tenant_id, customer_id, channel)
        if values["unsubscribe_url"] is None and rehearsal:
            # a rehearsal may show its text without a public address; a real message may not go out without a working link
            values["unsubscribe_url"], placeholder_link = "https://public-address-not-set.invalid/unsubscribe", True
    message = NotificationMessage(tenant_id=tenant_id, customer_id=customer_id, channel=channel, provider_id=provider.id if provider else None,
                                  template_id=template.id, campaign_id=campaign_id, enrollment_id=enrollment_id, step_index=step_index, variant=variant,
                                  category=template.category, status="queued", is_dry_run=dry_run or provider is None or provider.mode == "DRY_RUN",
                                  idempotency_key=idempotency_key, attempts=0, created_by=created_by)  # fmt: skip
    if address:
        message.recipient_enc, message.recipient_hash, message.recipient_hint = SecretBox().encrypt(address), recipient_hash(channel, address), mask(channel, address)
    session.add(message)
    now = utcnow()
    # --- the rules, in order; the first one that refuses decides
    if template.category == "marketing" and customer.consent_marketing is not True:
        return _flush(session, _final(message, "blocked", "no marketing consent on record"))
    preference = session.execute(select(NotificationPreference.allowed).where(
        NotificationPreference.customer_id == customer_id, NotificationPreference.channel == channel,
        NotificationPreference.category == template.category)).scalar_one_or_none()  # fmt: skip
    if preference is False:
        return _flush(session, _final(message, "blocked", f"the customer opted out of {template.category} messages on this channel"))
    if address is None:
        return _flush(session, _final(message, "blocked", problem))
    suppressed = session.execute(select(NotificationSuppression.reason).where(
        NotificationSuppression.tenant_id == tenant_id, NotificationSuppression.channel == channel,
        NotificationSuppression.recipient_hash == message.recipient_hash, NotificationSuppression.lifted_at.is_(None))).scalar_one_or_none()  # fmt: skip
    if suppressed is not None:
        return _flush(session, _final(message, "suppressed", f"recipient is on the suppression list ({suppressed})"))
    if template.category == "marketing":
        for label, hours, limit in (("day", 24, settings.notify_max_per_customer_per_day), ("week", 168, settings.notify_max_per_customer_per_week)):
            recent = session.execute(select(func.count()).select_from(NotificationMessage).where(
                NotificationMessage.tenant_id == tenant_id, NotificationMessage.customer_id == customer_id, NotificationMessage.category == "marketing",
                NotificationMessage.status.in_(COUNTED), NotificationMessage.created_at >= now - timedelta(hours=hours),
                NotificationMessage.idempotency_key != idempotency_key)).scalar_one()  # fmt: skip
            if recent >= limit:
                return _flush(session, _final(message, "blocked", f"frequency cap: {recent} marketing message(s) in the last {label} (limit {limit})"))
    try:
        message.subject, message.body = render(template, values)
    except ValidationFailed as exc:
        reason = exc.message
        if "unsubscribe_url" in reason and not get_settings().public_base_url:
            reason = "no unsubscribe link can be built: CHURN_PUBLIC_BASE_URL is not set"
        return _flush(session, _final(message, "blocked", reason))
    if provider is None:
        return _flush(session, _final(message, "blocked", f"no {channel} provider is configured"))
    if template.category == "marketing" and provider.mode != "DRY_RUN" and not dry_run:
        resumes = quiet_hours(now)
        if resumes is not None:
            message.status, message.next_attempt_at = "queued", resumes
            message.status_reason = f"quiet hours: held until {resumes.isoformat(timespec='minutes')}"[:200]
            session.flush()
            jobs.enqueue(session, tenant_id=tenant_id, job_type="notify.deliver", payload={"message_id": message.id}, created_by=created_by,
                         run_after=resumes, idempotency_key=f"notify.deliver:{message.id}:quiet")  # fmt: skip
            return _flush(session, message)
    if provider.mode == "LIVE" and not settings.notify_allow_live:
        return _flush(session, _final(message, "blocked", "live delivery is switched off for this installation (CHURN_NOTIFY_ALLOW_LIVE)"))
    credentials = json.loads(SecretBox().decrypt(provider.credentials_enc)) if provider.credentials_enc else {}
    request = build_request(provider, credentials, recipient=address, subject=message.subject, body=message.body,
                            message_ref=idempotency_key[:64], validate_only=provider.mode == "SANDBOX")  # fmt: skip
    message.request = redacted(request)
    if provider.mode == "DRY_RUN" or dry_run:
        why = "the campaign is a rehearsal" if dry_run and provider.mode != "DRY_RUN" else "the provider is in DRY_RUN"
        note = " (the unsubscribe link is a placeholder: CHURN_PUBLIC_BASE_URL is not set)" if placeholder_link else ""
        return _flush(session, _final(message, "dry_run", f"{why}: the request was built and checked; nothing was sent{note}"))
    session.flush()
    if provider.provider == "inbox":
        message.status, message.sent_at = "sent", now  # available to the product; "delivered" once the product shows it
        return _flush(session, message)
    jobs.enqueue(session, tenant_id=tenant_id, job_type="notify.deliver", payload={"message_id": message.id}, created_by=created_by,
                 idempotency_key=f"notify.deliver:{message.id}:0")  # fmt: skip
    return message


def _flush(session: Session, message: NotificationMessage) -> NotificationMessage:
    session.flush()
    return message


class SmtpResponse:
    """What a mail server's answer looks like to the code that records an outcome (the shape of an httpx response)."""

    def __init__(self, code: int, message_id: str | None, text: str) -> None:
        self.status_code, self.text, self.content = code, text, b""
        self.headers = {"X-Message-Id": message_id} if message_id else {}

    def json(self) -> Any:
        raise ValueError("an SMTP answer is not JSON")


def _smtp_call(request: dict) -> SmtpResponse:
    """Speak SMTP to the mail server: EHLO, optional STARTTLS and AUTH, one message, QUIT.

    The mail server's address is checked the way the HTTP providers' URLs are (``netguard``): a
    name that resolves to a private, loopback or link-local address is refused unless
    ``CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS`` says otherwise, which is what a relay on the same machine
    needs.  Without STARTTLS the connection is made to the address that was checked; with it the
    name is used again, because the certificate is verified against the name.
    """
    import smtplib
    from email.message import EmailMessage
    from email.utils import formatdate, make_msgid

    config, body = request["smtp"], request["json"]
    message = EmailMessage()
    name = body.get("from_name")
    message["From"] = f"{name} <{body['from']}>" if name else body["from"]
    message["To"] = body["to"]
    message["Subject"] = body["subject"]
    message["Date"] = formatdate(localtime=False)
    message["Message-ID"] = make_msgid(idstring=(body.get("message_ref") or "")[:40] or None)
    message["X-Churn-Message-Ref"] = body.get("message_ref") or ""
    message.set_content(body["body"])
    settings = get_settings()
    vetted, address = netguard.vet_host(
        config["host"], config.get("port"), allow_private=settings.notify_allow_private_hosts, field_name="smtp host"
    )
    where = vetted if config.get("starttls") else address
    with smtplib.SMTP(where, config["port"], timeout=settings.notify_http_timeout_seconds) as server:
        code, hello = server.ehlo()
        if code >= 400:
            raise ExternalServiceError(f"the mail server refused the greeting: {hello.decode(errors='replace')[:200]}")
        if config.get("starttls"):
            server.starttls()
            server.ehlo()
        if config.get("username"):
            server.login(config["username"], config.get("password") or "")
        if body.get("validate_only"):
            code, answer = server.noop()  # the handshake worked; the message itself is not transmitted
            return SmtpResponse(int(code), None, f"SANDBOX: {answer.decode(errors='replace')[:200]}")
        refused = server.send_message(message)
        if refused:
            raise ExternalServiceError(f"the mail server refused these recipients: {', '.join(sorted(refused))[:200]}")
        server.quit()
    return SmtpResponse(250, message["Message-ID"], "accepted")


def _call(request: dict) -> Any:
    if request.get("method") == "SMTP":
        return _smtp_call(request)
    settings = get_settings()
    target = netguard.vet(request["url"], allow_private=settings.notify_allow_private_hosts, field_name="provider url", resolve=_transport is None)
    headers = {**request.get("headers", {}), **target.headers}
    content = None
    if request.get("sigv4"):
        content = json.dumps(request["json"]).encode()
        headers.update(sigv4_headers("POST", request["url"], content, **request["sigv4"]))
    with httpx.Client(timeout=settings.notify_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
        if content is not None:
            return client.post(target.url, content=content, headers=headers, extensions=target.extensions)
        if request.get("form") is not None:
            return client.post(target.url, data=request["form"], headers=headers, auth=request.get("basic_auth"), extensions=target.extensions)
        return client.post(target.url, json=request["json"], headers=headers, extensions=target.extensions)


def deliver(message_id: int, ctx: Any = None) -> dict:
    """Send one queued message to its vendor (SANDBOX or LIVE).  Temporary failures are retried with a growing
    delay; a refusal by the vendor is final."""
    with session_scope() as ws:
        message = ws.get(NotificationMessage, message_id)
        if message is None:
            raise jobs.PermanentJobError(f"message {message_id} does not exist")
        if message.status != "queued":
            return {"status": message.status, "skipped": "already handled"}
        provider = ws.get(NotificationProvider, message.provider_id)
        if provider is None or provider.mode == "DRY_RUN" or message.is_dry_run:
            _final(message, "dry_run" if message.is_dry_run else "blocked", "the provider was switched to DRY_RUN before this message was sent")
            return {"status": message.status}
        if provider.mode == "LIVE" and not get_settings().notify_allow_live:
            _final(message, "blocked", "live delivery is switched off for this installation (CHURN_NOTIFY_ALLOW_LIVE)")
            return {"status": "blocked"}
        credentials = json.loads(SecretBox().decrypt(provider.credentials_enc)) if provider.credentials_enc else {}
        request = build_request(provider, credentials, recipient=SecretBox().decrypt(message.recipient_enc), subject=message.subject, body=message.body,
                                message_ref=message.idempotency_key[:64], validate_only=provider.mode == "SANDBOX")  # fmt: skip
        message.attempts += 1
        attempts, tenant_id, validate_only, vendor = message.attempts, message.tenant_id, provider.mode == "SANDBOX", provider.provider
    outcome: dict[str, Any]
    try:
        if request.get("http2"):
            raise ExternalServiceError("the Apple push service needs HTTP/2, which this build does not include")
        response = _call(request)
        retryable = response.status_code in (408, 425, 429, 500, 502, 503, 504)
        try:
            body = response.json()
        except ValueError:
            body = {}
        external = response.headers.get("X-Message-Id") or (body.get("sid") or body.get("MessageId") or body.get("name") if isinstance(body, dict) else None)
        outcome = {"http_status": response.status_code, "ok": response.status_code in request["ok"], "retryable": retryable, "external_id": external,
                   "error": None if response.status_code in request["ok"] else json.dumps(body)[:300] if body else response.text[:300]}  # fmt: skip
    except (httpx.HTTPError, smtplib.SMTPException, OSError, ExternalServiceError, ValidationFailed) as exc:
        outcome = {"http_status": None, "ok": False, "retryable": isinstance(exc, (httpx.HTTPError, smtplib.SMTPException, OSError)),
                   "external_id": None, "error": f"{type(exc).__name__}: {getattr(exc, 'message', exc)}"[:300]}  # fmt: skip
    with session_scope() as ws:
        message = ws.get(NotificationMessage, message_id)
        message.response = {k: outcome[k] for k in ("http_status", "error", "retryable")}
        if outcome["ok"]:
            message.status, message.sent_at, message.provider_message_id = "sent", utcnow(), outcome["external_id"]
            message.status_reason = "accepted by the vendor's validation mode; nothing was delivered" if validate_only else None
        elif outcome["retryable"] and attempts < MAX_ATTEMPTS:
            delay = min(3600, 30 * 2 ** (attempts - 1))
            message.next_attempt_at = utcnow() + timedelta(seconds=delay)
            jobs.enqueue(ws, tenant_id=tenant_id, job_type="notify.deliver", payload={"message_id": message_id}, run_after=message.next_attempt_at,
                         idempotency_key=f"notify.deliver:{message_id}:{attempts}")  # fmt: skip
        else:
            _final(message, "failed", outcome["error"] or f"{vendor} answered HTTP {outcome['http_status']}")
        return {"status": message.status, "attempts": attempts, "http_status": outcome["http_status"]}


# ----------------------------------------------------------------------------- vendor events (delivery, bounce, complaint ...)
EVENT_STATUS = {"delivered": "delivered", "bounce": "bounced", "bounced": "bounced", "complaint": "complained", "spamreport": "complained",
                "dropped": "failed", "failed": "failed", "undelivered": "failed"}  # fmt: skip


def receive_events(session: Session, provider_id: int, body: bytes, signature: str | None) -> dict:
    """Signed event webhook: ``X-Signature: sha256=<hex HMAC of the raw body>``.  Accepts a JSON list of
    ``{id, type, message_ref | provider_message_id, recipient?}``; each event is applied once."""
    provider = session.get(NotificationProvider, provider_id)
    if provider is None or not provider.webhook_secret_enc:
        raise Unauthorized("unknown webhook", code="webhook_unknown")
    expected = hmac.new(SecretBox().decrypt(provider.webhook_secret_enc).encode(), body, hashlib.sha256).hexdigest()
    if not signature or not hmac.compare_digest(signature.removeprefix("sha256=").strip(), expected):
        raise Unauthorized("the signature of this webhook is not valid", code="webhook_signature_invalid")
    try:
        events = json.loads(body)
        events = events if isinstance(events, list) else [events]
    except ValueError as exc:
        raise ValidationFailed("the webhook body is not JSON") from exc
    applied = duplicates = unmatched = 0
    for event in events[:1000]:
        if not isinstance(event, dict) or not event.get("id") or not event.get("type"):
            unmatched += 1
            continue
        key, kind = str(event["id"])[:200], str(event["type"]).lower()
        if session.execute(select(NotificationEvent.id).where(NotificationEvent.tenant_id == provider.tenant_id, NotificationEvent.provider_id == provider.id,
                                                              NotificationEvent.event_key == key)).first():  # fmt: skip
            duplicates += 1
            continue
        message = None
        if event.get("message_ref"):
            message = session.execute(select(NotificationMessage).where(NotificationMessage.tenant_id == provider.tenant_id,
                                                                        NotificationMessage.idempotency_key == str(event["message_ref"]))).scalar_one_or_none()  # fmt: skip
        if message is None and event.get("provider_message_id"):
            message = session.execute(select(NotificationMessage).where(NotificationMessage.tenant_id == provider.tenant_id,
                                                                        NotificationMessage.provider_message_id == str(event["provider_message_id"]))).scalars().first()  # fmt: skip
        session.add(NotificationEvent(tenant_id=provider.tenant_id, provider_id=provider.id, message_id=message.id if message else None, event_type=kind[:30],
                                      event_key=key, payload={k: v for k, v in event.items() if k != "recipient"}))  # fmt: skip
        if message is None:
            unmatched += 1
            continue
        applied += 1
        if kind in EVENT_STATUS and not message.is_dry_run and message.status in ("sent", "delivered"):
            message.status = EVENT_STATUS[kind]
            if kind == "delivered":
                message.delivered_at = utcnow()
        if kind in ("bounce", "bounced", "complaint", "spamreport", "unsubscribe") and message.recipient_enc:
            reason = "bounce" if kind.startswith("bounce") else "unsubscribe" if kind == "unsubscribe" else "complaint"
            suppress(session, provider.tenant_id, message.channel, SecretBox().decrypt(message.recipient_enc), reason=reason, source=f"{provider.provider} event",
                     customer_id=message.customer_id)  # fmt: skip
            if reason != "bounce" and message.customer_id:
                set_preference(session, provider.tenant_id, message.customer_id, message.channel, "marketing", False, source=f"{provider.provider} {reason}")
    return {"received": len(events), "applied": applied, "duplicates": duplicates, "unmatched": unmatched}


def mark_read(session: Session, tenant_id: int, message_id: int) -> NotificationMessage:
    """The product reports that an in-app message was shown."""
    message = get_owned(session, NotificationMessage, tenant_id, message_id, label="Message")
    if message.channel != "in_app" or message.is_dry_run or message.status not in ("sent", "delivered"):
        raise Conflict("only an in-app message that was really sent can be marked as read")
    message.status, message.delivered_at, message.read_at = "delivered", message.delivered_at or utcnow(), utcnow()
    return message


# ----------------------------------------------------------------------------- reading
def overview(session: Session, tenant_id: int, days: int = 30) -> dict:
    since = utcnow() - timedelta(days=days)
    rows = session.execute(select(NotificationMessage.channel, NotificationMessage.status, func.count()).where(
        NotificationMessage.tenant_id == tenant_id, NotificationMessage.created_at >= since).group_by(NotificationMessage.channel, NotificationMessage.status)).all()  # fmt: skip
    by_status: dict[str, int] = {}
    by_channel: dict[str, dict[str, int]] = {}
    for channel, status, count in rows:
        by_status[status] = by_status.get(status, 0) + count
        by_channel.setdefault(channel, {})[status] = count
    reasons = session.execute(select(NotificationMessage.status_reason, func.count()).where(
        NotificationMessage.tenant_id == tenant_id, NotificationMessage.created_at >= since, NotificationMessage.status.in_(("blocked", "suppressed", "failed")))
        .group_by(NotificationMessage.status_reason).order_by(func.count().desc()).limit(10)).all()  # fmt: skip
    providers = session.execute(select(NotificationProvider).where(NotificationProvider.tenant_id == tenant_id).order_by(NotificationProvider.channel)).scalars().all()
    suppressions = dict(session.execute(select(NotificationSuppression.reason, func.count()).where(
        NotificationSuppression.tenant_id == tenant_id, NotificationSuppression.lifted_at.is_(None)).group_by(NotificationSuppression.reason)).all())  # fmt: skip
    really_sent = by_status.get("sent", 0) + by_status.get("delivered", 0) + by_status.get("bounced", 0) + by_status.get("complained", 0)
    return {
        "window_days": days, "by_status": by_status, "by_channel": by_channel, "really_sent": really_sent, "dry_run": by_status.get("dry_run", 0),
        "not_sent_reasons": [{"reason": reason, "messages": count} for reason, count in reasons],
        "providers": [provider_view(p) for p in providers], "suppressions": suppressions,
        "live_allowed_by_configuration": get_settings().notify_allow_live, "public_base_url_set": bool(get_settings().public_base_url),
        "caps": {"marketing_per_customer_per_day": get_settings().notify_max_per_customer_per_day,
                 "marketing_per_customer_per_week": get_settings().notify_max_per_customer_per_week},
        "note": "A dry-run message was built and checked and went nowhere; it is never counted as sent or delivered.",
    }  # fmt: skip


def messages_query(tenant_id: int, *, status: str | None = None, channel: str | None = None, campaign_id: int | None = None,
                   customer_id: int | None = None):  # type: ignore[no-untyped-def]
    stmt = (select(NotificationMessage, Customer.external_id, Customer.name).outerjoin(Customer, Customer.id == NotificationMessage.customer_id)
            .where(NotificationMessage.tenant_id == tenant_id))  # fmt: skip
    for column, value in ((NotificationMessage.status, status), (NotificationMessage.channel, channel), (NotificationMessage.campaign_id, campaign_id),
                          (NotificationMessage.customer_id, customer_id)):  # fmt: skip
        if value:
            stmt = stmt.where(column == value)
    return stmt.order_by(NotificationMessage.id.desc())


def message_row_view(row: Any) -> dict:
    message, external_id, name = row
    return to_dict(message, include={"customer_external_id": external_id, "customer_name": name})
