"""Rate limits that every server process shares.

Counters live in the database (``rate_limit_counters``): one row per (bucket, subject, minute).  A hit is a single
atomic upsert in its own short transaction, so two processes can never both believe they are under the limit -
which the per-process limiter of 1.0 allowed.

If the counter store cannot be reached the limiter does not silently switch itself off: depending on
``CHURN_RATE_LIMIT_STORE_FAILURE`` it either falls back to a per-process count (``local``, the default) or refuses
the request (``deny``).  Either way the failure is logged.
"""

from __future__ import annotations

import logging
import random
import threading
import time
from collections import defaultdict
from dataclasses import dataclass

from sqlalchemy import delete, text

from ..config import get_settings
from ..db import get_engine
from ..errors import RateLimited, ServiceUnavailable
from ..models import RateLimitCounter

log = logging.getLogger("churn.ratelimit")
WINDOW_SECONDS = 60
_local: dict[tuple[str, str, int], int] = defaultdict(int)
_local_lock = threading.Lock()
_UPSERT = text(
    "INSERT INTO rate_limit_counters (bucket, subject, window_start, hits) VALUES (:bucket, :subject, :window, 1) "
    "ON CONFLICT (bucket, subject, window_start) DO UPDATE SET hits = rate_limit_counters.hits + 1 RETURNING hits"
)


@dataclass(frozen=True)
class Verdict:
    allowed: bool
    limit: int
    hits: int
    retry_after: int
    store: str  # shared | local

    @property
    def remaining(self) -> int:
        return max(0, self.limit - self.hits)

    def headers(self) -> dict[str, str]:
        out = {"X-RateLimit-Limit": str(self.limit), "X-RateLimit-Remaining": str(self.remaining)}
        if not self.allowed:
            out["Retry-After"] = str(self.retry_after)
        return out


def _count_local(bucket: str, subject: str, window: int) -> int:
    with _local_lock:
        for key in [k for k in _local if k[2] < window - 1]:
            del _local[key]
        _local[(bucket, subject, window)] += 1
        return _local[(bucket, subject, window)]


def hit(bucket: str, subject: str, limit: int, *, now: float | None = None) -> Verdict:
    """Count one request and say whether it is within ``limit`` per minute."""
    settings = get_settings()
    moment = time.time() if now is None else now
    window = int(moment // WINDOW_SECONDS)
    retry_after = max(1, int((window + 1) * WINDOW_SECONDS - moment) + 1)
    subject = (subject or "unknown")[:200]
    if not settings.rate_limit_enabled or limit <= 0:
        return Verdict(True, limit, 0, 0, "off")
    try:
        with get_engine().begin() as connection:
            hits = int(connection.execute(_UPSERT, {"bucket": bucket, "subject": subject, "window": window}).scalar_one())
            # now and then old counters are tidied away; nothing security-relevant depends on this draw
            if random.random() < 0.01:  # nosec B311
                connection.execute(delete(RateLimitCounter).where(RateLimitCounter.window_start < window - 10))
        store = "shared"
    except Exception as exc:
        log.warning("rate-limit store unavailable", extra={"ctx": {"bucket": bucket, "error": f"{type(exc).__name__}: {exc}"[:200],
                                                                    "policy": settings.rate_limit_store_failure}})  # fmt: skip
        if settings.rate_limit_store_failure == "deny":
            raise ServiceUnavailable("The request limiter is unavailable; try again shortly", code="rate_limiter_unavailable") from exc
        hits, store = _count_local(bucket, subject, window), "local"
    return Verdict(hits <= limit, limit, hits, retry_after, store)


def enforce(bucket: str, subject: str, limit: int, message: str = "Too many requests; wait a minute and try again") -> Verdict:
    verdict = hit(bucket, subject, limit)
    if not verdict.allowed:
        raise RateLimited(message, details={"retry_after_seconds": verdict.retry_after, "limit_per_minute": limit, "bucket": bucket})
    return verdict


def reset_local() -> None:
    with _local_lock:
        _local.clear()


def snapshot(limit: int = 50, *, subject_prefix: str = "") -> list[dict]:
    """The busiest counters of the current minute, optionally those whose subject starts with ``subject_prefix``.

    The counters belong to the installation, not to a tenant: subjects are addresses, account names and user ids of
    every tenant.  Whatever is shown to a tenant has to be filtered by the caller (see the security overview)."""
    window = int(time.time() // WINDOW_SECONDS)
    with get_engine().connect() as connection:
        rows = connection.execute(text("SELECT bucket, subject, hits FROM rate_limit_counters WHERE window_start = :w AND subject LIKE :p "
                                       "ORDER BY hits DESC, bucket, subject LIMIT :n"),
                                  {"w": window, "p": subject_prefix.replace("%", "") + "%", "n": limit}).all()  # fmt: skip
    return [{"bucket": bucket, "subject": subject, "hits": hits} for bucket, subject, hits in rows]
