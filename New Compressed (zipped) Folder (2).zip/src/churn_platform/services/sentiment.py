"""Sentiment of support text.

What is here
  * a provider abstraction with two implementations: a **local transformer** (ONNX runtime, multilingual, weights
    pinned by revision and SHA-256) and a **word-list baseline** that exists only as a fallback and is labelled as
    a baseline wherever its results appear - it is never presented as a trained model;
  * text preparation shared by every provider: Unicode normalisation, PII redaction, language detection, length
    limits, duplicate detection;
  * labels ``positive | negative | neutral | mixed`` plus ``uncertain``, with a confidence, the detected language
    and an explicit state for everything that could not be scored (empty, too short, unsupported language ...);
  * storage of one score per interaction and model, with the model's identity and checksum, so that point-in-time
    features can read them through the interaction's own timestamp.

Inference is local.  No support text is sent to any external service: the only network access in this module is
``fetch_model``, which downloads the pinned weights and is run by an operator (``churn-platform sentiment-model``).

Accuracy.  The decision thresholds below were set on the SYNTHETIC templates shipped with the platform.  How well
any of this agrees with human judgement on real support text is unknown until a labelled sample of that text has
been evaluated (``evaluate``); until then production accuracy is reported as BLOCKED.
"""

from __future__ import annotations

import hashlib
import json
import re
import threading
import unicodedata
from dataclasses import dataclass, field
from datetime import timedelta
from pathlib import Path
from typing import Any, Protocol

import numpy as np
from sqlalchemy import case, func, select, update
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import Customer, SentimentEvaluation, SentimentModel, SentimentRun, SentimentScore, SupportInteraction
from ..security import Principal
from . import audit, jobs
from .common import get_owned, to_dict

LABELS = ("positive", "negative", "neutral", "mixed", "uncertain")
MIN_CHARS = 3
CHUNK = 2000
MAX_TOKENS = 256

# Models that can be fetched.  Every file is pinned by size and SHA-256 at one upstream revision; a download that
# does not match is rejected, and a model directory that does not match is not loaded.
PINS: dict[str, dict[str, Any]] = {
    "nlptown-multilingual": {
        "model_id": "nlptown/bert-base-multilingual-uncased-sentiment",
        "onnx_repo": "Xenova/bert-base-multilingual-uncased-sentiment",
        "revision": "fad9b372f770c208d2efaf00d02f2cb3b61ec450",
        "license": "mit",
        "tokenizer": "BertTokenizer (WordPiece, uncased), tokenizer.json",
        "languages": ["en", "nl", "de", "fr", "it", "es"],
        "trained_on": "product reviews with 1-5 star ratings (upstream model card)",
        "classes": {"negative": [0, 1], "neutral": [2], "positive": [3, 4]},
        "thresholds": {"polar": 0.8, "neutral": 0.5},
        "weights": "onnx/model_quantized.onnx",
        "files": {
            "config.json": (1152, "b27932c748cc010fb94185879253a7c708fc627e7dafa2b24e07e827e8421a33"),
            "tokenizer.json": (2563370, "11aaf894a4ccf3d95e8830e27c0f8152791fbbff2b988e29a265580b86edd216"),
            "tokenizer_config.json": (384, "31cc1c3fbb5d585524b26713d9cf2e0c7578a0a2298b7644f1db3008b0809516"),
            "special_tokens_map.json": (125, "b6d346be366a7d1d48332dbc9fdf3bf8960b5d879522b7799ddba59e76237ee3"),
            "onnx/model_quantized.onnx": (168593695, "aefeb9b1f7e84d525d0a91f9f06d0d12bb7270186194a421436b728d6be55643"),
        },
    },
    "distilbert-student-multilingual": {
        "model_id": "lxyuan/distilbert-base-multilingual-cased-sentiments-student",
        "onnx_repo": "Xenova/distilbert-base-multilingual-cased-sentiments-student",
        "revision": "9d9ac661fd7b0b48535a1fc99b20ae6947629e65",
        "license": "apache-2.0",
        "tokenizer": "DistilBertTokenizer (WordPiece, cased), tokenizer.json",
        "languages": ["en", "ar", "de", "es", "fr", "ja", "zh", "id", "hi", "it", "ms", "pt"],
        "trained_on": "distilled from a zero-shot classifier on a multilingual sentiment set (upstream model card)",
        "classes": {"positive": [0], "neutral": [1], "negative": [2]},
        "thresholds": {"polar": 0.4, "neutral": 0.2},
        "weights": "onnx/model_quantized.onnx",
        "files": {
            "config.json": (757, "89c0158e3725d30d852258638c64057228ff93d676f2c3e22ac20025a89653c7"),
            "tokenizer.json": (2919615, "a4a4fa4b10a2a40361529954532f10257fda53cb22177554a862bcc661b7e4d8"),
            "tokenizer_config.json": (1440, "98732e4b2ce5619be1756f51eb32fd7fe56fd4060843fbd900cbe23cbce664c9"),
            "special_tokens_map.json": (695, "5d5b662e421ea9fac075174bb0688ee0d9431699900b90662acd44b2a350503a"),
            "onnx/model_quantized.onnx": (135953840, "9570fdd726d952dbaf559ba0b9f38a523554f08a8038d62d9263a90dcbb3cd3e"),
        },
    },
}
DEFAULT_PIN = "nlptown-multilingual"
HUB = "https://huggingface.co"

# The fallback word lists (English).  Stems, matched as substrings of lower-cased text.
BASELINE_NEGATIVE = ("frustrat", "broken", "unacceptable", "slow", "unreliable", "disappoint", "alternativ", "fail", "cancel", "refund",
                     "terrible", "angry", "worst", "useless", "bug", "outage", "not fixed", "unhappy", "annoy", "poor")  # fmt: skip
BASELINE_POSITIVE = ("thank", "great", "love", "appreciate", "excellent", "perfect", "happy", "helpful", "works well", "awesome",
                     "fantastic", "pleased", "wonderful", "solved", "saves")  # fmt: skip


# ----------------------------------------------------------------------------- text preparation
_CONTROL = re.compile(r"[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f\u200b-\u200f\u2028\u2029\ufeff]")
_SPACE = re.compile(r"\s+")
_REDACTIONS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("url", re.compile(r"(?i)\b(?:https?://|www\.)\S+")),
    ("email", re.compile(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+")),
    ("iban", re.compile(r"\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){2,7}(?:\s?[A-Z0-9]{1,4})?\b")),
    ("card", re.compile(r"(?<![\w.])\d(?:[ -]?\d){12,18}(?!\w|\.\d)")),
    ("ip", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("phone", re.compile(r"(?<![\w.])\+?\d[\d\s().-]{6,}\d(?!\w|\.\d)")),
)
_PLACEHOLDER = re.compile(r"\[(?:URL|EMAIL|IBAN|CARD|IP|PHONE)\]")
_CLAUSE = re.compile(
    r"(?<=[.!?।…])\s+|\s*[;\n]\s*|,?\s+(?:but|however|although|aber|jedoch|allerdings|mais|cependant|pero|sin embargo|ma|però|maar|"
    r"लेकिन|परंतु)\s+",
    re.IGNORECASE,
)


def normalise(text: str | None) -> str:
    """NFKC, control characters removed, whitespace collapsed."""
    if not text:
        return ""
    return _SPACE.sub(" ", _CONTROL.sub(" ", unicodedata.normalize("NFKC", str(text)))).strip()


def _luhn(digits: str) -> bool:
    total, double = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if double:
            d = d * 2 - 9 if d > 4 else d * 2
        total, double = total + d, not double
    return total % 10 == 0


def redact_pii(text: str) -> tuple[str, dict[str, int]]:
    """Replace personal identifiers by placeholders.  Returns the redacted text and how many of each kind."""
    counts: dict[str, int] = {}

    def sub(kind: str, pattern: re.Pattern[str], value: str) -> str:
        def replace(match: re.Match[str]) -> str:
            found = match.group(0)
            digits = re.sub(r"\D", "", found)
            if kind == "card" and not (13 <= len(digits) <= 19 and _luhn(digits)):
                return found
            if kind == "phone" and not 8 <= len(digits) <= 15:  # E.164 numbers have at most 15 digits
                return found
            counts[kind] = counts.get(kind, 0) + 1
            return f"[{kind.upper()}]"

        return pattern.sub(replace, value)

    for kind, pattern in _REDACTIONS:
        text = sub(kind, pattern, text)
    return text, counts


def text_key(clean: str) -> str:
    return hashlib.sha256(clean.casefold().encode()).hexdigest()


def clauses(clean: str) -> list[str]:
    parts = [p.strip(" ,") for p in _CLAUSE.split(clean) if p and p.strip(" ,")]
    return [p for p in parts if len(p) >= 8]


# ----------------------------------------------------------------------------- language detection
_SCRIPTS = (("hi", 0x0900, 0x097F), ("ar", 0x0600, 0x06FF), ("ru", 0x0400, 0x04FF), ("el", 0x0370, 0x03FF), ("he", 0x0590, 0x05FF),
            ("th", 0x0E00, 0x0E7F), ("ko", 0xAC00, 0xD7AF), ("ja", 0x3040, 0x30FF), ("zh", 0x4E00, 0x9FFF))  # fmt: skip
# A few very common words per language: enough to tell the supported Latin-script languages apart in short texts.
_STOPWORDS: dict[str, frozenset[str]] = {
    code: frozenset(words.split())
    for code, words in {
        "en": "the and is are was not for with this that have has you your our please how what where can could would thank thanks",
        "de": "der die das und ist nicht für mit wir sie bitte wie wo können vielen dank ein eine von uns seit wurde",
        "fr": "le la les et est pas pour avec nous vous merci comment où une des du nos notre très ce cette",
        "es": "el la los las y es no para con nos por favor cómo dónde una del muy gracias nuestro esto que",
        "it": "il lo gli e non per con noi grazie come dove una della molto questo che sono abbiamo",
        "pt": "o os as e é não para com nós obrigado como onde uma do da muito isso que nosso",
        "nl": "de het een en is niet voor met wij bedankt hoe waar van onze zeer dit dat hebben",
        "tr": "ve bir bu için çok nasıl lütfen teşekkürler bize değil ile mi mı",  # noqa: RUF001
    }.items()
}
_langid: Any = None
_langid_lock = threading.Lock()


def _heuristic_language(clean: str) -> tuple[str, float]:
    letters = [ch for ch in clean if ch.isalpha()]
    if not letters:
        return "und", 0.0
    for code, low, high in _SCRIPTS:
        share = sum(low <= ord(ch) <= high for ch in letters) / len(letters)
        if share >= 0.4:
            return code, round(share, 3)
    tokens = re.findall(r"[^\W\d_]+", clean.casefold())
    hits = {code: sum(token in words for token in tokens) for code, words in _STOPWORDS.items()}
    best = max(hits, key=lambda code: hits[code])
    total = sum(hits.values())
    if hits[best] == 0 or sorted(hits.values())[-2] == hits[best]:
        return "und", 0.0
    return best, round(hits[best] / total, 3)


def language_detector() -> str:
    try:
        import py3langid  # noqa: F401
    except ImportError:
        return "builtin-script-stopword/1"
    return "py3langid+builtin-script-stopword/1"


def detect_language(clean: str) -> tuple[str, float]:
    """``(ISO 639-1 code or 'und', confidence)``.  Uses py3langid when installed; scripts and stop words otherwise,
    and for texts too short for a statistical guess."""
    global _langid
    guess, confidence = _heuristic_language(clean)
    letters = sum(ch.isalpha() for ch in clean)
    if letters < 12 or (guess not in _STOPWORDS and guess != "und"):
        return guess, confidence  # a non-Latin script decides; a very short text gets no statistical guess
    try:
        if _langid is None:
            with _langid_lock:
                if _langid is None:
                    from py3langid.langid import MODEL_FILE, LanguageIdentifier

                    _langid = LanguageIdentifier.from_model_file(MODEL_FILE, norm_probs=True)
        code, probability = _langid.classify(clean)
        probability = float(probability)
    except ImportError:
        return guess, confidence
    if probability >= 0.9 or (probability >= 0.6 and guess in ("und", code)):
        return str(code), round(probability, 3)
    return (guess, confidence) if guess != "und" else ("und", round(probability, 3))


# ----------------------------------------------------------------------------- providers
@dataclass(frozen=True)
class ModelInfo:
    provider: str
    model_id: str
    model_version: str
    tokenizer: str | None
    checksum_sha256: str
    source: str | None
    license: str | None
    languages: tuple[str, ...]
    is_baseline: bool
    thresholds: dict = field(default_factory=dict, hash=False, compare=False)
    note: str | None = None


class SentimentProvider(Protocol):
    info: ModelInfo

    def predict(self, texts: list[str]) -> np.ndarray:
        """One row per text: probabilities ``(positive, neutral, negative)``."""


class LexiconBaseline:
    """Counts words from two fixed English lists.  A fallback, not a trained model: it knows nothing about negation,
    context or any other language, and its 'probabilities' are counts rescaled to sum to one."""

    def __init__(self) -> None:
        digest = hashlib.sha256(json.dumps([BASELINE_NEGATIVE, BASELINE_POSITIVE]).encode()).hexdigest()
        self.info = ModelInfo(provider="lexicon_baseline", model_id="word-list-baseline-en", model_version=digest[:12], tokenizer=None,
                              checksum_sha256=digest, source="churn_platform.services.sentiment (built in)", license=None, languages=("en",),
                              is_baseline=True, thresholds={"polar": 0.34, "neutral": 0.2},
                              note="BASELINE: fixed English word lists, not a trained model")  # fmt: skip

    def predict(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), 3))
        for row, text in enumerate(texts):
            lowered = text.casefold()
            negative = sum(lowered.count(word) for word in BASELINE_NEGATIVE)
            positive = sum(lowered.count(word) for word in BASELINE_POSITIVE)
            out[row] = (positive, 1.0, negative)
            out[row] /= out[row].sum()
        return out


class OnnxTransformer:
    """A sequence-classification transformer run locally with ONNX Runtime (CPU)."""

    def __init__(self, directory: Path, pin_name: str) -> None:
        import onnxruntime
        from tokenizers import Tokenizer

        pin = PINS[pin_name]
        problems = verify_directory(directory, pin_name)
        if problems:
            raise ValidationFailed("the sentiment model directory does not match its pinned checksums: " + "; ".join(problems[:3]))
        self._tokenizer = Tokenizer.from_file(str(directory / "tokenizer.json"))
        self._tokenizer.enable_truncation(max_length=MAX_TOKENS)
        self._tokenizer.no_padding()  # one text per forward pass (see predict): nothing to pad
        options = onnxruntime.SessionOptions()
        options.intra_op_num_threads = max(1, get_settings().sentiment_threads)
        options.inter_op_num_threads = 1
        # No memory arena: with it, one batch of long texts leaves the process about 150 MB larger for good (measured:
        # 445 MB against 300 MB resident afterwards).  Short texts are scored at the same speed either way.
        options.enable_cpu_mem_arena = False
        options.enable_mem_pattern = False
        self._session = onnxruntime.InferenceSession(str(directory / pin["weights"]), options, providers=["CPUExecutionProvider"])
        self._inputs = [node.name for node in self._session.get_inputs()]
        self._classes = pin["classes"]
        self._lock = threading.Lock()
        self.info = transformer_info(pin_name)

    def predict(self, texts: list[str]) -> np.ndarray:
        """Class probabilities (positive, neutral, negative), one text per forward pass.

        Not batched on purpose.  The pinned weights are dynamically quantised: value ranges are taken from the whole
        input tensor, so in a batch a text's score moves with its neighbours and with the padding (measured on the 99
        synthetic templates: 48 probabilities moved by more than 0.01, 5 by more than 0.1, 4 labels flipped).  Alone,
        a text always gets the same score.  The price is throughput: about 19 ms instead of 13 ms per short text."""
        out = np.zeros((len(texts), 3))
        for n, encoded in enumerate(self._tokenizer.encode_batch(list(texts))):
            ids = np.array([encoded.ids], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": np.ones_like(ids)}
            if "token_type_ids" in self._inputs:
                feed["token_type_ids"] = np.zeros_like(ids)
            with self._lock:
                logits = self._session.run(None, feed)[0][0]
            p = np.exp(logits - logits.max())
            p /= p.sum()
            for k, name in enumerate(("positive", "neutral", "negative")):
                out[n, k] = p[self._classes[name]].sum()
        return out


_provider_cache: dict[tuple, tuple[SentimentProvider, str | None]] = {}
_provider_lock = threading.Lock()


def model_directory(pin_name: str | None = None) -> Path:
    return get_settings().sentiment_model_path / (pin_name or DEFAULT_PIN)


_verified: dict[tuple, bool] = {}


def verify_directory(directory: Path, pin_name: str) -> list[str]:
    """Problems with the files of a model directory against the pin (empty list = exactly the pinned model).
    A file that was hashed once is not hashed again while its size and modification time stay the same."""
    problems = []
    for name, (size, sha) in PINS[pin_name]["files"].items():
        path = directory / name
        if not path.is_file():
            problems.append(f"{name} is missing")
            continue
        stat = path.stat()
        if stat.st_size != size:
            problems.append(f"{name} has {stat.st_size} bytes, expected {size}")
            continue
        key = (str(path), stat.st_size, stat.st_mtime_ns, sha)
        if key not in _verified:
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for block in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(block)
            _verified[key] = digest.hexdigest() == sha
        if not _verified[key]:
            problems.append(f"{name} does not have the pinned SHA-256")
    return problems


def describe_provider() -> tuple[ModelInfo | None, str | None, str | None]:
    """``(identity of the provider this installation scores with, why the baseline stands in, problem)`` without
    loading any weights - for status pages.  ``get_provider`` is what actually loads the model."""
    settings = get_settings()
    baseline = LexiconBaseline().info
    if settings.sentiment_provider == "lexicon_baseline":
        return baseline, None, None
    reason = runtime_problem()
    if reason is None and not (model_directory() / PINS[DEFAULT_PIN]["weights"]).is_file():
        reason = f"no model in {model_directory()} (run: churn-platform sentiment-model fetch)"
    if reason is None:
        problems = verify_directory(model_directory(), DEFAULT_PIN)
        if problems:
            reason = "the sentiment model directory does not match its pinned checksums: " + "; ".join(problems[:3])
    if reason is None:
        return transformer_info(DEFAULT_PIN), None, None
    if settings.sentiment_provider == "onnx_transformer":
        return None, None, f"CHURN_SENTIMENT_PROVIDER=onnx_transformer but the transformer cannot be used: {reason}"
    return baseline, reason, None


def transformer_info(pin_name: str) -> ModelInfo:
    pin = PINS[pin_name]
    try:
        import onnxruntime

        runtime = f"ONNX Runtime {onnxruntime.__version__}"
    except ImportError:
        runtime = "ONNX Runtime"
    return ModelInfo(provider="onnx_transformer", model_id=pin["model_id"], model_version=pin["revision"], tokenizer=pin["tokenizer"],
                     checksum_sha256=pin["files"][pin["weights"]][1], source=f"{HUB}/{pin['onnx_repo']}/tree/{pin['revision']}",
                     license=pin["license"], languages=tuple(pin["languages"]), is_baseline=False, thresholds=dict(pin["thresholds"]),
                     note=f"{runtime}, 8-bit quantised weights; trained on {pin['trained_on']}")  # fmt: skip


def runtime_problem() -> str | None:
    for module in ("onnxruntime", "tokenizers"):
        try:
            __import__(module)
        except ImportError:
            return f"the Python package '{module}' is not installed (install the 'nlp' extra)"
    return None


def get_provider() -> tuple[SentimentProvider, str | None]:
    """The provider this process scores with, and - when it is the baseline standing in for the transformer - why."""
    settings = get_settings()
    key = (settings.sentiment_provider, str(settings.sentiment_model_path), settings.sentiment_threads)
    with _provider_lock:
        if key in _provider_cache:
            return _provider_cache[key]
        reason = None
        provider: SentimentProvider
        if settings.sentiment_provider == "lexicon_baseline":
            provider = LexiconBaseline()
        else:
            reason = runtime_problem()
            if reason is None and not (model_directory() / PINS[DEFAULT_PIN]["weights"]).is_file():
                reason = f"no model in {model_directory()} (run: churn-platform sentiment-model fetch)"
            if reason is None:
                try:
                    provider = OnnxTransformer(model_directory(), DEFAULT_PIN)
                except ValidationFailed as exc:
                    reason = exc.message
            if reason is not None:
                if settings.sentiment_provider == "onnx_transformer":
                    raise Conflict(f"CHURN_SENTIMENT_PROVIDER=onnx_transformer but the transformer cannot be used: {reason}",
                                   code="sentiment_model_unavailable")  # fmt: skip
                provider = LexiconBaseline()
        _provider_cache[key] = (provider, reason)
        return provider, reason


def reset_provider_cache() -> None:
    with _provider_lock:
        _provider_cache.clear()


def fetch_model(pin_name: str = DEFAULT_PIN, directory: Path | None = None, log: Any = print) -> dict:
    """Download the pinned model files and verify each against its size and SHA-256.  Operator command; the only
    network access of this module.  Nothing is uploaded."""
    import httpx

    if pin_name not in PINS:
        raise ValidationFailed(f"unknown model '{pin_name}'; available: {', '.join(PINS)}")
    pin, target = PINS[pin_name], directory or model_directory(pin_name)
    target.mkdir(parents=True, exist_ok=True)
    with httpx.Client(timeout=120.0, follow_redirects=True) as client:
        for name, (size, sha) in pin["files"].items():
            path = target / name
            if path.is_file() and path.stat().st_size == size and hashlib.sha256(path.read_bytes()).hexdigest() == sha:
                log(f"  {name}: already present and verified")
                continue
            path.parent.mkdir(parents=True, exist_ok=True)
            digest, written, partial = hashlib.sha256(), 0, path.with_suffix(path.suffix + ".part")
            with client.stream("GET", f"{HUB}/{pin['onnx_repo']}/resolve/{pin['revision']}/{name}") as response:
                response.raise_for_status()
                with partial.open("wb") as handle:
                    for block in response.iter_bytes(1 << 20):
                        handle.write(block)
                        digest.update(block)
                        written += len(block)
            if written != size or digest.hexdigest() != sha:
                partial.unlink(missing_ok=True)
                raise ValidationFailed(f"{name}: the download does not match the pinned size and SHA-256; nothing was installed")
            partial.replace(path)
            log(f"  {name}: {written:,} bytes, SHA-256 verified")
    manifest = {"pin": pin_name, "model_id": pin["model_id"], "onnx_repo": pin["onnx_repo"], "revision": pin["revision"],
                "license": pin["license"], "languages": pin["languages"], "source": f"{HUB}/{pin['onnx_repo']}/tree/{pin['revision']}",
                "files": {name: {"bytes": size, "sha256": sha} for name, (size, sha) in pin["files"].items()},
                "fetched_at": utcnow().isoformat()}  # fmt: skip
    (target / "sentiment_model.json").write_text(json.dumps(manifest, indent=2))
    reset_provider_cache()
    return {"directory": str(target), **manifest}


# ----------------------------------------------------------------------------- analysis (no database)
@dataclass
class Analysis:
    label: str = "uncertain"
    state: str = "ok"
    confidence: float | None = None
    p_positive: float | None = None
    p_neutral: float | None = None
    p_negative: float | None = None
    score: float | None = None
    language: str | None = None
    language_confidence: float | None = None
    flags: list[str] = field(default_factory=list)
    redactions: dict[str, int] = field(default_factory=dict)
    text_sha256: str | None = None
    text_chars: int = 0
    excerpt: str | None = None
    error: str | None = None


def _decide(whole: np.ndarray, parts: list[np.ndarray], thresholds: dict) -> tuple[str, float]:
    """Label and confidence from the probabilities of the whole text and of its clauses."""
    polar, neutral = float(thresholds["polar"]), float(thresholds["neutral"])
    margins = [float(p[0] - p[2]) for p in parts]
    if len(parts) > 1 and max(margins) >= polar and min(margins) <= -polar:
        return "mixed", round(min(max(margins), -min(margins)), 4)
    margin = float(whole[0] - whole[2])
    if margin >= polar:
        return "positive", round(float(whole[0]), 4)
    if margin <= -polar:
        return "negative", round(float(whole[2]), 4)
    if abs(margin) <= neutral:
        return "neutral", round(1.0 - abs(margin), 4)
    return "uncertain", round(1.0 - abs(margin), 4)


def analyse(texts: list[str | None], provider: SentimentProvider | None = None) -> list[Analysis]:
    """Prepare, score and label a list of raw texts.  Identical texts (after preparation) are scored once."""
    provider = provider or get_provider()[0]
    settings = get_settings()
    results: list[Analysis] = []
    units: dict[str, int] = {}  # text to score -> position in the batch
    plan: list[tuple[int, str, list[str]] | None] = []
    for raw in texts:
        result = Analysis()
        clean = normalise(raw)
        clean, result.redactions = redact_pii(clean)
        result.text_chars = len(clean)
        if result.redactions:
            result.flags.append("redacted")
        if not clean:
            result.state = "empty"
        elif sum(ch.isalpha() for ch in _PLACEHOLDER.sub(" ", clean)) < MIN_CHARS:
            result.state = "too_short"
        if result.state == "ok":
            if len(clean) > settings.sentiment_max_chars:
                head = settings.sentiment_max_chars * 6 // 10
                clean = clean[:head].rsplit(" ", 1)[0] + " … " + clean[-(settings.sentiment_max_chars - head) :].split(" ", 1)[-1]
                result.flags.append("truncated")
            result.language, result.language_confidence = detect_language(clean)
            if result.language == "und":
                result.state = "language_undetermined"
            elif result.language not in provider.info.languages:
                result.state = "unsupported_language"
        result.text_sha256 = text_key(clean) if clean else None
        result.excerpt = clean[:280] or None
        results.append(result)
        if result.state != "ok":
            plan.append(None)
            continue
        pieces = clauses(clean)
        pieces = pieces if len(pieces) > 1 else []
        for unit in (clean, *pieces):
            units.setdefault(unit, len(units))
        plan.append((units[clean], clean, pieces))
    probabilities = provider.predict(list(units)) if units else np.zeros((0, 3))
    for result, item in zip(results, plan, strict=True):
        if item is None:
            continue
        whole = probabilities[item[0]]
        result.label, result.confidence = _decide(whole, [probabilities[units[p]] for p in item[2]], provider.info.thresholds)
        result.p_positive, result.p_neutral, result.p_negative = (round(float(v), 4) for v in whole)
        result.score = round(float(whole[0] - whole[2]), 4)
    return results


def analysis_view(result: Analysis) -> dict:
    return {k: getattr(result, k) for k in ("label", "state", "confidence", "p_positive", "p_neutral", "p_negative", "score", "language",
                                            "language_confidence", "flags", "redactions", "text_chars", "excerpt", "error")}  # fmt: skip


# ----------------------------------------------------------------------------- model registry rows
def model_view(model: SentimentModel) -> dict:
    return to_dict(model)


def ensure_model(session: Session, tenant_id: int, info: ModelInfo, created_by: int | None = None) -> SentimentModel:
    """The tenant's row for this exact model (created on first use) - and the only active one."""
    model = session.execute(select(SentimentModel).where(
        SentimentModel.tenant_id == tenant_id, SentimentModel.provider == info.provider, SentimentModel.model_id == info.model_id,
        SentimentModel.model_version == info.model_version, SentimentModel.checksum_sha256 == info.checksum_sha256)).scalar_one_or_none()  # fmt: skip
    if model is None:
        model = SentimentModel(tenant_id=tenant_id, provider=info.provider, model_id=info.model_id, model_version=info.model_version,
                               tokenizer=info.tokenizer, checksum_sha256=info.checksum_sha256, source=info.source, license=info.license,
                               languages=list(info.languages), is_baseline=info.is_baseline, is_active=False,
                               config={"thresholds": info.thresholds, "note": info.note, "language_detector": language_detector()},
                               created_by=created_by)  # fmt: skip
        session.add(model)
        session.flush()
    if not model.is_active:
        session.execute(update(SentimentModel).where(SentimentModel.tenant_id == tenant_id, SentimentModel.id != model.id).values(is_active=False))
        model.is_active = True
        audit.record(session, tenant_id=tenant_id, action="sentiment.model_activated", entity_type="sentiment_model", entity_id=model.id,
                     detail={"provider": info.provider, "model_id": info.model_id, "model_version": info.model_version,
                             "checksum_sha256": info.checksum_sha256, "is_baseline": info.is_baseline})  # fmt: skip
    return model


def active_model(session: Session, tenant_id: int) -> SentimentModel | None:
    return session.execute(select(SentimentModel).where(SentimentModel.tenant_id == tenant_id, SentimentModel.is_active.is_(True))).scalar_one_or_none()


# ----------------------------------------------------------------------------- scoring
def _pending(tenant_id: int, model_id: int, customer_ids: list[int] | None = None, after_id: int = 0):  # type: ignore[no-untyped-def]
    """Interactions of the tenant (or of some of its customers) without an up-to-date score under this model.
    A score that failed with an error does not count as a score: the next run tries again."""
    scored = select(SentimentScore.id).where(SentimentScore.interaction_id == SupportInteraction.id, SentimentScore.sentiment_model_id == model_id,
                                              SentimentScore.source_record_version == SupportInteraction.record_version,
                                              SentimentScore.state != "error")  # fmt: skip
    stmt = select(SupportInteraction.id, SupportInteraction.customer_id, SupportInteraction.opened_at, SupportInteraction.body,
                  SupportInteraction.record_version, SupportInteraction.dataset_version_id).where(
        SupportInteraction.tenant_id == tenant_id, SupportInteraction.kind != "nps_survey", SupportInteraction.id > after_id,
        ~scored.exists())  # fmt: skip
    if customer_ids is not None:
        stmt = stmt.where(SupportInteraction.customer_id.in_(customer_ids))
    return stmt.order_by(SupportInteraction.id)


def pending_count(session: Session, tenant_id: int, model_id: int, customer_ids: list[int] | None = None) -> int:
    return session.execute(select(func.count()).select_from(_pending(tenant_id, model_id, customer_ids).subquery())).scalar_one()


def _write_scores(session: Session, tenant_id: int, model_id: int, rows: list[Any], results: list[Analysis], keys: list[str],
                  run_id: int | None, counts: dict | None = None) -> None:
    """Replace the scores of these interactions under this model (one row per interaction and model)."""
    now, seen, values = utcnow(), set(), []
    session.execute(SentimentScore.__table__.delete().where(SentimentScore.sentiment_model_id == model_id,
                                                            SentimentScore.interaction_id.in_([r.id for r in rows])))  # fmt: skip
    for row, result, key in zip(rows, results, keys, strict=True):
        duplicate = bool(key and key in seen)
        seen.add(key)
        values.append({
            "tenant_id": tenant_id, "interaction_id": row.id, "customer_id": row.customer_id, "sentiment_model_id": model_id, "run_id": run_id,
            "occurred_at": row.opened_at, "label": result.label, "confidence": result.confidence, "p_positive": result.p_positive,
            "p_neutral": result.p_neutral, "p_negative": result.p_negative, "score": result.score, "language": result.language,
            "language_confidence": result.language_confidence, "state": result.state, "error": result.error,
            "flags": list(result.flags) + (["duplicate_text"] if duplicate else []), "text_sha256": result.text_sha256,
            "text_chars": result.text_chars, "redactions": result.redactions or None, "excerpt": result.excerpt,
            "source_record_version": row.record_version, "source_dataset_version_id": row.dataset_version_id, "scored_at": now,
        })  # fmt: skip
        if counts is not None:
            counts["reused_duplicate_text"] += duplicate
            for bucket, value in (("by_label", result.label), ("by_state", result.state), ("by_language", result.language or "none")):
                counts[bucket][value] = counts[bucket].get(value, 0) + 1
    if values:
        session.execute(SentimentScore.__table__.insert(), values)


def score_customer(session: Session, tenant_id: int, customer_id: int) -> int:
    """Score one customer's waiting support text inside the caller's transaction (used when a single customer is
    scored on request).  Does nothing for a tenant that has never been scored: the first scoring is a job."""
    model = active_model(session, tenant_id)
    info = describe_provider()[0]
    if model is None or info is None or (model.provider, model.checksum_sha256) != (info.provider, info.checksum_sha256):
        return 0
    rows = session.execute(_pending(tenant_id, model.id, [customer_id]).limit(CHUNK)).all()
    if not rows:
        return 0
    results = analyse([r.body for r in rows], get_provider()[0])
    _write_scores(session, tenant_id, model.id, rows, results, [r.text_sha256 or "" for r in results], None)
    return len(rows)


def score_pending(tenant_id: int, *, run_id: int | None = None, created_by: int | None = None, progress: Any = None,
                  customer_ids: list[int] | None = None) -> dict:
    """Score every interaction that has no current score under the active provider's model.  Idempotent."""
    provider, fallback = get_provider()
    with session_scope() as ws:
        model = ensure_model(ws, tenant_id, provider.info, created_by)
        model_id = model.id
    counts: dict[str, Any] = {"scored": 0, "reused_duplicate_text": 0, "by_label": {}, "by_state": {}, "by_language": {}}
    cache: dict[str, Analysis] = {}
    with read_session() as rs:
        total = pending_count(rs, tenant_id, model_id, customer_ids)
    done = last_id = 0
    while True:
        with read_session() as rs:
            rows = rs.execute(_pending(tenant_id, model_id, customer_ids, after_id=last_id).limit(CHUNK)).all()
        if not rows:
            break
        last_id = rows[-1].id
        prepared = [normalise(r.body) for r in rows]
        keys = [text_key(redact_pii(p)[0]) if p else "" for p in prepared]
        fresh = [n for n, key in enumerate(keys) if key not in cache]
        try:
            for n, result in zip(fresh, analyse([rows[n].body for n in fresh], provider), strict=True):
                cache.setdefault(keys[n], result)
        except Exception as exc:  # a provider failure is a state of the score, not the end of the run
            for n in fresh:
                cache.setdefault(keys[n], Analysis(state="error", error=f"{type(exc).__name__}: {exc}"[:300]))
        with session_scope() as ws:
            _write_scores(ws, tenant_id, model_id, rows, [cache[key] for key in keys], keys, run_id, counts)
        done += len(rows)
        counts["scored"] = done
        if progress is not None:
            progress(min(0.95, done / max(1, total)), f"{done:,} of {total:,} interactions")
    counts.update({"model": {"provider": provider.info.provider, "model_id": provider.info.model_id, "model_version": provider.info.model_version,
                             "checksum_sha256": provider.info.checksum_sha256, "is_baseline": provider.info.is_baseline},
                   "sentiment_model_id": model_id, "fallback_reason": fallback, "language_detector": language_detector(),
                   "distinct_texts": len(cache)})  # fmt: skip
    return counts


def start_run(session: Session, principal: Principal, *, trigger: str = "manual") -> tuple[SentimentRun, Any]:
    run = SentimentRun(tenant_id=principal.tenant_id, status="pending", trigger=trigger, created_by=principal.user_id)
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="sentiment.score", payload={"sentiment_run_id": run.id},
                       created_by=principal.user_id)  # fmt: skip
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="sentiment.run_started", entity_type="sentiment_run", entity_id=run.id)
    return run, job


def run_scoring(run_id: int, ctx: Any = None) -> dict:
    with session_scope() as ws:
        run = ws.get(SentimentRun, run_id)
        if run is None:
            raise jobs.PermanentJobError(f"sentiment run {run_id} does not exist")
        run.status, tenant_id, created_by = "running", run.tenant_id, run.created_by
    try:
        counts = score_pending(tenant_id, run_id=run_id, created_by=created_by, progress=ctx.progress if ctx is not None else None)
    except Exception as exc:
        with session_scope() as ws:
            run = ws.get(SentimentRun, run_id)
            run.status, run.error, run.finished_at = "failed", f"{type(exc).__name__}: {exc}"[:1000], utcnow()
        raise
    with session_scope() as ws:
        run = ws.get(SentimentRun, run_id)
        run.status, run.counts, run.finished_at, run.sentiment_model_id = "completed", counts, utcnow(), counts["sentiment_model_id"]
        audit.record(ws, tenant_id=tenant_id, action="sentiment.run_completed", entity_type="sentiment_run", entity_id=run_id,
                     detail={"scored": counts["scored"], "model": counts["model"], "fallback_reason": counts["fallback_reason"]})  # fmt: skip
    return counts


def ensure_scored(tenant_id: int, customer_ids: list[int] | None = None) -> dict | None:
    """Called before features are computed: nothing may be computed from a half-scored history.

    Returns the active model's identity (None for a tenant without support text).  Scores inline when interactions
    are waiting; a tenant that is fully scored costs one COUNT.
    """
    info, _fallback, problem = describe_provider()
    if info is None:
        raise Conflict(problem or "no sentiment provider is available", code="sentiment_model_unavailable")
    with read_session() as rs:
        model = rs.execute(select(SentimentModel).where(
            SentimentModel.tenant_id == tenant_id, SentimentModel.provider == info.provider, SentimentModel.model_id == info.model_id,
            SentimentModel.model_version == info.model_version, SentimentModel.checksum_sha256 == info.checksum_sha256)).scalar_one_or_none()  # fmt: skip
        waiting = pending_count(rs, tenant_id, model.id, customer_ids) if model is not None and model.is_active else None
        if waiting is None and rs.execute(select(SupportInteraction.id).where(SupportInteraction.tenant_id == tenant_id).limit(1)).first() is None:
            return None
    if waiting is None or waiting > 0:
        # a model that was never used for this tenant scores everything; otherwise only what is waiting (for these customers)
        score_pending(tenant_id, customer_ids=customer_ids if waiting is not None else None)
    return {"provider": info.provider, "model_id": info.model_id, "model_version": info.model_version, "checksum_sha256": info.checksum_sha256,
            "is_baseline": info.is_baseline}  # fmt: skip


# ----------------------------------------------------------------------------- reading
def status(session: Session, tenant_id: int) -> dict:
    """What scores with what, and what is still unknown.  ``production_accuracy`` is BLOCKED until a labelled set
    that is not synthetic has been evaluated for the active model."""
    settings = get_settings()
    info, fallback, problem = describe_provider()
    model = active_model(session, tenant_id)
    evaluations = session.execute(select(SentimentEvaluation).where(SentimentEvaluation.tenant_id == tenant_id)
                                  .order_by(SentimentEvaluation.id.desc()).limit(20)).scalars().all()  # fmt: skip
    real = [e for e in evaluations if not e.is_synthetic and model is not None and e.sentiment_model_id == model.id]
    current = model is not None and info is not None and (model.provider, model.checksum_sha256) == (info.provider, info.checksum_sha256)
    return {
        "configured_provider": settings.sentiment_provider,
        "provider": None if info is None else {"provider": info.provider, "model_id": info.model_id, "model_version": info.model_version,
                                               "tokenizer": info.tokenizer, "checksum_sha256": info.checksum_sha256, "source": info.source,
                                               "license": info.license, "languages": list(info.languages), "is_baseline": info.is_baseline,
                                               "thresholds": info.thresholds, "note": info.note},
        "problem": problem, "fallback_reason": fallback, "language_detector": language_detector(),
        "active_model": model_view(model) if model is not None else None,
        "active_model_is_current": bool(current),
        "pending": pending_count(session, tenant_id, model.id) if model is not None else
                   session.execute(select(func.count()).select_from(SupportInteraction).where(SupportInteraction.tenant_id == tenant_id,
                                                                                               SupportInteraction.kind != "nps_survey")).scalar_one(),
        "inference": "local (no text leaves this installation)",
        "production_accuracy": {"status": "PASS" if real else "BLOCKED",
                                "reason": None if real else "no labelled sample of real support text has been evaluated for the active model",
                                "evaluations": [evaluation_view(e) for e in evaluations]},
        "available_models": {name: {"model_id": pin["model_id"], "revision": pin["revision"], "license": pin["license"],
                                    "languages": pin["languages"], "installed": not verify_directory(model_directory(name), name)
                                    if (model_directory(name) / pin["weights"]).is_file() else False} for name, pin in PINS.items()},
    }  # fmt: skip


def summary(session: Session, tenant_id: int, days: int = 180) -> dict:
    """Distribution of labels, states and languages, and the weekly trend, for the active model."""
    model = active_model(session, tenant_id)
    if model is None:
        return {"model": None, "total": 0, "by_label": {}, "by_state": {}, "by_language": [], "weekly": [], "customers": []}
    base = (SentimentScore.tenant_id == tenant_id, SentimentScore.sentiment_model_id == model.id)
    newest = session.execute(select(func.max(SentimentScore.occurred_at)).where(*base)).scalar()
    if newest is None:
        return {"model": model_view(model), "total": 0, "by_label": {}, "by_state": {}, "by_language": [], "weekly": [], "customers": []}
    since = newest - timedelta(days=days)
    window = (*base, SentimentScore.occurred_at >= since)
    by_label = dict(session.execute(select(SentimentScore.label, func.count()).where(*window, SentimentScore.state == "ok").group_by(SentimentScore.label)).all())
    by_state = dict(session.execute(select(SentimentScore.state, func.count()).where(*window).group_by(SentimentScore.state)).all())
    languages = session.execute(select(SentimentScore.language, SentimentScore.label, func.count()).where(*window)
                                .group_by(SentimentScore.language, SentimentScore.label)).all()  # fmt: skip
    by_language: dict[str, dict] = {}
    for language, label, count in languages:
        entry = by_language.setdefault(language or "none", {"language": language or "none", "total": 0, "supported": language in (model.languages or [])})
        entry[label] = entry.get(label, 0) + count
        entry["total"] += count
    rows = session.execute(select(SentimentScore.occurred_at, SentimentScore.label, SentimentScore.score).where(*window, SentimentScore.state == "ok")).all()
    weekly: dict[str, dict] = {}
    for occurred_at, label, score in rows:
        week = (occurred_at.date() - timedelta(days=occurred_at.weekday())).isoformat()
        entry = weekly.setdefault(week, {"week": week, "n": 0, "negative": 0, "positive": 0, "sum": 0.0})
        entry["n"] += 1
        entry["sum"] += score or 0.0
        entry["negative"] += label == "negative"
        entry["positive"] += label == "positive"
    series = [{"week": w["week"], "n": w["n"], "avg_score": round(w["sum"] / w["n"], 4), "negative_share": round(w["negative"] / w["n"], 4),
               "positive_share": round(w["positive"] / w["n"], 4)} for w in sorted(weekly.values(), key=lambda w: w["week"])]  # fmt: skip
    negative = func.sum(case((SentimentScore.label == "negative", 1), else_=0))
    worst = session.execute(
        select(Customer.id, Customer.external_id, Customer.name, func.count(), negative, func.avg(SentimentScore.score))
        .join(Customer, Customer.id == SentimentScore.customer_id).where(*window, SentimentScore.state == "ok")
        .group_by(Customer.id, Customer.external_id, Customer.name).having(func.count() >= 2).order_by(negative.desc(), func.avg(SentimentScore.score)).limit(15)
    ).all()  # fmt: skip
    return {
        "model": model_view(model), "window_days": days, "newest": newest.isoformat(), "total": sum(by_state.values()),
        "by_label": by_label, "by_state": by_state, "by_language": sorted(by_language.values(), key=lambda e: -e["total"]), "weekly": series,
        "customers": [{"customer_id": cid, "external_id": ext, "name": name, "interactions": int(n), "negative": int(neg or 0),
                       "avg_score": None if avg is None else round(float(avg), 4)} for cid, ext, name, n, neg, avg in worst],
    }  # fmt: skip


def scores_query(tenant_id: int, model_id: int, *, label: str | None = None, state: str | None = None, language: str | None = None,
                 q: str | None = None, customer_id: int | None = None):  # type: ignore[no-untyped-def]
    stmt = (select(SentimentScore, Customer.external_id, Customer.name).join(Customer, Customer.id == SentimentScore.customer_id)
            .where(SentimentScore.tenant_id == tenant_id, SentimentScore.sentiment_model_id == model_id))  # fmt: skip
    if label:
        if label not in LABELS:
            raise ValidationFailed(f"label must be one of {', '.join(LABELS)}", details={"field": "label"})
        stmt = stmt.where(SentimentScore.label == label)
    if state:
        stmt = stmt.where(SentimentScore.state == state)
    if language:
        stmt = stmt.where(SentimentScore.language == language)
    if customer_id:
        stmt = stmt.where(SentimentScore.customer_id == customer_id)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Customer.external_id.ilike(like) | Customer.name.ilike(like) | SentimentScore.excerpt.ilike(like))
    return stmt.order_by(SentimentScore.occurred_at.desc(), SentimentScore.id.desc())


def score_view(row: Any) -> dict:
    score, external_id, name = row
    return to_dict(score, exclude={"text_sha256"}, include={"customer_external_id": external_id, "customer_name": name})


# ----------------------------------------------------------------------------- evaluation against labelled text
def evaluation_view(evaluation: SentimentEvaluation) -> dict:
    return to_dict(evaluation)


def evaluate(session: Session, principal: Principal, *, dataset_name: str, rows: list[dict], is_synthetic: bool) -> SentimentEvaluation:
    """Agreement of the active provider with labelled texts (``[{"text": ..., "label": ...}]``).

    Texts the provider does not label (unsupported language, too short) and texts it calls ``uncertain`` are
    reported as *not covered*; accuracy is given both on the covered texts and on all texts.
    """
    if not rows or len(rows) > 20000:
        raise ValidationFailed("between 1 and 20,000 labelled rows are required", details={"field": "rows"})
    wanted = {"positive", "negative", "neutral", "mixed"}
    for n, row in enumerate(rows):
        if not isinstance(row.get("text"), str) or row.get("label") not in wanted:
            raise ValidationFailed(f"row {n + 1}: 'text' must be a string and 'label' one of {', '.join(sorted(wanted))}", details={"field": "rows"})
    provider, fallback = get_provider()
    model = ensure_model(session, principal.tenant_id, provider.info, principal.user_id)
    results = analyse([r["text"] for r in rows], provider)
    truth = [r["label"] for r in rows]
    covered = [n for n, r in enumerate(results) if r.state == "ok" and r.label != "uncertain"]
    correct = [n for n in covered if results[n].label == truth[n]]
    per_label = {}
    for label in sorted(wanted):
        predicted = [n for n in covered if results[n].label == label]
        actual = [n for n, t in enumerate(truth) if t == label]
        hit = [n for n in predicted if truth[n] == label]
        precision = len(hit) / len(predicted) if predicted else None
        recall = len(hit) / len(actual) if actual else None
        per_label[label] = {"support": len(actual), "precision": precision, "recall": recall,
                            "f1": 2 * precision * recall / (precision + recall) if precision and recall else (0.0 if actual else None)}  # fmt: skip
    languages: dict[str, dict] = {}
    for n, result in enumerate(results):
        entry = languages.setdefault(result.language or "none", {"n": 0, "covered": 0, "correct": 0})
        entry["n"] += 1
        entry["covered"] += n in set(covered)
        entry["correct"] += n in set(correct)
    polarity_errors = sum(1 for n in covered if {results[n].label, truth[n]} == {"positive", "negative"})
    f1s = [v["f1"] for v in per_label.values() if v["f1"] is not None]
    metrics = {
        "rows": len(rows), "covered": len(covered), "coverage": len(covered) / len(rows),
        "accuracy_on_covered": len(correct) / len(covered) if covered else None, "accuracy_on_all": len(correct) / len(rows),
        "macro_f1": sum(f1s) / len(f1s) if f1s else None, "polarity_errors": polarity_errors, "per_label": per_label, "per_language": languages,
        "not_scored_by_state": {s: sum(1 for r in results if r.state == s) for s in sorted({r.state for r in results} - {"ok"})},
        "uncertain": sum(1 for r in results if r.state == "ok" and r.label == "uncertain"),
        "model": {"provider": provider.info.provider, "model_id": provider.info.model_id, "model_version": provider.info.model_version,
                  "checksum_sha256": provider.info.checksum_sha256, "is_baseline": provider.info.is_baseline, "thresholds": provider.info.thresholds},
        "fallback_reason": fallback,
        "caveat": ("SYNTHETIC labelled set: the labels are the intent of the template authors and the decision thresholds were set on these "
                   "same templates. This shows that the evaluation works; it is not an accuracy figure.") if is_synthetic else None,
    }  # fmt: skip
    evaluation = SentimentEvaluation(tenant_id=principal.tenant_id, sentiment_model_id=model.id, dataset_name=dataset_name.strip()[:200] or "unnamed",
                                     is_synthetic=is_synthetic, rows=len(rows), metrics=metrics, created_by=principal.user_id)  # fmt: skip
    session.add(evaluation)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="sentiment.evaluated", entity_type="sentiment_evaluation",
                 entity_id=evaluation.id, detail={"dataset": evaluation.dataset_name, "rows": len(rows), "is_synthetic": is_synthetic,
                                                  "accuracy_on_covered": metrics["accuracy_on_covered"], "coverage": metrics["coverage"]})  # fmt: skip
    return evaluation


def get_run(session: Session, tenant_id: int, run_id: int) -> SentimentRun:
    return get_owned(session, SentimentRun, tenant_id, run_id, label="Sentiment run")
