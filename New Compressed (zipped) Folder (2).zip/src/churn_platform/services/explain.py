"""Explainability with SHAP: global importance, per-customer contributions and waterfalls.

SHAP values describe how the *model* arrived at a score.  They are attributions of a prediction,
not causes of churn, and nothing here should be read as a causal or treatment effect.
"""

from __future__ import annotations

import warnings
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..errors import Conflict
from ..models import Explanation, MLDataset, ModelRun
from ..security import Principal
from . import audit, feature_engine, mlprep, training
from .common import get_owned, json_safe, to_dict

ADDITIVITY_TOLERANCE = 1e-3
GLOBAL_SAMPLE = 2000
NOT_CAUSAL = ("SHAP values attribute the model's prediction to its inputs. They describe associations the model "
              "learned, not causes of churn, and do not estimate the effect of any intervention.")  # fmt: skip


def _import_shap() -> Any:
    with warnings.catch_warnings():
        # shap's plotting helpers trigger a matplotlib PendingDeprecationWarning at import time;
        # plotting is not used here.  Scoped to this import only.
        warnings.simplefilter("ignore", PendingDeprecationWarning)
        import shap

    return shap


def _model_inputs(bundle: dict, raw: pd.DataFrame) -> tuple[Any, np.ndarray]:
    """Final estimator and the matrix it actually sees (after any scaler; samplers act in fit only)."""
    X = mlprep.transform(bundle["prep"], raw[bundle["features"]]).to_numpy()
    pipeline = bundle["model"]
    for name, step in pipeline.steps[:-1]:
        if name != "smote":
            X = step.transform(X)
    return pipeline.steps[-1][1], X


def _class1(values: Any, expected: Any) -> tuple[np.ndarray, float]:
    if isinstance(values, list):
        values = values[1]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, 1]
    expected = np.atleast_1d(np.asarray(expected, dtype="float64"))
    return values, float(expected[1] if len(expected) > 1 else expected[0])


def shap_values(bundle: dict, raw: pd.DataFrame) -> dict:
    """Encoded-column SHAP values in the model's raw output space, with an additivity check."""
    algorithm = bundle["algorithm"]
    try:
        model, X = _model_inputs(bundle, raw)
        if algorithm == "logistic_regression":
            coef = model.coef_[0]
            values, base = X * coef[None, :], float(model.intercept_[0])  # background = training mean (zero after scaling)
            raw_out, space, method = model.decision_function(X), "log_odds", "exact linear SHAP (independent features)"
        elif algorithm == "random_forest":
            shap = _import_shap()
            explainer = shap.TreeExplainer(model)
            values, base = _class1(explainer.shap_values(X, check_additivity=False), explainer.expected_value)
            raw_out, space, method = model.predict_proba(X)[:, 1], "probability", "shap.TreeExplainer (path-dependent)"
        elif algorithm == "xgboost":
            raw_out, space = model.predict(X, output_margin=True), "log_odds"
            try:
                shap = _import_shap()
                explainer = shap.TreeExplainer(model)
                values, base = _class1(explainer.shap_values(X, check_additivity=False), explainer.expected_value)
                method = "shap.TreeExplainer (path-dependent)"
            except Exception:  # fall back to the library's own exact TreeSHAP implementation
                import xgboost

                contrib = model.get_booster().predict(xgboost.DMatrix(X), pred_contribs=True)
                values, base, method = contrib[:, :-1], float(contrib[0, -1]), "xgboost pred_contribs (TreeSHAP)"
        elif algorithm == "lightgbm":
            # LightGBM computes path-dependent TreeSHAP itself.  shap.TreeExplainer only forwards to this call (and adds
            # a UserWarning about its own return type for binary models), so it is called directly: the same numbers on
            # one code path, whatever the warning filters are.
            raw_out, space = model.predict(X, raw_score=True), "log_odds"
            contrib = np.asarray(model.booster_.predict(X, pred_contrib=True), dtype="float64")
            values, base, method = contrib[:, :-1], float(contrib[0, -1]), "lightgbm pred_contrib (TreeSHAP)"
        else:
            return {"status": "unavailable", "reason": f"no SHAP explainer is implemented for algorithm '{algorithm}'"}
    except Exception as exc:
        return {"status": "unavailable", "reason": f"SHAP computation failed: {type(exc).__name__}: {exc}"[:500]}
    values = np.asarray(values, dtype="float64")
    error = np.abs(base + values.sum(axis=1) - np.asarray(raw_out, dtype="float64"))
    if not np.all(np.isfinite(values)) or float(error.max(initial=0.0)) > ADDITIVITY_TOLERANCE:
        return {"status": "unavailable",
                "reason": f"SHAP additivity check failed (max error {float(error.max(initial=0.0)):.2e} > {ADDITIVITY_TOLERANCE})"}  # fmt: skip
    return {"status": "available", "method": method, "space": space, "base_value": base, "values": values,
            "raw_output": np.asarray(raw_out, dtype="float64"), "additivity_error": error}  # fmt: skip


def aggregate_to_features(bundle: dict, values: np.ndarray) -> pd.DataFrame:
    """Sum one-hot and missing-indicator columns back onto the contract feature they came from."""
    sources = [bundle["prep"]["source"][c] for c in bundle["columns"]]
    frame = pd.DataFrame(values, columns=bundle["columns"])
    return frame.T.groupby(sources, sort=False).sum().T[bundle["features"]]


def to_probability(bundle: dict, raw_value: np.ndarray, space: str) -> np.ndarray:
    raw_value = np.asarray(raw_value, dtype="float64")
    score = 1.0 / (1.0 + np.exp(-raw_value)) if space == "log_odds" else np.clip(raw_value, 0.0, 1.0)
    return training.apply_calibrator(bundle.get("calibrator"), score)


def format_value(name: str, value: Any) -> str:
    spec = feature_engine.SPECS[name]
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return "not available"
    if spec.dtype == "category":
        return str(value)
    if spec.dtype == "bool":
        return "yes" if float(value) >= 0.5 else "no"
    if name.endswith("_pct") and name != "discount_pct":
        return f"{float(value):+.0%}"
    number = float(value)
    return f"{number:,.0f}" if abs(number) >= 100 or number == int(number) else f"{number:,.2f}"


def reason(name: str, value: Any, contribution: float) -> dict:
    spec = feature_engine.SPECS[name]
    direction = "raises" if contribution > 0 else "lowers"
    return {"feature": name, "label": spec.label, "group": spec.group, "value": json_safe(value), "display_value": format_value(name, value),
            "contribution": float(contribution), "direction": direction,
            "text": f"{spec.label}: {format_value(name, value)} ({direction} the predicted risk)"}  # fmt: skip


def explain_rows(bundle: dict, raw: pd.DataFrame, top_k: int = 3) -> dict:
    """Vectorised per-row explanation used by batch scoring: top-k risk-raising reasons for each row."""
    result = shap_values(bundle, raw)
    if result["status"] != "available":
        return result
    contrib = aggregate_to_features(bundle, result["values"])
    matrix = contrib.to_numpy()
    names = list(contrib.columns)
    reasons = []
    values = raw[names].reset_index(drop=True)
    for i in range(len(matrix)):
        order = np.argsort(-matrix[i])[:top_k]
        reasons.append([reason(names[j], values.iat[i, j], matrix[i, j]) for j in order if matrix[i, j] > 0])
    return {**result, "contributions": contrib, "top_reasons": reasons}


def waterfall(bundle: dict, base_value: float, contributions: dict[str, float], values: dict[str, Any], space: str, top_n: int = 8) -> dict:
    """Waterfall from the base rate to the customer's probability.

    Raw contributions are exact SHAP values in the model's output space.  The probability steps are
    obtained by adding features one at a time in order of absolute contribution and converting the
    running total to a calibrated probability, so they always sum to (final - base) exactly; because
    the link is non-linear the size of an individual probability step depends on that ordering.
    """
    ordered = sorted(contributions.items(), key=lambda kv: -abs(kv[1]))
    head, tail = ordered[:top_n], ordered[top_n:]
    running = base_value
    p_prev = float(to_probability(bundle, np.array([running]), space)[0])
    base_probability = p_prev
    steps = []
    for name, phi in head:
        running += phi
        p_new = float(to_probability(bundle, np.array([running]), space)[0])
        steps.append({**reason(name, values.get(name), phi), "probability_delta": p_new - p_prev, "probability_after": p_new})
        p_prev = p_new
    if tail:
        rest = float(sum(phi for _n, phi in tail))
        running += rest
        p_new = float(to_probability(bundle, np.array([running]), space)[0])
        steps.append({"feature": "__other__", "label": f"All other features ({len(tail)})", "group": "other", "value": None,
                      "display_value": "", "contribution": rest, "direction": "raises" if rest > 0 else "lowers",
                      "text": f"All other features combined ({len(tail)})", "probability_delta": p_new - p_prev,
                      "probability_after": p_new})  # fmt: skip
        p_prev = p_new
    return {"base_probability": base_probability, "final_probability": p_prev, "steps": steps, "space": space,
            "ordering": "features added in order of absolute SHAP contribution", "disclaimer": NOT_CAUSAL}  # fmt: skip


def explain_one(bundle: dict, raw_row: pd.DataFrame) -> dict:
    result = shap_values(bundle, raw_row)
    if result["status"] != "available":
        return result
    contrib = aggregate_to_features(bundle, result["values"]).iloc[0].to_dict()
    values = {k: (None if pd.isna(v) else v) for k, v in raw_row[bundle["features"]].iloc[0].to_dict().items()}
    wf = waterfall(bundle, result["base_value"], contrib, values, result["space"])
    return {"status": "available", "method": result["method"], "space": result["space"], "base_value": result["base_value"],
            "output_value": float(result["raw_output"][0]), "additivity_error": float(result["additivity_error"][0]),
            "contributions": {k: float(v) for k, v in contrib.items()}, "waterfall": wf}  # fmt: skip


# ----------------------------------------------------------------------------- persisted explanations
def global_explanation(session: Session, principal: Principal, run_id: int) -> Explanation:
    run = get_owned(session, ModelRun, principal.tenant_id, run_id, label="Model run")
    if run.status != "completed":
        raise Conflict(f"model run is {run.status}; only completed runs can be explained")
    dataset = session.get(MLDataset, run.dataset_id)
    bundle = training.load_bundle(run)
    frame = mlprep.load_split(dataset, "valid")
    if len(frame) > GLOBAL_SAMPLE:
        frame = frame.sample(GLOBAL_SAMPLE, random_state=run.seed).reset_index(drop=True)
    result = shap_values(bundle, frame)
    common = {"tenant_id": run.tenant_id, "scope": "global", "model_run_id": run.id,
              "contract_version": str((dataset.config or {}).get("contract_schema_hash", ""))[:140]}  # fmt: skip
    if result["status"] != "available":
        explanation = Explanation(**common, status="unavailable", reason=result["reason"])
    else:
        contrib = aggregate_to_features(bundle, result["values"])
        mean_abs = contrib.abs().mean().sort_values(ascending=False)
        total = float(mean_abs.sum()) or 1.0
        rows = []
        for name, importance in mean_abs.items():
            spec = feature_engine.SPECS[name]
            direction = None
            if spec.dtype != "category":
                x = pd.to_numeric(frame[name], errors="coerce")
                if x.notna().sum() > 10 and x.nunique() > 1 and contrib[name].nunique() > 1:
                    corr = np.corrcoef(x.fillna(x.median()).to_numpy(), contrib[name].to_numpy())[0, 1]
                    direction = None if np.isnan(corr) else ("higher value -> higher predicted risk" if corr > 0
                                                             else "higher value -> lower predicted risk")  # fmt: skip
            rows.append({"feature": name, "label": spec.label, "group": spec.group, "mean_abs_shap": float(importance),
                         "share": float(importance / total), "mean_shap": float(contrib[name].mean()), "direction": direction})  # fmt: skip
        groups = pd.Series({r["feature"]: r["mean_abs_shap"] for r in rows}).groupby(lambda n: feature_engine.SPECS[n].group).sum()
        explanation = Explanation(
            **common, status="available", method=result["method"], space=result["space"], base_value=result["base_value"],
            additivity_error=float(result["additivity_error"].max()),
            contributions=json_safe({"features": rows, "groups": {k: float(v) for k, v in groups.sort_values(ascending=False).items()},
                                     "sample_rows": int(len(frame)), "sample_source": "validation split", "disclaimer": NOT_CAUSAL}))  # fmt: skip
    session.add(explanation)
    session.flush()
    audit.record(session, tenant_id=run.tenant_id, actor=principal, action="ml.global_explanation", entity_type="model_run",
                 entity_id=run.id, detail={"status": explanation.status, "explanation_id": explanation.id})  # fmt: skip
    return explanation


def latest_global(session: Session, tenant_id: int, run_id: int) -> Explanation | None:
    return session.execute(select(Explanation).where(Explanation.tenant_id == tenant_id, Explanation.model_run_id == run_id,
                                                     Explanation.scope == "global").order_by(Explanation.id.desc())).scalars().first()  # fmt: skip


def explanation_view(explanation: Explanation) -> dict:
    return to_dict(explanation)
