"""CRM connections that sign in with OAuth 2.0 (authorization code), and signed events coming back from the CRM.

Tokens are stored encrypted and refreshed before they expire.  A refresh that the vendor refuses marks the
connection as needing a new authorisation; nothing is sent with a token that is known to be dead.  Disconnecting
revokes the token at the vendor where the vendor offers that, and always erases it here.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
from datetime import timedelta
from typing import Any
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import netguard
from ..config import get_settings
from ..db import session_scope, utcnow
from ..errors import Conflict, ExternalServiceError, Unauthorized, ValidationFailed
from ..models import CRMConnection, CRMDelivery, CRMOAuthState, CRMWebhookEvent
from ..security import Principal, SecretBox, hash_token
from . import audit
from .common import get_owned, to_dict

PROFILES: dict[str, dict[str, Any]] = {
    # "token" is the address of the vendor's token endpoint, not a credential (hence the nosec marks)
    "salesforce": {"authorize": "https://login.salesforce.com/services/oauth2/authorize", "token": "https://login.salesforce.com/services/oauth2/token",  # nosec B105
                   "revoke": "https://login.salesforce.com/services/oauth2/revoke", "scopes": ["api", "refresh_token"], "pkce": True},
    "hubspot": {"authorize": "https://app.hubspot.com/oauth/authorize", "token": "https://api.hubapi.com/oauth/v1/token", "revoke": None,  # nosec B105
                "scopes": ["crm.objects.companies.write", "crm.objects.companies.read"], "pkce": False},
    "intercom": {"authorize": "https://app.intercom.com/oauth", "token": "https://api.intercom.io/auth/eagle/token", "revoke": None, "scopes": [], "pkce": False},  # nosec B105
}  # fmt: skip
STATE_TTL = timedelta(minutes=10)
REFRESH_MARGIN = timedelta(seconds=90)
_transport: httpx.BaseTransport | None = None


def set_transport(transport: httpx.BaseTransport | None) -> None:
    global _transport
    _transport = transport


def endpoints(connection: CRMConnection) -> dict:
    return {**PROFILES[connection.provider], **(connection.oauth_endpoints or {})}


def redirect_uri(request_base: str = "") -> str:
    return f"{(get_settings().public_base_url or request_base).rstrip('/')}/api/v1/crm/oauth/callback"


def configure(session: Session, principal: Principal, connection_id: int, *, client_id: str, client_secret: str, scopes: list[str] | None = None,
              oauth_endpoints: dict | None = None, webhook_secret: str | None = None) -> CRMConnection:
    """Give a connection its OAuth application.  Nothing is authorised yet: that needs the consent screen."""
    connection = get_owned(session, CRMConnection, principal.tenant_id, connection_id, label="CRM connection")
    if not client_id.strip() or not client_secret:
        raise ValidationFailed("client_id and client_secret are required", details={"field": "client_id"})
    overrides = {k: v for k, v in (oauth_endpoints or {}).items() if k in ("authorize", "token", "revoke") and v}
    for name, url in overrides.items():
        if not str(url).startswith("https://") and get_settings().env not in ("development", "test"):
            raise ValidationFailed(f"the {name} endpoint must use https", details={"field": "oauth_endpoints"})
    connection.auth_type, connection.client_id, connection.client_secret_enc = "oauth", client_id.strip(), SecretBox().encrypt(client_secret)
    connection.scopes, connection.oauth_endpoints = list(scopes) if scopes is not None else PROFILES[connection.provider]["scopes"], overrides or None
    if webhook_secret:
        connection.webhook_secret_enc = SecretBox().encrypt(webhook_secret)
    connection.health = {"state": "authorisation_needed", "since": utcnow().isoformat()}
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="crm.oauth_configured", entity_type="crm_connection", entity_id=connection.id,
                 detail={"provider": connection.provider, "scopes": connection.scopes})  # fmt: skip
    return connection


def begin(session: Session, principal: Principal, connection_id: int, *, request_base: str = "") -> dict:
    connection = get_owned(session, CRMConnection, principal.tenant_id, connection_id, label="CRM connection")
    if connection.auth_type != "oauth" or not connection.client_id:
        raise Conflict("configure the OAuth application of this connection first", code="oauth_not_configured")
    profile, state, verifier = endpoints(connection), secrets.token_urlsafe(32), secrets.token_urlsafe(64)
    uri = redirect_uri(request_base)
    session.add(CRMOAuthState(tenant_id=connection.tenant_id, connection_id=connection.id, state_hash=hash_token(state),
                              code_verifier_enc=SecretBox().encrypt(verifier), redirect_uri=uri, created_by=principal.user_id, expires_at=utcnow() + STATE_TTL))  # fmt: skip
    query = {"response_type": "code", "client_id": connection.client_id, "redirect_uri": uri, "state": state}
    if connection.scopes:
        query["scope"] = " ".join(connection.scopes)
    if profile.get("pkce"):
        query.update({"code_challenge": base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode(), "code_challenge_method": "S256"})
    return {"authorization_url": f"{profile['authorize']}?{urlencode(query)}", "redirect_uri": uri}


def _token_call(connection: CRMConnection, form: dict) -> dict:
    settings = get_settings()
    url = endpoints(connection)["token"]
    target = netguard.vet(url, allow_private=settings.crm_allow_private_hosts, field_name="token endpoint", resolve=_transport is None)
    form = {**form, "client_id": connection.client_id, "client_secret": SecretBox().decrypt(connection.client_secret_enc)}
    try:
        with httpx.Client(timeout=settings.crm_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
            response = client.post(target.url, data=form, headers={"Accept": "application/json", **target.headers}, extensions=target.extensions)
    except httpx.HTTPError as exc:
        raise ExternalServiceError(f"the CRM's token endpoint could not be reached ({type(exc).__name__})") from exc
    try:
        body = response.json()
    except ValueError:
        body = {}
    if response.status_code != 200 or not isinstance(body, dict) or not body.get("access_token"):
        error = body.get("error") if isinstance(body, dict) else None
        raise Unauthorized(f"the CRM refused the authorisation ({error or 'HTTP ' + str(response.status_code)})", code="crm_oauth_refused",
                           details={"vendor_error": error, "http_status": response.status_code})  # fmt: skip
    return body


def _store_tokens(connection: CRMConnection, body: dict) -> None:
    now = utcnow()
    connection.credentials_enc = SecretBox().encrypt(body["access_token"])
    if body.get("refresh_token"):
        connection.refresh_token_enc = SecretBox().encrypt(body["refresh_token"])
    expires = body.get("expires_in")
    connection.token_expires_at = now + timedelta(seconds=int(expires)) if isinstance(expires, int | float) or (isinstance(expires, str) and expires.isdigit()) else None
    if body.get("scope"):
        connection.scopes = str(body["scope"]).split()
    if connection.provider == "salesforce" and body.get("instance_url"):
        instance = str(body["instance_url"]).rstrip("/")
        netguard.vet(instance, allow_private=get_settings().crm_allow_private_hosts, field_name="instance_url", resolve=_transport is None)
        connection.base_url = instance
    connection.status, connection.last_error, connection.last_checked_at, connection.disconnected_at = "connected", None, now, None
    connection.health = {"state": "connected", "since": now.isoformat(), "token_expires_at": connection.token_expires_at.isoformat() if connection.token_expires_at else None,
                         "can_refresh": bool(connection.refresh_token_enc)}  # fmt: skip


def callback(session: Session, *, state: str | None, code: str | None, error: str | None = None) -> CRMConnection:
    """The CRM sent the browser back from its consent screen."""
    entry = session.execute(select(CRMOAuthState).where(CRMOAuthState.state_hash == hash_token(state or ""))).scalar_one_or_none()
    now = utcnow()
    if entry is None or entry.used_at is not None or entry.expires_at <= now:
        raise Unauthorized("this authorisation was not started here, has expired, or was already completed", code="crm_oauth_state_invalid")
    entry.used_at = now
    connection = session.get(CRMConnection, entry.connection_id)
    if error or not code:
        connection.health = {"state": "authorisation_refused", "since": now.isoformat(), "vendor_error": (error or "no code")[:100]}
        audit.record(session, tenant_id=connection.tenant_id, action="crm.oauth_refused", entity_type="crm_connection", entity_id=connection.id,
                     detail={"vendor_error": (error or "no code")[:100]})  # fmt: skip
        session.commit()
        raise Unauthorized("the CRM did not grant access", code="crm_oauth_refused")
    form = {"grant_type": "authorization_code", "code": code, "redirect_uri": entry.redirect_uri}
    if endpoints(connection).get("pkce"):
        form["code_verifier"] = SecretBox().decrypt(entry.code_verifier_enc)
    _store_tokens(connection, _token_call(connection, form))
    audit.record(session, tenant_id=connection.tenant_id, action="crm.oauth_connected", entity_type="crm_connection", entity_id=connection.id,
                 detail={"provider": connection.provider, "scopes": connection.scopes, "expires": connection.token_expires_at is not None})  # fmt: skip
    return connection


def ensure_fresh_token(connection_id: int, *, force: bool = False) -> None:
    """Refresh the access token when it is about to expire (or when the vendor just said it is not valid)."""
    with session_scope() as ws:
        connection = ws.get(CRMConnection, connection_id)
        if connection is None or connection.auth_type != "oauth" or not connection.credentials_enc:
            return
        due = connection.token_expires_at is not None and connection.token_expires_at - REFRESH_MARGIN <= utcnow()
        if not (due or force):
            return
        if not connection.refresh_token_enc:
            if force or due:
                connection.status, connection.health = "reauthorisation_required", {"state": "reauthorisation_required", "since": utcnow().isoformat(),
                                                                                     "reason": "the token is no longer valid and the CRM issued no refresh token"}  # fmt: skip
            return
        try:
            body = _token_call(connection, {"grant_type": "refresh_token", "refresh_token": SecretBox().decrypt(connection.refresh_token_enc)})
        except Unauthorized as exc:
            connection.status, connection.last_error = "reauthorisation_required", exc.message[:400]
            connection.health = {"state": "reauthorisation_required", "since": utcnow().isoformat(), "reason": exc.message}
            audit.record(ws, tenant_id=connection.tenant_id, action="crm.oauth_refresh_refused", entity_type="crm_connection", entity_id=connection.id,
                         detail=exc.details if isinstance(exc.details, dict) else None)  # fmt: skip
            return
        except ExternalServiceError as exc:
            connection.last_error = exc.message[:400]  # temporary: the old token is kept and the next delivery tries again
            return
        _store_tokens(connection, body)
        audit.record(ws, tenant_id=connection.tenant_id, action="crm.oauth_token_refreshed", entity_type="crm_connection", entity_id=connection.id)


def disconnect(session: Session, principal: Principal, connection_id: int) -> CRMConnection:
    connection = get_owned(session, CRMConnection, principal.tenant_id, connection_id, label="CRM connection")
    revoked: bool | None = None
    revoke_url = endpoints(connection).get("revoke") if connection.auth_type == "oauth" else None
    token = connection.refresh_token_enc or connection.credentials_enc
    if revoke_url and token:
        try:
            target = netguard.vet(revoke_url, allow_private=get_settings().crm_allow_private_hosts, field_name="revoke endpoint", resolve=_transport is None)
            with httpx.Client(timeout=get_settings().crm_http_timeout_seconds, transport=_transport, follow_redirects=False) as client:
                response = client.post(target.url, data={"token": SecretBox().decrypt(token)}, headers=target.headers, extensions=target.extensions)
            revoked = response.status_code == 200
        except (httpx.HTTPError, ValidationFailed):
            revoked = False
    connection.credentials_enc, connection.refresh_token_enc, connection.token_expires_at = None, None, None
    connection.status, connection.disconnected_at = "disconnected", utcnow()
    connection.health = {"state": "disconnected", "since": utcnow().isoformat(),
                         "revoked_at_vendor": revoked if revoked is not None else "the vendor offers no revocation endpoint; remove the app's access in the CRM"}  # fmt: skip
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="crm.disconnected", entity_type="crm_connection", entity_id=connection.id,
                 detail={"revoked_at_vendor": revoked})  # fmt: skip
    return connection


# ----------------------------------------------------------------------------- events from the CRM
def verify_signature(connection: CRMConnection, *, method: str, url: str, body: bytes, headers: dict[str, str]) -> bool:
    """HubSpot: v3 signature (HMAC-SHA256 of method + URL + body + timestamp, keyed with the app's client secret).
    Intercom: ``X-Hub-Signature`` (HMAC-SHA1 of the body, keyed with the client secret).
    Anything else: ``X-Signature: sha256=<hex HMAC-SHA256 of the body>`` keyed with the connection's webhook secret."""
    lower = {k.lower(): v for k, v in headers.items()}
    if connection.provider == "hubspot" and connection.client_secret_enc and lower.get("x-hubspot-signature-v3"):
        stamp = lower.get("x-hubspot-request-timestamp", "")
        if not stamp.isdigit() or abs(utcnow().timestamp() * 1000 - int(stamp)) > 5 * 60 * 1000:
            return False
        mac = hmac.new(SecretBox().decrypt(connection.client_secret_enc).encode(), f"{method}{url}".encode() + body + stamp.encode(), hashlib.sha256).digest()
        return hmac.compare_digest(base64.b64encode(mac).decode(), lower["x-hubspot-signature-v3"])
    if connection.provider == "intercom" and connection.client_secret_enc and lower.get("x-hub-signature"):
        mac = hmac.new(SecretBox().decrypt(connection.client_secret_enc).encode(), body, hashlib.sha1).hexdigest()
        return hmac.compare_digest(f"sha1={mac}", lower["x-hub-signature"])
    if connection.webhook_secret_enc and lower.get("x-signature"):
        mac = hmac.new(SecretBox().decrypt(connection.webhook_secret_enc).encode(), body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(mac, lower["x-signature"].removeprefix("sha256=").strip())
    return False


def receive(session: Session, connection_id: int, *, method: str, url: str, body: bytes, headers: dict[str, str]) -> dict:
    """Store signed CRM events once each and apply the ones the platform understands: a HubSpot property-change
    event for the risk-score property confirms that the CRM holds the value that was sent."""
    connection = session.get(CRMConnection, connection_id)
    if connection is None or not verify_signature(connection, method=method, url=url, body=body, headers=headers):
        raise Unauthorized("the signature of this webhook is not valid", code="webhook_signature_invalid")
    try:
        events = json.loads(body)
        events = events if isinstance(events, list) else [events]
    except ValueError as exc:
        raise ValidationFailed("the webhook body is not JSON") from exc
    mapping = connection.field_mapping or {}
    stored = duplicates = verified = 0
    for event in events[:1000]:
        if not isinstance(event, dict):
            continue
        key = str(event.get("eventId") or event.get("id") or hashlib.sha256(json.dumps(event, sort_keys=True).encode()).hexdigest())[:200]
        if session.execute(select(CRMWebhookEvent.id).where(CRMWebhookEvent.connection_id == connection.id, CRMWebhookEvent.event_key == key)).first():
            duplicates += 1
            continue
        kind = str(event.get("subscriptionType") or event.get("topic") or event.get("type") or "unknown")[:80]
        entry = CRMWebhookEvent(tenant_id=connection.tenant_id, connection_id=connection.id, event_key=key, event_type=kind, payload=event, status="received", attempts=1)
        session.add(entry)
        stored += 1
        if kind.endswith("propertyChange") and event.get("propertyName") == mapping.get("probability") and event.get("objectId") is not None:
            delivery = session.execute(select(CRMDelivery).where(CRMDelivery.connection_id == connection.id, CRMDelivery.kind == "risk_score",
                                                                 CRMDelivery.external_id == str(event["objectId"]), CRMDelivery.status == "sent")
                                       .order_by(CRMDelivery.id.desc()).limit(1)).scalar_one_or_none()  # fmt: skip
            if delivery is not None:
                sent, held = (delivery.payload or {}).get("probability"), event.get("propertyValue")
                try:
                    matches = sent is not None and abs(float(held) - float(sent)) < 1e-6
                except (TypeError, ValueError):
                    matches = False
                delivery.verified_at = utcnow()
                delivery.verification = {"source": "crm property-change event", "event_key": key, "value_in_crm": held, "value_sent": sent, "matches": matches}
                entry.status, entry.outcome, entry.processed_at = "processed", {"delivery_id": delivery.id, "matches": matches}, utcnow()
                verified += 1
                continue
        entry.status, entry.processed_at = "ignored", utcnow()
    return {"received": len(events), "stored": stored, "duplicates": duplicates, "deliveries_verified": verified}


def events(session: Session, tenant_id: int, connection_id: int, limit: int = 50) -> list[dict]:
    get_owned(session, CRMConnection, tenant_id, connection_id, label="CRM connection")
    rows = session.execute(select(CRMWebhookEvent).where(CRMWebhookEvent.connection_id == connection_id).order_by(CRMWebhookEvent.id.desc()).limit(limit)).scalars().all()
    return [to_dict(r) for r in rows]
