"""Model evaluation: PR-AUC first, calibration, lift, and cost-matrix threshold optimisation.

All monetary arithmetic uses ``Decimal``.  No financial figure is ever invented: the cost matrix
must be an approved policy entered by the business, and results computed from a policy flagged
``is_example`` are labelled illustrative.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import money, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import MLDataset, ModelEvaluation, ModelRun, Policy
from ..security import Principal
from . import audit, mlprep, policies, training
from .common import get_owned, json_safe, to_dict
from .policies import CostMatrix

MAX_CURVE_POINTS = 200
SEGMENT_FEATURES = ("plan_tier", "company_size", "region", "billing_period")


def _downsample(*arrays: np.ndarray) -> list[np.ndarray]:
    n = len(arrays[0])
    if n <= MAX_CURVE_POINTS:
        return list(arrays)
    idx = np.unique(np.linspace(0, n - 1, MAX_CURVE_POINTS).astype(int))
    return [a[idx] for a in arrays]


def expected_calibration_error(y: np.ndarray, p: np.ndarray, bins: int = 10) -> tuple[float, list[dict]]:
    """ECE over equal-frequency bins, plus the reliability table."""
    order = np.argsort(p, kind="stable")
    table, ece = [], 0.0
    for chunk in np.array_split(order, min(bins, max(1, len(y) // 5))):
        if len(chunk) == 0:
            continue
        mean_p, rate = float(p[chunk].mean()), float(y[chunk].mean())
        ece += abs(mean_p - rate) * len(chunk) / len(y)
        table.append({"n": int(len(chunk)), "mean_predicted": mean_p, "observed_rate": rate})
    return float(ece), table


def core_metrics(y: np.ndarray, p: np.ndarray, *, seed: int = 0, bootstrap: int = 200) -> dict:
    """Threshold-free quality metrics.  PR-AUC (average precision) is the headline metric."""
    from sklearn.metrics import average_precision_score, brier_score_loss, log_loss, roc_auc_score

    y = np.asarray(y).astype(int)
    p = np.asarray(p, dtype="float64")
    n, pos = len(y), int(y.sum())
    out: dict[str, Any] = {"n": n, "positives": pos, "base_rate": pos / n if n else None, "pr_auc": None, "roc_auc": None,
                           "brier": None, "log_loss": None, "ece": None, "pr_auc_baseline": pos / n if n else None}  # fmt: skip
    if n == 0 or pos == 0 or pos == n:
        out["note"] = "metrics are undefined because the sample contains a single class"
        return out
    out["pr_auc"] = float(average_precision_score(y, p))
    out["roc_auc"] = float(roc_auc_score(y, p))
    out["brier"] = float(brier_score_loss(y, p))
    out["log_loss"] = float(log_loss(y, np.clip(p, 1e-9, 1 - 1e-9), labels=[0, 1]))
    out["ece"], _ = expected_calibration_error(y, p)
    out["pr_auc_lift_over_baseline"] = out["pr_auc"] / out["pr_auc_baseline"]
    if bootstrap:
        rng = np.random.default_rng(seed)
        samples = []
        for _ in range(bootstrap):
            idx = rng.integers(0, n, n)
            if 0 < y[idx].sum() < n:
                samples.append(average_precision_score(y[idx], p[idx]))
        if len(samples) >= 20:
            out["pr_auc_ci95"] = [float(np.percentile(samples, 2.5)), float(np.percentile(samples, 97.5))]
            out["pr_auc_ci_method"] = f"percentile bootstrap, {len(samples)} resamples"
    return out


def curves(y: np.ndarray, p: np.ndarray) -> dict:
    from sklearn.metrics import precision_recall_curve, roc_curve

    y = np.asarray(y).astype(int)
    precision, recall, _ = precision_recall_curve(y, p)
    fpr, tpr, _ = roc_curve(y, p)
    pr_r, pr_p = _downsample(recall[::-1], precision[::-1])
    roc_f, roc_t = _downsample(fpr, tpr)
    _, reliability = expected_calibration_error(y, p)
    order = np.argsort(-p, kind="stable")
    deciles = []
    total_pos = max(int(y.sum()), 1)
    captured = 0
    for rank, chunk in enumerate(np.array_split(order, 10), start=1):
        hits = int(y[chunk].sum())
        captured += hits
        deciles.append({"decile": rank, "n": int(len(chunk)), "churners": hits,
                        "churn_rate": float(hits / len(chunk)) if len(chunk) else None,
                        "lift": float((hits / len(chunk)) / (y.mean())) if len(chunk) and y.mean() > 0 else None,
                        "cumulative_capture": float(captured / total_pos)})  # fmt: skip
    return {"pr": {"recall": pr_r.tolist(), "precision": pr_p.tolist()}, "roc": {"fpr": roc_f.tolist(), "tpr": roc_t.tolist()},
            "calibration": reliability, "deciles": deciles}  # fmt: skip


def confusion_at(y: np.ndarray, p: np.ndarray, threshold: float) -> dict:
    y = np.asarray(y).astype(int)
    flag = p >= threshold
    tp, fp = int((flag & (y == 1)).sum()), int((flag & (y == 0)).sum())
    fn, tn = int((~flag & (y == 1)).sum()), int((~flag & (y == 0)).sum())
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * precision * recall / (precision + recall) if precision and recall else None
    return {"threshold": float(threshold), "tp": tp, "fp": fp, "fn": fn, "tn": tn, "flagged": tp + fp, "precision": precision,
            "recall": recall, "f1": f1}  # fmt: skip


def best_f1_threshold(y: np.ndarray, p: np.ndarray) -> dict:
    """Non-financial fallback threshold (maximum F1) used only when no cost matrix is approved."""
    best = None
    for t in np.unique(np.round(p, 4)):
        c = confusion_at(y, p, float(t))
        if c["f1"] is not None and (best is None or c["f1"] > best["f1"]):
            best = c
    return best or confusion_at(y, p, 0.5)


def optimise_threshold(y: np.ndarray, p: np.ndarray, cost: CostMatrix, *, mrr: np.ndarray | None = None,
                       groups: np.ndarray | None = None) -> dict:
    """Choose the probability threshold that minimises total expected cost under the cost matrix.

    Per flagged customer the intervention costs ``intervention_cost``.  A churner who is flagged is
    saved with probability ``save_rate``; the value at stake for a churner is CLV x contribution
    margin (a fixed CLV, or the customer's own MRR x ``clv_months``).

        cost(FP) = intervention_cost
        cost(FN) = value
        cost(TP) = intervention_cost + (1 - save_rate) * value
        cost(TN) = 0

    ``capacity`` (if set) limits how many customers may be flagged per scoring date.
    """
    y = np.asarray(y).astype(int)
    p = np.asarray(p, dtype="float64")
    n = len(y)
    if cost.clv_mode == "mrr_multiple":
        if mrr is None:
            raise ValidationFailed("this cost matrix values customers by MRR, but the dataset has no 'mrr' feature")
        values = [money(Decimal(repr(float(m))) * cost.clv_months * cost.contribution_margin) if np.isfinite(m) else Decimal("0")
                  for m in mrr]  # fmt: skip
    else:
        values = [money(cost.clv * cost.contribution_margin)] * n
    order = np.argsort(-p, kind="stable")
    zero = Decimal("0")
    total_value_at_risk = sum((values[i] for i in range(n) if y[i] == 1), zero)
    do_nothing_cost = total_value_at_risk
    # cumulative sums along the ranking: flagging the top-k customers
    cum_tp, cum_fp, cum_value = 0, 0, zero
    rows, k = [], 0
    candidates = sorted({round(float(t), 4) for t in np.linspace(0.01, 0.99, 99)} | {round(float(q), 4) for q in np.quantile(p, np.linspace(0, 1, 51))}, reverse=True)
    group_counts: dict[Any, int] = {}
    max_group = 0
    for threshold in candidates:
        while k < n and p[order[k]] >= threshold:
            i = order[k]
            if y[i] == 1:
                cum_tp += 1
                cum_value += values[i]
            else:
                cum_fp += 1
            if groups is not None:
                group_counts[groups[i]] = group_counts.get(groups[i], 0) + 1
                max_group = max(max_group, group_counts[groups[i]])
            k += 1
        flagged = cum_tp + cum_fp
        fn = int(y.sum()) - cum_tp
        intervention = cost.intervention_cost * flagged + (cost.campaign_fixed_cost if flagged else zero)
        lost_fn = total_value_at_risk - cum_value
        lost_tp = (Decimal("1") - cost.save_rate) * cum_value
        total_cost = money(intervention + lost_fn + lost_tp)
        peak = max_group if groups is not None else flagged
        rows.append({"threshold": threshold, "flagged": flagged, "tp": cum_tp, "fp": cum_fp, "fn": fn, "tn": n - flagged - fn,
                     "precision": cum_tp / flagged if flagged else None, "recall": cum_tp / int(y.sum()) if y.sum() else None,
                     "total_cost": total_cost, "net_benefit_vs_no_action": money(do_nothing_cost - total_cost),
                     "max_flagged_per_date": peak, "within_capacity": cost.capacity is None or peak <= cost.capacity})  # fmt: skip
    feasible = [r for r in rows if r["within_capacity"]]
    no_action = {"threshold": None, "flagged": 0, "total_cost": money(do_nothing_cost), "net_benefit_vs_no_action": money(zero)}
    best = min(feasible, key=lambda r: (r["total_cost"], -r["threshold"])) if feasible else None
    act = best is not None and best["total_cost"] < money(do_nothing_cost)
    return {
        "currency": cost.currency, "is_example": cost.is_example, "capacity": cost.capacity,
        "assumptions": {"intervention_cost": str(cost.intervention_cost), "clv_mode": cost.clv_mode,
                        "clv": None if cost.clv is None else str(cost.clv),
                        "clv_months": None if cost.clv_months is None else str(cost.clv_months),
                        "contribution_margin": str(cost.contribution_margin), "save_rate": str(cost.save_rate),
                        "campaign_fixed_cost": str(cost.campaign_fixed_cost), "evidence": cost.evidence},
        "do_nothing_cost": str(money(do_nothing_cost)),
        "optimal": json_safe(best) if act else json_safe(no_action),
        "recommendation": ("intervene_above_threshold" if act else "no_threshold_beats_doing_nothing"),
        "table": json_safe(rows),
        "disclaimer": ("ILLUSTRATIVE ONLY: the cost matrix is flagged as an example, not approved business figures. "
                       if cost.is_example else "") + "Expected values depend entirely on the stated assumptions (save rate, "
                      "CLV, margin); they are scenario arithmetic, not a forecast or a measured return.",
    }  # fmt: skip


# ----------------------------------------------------------------------------- persisted evaluations
def _segment_metrics(frame: pd.DataFrame, p: np.ndarray, threshold: float) -> dict:
    out: dict[str, list[dict]] = {}
    for col in SEGMENT_FEATURES:
        if col not in frame.columns:
            continue
        groups = []
        for value, idx in frame.groupby(frame[col].fillna("(missing)").astype(str)).indices.items():
            y = frame["label"].to_numpy()[idx]
            c = confusion_at(y, p[idx], threshold)
            groups.append({"segment": value, "n": int(len(idx)), "churners": int(y.sum()), "base_rate": float(y.mean()),
                           "mean_predicted": float(p[idx].mean()), "precision": c["precision"], "recall": c["recall"]})  # fmt: skip
        out[col] = sorted(groups, key=lambda g: -g["n"])
    return out


def evaluate(session: Session, principal: Principal, run_id: int, *, split: str = "valid", cost_policy_id: int | None = None) -> ModelEvaluation:
    """Evaluate a trained run on VALIDATION (repeatable) or on TEST (final, exactly once, audited)."""
    run = get_owned(session, ModelRun, principal.tenant_id, run_id, label="Model run")
    if run.status != "completed":
        raise Conflict(f"model run is {run.status}; only completed runs can be evaluated")
    if split not in ("valid", "test"):
        raise ValidationFailed("split must be 'valid' or 'test'", details={"field": "split"})
    dataset = session.get(MLDataset, run.dataset_id)
    cost_policy: Policy | None = None
    if cost_policy_id:
        cost_policy = policies.get_approved(session, principal.tenant_id, cost_policy_id, "cost_matrix")
    else:
        cost_policy = policies.get_active(session, principal.tenant_id, "cost_matrix", required=False)
    bundle = training.load_bundle(run)
    valid = mlprep.load_split(dataset, "valid")
    p_valid = training.predict_proba(bundle, valid)
    y_valid = valid["label"].to_numpy()
    analysis: dict[str, Any]
    if cost_policy is not None:
        cost = policies.parse(cost_policy)
        mrr = valid["mrr"].to_numpy(dtype="float64") if "mrr" in valid.columns else None
        analysis = optimise_threshold(y_valid, p_valid, cost, mrr=mrr, groups=valid["as_of_date"].to_numpy())
        analysis["basis"] = "cost_matrix"
        analysis["cost_policy"] = {"id": cost_policy.id, "name": cost_policy.name, "version": cost_policy.version}
        threshold = analysis["optimal"]["threshold"]
        if threshold is None:  # nothing beats doing nothing: fall back so a confusion matrix can still be shown
            threshold = best_f1_threshold(y_valid, p_valid)["threshold"]
            analysis["operating_threshold_note"] = "no cost-effective threshold exists; the max-F1 threshold is shown for reference only"
    else:
        threshold = best_f1_threshold(y_valid, p_valid)["threshold"]
        analysis = {"basis": "max_f1", "note": "No approved cost matrix exists, so no financial optimisation was performed. "
                                               "The threshold maximises F1 on the validation split."}  # fmt: skip
    analysis["threshold"] = float(threshold)
    analysis["threshold_selected_on"] = "validation split"
    if split == "test":
        if run.test_evaluated_at is not None:
            existing = session.execute(select(ModelEvaluation).where(ModelEvaluation.model_run_id == run.id, ModelEvaluation.split == "test")
                                       .order_by(ModelEvaluation.id.desc())).scalars().first()  # fmt: skip
            raise Conflict("the TEST split has already been used for this model's final evaluation; it cannot be re-run",
                           code="test_already_evaluated", details={"evaluation_id": existing.id if existing else None})  # fmt: skip
        frame = mlprep.load_split(dataset, "test", purpose=mlprep.TEST_PURPOSE)
        p = training.predict_proba(bundle, frame)
    else:
        frame, p = valid, p_valid
    y = frame["label"].to_numpy()
    metrics = core_metrics(y, p, seed=run.seed)
    metrics["at_threshold"] = confusion_at(y, p, threshold)
    if split == "test" and cost_policy is not None:
        # apply (do not re-optimise) the validation-chosen threshold to the test split
        mrr = frame["mrr"].to_numpy(dtype="float64") if "mrr" in frame.columns else None
        test_table = optimise_threshold(y, p, policies.parse(cost_policy), mrr=mrr, groups=frame["as_of_date"].to_numpy())
        nearest = min(test_table["table"], key=lambda r: abs(r["threshold"] - threshold))
        analysis["test_outcome_at_validation_threshold"] = nearest
        analysis["test_do_nothing_cost"] = test_table["do_nothing_cost"]
    evaluation = ModelEvaluation(tenant_id=run.tenant_id, model_run_id=run.id, split=split, metrics=json_safe(metrics),
                                 curves=json_safe(curves(y, p)), threshold_analysis=json_safe(analysis),
                                 subgroups=json_safe(_segment_metrics(frame, p, threshold)),
                                 cost_policy_id=cost_policy.id if cost_policy else None, created_by=principal.user_id)  # fmt: skip
    session.add(evaluation)
    if split == "test":
        run.test_metrics, run.test_evaluated_at = json_safe(metrics), utcnow()
    session.flush()
    audit.record(session, tenant_id=run.tenant_id, actor=principal, action=f"ml.evaluated_{split}", entity_type="model_run",
                 entity_id=run.id, detail={"evaluation_id": evaluation.id, "pr_auc": metrics.get("pr_auc"),
                                           "threshold": threshold, "basis": analysis["basis"]})  # fmt: skip
    return evaluation


def evaluation_view(evaluation: ModelEvaluation) -> dict:
    return to_dict(evaluation)
