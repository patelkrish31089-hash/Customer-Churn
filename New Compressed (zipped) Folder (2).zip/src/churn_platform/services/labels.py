"""Churn label generation under a versioned, approved churn definition.

For an as-of date ``T`` (the instant T 00:00 UTC) a customer is

* ``ineligible``  - not a paying subscriber at T (no active paid subscription, still in trial,
                    below the minimum tenure) or the subscription ends for an excluded reason;
* ``churned``     - eligible and, per the multi-subscription rule, the subscription state ends in
                    ``[T, T + horizon)`` without being reactivated within the reactivation window;
* ``retained``    - eligible and still subscribed at ``T + horizon``;
* ``immature``    - eligible but the observation window ``T + horizon + reactivation window`` lies
                    beyond the data cutoff (right-censored: the outcome is not knowable yet);
* ``unknown``     - eligible but the subscription history is contradictory.

Eligibility uses only information before T; the outcome necessarily uses the window after T and
is therefore never exposed to feature engineering.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Any

import pandas as pd
from sqlalchemy import delete, func, insert, select
from sqlalchemy.orm import Session

from ..db import read_session, session_scope, utcnow
from ..errors import Conflict, ValidationFailed
from ..models import ChurnLabel, Customer, LabelRun, Policy
from ..security import Principal
from . import audit, jobs, policies, timeline
from .common import get_owned, json_safe, parse_date, to_dict
from .policies import ChurnDefinition

MAX_AS_OF_DATES = 120


def month_starts(first: date, last: date) -> list[date]:
    out, cur = [], date(first.year, first.month, 1)
    while cur <= last:
        if cur >= first:
            out.append(cur)
        cur = date(cur.year + (cur.month == 12), cur.month % 12 + 1, 1)
    return out


def classify_reason(defn: ChurnDefinition, reason: str | None) -> str:
    if reason in defn.voluntary_reasons:
        return "voluntary"
    if reason in defn.involuntary_reasons:
        return "involuntary"
    if reason in defn.excluded_reasons:
        return "excluded"
    return "unknown"


def compute_labels(frames: dict[str, pd.DataFrame], defn: ChurnDefinition, as_of_dates: list[date],
                   cutoff: datetime | pd.Timestamp, intervals: pd.DataFrame | None = None) -> pd.DataFrame:
    """Pure function: label every existing customer at every as-of date."""
    cutoff = timeline.ts(cutoff)
    if intervals is None:
        intervals = timeline.build_intervals(frames, defn.grace_period_days, cutoff)
    paid = timeline.paid_intervals(intervals, defn.include_trials)
    horizon = pd.Timedelta(days=defn.horizon_days)
    reactivation = defn.reactivation_window_days
    rule = defn.multi_subscription_rule
    block_key = "customer_id" if rule == "all" else "subscription_id"
    blocks = timeline.merge_blocks(paid, block_key, reactivation)
    if rule != "all":
        owner = paid.drop_duplicates("subscription_id").set_index("subscription_id")["customer_id"]
        blocks["customer_id"] = blocks["subscription_id"].map(owner)
    mrr = frames["subscriptions"].set_index("id")["mrr"].fillna(0.0)
    first_start = paid.groupby("customer_id")["paid_start"].min()
    problem_customers = set(intervals.loc[intervals["problem"], "customer_id"])
    customers = frames["customers"][["id", "acquired_at"]]
    first_seen = intervals.groupby("customer_id")["start"].min()
    out: list[dict] = []
    for as_of in as_of_dates:
        t0 = timeline.ts(as_of)
        window_end = t0 + horizon
        mature = window_end + pd.Timedelta(days=reactivation) <= cutoff + pd.Timedelta(seconds=1)
        active_raw = timeline.active_at(paid, t0, "paid_start")
        active_any = timeline.active_at(intervals, t0)
        trial_only = set(active_any["customer_id"]) - set(active_raw["customer_id"])
        n_active = active_raw.groupby("customer_id")["subscription_id"].nunique()
        cur = timeline.active_at(blocks, t0)
        if rule == "primary" and not cur.empty:
            cur = cur.assign(_mrr=cur["subscription_id"].map(mrr).fillna(0.0)).sort_values(
                ["customer_id", "_mrr", "subscription_id"], ascending=[True, False, True]).drop_duplicates("customer_id")  # fmt: skip
        elif rule == "any" and not cur.empty:  # the earliest-ending subscription decides
            far = pd.Timestamp.max.floor("D")
            cur = cur.assign(_end=cur["end"].fillna(far)).sort_values(["customer_id", "_end"]).drop_duplicates("customer_id")
        cur = cur.set_index("customer_id")
        for cust in customers.itertuples(index=False):
            cid = cust.id
            known_since = first_seen.get(cid, cust.acquired_at)
            if pd.isna(known_since) or known_since >= t0:
                continue  # the customer did not exist yet at T: no row at all
            base: dict[str, Any] = {"customer_id": cid, "as_of_date": as_of, "label": None, "churn_type": None,
                                    "churn_reason": None, "churn_date": None}  # fmt: skip
            if cid not in n_active.index or cid not in cur.index:
                why = "in_trial" if cid in trial_only else "no_active_subscription"
                out.append({**base, "status": "ineligible", "detail": {"reason": why}})
                continue
            tenure = (t0 - first_start[cid]).days
            detail: dict[str, Any] = {"active_subscriptions": int(n_active[cid]), "tenure_days": int(tenure), "rule": rule}
            if tenure < defn.min_tenure_days:
                out.append({**base, "status": "ineligible", "detail": {**detail, "reason": "below_min_tenure"}})
                continue
            if cid in problem_customers:
                out.append({**base, "status": "unknown", "detail": {**detail, "reason": "contradictory_subscription_history"}})
                continue
            block = cur.loc[cid]
            end, reason = block["end"], block["end_reason"]
            ends_in_window = pd.notna(end) and end < window_end
            if ends_in_window and classify_reason(defn, reason) == "excluded":
                out.append({**base, "status": "ineligible", "detail": {**detail, "reason": f"excluded_reason:{reason}"}})
            elif not mature:
                out.append({**base, "status": "immature",
                            "detail": {**detail, "reason": "observation_window_not_complete",
                                       "observable_from": (window_end + pd.Timedelta(days=reactivation)).date().isoformat()}})  # fmt: skip
            elif ends_in_window:
                out.append({**base, "status": "churned", "label": 1, "churn_type": classify_reason(defn, reason),
                            "churn_reason": reason, "churn_date": end.date(), "detail": detail})  # fmt: skip
            else:
                out.append({**base, "status": "retained", "label": 0, "detail": detail})
    return pd.DataFrame(out, columns=["customer_id", "as_of_date", "status", "label", "churn_type", "churn_reason",
                                      "churn_date", "detail"])  # fmt: skip


LABEL_TABLES = ("customers", "subscriptions", "sub_events", "payments")
NOT_COVERED = {
    "in_trial": "the customer is still in a trial, and the churn definition covers paying subscribers only",
    "no_active_subscription": "the customer has no active subscription",
    "below_min_tenure": "the customer has not reached the minimum tenure set in the churn definition",
    "contradictory_subscription_history": "the customer's subscription history is contradictory",
}


def covered_population(frames: dict[str, pd.DataFrame], defn: ChurnDefinition, as_of: date) -> tuple[set[int], dict[int, str]]:
    """Who the churn definition covers at T, judged only from what was known strictly before T.

    Returns ``(covered customer ids, {customer id: reason} for everybody else)``.  These are exactly the customers
    that get a churned / retained label for T later on, i.e. the population a model trained under ``defn`` learned
    from - and therefore the only population it should be asked to score.
    """
    t0 = timeline.ts(as_of)
    rows = compute_labels(timeline.known_before(frames, t0), defn, [as_of], cutoff=t0)  # nothing is mature at T: covered = 'immature'
    covered = {int(c) for c in rows.loc[rows["status"] == "immature", "customer_id"]}
    left_out = {int(r.customer_id): (r.detail or {}).get("reason", r.status) for r in rows.itertuples(index=False) if r.status != "immature"}
    return covered, left_out


# ----------------------------------------------------------------------------- persistence / jobs
def resolve_dates(as_of_dates: list | None, start: Any, end: Any, cutoff: datetime) -> list[date]:
    if as_of_dates:
        dates = sorted({parse_date(d, field="as_of_dates") for d in as_of_dates})
    else:
        first, last = parse_date(start, field="start"), parse_date(end, field="end")
        if first is None or last is None:
            raise ValidationFailed("give either as_of_dates or both start and end", details={"field": "as_of_dates"})
        if last < first:
            raise ValidationFailed("end must not be before start", details={"field": "end"})
        dates = month_starts(first, last)
    if not dates:
        raise ValidationFailed("no as-of dates in the requested range (as-of dates are month starts)", details={"field": "start"})
    if len(dates) > MAX_AS_OF_DATES:
        raise ValidationFailed(f"at most {MAX_AS_OF_DATES} as-of dates per run", details={"field": "as_of_dates"})
    latest_allowed = cutoff.date() + timedelta(days=1)
    if dates[-1] > latest_allowed:
        raise ValidationFailed(f"as-of dates cannot be later than the data cutoff ({cutoff.date().isoformat()})",
                               details={"field": "as_of_dates"})  # fmt: skip
    return dates


def start_run(session: Session, principal: Principal, *, policy_id: int | None = None, as_of_dates: list | None = None,
              start: Any = None, end: Any = None) -> tuple[LabelRun, Any]:
    policy = (policies.get_approved(session, principal.tenant_id, policy_id, "churn_definition") if policy_id
              else policies.get_active(session, principal.tenant_id, "churn_definition"))  # fmt: skip
    cutoff = timeline.data_cutoff(session, principal.tenant_id)
    if cutoff is None:
        raise Conflict("no subscription or usage data has been ingested yet", code="no_data")
    dates = resolve_dates(as_of_dates, start, end, cutoff)
    run = LabelRun(tenant_id=principal.tenant_id, policy_id=policy.id, as_of_dates=[d.isoformat() for d in dates],
                   data_cutoff=cutoff, created_by=principal.user_id)  # fmt: skip
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=principal.tenant_id, job_type="labels.run", payload={"label_run_id": run.id},
                       created_by=principal.user_id)  # fmt: skip
    run.job_id = job.id
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="labels.run_started", entity_type="label_run",
                 entity_id=run.id, detail={"policy_id": policy.id, "policy_version": policy.version, "dates": len(dates)})  # fmt: skip
    return run, job


def run_labels(label_run_id: int, ctx: Any = None) -> dict:
    with read_session() as rs:
        run = rs.get(LabelRun, label_run_id)
        if run is None:
            raise jobs.PermanentJobError(f"label run {label_run_id} does not exist")
        policy = rs.get(Policy, run.policy_id)
        defn = policies.parse(policy)
        tenant_id, cutoff = run.tenant_id, run.data_cutoff
        dates = [date.fromisoformat(d) for d in run.as_of_dates]
        frames = timeline.load_frames(rs, tenant_id, tables=LABEL_TABLES)
    if ctx is not None:
        ctx.progress(0.2, "subscription timelines loaded", force=True)
    labels = compute_labels(frames, defn, dates, cutoff)
    if ctx is not None:
        ctx.progress(0.7, f"{len(labels):,} labels computed", force=True)
    now = utcnow()
    records = [
        {"tenant_id": tenant_id, "policy_id": policy.id, "label_run_id": label_run_id, "customer_id": int(r.customer_id),
         "as_of_date": r.as_of_date, "horizon_days": defn.horizon_days, "status": r.status,
         "label": None if pd.isna(r.label) else int(r.label), "churn_type": r.churn_type, "churn_reason": r.churn_reason,
         "churn_date": None if pd.isna(r.churn_date) else r.churn_date, "detail": json_safe(r.detail), "computed_at": now}
        for r in labels.itertuples(index=False)
    ]  # fmt: skip
    counts = {str(k): int(v) for k, v in labels["status"].value_counts().items()}
    by_type = {str(k): int(v) for k, v in labels.loc[labels["status"] == "churned", "churn_type"].value_counts().items()}
    with session_scope() as ws:
        ws.execute(delete(ChurnLabel).where(ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id,
                                            ChurnLabel.as_of_date.in_(dates)))  # fmt: skip
        for start in range(0, len(records), 5000):
            ws.execute(insert(ChurnLabel.__table__), records[start : start + 5000])
        run = ws.get(LabelRun, label_run_id)
        run.counts = {"by_status": counts, "churned_by_type": by_type, "total": len(records)}
        audit.record(ws, tenant_id=tenant_id, action="labels.run_completed", entity_type="label_run", entity_id=label_run_id,
                     detail={"total": len(records), **counts})  # fmt: skip
    return {"label_run_id": label_run_id, "labels": len(records), "by_status": counts, "churned_by_type": by_type}


def summary(session: Session, tenant_id: int, policy_id: int | None = None) -> dict:
    """Counts per as-of date and status (plus churn type split) for the chosen / active definition."""
    policy = (get_owned(session, Policy, tenant_id, policy_id, label="Policy") if policy_id
              else policies.get_active(session, tenant_id, "churn_definition", required=False))  # fmt: skip
    if policy is None:
        return {"policy": None, "dates": [], "totals": {}}
    rows = session.execute(
        select(ChurnLabel.as_of_date, ChurnLabel.status, ChurnLabel.churn_type, func.count())
        .where(ChurnLabel.tenant_id == tenant_id, ChurnLabel.policy_id == policy.id)
        .group_by(ChurnLabel.as_of_date, ChurnLabel.status, ChurnLabel.churn_type).order_by(ChurnLabel.as_of_date)
    ).all()  # fmt: skip
    by_date: dict[str, dict] = {}
    totals: dict[str, int] = {}
    for as_of, status, churn_type, n in rows:
        entry = by_date.setdefault(as_of.isoformat(), {"as_of_date": as_of.isoformat(), "churned": 0, "retained": 0, "immature": 0,
                                                       "unknown": 0, "ineligible": 0, "voluntary": 0, "involuntary": 0})  # fmt: skip
        entry[status] += n
        totals[status] = totals.get(status, 0) + n
        if status == "churned" and churn_type in ("voluntary", "involuntary"):
            entry[churn_type] += n
    for entry in by_date.values():
        mature = entry["churned"] + entry["retained"]
        entry["churn_rate"] = round(entry["churned"] / mature, 6) if mature else None
    return {"policy": to_dict(policy), "dates": list(by_date.values()), "totals": totals}


def label_view(label: ChurnLabel, customer: Customer | None = None) -> dict:
    view = to_dict(label)
    if customer is not None:
        view["customer_external_id"], view["customer_name"] = customer.external_id, customer.name
    return view
