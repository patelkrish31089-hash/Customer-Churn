"""Point-in-time feature engineering (pure functions over DataFrames; no database access).

For an as-of date ``T`` every feature is computed **only** from records strictly before the
instant ``T 00:00:00 UTC``.  Correctness is enforced by construction (every input frame is
truncated at T before anything is derived from it) and verified by the future-perturbation
tests: adding, changing or deleting any record at or after T must not change a single value.

Two point-in-time classes exist and are declared per feature:

* ``event_time``  - derived from timestamped events; exactly reproducible for any past T.
* ``snapshot``    - a slowly-changing attribute read from the current canonical row (industry,
                    seats ...).  For a historical T it reflects the value as loaded, except where
                    the platform recorded the change itself (card expiry is reconstructed from
                    change history).  These are flagged so reviewers can exclude them.

One documented exception: ``mrr`` and ``plan_tier`` are event-time features, but a subscription
whose lifecycle events carry no MRR / plan falls back to the value on its subscription row.  The
number of vectors affected is reported with every computation (``DataFrame.attrs["row_fallback"]``,
stored in the feature run statistics) so the approximation is never silent; it is zero when the
source sends MRR and plan on its ``started`` / ``plan_changed`` events.
"""

from __future__ import annotations

import fnmatch
import hashlib
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

from . import timeline

FEATURE_VERSION = 1
EW_LAMBDA = 0.9  # day-over-day decay of the exponentially-weighted inactivity score
PERIOD_DAYS = {"monthly": 30, "quarterly": 90, "annual": 365}
# Customer attributes that are read from their history (the value that held at T), not from today's row.
HISTORY_ATTRIBUTES = ("employee_count", "company_size", "industry", "region", "acquisition_channel")
# What "an active user" means when the tenant has not approved an activity definition of its own.
DEFAULT_ACTIVITY = {"active_event_types": ["login", "session", "feature_use", "key_action"], "timezone": "UTC",
                    "exclude_user_patterns": [], "min_identified_share": 0.5}  # fmt: skip


@dataclass(frozen=True)
class FeatureSpec:
    name: str
    group: str  # customer | subscription | rfm | usage | trend | inactivity | support | billing
    dtype: str  # float | int | bool | category
    label: str
    description: str
    sources: tuple[str, ...]
    window_days: int | None = None
    pit: str = "event_time"  # event_time | snapshot (today's row) | history (the value that held at T)


def _s(name: str, group: str, dtype: str, label: str, description: str, sources: str, window: int | None = None,
       pit: str = "event_time") -> FeatureSpec:
    return FeatureSpec(name, group, dtype, label, description, tuple(sources.split(",")), window, pit)


CATALOG: tuple[FeatureSpec, ...] = (
    # --- customer / account attributes (snapshot class)
    _s("employee_count", "customer", "float", "Employees", "Number of employees at the customer.", "customers,customer_attribute_history", pit="history"),
    _s("company_size", "customer", "category", "Company size", "Size segment of the customer.", "customers,customer_attribute_history", pit="history"),
    _s("industry", "customer", "category", "Industry", "Industry of the customer.", "customers,customer_attribute_history", pit="history"),
    _s("region", "customer", "category", "Region", "Sales region of the customer.", "customers,customer_attribute_history", pit="history"),
    _s("acquisition_channel", "customer", "category", "Acquisition channel", "Channel through which the customer was acquired.", "customers,customer_attribute_history", pit="history"),
    # --- subscription state at T
    _s("tenure_days", "subscription", "float", "Tenure (days)", "Days since the customer's first subscription started.", "subscription_events,subscriptions"),
    _s("subscription_age_days", "subscription", "float", "Current subscription age (days)", "Days since the current active period of the primary subscription began.", "subscription_events,subscriptions"),
    _s("active_subscriptions", "subscription", "int", "Active subscriptions", "Number of subscriptions active at T.", "subscription_events,subscriptions"),
    _s("mrr", "subscription", "float", "Monthly recurring revenue", "Total MRR of the subscriptions active at T: the latest MRR carried by a subscription event before T; a subscription whose events carry no MRR uses its subscription row (counted as row_fallback).", "subscription_events,subscriptions"),
    _s("plan_tier", "subscription", "category", "Plan tier", "Tier of the plan the primary subscription was on at T: the latest plan carried by a subscription event before T; without one, the plan on the subscription row (counted as row_fallback).", "subscription_events,subscriptions,plans"),
    _s("billing_period", "subscription", "category", "Billing period", "Billing period of the primary subscription.", "subscriptions", pit="snapshot"),
    _s("seats", "subscription", "float", "Seats", "Licensed quantity of the primary subscription.", "subscriptions", pit="snapshot"),
    _s("discount_pct", "subscription", "float", "Discount %", "Discount percentage on the primary subscription.", "subscriptions", pit="snapshot"),
    _s("had_trial", "subscription", "bool", "Started with a trial", "1 if the primary subscription began with a trial that ended before T.", "subscription_events,subscriptions"),
    _s("prior_churn_count", "subscription", "int", "Previous lapses", "Number of earlier subscription periods of this customer that ended before T.", "subscription_events,subscriptions"),
    _s("days_since_reactivation", "subscription", "float", "Days since reactivation", "Days since the customer came back after a lapse (missing if never lapsed).", "subscription_events"),
    _s("pending_cancellation", "subscription", "bool", "Cancellation requested", "1 if a cancellation request before T has not been revoked.", "subscription_events"),
    _s("plan_changes_90d", "subscription", "int", "Plan changes (90d)", "Plan-change events in the 90 days before T.", "subscription_events", 90),
    _s("is_first_90_days", "subscription", "bool", "In first 90 days", "1 if tenure at T is below 90 days.", "subscription_events,subscriptions"),
    # --- RFM
    _s("recency_days", "rfm", "float", "Days since last activity", "Recency: days between the last product activity and T (tenure if never active).", "usage_events"),
    _s("frequency_30d", "rfm", "int", "Active days (30d)", "Frequency: days with any product activity in the 30 days before T.", "usage_events", 30),
    _s("monetary_90d", "rfm", "float", "Paid amount (90d)", "Monetary: invoice amounts paid in the 90 days before T.", "invoices", 90),
    _s("monetary_lifetime", "rfm", "float", "Paid amount (lifetime)", "Invoice amounts paid before T.", "invoices"),
    # --- usage volumes
    _s("logins_7d", "usage", "float", "Logins (7d)", "Logins in the 7 days before T.", "usage_events", 7),
    _s("logins_30d", "usage", "float", "Logins (30d)", "Logins in the 30 days before T.", "usage_events", 30),
    _s("logins_90d", "usage", "float", "Logins (90d)", "Logins in the 90 days before T.", "usage_events", 90),
    _s("active_days_7d", "usage", "int", "Active days (7d)", "Days with activity in the 7 days before T.", "usage_events", 7),
    _s("active_days_90d", "usage", "int", "Active days (90d)", "Days with activity in the 90 days before T.", "usage_events", 90),
    _s("session_minutes_7d", "usage", "float", "Session minutes (7d)", "Total session minutes in the 7 days before T.", "usage_events", 7),
    _s("session_minutes_30d", "usage", "float", "Session minutes (30d)", "Total session minutes in the 30 days before T.", "usage_events", 30),
    _s("avg_session_minutes_30d", "usage", "float", "Average session length (30d)", "Session minutes per login over the 30 days before T.", "usage_events", 30),
    _s("feature_uses_30d", "usage", "float", "Feature uses (30d)", "Feature-usage events in the 30 days before T.", "usage_events", 30),
    _s("distinct_features_30d", "usage", "int", "Distinct features used (30d)", "Feature adoption breadth over the 30 days before T.", "usage_events", 30),
    _s("distinct_features_90d", "usage", "int", "Distinct features used (90d)", "Feature adoption breadth over the 90 days before T.", "usage_events", 90),
    _s("key_actions_30d", "usage", "float", "Key actions (30d)", "Core workflow completions in the 30 days before T.", "usage_events", 30),
    _s("avg_daily_active_users_30d", "usage", "float", "Daily active users (30d average)", "DAU: distinct people active per day (identities resolved, excluded users removed, days in the activity definition's time zone), averaged over the 30 days before T. Missing when too few of the customer's events identify a user.", "usage_events,identity_links", 30),
    _s("avg_daily_active_users_7d", "usage", "float", "Daily active users (7d average)", "DAU averaged over the 7 days before T. Missing when too few of the customer's events identify a user.", "usage_events,identity_links", 7),
    _s("monthly_active_users_30d", "usage", "float", "Monthly active users (30d)", "MAU: distinct people active in the 30 days before T. Missing when too few of the customer's events identify a user.", "usage_events,identity_links", 30),
    _s("dau_mau_ratio_30d", "usage", "float", "Stickiness (DAU / MAU, 30d)", "Average daily active users divided by monthly active users over the 30 days before T. Missing when nobody was active.", "usage_events,identity_links", 30),
    _s("active_user_seat_share_30d", "usage", "float", "Active users per licensed seat (30d)", "Monthly active users divided by the licensed seats of the primary subscription (the seat count as loaded, like 'seats'). Missing without a seat count.", "usage_events,identity_links,subscriptions", 30, pit="snapshot"),
    _s("dau_delta_7d_30d_pct", "trend", "float", "DAU change, 7d vs 30d average", "Relative change of the 7-day average of daily active users against the 30-day average.", "usage_events,identity_links", 30),
    # --- adoption of the governed product-feature catalogue (missing while no catalogue is approved)
    _s("feature_adoption_rate_30d", "adoption", "float", "Feature adoption rate (30d)", "Catalogue features the customer adopted in the 30 days before T, divided by the catalogue features the customer could use at T (released, not retired, included in the plan). Missing when that denominator is zero.", "usage_events,product_features", 30),
    _s("feature_adoption_rate_90d", "adoption", "float", "Feature adoption rate (90d)", "As the 30-day rate, over the 90 days before T.", "usage_events,product_features", 90),
    _s("core_feature_adoption_rate_90d", "adoption", "float", "Core feature adoption rate (90d)", "Adoption rate over the 90 days before T, counting only catalogue features marked as core.", "usage_events,product_features", 90),
    _s("lifetime_feature_adoption_rate", "adoption", "float", "Feature adoption rate (ever)", "Catalogue features the customer has ever adopted before T, divided by those it could use at T.", "usage_events,product_features"),
    _s("feature_adoption_delta_30d_prev30d", "adoption", "float", "Adoption change vs previous 30 days", "30-day adoption rate minus the rate of the 30 days before that (negative = features abandoned).", "usage_events,product_features", 60),
    _s("days_to_first_key_action", "usage", "float", "Time to value (days)", "TTV: days from the customer's first subscription start to their first core workflow completion before T. Missing while that has not happened.", "usage_events,subscription_events,subscriptions"),
    # --- time-window trends (7-day vs 30-day moving averages and deltas)
    _s("logins_daily_avg_7d", "trend", "float", "Daily logins, 7-day average", "Average daily logins over the 7 days before T.", "usage_events", 7),
    _s("logins_daily_avg_30d", "trend", "float", "Daily logins, 30-day average", "Average daily logins over the 30 days before T.", "usage_events", 30),
    _s("login_ratio_7d_30d", "trend", "float", "Login trend ratio (7d / 30d)", "7-day average daily logins divided by the 30-day average.", "usage_events", 30),
    _s("login_delta_7d_30d_pct", "trend", "float", "Login change, 7d vs 30d average", "Relative change of the 7-day average against the 30-day average (-0.75 = a 75% drop).", "usage_events", 30),
    _s("minutes_delta_7d_30d_pct", "trend", "float", "Session-time change, 7d vs 30d average", "Relative change of 7-day average session minutes against the 30-day average.", "usage_events", 30),
    _s("feature_use_delta_7d_30d_pct", "trend", "float", "Feature-use change, 7d vs 30d average", "Relative change of 7-day average feature uses against the 30-day average.", "usage_events", 30),
    _s("key_action_delta_7d_30d_pct", "trend", "float", "Key-action change, 7d vs 30d average", "Relative change of 7-day average core workflow completions against the 30-day average.", "usage_events", 30),
    _s("login_delta_30d_prev30d_pct", "trend", "float", "Login change vs previous 30 days", "Relative change of logins in the last 30 days against the 30 days before that.", "usage_events", 60),
    _s("active_days_delta_30d_prev30d", "trend", "float", "Active-day change vs previous 30 days", "Active days in the last 30 days minus active days in the 30 days before that.", "usage_events", 60),
    # --- inactivity
    _s("inactivity_streak_days", "inactivity", "float", "Current inactivity streak (days)", "Consecutive days without activity immediately before T.", "usage_events"),
    _s("max_inactivity_streak_90d", "inactivity", "float", "Longest inactivity streak (90d)", "Longest run of consecutive inactive days within the 90 days before T.", "usage_events", 90),
    _s("ew_inactivity_score", "inactivity", "float", "Exponentially-weighted inactivity", "Exponentially weighted (decay 0.9/day) sum of the running inactivity-streak length over 90 days.", "usage_events", 90),
    # --- support and sentiment
    _s("tickets_30d", "support", "int", "Support tickets (30d)", "Tickets opened in the 30 days before T.", "support_interactions", 30),
    _s("tickets_90d", "support", "int", "Support tickets (90d)", "Tickets opened in the 90 days before T.", "support_interactions", 90),
    _s("open_tickets", "support", "int", "Open tickets", "Tickets opened before T and not resolved before T.", "support_interactions"),
    _s("avg_resolution_hours_90d", "support", "float", "Average resolution time (h, 90d)", "Mean hours to resolve, over tickets opened in the last 90 days and resolved before T.", "support_interactions", 90),
    _s("escalations_90d", "support", "int", "Escalated tickets (90d)", "Escalated tickets opened in the last 90 days and resolved before T.", "support_interactions", 90),
    _s("support_friction_index_90d", "support", "float", "Support friction index", "Ticket frequency (per 30 days) multiplied by the mean hours tickets stayed open (up to T), over 90 days.", "support_interactions", 90),
    _s("negative_ticket_share_90d", "support", "float", "Negative-sentiment ticket share (90d)", "Share of the tickets of the last 90 days that the sentiment model labelled negative, among those it could score. Missing when none could be scored.", "support_interactions,sentiment_scores", 90),
    _s("negative_tickets_30d", "support", "float", "Negative tickets (30d)", "Tickets of the last 30 days labelled negative by the sentiment model. Missing when the customer has tickets in that period and none could be scored.", "support_interactions,sentiment_scores", 30),
    _s("sentiment_avg_score_30d", "support", "float", "Average sentiment (30d)", "Mean sentiment score (probability positive minus probability negative, -1 to 1) of the scored tickets of the last 30 days.", "support_interactions,sentiment_scores", 30),
    _s("sentiment_avg_score_90d", "support", "float", "Average sentiment (90d)", "Mean sentiment score of the scored tickets of the last 90 days.", "support_interactions,sentiment_scores", 90),
    _s("sentiment_delta_30d_prev60d", "support", "float", "Sentiment change, last 30d vs the 60d before", "Average sentiment of the last 30 days minus the average of days 31 to 90 before T. Missing unless both periods have scored tickets.", "support_interactions,sentiment_scores", 90),
    _s("last_ticket_sentiment_score", "support", "float", "Sentiment of the latest ticket", "Sentiment score of the most recent scored ticket before T.", "support_interactions,sentiment_scores"),
    _s("avg_csat_90d", "support", "float", "Average CSAT (90d)", "Mean satisfaction score of tickets resolved in the 90 days before T.", "support_interactions", 90),
    _s("last_nps_score", "support", "float", "Latest NPS score", "Most recent NPS survey response before T.", "support_interactions"),
    _s("days_since_last_ticket", "support", "float", "Days since last ticket", "Days between the last ticket opened and T.", "support_interactions"),
    # --- billing and payments
    _s("failed_payments_30d", "billing", "int", "Failed payments (30d)", "Failed payment attempts in the 30 days before T.", "payments", 30),
    _s("failed_payments_90d", "billing", "int", "Failed payments (90d)", "Failed payment attempts in the 90 days before T.", "payments", 90),
    _s("days_since_last_failed_payment", "billing", "float", "Days since last failed payment", "Days between the last failed payment attempt and T.", "payments"),
    _s("last_payment_failed", "billing", "bool", "Latest payment failed", "1 if the most recent payment attempt before T failed.", "payments"),
    _s("overdue_invoices", "billing", "int", "Overdue invoices", "Invoices past their due date at T and not paid before T.", "invoices"),
    _s("late_payments_180d", "billing", "int", "Late payments (180d)", "Invoices paid after their due date in the 180 days before T.", "invoices", 180),
    _s("avg_days_late_180d", "billing", "float", "Average days late (180d)", "Mean days past due for invoices paid in the 180 days before T.", "invoices", 180),
    _s("days_to_renewal", "billing", "float", "Days to next renewal", "Days from T to the next billing date: last invoice before T plus the billing period on the subscription row.", "invoices,subscriptions", pit="snapshot"),
    _s("days_to_card_expiry", "billing", "float", "Days until payment method expires", "Days from T until the payment method on file expires (negative if already expired).", "accounts", pit="snapshot"),
    _s("invoices_180d", "billing", "int", "Invoices (180d)", "Invoices issued in the 180 days before T.", "invoices", 180),
)  # fmt: skip
SPECS = {f.name: f for f in CATALOG}
FEATURE_NAMES = tuple(f.name for f in CATALOG)
CATEGORICAL = tuple(f.name for f in CATALOG if f.dtype == "category")
NUMERIC = tuple(f.name for f in CATALOG if f.dtype != "category")
# Current-state columns that encode the outcome and must never feed a feature.
FORBIDDEN_SOURCE_COLUMNS = ("status", "ended_at", "end_reason", "cancel_requested_at", "current_period_end", "auto_renew",
                            "closed_at")  # fmt: skip


def engine_hash() -> str:
    """Fingerprint of the feature logic (this module + the timeline module)."""
    digest = hashlib.sha256()
    for module in (Path(__file__), Path(timeline.__file__)):
        digest.update(module.read_bytes())
    return digest.hexdigest()


def _truncate(frames: dict[str, pd.DataFrame], t0: pd.Timestamp) -> dict[str, pd.DataFrame]:
    """Drop everything that was not knowable strictly before ``t0``."""
    out = timeline.known_before(frames, t0)  # subscriptions, subscription events, payments
    out["usage"] = frames["usage"][frames["usage"]["occurred_at"] < t0]
    out["support"] = frames["support"][frames["support"]["opened_at"] < t0].copy()
    late = out["support"]["resolved_at"] >= t0
    out["support"].loc[late, ["resolved_at", "csat"]] = [pd.NaT, np.nan]
    out["support"].loc[late, "escalated"] = False
    inv = frames["invoices"][frames["invoices"]["issued_at"] < t0].copy()
    inv.loc[inv["paid_at"] >= t0, "paid_at"] = pd.NaT
    out["invoices"] = inv
    return out


def _count(series: pd.Series, index: pd.Index) -> np.ndarray:
    return series.reindex(index).fillna(0).to_numpy(dtype="float64")


def normalise_ref(value: object) -> str | None:
    """How a user identifier is compared everywhere: trimmed and case-folded; empty means missing."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    text = str(value).strip().casefold()
    return text or None


def exclusion_pattern(patterns: list[str] | tuple[str, ...]) -> re.Pattern[str] | None:
    cleaned = [p.strip().casefold() for p in patterns if p and p.strip()]
    return re.compile("|".join(fnmatch.translate(p) for p in cleaned)) if cleaned else None


def resolve_users(usage: pd.DataFrame, links: pd.DataFrame | None, exclude: list[str] | tuple[str, ...] = ()) -> pd.Series:
    """The person behind each usage row (None = the row counts for nobody).

    * an identifier with an active link (valid at the event's time, for the event's customer) is that link's person;
    * an identifier whose link is quarantined or rejected counts for nobody until somebody reviewed it;
    * an identifier without any link counts as itself, so unmapped people are still counted - once each;
    * identifiers matching an exclusion pattern (staff, tests, automation) count for nobody.
    """
    if "user_ref" not in usage or usage.empty:
        return pd.Series(index=usage.index, dtype=object)
    raw = usage["user_ref"]
    norm = raw.where(raw.isna(), raw.astype(str).str.strip().str.casefold())
    norm = norm.where(norm != "", np.nan)
    user = norm.copy()
    pattern = exclusion_pattern(exclude)
    if pattern is not None:
        distinct = pd.Series(norm.dropna().unique())
        excluded = set(distinct[[bool(pattern.match(v)) for v in distinct]])
        if excluded:
            user = user.where(~norm.isin(excluded), np.nan)
    if links is None or links.empty:
        return user
    known = norm.notna() & user.notna() & norm.isin(set(links["external_user_id"]))
    if not known.any():
        return user
    mask = known.to_numpy()
    rows = pd.DataFrame({"row": np.flatnonzero(mask), "external_user_id": norm[known].to_numpy(),
                         "customer_id": usage["customer_id"].to_numpy(dtype="float64")[mask], "occurred_at": usage["occurred_at"].to_numpy()[mask]})  # fmt: skip
    columns = ["link_id", "external_user_id", "user_key", "status", "valid_from", "valid_to"]
    bound, anywhere = links[links["customer_id"].notna()], links[links["customer_id"].isna()]
    # a link bound to a customer only ever meets that customer's rows (joining on the identifier alone would pair
    # every "user 17" of every customer with every other)
    cand = pd.concat([
        rows.merge(bound[[*columns, "customer_id"]], on=["external_user_id", "customer_id"]).assign(bound=True),
        rows.merge(anywhere[columns], on="external_user_id").assign(bound=False),
    ], ignore_index=True)  # fmt: skip
    ok = cand["valid_from"].isna() | (cand["valid_from"] <= cand["occurred_at"])
    ok &= cand["valid_to"].isna() | (cand["valid_to"] > cand["occurred_at"])
    cand = cand[ok]
    if cand.empty:
        return user
    # the most specific link wins: bound to the customer, then the latest start, then the newest link
    cand = cand.assign(start=cand["valid_from"].fillna(pd.Timestamp.min))
    best = cand.sort_values(["row", "bound", "start", "link_id"]).drop_duplicates("row", keep="last")
    resolved = best["user_key"].where(best["status"] == "active", np.nan).astype(object)
    values = user.to_numpy(dtype=object, copy=True)
    values[best["row"].to_numpy()] = resolved.to_numpy(dtype=object)
    return pd.Series(values, index=usage.index, dtype=object)


def _usage_matrices(usage: pd.DataFrame, cust_ids: np.ndarray, day0: pd.Timestamp, n_days: int,
                    activity: dict | None = None) -> dict[str, np.ndarray]:
    """Daily matrices (customer x day).  ``usage`` may carry a resolved ``user`` column (see ``resolve_users``)
    and a ``user_day`` column (the day in the activity definition's time zone); without them the raw
    ``user_ref`` and the UTC day are used."""
    activity = activity or DEFAULT_ACTIVITY
    pos = pd.Series(np.arange(len(cust_ids)), index=cust_ids)
    u = usage[usage["customer_id"].isin(cust_ids)]
    rows = pos.reindex(u["customer_id"]).to_numpy()
    cols = ((u["occurred_at"].dt.normalize() - day0).dt.days).to_numpy()
    keep = (cols >= 0) & (cols < n_days)
    rows, cols, u = rows[keep].astype(int), cols[keep].astype(int), u[keep]
    shape = (len(cust_ids), n_days)
    qty = u["quantity"].fillna(1).to_numpy(dtype="float64")
    kind = u["event_type"].to_numpy()
    minutes = u["duration_seconds"].fillna(0).to_numpy(dtype="float64") / 60.0
    out = {k: np.zeros(shape, dtype="float64") for k in ("logins", "minutes", "feature_uses", "key_actions", "active", "users",
                                                          "user_events", "identified_events")}  # fmt: skip
    is_login = (kind == "login") | (kind == "session")
    np.add.at(out["logins"], (rows[is_login], cols[is_login]), qty[is_login])
    np.add.at(out["minutes"], (rows, cols), minutes)
    np.add.at(out["feature_uses"], (rows[kind == "feature_use"], cols[kind == "feature_use"]), qty[kind == "feature_use"])
    np.add.at(out["key_actions"], (rows[kind == "key_action"], cols[kind == "key_action"]), qty[kind == "key_action"])
    out["active"][rows, cols] = 1.0
    # distinct people per customer and day; only events of the types that count as activity are considered
    counts = np.isin(kind, list(activity["active_event_types"]))
    who = (u["user"] if "user" in u else u["user_ref"] if "user_ref" in u else pd.Series(index=u.index, dtype=object)).to_numpy(dtype=object)
    has_ref = u["user_ref"].notna().to_numpy() if "user_ref" in u else np.zeros(len(u), dtype=bool)
    user_cols = ((u["user_day"] - day0).dt.days).to_numpy().astype(int) if "user_day" in u else cols
    inside = counts & (user_cols >= 0) & (user_cols < n_days)
    np.add.at(out["user_events"], (rows[inside], user_cols[inside]), 1.0)
    np.add.at(out["identified_events"], (rows[inside & has_ref], user_cols[inside & has_ref]), 1.0)
    known = inside & pd.notna(who)
    out["_people"] = pd.DataFrame({"row": rows[known], "col": user_cols[known], "user": who[known]}).drop_duplicates()  # type: ignore[assignment]
    if known.any():
        np.add.at(out["users"], (out["_people"]["row"].to_numpy(), out["_people"]["col"].to_numpy()), 1.0)
    return out


def _distinct_people(people: pd.DataFrame, n_customers: int, first_day: int, last_day: int) -> np.ndarray:
    """Distinct people per customer over the days ``first_day <= day < last_day``."""
    inside = people[(people["col"] >= first_day) & (people["col"] < last_day)].drop_duplicates(["row", "user"])
    return np.bincount(inside["row"].to_numpy(), minlength=n_customers).astype("float64")


def _attributes_at(history: pd.DataFrame, t0: pd.Timestamp) -> pd.DataFrame:
    """One row per (customer, attribute): the value that held at ``t0`` as the platform knew it at ``t0``.

    A row counts when it was valid at t0, had been recorded by t0 (rows of declared history - initial, effective,
    backfill - carry no ``known_from`` and are trusted from their start), and had not been superseded by t0.
    """
    ok = history["valid_from"].isna() | (history["valid_from"] < t0)
    ok &= history["valid_to"].isna() | (history["valid_to"] >= t0)
    ok &= history["known_from"].isna() | (history["known_from"] < t0)
    ok &= history["superseded_at"].isna() | (history["superseded_at"] >= t0)
    rows = history[ok].assign(start=history.loc[ok, "valid_from"].fillna(pd.Timestamp.min))
    return rows.sort_values(["customer_id", "attribute", "start", "id"]).drop_duplicates(["customer_id", "attribute"], keep="last")


class AdoptionGrid:
    """Who could use which catalogue feature at T, and who did.  Shared by the feature vectors and by the adoption
    report so that the two can never disagree.

    ``feats`` holds usage rows already mapped to a catalogue position (column ``k``), all before T.  A feature is
    in a customer's denominator when it was released before T, not retired by T, included in the plan tier the
    customer was on at T, and its telemetry had been seen at least once before T.
    """

    def __init__(self, feats: pd.DataFrame, catalog: pd.DataFrame, cust_ids: np.ndarray, tiers: np.ndarray, t0: pd.Timestamp) -> None:
        self.feats, self.n, self.m, self.t0 = feats[feats["customer_id"].isin(cust_ids)], len(cust_ids), len(catalog), t0
        released = catalog["release_date"].to_numpy(dtype="datetime64[ns]")
        retired = catalog["retired_date"].to_numpy(dtype="datetime64[ns]")
        self.available = (np.isnat(released) | (released < t0.to_datetime64())) & (np.isnat(retired) | (retired >= t0.to_datetime64()))
        if "first_seen" in catalog:  # telemetry that has never arrived cannot show non-use: the feature does not count yet
            first_seen = catalog["first_seen"].to_numpy(dtype="datetime64[ns]")
            self.instrumented = ~np.isnat(first_seen) & (first_seen < t0.to_datetime64())
            self.available &= self.instrumented
        else:
            self.instrumented = np.ones(self.m, dtype=bool)
        self.eligible = np.tile(self.available, (self.n, 1))
        for k, allowed in enumerate(catalog["plan_tiers"]):
            if allowed:
                self.eligible[:, k] &= np.isin(tiers, list(allowed))
        self.pos = pd.Series(np.arange(self.n), index=cust_ids)
        self.min_events = catalog["min_events"].to_numpy(dtype="float64")
        self.min_days = catalog["min_days"].to_numpy(dtype="float64")
        self.core = catalog["is_core"].to_numpy(dtype=bool)

    def counts(self, since: pd.Timestamp | None = None, until: pd.Timestamp | None = None) -> tuple[np.ndarray, np.ndarray]:
        """(events, distinct days) per customer and feature inside ``[since, until)``."""
        rows = self.feats
        if since is not None:
            rows = rows[rows["occurred_at"] >= since]
        if until is not None:
            rows = rows[rows["occurred_at"] < until]
        events, days = np.zeros((self.n, self.m)), np.zeros((self.n, self.m))
        if len(rows):
            grouped = rows.groupby(["customer_id", "k"]).agg(events=("quantity", "sum"), days=("day", "nunique")).reset_index()
            r, c = self.pos.reindex(grouped["customer_id"]).to_numpy().astype(int), grouped["k"].to_numpy().astype(int)
            events[r, c], days[r, c] = grouped["events"].to_numpy(), grouped["days"].to_numpy()
        return events, days

    def adopted(self, since: pd.Timestamp | None = None, until: pd.Timestamp | None = None) -> np.ndarray:
        events, days = self.counts(since, until)
        return (events >= self.min_events[None, :]) & (days >= self.min_days[None, :]) & self.eligible

    def rate(self, flags: np.ndarray, only: np.ndarray | None = None) -> np.ndarray:
        """Adopted / eligible per customer; missing (never zero) where nothing is eligible."""
        base = self.eligible if only is None else self.eligible & only[None, :]
        denominator = base.sum(axis=1).astype("float64")
        numerator = (flags & base).sum(axis=1).astype("float64")
        return np.divide(numerator, denominator, out=np.full(self.n, np.nan), where=denominator > 0)

    def features(self) -> dict[str, np.ndarray]:
        d30, d60, d90 = (self.t0 - pd.Timedelta(days=d) for d in (30, 60, 90))
        last30, last90 = self.adopted(d30), self.adopted(d90)
        return {
            "feature_adoption_rate_30d": self.rate(last30),
            "feature_adoption_rate_90d": self.rate(last90),
            "core_feature_adoption_rate_90d": self.rate(last90, self.core),
            "lifetime_feature_adoption_rate": self.rate(self.adopted()),
            "feature_adoption_delta_30d_prev30d": self.rate(last30) - self.rate(self.adopted(d60, d30)),
        }


def map_to_catalog(usage: pd.DataFrame, catalog: pd.DataFrame) -> pd.DataFrame:
    """Usage rows that the catalogue maps to one of its features, with the catalogue position in column ``k``."""
    lookup = {(etype, name): k for k, (names, etypes) in enumerate(zip(catalog["names"], catalog["event_types"], strict=True))
              for name in names for etype in etypes}  # fmt: skip
    named = usage[usage["feature_name"].notna()]
    keys = pd.Series(list(zip(named["event_type"], named["feature_name"].astype(str).str.strip().str.casefold(), strict=True)),
                     index=named.index, dtype=object).map(lookup)  # fmt: skip
    mapped = named.assign(k=keys, day=named["occurred_at"].dt.normalize(), quantity=named["quantity"].fillna(1))
    columns = ["customer_id", "occurred_at", "k", "day", "quantity"] + (["user"] if "user" in mapped else [])
    return mapped[mapped["k"].notna()][columns]


def _ratio(num: np.ndarray, den: np.ndarray) -> np.ndarray:
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(den > 0, num / den, np.nan)


def compute_features(frames: dict[str, pd.DataFrame], as_of_dates: list[date], *, grace_days: int = 14,
                     activity: dict | None = None) -> pd.DataFrame:
    """Feature vectors for every customer with an active subscription at each as-of date.

    Returns a DataFrame with columns ``customer_id, as_of_date, max_source_ts`` + FEATURE_NAMES.

    Besides the canonical tables, four optional frames feed the derived signals; a signal whose frame is absent
    is reported as missing, never as zero:
      ``sentiment``   one row per scored support interaction (``interaction_id, label, score, state``);
      ``catalog``     the approved product-feature catalogue (see ``services.adoption.catalog_frame``);
      ``identity``    identity links (``services.identity.links_frame``); without it identifiers count as themselves;
      ``attributes``  customer attribute history (``services.attributes.history_frame``); without it today's row is used.
    ``activity`` is the tenant's approved activity definition (what counts as an active user).
    """
    results: list[pd.DataFrame] = []
    row_fallback = {"mrr": 0, "plan_tier": 0, "attributes": 0}
    activity = {**DEFAULT_ACTIVITY, **(activity or frames.get("activity") or {})}
    customers = frames["customers"].set_index("id")
    plans_tier = frames["plans"].set_index("id")["tier"] if len(frames["plans"]) else pd.Series(dtype=object)
    accounts = frames["accounts"].drop_duplicates("customer_id").set_index("customer_id")
    history = frames.get("account_history")
    # --- sentiment: the support frame carries each interaction's score (missing where it could not be scored)
    support_all = frames["support"].copy()
    sentiment = frames.get("sentiment")
    if sentiment is not None and len(sentiment):
        scored = sentiment[sentiment["state"] == "ok"].drop_duplicates("interaction_id").set_index("interaction_id")
        support_all["sentiment_score"] = support_all["id"].map(scored["score"]).astype("float64")
        support_all["sentiment_label"] = support_all["id"].map(scored["label"])
    else:
        support_all["sentiment_score"], support_all["sentiment_label"] = np.nan, None
    # --- people: resolve identifiers once; days for user counts follow the activity definition's time zone
    usage_all = frames["usage"]
    usage_all = usage_all.assign(user=resolve_users(usage_all, frames.get("identity"), activity["exclude_user_patterns"]))
    if activity["timezone"] != "UTC" and len(usage_all):
        local = usage_all["occurred_at"].dt.tz_localize("UTC").dt.tz_convert(activity["timezone"]).dt.tz_localize(None)
        usage_all = usage_all.assign(user_day=local.dt.normalize())
    # --- adoption: usage rows that the approved catalogue maps to one of its features
    catalog = frames.get("catalog")
    mapped_usage = None
    if catalog is not None and len(catalog):
        catalog = catalog.reset_index(drop=True)
        mapped_usage = map_to_catalog(usage_all, catalog)
    attribute_history = frames.get("attributes")
    frames = {**frames, "support": support_all, "usage": usage_all}

    for as_of in sorted(as_of_dates):
        t0 = timeline.ts(as_of)
        f = _truncate(frames, t0)
        intervals = timeline.build_intervals(f, grace_days, t0)
        intervals = intervals[intervals["start"] < t0]
        act = timeline.active_at(intervals, t0)
        if act.empty:
            continue
        subs = f["subscriptions"].set_index("id")
        events = f["sub_events"]
        # --- MRR and plan as of T: latest event carrying the value, else the subscription row
        mrr_ev = events.dropna(subset=["mrr"]).sort_values("occurred_at").groupby("subscription_id")["mrr"].last()
        plan_ev = events.dropna(subset=["plan_id"]).sort_values("occurred_at").groupby("subscription_id")["plan_id"].last()
        mrr_from_events, plan_from_events = act["subscription_id"].map(mrr_ev), act["subscription_id"].map(plan_ev)
        row_fallback["mrr"] += int(mrr_from_events.isna().sum())
        row_fallback["plan_tier"] += int(plan_from_events.isna().sum())
        act = act.assign(
            mrr=mrr_from_events.fillna(act["subscription_id"].map(subs["mrr"])).fillna(0.0),
            plan_id=plan_from_events.fillna(act["subscription_id"].map(subs["plan_id"])),
        )
        primary = act.sort_values(["customer_id", "mrr", "subscription_id"], ascending=[True, False, True]).drop_duplicates("customer_id").set_index("customer_id")
        idx = primary.index
        cust_ids = idx.to_numpy()
        out = pd.DataFrame(index=idx)
        psub = primary["subscription_id"]

        # --- customer attributes: the value that held at T (attribute history); today's row only where no history exists
        if attribute_history is not None:
            at_t = _attributes_at(attribute_history, t0)
            for col in HISTORY_ATTRIBUTES:
                held = at_t[at_t["attribute"] == col].set_index("customer_id")["value"]
                missing = ~idx.isin(held.index)
                row_fallback["attributes"] += int(missing.sum())
                value = held.reindex(idx).where(~missing, customers[col].reindex(idx).astype(object))
                out[col] = pd.to_numeric(value, errors="coerce") if col == "employee_count" else value
        else:
            for col in HISTORY_ATTRIBUTES:
                out[col] = customers[col].reindex(idx)

        # --- subscription state
        first_start = intervals.groupby("customer_id")["start"].min().reindex(idx)
        tenure = (t0 - first_start).dt.total_seconds() / 86400.0
        out["tenure_days"] = np.floor(tenure)
        out["subscription_age_days"] = np.floor((t0 - primary["start"]).dt.total_seconds() / 86400.0)
        out["active_subscriptions"] = act.groupby("customer_id")["subscription_id"].nunique().reindex(idx)
        out["mrr"] = act.groupby("customer_id")["mrr"].sum().reindex(idx)
        out["plan_tier"] = primary["plan_id"].map(plans_tier)
        out["billing_period"] = psub.map(subs["billing_period"])
        out["seats"] = psub.map(subs["quantity"])
        out["discount_pct"] = psub.map(subs["discount_pct"])
        # compare with the subscription's FIRST start: after a reactivation the current period begins later than the trial ended
        sub_first_start = psub.map(intervals.groupby("subscription_id")["start"].min())
        out["had_trial"] = (primary["trial_end"].notna() & (primary["trial_end"] < t0) & (primary["trial_end"] > sub_first_start)).astype(float)
        ended = intervals[intervals["end"].notna() & (intervals["end"] <= t0)]
        out["prior_churn_count"] = _count(ended.groupby("customer_id").size(), idx)
        last_end = ended.groupby("customer_id")["end"].max().reindex(idx)
        cur_start = act.groupby("customer_id")["start"].min().reindex(idx)
        out["days_since_reactivation"] = np.where(last_end.notna() & (cur_start >= last_end),
                                                  np.floor((t0 - cur_start).dt.total_seconds() / 86400.0), np.nan)  # fmt: skip
        cancel = events[events["event_type"].isin(["cancel_requested", "cancel_revoked"]) & events["subscription_id"].isin(act["subscription_id"])]
        last_cancel = cancel.sort_values("occurred_at").groupby("customer_id")["event_type"].last()
        out["pending_cancellation"] = (last_cancel.reindex(idx) == "cancel_requested").astype(float)
        changes = events[(events["event_type"] == "plan_changed") & (events["occurred_at"] >= t0 - pd.Timedelta(days=90))]
        out["plan_changes_90d"] = _count(changes.groupby("customer_id").size(), idx)
        out["is_first_90_days"] = (out["tenure_days"] < 90).astype(float)

        # --- usage: daily matrices and cumulative sums (window = the w days immediately before T)
        usage = f["usage"]
        horizon_days = 130
        earliest = usage["occurred_at"].min() if len(usage) else t0
        day0 = min(t0 - pd.Timedelta(days=horizon_days), (earliest if pd.notna(earliest) else t0)).normalize()
        n_days = int((t0 - day0).days)
        mats = _usage_matrices(usage, cust_ids, day0, n_days, activity)
        people = mats.pop("_people")
        cum = {k: np.concatenate([np.zeros((len(cust_ids), 1)), np.cumsum(m, axis=1)], axis=1) for k, m in mats.items()}

        def window(name: str, days: int, offset: int = 0, cum: dict = cum, n_days: int = n_days) -> np.ndarray:
            hi = n_days - offset
            return cum[name][:, hi] - cum[name][:, max(hi - days, 0)]

        tenure_arr = np.maximum(out["tenure_days"].to_numpy(dtype="float64"), 1.0)
        out["logins_7d"], out["logins_30d"], out["logins_90d"] = window("logins", 7), window("logins", 30), window("logins", 90)
        out["active_days_7d"], out["frequency_30d"], out["active_days_90d"] = window("active", 7), window("active", 30), window("active", 90)
        out["session_minutes_7d"], out["session_minutes_30d"] = window("minutes", 7), window("minutes", 30)
        out["avg_session_minutes_30d"] = _ratio(window("minutes", 30), window("logins", 30))
        out["feature_uses_30d"], out["key_actions_30d"] = window("feature_uses", 30), window("key_actions", 30)
        # People: known only when enough of the customer's activity identifies a user; otherwise unknown, never zero
        identified = np.divide(cum["identified_events"][:, -1], cum["user_events"][:, -1], out=np.zeros(len(cust_ids)), where=cum["user_events"][:, -1] > 0)
        counted = (cum["user_events"][:, -1] > 0) & (identified >= float(activity["min_identified_share"])) & (identified > 0)
        dau30 = window("users", 30) / np.minimum(30.0, tenure_arr)
        dau7 = window("users", 7) / np.minimum(7.0, tenure_arr)
        mau = _distinct_people(people, len(cust_ids), n_days - 30, n_days)
        out["avg_daily_active_users_30d"] = np.where(counted, dau30, np.nan)
        out["avg_daily_active_users_7d"] = np.where(counted, dau7, np.nan)
        out["monthly_active_users_30d"] = np.where(counted, mau, np.nan)
        out["dau_mau_ratio_30d"] = np.where(counted, _ratio(dau30, mau), np.nan)
        seats = pd.to_numeric(out["seats"], errors="coerce").to_numpy(dtype="float64")
        out["active_user_seat_share_30d"] = np.where(counted & (seats > 0), mau / np.where(seats > 0, seats, 1.0), np.nan)
        out["dau_delta_7d_30d_pct"] = np.where(counted, _ratio(dau7, dau30) - 1.0, np.nan)
        # Adoption of the governed catalogue (missing while there is no approved catalogue)
        if mapped_usage is not None:
            tier_now = out["plan_tier"].astype(object).to_numpy()
            for name, values in AdoptionGrid(mapped_usage[mapped_usage["occurred_at"] < t0], catalog, cust_ids, tier_now, t0).features().items():
                out[name] = values
        else:
            for name in ("feature_adoption_rate_30d", "feature_adoption_rate_90d", "core_feature_adoption_rate_90d",
                         "lifetime_feature_adoption_rate", "feature_adoption_delta_30d_prev30d"):  # fmt: skip
                out[name] = np.nan
        # time to value: first core workflow completion, counted from the first subscription start
        reached = mats["key_actions"] > 0
        first_value_day = reached.argmax(axis=1) if n_days else np.zeros(len(cust_ids), dtype=int)
        start_day = ((first_start.dt.normalize() - day0).dt.days).to_numpy()
        has_value = reached.any(axis=1) if n_days else np.zeros(len(cust_ids), dtype=bool)
        out["days_to_first_key_action"] = np.where(has_value, np.maximum(first_value_day - start_day, 0), np.nan)
        feats = usage[(usage["event_type"] == "feature_use") & usage["feature_name"].notna()]
        for days in (30, 90):
            recent = feats[feats["occurred_at"] >= t0 - pd.Timedelta(days=days)]
            out[f"distinct_features_{days}d"] = _count(recent.groupby("customer_id")["feature_name"].nunique(), idx)
        avg7 = window("logins", 7) / np.minimum(7.0, tenure_arr)
        avg30 = window("logins", 30) / np.minimum(30.0, tenure_arr)
        out["logins_daily_avg_7d"], out["logins_daily_avg_30d"] = avg7, avg30
        out["login_ratio_7d_30d"] = _ratio(avg7, avg30)
        out["login_delta_7d_30d_pct"] = out["login_ratio_7d_30d"] - 1.0
        out["minutes_delta_7d_30d_pct"] = _ratio(window("minutes", 7) / np.minimum(7.0, tenure_arr),
                                                 window("minutes", 30) / np.minimum(30.0, tenure_arr)) - 1.0  # fmt: skip
        for name, source in (("feature_use_delta_7d_30d_pct", "feature_uses"), ("key_action_delta_7d_30d_pct", "key_actions")):
            out[name] = _ratio(window(source, 7) / np.minimum(7.0, tenure_arr), window(source, 30) / np.minimum(30.0, tenure_arr)) - 1.0
        prev30 = window("logins", 30, offset=30)
        out["login_delta_30d_prev30d_pct"] = _ratio(window("logins", 30) - prev30, prev30)
        out["active_days_delta_30d_prev30d"] = np.where(tenure_arr >= 60, window("active", 30) - window("active", 30, offset=30), np.nan)

        # --- recency and inactivity streaks
        day_idx = np.arange(n_days)
        last_active = np.maximum.accumulate(np.where(mats["active"] > 0, day_idx, -1), axis=1) if n_days else np.zeros((len(cust_ids), 0))
        start_idx = np.clip(((first_start.dt.normalize() - day0).dt.days).to_numpy(), 0, n_days)
        la_now = last_active[:, -1] if n_days else np.full(len(cust_ids), -1)
        recency = np.where(la_now >= 0, n_days - la_now, np.nan)
        out["recency_days"] = np.where(np.isnan(recency), tenure_arr, recency)
        base = np.maximum(last_active, start_idx[:, None] - 1)
        streak = np.where(day_idx[None, :] >= start_idx[:, None], day_idx[None, :] - base, 0).astype("float64")
        out["inactivity_streak_days"] = streak[:, -1] if n_days else 0.0
        recent_streak = streak[:, max(n_days - 90, 0) :]
        out["max_inactivity_streak_90d"] = recent_streak.max(axis=1) if recent_streak.shape[1] else 0.0
        weights = EW_LAMBDA ** np.arange(recent_streak.shape[1] - 1, -1, -1)
        out["ew_inactivity_score"] = (recent_streak * weights[None, :]).sum(axis=1) * (1 - EW_LAMBDA)

        # --- support
        sup = f["support"]
        tickets = sup[sup["kind"] != "nps_survey"]
        d30, d90, d180 = (t0 - pd.Timedelta(days=d) for d in (30, 90, 180))
        t90 = tickets[tickets["opened_at"] >= d90]
        out["tickets_30d"] = _count(tickets[tickets["opened_at"] >= d30].groupby("customer_id").size(), idx)
        out["tickets_90d"] = _count(t90.groupby("customer_id").size(), idx)
        out["open_tickets"] = _count(tickets[tickets["resolved_at"].isna()].groupby("customer_id").size(), idx)
        resolved90 = t90[t90["resolved_at"].notna()]
        hours = (resolved90["resolved_at"] - resolved90["opened_at"]).dt.total_seconds() / 3600.0
        out["avg_resolution_hours_90d"] = hours.groupby(resolved90["customer_id"]).mean().reindex(idx)
        out["escalations_90d"] = _count(resolved90[resolved90["escalated"].astype(bool)].groupby("customer_id").size(), idx)
        open_hours = (t90["resolved_at"].fillna(t0) - t90["opened_at"]).dt.total_seconds() / 3600.0
        mean_open = open_hours.groupby(t90["customer_id"]).mean().reindex(idx).fillna(0.0)
        out["support_friction_index_90d"] = (out["tickets_90d"] / 3.0) * mean_open
        # sentiment of the tickets the model could score; a customer whose tickets could not be scored is unknown
        s90 = t90[t90["sentiment_score"].notna()]
        s30 = s90[s90["opened_at"] >= d30]
        out["negative_ticket_share_90d"] = (s90["sentiment_label"] == "negative").groupby(s90["customer_id"]).mean().reindex(idx)
        tickets30 = tickets[tickets["opened_at"] >= d30].groupby("customer_id").size().reindex(idx).fillna(0)
        negative30 = (s30["sentiment_label"] == "negative").groupby(s30["customer_id"]).sum().reindex(idx)
        scored30 = s30.groupby("customer_id").size().reindex(idx).fillna(0)
        out["negative_tickets_30d"] = np.where((tickets30 > 0) & (scored30 == 0), np.nan, negative30.fillna(0.0)) if sentiment is not None else np.nan
        out["sentiment_avg_score_30d"] = s30.groupby("customer_id")["sentiment_score"].mean().reindex(idx)
        out["sentiment_avg_score_90d"] = s90.groupby("customer_id")["sentiment_score"].mean().reindex(idx)
        earlier = s90[s90["opened_at"] < d30].groupby("customer_id")["sentiment_score"].mean().reindex(idx)
        out["sentiment_delta_30d_prev60d"] = out["sentiment_avg_score_30d"] - earlier
        scored_all = tickets[tickets["sentiment_score"].notna()].sort_values(["opened_at", "id"])
        out["last_ticket_sentiment_score"] = scored_all.groupby("customer_id")["sentiment_score"].last().reindex(idx)
        csat = tickets[tickets["resolved_at"].notna() & (tickets["resolved_at"] >= d90)]
        out["avg_csat_90d"] = csat.groupby("customer_id")["csat"].mean().reindex(idx)
        nps = sup[(sup["kind"] == "nps_survey") & sup["nps_score"].notna()].sort_values("opened_at")
        out["last_nps_score"] = nps.groupby("customer_id")["nps_score"].last().reindex(idx)
        last_ticket = tickets.groupby("customer_id")["opened_at"].max().reindex(idx)
        out["days_since_last_ticket"] = np.floor((t0 - last_ticket).dt.total_seconds() / 86400.0)

        # --- billing
        pay = f["payments"]
        failed = pay[pay["status"] == "failed"]
        out["failed_payments_30d"] = _count(failed[failed["attempted_at"] >= d30].groupby("customer_id").size(), idx)
        out["failed_payments_90d"] = _count(failed[failed["attempted_at"] >= d90].groupby("customer_id").size(), idx)
        last_failed = failed.groupby("customer_id")["attempted_at"].max().reindex(idx)
        out["days_since_last_failed_payment"] = np.floor((t0 - last_failed).dt.total_seconds() / 86400.0)
        last_status = pay.sort_values(["attempted_at", "id"]).groupby("customer_id")["status"].last().reindex(idx)
        out["last_payment_failed"] = (last_status == "failed").astype(float)
        inv = f["invoices"]
        paid = inv[inv["paid_at"].notna()]
        out["monetary_90d"] = _count(paid[paid["paid_at"] >= d90].groupby("customer_id")["amount"].sum(), idx)
        out["monetary_lifetime"] = _count(paid.groupby("customer_id")["amount"].sum(), idx)
        overdue = inv[inv["paid_at"].isna() & inv["due_at"].notna() & (inv["due_at"] < t0)]
        out["overdue_invoices"] = _count(overdue.groupby("customer_id").size(), idx)
        paid180 = paid[(paid["paid_at"] >= d180) & paid["due_at"].notna()]
        days_late = ((paid180["paid_at"] - paid180["due_at"]).dt.total_seconds() / 86400.0).clip(lower=0)
        out["late_payments_180d"] = _count((days_late > 0).groupby(paid180["customer_id"]).sum(), idx)
        out["avg_days_late_180d"] = days_late.groupby(paid180["customer_id"]).mean().reindex(idx)
        out["invoices_180d"] = _count(inv[inv["issued_at"] >= d180].groupby("customer_id").size(), idx)
        last_invoice = inv.groupby("customer_id")["issued_at"].max().reindex(idx)
        period = out["billing_period"].map(PERIOD_DAYS).fillna(30).to_numpy(dtype="float64")
        out["days_to_renewal"] = np.floor((last_invoice - t0).dt.total_seconds() / 86400.0) + period
        expiry = accounts["payment_method_expires_on"].reindex(idx)
        if history is not None and len(history):
            later = history[history["changed_at"] >= t0].sort_values("changed_at").drop_duplicates("account_id")
            previous = accounts["id"].reindex(idx).map(later.set_index("account_id")["previous_expiry"])
            changed = accounts["id"].reindex(idx).isin(later["account_id"])
            expiry = expiry.where(~changed, previous)
        out["days_to_card_expiry"] = np.floor((expiry - t0).dt.total_seconds() / 86400.0)

        # --- provenance: newest record that fed this vector (always < T)
        newest = [s.groupby("customer_id")[c].max().reindex(idx) for s, c in
                  ((usage, "occurred_at"), (events, "occurred_at"), (pay, "attempted_at"), (sup, "opened_at"), (inv, "issued_at"))]  # fmt: skip
        out["max_source_ts"] = pd.concat(newest, axis=1).max(axis=1)
        out = out.reset_index().rename(columns={"index": "customer_id"})
        out.insert(1, "as_of_date", as_of)
        results.append(out[["customer_id", "as_of_date", "max_source_ts", *FEATURE_NAMES]])
    final = (pd.concat(results, ignore_index=True) if results
             else pd.DataFrame(columns=["customer_id", "as_of_date", "max_source_ts", *FEATURE_NAMES]))  # fmt: skip
    final.attrs["row_fallback"] = row_fallback
    return final
