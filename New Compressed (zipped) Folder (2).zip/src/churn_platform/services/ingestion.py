"""Dataset catalog and ingestion pipeline.

Raw files are stored immutably (content-addressed, read-only, checksum-verified before every use);
the import job streams them through mapping -> coercion -> validation -> reference resolution ->
idempotent upsert into the canonical tables, quarantining every row it cannot load and finishing
with a reconciliation that must balance (rows read = inserted + updated + unchanged + duplicate +
quarantined + skipped-by-cursor).
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import threading
import time
from collections import defaultdict, deque
from collections.abc import Iterator
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Any

import httpx
from sqlalchemy import delete, func, insert, select, update
from sqlalchemy.orm import Session

from .. import netguard, storage
from ..config import get_settings
from ..db import get_session_factory, money, utcnow
from ..errors import Conflict, ExternalServiceError, NotFound, Unauthorized, ValidationFailed
from ..logging_setup import get_logger
from ..models import (
    ENTITY_MODELS,
    ENTITY_TYPES,
    Account,
    Correction,
    Customer,
    DatasetVersion,
    DataSource,
    EntityHistory,
    ImportRun,
    Invoice,
    Plan,
    QuarantineRecord,
    SourceMapping,
    Subscription,
    WebhookEvent,
)
from ..security import Principal, SecretBox, constant_time_equals, hmac_sha256_hex
from . import attributes, audit, jobs
from .common import get_owned, json_safe, to_dict
from .readers import detect_format, discover_schema, iter_rows, suggest_mapping
from .schemas import ENTITY_DEFAULTS, ENTITY_SCHEMAS, CoercionError, FieldSpec, coerce, is_missing, row_rule_violations

log = get_logger("ingestion")
CHUNK_ROWS = 2000
REF_MODELS = {"customers": Customer, "accounts": Account, "plans": Plan, "subscriptions": Subscription, "invoices": Invoice}
CONTROL_TOTAL_FIELD = {"invoices": "amount", "payments": "amount", "subscriptions": "mrr", "plans": "list_price",
                       "acquisitions": "cac"}  # fmt: skip
SOURCE_KINDS = ("file", "rest_api", "webhook")


# ----------------------------------------------------------------------------- raw storage
def sha256_file(path: Path) -> tuple[str, int]:
    digest, size = hashlib.sha256(), 0
    with open(path, "rb") as fh:
        while chunk := fh.read(1 << 20):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def raw_root() -> Path:
    root = get_settings().data_dir / "raw"
    root.mkdir(parents=True, exist_ok=True)
    return root


def new_temp_path(suffix: str = "") -> Path:
    tmp_dir = get_settings().data_dir / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=tmp_dir, suffix=suffix)
    os.close(fd)
    return Path(name)


def verified_path(dv: DatasetVersion) -> Path:
    """Return the raw file path after proving its content still matches the recorded checksum."""
    path = storage.resolve(dv.storage_path)
    if not path.is_file():
        raise jobs.PermanentJobError(f"raw file for dataset version {dv.id} is missing from storage")
    actual, _ = sha256_file(path)
    if actual != dv.checksum_sha256:
        raise jobs.PermanentJobError(f"raw file for dataset version {dv.id} failed its SHA-256 integrity check")
    return path


# ----------------------------------------------------------------------------- catalog
def _clean_config(kind: str, config: dict | None, previous: dict | None = None) -> dict:
    config = dict(config or {})
    auth = dict(config.get("auth") or {})
    secret = auth.pop("secret", None)
    if secret:
        auth["secret_enc"] = SecretBox().encrypt(str(secret))
    elif previous and (previous.get("auth") or {}).get("secret_enc"):
        auth.setdefault("secret_enc", previous["auth"]["secret_enc"])
    if auth:
        config["auth"] = auth
    if kind == "rest_api":
        url = config.get("url")
        if not url:
            raise ValidationFailed("a REST source needs config.url", details={"field": "config.url"})
        assert_fetchable_url(url)
        pag_type = (config.get("pagination") or {}).get("type", "none")
        if pag_type not in ("none", "page", "offset", "cursor"):
            raise ValidationFailed("pagination.type must be none, page, offset or cursor")
    return config


def mask_config(config: dict | None) -> dict:
    config = json.loads(json.dumps(config or {}))
    if "secret_enc" in (config.get("auth") or {}):
        config["auth"].pop("secret_enc")
        config["auth"]["secret_set"] = True
    return config


def source_view(source: DataSource, mapping: SourceMapping | None = None) -> dict:
    view = to_dict(source, exclude={"config"})
    view["config"] = mask_config(source.config)
    view["webhook_secret_set"] = bool(source.webhook_secret_enc)
    if mapping is not None:
        view["mapping"] = {"version": mapping.version, "mapping": mapping.mapping}
    return view


def create_source(session: Session, principal: Principal, *, name: str, entity_type: str, kind: str = "file",
                  description: str | None = None, config: dict | None = None,
                  webhook_secret: str | None = None) -> DataSource:
    name = (name or "").strip()
    if not name:
        raise ValidationFailed("name is required", details={"field": "name"})
    if entity_type not in ENTITY_TYPES:
        raise ValidationFailed(f"entity_type must be one of {', '.join(ENTITY_TYPES)}", details={"field": "entity_type"})
    if kind not in SOURCE_KINDS:
        raise ValidationFailed(f"kind must be one of {', '.join(SOURCE_KINDS)}", details={"field": "kind"})
    if session.execute(select(DataSource.id).where(DataSource.tenant_id == principal.tenant_id, DataSource.name == name)).first():
        raise Conflict(f"a source named '{name}' already exists")
    if kind == "webhook" and not webhook_secret:
        raise ValidationFailed("a webhook source needs a signing secret (min 16 characters)", details={"field": "webhook_secret"})
    if webhook_secret is not None and len(webhook_secret) < 16:
        raise ValidationFailed("webhook secret must be at least 16 characters", details={"field": "webhook_secret"})
    source = DataSource(tenant_id=principal.tenant_id, name=name, entity_type=entity_type, kind=kind,
                        description=description, config=_clean_config(kind, config), created_by=principal.user_id,
                        webhook_secret_enc=SecretBox().encrypt(webhook_secret) if webhook_secret else None)  # fmt: skip
    session.add(source)
    session.flush()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="source.created", entity_type="data_source",
                 entity_id=source.id, detail={"name": name, "entity_type": entity_type, "kind": kind})  # fmt: skip
    return source


def update_source(session: Session, principal: Principal, source_id: int, *, description: str | None = None,
                  config: dict | None = None, is_active: bool | None = None) -> DataSource:
    source = get_owned(session, DataSource, principal.tenant_id, source_id, label="Source")
    if description is not None:
        source.description = description
    if config is not None:
        source.config = _clean_config(source.kind, config, previous=source.config)
    if is_active is not None:
        source.is_active = is_active
    source.updated_at = utcnow()
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action="source.updated", entity_type="data_source",
                 entity_id=source.id, detail={"config_changed": config is not None, "is_active": is_active})  # fmt: skip
    return source


def current_mapping(session: Session, source_id: int) -> SourceMapping | None:
    stmt = select(SourceMapping).where(SourceMapping.source_id == source_id, SourceMapping.is_current.is_(True))
    return session.execute(stmt.order_by(SourceMapping.version.desc()).limit(1)).scalar_one_or_none()


def validate_mapping(entity_type: str, mapping: dict) -> dict:
    specs = {s.name: s for s in ENTITY_SCHEMAS[entity_type]}
    clean: dict[str, Any] = {}
    for field, target in (mapping or {}).items():
        if field not in specs:
            raise ValidationFailed(f"'{field}' is not a canonical field of {entity_type}",
                                   details={"field": field, "allowed": sorted(specs)})  # fmt: skip
        if isinstance(target, str) and target.strip():
            clean[field] = target
        elif isinstance(target, dict) and (target.get("source") or "default" in target):
            clean[field] = {k: target[k] for k in ("source", "default") if k in target}
        else:
            raise ValidationFailed(f"mapping for '{field}' must be a source column name or {{source, default}}")
    missing = [s.name for s in specs.values() if s.required and s.name not in clean]
    if missing:
        raise ValidationFailed(f"required canonical fields are not mapped: {', '.join(missing)}", details={"missing": missing})
    return clean


def require_mapped_columns(entity_type: str, mapping: dict, dv: DatasetVersion) -> None:
    """Refuse an import whose mapping points a required field at a column the file does not have.

    Without this check a typo in the mapping (or a renamed column in a new delivery) would send every row of the
    file to quarantine, one record per row.  Only checked when the file's columns are known completely: formats
    with a header, or a JSON file that was profiled in full.
    """
    schema = dv.schema or {}
    columns = {c["name"] for c in schema.get("columns", [])}
    complete = dv.file_format not in ("json", "jsonl") or schema.get("sampled_rows", 0) >= schema.get("row_count", 0)
    if not columns or not complete:
        return
    absent = [(spec.name, column) for spec, column, default in compile_mapping(entity_type, mapping)
              if spec.required and column and column not in columns and is_missing(default)]  # fmt: skip
    if absent:
        listing = ", ".join(f"'{column}' (mapped to {field})" for field, column in absent)
        raise ValidationFailed(f"the file has no column {listing}; fix the mapping or upload a file with that column",
                               code="mapped_column_missing", details={"missing": [c for _, c in absent], "columns_in_file": sorted(columns)})  # fmt: skip


def set_mapping(session: Session, principal: Principal | None, source: DataSource, mapping: dict, *,
                validate: bool = True, user_id: int | None = None) -> SourceMapping:
    clean = validate_mapping(source.entity_type, mapping) if validate else mapping
    session.execute(update(SourceMapping).where(SourceMapping.source_id == source.id).values(is_current=False))
    version = (session.execute(select(func.max(SourceMapping.version)).where(SourceMapping.source_id == source.id)).scalar() or 0) + 1
    row = SourceMapping(tenant_id=source.tenant_id, source_id=source.id, version=version, mapping=clean, is_current=True,
                        created_by=principal.user_id if principal else user_id)  # fmt: skip
    session.add(row)
    session.flush()
    audit.record(session, tenant_id=source.tenant_id, actor=principal, action="source.mapping_set", entity_type="data_source",
                 entity_id=source.id, detail={"version": version, "fields": sorted(clean)})  # fmt: skip
    return row


def register_file(session: Session, *, source: DataSource, tmp_path: Path, file_name: str, created_by: int | None,
                  origin: str = "upload", is_synthetic: bool = False, actor: Principal | None = None) -> tuple[DatasetVersion, bool]:
    """Profile and store a raw file as a new immutable dataset version (or detect a duplicate)."""
    fmt = detect_format(file_name, (source.config or {}).get("format"))
    checksum, size = sha256_file(tmp_path)
    if size == 0:
        tmp_path.unlink(missing_ok=True)
        raise ValidationFailed("the file is empty")
    existing = session.execute(
        select(DatasetVersion).where(DatasetVersion.tenant_id == source.tenant_id, DatasetVersion.source_id == source.id,
                                     DatasetVersion.checksum_sha256 == checksum)
    ).scalar_one_or_none()  # fmt: skip
    if existing is not None:
        tmp_path.unlink(missing_ok=True)
        return existing, True
    try:
        schema = discover_schema(tmp_path, fmt, (source.config or {}).get("reader_options"))
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise
    dest = raw_root() / str(source.tenant_id) / checksum[:2] / f"{checksum}.{fmt}"
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        tmp_path.unlink(missing_ok=True)
    else:
        shutil.move(str(tmp_path), dest)
        dest.chmod(0o444)  # raw data is immutable
    previous = session.execute(
        select(DatasetVersion).where(DatasetVersion.source_id == source.id).order_by(DatasetVersion.version_no.desc()).limit(1)
    ).scalar_one_or_none()
    dv = DatasetVersion(
        tenant_id=source.tenant_id, source_id=source.id, version_no=(previous.version_no + 1) if previous else 1,
        checksum_sha256=checksum, file_name=Path(file_name).name[:300], file_format=fmt, size_bytes=size,
        row_count=schema["row_count"], schema=schema, storage_path=storage.to_stored(dest), origin=origin, is_synthetic=is_synthetic,
        parent_version_id=previous.id if previous else None, created_by=created_by,
    )  # fmt: skip
    session.add(dv)
    source.discovered_schema, source.updated_at = schema, utcnow()
    session.flush()
    if current_mapping(session, source.id) is None:
        suggested = suggest_mapping(source.entity_type, [c["name"] for c in schema["columns"]])
        set_mapping(session, actor, source, suggested, validate=False, user_id=created_by)
    audit.record(session, tenant_id=source.tenant_id, actor=actor, action="dataset.version_registered",
                 entity_type="dataset_version", entity_id=dv.id,
                 detail={"source_id": source.id, "version_no": dv.version_no, "sha256": checksum, "rows": dv.row_count,
                         "origin": origin, "synthetic": is_synthetic})  # fmt: skip
    return dv, False


def start_import(session: Session, principal: Principal, source_id: int, *, dataset_version_id: int | None = None,
                 mode: str = "full") -> tuple[ImportRun, Any]:
    source = get_owned(session, DataSource, principal.tenant_id, source_id, label="Source")
    if mode not in ("full", "incremental"):
        raise ValidationFailed("mode must be 'full' or 'incremental'", details={"field": "mode"})
    if source.kind == "rest_api" and dataset_version_id is None:
        job = jobs.enqueue(session, tenant_id=source.tenant_id, job_type="ingest.rest_pull", created_by=principal.user_id,
                           payload={"source_id": source.id, "mode": mode})  # fmt: skip
        audit.record(session, tenant_id=source.tenant_id, actor=principal, action="import.rest_pull_requested",
                     entity_type="data_source", entity_id=source.id, detail={"job_id": job.id, "mode": mode})  # fmt: skip
        return None, job  # type: ignore[return-value]
    if dataset_version_id is None:
        dv = session.execute(
            select(DatasetVersion).where(DatasetVersion.source_id == source.id).order_by(DatasetVersion.version_no.desc()).limit(1)
        ).scalar_one_or_none()
        if dv is None:
            raise Conflict("this source has no dataset version yet; upload a file first")
    else:
        dv = get_owned(session, DatasetVersion, principal.tenant_id, dataset_version_id, label="Dataset version")
        if dv.source_id != source.id:
            raise ValidationFailed("dataset version belongs to a different source")
    mapping = current_mapping(session, source.id)
    if mapping is None:
        raise Conflict("this source has no column mapping yet")
    validate_mapping(source.entity_type, mapping.mapping)  # an auto-suggested mapping may be incomplete
    require_mapped_columns(source.entity_type, mapping.mapping, dv)
    run = ImportRun(tenant_id=source.tenant_id, source_id=source.id, dataset_version_id=dv.id, mode=mode,
                    mapping_version=mapping.version, status="pending", created_by=principal.user_id)  # fmt: skip
    session.add(run)
    session.flush()
    job = jobs.enqueue(session, tenant_id=source.tenant_id, job_type="ingest.import", created_by=principal.user_id,
                       payload={"import_run_id": run.id})  # fmt: skip
    run.job_id = job.id
    audit.record(session, tenant_id=source.tenant_id, actor=principal, action="import.started", entity_type="import_run",
                 entity_id=run.id, detail={"source_id": source.id, "dataset_version_id": dv.id, "mode": mode})  # fmt: skip
    return run, job


# ----------------------------------------------------------------------------- normalisation
def compile_mapping(entity_type: str, mapping: dict) -> list[tuple[FieldSpec, str | None, Any]]:
    out = []
    for spec in ENTITY_SCHEMAS[entity_type]:
        target = mapping.get(spec.name)
        if target is None:
            continue
        if isinstance(target, str):
            out.append((spec, target, None))
        else:
            out.append((spec, target.get("source"), target.get("default")))
    return out


def normalize_row(entity_type: str, raw: dict, compiled: list, now: datetime) -> tuple[dict, list[str]]:
    row: dict[str, Any] = {}
    errors: list[str] = []
    for spec, column, default in compiled:
        value = raw.get(column) if column else None
        if is_missing(value):
            value = default
        if is_missing(value):
            if spec.required:
                errors.append(f"missing required field '{spec.name}'")
            row[spec.name] = None
            continue
        try:
            row[spec.name] = coerce(spec, value)
        except CoercionError as exc:
            errors.append(f"{spec.name}: {exc}")
            row[spec.name] = None
    if not errors:
        errors.extend(row_rule_violations(entity_type, row, now))
    if entity_type == "usage_events" and not errors and not row.get("external_id"):
        basis = "|".join(str(row.get(k)) for k in ("customer_external_id", "occurred_at", "event_type", "feature_name",
                                                    "user_ref", "duration_seconds", "quantity"))  # fmt: skip
        row["external_id"] = "h:" + hashlib.sha1(basis.encode(), usedforsecurity=False).hexdigest()
    return row, errors


def _same(old: Any, new: Any) -> bool:
    if old is None or new is None:
        return old is None and new is None
    if isinstance(new, Decimal) or isinstance(old, Decimal):
        return money(old) == money(new)
    if isinstance(new, float) or isinstance(old, float):
        return abs(float(old) - float(new)) <= 1e-9 * max(1.0, abs(float(new)))
    return old == new


class _Loader:
    """Upserts validated rows chunk by chunk and keeps the import counters."""

    def __init__(self, session: Session, run: ImportRun, entity_type: str, dv: DatasetVersion, mapped: set[str]) -> None:
        self.s, self.run, self.et, self.dv = session, run, entity_type, dv
        self.tenant_id = run.tenant_id
        self.model = ENTITY_MODELS[entity_type]
        self.table = self.model.__table__
        self.specs = [s for s in ENTITY_SCHEMAS[entity_type] if s.name in mapped or s.name == "external_id"]
        self.counts = dict.fromkeys(("read", "inserted", "updated", "unchanged", "duplicate", "quarantined", "skipped_cursor"), 0)
        self.pinned_skipped = 0
        self.control_total = Decimal("0")
        self.max_cursor: Any = None

    def quarantine(self, row_number: int, raw: dict, reasons: list[str]) -> None:
        self.s.add(QuarantineRecord(tenant_id=self.tenant_id, import_run_id=self.run.id, dataset_version_id=self.dv.id,
                                    entity_type=self.et, row_number=row_number, payload=json_safe(raw), reasons=reasons))  # fmt: skip
        self.counts["quarantined"] += 1

    def _resolve(self, ref_type: str, external_ids: set[str]) -> dict[str, Any]:
        if not external_ids:
            return {}
        model = REF_MODELS[ref_type]
        cols = [model.external_id, model.id] + ([model.customer_id] if ref_type == "subscriptions" else [])
        found: dict[str, Any] = {}
        ids = list(external_ids)
        for start in range(0, len(ids), 5000):
            stmt = select(*cols).where(model.tenant_id == self.tenant_id, model.external_id.in_(ids[start : start + 5000]))
            for rec in self.s.execute(stmt):
                found[rec[0]] = rec
        return found

    def load_chunk(self, items: list[tuple[int, dict, dict]]) -> None:
        now = utcnow()
        unique: dict[str, tuple[int, dict, dict]] = {}
        for rn, row, raw in items:
            key = row["external_id"]
            first = unique.get(key)
            if first is None:
                unique[key] = (rn, row, raw)
            elif first[1] == row:
                self.counts["duplicate"] += 1
            else:
                self.quarantine(rn, raw, [f"duplicate external_id '{key}' with conflicting values (first seen at row {first[0]})"])
        ref_maps = {
            s.name: self._resolve(s.ref, {row[s.name] for _, row, _ in unique.values() if row.get(s.name) is not None})
            for s in self.specs if s.ref
        }  # fmt: skip
        keys = list(unique)
        existing = {r["external_id"]: r for r in self.s.execute(
            select(self.table).where(self.table.c.tenant_id == self.tenant_id, self.table.c.external_id.in_(keys))
        ).mappings()}  # fmt: skip
        pinned: set[tuple[int, str]] = set()
        if existing:
            stmt = select(Correction.entity_id, Correction.field).where(
                Correction.tenant_id == self.tenant_id, Correction.entity_type == self.et, Correction.status == "applied",
                Correction.entity_id.in_([r["id"] for r in existing.values()]), Correction.applied_at >= self.dv.created_at)  # fmt: skip
            pinned = {(eid, field) for eid, field in self.s.execute(stmt)}
        defaults = ENTITY_DEFAULTS.get(self.et, {})
        control_field = CONTROL_TOTAL_FIELD.get(self.et)
        inserts: list[dict] = []
        history: list[dict] = []
        attribute_changes: list[dict] = []
        for key, (rn, row, raw) in unique.items():
            values: dict[str, Any] = {}
            problems: list[str] = []
            for spec in self.specs:
                value = row.get(spec.name)
                if spec.ref and value is not None:
                    target = ref_maps[spec.name].get(value)
                    if target is None:
                        problems.append(f"unknown {spec.ref.rstrip('s')} reference '{value}'")
                    else:
                        values[spec.attr] = target[1]
                        if self.et == "subscription_events" and spec.ref == "subscriptions":
                            values["customer_id"] = target[2]
                else:
                    values[spec.attr] = value
            if problems:
                self.quarantine(rn, raw, problems)
                continue
            current = existing.get(key)
            if current is None:
                record = {k: (defaults.get(k) if v is None else v) for k, v in values.items()}
                record.update(tenant_id=self.tenant_id, dataset_version_id=self.dv.id, source_row=rn, record_version=1,
                              created_at=now, updated_at=now)  # fmt: skip
                inserts.append(record)
                self.counts["inserted"] += 1
                if control_field and values.get(control_field) is not None:
                    self.control_total += values[control_field]
                continue
            diffs = {k: v for k, v in values.items() if k != "external_id" and not _same(current[k], v)}
            for field in [f for f in diffs if (current["id"], f) in pinned]:
                diffs.pop(field)
                self.pinned_skipped += 1
            if current["dataset_version_id"] == self.dv.id and current["source_row"] != rn:
                if diffs:  # a later row in the same file disagrees with an earlier one
                    self.quarantine(rn, raw, [f"duplicate external_id '{key}' with conflicting values "
                                              f"(first seen at row {current['source_row']})"])  # fmt: skip
                else:
                    self.counts["duplicate"] += 1
                continue
            if not diffs:
                self.counts["unchanged"] += 1
                continue
            self.s.execute(update(self.table).where(self.table.c.id == current["id"]).values(
                **diffs, dataset_version_id=self.dv.id, source_row=rn, record_version=current["record_version"] + 1,
                updated_at=now))  # fmt: skip
            history.append({"tenant_id": self.tenant_id, "entity_type": self.et, "entity_id": current["id"],
                            "record_version": current["record_version"] + 1, "change_source": "import",
                            "dataset_version_id": self.dv.id, "correction_id": None, "changed_by": self.run.created_by,
                            "changed_at": now, "before": json_safe({k: current[k] for k in diffs}),
                            "after": json_safe(diffs)})  # fmt: skip
            if self.et == "customers":
                attribute_changes += [{"customer_id": current["id"], "attribute": k, "value": v, "effective_at": values.get("attributes_effective_at")}
                                      for k, v in diffs.items() if k in attributes.TRACKED]  # fmt: skip
            self.counts["updated"] += 1
            if control_field and values.get(control_field) is not None:
                self.control_total += values[control_field]
        if inserts:
            self.s.execute(insert(self.table), inserts)
        if history:
            self.s.execute(insert(EntityHistory.__table__), history)
        if self.et == "customers" and (inserts or attribute_changes):
            # slowly changing attributes keep their history: new customers get a timeline, changed values a new period
            attributes.after_customer_load(self.s, self.tenant_id, attribute_changes, dataset_version_id=self.dv.id,
                                           recorded_by=self.run.created_by, now=now)  # fmt: skip


def _cursor_value(row: dict, field: str | None) -> Any:
    value = row.get(field) if field else None
    return value.isoformat() if hasattr(value, "isoformat") else (None if value is None else str(value))


def run_import(import_run_id: int, ctx: Any = None) -> dict:
    """Execute one import run (idempotent: safe to retry after a crash)."""
    session = get_session_factory()()
    try:
        run = session.get(ImportRun, import_run_id)
        if run is None:
            raise jobs.PermanentJobError(f"import run {import_run_id} does not exist")
        source = session.get(DataSource, run.source_id)
        dv = session.get(DatasetVersion, run.dataset_version_id)
        mapping = session.execute(select(SourceMapping).where(SourceMapping.source_id == source.id,
                                                              SourceMapping.version == run.mapping_version)).scalar_one()  # fmt: skip
        path = verified_path(dv)
        entity_type = source.entity_type
        compiled = compile_mapping(entity_type, mapping.mapping)
        cursor_field = (source.config or {}).get("cursor_field")
        cursor_before = source.incremental_cursor if run.mode == "incremental" else None
        session.execute(delete(QuarantineRecord).where(QuarantineRecord.import_run_id == run.id, QuarantineRecord.status == "open"))
        run.status, run.started_at, run.error, run.cursor_before = "running", utcnow(), None, cursor_before
        session.commit()

        loader = _Loader(session, run, entity_type, dv, {spec.name for spec, _, _ in compiled})
        total = dv.row_count or 0
        now = utcnow()
        chunk: list[tuple[int, dict, dict]] = []

        def flush() -> None:
            loader.load_chunk(chunk)
            chunk.clear()
            c = loader.counts
            run.rows_read, run.rows_inserted, run.rows_updated = c["read"], c["inserted"], c["updated"]
            run.rows_unchanged, run.rows_duplicate, run.rows_quarantined = c["unchanged"], c["duplicate"], c["quarantined"]
            session.commit()
            if ctx is not None:
                ctx.progress(min(0.99, c["read"] / total) if total else 0.5, f"{c['read']:,} rows read")

        for row_number, raw in enumerate(iter_rows(path, dv.file_format, (source.config or {}).get("reader_options")), start=1):
            loader.counts["read"] += 1
            row, errors = normalize_row(entity_type, raw, compiled, now)
            if errors:
                loader.quarantine(row_number, raw, errors)
            else:
                cur = _cursor_value(row, cursor_field)
                if cur is not None and (loader.max_cursor is None or cur > loader.max_cursor):
                    loader.max_cursor = cur
                if cursor_before is not None and cur is not None and cur <= cursor_before:
                    loader.counts["skipped_cursor"] += 1
                else:
                    chunk.append((row_number, row, raw))
            if len(chunk) >= CHUNK_ROWS:
                flush()
        flush()

        c = loader.counts
        accounted = c["inserted"] + c["updated"] + c["unchanged"] + c["duplicate"] + c["quarantined"] + c["skipped_cursor"]
        written = session.execute(
            select(func.count()).select_from(loader.table).where(
                loader.table.c.tenant_id == run.tenant_id, loader.table.c.dataset_version_id == dv.id,
                loader.table.c.updated_at >= run.started_at)
        ).scalar_one()  # fmt: skip
        recon: dict[str, Any] = {
            "rows_in_file": total, "rows_read": c["read"], "accounted_for": accounted, "skipped_by_cursor": c["skipped_cursor"],
            "rows_written_expected": c["inserted"] + c["updated"], "rows_written_in_database": written,
            "fields_protected_by_approved_corrections": loader.pinned_skipped,
        }  # fmt: skip
        checks = [c["read"] == accounted, c["read"] == total, written == c["inserted"] + c["updated"]]
        field = CONTROL_TOTAL_FIELD.get(entity_type)
        if field and field in {spec.attr for spec in loader.specs}:
            db_total = session.execute(
                select(func.sum(loader.table.c[field])).where(
                    loader.table.c.tenant_id == run.tenant_id, loader.table.c.dataset_version_id == dv.id,
                    loader.table.c.updated_at >= run.started_at)
            ).scalar()  # fmt: skip
            db_total = money(db_total or 0)
            recon["control_total"] = {"field": field, "file": str(money(loader.control_total)), "database": str(db_total)}
            if loader.pinned_skipped == 0:
                checks.append(db_total == money(loader.control_total))
        recon["balanced"] = all(checks)
        run.reconciliation = recon
        run.finished_at = utcnow()
        run.status = "completed" if recon["balanced"] else "reconciliation_failed"
        if loader.max_cursor is not None and cursor_field and recon["balanced"]:
            run.cursor_after = loader.max_cursor
            if source.incremental_cursor is None or loader.max_cursor > source.incremental_cursor:
                source.incremental_cursor = loader.max_cursor
        audit.record(session, tenant_id=run.tenant_id, action="import.finished", entity_type="import_run", entity_id=run.id,
                     detail={"status": run.status, **c})  # fmt: skip
        session.commit()
        return {"import_run_id": run.id, "status": run.status, **c, "reconciliation": recon}
    except Exception as exc:
        session.rollback()
        if not isinstance(exc, jobs.JobCancelled | jobs.JobInterrupted):
            session.execute(update(ImportRun).where(ImportRun.id == import_run_id).values(
                status="failed", error=str(exc)[:2000], finished_at=utcnow()))  # fmt: skip
            session.commit()
        raise
    finally:
        session.close()


# ----------------------------------------------------------------------------- REST API sources
def assert_fetchable_url(url: str) -> netguard.Target:
    """SSRF guard: only http(s) URLs that resolve to public addresses (unless explicitly allowed).

    Returns the request target pinned to the vetted address (see ``netguard``)."""
    return netguard.vet(url, allow_private=get_settings().ingest_allow_private_hosts, field_name="config.url")


def _dig(doc: Any, path: str | None) -> Any:
    for part in (path or "").split("."):
        if part:
            doc = doc.get(part) if isinstance(doc, dict) else None
    return doc


def _get_with_retry(client: httpx.Client, target: netguard.Target, params: dict, headers: dict, attempts: int = 4) -> httpx.Response:
    delay = 0.5
    for attempt in range(1, attempts + 1):
        try:
            resp = client.get(target.url, params=params, headers={**headers, **target.headers}, extensions=target.extensions)
        except httpx.HTTPError as exc:
            if attempt == attempts:
                raise ExternalServiceError(f"REST source request failed: {type(exc).__name__}") from exc
        else:
            if resp.status_code < 400:
                return resp
            if resp.status_code not in (429, 500, 502, 503, 504) or attempt == attempts:
                raise ExternalServiceError(f"REST source returned HTTP {resp.status_code}")
            retry_after = resp.headers.get("Retry-After", "")
            if retry_after.isdigit():
                delay = min(float(retry_after), 30.0)
        time.sleep(delay)
        delay = min(delay * 2, 30.0)
    raise ExternalServiceError("REST source request failed")  # pragma: no cover


def fetch_rest_records(config: dict, cursor: str | None) -> Iterator[dict]:
    target = assert_fetchable_url(config["url"])  # vetted once; every page goes to the same pinned address
    pag = config.get("pagination") or {}
    kind = pag.get("type", "none")
    size = int(pag.get("page_size", 100))
    params = dict(config.get("params") or {})
    incremental = config.get("incremental") or {}
    if cursor and incremental.get("param"):
        params[incremental["param"]] = cursor
    headers = dict(config.get("headers") or {})
    auth = config.get("auth") or {}
    if auth.get("secret_enc"):
        secret = SecretBox().decrypt(auth["secret_enc"])
        if auth.get("type", "bearer") == "bearer":
            headers["Authorization"] = f"Bearer {secret}"
        else:
            headers[auth.get("header", "X-Api-Key")] = secret
    page, offset, next_cursor = int(pag.get("start_page", 1)), 0, None
    with httpx.Client(timeout=get_settings().ingest_http_timeout_seconds, follow_redirects=False) as client:
        for _ in range(int(pag.get("max_pages", 10000))):
            query = dict(params)
            if kind == "page":
                query.update({pag.get("page_param", "page"): page, pag.get("size_param", "per_page"): size})
            elif kind == "offset":
                query.update({pag.get("offset_param", "offset"): offset, pag.get("limit_param", "limit"): size})
            elif kind == "cursor" and next_cursor:
                query[pag.get("cursor_param", "cursor")] = next_cursor
            try:
                doc = _get_with_retry(client, target, query, headers).json()
            except ValueError as exc:
                raise ExternalServiceError("REST source did not return JSON") from exc
            records = _dig(doc, config.get("records_path")) if config.get("records_path") else doc
            if not isinstance(records, list):
                raise ExternalServiceError("records_path did not resolve to a list of records")
            yield from records
            if kind == "page" and len(records) >= size:
                page += 1
            elif kind == "offset" and len(records) >= size:
                offset += len(records)
            elif kind == "cursor" and (next_cursor := _dig(doc, pag.get("next_cursor_path", "next_cursor"))):
                continue
            else:
                return
        raise ExternalServiceError("REST source exceeded the configured max_pages")


def _write_jsonl(records: Iterator[dict] | list[dict]) -> tuple[Path, int]:
    path, count = new_temp_path(".jsonl"), 0
    with open(path, "w", encoding="utf-8") as fh:
        for rec in records:
            if not isinstance(rec, dict):
                raise ExternalServiceError("source returned a record that is not a JSON object")
            fh.write(json.dumps(rec, sort_keys=True, default=str) + "\n")
            count += 1
    return path, count


def _store_and_import(session: Session, source: DataSource, path: Path, *, file_name: str, origin: str, mode: str,
                      created_by: int | None, ctx: Any) -> dict:
    """Store fetched records as a dataset version and load them (REST pulls and webhook deliveries).

    Storing and loading are two commits, and the job can be retried in between.  Identical bytes are therefore
    skipped only when they were actually LOADED before; a payload that was stored by an attempt which then failed
    is loaded now.  (Treating every stored payload as done would turn a failed import into a silent success.)
    """
    dv, duplicate = register_file(session, source=source, tmp_path=path, file_name=file_name, created_by=created_by, origin=origin)
    session.commit()
    if duplicate and session.execute(select(ImportRun.id).where(ImportRun.dataset_version_id == dv.id, ImportRun.status == "completed")
                                     .limit(1)).first() is not None:  # fmt: skip
        return {"status": "duplicate_payload", "dataset_version_id": dv.id}
    mapping = current_mapping(session, source.id)
    try:
        if mapping is None:
            raise ValidationFailed("the source has no column mapping yet")
        validate_mapping(source.entity_type, mapping.mapping)
        require_mapped_columns(source.entity_type, mapping.mapping, dv)
    except ValidationFailed as exc:  # needs a person: retrying would only fetch the same records again
        raise jobs.PermanentJobError(
            f"the records were stored as dataset version {dv.version_no} but cannot be loaded: {exc.message}. "
            "Correct the column mapping of the source, then retry this job.") from exc
    return _import_inline(session, source, dv, mode, created_by, ctx)


def _import_inline(session: Session, source: DataSource, dv: DatasetVersion, mode: str, created_by: int | None, ctx: Any) -> dict:
    mapping = current_mapping(session, source.id)
    run = ImportRun(tenant_id=source.tenant_id, source_id=source.id, dataset_version_id=dv.id, mode=mode,
                    mapping_version=mapping.version, status="pending", created_by=created_by,
                    job_id=ctx.job_id if ctx is not None else None)  # fmt: skip
    session.add(run)
    session.commit()
    return run_import(run.id, ctx)


def run_rest_pull(source_id: int, mode: str, created_by: int | None, ctx: Any = None) -> dict:
    """Pull every page from a REST source into a new dataset version, then import it."""
    session = get_session_factory()()
    try:
        source = session.get(DataSource, source_id)
        if source is None or source.kind != "rest_api":
            raise jobs.PermanentJobError(f"source {source_id} is not a REST source")
        cursor = source.incremental_cursor if mode == "incremental" else None
        path, count = _write_jsonl(fetch_rest_records(source.config, cursor))
        if count == 0:
            path.unlink(missing_ok=True)
            return {"records_fetched": 0, "status": "no_new_records"}
        stamp = utcnow().strftime("%Y%m%dT%H%M%SZ")
        return {"records_fetched": count, **_store_and_import(session, source, path, file_name=f"rest-{source.id}-{stamp}.jsonl", origin="rest",
                                                              mode=mode, created_by=created_by, ctx=ctx)}  # fmt: skip
    finally:
        session.close()


# ----------------------------------------------------------------------------- webhook sources
# The webhook receiver is the one route anybody on the network can call.  A rejected delivery is worth an audit
# event, but an unauthenticated caller must not be able to append to the audit chain without bound.
REJECTION_AUDITS_PER_MINUTE = 20
_rejections: dict[int, deque[float]] = defaultdict(deque)
_rejections_lock = threading.Lock()


def _rejection_audit_allowed(source_id: int) -> bool:
    now = time.monotonic()
    with _rejections_lock:
        window = _rejections[source_id]
        while window and now - window[0] > 60:
            window.popleft()
        if len(window) >= REJECTION_AUDITS_PER_MINUTE:
            return False
        window.append(now)
        return True


def receive_webhook(session: Session, source_id: int, body: bytes, signature: str | None, idempotency_key: str | None) -> dict:
    """Verify, de-duplicate and persist one inbound webhook delivery (processed later by the worker)."""
    source = session.get(DataSource, source_id)
    if source is None or source.kind != "webhook" or not source.is_active or not source.webhook_secret_enc:
        raise NotFound("webhook source not found")
    expected = "sha256=" + hmac_sha256_hex(SecretBox().decrypt(source.webhook_secret_enc), body)
    if not signature or not constant_time_equals(signature.strip(), expected):
        if _rejection_audit_allowed(source.id):
            audit.record(session, tenant_id=source.tenant_id, action="webhook.rejected", entity_type="data_source",
                         entity_id=source.id, detail={"reason": "bad_signature"})  # fmt: skip
            session.commit()
        else:
            log.warning("webhook rejected (audit trail throttled)", extra={"ctx": {"source_id": source.id, "reason": "bad_signature"}})
        raise Unauthorized("webhook signature is missing or invalid", code="invalid_signature")
    try:
        payload = json.loads(body)
    except ValueError as exc:
        raise ValidationFailed("webhook body must be JSON") from exc
    records = payload.get("records") if isinstance(payload, dict) and isinstance(payload.get("records"), list) else [payload]
    if not records or not all(isinstance(r, dict) for r in records):
        raise ValidationFailed("webhook body must be an object or {\"records\": [objects]}")
    key = (idempotency_key or (payload.get("event_id") if isinstance(payload, dict) else None) or hashlib.sha256(body).hexdigest())
    key = str(key)[:200]
    duplicate = session.execute(select(WebhookEvent.id).where(
        WebhookEvent.tenant_id == source.tenant_id, WebhookEvent.provider == "generic", WebhookEvent.idempotency_key == key)).first()  # fmt: skip
    if duplicate:
        return {"status": "duplicate", "event_id": duplicate[0]}
    event = WebhookEvent(tenant_id=source.tenant_id, source_id=source.id, provider="generic", idempotency_key=key,
                         payload={"records": records}, signature_valid=True, status="received")  # fmt: skip
    session.add(event)
    session.flush()
    job = jobs.enqueue(session, tenant_id=source.tenant_id, job_type="ingest.webhook_flush", payload={"source_id": source.id},
                       idempotency_key=f"webhook-flush:{source.id}:{event.id}")  # fmt: skip
    return {"status": "accepted", "event_id": event.id, "records": len(records), "job_id": job.id}


def run_webhook_flush(source_id: int, ctx: Any = None) -> dict:
    """Turn all pending webhook deliveries for a source into one dataset version and import it."""
    session = get_session_factory()()
    try:
        source = session.get(DataSource, source_id)
        events = session.execute(select(WebhookEvent).where(WebhookEvent.source_id == source_id, WebhookEvent.status == "received")
                                 .order_by(WebhookEvent.id)).scalars().all()  # fmt: skip
        if not events:
            return {"status": "nothing_pending"}
        path, count = _write_jsonl([rec for ev in events for rec in ev.payload["records"]])
        result = _store_and_import(session, source, path, file_name=f"webhook-{source.id}-{events[0].id}-{events[-1].id}.jsonl",
                                   origin="webhook", mode="full", created_by=None, ctx=ctx)  # fmt: skip
        session.execute(update(WebhookEvent).where(WebhookEvent.id.in_([e.id for e in events]))
                        .values(status="processed", processed_at=utcnow()))  # fmt: skip
        session.commit()
        return {"events": len(events), "records": count, **result}
    finally:
        session.close()


# ----------------------------------------------------------------------------- quarantine review
def review_quarantine(session: Session, principal: Principal, ids: list[int], action: str, *,
                      corrected: dict[int, dict] | None = None, note: str | None = None) -> dict:
    """Bulk review: ``reject``, ``correct`` (save a fixed payload) or ``reprocess`` (try loading again)."""
    if action not in ("reject", "correct", "reprocess"):
        raise ValidationFailed("action must be reject, correct or reprocess", details={"field": "action"})
    if not ids:
        raise ValidationFailed("select at least one quarantined record", details={"field": "ids"})
    records = session.execute(select(QuarantineRecord).where(QuarantineRecord.tenant_id == principal.tenant_id,
                                                             QuarantineRecord.id.in_(ids))).scalars().all()  # fmt: skip
    if len(records) != len(set(ids)):
        raise NotFound("one or more quarantined records were not found")
    corrected = {int(k): v for k, v in (corrected or {}).items()}
    now = utcnow()
    outcome = {"rejected": 0, "corrected": 0, "reprocessed": 0, "still_failing": 0}
    for rec in records:
        if rec.status in ("rejected", "reprocessed"):
            raise Conflict(f"quarantined record {rec.id} is already {rec.status}")
        rec.reviewed_by, rec.reviewed_at, rec.review_note = principal.user_id, now, note
        if rec.id in corrected:
            if not isinstance(corrected[rec.id], dict):
                raise ValidationFailed("a corrected payload must be an object")
            rec.corrected_payload = corrected[rec.id]
        if action == "reject":
            rec.status = "rejected"
            outcome["rejected"] += 1
        elif action == "correct":
            if rec.corrected_payload is None:
                raise ValidationFailed(f"no corrected payload supplied for record {rec.id}")
            rec.status = "corrected"
            outcome["corrected"] += 1
    if action == "reprocess":
        by_run: dict[int, list[QuarantineRecord]] = {}
        for rec in records:
            by_run.setdefault(rec.import_run_id, []).append(rec)
        for run_id, recs in by_run.items():
            run = session.get(ImportRun, run_id)
            source = session.get(DataSource, run.source_id)
            dv = session.get(DatasetVersion, run.dataset_version_id)
            mapping = session.execute(select(SourceMapping).where(SourceMapping.source_id == source.id,
                                                                  SourceMapping.version == run.mapping_version)).scalar_one()  # fmt: skip
            compiled = compile_mapping(source.entity_type, mapping.mapping)
            loader = _Loader(session, run, source.entity_type, dv, {spec.name for spec, _, _ in compiled})
            for rec in recs:
                raw = rec.corrected_payload or rec.payload
                row, errors = normalize_row(source.entity_type, raw, compiled, now)
                before = loader.counts["quarantined"]
                if not errors:
                    with session.no_autoflush:
                        loader.load_chunk([(rec.row_number, row, raw)])
                failed_again = bool(errors) or loader.counts["quarantined"] > before
                if failed_again:
                    if not errors:  # the loader queued a fresh quarantine row: fold its reasons into this one
                        fresh = [o for o in session.new if isinstance(o, QuarantineRecord)]
                        errors = fresh[-1].reasons if fresh else ["could not be loaded"]
                        for obj in fresh:
                            session.expunge(obj)
                    rec.reasons = errors
                    outcome["still_failing"] += 1
                else:
                    rec.status = "reprocessed"
                    outcome["reprocessed"] += 1
            run.rows_quarantined = max(0, run.rows_quarantined - sum(1 for r in recs if r.status == "reprocessed"))
            run.rows_inserted += loader.counts["inserted"]
            run.rows_updated += loader.counts["updated"]
            run.rows_unchanged += loader.counts["unchanged"] + loader.counts["duplicate"]
    audit.record(session, tenant_id=principal.tenant_id, actor=principal, action=f"quarantine.{action}",
                 entity_type="quarantine", detail={"ids": sorted(ids)[:200], "count": len(ids), **outcome, "note": note})  # fmt: skip
    return outcome
