// Screens: customer signals — support sentiment, feature adoption, identity & active users, attribute history.
import { api, can, h, card, kpi, kv, notice, badge, pageHead, button, dataTable, pagedTable, tabs, empty, bar, link, words,
  fmtInt, fmtNum, fmtPct, fmtDate, fmtDateTime, shortHash, formDialog, confirmDialog, openDialog, startJob, trackJob, toast, clear, isNum } from "./core.js";
import { lineChart, barChart } from "./charts.js";

const closeFoot = () => h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"));
const select = (name, options, onchange, label) => {
  const el = h("select", { name, "aria-label": label || name }, options.map((o) => { const [v, l] = Array.isArray(o) ? o : [o, o === "" ? `Any ${label || name}` : words(o)]; return h("option", { value: v }, l); }));
  el.addEventListener("change", onchange); return el;
};
const search = (placeholder, onchange) => {
  const el = h("input", { type: "search", placeholder, "aria-label": placeholder });
  let timer; el.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(onchange, 300); }); return el;
};
const LABEL_CLASS = { positive: "ok", negative: "alert", neutral: "plain", mixed: "warning", uncertain: "pending" };
const sentimentBadge = (row) => (row.state !== "ok" ? badge("skipped", words(row.state)) : badge(LABEL_CLASS[row.label] || "pending", row.label));

// ------------------------------------------------------------------ sentiment
export async function sentiment() {
  const root = h("div");
  async function render() {
    const data = await api("/signals/sentiment");
    const { status, summary } = data;
    const provider = status.provider;
    const model = summary.model;
    const head = pageHead("Support sentiment", "What customers say in tickets and chats, labelled by a language model that runs inside this installation. No text is sent anywhere.", [
      can("signals:write") ? button("Try a message", tryMessage) : null,
      can("signals:write") ? button("Evaluate on labelled texts", evaluateDialog) : null,
      can("signals:write") ? button(status.pending ? `Score ${fmtInt(status.pending)} waiting` : "Score again", () => startJob("Sentiment scoring", "/signals/sentiment/runs", {}, render), "primary") : null]);
    const banners = [];
    if (status.problem) banners.push(notice("danger", h("strong", null, "The configured sentiment model cannot be used. "), status.problem));
    else if (provider.is_baseline) {
      banners.push(notice("warning", h("strong", null, "Word-list baseline in use. "),
        "This is a fixed list of English words, not a trained model. It ignores negation, context and every other language. ",
        status.fallback_reason ? `It stands in because ${status.fallback_reason}.` : "It was selected in the configuration."));
    }
    if (model && !status.active_model_is_current) banners.push(notice("warning", "The scores shown were made by a different model than the one configured now. Score again to replace them."));
    const accuracy = status.production_accuracy;
    banners.push(accuracy.status === "BLOCKED"
      ? notice("warning", h("strong", null, "Accuracy on real support text: not measured. "), `Reason: ${accuracy.reason}. Upload a sample of your own messages with labels (Evaluate on labelled texts) to measure it.`)
      : notice("info", "Accuracy was measured on labelled texts that are not synthetic. See Evaluations."));
    const labels = summary.by_label || {};
    const states = summary.by_state || {};
    const scored = states.ok || 0;
    const kpis = h("div", { class: "grid kpis" },
      kpi("Messages scored", fmtInt(scored), `of ${fmtInt(summary.total)} in the last ${summary.window_days || 180} days`),
      kpi("Negative", fmtPct(scored ? (labels.negative || 0) / scored : null), `${fmtInt(labels.negative || 0)} messages`, "high"),
      kpi("Positive", fmtPct(scored ? (labels.positive || 0) / scored : null), `${fmtInt(labels.positive || 0)} messages`),
      kpi("Mixed or uncertain", fmtPct(scored ? ((labels.mixed || 0) + (labels.uncertain || 0)) / scored : null), "two opinions at once, or no clear one"),
      kpi("Could not be scored", fmtInt(summary.total - scored), Object.entries(states).filter(([k]) => k !== "ok").map(([k, v]) => `${words(k)} ${fmtInt(v)}`).join(" · ") || "none"));
    const weekly = summary.weekly || [];
    const trend = weekly.length > 1
      ? lineChart({ height: 230, yLabel: "Share of scored messages", label: "Weekly share of negative and positive messages", yFmt: (v) => fmtPct(v, 0), yDomain: [0, 1],
        xFmt: (i) => (weekly[Math.round(i)] ? weekly[Math.round(i)].week.slice(5) : ""),
        series: [{ name: "Negative", color: "red", points: weekly.map((w, i) => [i, w.negative_share]) }, { name: "Positive", color: "accent", points: weekly.map((w, i) => [i, w.positive_share]) }] })
      : empty("Not enough history", "A trend needs scored messages from at least two weeks.");
    const languages = dataTable([
      { label: "Language", value: (r) => (r.language === "none" ? "not detected" : r.language) },
      { label: "Messages", align: "right", value: (r) => fmtInt(r.total) },
      { label: "Covered by the model", value: (r) => (r.language === "none" ? badge("skipped", "n/a") : r.supported ? badge("ok", "yes") : badge("warning", "no")) },
      { label: "Negative", align: "right", value: (r) => fmtInt(r.negative || 0) }, { label: "Neutral", align: "right", value: (r) => fmtInt(r.neutral || 0) },
      { label: "Positive", align: "right", value: (r) => fmtInt(r.positive || 0) }, { label: "Mixed", align: "right", value: (r) => fmtInt(r.mixed || 0) },
    ], summary.by_language || [], { caption: "Messages by language", emptyText: "No messages have been scored yet." });
    const worst = dataTable([
      { label: "Customer", value: (r) => link(r.name || r.external_id, `#/customers/${r.customer_id}`) },
      { label: "Scored messages", align: "right", value: (r) => fmtInt(r.interactions) }, { label: "Negative", align: "right", value: (r) => fmtInt(r.negative) },
      { label: "Average sentiment", align: "right", value: (r) => fmtNum(r.avg_score, 2) },
    ], summary.customers || [], { caption: "Customers with the most negative messages", emptyText: "No customer has two or more scored messages yet." });
    const modelCard = provider ? kv([
      ["Provider", provider.is_baseline ? "Word-list baseline (not a trained model)" : "Local transformer (ONNX Runtime)"], ["Model", provider.model_id],
      ["Version", h("code", null, shortHash(provider.model_version))], ["Weights checksum (SHA-256)", h("code", { title: provider.checksum_sha256 }, shortHash(provider.checksum_sha256))],
      ["Tokenizer", provider.tokenizer], ["Languages covered", (provider.languages || []).join(", ")], ["Licence", provider.license],
      ["Source", provider.source], ["Language detection", status.language_detector], ["Where it runs", status.inference], ["Notes", provider.note],
    ]) : empty("No provider", status.problem || "");
    const filters = { label: "", state: "", language: "", q: "" };
    const table = pagedTable({
      caption: "Scored messages", pageSize: 20,
      load: (page, pageSize) => api(`/signals/sentiment/scores?page=${page}&page_size=${pageSize}` + Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join("")),
      columns: [
        { label: "When", value: (r) => fmtDate(r.occurred_at) }, { label: "Customer", value: (r) => link(r.customer_name || r.customer_external_id, `#/customers/${r.customer_id}`) },
        { label: "Sentiment", value: sentimentBadge }, { label: "Confidence", align: "right", value: (r) => (isNum(r.confidence) ? fmtPct(r.confidence, 0) : "–") },
        { label: "Language", value: (r) => r.language || "–" },
        { label: "Message (personal details removed)", cls: "wrap", value: (r) => h("span", null, r.excerpt || h("span", { class: "muted" }, "empty"), (r.flags || []).includes("truncated") ? h("span", { class: "muted" }, " (long message, shortened)") : null) },
      ],
      emptyNode: empty("No messages match", "Change the filters, or score the support messages first."),
    });
    const filterBar = h("div", { class: "toolbar" },
      select("label", ["", "negative", "positive", "neutral", "mixed", "uncertain"], (e) => { filters.label = e.target.value; table.reload(); }, "sentiment"),
      select("state", ["", "ok", "empty", "too_short", "unsupported_language", "language_undetermined", "error"], (e) => { filters.state = e.target.value; table.reload(); }, "state"),
      select("language", ["", ...(summary.by_language || []).filter((l) => l.language !== "none").map((l) => l.language)], (e) => { filters.language = e.target.value; table.reload(); }, "language"),
      (() => { const el = search("Search customer or text", () => { filters.q = el.value; table.reload(); }); return el; })());
    const evaluations = dataTable([
      { label: "When", value: (r) => fmtDateTime(r.created_at) }, { label: "Labelled set", value: (r) => r.dataset_name },
      { label: "Kind", value: (r) => (r.is_synthetic ? badge("warning", "synthetic") : badge("ok", "real text")) }, { label: "Texts", align: "right", value: (r) => fmtInt(r.rows) },
      { label: "Covered", align: "right", value: (r) => fmtPct(r.metrics.coverage) }, { label: "Agreement on covered", align: "right", value: (r) => fmtPct(r.metrics.accuracy_on_covered) },
      { label: "Agreement on all", align: "right", value: (r) => fmtPct(r.metrics.accuracy_on_all) }, { label: "Opposite label", align: "right", value: (r) => fmtInt(r.metrics.polarity_errors) },
      { label: "", value: (r) => button("Details", () => evaluationDetail(r), "small") },
    ], accuracy.evaluations || [], { caption: "Evaluations against labelled texts", emptyText: "No evaluation yet." });
    clear(root).append(head, ...banners, kpis,
      h("div", { class: "grid cols-2" }, card("Weekly trend", trend, { sub: "share of the messages that could be scored" }), card("Model in use", modelCard)),
      h("div", { class: "grid cols-2" }, card("By language", languages, { flush: true }), card("Customers to look at", worst, { flush: true })),
      card("Messages", h("div", null, filterBar, table.el), { flush: true }),
      card("Evaluations", evaluations, { flush: true, sub: "agreement with labels written by people" }));
  }
  async function tryMessage() {
    const out = h("div");
    await formDialog({ title: "Try a message", description: "Scores the text with the model in use. Nothing is stored.", submitLabel: "Score", wide: true,
      fields: [{ name: "text", label: "Message", type: "textarea", required: true, placeholder: "The export keeps failing and nobody answers." }],
      onSubmit: async (v) => {
        const res = await api("/signals/sentiment/analyse", { method: "POST", body: { texts: [v.text] } });
        const r = res.results[0];
        const dialog = openDialog({ title: "Result", body: h("div", null, out, closeFoot()) });
        clear(out).append(kv([["Sentiment", sentimentBadge(r)], ["Confidence", isNum(r.confidence) ? fmtPct(r.confidence, 0) : "–"], ["Language", r.language || "not detected"],
          ["Positive / neutral / negative", r.state === "ok" ? `${fmtPct(r.p_positive, 0)} / ${fmtPct(r.p_neutral, 0)} / ${fmtPct(r.p_negative, 0)}` : "–"],
          ["Personal details removed", Object.keys(r.redactions || {}).length ? Object.entries(r.redactions).map(([k, n]) => `${k} ${n}`).join(", ") : "none found"],
          ["Text as scored", r.excerpt], ["Scored by", res.provider.is_baseline ? "word-list baseline" : res.provider.model_id]]));
        void dialog;
      } });
  }
  async function evaluateDialog() {
    const res = await formDialog({ title: "Evaluate on labelled texts", wide: true, submitLabel: "Evaluate",
      description: "Paste a JSON list of {\"text\": …, \"label\": positive | negative | neutral | mixed}. Use messages from your own support desk, labelled by people.",
      fields: [{ name: "dataset_name", label: "Name of this labelled set", required: true }, { name: "rows", label: "Labelled texts (JSON list)", type: "json", value: [] },
        { name: "is_synthetic", label: "These texts are synthetic", type: "checkbox", hint: "synthetic sets do not count as an accuracy measurement" }],
      onSubmit: (v) => api("/signals/sentiment/evaluations", { method: "POST", body: v }) });
    if (res) { toast("Evaluation stored", "success"); await render(); }
  }
  function evaluationDetail(r) {
    const m = r.metrics;
    openDialog({ title: `Evaluation: ${r.dataset_name}`, wide: true, body: h("div", null,
      m.caveat ? notice("warning", m.caveat) : null,
      kv([["Texts", fmtInt(m.rows)], ["Covered (scored with a clear label)", `${fmtInt(m.covered)} (${fmtPct(m.coverage)})`], ["Agreement on covered", fmtPct(m.accuracy_on_covered)],
        ["Agreement on all", fmtPct(m.accuracy_on_all)], ["Macro F1", fmtNum(m.macro_f1, 3)], ["Opposite label (positive ↔ negative)", fmtInt(m.polarity_errors)],
        ["Labelled uncertain", fmtInt(m.uncertain)], ["Not scored", Object.entries(m.not_scored_by_state || {}).map(([k, v]) => `${words(k)} ${v}`).join(", ") || "none"],
        ["Model", `${m.model.model_id}${m.model.is_baseline ? " (baseline)" : ""}`]]),
      h("h3", null, "By label"),
      dataTable([{ label: "Label", value: (x) => x[0] }, { label: "Texts", align: "right", value: (x) => fmtInt(x[1].support) }, { label: "Precision", align: "right", value: (x) => fmtPct(x[1].precision) },
        { label: "Recall", align: "right", value: (x) => fmtPct(x[1].recall) }, { label: "F1", align: "right", value: (x) => fmtNum(x[1].f1, 3) }], Object.entries(m.per_label || {})),
      h("h3", null, "By language"),
      dataTable([{ label: "Language", value: (x) => x[0] }, { label: "Texts", align: "right", value: (x) => fmtInt(x[1].n) }, { label: "Covered", align: "right", value: (x) => fmtInt(x[1].covered) },
        { label: "Agree", align: "right", value: (x) => fmtInt(x[1].correct) }], Object.entries(m.per_language || {})), closeFoot()) });
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ feature adoption
export async function adoption() {
  const root = h("div");
  async function render() {
    const [overview, catalog] = await Promise.all([api("/signals/adoption"), api("/signals/catalog")]);
    const latest = overview.latest;
    const res = latest ? latest.result : null;
    const head = pageHead("Feature adoption", "Which product features each customer uses, measured against a feature list that somebody approved.", [
      can("signals:write") ? button("Add a feature", () => featureDialog()) : null,
      can("signals:write") && catalog.in_force ? button("Measure now", measure, "primary") : null]);
    const body = tabs([
      { id: "overview", label: "Adoption", render: () => adoptionTab(overview, res, latest) },
      { id: "catalog", label: `Feature list (${catalog.in_force} in force)`, render: () => catalogTab(catalog) },
      { id: "customers", label: "By customer", render: () => (latest ? customersTab(latest, res) : empty("No measurement yet", "Measure adoption first.")) },
    ], window.location.hash.includes("tab=catalog") ? "catalog" : "overview");
    clear(root).append(...[head, !catalog.in_force ? notice("warning", h("strong", null, "No approved feature list. "), "Adoption cannot be measured, and the adoption features of the churn model stay empty, until at least one feature is approved.") : null,
      catalog.conflicts.length ? notice("danger", `${catalog.conflicts.length} telemetry name(s) are claimed by more than one feature. One event can count for one feature only.`) : null, body].filter(Boolean));
  }
  function adoptionTab(overview, res, latest) {
    if (!res) return empty("No measurement yet", "Approve a feature list, then choose Measure now. The nightly pipeline measures adoption as well.");
    const features = res.features;
    const measurable = features.filter((f) => f.mapping_state === "ok");
    const kpis = h("div", { class: "grid kpis" },
      kpi("Average adoption rate", fmtPct(res.mean_adoption_rate), `per customer, last ${res.window_days} days to ${fmtDate(res.as_of_date)}`),
      kpi("Median adoption rate", fmtPct(res.median_adoption_rate), "half of the customers are below this"),
      kpi("Customers measured", fmtInt(res.customers_measured), "active on that date, with usage data"),
      kpi("Not measurable", fmtInt(res.customers_without_telemetry + res.customers_without_eligible_features), `${fmtInt(res.customers_without_telemetry)} without usage data · ${fmtInt(res.customers_without_eligible_features)} with no feature in their plan`),
      kpi("Events no feature claims", fmtInt(res.unmapped_events), res.unmapped_telemetry.length ? `${res.unmapped_telemetry.length} telemetry name(s)` : "all usage is mapped"));
    const chart = measurable.length ? barChart({ labels: measurable.map((f) => f.name), series: [{ name: "Adoption rate", color: "accent", values: measurable.map((f) => f.adoption_rate || 0) }],
      yLabel: "Share of eligible customers", yFmt: (v) => fmtPct(v, 0), yDomain: [0, 1], label: "Adoption rate by feature", height: 240 }) : empty("Nothing measurable", "");
    const table = dataTable([
      { label: "Feature", value: (f) => h("span", null, f.name, f.is_core ? h("span", { class: "badge" }, "core") : null) },
      { label: "Could use it", align: "right", value: (f) => fmtInt(f.eligible_customers) }, { label: "Adopted", align: "right", value: (f) => fmtInt(f.adopted_customers) },
      { label: "Adoption rate", value: (f) => (f.mapping_state === "ok" ? bar(f.adoption_rate, "", fmtPct(f.adoption_rate)) : badge("warning", "no usage data seen")) },
      { label: "New", align: "right", value: (f) => fmtInt(f.new_adopters) }, { label: "Stopped", align: "right", value: (f) => fmtInt(f.abandoned) },
      { label: "Days to first use (median)", align: "right", value: (f) => fmtNum(f.median_days_to_first_use, 1) },
      { label: "Users per adopting customer", align: "right", value: (f) => fmtNum(f.users_per_adopting_customer, 1) },
    ], features, { caption: "Adoption by feature" });
    const segments = dataTable([
      { label: "Segment", value: (s) => words(s.segment.replace(":", ": ")) }, { label: "Customers", align: "right", value: (s) => fmtInt(s.customers) },
      { label: "Adoption rate", value: (s) => bar(s.adoption_rate, "", fmtPct(s.adoption_rate)) },
    ], res.segments, { caption: "Adoption by segment" });
    const trendPoints = overview.trend.filter((p) => p.window_days === res.window_days && isNum(p.mean_adoption_rate));
    const trend = trendPoints.length > 1
      ? lineChart({ height: 220, yLabel: "Average adoption rate", yFmt: (v) => fmtPct(v, 0), label: "Average adoption rate over time", xFmt: (i) => (trendPoints[Math.round(i)] ? trendPoints[Math.round(i)].as_of_date.slice(5) : ""),
        series: [{ name: "Average adoption rate", color: "accent", dots: true, points: trendPoints.map((p, i) => [i, p.mean_adoption_rate]) }] })
      : empty("One measurement so far", "The trend appears after adoption has been measured for a second date.");
    const unmapped = res.unmapped_telemetry.length ? dataTable([
      { label: "Event type", value: (u) => words(u.event_type) }, { label: "Name in telemetry", value: (u) => h("code", null, u.feature_name) }, { label: "Events", align: "right", value: (u) => fmtInt(u.events) },
    ], res.unmapped_telemetry, { caption: "Telemetry no feature claims" }) : null;
    return h("div", { class: "stack" }, kpis,
      h("div", { class: "grid cols-2" }, card("By feature", chart), card("Over time", trend)),
      card("Features", table, { flush: true, sub: `measured ${fmtDateTime(latest.finished_at)}` }),
      h("div", { class: "grid cols-2" }, card("By segment", segments, { flush: true }),
        card("How this is counted", kv(Object.entries(res.definitions).map(([k, v]) => [words(k), v])))),
      unmapped ? card("Usage that no feature claims", unmapped, { flush: true, sub: "add these names to a feature, or leave them out on purpose" }) : null);
  }
  function catalogTab(catalog) {
    const table = dataTable([
      { label: "Feature", value: (f) => h("span", null, h("strong", null, f.name), h("div", { class: "muted small" }, f.feature_key)) },
      { label: "Version", align: "right", value: (f) => `v${f.version}` },
      { label: "State", value: (f) => h("span", null, badge(f.status), f.in_force ? h("span", { class: "badge ok" }, "in force") : null, f.status === "approved" && !f.is_active ? badge("skipped", "switched off") : null) },
      { label: "Counts as use", cls: "wrap", value: (f) => f.event_mapping.map((m) => `${words(m.event_type)}: ${m.feature_name}`).join(", ") },
      { label: "Adopted when", value: (f) => `${f.adoption_rule.min_events}+ events on ${f.adoption_rule.min_days}+ days` },
      { label: "Who can use it", cls: "wrap", value: (f) => [f.eligibility && f.eligibility.plan_tiers ? `plans: ${f.eligibility.plan_tiers.join(", ")}` : "all plans", f.release_date ? `from ${f.release_date}` : null, f.retired_date ? `until ${f.retired_date}` : null].filter(Boolean).join(" · ") },
      { label: "", value: (f) => h("div", { class: "actions" },
        f.status === "draft" && can("signals:write") ? button("Submit", () => act(`/signals/catalog/${f.id}/submit`, {}, "Submitted for review"), "small") : null,
        f.status === "pending" && can("signals:approve") ? button("Review", () => reviewDialog(f), "small primary") : null,
        f.status === "approved" && can("signals:approve") ? button(f.is_active ? "Switch off" : "Switch on", () => act(`/signals/catalog/${f.id}/active`, { active: !f.is_active }, "Saved"), "small") : null,
        can("signals:write") ? button("New version", () => featureDialog(f), "small") : null) },
    ], catalog.items, { caption: "Product-feature list", empty: empty("No features yet", "Add the product's features and say which usage events count for each.") });
    const telemetry = dataTable([
      { label: "Event type", value: (t) => words(t.event_type) }, { label: "Name in telemetry", value: (t) => h("code", null, t.feature_name) },
      { label: "Events", align: "right", value: (t) => fmtInt(t.events) }, { label: "First seen", value: (t) => fmtDate(t.first_seen) }, { label: "Last seen", value: (t) => fmtDate(t.last_seen) },
      { label: "Counts for", value: (t) => (t.mapped_to ? h("code", null, t.mapped_to) : badge("warning", "no feature")) },
    ], catalog.telemetry, { caption: "Names seen in usage data", emptyText: "No usage events carry a feature name yet." });
    return h("div", { class: "stack" }, card("Feature list", table, { flush: true, sub: "a version counts after somebody other than its author approved it" }),
      card("Names seen in usage data", telemetry, { flush: true }));
  }
  function customersTab(latest, res) {
    const filters = { feature_key: "", state: "", q: "" };
    const table = pagedTable({ caption: "Adoption by customer and feature", pageSize: 25,
      load: (page, pageSize) => api(`/signals/adoption/runs/${latest.id}/facts?page=${page}&page_size=${pageSize}` + Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join("")),
      columns: [
        { label: "Customer", value: (r) => link(r.customer_name || r.customer_external_id, `#/customers/${r.customer_id}`) }, { label: "Feature", value: (r) => r.feature_key },
        { label: "State", value: (r) => h("span", null, badge({ adopted: "ok", not_adopted: "warning", not_eligible: "skipped", unknown: "pending", invalid_mapping: "warning" }[r.state], words(r.state)),
          r.is_new ? h("span", { class: "badge ok" }, "new") : null, r.is_abandoned ? h("span", { class: "badge alert" }, "stopped") : null) },
        { label: "Events", align: "right", value: (r) => fmtInt(r.events) }, { label: "Days used", align: "right", value: (r) => fmtInt(r.active_days) },
        { label: "Users", align: "right", value: (r) => fmtInt(r.users) }, { label: "First used", value: (r) => fmtDate(r.first_used_at) }, { label: "Last used", value: (r) => fmtDate(r.last_used_at) }],
      emptyNode: empty("Nothing matches", "Change the filters.") });
    const bar2 = h("div", { class: "toolbar" },
      select("feature_key", ["", ...res.features.map((f) => f.feature_key)], (e) => { filters.feature_key = e.target.value; table.reload(); }, "feature"),
      select("state", ["", "adopted", "not_adopted", "not_eligible", "unknown", "invalid_mapping"], (e) => { filters.state = e.target.value; table.reload(); }, "state"),
      (() => { const el = search("Search customer", () => { filters.q = el.value; table.reload(); }); return el; })());
    return card(`Customers on ${fmtDate(latest.as_of_date)}`, h("div", null, bar2, table.el), { flush: true, sub: `last ${latest.window_days} days` });
  }
  async function act(path, body, message) { await api(path, { method: "POST", body }); toast(message, "success"); await render(); }
  async function measure() {
    const res = await formDialog({ title: "Measure adoption", submitLabel: "Measure", description: "Counts, for every active customer, which features of the approved list were adopted in the period before the date.",
      fields: [{ name: "as_of_date", label: "Date", type: "date", hint: "empty = the latest date with data" }, { name: "window_days", label: "Period (days)", type: "number", value: 30, min: 1, max: 365 }],
      onSubmit: (v) => api("/signals/adoption/runs", { method: "POST", body: { as_of_date: v.as_of_date, window_days: v.window_days || 30 } }) });
    if (res && res.job) { await trackJob(res.job, "Adoption"); await render(); }
  }
  async function featureDialog(from) {
    const res = await formDialog({ title: from ? `New version of ${from.name}` : "Add a feature", wide: true, submitLabel: "Save draft",
      description: "A draft has no effect. Submit it, and somebody else approves it.",
      fields: [
        { name: "feature_key", label: "Key", required: true, value: from ? from.feature_key : "", hint: "lower-case letters, digits, underscores; the same key makes a new version" },
        { name: "name", label: "Name", required: true, value: from ? from.name : "" },
        { name: "event_mapping", label: "Usage events that count (JSON list)", type: "json", value: from ? from.event_mapping : [{ event_type: "feature_use", feature_name: "" }] },
        { name: "adoption_rule", label: "Adopted when (JSON)", type: "json", value: from ? from.adoption_rule : { min_events: 3, min_days: 2 } },
        { name: "eligibility", label: "Who can use it (JSON; {} = every plan)", type: "json", value: from && from.eligibility ? from.eligibility : {} },
        { name: "release_date", label: "Released on", type: "date", value: from ? from.release_date : null }, { name: "retired_date", label: "Retired on", type: "date", value: from ? from.retired_date : null },
        { name: "is_core", label: "Core feature", type: "checkbox", value: from ? from.is_core : false }, { name: "owner", label: "Owner", value: from ? from.owner : "" }],
      onSubmit: (v) => api("/signals/catalog", { method: "POST", body: { ...v, eligibility: Object.keys(v.eligibility || {}).length ? v.eligibility : null } }) });
    if (res) { toast("Draft saved", "success"); await render(); }
  }
  async function reviewDialog(f) {
    const res = await formDialog({ title: `Review ${f.name} v${f.version}`, submitLabel: "Record decision",
      fields: [{ name: "approve", label: "Decision", type: "select", options: [["true", "Approve"], ["false", "Reject"]] }, { name: "note", label: "Note" }],
      onSubmit: (v) => api(`/signals/catalog/${f.id}/review`, { method: "POST", body: { approve: v.approve === "true", note: v.note } }) });
    if (res) { toast("Decision recorded", "success"); await render(); }
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ identity and active users
export async function identity() {
  const root = h("div");
  async function render() {
    const data = await api("/signals/identity");
    const recon = data.reconciliation ? data.reconciliation.result : null;
    const totals = recon ? recon.totals : null;
    const days = recon ? recon.days || [] : [];
    const last = recon ? recon.last_day : null;
    const head = pageHead("Active users & identity", "How many people use the product each day, and how user identifiers from the usage data are matched to people.", [
      link("Change the definition", "#/policies", "btn"),
      can("signals:write") ? button("Import a mapping", importDialog) : null,
      can("signals:write") ? button("Reconcile now", () => startJob("Identity reconciliation", "/signals/identity/reconciliations", { window_days: 90 }, render), "primary") : null]);
    if (!recon || !totals) {
      clear(root).append(head, empty("Not reconciled yet", "Choose Reconcile now to match the identifiers in the usage data to people and to compute daily, weekly and monthly active users."));
      return;
    }
    const kpis = h("div", { class: "grid kpis" },
      kpi("Daily active users", fmtInt(last ? last.dau : null), last ? `on ${last.day}` : ""), kpi("Weekly active users", fmtInt(last ? last.wau : null), "7 days to that day"),
      kpi("Monthly active users", fmtInt(last ? last.mau : null), "30 days to that day"), kpi("Stickiness (DAU ÷ MAU)", fmtPct(last ? last.stickiness : null), "how much of the month's users come back daily"),
      kpi("Events without a user", fmtPct(totals.events ? totals.events_without_user / totals.events : null), `${fmtInt(totals.events_without_user)} of ${fmtInt(totals.events)} events`, totals.events_without_user ? "high" : ""));
    const chart = days.length > 1 ? lineChart({ height: 250, yLabel: "People", label: "Daily, weekly and monthly active users", xFmt: (i) => (days[Math.round(i)] ? days[Math.round(i)].day.slice(5) : ""),
      series: [{ name: "Monthly", color: "violet", points: days.map((d, i) => [i, d.mau]) }, { name: "Weekly", color: "blue", points: days.map((d, i) => [i, d.wau]) }, { name: "Daily", color: "accent", points: days.map((d, i) => [i, d.dau]) }] })
      : empty("Not enough days", "");
    const def = data.definition;
    const definition = kv([
      ["Counts as activity", def.active_event_types.map(words).join(", ")], ["Days follow time zone", def.timezone],
      ["Not counted (staff, tests, automation)", def.exclude_user_patterns.length ? def.exclude_user_patterns.map((p) => h("code", null, p, " ")) : "nothing is excluded"],
      ["A customer's user counts are unknown below", `${fmtPct(def.min_identified_share, 0)} of events naming a user`],
      ["Approved definition", data.definition_is_default ? badge("warning", "built-in default (none approved)") : badge("ok", "approved policy")]]);
    const quality = kv([
      ["Identifiers in the usage data", fmtInt(totals.raw_identifiers)], ["People after matching", fmtInt(totals.people)],
      ["Spelling variants folded together", fmtInt(recon.links.raw_variants_folded)], ["Excluded identifiers / events", `${fmtInt(totals.excluded_identifiers)} / ${fmtInt(totals.excluded_events)}`],
      ["Events counting for nobody after review", fmtInt(totals.events_counting_for_nobody_after_review)],
      ["Customers whose user counts are unknown", `${fmtInt(totals.customers_below_identified_threshold)} of ${fmtInt(totals.customers_with_activity)} (too few events name a user)`],
      ["Customers that never name a user", fmtInt(totals.customers_without_any_user)],
      ["Same plain identifier under several customers", `${fmtInt(recon.links.non_email_identifiers_under_several_customers)} (counted as different people)`],
      ["Possible duplicates waiting for a decision", fmtInt(data.open_merge_candidates)]]);
    const candidates = dataTable([
      { label: "Why", value: (c) => words(c.reason) }, { label: "Identifiers", value: (c) => ((c.evidence || {}).identifiers || []).map((i) => h("code", null, i, " ")) },
      { label: "Confidence", align: "right", value: (c) => fmtPct(c.confidence, 0) },
      { label: "", value: (c) => (can("signals:approve") ? h("div", { class: "actions" },
        button("Same person", () => decide(c, true), "small primary"), button("Different people", () => decide(c, false), "small")) : null) },
    ], data.candidates.slice(0, 25), { caption: "Possible duplicates", empty: empty("No open candidates", "Nothing looks like the same person under two identifiers.") });
    const filters = { status: "", q: "" };
    const table = pagedTable({ caption: "Identity links", pageSize: 20,
      load: (page, pageSize) => api(`/signals/identity/links?page=${page}&page_size=${pageSize}` + Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join("")),
      columns: [
        { label: "Identifier", value: (r) => h("code", null, r.external_user_id) }, { label: "Customer", value: (r) => (r.customer_id ? link(r.customer_name || r.customer_external_id, `#/customers/${r.customer_id}`) : h("span", { class: "muted" }, "any customer")) },
        { label: "Person", value: (r) => h("code", { title: r.user_key }, shortHash(r.user_key)) }, { label: "Matched by", value: (r) => words(r.match_rule) }, { label: "State", value: (r) => badge(r.status === "quarantined" ? "warning" : r.status) },
        { label: "Valid", value: (r) => (r.valid_from || r.valid_to ? `${fmtDate(r.valid_from)} → ${fmtDate(r.valid_to)}` : "always") },
        { label: "", value: (r) => (can("signals:approve") && r.status !== "merged" ? h("div", { class: "actions" },
          r.status === "active" ? button("Quarantine", () => setStatus(r, "quarantined"), "small") : button("Put back", () => setStatus(r, "active"), "small")) : null) }],
      emptyNode: empty("No links match", "Change the filters.") });
    const linkBar = h("div", { class: "toolbar" }, select("status", ["", "active", "quarantined", "merged", "rejected"], (e) => { filters.status = e.target.value; table.reload(); }, "state"),
      (() => { const el = search("Search identifier, person or customer", () => { filters.q = el.value; table.reload(); }); return el; })());
    clear(root).append(...[head, data.definition_is_default ? notice("info", "No activity definition has been approved, so the built-in default applies. Create one under Policies (kind: activity definition) to exclude staff and test users or to change the time zone.") : null,
      kpis, card("Active users", chart, { sub: `reconciled ${fmtDateTime(data.reconciliation.finished_at)} · ${recon.window_days} days` }),
      h("div", { class: "grid cols-2" }, card("What counts", definition), card("Quality of the matching", quality)),
      card("Possible duplicates", candidates, { flush: true, sub: `${fmtInt(data.open_merge_candidates)} open · showing ${Math.min(25, data.candidates.length)} · nothing is merged without a decision` }),
      card("Identity links", h("div", null, linkBar, table.el), { flush: true })].filter(Boolean));
  }
  async function decide(c, merge) {
    const ok = await confirmDialog(merge ? "Same person?" : "Different people?", merge ? "The two identifiers will count as one person from now on. This can be undone." : "The candidate is closed and will not be proposed again.",
      merge ? "Merge" : "Keep apart", () => api(`/signals/identity/candidates/${c.id}/review`, { method: "POST", body: { merge } }));
    if (ok) { toast("Decision recorded", "success"); await render(); }
  }
  async function setStatus(r, status) {
    const ok = await confirmDialog(status === "quarantined" ? "Quarantine this identifier?" : "Put this identifier back?",
      status === "quarantined" ? "Its events count for nobody until it is put back." : "Its events count for its person again.", "Confirm",
      () => api(`/signals/identity/links/${r.id}/status`, { method: "POST", body: { status } }));
    if (ok) { toast("Saved", "success"); await render(); }
  }
  async function importDialog() {
    const res = await formDialog({ title: "Import an identity mapping", wide: true, submitLabel: "Import",
      description: "A JSON list of {\"external_user_id\", \"person_id\", \"customer_external_id\"}. Identifiers that share a person_id become one person. Identifiers that are not e-mail addresses need the customer.",
      fields: [{ name: "rows", label: "Mapping (JSON list)", type: "json", value: [] }], onSubmit: (v) => api("/signals/identity/links/import", { method: "POST", body: v }) });
    if (res) { toast(`${fmtInt(res.created)} link(s) created, ${fmtInt(res.rejected_rows)} row(s) rejected`, res.rejected_rows ? "info" : "success"); await render(); }
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ attribute history
export async function attributeHistory() {
  const data = await api("/signals/attributes");
  const basis = data.periods_by_basis || {};
  const total = Object.values(basis).reduce((a, b) => a + b, 0);
  const head = pageHead("Customer attribute history", "Industry, company size, head count, geography and acquisition channel as they were on any past date — so that a model trained on last year sees last year's customer.");
  const kpis = h("div", { class: "grid kpis" },
    kpi("Customers with history", `${fmtInt(data.customers_with_history)} of ${fmtInt(data.customers)}`), kpi("Periods on record", fmtInt(total)),
    kpi("Assumed (first value seen)", fmtPct(total ? (basis.initial || 0) / total : null), `${fmtInt(basis.initial || 0)} periods`),
    kpi("Changes with a known date", fmtInt((basis.effective || 0) + (basis.observed || 0) + (basis.backfill || 0) + (basis.correction || 0)), "effective, observed, backfilled or corrected"),
    kpi("Rewritten rows kept", fmtInt(data.superseded_rows), "what the platform believed before a fix"));
  const changes = dataTable([
    { label: "Attribute", value: (a) => words(a) }, { label: "Customers with a change", align: "right", value: (a) => fmtInt((data.customers_with_changes || {})[a] || 0) },
  ], data.tracked, { caption: "Changes by attribute" });
  const recent = dataTable([
    { label: "Recorded", value: (r) => fmtDateTime(r.recorded_at) }, { label: "Customer", value: (r) => link(r.customer_name || r.customer_external_id, `#/customers/${r.customer_id}`) },
    { label: "Attribute", value: (r) => words(r.attribute) }, { label: "New value", value: (r) => r.value }, { label: "From", value: (r) => fmtDate(r.valid_from) },
    { label: "Basis", value: (r) => badge(r.basis === "initial" ? "pending" : "ok", r.basis) },
    { label: "", value: (r) => button("Timeline", () => timelineDialog(r.customer_id, r.customer_name || r.customer_external_id), "small") },
  ], data.recent_changes, { caption: "Latest changes", empty: empty("No changes on record", "Every customer still has the first value the platform saw.") });
  return h("div", null, head, notice("info", data.note), kpis,
    h("div", { class: "grid cols-2" }, card("Changes by attribute", changes, { flush: true }), card("What the bases mean", kv([
      ["initial", "the first value seen; assumed to hold since the customer began"], ["effective", "a change whose source gave the date it took effect"],
      ["observed", "a change noticed at import; dated when it was noticed"], ["backfill", "declared history, trusted for any past date in its period"],
      ["correction", "a fix; past dates keep what was believed at the time"]]))),
    card("Latest changes", recent, { flush: true }));
}

export async function timelineDialog(customerId, name) {
  const data = await api(`/signals/attributes/customers/${customerId}`);
  const table = dataTable([
    { label: "Attribute", value: (p) => words(p.attribute) }, { label: "Value", value: (p) => (p.is_current ? p.value : h("s", null, p.value)) },
    { label: "From", value: (p) => (p.valid_from ? fmtDate(p.valid_from) : "the beginning") }, { label: "Until", value: (p) => (p.valid_to ? fmtDate(p.valid_to) : "now") },
    { label: "Basis", value: (p) => badge(p.basis === "initial" ? "pending" : "ok", p.basis) }, { label: "Recorded", value: (p) => fmtDate(p.recorded_at) },
    { label: "", value: (p) => (p.is_current ? null : badge("skipped", `replaced ${fmtDate(p.superseded_at)}`)) }, { label: "Note", cls: "wrap", value: (p) => p.note },
  ], data.periods, { caption: "Attribute timeline" });
  const actions = can("signals:approve") ? button("Rewrite a period", async () => {
    const res = await formDialog({ title: "Rewrite attribute history", submitLabel: "Record", description: "Backfill = declared history (used for past dates too). Correction = a fix (past dates keep what was believed then). The old rows stay on record.",
      fields: [{ name: "attribute", label: "Attribute", type: "select", options: data.tracked }, { name: "value", label: "Value" },
        { name: "valid_from", label: "From (empty = the beginning)", type: "date" }, { name: "valid_to", label: "Until (empty = now)", type: "date" },
        { name: "basis", label: "Basis", type: "select", options: ["correction", "backfill"] }, { name: "note", label: "Why", required: true }],
      onSubmit: (v) => api(`/signals/attributes/customers/${customerId}`, { method: "POST", body: { ...v, valid_from: v.valid_from ? `${v.valid_from}T00:00:00Z` : null, valid_to: v.valid_to ? `${v.valid_to}T00:00:00Z` : null } }) });
    if (res) toast("History rewritten. Reopen the timeline to see it.", "success");
  }) : null;
  openDialog({ title: `Attribute history: ${name}`, wide: true, body: h("div", null, table, h("div", { class: "dialog-foot" }, actions, h("form", { method: "dialog" }, h("button", { class: "btn" }, "Close")))) });
}
