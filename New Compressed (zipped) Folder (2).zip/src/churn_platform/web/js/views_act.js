// Screens: customers, Customer 360, retention recommendations, experiments & uplift, CRM sync.
import { api, can, h, card, kpi, kv, notice, badge, tierBadge, pageHead, button, dataTable, pagedTable, tabs, empty, jsonBlock, bar, link, go, words,
  fmtInt, fmtNum, fmtPct, fmtProb, fmtMoney, fmtDate, fmtDateTime, formDialog, openDialog, startJob, trackJob, toast, clear, isNum } from "./core.js";
import { lineChart, scatter, pctTick } from "./charts.js";
import { safe, SEGMENT_LABEL } from "./views_data.js";
import { reasonList, explanationCard } from "./views_ml.js";

const closeFoot = () => h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"));
const pp = (v, digits = 1) => (isNum(v) ? `${v >= 0 ? "+" : "−"}${Math.abs(v * 100).toFixed(digits)} pp` : "–");

// ------------------------------------------------------------------ customers
export async function customers() {
  const search = h("input", { type: "search", placeholder: "Search by name or customer ID", "aria-label": "Search customers", class: "grow" });
  const tier = h("select", { "aria-label": "Risk tier" }, h("option", { value: "" }, "All tiers"), ["high", "medium", "low"].map((t) => h("option", { value: t }, `${t} risk`)));
  const sort = h("select", { "aria-label": "Sort" }, [["risk", "Highest risk first"], ["name", "Name"], ["external_id", "Customer ID"]].map(([v, l]) => h("option", { value: v }, l)));
  const info = h("span", { class: "muted small" });
  const table = pagedTable({ load: async (page, size) => {
    const data = await api("/customers", { query: { page, page_size: size, q: search.value.trim(), tier: tier.value, sort: sort.value } });
    info.textContent = data.batch ? `Risk from the scoring batch for ${data.batch.as_of_date}` : "No scores yet";
    return data;
  }, caption: "Customers", columns: [
    { label: "Customer", value: (c) => h("span", null, c.name || c.external_id, h("span", { class: "sub" }, c.external_id)) },
    { label: "Industry", value: (c) => words(c.industry) }, { label: "Size", value: (c) => words(c.company_size) }, { label: "Region", value: (c) => (c.region ? String(c.region).toUpperCase() : "–") },
    { label: "Churn risk", value: (c) => (isNum(c.probability) ? bar(c.probability, c.risk_tier, fmtProb(c.probability)) : h("span", { class: "muted" }, "not scored")) },
    { label: "Tier", value: (c) => (c.risk_tier ? tierBadge(c.risk_tier) : "–") },
    { label: "Main factor", value: (c) => (c.top_reasons && c.top_reasons[0] ? String(c.top_reasons[0]).replace(/ \((raises|lowers) the predicted risk\)/, "") : "–") },
  ], onRow: (c) => go(`#/customers/${c.id}`), emptyNode: empty("No customers match", "Try a different search or tier.") });
  let timer; search.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => table.reload(), 300); });
  tier.addEventListener("change", () => table.reload()); sort.addEventListener("change", () => table.reload());
  return h("div", null, pageHead("Customers", "Every customer with the latest churn score. Open one for the full picture: subscription, billing, usage, support and the reasons behind the score."),
    card(null, h("div", null, h("div", { class: "toolbar" }, search, tier, sort, info), table.el), { flush: true }));
}

export async function customer360(id) {
  const root = h("div");
  async function render() {
    const c = await api(`/customers/${id}`);
    const cust = c.customer; const latest = (c.predictions || [])[0];
    const explanation = latest && can("predict:read") ? await safe(api(`/predictions/${latest.id}/explanation`)) : null;
    const activeSubs = c.subscriptions.filter((s) => s.status === "active" || s.status === "trialing" || s.status === "past_due");
    const mrr = activeSubs.reduce((sum, s) => sum + Number(s.mrr || 0), 0);
    const account = c.accounts[0];
    const failed = c.payments.filter((p) => p.status === "failed");
    clear(root).append(pageHead(cust.name || cust.external_id, `${cust.external_id} · ${words(cust.industry)} · ${words(cust.company_size)} · ${cust.country || "–"}`, [
      can("predict:run") ? button("Re-score now", async () => { await api(`/customers/${id}/predict`, { method: "POST" }); toast("Customer re-scored with the production model", "success"); await render(); }) : null,
    ], h("span", null, link("Customers", "#/customers"), ` / ${cust.external_id}`)));
    root.append(h("div", { class: "grid kpis" },
      latest ? kpi("Churn risk (30 days)", fmtProb(latest.probability), h("span", null, tierBadge(latest.risk_tier), " ", h("span", { class: "nowrap" }, `as of ${latest.as_of_date}`)), latest.risk_tier === "high" ? "high" : "") : kpi("Churn risk", "–", "not scored (no active paid subscription, or no batch yet)"),
      kpi("MRR", fmtMoney(mrr, (account && account.currency) || "USD", 2), activeSubs.length ? activeSubs.map((s) => s.plan_name).join(", ") : "no active subscription"),
      kpi("Customer since", fmtDate(cust.acquired_at), cust.acquisition_channel ? `via ${words(cust.acquisition_channel)}` : null),
      kpi("Failed payments", fmtInt(failed.length), failed.length ? `last on ${fmtDate(failed[0].attempted_at)}` : "none on record", failed.length ? "high" : "ok"),
      account ? kpi("Payment method", words(account.payment_method_type), account.payment_method_expires_on ? `expires ${account.payment_method_expires_on}` : "no expiry on file") : null));
    const usage = c.usage || [];
    const left = h("div", { class: "stack" },
      latest ? explanationCard(explanation) : null,
      card("Product usage", usage.length ? lineChart({ height: 220, yLabel: "Logins per day", label: "Logins per day",
        series: [{ name: "Logins", color: "accent", points: usage.map((u, i) => [i, u.logins]) }], xFmt: (i) => (usage[Math.round(i)] || {}).day?.slice(5) || "" }) : empty("No usage events", "No product telemetry has been loaded for this customer."),
      { sub: usage.length ? `${usage[0].day} → ${usage[usage.length - 1].day}` : null }),
      card("Support history", dataTable([
        { label: "Opened", value: (t) => fmtDate(t.opened_at) }, { label: "Kind", value: (t) => words(t.kind) }, { label: "Category", value: (t) => words(t.category) }, { label: "Priority", value: (t) => words(t.priority) },
        { label: "Status", value: (t) => h("span", null, words(t.status), t.escalated ? [" ", h("span", { class: "badge bad" }, "escalated")] : null) },
        { label: "CSAT", align: "right", value: (t) => (isNum(t.csat) ? t.csat : "–") }, { label: "NPS", align: "right", value: (t) => (isNum(t.nps_score) ? t.nps_score : "–") },
      ], c.support, { emptyText: "No tickets or surveys on record.", caption: "Support interactions" }), { flush: true }),
      card("Invoices and payments", dataTable([
        { label: "Issued", value: (i) => fmtDate(i.issued_at) }, { label: "Amount", align: "right", value: (i) => fmtMoney(i.amount, i.currency, 2) }, { label: "Due", value: (i) => fmtDate(i.due_at) },
        { label: "Paid", value: (i) => fmtDate(i.paid_at) }, { label: "Status", value: (i) => badge(i.status === "paid" ? "ok" : i.status === "open" ? "pending" : "failed", words(i.status)) },
      ], c.invoices, { emptyText: "No invoices on record.", caption: "Invoices" }), { flush: true, foot: failed.length ? `${failed.length} failed payment attempt(s): ${failed.slice(0, 3).map((p) => `${fmtDate(p.attempted_at)} (${words(p.failure_reason)})`).join(", ")}` : null }));
    const right = h("div", { class: "stack" },
      card("Profile", kv([["Contact", cust.email], ["Employees", fmtInt(cust.employee_count)], ["Region", cust.region ? String(cust.region).toUpperCase() : null],
        ["Marketing consent", cust.consent_marketing ? badge("ok", "given") : badge("warning", "not recorded")], ["Account status", account ? badge(account.status) : null], ["Success manager", account && account.csm_owner]])),
      card("Recommended actions", c.recommendations.length ? h("ul", { class: "timeline" }, c.recommendations.map((r) => h("li", { class: r.status === "blocked" ? "bad" : r.status === "executed" ? "good" : null },
        h("div", { class: "strong" }, (r.rationale && r.rationale.action_name) || words(r.action_code)), h("div", null, badge(r.status), " ", h("span", { class: "muted small" }, SEGMENT_LABEL[r.segment] || words(r.segment))),
        r.blocked_reason ? h("div", { class: "small muted" }, r.blocked_reason) : null))) : empty("No action proposed", "Recommendations are generated from the latest scores."), { actions: can("retention:read") ? link("All recommendations", "#/retention") : null }),
      card("Subscription timeline", c.subscription_events.length ? h("ul", { class: "timeline" }, c.subscription_events.slice(0, 12).map((e) => h("li", { class: /cancel|ended|fail|suspend|churn/.test(e.event_type) ? "bad" : /convert|start|reactiv|upgrade/.test(e.event_type) ? "good" : null },
        h("div", { class: "strong" }, words(e.event_type)), h("div", { class: "when" }, `${fmtDateTime(e.occurred_at)}${e.reason ? ` · ${words(e.reason)}` : ""}${e.mrr ? ` · MRR ${fmtMoney(e.mrr, "USD", 2)}` : ""}`)))) : empty("No events", "")),
      card("Risk history", dataTable([{ label: "As of", value: (p) => p.as_of_date }, { label: "Risk", value: (p) => bar(p.probability, p.risk_tier, fmtProb(p.probability)) }], c.predictions, { emptyText: "Not scored yet." }), { flush: true }),
      card("Observed outcomes", dataTable([{ label: "As of", value: (l) => l.as_of_date }, { label: "Outcome in the next 30 days", value: (l) => h("span", null, badge(l.status), l.churn_type ? ` ${words(l.churn_type)}` : "") }], c.labels, { emptyText: "No labels yet." }), { flush: true }));
    root.append(h("div", { class: "split" }, left, right), h("p", { class: "muted small" }, `Data cutoff ${fmtDateTime(c.data_cutoff)}. The score ranks customers by likelihood of churning; it does not say that an action will change the outcome.`));
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ retention
export async function retention() {
  const root = h("div");
  async function render() {
    const [head, batches] = await Promise.all([api("/retention/recommendations", { query: { page_size: 1 } }), can("predict:read") ? safe(api("/predictions/batches", { query: { page_size: 10 } })) : null]);
    const latest = batches && batches.items.find((b) => b.kind !== "backtest" && b.status === "completed");
    clear(root).append(pageHead("Retention recommendations", "Each scored customer is matched to a playbook action by risk tier and value: a personal call for high-risk, high-value accounts; automated re-engagement or an offer for the rest; payment reminders where the risk is a failing card.", [
      can("retention:write") && latest ? button("Regenerate from latest scores", () => startJob("Recommendations", "/retention/recommendations/generate", { batch_id: latest.id }, render)) : null]));
    const seg = head.summary ? head.summary.by_segment : {};
    const scope = head.scope || {};
    root.append(scope.batch_id
      ? notice("info", h("strong", null, `Work queue for the scores of ${scope.as_of_date}. `), "It shows the proposals from the most recent scoring run, plus actions approved earlier that have not been carried out yet. ",
        can("predict:read") ? link(`Open scoring batch #${scope.batch_id}`, `#/predictions/${scope.batch_id}`) : null)
      : notice("info", "No recommendations have been generated yet. Score the customers, then generate recommendations from that batch."));
    root.append(h("div", { class: "grid kpis" }, Object.entries(SEGMENT_LABEL).map(([key, label]) => {
      const counts = seg[key] || {}; const total = Object.values(counts).reduce((a, b) => a + b, 0);
      return kpi(label, fmtInt(total), Object.entries(counts).map(([s, n]) => `${fmtInt(n)} ${words(s)}`).join(" · ") || "none");
    })));
    const uplift = head.summary && head.summary.uplift_model_in_force;
    if (uplift) root.append(notice("info", `Approved uplift model #${uplift.id} steers these recommendations: customers predicted to react badly to contact are held back, and those predicted to respond are put first.`));
    root.append(tabs([{ id: "recs", label: "Recommendations", render: () => recsTab(render) }, { id: "interventions", label: "Actions taken & outcomes", render: () => interventionsTab() }]));
    if (head.summary && head.summary.note) root.append(h("p", { class: "muted small" }, head.summary.note));
  }
  await render();
  return root;
}
function recsTab(refresh) {
  const mayReview = can("retention:write") || can("retention:approve");
  const segment = h("select", { "aria-label": "Segment" }, h("option", { value: "" }, "All segments"), Object.entries(SEGMENT_LABEL).map(([v, l]) => h("option", { value: v }, l)));
  const status = h("select", { "aria-label": "Status" }, h("option", { value: "" }, "All statuses"), ["proposed", "approved", "executed", "blocked", "dismissed"].map((s) => h("option", { value: s }, words(s))));
  const table = pagedTable({ load: (page, size) => api("/retention/recommendations", { query: { page, page_size: size, segment: segment.value, status: status.value } }), caption: "Recommendations", columns: [
    { label: "Customer", value: (r) => h("span", null, r.customer_name || r.customer_external_id, h("span", { class: "sub" }, r.customer_external_id)) },
    { label: "Segment", value: (r) => SEGMENT_LABEL[r.segment] || words(r.segment) },
    { label: "Action", value: (r) => h("span", null, r.rationale.action_name || words(r.action_code), h("span", { class: "sub" }, `${words(r.channel)}${r.rationale.requires_human_review ? " · needs human review" : ""}`)) },
    { label: "Risk", align: "right", value: (r) => fmtProb(r.rationale.probability) }, { label: "MRR", align: "right", value: (r) => fmtMoney(r.rationale.mrr, "USD", 0) },
    { label: "Status", value: (r) => h("span", null, badge(r.status), r.blocked_reason ? h("span", { class: "sub" }, r.blocked_reason) : null) },
    { label: "", value: (r) => h("div", { class: "actions" },
      r.status === "proposed" && (r.rationale.requires_human_review ? can("retention:approve") : mayReview) ? button("Approve", async () => { await api(`/retention/recommendations/${r.id}/review`, { method: "POST", body: { approve: true } }); toast("Recommendation approved", "success"); await refresh(); }, "small primary") : null,
      r.status === "proposed" && r.rationale.requires_human_review && mayReview && !can("retention:approve") ? h("span", { class: "muted small" }, "awaits an approver") : null,
      mayReview && r.status === "proposed" ? button("Dismiss", async () => { await api(`/retention/recommendations/${r.id}/review`, { method: "POST", body: { approve: false } }); await refresh(); }, "small") : null,
      can("retention:write") && r.status === "approved" ? button("Carry out", async () => {
        const connections = ((await safe(api("/crm/connections"))) || { items: [] }).items;
        const result = await formDialog({ title: "Carry out this action?", submitLabel: "Carry out",
          description: "Records the intervention. The platform never contacts customers itself: choose a CRM connection to queue the action for delivery there, or record it for manual follow-up.",
          fields: [{ name: "connection_id", label: "Hand over to", type: "select", value: "", options: [["", "No CRM: record for manual follow-up"], ...connections.map((c) => [String(c.id), `${c.name} (${c.mode === "TEST_ONLY" ? "test only, nothing is sent" : words(c.mode)})`])] }],
          onSubmit: (v) => api(`/retention/recommendations/${r.id}/execute`, { method: "POST", body: { connection_id: v.connection_id ? Number(v.connection_id) : null } }) });
        if (result) { toast(result.crm_delivery_id ? "Intervention recorded and queued for the CRM" : "Intervention recorded for manual follow-up", "success"); await refresh(); }
      }, "small primary") : null,
      mayReview && r.status === "approved" ? button("Withdraw", async () => {
        const ok = await formDialog({ title: "Withdraw this approved action?", description: "The action has not been carried out. Withdrawing dismisses it; the customer can be proposed again by the next scoring run.", submitLabel: "Withdraw", danger: true,
          fields: [{ name: "note", label: "Reason" }], onSubmit: (v) => api(`/retention/recommendations/${r.id}/review`, { method: "POST", body: { approve: false, note: v.note } }) });
        if (ok) await refresh();
      }, "small") : null) },
  ], onRow: recDialog, emptyNode: empty("No recommendations", "Generate recommendations from a scoring batch.") });
  segment.addEventListener("change", () => table.reload()); status.addEventListener("change", () => table.reload());
  return card(null, h("div", null, h("div", { class: "toolbar" }, segment, status), table.el), { flush: true });
}
function recDialog(r) {
  const x = r.rationale;
  openDialog({ title: x.action_name || words(r.action_code), description: `${r.customer_name || r.customer_external_id} · ${SEGMENT_LABEL[r.segment] || words(r.segment)}`, wide: true, body: h("div", { class: "stack" },
    kv([["Churn risk", h("span", null, fmtProb(x.probability), " ", tierBadge(x.risk_tier))], ["MRR", `${fmtMoney(x.mrr, "USD", 2)} (higher than ${fmtPct(x.value_percentile, 0)} of scored customers)`],
      ["Status", h("span", null, badge(r.status), r.blocked_reason ? ` ${r.blocked_reason}` : "")], ["Assigned to", r.assigned_to], ["Offer", x.offer ? JSON.stringify(x.offer) : "none"],
      ["Uplift segment", x.uplift_segment ? words(x.uplift_segment) : "not used (no approved uplift model)"],
      ["Consent", r.eligibility ? `${r.eligibility.consent_required ? "required" : "not required"}; marketing consent ${r.eligibility.consent_marketing ? "given" : "not recorded"}${r.eligibility.in_cooldown ? "; in contact cooldown" : ""}` : null]]),
    x.payment_triggers && x.payment_triggers.length ? h("div", null, h("h3", null, "Payment triggers"), h("ul", null, x.payment_triggers.map((t) => h("li", null, typeof t === "string" ? t : (t.text || JSON.stringify(t)))))) : null,
    h("div", null, h("h3", null, "Why the model scores this customer as it does"), reasonList(x.top_reasons)),
    x.talking_points && x.talking_points.length ? h("div", null, h("h3", null, "Suggested talking points"), h("ul", null, x.talking_points.map((t) => h("li", null, t)))) : null,
    h("p", { class: "muted small" }, x.disclaimer), h("div", { class: "dialog-foot" }, link("Open customer", `#/customers/${r.customer_id}`, "btn"), h("form", { method: "dialog" }, h("button", { class: "btn" }, "Close")))) });
}
function interventionsTab() {
  const table = pagedTable({ load: (page, size) => api("/retention/interventions", { query: { page, page_size: size } }), caption: "Interventions", columns: [
    { label: "Customer", value: (i) => link(i.customer_name || i.customer_external_id || `Customer #${i.customer_id}`, `#/customers/${i.customer_id}`) }, { label: "Action", value: (i) => words(i.action_code) }, { label: "Channel", value: (i) => words(i.channel) },
    { label: "Carried out", value: (i) => fmtDateTime(i.delivered_at || i.created_at) }, { label: "Outcome", value: (i) => (i.outcome ? badge(i.outcome) : h("span", { class: "muted" }, "not recorded")) },
    { label: "", value: (i) => (can("retention:write") ? button("Record outcome", async () => {
      const ok = await formDialog({ title: "Record outcome", submitLabel: "Save", fields: [{ name: "outcome", label: "What happened", type: "select", options: ["retained", "churned", "unknown"], value: i.outcome || "retained" }, { name: "note", label: "Note" }],
        onSubmit: (v) => api(`/retention/interventions/${i.id}/outcome`, { method: "POST", body: v }) });
      if (ok) table.reload(false);
    }, "small") : null) },
  ], emptyNode: empty("No actions carried out yet", "Approve a recommendation and carry it out to record an intervention.") });
  return card(null, table.el, { flush: true, foot: "Outcomes recorded here are observational. Only a randomised experiment can show whether an action caused customers to stay." });
}

// ------------------------------------------------------------------ experiments & uplift
export async function experiments() {
  const root = h("div");
  async function render() {
    const [exps, upl] = await Promise.all([api("/experiments"), api("/uplift/models")]);
    const result = h("div");
    clear(root).append(pageHead("Experiments & uplift", "A risk score says who is likely to leave, not whether contacting them helps. Randomised experiments measure the effect of an action; uplift models then look for the customers who can actually be persuaded.", [
      can("retention:write") ? button("New experiment", async () => {
        const made = await formDialog({ title: "New experiment", description: "A random share of the targeted customers is held out as control. Needs approval before customers are assigned.", submitLabel: "Create draft",
          fields: [{ name: "name", label: "Name", required: true }, { name: "hypothesis", label: "Hypothesis" },
            { name: "treatment_share", label: "Share receiving the action", type: "number", value: 0.5, min: 0.05, max: 0.95, step: 0.05 },
            { name: "baseline_rate", label: "Expected churn rate without action", type: "number", value: 0.05, min: 0.001, max: 0.99, step: 0.001 },
            { name: "min_detectable_effect", label: "Smallest reduction worth detecting (absolute)", type: "number", value: 0.02, min: 0.001, max: 0.5, step: 0.001 },
            { name: "outcome_window_days", label: "Outcome window (days)", type: "number", value: 30, min: 1, max: 365 }],
          onSubmit: (v) => api("/experiments", { method: "POST", body: v }) });
        if (made) { toast("Experiment drafted", "success"); await render(); }
      }, "primary") : null]));
    const calc = h("form", { class: "toolbar" },
      h("label", { class: "small muted" }, "Churn rate without action ", h("input", { type: "number", name: "b", value: "0.05", step: "0.001", min: "0.001", max: "0.99" })),
      h("label", { class: "small muted" }, "Reduction to detect ", h("input", { type: "number", name: "m", value: "0.01", step: "0.001", min: "0.001", max: "0.5" })),
      h("label", { class: "small muted" }, "Share treated ", h("input", { type: "number", name: "t", value: "0.5", step: "0.05", min: "0.05", max: "0.95" })),
      h("button", { class: "btn", type: "submit" }, "Calculate"));
    calc.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        const r = await api("/experiments/sample-size", { method: "POST", body: { baseline_rate: Number(calc.b.value), min_detectable_effect: Number(calc.m.value), treatment_share: Number(calc.t.value) } });
        clear(result).append(h("div", { class: "card-body" }, h("strong", null, `${fmtInt(r.treatment)} treated + ${fmtInt(r.control)} control = ${fmtInt(r.total)} customers`), h("span", { class: "muted" }, ` to detect that reduction with ${fmtPct(r.power ?? 0.8, 0)} power at a ${fmtPct(r.alpha ?? 0.05, 0)} significance level (two-sided).`)));
      } catch (err) { clear(result).append(h("div", { class: "card-body" }, notice("danger", err.message))); }
    });
    root.append(h("div", { class: "stack" },
      card("How many customers does a test need?", h("div", null, calc, result), { flush: true, sub: "Sample size for comparing two churn rates" }),
      card("Experiments", dataTable([
        { label: "Experiment", value: (e) => h("span", null, e.name, e.origin === "aa_backtest" ? h("span", { class: "sub" }, "A/A check: no action was applied, so no difference is expected") : null) },
        { label: "Status", value: (e) => badge(e.status) }, { label: "Treated share", align: "right", value: (e) => fmtPct(e.treatment_share, 0) },
        { label: "Needed per arm", align: "right", value: (e) => fmtInt(e.required_per_arm) }, { label: "Assigned", value: (e) => fmtDateTime(e.assigned_at) },
      ], exps.items, { onRow: (e) => go(`#/experiments/${e.id}`), emptyText: "No experiment yet.", caption: "Experiments" }), { flush: true }),
      card("Uplift models", dataTable([
        { label: "Model", value: (m) => `#${m.id} · experiment #${m.experiment_id}` }, { label: "Status", value: (m) => badge(m.status) },
        { label: "Qini coefficient (90% CI)", value: (m) => (m.validation && isNum(m.validation.qini_coefficient) ? `${fmtNum(m.validation.qini_coefficient, 4)} (${fmtNum(m.validation.qini_ci90[0], 4)} to ${fmtNum(m.validation.qini_ci90[1], 4)})` : "–") },
        { label: "Usable for targeting", value: (m) => (m.status === "approved" ? badge("ok", "yes") : badge("blocked", "no — diagnostic only")) },
      ], upl.items, { onRow: (m) => go(`#/experiments/${m.experiment_id}`), emptyText: "Fit an uplift model from a completed experiment.", caption: "Uplift models" }),
      { flush: true, foot: "An uplift model may steer targeting only if it beats random targeting out of sample (lower bound of the Qini interval above zero) and a second person approves it." })));
  }
  await render();
  return root;
}

export async function experimentDetail(id) {
  const root = h("div");
  async function render() {
    const [e, upl, batches, contracts] = await Promise.all([api(`/experiments/${id}`), api("/uplift/models"), can("predict:read") ? safe(api("/predictions/batches", { query: { page_size: 20 } })) : null, can("features:read") ? safe(api("/features/contracts")) : null]);
    const res = e.results || {}; const models = upl.items.filter((m) => m.experiment_id === e.id);
    const approvedContract = contracts && contracts.items.find((c) => c.status === "approved");
    const post = (path, body, msg) => async () => { await api(`/experiments/${id}/${path}`, { method: "POST", body }); toast(msg, "success"); await render(); };
    clear(root).append(pageHead(e.name, e.hypothesis, [
      can("retention:write") && e.status === "draft" ? button("Submit for approval", post("submit", undefined, "Submitted for approval"), "primary") : null,
      can("retention:approve") && e.status === "pending" ? button("Approve", post("review", { approve: true }, "Experiment approved"), "primary") : null,
      can("retention:approve") && e.status === "pending" ? button("Reject", post("review", { approve: false }, "Experiment rejected")) : null,
      can("retention:write") && e.status === "approved" && batches ? button("Assign customers", async () => {
        const done = await formDialog({ title: "Assign customers", description: "Customers in the chosen tiers of a scoring batch are split at random (by a salted hash of the customer ID, so the split is reproducible).", submitLabel: "Assign",
          fields: [{ name: "batch_id", label: "Scoring batch", type: "select", options: batches.items.filter((b) => b.status === "completed").map((b) => [b.id, `#${b.id} · ${b.as_of_date} · ${b.kind}`]) },
            { name: "high", label: "High-risk tier", type: "checkbox", value: true }, { name: "medium", label: "Medium-risk tier", type: "checkbox", value: true }, { name: "low", label: "Low-risk tier", type: "checkbox", value: false }],
          onSubmit: (v) => api(`/experiments/${id}/assign`, { method: "POST", body: { batch_id: Number(v.batch_id), tiers: ["high", "medium", "low"].filter((t) => v[t]) } }) });
        if (done) { toast("Customers assigned", "success"); await render(); }
      }, "primary") : null,
      can("retention:write") && (e.status === "running" || e.status === "completed") ? button("Analyse outcomes", post("analyse", undefined, "Analysis updated")) : null,
      can("ml:train") && res.analysis && approvedContract ? button("Fit uplift model", async () => {
        const made = await formDialog({ title: "Fit an uplift model", description: "Two models are fitted (treated and control) with cross-fitting; the difference in predicted retention is the estimated effect of the action for each customer.", submitLabel: "Fit",
          fields: [{ name: "delta", label: "Minimum effect to call a customer persuadable", type: "number", value: 0.02, min: 0.001, max: 0.5, step: 0.001 }],
          onSubmit: (v) => api("/uplift/models", { method: "POST", body: { experiment_id: e.id, contract_id: approvedContract.id, delta: v.delta } }) });
        if (made) { toast("Uplift model fitted and validated", "success"); await render(); }
      }) : null,
    ], h("span", null, link("Experiments & uplift", "#/experiments"), ` / #${e.id}`)));
    if (e.origin === "aa_backtest") root.append(notice("info", h("strong", null, "A/A check. "), "This demo experiment split customers at random on a past scoring date and applied no action, so there is no effect to find. Any difference between the arms is chance (about 1 split in 20 looks significant at 5%), and an uplift model should fail validation. It demonstrates the method, not a retention effect."));
    root.append(h("div", { class: "grid cols-2" },
      card("Design", kv([["Status", badge(e.status)], ["Share treated", fmtPct(e.treatment_share, 0)], ["Expected churn without action", fmtPct(e.baseline_rate)], ["Smallest effect to detect", pp(-(e.min_detectable_effect || 0))],
        ["Significance / power", `${fmtPct(e.alpha, 0)} / ${fmtPct(e.power, 0)}`], ["Needed per arm", fmtInt(e.required_per_arm)], ["Outcome window", `${e.outcome_window_days} days`]])),
      res.assignment ? card("Assignment", kv([["Scoring date", res.assignment.as_of_date], ["Tiers included", res.assignment.tiers.join(", ")], ["Treated", fmtInt(res.assignment.treatment)], ["Control", fmtInt(res.assignment.control)],
        ["Split check (sample-ratio mismatch)", h("span", null, badge(res.assignment.srm.status), ` observed ${fmtPct(res.assignment.srm.observed_share)} vs designed ${fmtPct(res.assignment.srm.designed_share)}, p = ${fmtNum(res.assignment.srm.p_value, 3)}`)],
        ["Method", res.assignment.method]]), { sub: res.assignment.treatment + res.assignment.control < 2 * e.required_per_arm ? "Fewer customers than the design calls for: the test is underpowered" : null })
        : card("Assignment", empty("Not assigned yet", "Customers are assigned after the experiment is approved."))));
    if (res.analysis) {
      const a = res.analysis; const cmp = a.comparison;
      root.append(h("div", { class: "stack" }, card("Result", cmp.status === "ok" ? h("div", null,
        h("div", { class: "grid kpis" }, kpi("Churn, treated", fmtPct(cmp.churn_rate_treatment), `${fmtInt(cmp.churned_treatment)} of ${fmtInt(cmp.n_treatment)}`), kpi("Churn, control", fmtPct(cmp.churn_rate_control), `${fmtInt(cmp.churned_control)} of ${fmtInt(cmp.n_control)}`),
          kpi("Difference", pp(cmp.difference), `${fmtPct(cmp.confidence, 0)} CI ${pp(cmp.ci_low)} to ${pp(cmp.ci_high)}`), kpi("p-value", fmtNum(cmp.p_value, 3), cmp.significant ? "statistically significant" : "not statistically significant")),
        notice(cmp.significant ? (e.origin === "aa_backtest" ? "warn" : "ok") : "info", h("strong", null, "Reading: "), cmp.reading, ". ", cmp.method),
        a.resplit && a.resplit.evaluated ? notice(a.resplit.status === "ok" ? "info" : "danger", h("strong", null, "Repeated on fresh random splits: "),
          `${fmtInt(a.resplit.significant)} of ${fmtInt(a.resplit.evaluated)} splits (${fmtPct(a.resplit.rate)}) were significant at ${fmtPct(a.resplit.alpha, 0)}. `,
          a.resplit.status === "ok" ? "That is what chance alone produces: assignment and comparison behave." : "That is well above what chance produces: assignment or outcome measurement is biased.") : null,
        h("ul", { class: "muted small" }, (a.notes || []).map((n) => h("li", null, n))))
        : notice("warn", `Not enough matured outcomes to compare the arms (${words(cmp.status)}).`),
      { sub: `${fmtInt(a.matured)} of ${fmtInt(a.assigned)} assigned customers have a complete ${a.outcome_window_days}-day outcome · churn definition ${a.churn_definition}` })));
    }
    for (const m of models) root.append(h("div", { class: "stack" }, await upliftCard(m, render)));
  }
  await render();
  return root;
}
async function upliftCard(m, refresh) {
  const v = m.validation || {};
  const seg = await safe(api(`/uplift/models/${m.id}/segments`));
  const colors = { persuadable: "green", sure_thing: "grey", lost_cause: "amber", sleeping_dog: "red" };
  const labels = { persuadable: "Persuadable: stays only if contacted", sure_thing: "Sure thing: stays either way", lost_cause: "Lost cause: leaves either way", sleeping_dog: "Sleeping dog: contact makes leaving more likely" };
  const body = h("div", { class: "stack" });
  if (seg && seg.warning) body.append(notice("warn", seg.warning));
  if (m.status === "approved") body.append(notice("ok", "Approved: recommendations hold back customers classed as sleeping dogs and prioritise persuadables."));
  const charts = h("div", { class: "grid cols-2" });
  if (v.qini_curve) charts.append(h("div", null, h("h3", null, "Qini curve (out of sample)"), lineChart({ xLabel: "Share of customers targeted, best predicted uplift first", yLabel: "Extra customers retained", label: "Qini curve",
    series: [{ name: "Uplift model", color: "accent", points: v.qini_curve.map((p) => [p.share, p.incremental]) }, { name: "Random targeting", color: "grey", dashed: true, points: v.qini_curve.map((p) => [p.share, p.random]) }], xFmt: pctTick }),
  h("p", { class: "muted small" }, `Qini coefficient ${fmtNum(v.qini_coefficient, 4)}, 90% bootstrap interval ${fmtNum(v.qini_ci90[0], 4)} to ${fmtNum(v.qini_ci90[1], 4)}. Rule: ${v.rule}.`)));
  if (seg && seg.points) charts.append(h("div", null, h("h3", null, "Predicted retention with and without the action"), scatter({ xLabel: "P(stays) without action", yLabel: "P(stays) with action", fmt: (x) => fmtPct(x, 0), label: "Uplift quadrants",
    points: seg.points.map((p) => ({ x: p.p_control, y: p.p_treated, color: colors[p.segment] })), legendItems: Object.keys(labels).map((k) => ({ name: `${words(k)} (${fmtInt((seg.segments[k] || {}).customers)})`, color: colors[k] })) }),
  h("p", { class: "muted small" }, "Points above the diagonal are predicted to be helped by the action, points below to be harmed.")));
  body.append(charts);
  if (seg) body.append(dataTable([{ label: "Segment", value: (k) => labels[k] }, { label: "Customers", align: "right", value: (k) => fmtInt((seg.segments[k] || {}).customers) }, { label: "Mean predicted effect on retention", align: "right", value: (k) => pp((seg.segments[k] || {}).mean_uplift) }], Object.keys(labels)));
  if (v.buckets) body.append(h("div", null, h("h3", null, "Does predicted uplift match what was observed?"), dataTable([{ label: "Bucket (1 = highest predicted uplift)", value: (b) => b.bucket }, { label: "Customers", align: "right", value: (b) => fmtInt(b.n) },
    { label: "Predicted effect", align: "right", value: (b) => pp(b.predicted_uplift) }, { label: "Observed effect", align: "right", value: (b) => pp(b.observed_uplift) }], v.buckets)));
  return card(`Uplift model #${m.id}`, body, { sub: `${v.method || words(m.method)} · ${fmtInt((m.metrics || {}).treated)} treated, ${fmtInt((m.metrics || {}).control)} control`, actions: [badge(m.status),
    can("ml:approve") && v.passed && m.status !== "approved" ? button("Approve for targeting", async () => { await api(`/uplift/models/${m.id}/review`, { method: "POST", body: { approve: true } }); toast("Uplift model approved", "success"); await refresh(); }, "small primary") : null] });
}

// ------------------------------------------------------------------ CRM
export async function crm() {
  const root = h("div");
  async function render() {
    const [conns, batches] = await Promise.all([api("/crm/connections"), can("predict:read") ? safe(api("/predictions/batches", { query: { page_size: 10 } })) : null]);
    const latest = batches && batches.items.find((b) => b.kind !== "backtest" && b.status === "completed");
    clear(root).append(pageHead("CRM sync", "Pushes risk scores and tasks to the tools customer-facing teams already use (Salesforce, HubSpot, Intercom). Connections start in TEST_ONLY mode: requests are built and recorded but never sent.", [
      can("crm:write") ? button("New connection", async () => {
        const made = await formDialog({ title: "New CRM connection", description: "The access token is encrypted at rest and never shown again.", submitLabel: "Create",
          fields: [{ name: "provider", label: "Provider", type: "select", options: conns.providers, value: conns.providers[0] }, { name: "name", label: "Name", required: true }, { name: "base_url", label: "API base URL", required: true, placeholder: "https://api.hubapi.com" },
            { name: "mode", label: "Mode", type: "select", options: conns.modes, value: "TEST_ONLY", hint: "PRODUCTION must also be enabled by the operator (CHURN_CRM_ALLOW_PRODUCTION)" }, { name: "access_token", label: "Access token", type: "password" }],
          onSubmit: (v) => api("/crm/connections", { method: "POST", body: v }) });
        if (made) { toast("Connection created", "success"); await render(); }
      }, "primary") : null]));
    root.append(card("Connections", dataTable([
      { label: "Connection", value: (c) => h("span", null, c.name, h("span", { class: "sub" }, `${words(c.provider)} · ${c.base_url}`)) }, { label: "Mode", value: (c) => badge(c.mode === "PRODUCTION" ? "ok" : "test_only", c.mode) },
      { label: "Status", value: (c) => h("span", null, badge(c.status), c.last_error ? h("span", { class: "sub" }, c.last_error) : null) }, { label: "Credentials", value: (c) => (c.has_credentials ? "stored (encrypted)" : "none") }, { label: "Last checked", value: (c) => fmtDateTime(c.last_checked_at) },
      { label: "", value: (c) => (can("crm:write") && latest ? button("Sync latest scores", async () => {
        const res = await formDialog({ title: `Sync scores for ${latest.as_of_date}?`, description: c.mode === "TEST_ONLY" ? "TEST_ONLY: each request is built and stored for inspection; nothing is sent." : `Scores will be sent to ${c.base_url}.`, submitLabel: "Sync",
          fields: [{ name: "high", label: "High-risk customers", type: "checkbox", value: true }, { name: "medium", label: "Medium-risk customers", type: "checkbox", value: false }],
          onSubmit: (v) => api(`/crm/connections/${c.id}/sync`, { method: "POST", body: { batch_id: latest.id, tiers: ["high", "medium"].filter((t) => v[t]) } }) });
        if (res) { if (res.job) await trackJob(res.job, "CRM delivery"); toast("Sync queued", "success"); await render(); }
      }, "small") : null) },
    ], conns.items, { emptyText: "No CRM connection yet.", caption: "CRM connections" }), { flush: true }));
    const status = h("select", { "aria-label": "Delivery status" }, h("option", { value: "" }, "All statuses"), ["pending", "sent", "skipped", "failed", "dead"].map((s) => h("option", { value: s }, words(s))));
    const table = pagedTable({ pageSize: 15, load: (page, size) => api("/crm/deliveries", { query: { page, page_size: size, status: status.value } }), caption: "CRM deliveries", columns: [
      { label: "Delivery", value: (d) => `#${d.id}` }, { label: "Kind", value: (d) => words(d.kind) }, { label: "Customer", value: (d) => (d.payload && d.payload.external_id) || `#${d.customer_id}` },
      { label: "Status", value: (d) => h("span", null, badge(d.status), d.last_error ? h("span", { class: "sub" }, d.last_error) : null) }, { label: "Attempts", align: "right", value: (d) => d.attempts }, { label: "Created", value: (d) => fmtDateTime(d.created_at) },
    ], onRow: (d) => openDialog({ title: `Delivery #${d.id}`, description: `Idempotency key ${d.idempotency_key}: the same score is never delivered twice.`, wide: true, body: h("div", { class: "stack" }, h("h3", null, "Payload"), jsonBlock(d.payload), h("h3", null, "Request / response"), jsonBlock(d.response), closeFoot()) }),
    emptyNode: empty("Nothing delivered yet", "Sync scores from a connection above.") });
    status.addEventListener("change", () => table.reload());
    root.append(h("div", { class: "stack" }, card("Delivery log", h("div", null, h("div", { class: "toolbar" }, status), table.el), { flush: true, foot: "Skipped = TEST_ONLY mode. Failed deliveries are retried with back-off; after the last attempt they are marked dead." })));
  }
  await render();
  return root;
}
