// Shared client core: API access, DOM helpers, formatting, dialogs, toasts and job tracking.
// Every value that comes from the server is inserted as text (never as HTML).

export const state = { token: null, me: null, info: null, rotateAt: null };

const KEY = "churn.session";
let memoryToken = null;

function storage() {
  try { const s = window.sessionStorage; s.getItem(KEY); return s; } catch { return null; }
}
export function saveToken(token) {
  state.token = token; memoryToken = token;
  const s = storage();
  if (s) { if (token) s.setItem(KEY, token); else s.removeItem(KEY); }
}
export function loadToken() {
  const s = storage();
  state.token = (s && s.getItem(KEY)) || memoryToken;
  return state.token;
}

export class ApiError extends Error {
  constructor(status, code, message, details, correlationId) {
    super(message); this.status = status; this.code = code; this.details = details; this.correlationId = correlationId;
  }
}

// The session token is replaced on a schedule the server sets (session.rotate_after); a stolen token then stops
// working soon after its owner's next request.
let rotating = null;
function rotateIfDue() {
  if (!state.token || !state.rotateAt || Date.now() < state.rotateAt) return null;
  if (!rotating) {
    rotating = (async () => {
      try {
        const res = await fetch(new URL("api/v1/auth/rotate", document.baseURI), { method: "POST", headers: { Authorization: "Bearer " + state.token, "Content-Type": "application/json" }, body: "{}" });
        if (res.ok) { const data = await res.json(); saveToken(data.token); state.rotateAt = Date.parse(data.rotate_after); }
        else state.rotateAt = Date.now() + 60000;
      } catch { state.rotateAt = Date.now() + 60000; } finally { rotating = null; }
    })();
  }
  return rotating;
}

export async function api(path, opts = {}) {
  const { method = "GET", body, query, form, raw } = opts;
  if (!path.startsWith("/auth/")) await rotateIfDue();
  const url = new URL("api/v1" + path, document.baseURI);
  if (query) for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
  const headers = { Accept: "application/json" };
  if (state.token) headers.Authorization = "Bearer " + state.token;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) { headers["Content-Type"] = "application/json"; payload = JSON.stringify(body); }
  let res;
  try { res = await fetch(url, { method, headers, body: payload }); }
  catch { throw new ApiError(0, "network", "The server could not be reached. Check your connection and try again."); }
  if (res.status === 401 && path !== "/auth/login") { saveToken(null); window.dispatchEvent(new CustomEvent("auth:expired")); }
  if (!res.ok) {
    let err = {};
    try { err = (await res.json()).error || {}; } catch { /* non-JSON error body */ }
    throw new ApiError(res.status, err.code || "error", err.message || `The request failed (${res.status})`, err.details,
      err.correlation_id || res.headers.get("X-Correlation-ID"));
  }
  if (raw) return res;
  return res.status === 204 ? null : res.json();
}

export const can = (permission) => Boolean(state.me && state.me.permissions.includes(permission));

// ---------- DOM ----------
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) for (const [key, value] of Object.entries(attrs)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === "style") throw new Error("inline styles are not allowed (CSP)");
    if (key === "class") el.className = value;
    else if (key === "dataset") Object.assign(el.dataset, value);
    else if (key.startsWith("on") && typeof value === "function") el.addEventListener(key.slice(2), value);
    else if (value === true) el.setAttribute(key, "");
    else el.setAttribute(key, String(value));
  }
  append(el, children);
  return el;
}
export function append(el, children) {
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}
export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

// ---------- formatting ----------
const NA = "–";
export const isNum = (v) => typeof v === "number" && Number.isFinite(v);
export const fmtInt = (v) => (isNum(v) ? Math.round(v).toLocaleString("en-US") : NA);
export const fmtNum = (v, digits = 2) => (isNum(v) ? v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits }) : NA);
export const fmtPct = (v, digits = 1) => (isNum(v) ? (v * 100).toFixed(digits) + "%" : NA);
export function fmtProb(v) { if (!isNum(v)) return NA; const p = v * 100; return (p < 10 ? p.toFixed(2) : p.toFixed(1)) + "%"; }
export function fmtMoney(v, currency = "USD", digits = 0) {
  const n = typeof v === "string" ? Number(v) : v;
  if (!isNum(n)) return NA;
  return n.toLocaleString("en-US", { style: "currency", currency, minimumFractionDigits: digits, maximumFractionDigits: digits });
}
export function fmtDate(v) { return v ? String(v).slice(0, 10) : NA; }
export function fmtDateTime(v) {
  if (!v) return NA;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toISOString().slice(0, 16).replace("T", " ") + " UTC";
}
export function fmtDuration(start, end) {
  if (!start || !end) return NA;
  const sec = (new Date(end) - new Date(start)) / 1000;
  if (!Number.isFinite(sec)) return NA;
  return sec < 1 ? "<1 s" : sec < 90 ? `${sec.toFixed(0)} s` : `${(sec / 60).toFixed(1)} min`;
}
export const words = (v) => (v === null || v === undefined || v === "" ? NA : String(v).replaceAll("_", " "));
export const shortHash = (v) => (v ? String(v).slice(0, 10) : NA);

// ---------- small components ----------
const GOOD = new Set(["succeeded", "completed", "approved", "ok", "production", "pass", "sent", "applied", "available", "ready", "active",
  "valid", "retained", "executed", "passed", "balanced", "enabled", "connected", "reprocessed", "corrected", "resolved"]);
const WARN = new Set(["pending", "queued", "warning", "staging", "proposed", "immature", "skipped", "draft", "test_only", "insufficient_data",
  "open", "acknowledged", "unknown", "sandbox", "not_fitted", "fitted"]);
const BAD = new Set(["failed", "rejected", "alert", "blocked", "dead", "churned", "critical", "fail", "validation_failed", "error", "cancelled",
  "disabled", "locked", "mismatch", "unavailable"]);
export function badge(status, label) {
  const key = String(status ?? "").toLowerCase();
  const cls = GOOD.has(key) ? "good" : WARN.has(key) ? "warn" : BAD.has(key) ? "bad" : key === "running" ? "info" : "";
  return h("span", { class: `badge ${cls}` }, label ?? words(status));
}
export const tierBadge = (tier) => (tier ? h("span", { class: `badge tier-${tier}` }, `${tier} risk`) : h("span", { class: "muted" }, NA));
export function notice(kind, ...children) { return h("div", { class: `notice ${kind}`, role: kind === "danger" ? "alert" : "note" }, ...children); }
export function kpi(label, value, sub, cls = "") {
  return h("div", { class: `kpi ${cls}` }, h("div", { class: "label" }, label), h("div", { class: "value" }, value), sub ? h("div", { class: "sub" }, sub) : null);
}
export function card(title, body, opts = {}) {
  const { sub, actions, foot, flush } = opts;
  return h("section", { class: "card" },
    title ? h("div", { class: "card-head" }, h("h2", null, title, sub ? h("span", { class: "sub" }, sub) : null), actions ? h("div", { class: "actions" }, actions) : null) : null,
    h("div", { class: `card-body${flush ? " flush" : ""}` }, body),
    foot ? h("div", { class: "card-foot" }, foot) : null);
}
export function kv(pairs) {
  return h("dl", { class: "kv" }, pairs.filter(Boolean).map(([k, v]) => [h("dt", null, k), h("dd", null, v === null || v === undefined || v === "" ? NA : v)]));
}
export function empty(title, text, action) {
  return h("div", { class: "empty" }, h("h3", null, title), text ? h("p", null, text) : null, action || null);
}
export function jsonBlock(value) { return h("pre", { class: "json", tabindex: "0" }, JSON.stringify(value, null, 2)); }
export function pageHead(title, description, actions, crumbs) {
  return h("header", { class: "page-head" },
    h("div", { class: "titles" }, crumbs ? h("div", { class: "crumbs" }, crumbs) : null, h("h1", null, title), description ? h("p", null, description) : null),
    actions && actions.length ? h("div", { class: "actions" }, actions) : null);
}
export function button(label, onclick, cls = "", attrs = {}) {
  const el = h("button", { type: "button", class: `btn ${cls}`, ...attrs }, label);
  el.addEventListener("click", async () => {
    if (el.disabled) return;
    el.disabled = true;
    try { await onclick(el); } catch (err) { toastError(err); } finally { el.disabled = false; }
  });
  return el;
}
export function bar(fraction, cls = "", text) {
  const fill = h("div", { class: `bar-fill ${cls}` });
  fill.style.width = `${Math.max(0, Math.min(1, fraction || 0)) * 100}%`;
  return h("div", { class: "bar-cell" }, h("div", { class: "bar-track" }, fill), text !== undefined ? h("span", { class: "num small" }, text) : null);
}

/** columns: [{label, value: row => Node|string, align?: "right", cls?}] */
export function dataTable(columns, rows, opts = {}) {
  if (!rows || !rows.length) return opts.empty || empty("Nothing here yet", opts.emptyText || "");
  const head = h("tr", null, columns.map((c) => h("th", { class: c.align === "right" ? "right" : null, scope: "col" }, c.label)));
  const body = rows.map((row, index) => {
    const tr = h("tr", null, columns.map((c) => h("td", { class: [c.align === "right" ? "right" : "", c.cls || ""].join(" ").trim() || null }, c.value(row, index))));
    if (opts.onRow) {
      tr.classList.add("clickable"); tr.tabIndex = 0;
      tr.addEventListener("click", (event) => { if (!event.target.closest("button, a, input, select")) opts.onRow(row); });
      tr.addEventListener("keydown", (event) => { if (event.key === "Enter" && event.target === tr) opts.onRow(row); });
    }
    return tr;
  });
  return h("div", { class: "table-wrap" }, h("table", { class: "data" }, opts.caption ? h("caption", { class: "sr-only" }, opts.caption) : null, h("thead", null, head), h("tbody", null, body)));
}

/** Server-paged table.  load(page, pageSize) -> {items, total}.  Returns {el, reload}. */
export function pagedTable({ load, columns, onRow, pageSize = 25, emptyNode, caption }) {
  const el = h("div");
  let page = 1;
  async function render() {
    clear(el).append(h("div", { class: "loading" }, "Loading…"));
    try {
      const data = await load(page, pageSize);
      const pages = Math.max(1, Math.ceil((data.total || 0) / pageSize));
      clear(el).append(dataTable(columns, data.items, { onRow, empty: emptyNode, caption }));
      if (data.total > pageSize) {
        el.append(h("div", { class: "pager" },
          h("span", null, `${fmtInt((page - 1) * pageSize + 1)}–${fmtInt(Math.min(page * pageSize, data.total))} of ${fmtInt(data.total)}`),
          h("span", { class: "spacer" }),
          button("Previous", () => { page -= 1; return render(); }, "small", page <= 1 ? { disabled: true } : {}),
          h("span", null, `Page ${page} of ${pages}`),
          button("Next", () => { page += 1; return render(); }, "small", page >= pages ? { disabled: true } : {})));
      }
    } catch (err) { clear(el).append(errorNotice(err)); }
  }
  render();
  return { el, reload: (resetPage = true) => { if (resetPage) page = 1; return render(); } };
}

export function tabs(defs, initial) {
  const list = h("div", { class: "tabs", role: "tablist" });
  const panel = h("div", { role: "tabpanel" });
  const buttons = new Map();
  async function select(id) {
    for (const [key, btn] of buttons) btn.setAttribute("aria-selected", String(key === id));
    clear(panel).append(h("div", { class: "loading" }, "Loading…"));
    try { const node = await defs.find((d) => d.id === id).render(); clear(panel).append(node); }
    catch (err) { clear(panel).append(errorNotice(err)); }
  }
  for (const def of defs) {
    const btn = h("button", { type: "button", role: "tab", "aria-selected": "false", onclick: () => select(def.id) }, def.label);
    buttons.set(def.id, btn); list.append(btn);
  }
  select(initial && buttons.has(initial) ? initial : defs[0].id);
  return h("div", null, list, panel);
}

export function errorNotice(err) {
  const forbidden = err instanceof ApiError && err.status === 403;
  return notice(forbidden ? "warn" : "danger", h("strong", null, forbidden ? "Not permitted. " : "Could not load this. "), err.message || String(err),
    err.correlationId ? h("span", { class: "muted small" }, ` (reference ${err.correlationId})`) : null);
}

// ---------- toasts ----------
function toastHost() {
  let host = document.querySelector(".toasts");
  if (!host) { host = h("div", { class: "toasts", role: "status", "aria-live": "polite" }); document.body.append(host); }
  return host;
}
export function toast(message, kind = "info", ref) {
  const el = h("div", { class: `toast ${kind}` }, message, ref ? h("span", { class: "ref" }, `reference ${ref}`) : null);
  toastHost().append(el);
  setTimeout(() => el.remove(), kind === "error" ? 9000 : 4500);
  return el;
}
export function toastError(err) {
  if (err && err.silent) return;
  if (err instanceof ApiError && err.status === 401) return;
  const detail = err instanceof ApiError && Array.isArray(err.details) && err.details.length
    ? " — " + err.details.map((d) => `${String(d.field || "").replace(/^body\./, "")}: ${d.message}`).join("; ") : "";
  toast((err && err.message ? err.message : String(err)) + detail, "error", err && err.correlationId);
}

// ---------- dialogs ----------
export function openDialog({ title, description, body, wide }) {
  const dialog = h("dialog", { class: wide ? "wide" : null, "aria-labelledby": "dialog-title" },
    h("div", { class: "dialog-head" }, h("h2", { id: "dialog-title" }, title), description ? h("p", null, description) : null),
    h("div", { class: "dialog-body" }, body));
  document.body.append(dialog);
  dialog.addEventListener("close", () => dialog.remove());
  dialog.showModal();
  return dialog;
}

/** fields: [{name, label, type, value, options, hint, required, min, max, step, placeholder}] ; onSubmit(values) may throw ApiError. */
export function formDialog({ title, description, fields = [], submitLabel = "Save", danger = false, onSubmit, wide }) {
  return new Promise((resolve) => {
    const inputs = {};
    const error = h("p", { class: "form-error hidden", role: "alert" });
    const controls = fields.map((f) => {
      let input;
      const common = { name: f.name, id: `f-${f.name}`, required: f.required || null };
      if (f.type === "select") {
        input = h("select", common, f.options.map((o) => {
          const [value, label] = Array.isArray(o) ? o : [o, words(o)];
          return h("option", { value, selected: String(value) === String(f.value ?? "") || null }, label);
        }));
      } else if (f.type === "textarea" || f.type === "json") {
        input = h("textarea", { ...common, spellcheck: "false", placeholder: f.placeholder }, f.type === "json" ? JSON.stringify(f.value ?? {}, null, 2) : (f.value ?? ""));
      } else if (f.type === "checkbox") {
        input = h("input", { ...common, type: "checkbox", checked: f.value ? true : null, required: null });
        inputs[f.name] = input;
        return h("label", { class: "checkbox", for: common.id }, input, h("span", null, f.label, f.hint ? h("span", { class: "muted" }, ` — ${f.hint}`) : null));
      } else {
        input = h("input", { ...common, type: f.type || "text", value: f.value ?? null, min: f.min, max: f.max, step: f.step, placeholder: f.placeholder,
          autocomplete: f.type === "password" ? "new-password" : "off" });
      }
      inputs[f.name] = input;
      return h("label", { class: "field", for: common.id }, f.label, input, f.hint ? h("span", { class: "hint" }, f.hint) : null);
    });
    const submit = h("button", { type: "submit", class: `btn ${danger ? "danger" : "primary"}` }, submitLabel);
    const cancel = h("button", { type: "button", class: "btn" }, "Cancel");
    const form = h("form", null, error, controls, h("div", { class: "dialog-foot" }, cancel, submit));
    const dialog = openDialog({ title, description, body: form, wide });
    let settled = false;
    const finish = (value) => { if (!settled) { settled = true; resolve(value); } if (dialog.open) dialog.close(); };
    cancel.addEventListener("click", () => finish(null));
    dialog.addEventListener("close", () => finish(null));
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const values = {};
      try {
        for (const f of fields) {
          const input = inputs[f.name];
          if (f.type === "checkbox") values[f.name] = input.checked;
          else if (f.type === "number") values[f.name] = input.value === "" ? null : Number(input.value);
          else if (f.type === "json") values[f.name] = JSON.parse(input.value || "{}");
          else values[f.name] = input.value === "" ? null : input.value;
        }
      } catch { error.textContent = "The JSON is not valid. Check brackets, quotes and commas."; error.classList.remove("hidden"); return; }
      submit.disabled = true;
      try { const result = await onSubmit(values); settled = true; resolve(result ?? true); dialog.close(); }
      catch (err) {
        const detail = Array.isArray(err.details) && err.details.length ? " " + err.details.map((d) => `${String(d.field || "").replace(/^body\./, "")}: ${d.message}`).join("; ") : "";
        error.textContent = (err.message || String(err)) + detail; error.classList.remove("hidden");
      } finally { submit.disabled = false; }
    });
    const first = form.querySelector("input, select, textarea");
    if (first) first.focus(); else submit.focus();
  });
}
export const confirmDialog = (title, description, submitLabel, onSubmit, opts = {}) =>
  formDialog({ title, description, submitLabel, onSubmit, danger: opts.danger, fields: opts.fields || [] });

// ---------- background jobs ----------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export function jobError(job) {
  const text = String(job.error || "").trim().split("\n").pop() || "no error message";
  return text.replace(/^[\w.]+(Error|Exception):\s*/, "").slice(0, 300);
}
/** Follow a job to completion.  Resolves with the job; throws (already reported) when it fails. */
export async function trackJob(job, label) {
  if (!job) return null;
  if (!can("jobs:read")) { toast(`${label}: started in the background`); return null; }
  const fill = h("div");
  const text = h("span", null, `${label}: queued…`);
  const el = h("div", { class: "toast" }, text, h("div", { class: "progress" }, fill));
  toastHost().append(el);
  const started = Date.now();
  try {
    for (;;) {
      const current = await api(`/jobs/${job.id}`);
      fill.style.width = `${Math.round((current.progress || 0) * 100)}%`;
      if (current.status === "succeeded") { toast(`${label}: done`, "success"); return current; }
      if (current.status === "failed" || current.status === "cancelled") {
        const err = new Error(`${label} ${current.status}: ${jobError(current)}`); err.job = current; throw err;
      }
      const waited = (Date.now() - started) / 1000;
      text.textContent = current.status === "queued"
        ? (waited > 15 ? `${label}: waiting for a background worker… (is the worker running?)` : `${label}: queued…`)
        : `${label}: ${current.progress_message || "running"}…`;
      if (waited > 900) { toast(`${label} is still running. Follow it under Jobs & pipeline.`); return null; }
      await sleep(900);
    }
  } finally { el.remove(); }
}
/** POST that starts a job, follow it, then call `after`. */
export async function startJob(label, path, body, after) {
  const res = await api(path, { method: "POST", body: body ?? {} });
  await trackJob(res.job, label);
  if (after) await after(res);
  return res;
}
export function go(hash) { window.location.hash = hash; }
export function link(label, hash, cls) { return h("a", { href: hash, class: cls || null }, label); }
