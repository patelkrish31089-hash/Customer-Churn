// Screens: model training, run detail, model registry, predictions.
import { api, can, h, card, kpi, kv, notice, badge, tierBadge, pageHead, button, dataTable, pagedTable, tabs, empty, jsonBlock, bar, link, go, words,
  fmtInt, fmtNum, fmtPct, fmtProb, fmtMoney, fmtDate, fmtDateTime, shortHash, formDialog, openDialog, startJob, trackJob, toast, clear, isNum, state } from "./core.js";
import { lineChart, barChart, waterfall, pctTick } from "./charts.js";
import { safe } from "./views_data.js";

const ALGO = { logistic_regression: "Logistic regression", random_forest: "Random forest", xgboost: "XGBoost", lightgbm: "LightGBM" };
const algo = (a) => ALGO[a] || words(a);
const closeFoot = () => h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"));
const f3 = (v) => fmtNum(v, 3);

// ------------------------------------------------------------------ training
export async function models() {
  const root = h("div");
  async function render() {
    const [datasets, runs, algorithms, contracts] = await Promise.all([api("/ml/datasets"), api("/ml/runs"), api("/ml/algorithms"), can("features:read") ? safe(api("/features/contracts")) : null]);
    const ready = datasets.items.filter((d) => d.status === "ready");
    const approvedContracts = contracts ? contracts.items.filter((c) => c.status === "approved") : [];
    clear(root).append(pageHead("Model training", "Build a time-ordered dataset, train the candidate algorithms and compare them on the validation period. The test period stays sealed until one final evaluation before approval.", [
      can("ml:train") && approvedContracts.length ? button("Build dataset", async () => {
        const res = await formDialog({ title: "Build training dataset", description: "Joins point-in-time features with matured labels and splits by date: oldest dates train, then validation, the most recent dates are the sealed test set.", submitLabel: "Build",
          fields: [{ name: "name", label: "Name", value: "churn-30d", required: true },
            { name: "contract_id", label: "Feature contract", type: "select", options: approvedContracts.map((c) => [c.id, `${c.name} v${c.version}`]), value: approvedContracts[0].id },
            { name: "valid_dates", label: "Validation as-of dates", type: "number", value: 2, min: 1, max: 12 }, { name: "test_dates", label: "Test as-of dates", type: "number", value: 2, min: 1, max: 12 },
            { name: "embargo_days", label: "Extra gap between splits (days)", type: "number", value: 0, min: 0, max: 365 },
            { name: "target", label: "Predict", type: "select", options: [["all", "Any churn (voluntary + involuntary)"], ["voluntary", "Voluntary churn only"], ["involuntary", "Involuntary churn only"]], value: "all" }],
          onSubmit: (v) => api("/ml/datasets", { method: "POST", body: { ...v, contract_id: Number(v.contract_id) } }) });
        if (res && res.job) { await trackJob(res.job, "Dataset build"); await render(); }
      }) : null,
      can("ml:train") && ready.length ? button("Train models", async () => {
        const names = Object.keys(algorithms.algorithms).filter((a) => algorithms.algorithms[a].available);
        const res = await formDialog({ title: "Train models", description: "Each algorithm is tuned with time-ordered cross-validation on the training period, calibrated, and scored on the validation period.", submitLabel: "Start training",
          fields: [{ name: "dataset_id", label: "Dataset", type: "select", options: ready.map((d) => [d.id, `${d.name} v${d.version}`]), value: ready[0].id },
            ...names.map((a) => ({ name: `algo_${a}`, label: algo(a), type: "checkbox", value: true })),
            { name: "imbalance", label: "Class imbalance handling", type: "select", options: algorithms.imbalance_strategies, value: "auto", hint: "auto = class weights (scale_pos_weight for boosted trees); SMOTE is applied inside each training fold only" },
            { name: "n_iter", label: "Hyper-parameter candidates per algorithm", type: "number", value: 6, min: 1, max: 60 }, { name: "cv_folds", label: "Cross-validation folds", type: "number", value: 3, min: 2, max: 6 },
            { name: "seed", label: "Random seed", type: "number", value: 42 }],
          onSubmit: (v) => api("/ml/training", { method: "POST", body: { dataset_id: Number(v.dataset_id), algorithms: names.filter((a) => v[`algo_${a}`]), imbalance: v.imbalance, n_iter: v.n_iter, cv_folds: v.cv_folds, seed: v.seed } }) });
        if (res && res.job) { await trackJob(res.job, "Model training"); await render(); }
      }, "primary") : null]));
    const unavailable = Object.entries(algorithms.algorithms).filter(([, a]) => !a.available);
    if (unavailable.length) root.append(notice("warn", h("strong", null, "Some algorithms are not installed: "), unavailable.map(([name, a]) => `${algo(name)} (${a.reason})`).join("; ")));
    root.append(h("div", { class: "stack" },
      card("Datasets", dataTable([
        { label: "Dataset", value: (d) => `${d.name} v${d.version}` }, { label: "Status", value: (d) => badge(d.status) },
        { label: "Train", align: "right", value: (d) => splitCell(d, "train") }, { label: "Validation", align: "right", value: (d) => splitCell(d, "valid") }, { label: "Test (sealed)", align: "right", value: (d) => splitCell(d, "test") },
        { label: "Columns", align: "right", value: (d) => fmtInt(d.encoded_columns) },
        { label: "Leakage checks", value: (d) => (d.leakage_report ? badge(d.leakage_report.passed ? "passed" : "failed", d.leakage_report.passed ? `${d.leakage_report.checks.length} passed` : "failed") : "–") },
        { label: "Fingerprint", value: (d) => h("code", null, shortHash(d.fingerprint)) },
      ], datasets.items, { onRow: datasetDialog, emptyText: approvedContracts.length ? "Build a dataset to start modelling." : "An approved feature contract and matured labels are needed first.", caption: "Datasets" }),
      { flush: true, sub: "Rows are customer × as-of date. Positives are customers who churned within the window." }),
      card("Training runs", dataTable([
        { label: "Algorithm", value: (r) => h("span", null, algo(r.algorithm), r.is_baseline ? h("span", { class: "sub" }, "baseline") : null) },
        { label: "Imbalance", value: (r) => words(r.imbalance_strategy) }, { label: "Status", value: (r) => badge(r.status) },
        { label: "Validation PR-AUC", value: (r) => (isNum(r.valid_pr_auc) ? bar(r.valid_pr_auc, "", f3(r.valid_pr_auc)) : "–") },
        { label: "Validation ROC-AUC", align: "right", value: (r) => f3(r.valid_roc_auc) },
        { label: "Test PR-AUC", align: "right", value: (r) => (isNum(r.test_pr_auc) ? f3(r.test_pr_auc) : h("span", { class: "muted" }, "sealed")) },
        { label: "Trained", value: (r) => fmtDateTime(r.created_at) },
      ], runs.items, { onRow: (r) => go(`#/models/run/${r.id}`), emptyText: "No model has been trained yet.", caption: "Training runs" }),
      { flush: true, sub: `Ranked by ${runs.ranking || "validation PR-AUC"}`, foot: "PR-AUC (average precision) is the headline metric because churners are rare: it measures how well the model ranks them, which accuracy and ROC-AUC can overstate." })));
  }
  await render();
  return root;
}
function splitCell(d, split) {
  const b = d.class_balance && d.class_balance[split];
  return b ? h("span", null, fmtInt(b.rows), h("span", { class: "sub" }, `${fmtInt(b.positives)} churned (${fmtPct(b.positive_rate)})`)) : "–";
}
function datasetDialog(d) {
  const balance = d.class_balance || {};
  openDialog({ title: `${d.name} v${d.version}`, description: `Fingerprint ${d.fingerprint || "–"}`, wide: true, body: h("div", { class: "stack" },
    d.error ? notice("danger", d.error) : null,
    dataTable([{ label: "Split", value: (s) => words(s) }, { label: "As-of dates", value: (s) => { const dates = (balance[s] || {}).as_of_dates || []; return dates.length ? `${dates[0]} → ${dates[dates.length - 1]} (${dates.length})` : "–"; } },
      { label: "Rows", align: "right", value: (s) => fmtInt((balance[s] || {}).rows) }, { label: "Churned", align: "right", value: (s) => fmtInt((balance[s] || {}).positives) },
      { label: "Voluntary", align: "right", value: (s) => fmtInt(((balance[s] || {}).by_churn_type || {}).voluntary || 0) }, { label: "Involuntary", align: "right", value: (s) => fmtInt(((balance[s] || {}).by_churn_type || {}).involuntary || 0) }], ["train", "valid", "test"]),
    h("h3", null, "Leakage checks"),
    dataTable([{ label: "Check", value: (c) => words(c.check) }, { label: "Result", value: (c) => badge(c.passed ? "passed" : "failed") }, { label: "Evidence", value: (c) => h("code", null, JSON.stringify(c.detail).slice(0, 160)) }], (d.leakage_report || {}).checks || []),
    d.leakage_report && d.leakage_report.information ? h("p", { class: "muted small" }, `${fmtInt(d.leakage_report.information.customers_in_both_train_and_test)} customers appear in both train and test: ${d.leakage_report.information.note}`) : null,
    closeFoot()) });
}

// ------------------------------------------------------------------ run detail
export async function runDetail(id) {
  const root = h("div");
  async function render() {
    const run = await api(`/ml/runs/${id}`);
    const evals = Object.fromEntries((run.evaluations || []).map((e) => [e.split, e]));
    clear(root).append(pageHead(`${algo(run.algorithm)} · run #${run.id}`, `Imbalance handling: ${words(run.imbalance_strategy)}. Hyper-parameters: ${JSON.stringify(run.params)}. Seed ${run.seed}.`, [
      can("ml:train") && run.status === "completed" ? button("Evaluate on validation", async () => { await api(`/ml/runs/${id}/evaluate`, { method: "POST", body: { split: "valid" } }); toast("Validation evaluation stored", "success"); await render(); }) : null,
      can("ml:train") && run.status === "completed" ? button("Explain", async () => { await api(`/ml/runs/${id}/explain`, { method: "POST" }); toast("Explanation computed", "success"); await render(); }) : null,
      can("ml:train") && run.status === "completed" ? button("Register as version", async () => {
        const made = await formDialog({ title: "Register model version", description: "Creates a candidate in the registry. It still needs the final test evaluation and an approver before it can serve.", submitLabel: "Register",
          fields: [{ name: "name", label: "Model name", value: "churn-model", required: true }], onSubmit: (v) => api("/ml/registry", { method: "POST", body: { run_id: Number(id), name: v.name } }) });
        if (made) { toast("Version registered", "success"); go("#/registry"); }
      }, "primary") : null], h("span", null, link("Model training", "#/models"), " / run")));
    if (run.status !== "completed") { root.append(notice(run.status === "failed" ? "danger" : "info", `Run is ${run.status}. ${run.error || ""}`)); return; }
    const vm = run.valid_metrics || {}; const tm = run.test_metrics;
    root.append(h("div", { class: "grid kpis" },
      kpi("Validation PR-AUC", f3(vm.pr_auc), vm.pr_auc_ci95 ? `95% CI ${f3(vm.pr_auc_ci95[0])}–${f3(vm.pr_auc_ci95[1])} · ${fmtNum(vm.pr_auc_lift_over_baseline, 1)}× the no-skill ${f3(vm.pr_auc_baseline)}` : null),
      kpi("Validation ROC-AUC", f3(vm.roc_auc), `${fmtInt(vm.positives)} churners in ${fmtInt(vm.n)} rows`),
      kpi("Calibration error", f3(vm.ece), `Brier ${f3(vm.brier)} · ${run.calibration ? words(run.calibration.method) : "uncalibrated"}`),
      kpi("Cross-validation PR-AUC", f3((run.cv_metrics || {}).pr_auc_mean), `± ${f3((run.cv_metrics || {}).pr_auc_std)} over ${((run.cv_metrics || {}).folds || []).length} time-ordered folds`),
      tm ? kpi("Test PR-AUC (final)", f3(tm.pr_auc), `95% CI ${f3(tm.pr_auc_ci95[0])}–${f3(tm.pr_auc_ci95[1])} · ${fmtInt(tm.positives)} churners · evaluated once`) : kpi("Test PR-AUC", "sealed", "evaluated once, from the registry, before approval")));
    if (vm.positives < 100) root.append(notice("warn", h("strong", null, "Small sample. "), `Validation metrics rest on ${fmtInt(vm.positives)} churners; the confidence interval above shows how much they could move.`));
    const splits = ["valid", "test"].filter((s) => evals[s]);
    const defs = [];
    for (const s of splits) defs.push({ id: `curves-${s}`, label: s === "valid" ? "Ranking quality (validation)" : "Ranking quality (test)", render: () => curvesTab(evals[s]) });
    if (evals.valid) defs.push({ id: "threshold", label: "Threshold & cost", render: () => thresholdTab(evals.valid) });
    if (evals.valid) defs.push({ id: "subgroups", label: "Subgroups", render: () => subgroupsTab(evals.valid) });
    defs.push({ id: "explain", label: "What drives the score", render: () => explainTab(run.global_explanation) });
    defs.push({ id: "search", label: "Tuning", render: () => searchTab(run) });
    root.append(tabs(defs));
  }
  await render();
  return root;
}
function curvesTab(ev) {
  const c = ev.curves; const m = ev.metrics;
  return h("div", { class: "grid cols-2" },
    card("Precision–recall curve", lineChart({ xLabel: "Recall (share of churners found)", yLabel: "Precision", xDomain: [0, 1], yDomain: [0, 1], label: "Precision-recall curve",
      series: [{ name: `Model (PR-AUC ${f3(m.pr_auc)})`, color: "accent", points: c.pr.recall.map((r, i) => [r, c.pr.precision[i]]) }, { name: `No skill (${f3(m.base_rate)})`, color: "grey", dashed: true, points: [[0, m.base_rate], [1, m.base_rate]] }] }),
    { sub: "Of the customers flagged, how many really churn, at each level of coverage" }),
    card("ROC curve", lineChart({ xLabel: "False-positive rate", yLabel: "True-positive rate", xDomain: [0, 1], yDomain: [0, 1], label: "ROC curve",
      series: [{ name: `Model (ROC-AUC ${f3(m.roc_auc)})`, color: "accent", points: c.roc.fpr.map((x, i) => [x, c.roc.tpr[i]]) }, { name: "No skill", color: "grey", dashed: true, points: [[0, 0], [1, 1]] }] }),
    { sub: "Shown for reference; with rare churners PR-AUC is the stricter measure" }),
    card("Calibration", lineChart({ xLabel: "Predicted probability", yLabel: "Observed churn rate", label: "Calibration curve",
      series: [{ name: "Model", color: "accent", dots: true, points: c.calibration.map((b) => [b.mean_predicted, b.observed_rate]) }, { name: "Perfect", color: "grey", dashed: true, points: [[0, 0], [Math.max(...c.calibration.map((b) => b.mean_predicted)), Math.max(...c.calibration.map((b) => b.mean_predicted))]] }],
      xFmt: pctTick, yFmt: pctTick }), { sub: `Do predicted probabilities match reality? Expected calibration error ${f3(m.ece)}` }),
    card("Lift by risk decile", h("div", null, barChart({ labels: c.deciles.map((d) => `D${d.decile}`), series: [{ name: "Churn rate", color: "red", values: c.deciles.map((d) => d.churn_rate) }], yFmt: pctTick, xLabel: "Risk decile (D1 = highest scores)", label: "Churn rate by risk decile" }),
      h("p", { class: "muted small" }, `The top decile contains ${fmtPct(c.deciles[0].cumulative_capture)} of all churners (${fmtNum(c.deciles[0].lift, 1)}× the average rate).`))));
}
function thresholdTab(ev) {
  const t = ev.threshold_analysis; const cur = t.currency || "USD";
  const rows = t.table.filter((_, i) => i % Math.ceil(t.table.length / 60) === 0);
  const sample = [0.9, 0.5, 0.3, 0.2, 0.1, 0.05].map((target) => t.table.reduce((best, r) => (Math.abs(r.threshold - target) < Math.abs(best.threshold - target) ? r : best), t.table[0]));
  const picks = [...new Map([...sample, t.optimal].map((r) => [r.threshold, r])).values()].sort((a, b) => b.threshold - a.threshold);
  return h("div", { class: "stack" },
    t.is_example ? notice("warn", h("strong", null, "Illustrative figures. "), t.disclaimer) : notice("info", t.disclaimer || "Expected values depend on the approved cost assumptions."),
    h("div", { class: "grid cols-2" },
      card("Assumptions", kv([["Cost of one intervention", fmtMoney(t.assumptions.intervention_cost, cur)], ["Value of a retained customer", t.assumptions.clv_mode === "fixed" ? fmtMoney(t.assumptions.clv, cur) : `${t.assumptions.clv_months} months of MRR`],
        ["Assumed save rate", fmtPct(Number(t.assumptions.save_rate), 0)], ["Contribution margin", fmtPct(Number(t.assumptions.contribution_margin), 0)], ["Capacity per scoring date", t.capacity ? fmtInt(t.capacity) : "unlimited"],
        ["Cost if nothing is done", fmtMoney(t.do_nothing_cost, cur)], ["Source", t.assumptions.evidence]]), { sub: t.cost_policy ? `Cost matrix ${t.cost_policy.name} v${t.cost_policy.version}` : null }),
      card("Total cost by threshold", lineChart({ xLabel: "Decision threshold (flag customers scoring above)", yLabel: `Total cost (${cur})`, label: "Total expected cost by threshold",
        series: [{ name: "Missed churners + interventions", color: "accent", points: rows.map((r) => [r.threshold, Number(r.total_cost)]) }], xFmt: pctTick, yFmt: (v) => (Math.abs(v) >= 1000 ? `${Number((v / 1000).toPrecision(3))}k` : String(v)) }),
      { sub: `Lowest at ${fmtProb(t.optimal.threshold)} under these assumptions` })),
    card("What each threshold means", dataTable([
      { label: "Threshold", value: (r) => h("span", null, fmtProb(r.threshold), r.threshold === t.optimal.threshold ? h("span", { class: "badge good" }, "lowest cost") : null) },
      { label: "Customers flagged", align: "right", value: (r) => fmtInt(r.flagged) }, { label: "Churners caught", align: "right", value: (r) => fmtInt(r.tp) }, { label: "False alarms", align: "right", value: (r) => fmtInt(r.fp) },
      { label: "Churners missed", align: "right", value: (r) => fmtInt(r.fn) }, { label: "Precision", align: "right", value: (r) => fmtPct(r.precision) }, { label: "Recall", align: "right", value: (r) => fmtPct(r.recall) },
      { label: "Total cost", align: "right", value: (r) => fmtMoney(r.total_cost, cur) }, { label: "Saving vs. doing nothing", align: "right", value: (r) => fmtMoney(r.net_benefit_vs_no_action, cur) },
    ], picks, { caption: "Threshold scenarios" }), { flush: true, sub: `Chosen on the ${t.threshold_selected_on}; counts are for that period`,
      foot: "A false alarm costs one intervention; a missed churner costs the customer's value. When the value is far larger than the intervention cost, the cheapest policy is to contact almost everyone the model is unsure about." }));
}
function subgroupsTab(ev) {
  return h("div", { class: "grid cols-2" }, Object.entries(ev.subgroups).map(([name, rows]) => card(`By ${words(name)}`, dataTable([
    { label: "Segment", value: (r) => words(r.segment) }, { label: "Rows", align: "right", value: (r) => fmtInt(r.n) }, { label: "Churners", align: "right", value: (r) => fmtInt(r.churners) },
    { label: "Observed rate", align: "right", value: (r) => fmtPct(r.base_rate) }, { label: "Mean predicted", align: "right", value: (r) => fmtPct(r.mean_predicted) },
    { label: "Precision", align: "right", value: (r) => fmtPct(r.precision) }, { label: "Recall", align: "right", value: (r) => fmtPct(r.recall) }], rows), { flush: true, sub: "Checks that the model behaves consistently across segments" })));
}
function explainTab(ex) {
  if (!ex) return card(null, empty("No explanation yet", "Use “Explain” to compute SHAP values for this run."));
  if (ex.status !== "available") return notice("warn", h("strong", null, "Explanation unavailable. "), ex.reason || "");
  const feats = ex.contributions.features.slice().sort((a, b) => b.mean_abs_shap - a.mean_abs_shap).slice(0, 20);
  const groups = Object.entries(ex.contributions.groups).sort((a, b) => b[1] - a[1]); const total = groups.reduce((sum, g) => sum + g[1], 0) || 1;
  return h("div", { class: "stack" }, notice("info", ex.contributions.disclaimer),
    h("div", { class: "split" },
      card("Most influential features", dataTable([{ label: "Feature", value: (f) => h("span", null, f.label, h("span", { class: "sub" }, words(f.group))) },
        { label: "Average impact on the score (mean |SHAP|)", value: (f) => bar(f.mean_abs_shap / feats[0].mean_abs_shap, "", fmtNum(f.mean_abs_shap, 3)) }, { label: "Share", align: "right", value: (f) => fmtPct(f.share) }], feats, { caption: "Global feature importance" }),
      { flush: true, sub: `${ex.method} · ${fmtInt(ex.contributions.sample_rows)} rows from the ${ex.contributions.sample_source}` }),
      card("By data domain", dataTable([{ label: "Domain", value: (g) => words(g[0]) }, { label: "Share of total impact", value: (g) => bar(g[1] / groups[0][1], "", fmtPct(g[1] / total, 0)) }], groups), { flush: true })));
}
function searchTab(run) {
  const s = run.search || {};
  return h("div", { class: "stack" },
    card("Candidates tried", dataTable([{ label: "Hyper-parameters", value: (c) => h("code", null, JSON.stringify(c.params)) }, { label: "CV PR-AUC", align: "right", value: (c) => f3(c.cv_pr_auc_mean) },
      { label: "Std", align: "right", value: (c) => f3(c.cv_pr_auc_std) }, { label: "Per fold", value: (c) => (c.folds || []).map(f3).join(" · ") }], (s.candidates || []).slice().sort((a, b) => b.cv_pr_auc_mean - a.cv_pr_auc_mean)), { flush: true, sub: s.selection_metric }),
    card("Time-ordered folds", dataTable([{ label: "Fold", value: (_, i) => `#${i + 1}` }, { label: "Fitted on", value: (f) => `${f.fit_dates[0]} → ${f.fit_dates[f.fit_dates.length - 1]}` }, { label: "Validated on", value: (f) => `${f.validate_dates[0]} → ${f.validate_dates[f.validate_dates.length - 1]}` }], s.folds || []), { flush: true, sub: "Each fold validates on dates after the ones it was fitted on" }),
    card("Reproducibility", kv([["Artifact SHA-256", h("code", null, run.artifact_sha256)], ["Seed", run.seed], ["Training time", `${fmtNum(run.duration_seconds, 1)} s`], ["Calibration", run.calibration ? `${words(run.calibration.method)}, fitted on ${run.calibration.fitted_on}` : "none"], ["MLflow run", run.mlflow_run_id || "not mirrored"]])));
}

// ------------------------------------------------------------------ registry
export async function registry() {
  const root = h("div");
  async function render() {
    const [data, gateInfo] = await Promise.all([api("/ml/registry"), api("/ml/registry/gates")]);
    clear(root).append(pageHead("Model registry", "A version moves from candidate to validated (it passes the promotion gates), is approved by a second person, and only then can be promoted to production and produce scores."));
    const set = Object.entries(gateInfo.gates).filter(([, v]) => v !== null && v !== false);
    root.append(card("Promotion gates", kv(set.map(([k, v]) => [words(k), v === true ? "required" : String(v)])), { sub: gateInfo.source,
      actions: [link("Change under Policies", "#/policies", "btn small")] }));
    if (state.info && state.info.integrations && !state.info.integrations.mlflow_configured) root.append(h("p", { class: "muted small" }, "MLflow mirroring is off (CHURN_MLFLOW_TRACKING_URI is not set); this registry is the source of truth either way."));
    root.append(card("Versions", dataTable([
      { label: "Version", value: (v) => h("span", null, `${v.name} v${v.version}`, h("span", { class: "sub" }, algo(v.algorithm))) },
      { label: "Lifecycle", value: (v) => badge({ candidate: "draft", validated: "pending", approved: "approved", staging: "staging", production: "production", archived: "skipped", rejected: "rejected" }[v.lifecycle_state], v.lifecycle_state) },
      { label: "Approval", value: (v) => badge(v.approval_status) },
      { label: "Validation PR-AUC", align: "right", value: (v) => f3(v.valid_pr_auc) }, { label: "Test PR-AUC", align: "right", value: (v) => (isNum(v.test_pr_auc) ? f3(v.test_pr_auc) : h("span", { class: "muted" }, "sealed")) },
      { label: "Threshold", align: "right", value: (v) => fmtProb(v.threshold) }, { label: "MLflow", value: (v) => (v.mlflow_model_version ? `v${v.mlflow_model_version}` : "–") },
      { label: "", value: (v) => h("div", { class: "actions" },
        can("ml:train") && v.lifecycle_state === "candidate" && v.test_evaluated_at ? button("Validate", async () => {
          const res = await api(`/ml/registry/${v.id}/validate`, { method: "POST", body: {} });
          toast(res.decision === "applied" ? "All promotion gates passed" : "Blocked by the promotion gates", res.decision === "applied" ? "success" : "error");
          gateDialog(`${v.name} v${v.version}: ${res.decision === "applied" ? "validated" : "blocked"}`, res.gates); await render();
        }, "small") : null,
        button("History", async () => {
          const hist = await api(`/ml/registry/${v.id}/transitions`);
          openDialog({ title: `Lifecycle of ${v.name} v${v.version}`, wide: true, body: h("div", null, dataTable([
            { label: "When", value: (x) => fmtDateTime(x.created_at) }, { label: "From", value: (x) => x.from_state }, { label: "To", value: (x) => x.to_state },
            { label: "Decision", value: (x) => badge(x.decision === "applied" ? "ok" : "blocked", x.decision) }, { label: "Note", value: (x) => x.note },
            { label: "", value: (x) => (x.gates ? button("Gates", () => gateDialog("Gate results", x.gates), "small") : null) }], hist.items),
          h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"))) });
        }, "small"),
        can("ml:train") && !v.test_evaluated_at ? button("Run final test", async () => {
          const ok = await formDialog({ title: "Run the final test evaluation?", description: "The sealed test period is evaluated once per model and the result is recorded permanently. Do this only for the model you intend to put forward for approval.", submitLabel: "Evaluate on test", onSubmit: () => api(`/ml/runs/${v.model_run_id}/evaluate`, { method: "POST", body: { split: "test" } }) });
          if (ok) { toast("Final test evaluation recorded", "success"); await render(); }
        }, "small") : null,
        can("ml:approve") && v.approval_status === "pending" ? button("Approve", async () => {
          const ok = await formDialog({ title: `Approve ${v.name} v${v.version}?`, description: "You confirm that you reviewed the test evaluation, threshold basis and explanations. The author of a version cannot approve it.", submitLabel: "Approve", fields: [{ name: "note", label: "Review note" }],
            onSubmit: (x) => api(`/ml/registry/${v.id}/review`, { method: "POST", body: { approve: true, note: x.note } }) });
          if (ok) { toast("Version approved", "success"); await render(); }
        }, "small primary") : null,
        can("ml:approve") && v.approval_status === "pending" ? button("Reject", async () => {
          const ok = await formDialog({ title: `Reject ${v.name} v${v.version}?`, submitLabel: "Reject", danger: true, fields: [{ name: "note", label: "Reason" }], onSubmit: (x) => api(`/ml/registry/${v.id}/review`, { method: "POST", body: { approve: false, note: x.note } }) });
          if (ok) await render();
        }, "small") : null,
        can("ml:train") && v.approval_status === "approved" && v.stage !== "production" ? button("Promote to production", async () => {
          const ok = await formDialog({ title: `Serve ${v.name} v${v.version} in production?`, description: "The current production version of this model is archived. New batch scores will come from this version.", submitLabel: "Promote", onSubmit: () => api(`/ml/registry/${v.id}/stage`, { method: "POST", body: { stage: "production" } }) });
          if (ok) { toast("Now serving in production", "success"); await render(); }
        }, "small primary") : null,
        can("ml:train") && v.stage === "production" ? button("Archive", async () => {
          const ok = await formDialog({ title: `Archive ${v.name} v${v.version}?`, description: "Scoring stops until another version is promoted.", submitLabel: "Archive", danger: true, onSubmit: () => api(`/ml/registry/${v.id}/stage`, { method: "POST", body: { stage: "archived" } }) });
          if (ok) await render();
        }, "small danger") : null,
        button("Details", () => go(`#/models/run/${v.model_run_id}`), "small")) },
    ], data.items, { emptyText: "Register a trained run from Model training to see it here.", caption: "Model versions" }), { flush: true }));
  }
  await render();
  return root;
}

function gateDialog(title, gates) {
  openDialog({ title, wide: true, body: h("div", null, dataTable([
    { label: "Gate", value: (g) => words(g.gate) }, { label: "Result", value: (g) => badge(g.status === "pass" ? "pass" : g.status === "fail" ? "fail" : "skipped", words(g.status)) },
    { label: "Value", align: "right", value: (g) => (isNum(g.value) ? f3(g.value) : g.value === null || g.value === undefined ? "–" : String(g.value)) },
    { label: "Threshold", align: "right", value: (g) => (g.threshold === null || g.threshold === undefined ? "–" : String(g.threshold)) }, { label: "Detail", value: (g) => g.detail },
  ], gates, { caption: "Promotion gate results" }), h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"))) });
}

// ------------------------------------------------------------------ predictions
export async function predictions() {
  const root = h("div");
  async function render() {
    const data = await api("/predictions/batches", { query: { page_size: 50 } });
    clear(root).append(pageHead("Predictions", "Each batch scores every active subscriber for one as-of date with the production model: churn probability, risk tier and the three factors that contributed most.", [
      can("predict:run") ? button("Score now", async () => {
        const res = await formDialog({ title: "Run batch scoring", description: "Scores all active subscribers. Re-running for the same model and date returns the existing batch instead of creating a duplicate.", submitLabel: "Score",
          fields: [{ name: "as_of_date", label: "As-of date", type: "date", hint: "empty = the day after the latest loaded data" }], onSubmit: (v) => api("/predictions/batches", { method: "POST", body: { as_of_date: v.as_of_date } }) });
        if (res) { if (res.already_exists) toast("That date was already scored by this model; showing the existing batch."); else await trackJob(res.job, "Batch scoring"); await render(); }
      }, "primary") : null]));
    root.append(card("Scoring batches", dataTable([
      { label: "Batch", value: (b) => `#${b.id}` }, { label: "As-of date", value: (b) => b.as_of_date }, { label: "Kind", value: (b) => (b.kind === "backtest" ? badge("info", "back-test") : words(b.kind)) }, { label: "Status", value: (b) => badge(b.status) },
      { label: "Scored", align: "right", value: (b) => fmtInt(b.succeeded) }, { label: "Failed", align: "right", value: (b) => fmtInt(b.failed) }, { label: "Finished", value: (b) => fmtDateTime(b.finished_at) },
    ], data.items, { onRow: (b) => go(`#/predictions/${b.id}`), emptyText: "No batch yet. A production model is needed before scoring.", caption: "Scoring batches" }), { flush: true, foot: "Back-test = a past date scored after the fact so that predictions can be compared with what actually happened." }));
  }
  await render();
  return root;
}

export async function batchDetail(id) {
  const batch = await api(`/predictions/batches/${id}`);
  const s = batch.summary || {}; const root = h("div");
  const exportBtn = can("customers:export") ? button("Download CSV", async () => {
    const res = await api(`/predictions/batches/${id}/export.csv`, { raw: true });
    const url = URL.createObjectURL(await res.blob());
    const a = h("a", { href: url, download: `churn-scores-${batch.as_of_date}.csv` }); document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }) : null;
  root.append(pageHead(`Scores for ${batch.as_of_date}`, s.model ? `${s.model.name} v${s.model.version} (${algo(s.model.algorithm)}) · probability of churning within ${s.horizon_days} days · ${words(batch.kind)}` : words(batch.status),
    [exportBtn, can("retention:write") && batch.kind !== "backtest" ? button("Generate recommendations", () => startJob("Recommendations", "/retention/recommendations/generate", { batch_id: Number(id) }, () => go("#/retention")), "primary") : null],
    h("span", null, link("Predictions", "#/predictions"), ` / batch #${id}`)));
  if (batch.status !== "completed") { root.append(notice("info", `This batch is ${batch.status}.`)); return root; }
  root.append(h("div", { class: "grid kpis" }, kpi("Customers scored", fmtInt(s.customers_scored)), kpi("High risk", fmtInt(s.tiers.high), `score ≥ ${fmtProb(batch.decile_cutpoints.high_min_probability)}`, "high"),
    kpi("Medium risk", fmtInt(s.tiers.medium), `score ≥ ${fmtProb(batch.decile_cutpoints.medium_min_probability)}`), kpi("Average risk", fmtProb(s.mean_probability), `highest ${fmtProb(s.max_probability)}`),
    kpi("Above decision threshold", fmtInt(s.flagged_at_threshold), "would be flagged for action")));
  if (s.explanations && s.explanations.status !== "available") root.append(notice("warn", h("strong", null, "Reasons unavailable. "), s.explanations.reason || ""));
  const tier = h("select", { "aria-label": "Risk tier" }, h("option", { value: "" }, "All tiers"), ["high", "medium", "low"].map((t) => h("option", { value: t }, `${t} risk`)));
  const table = pagedTable({ load: (page, size) => api(`/predictions/batches/${id}/predictions`, { query: { page, page_size: size, tier: tier.value } }), caption: "Predictions", columns: [
    { label: "Customer", value: (p) => h("span", null, p.customer_name || p.customer_external_id, h("span", { class: "sub" }, p.customer_external_id)) },
    { label: "Churn probability", value: (p) => bar(p.probability, p.risk_tier, fmtProb(p.probability)) }, { label: "Tier", value: (p) => tierBadge(p.risk_tier) }, { label: "Decile", align: "right", value: (p) => p.risk_decile },
    { label: "Top three factors", value: (p) => reasonList(p.top_reasons) },
  ], onRow: (p) => go(`#/customers/${p.customer_id}`) });
  tier.addEventListener("change", () => table.reload());
  const edges = batch.distribution.histogram.edges; const counts = batch.distribution.histogram.counts;
  root.append(h("div", { class: "stack" },
    card("Score distribution", barChart({ labels: counts.map((_, i) => `${Math.round(edges[i] * 100)}%`), series: [{ name: "Customers", color: "accent", values: counts }], xLabel: "Predicted probability (lower bound of bin)", yLabel: "Customers", height: 210, label: "Score distribution" }),
      { sub: `Tiers come from the ${s.risk_policy ? s.risk_policy.source : "risk policy"}: the highest-scoring share of customers is 'high', the next share 'medium'` }),
    card("Customers", h("div", null, h("div", { class: "toolbar" }, tier), table.el), { flush: true })));
  return root;
}
export function reasonList(reasons) {
  if (!reasons || !reasons.length) return h("span", { class: "muted" }, "–");
  return h("ul", { class: "reason-list" }, reasons.map((r) => (typeof r === "string" ? h("li", null, r) : h("li", null,
    h("span", { class: r.direction === "raises" ? "arrow-up" : "arrow-down", title: r.direction === "raises" ? "raises the predicted risk" : "lowers the predicted risk" }, r.direction === "raises" ? "▲ " : "▼ "), `${r.label}: ${r.display_value}`))));
}
export function explanationCard(ex) {
  if (!ex || ex.status !== "available") return card("Why this score", notice("warn", (ex && ex.reason) || "No explanation is available for this prediction."));
  const w = ex.contributions.waterfall;
  return card("Why this score", h("div", null,
    waterfall({ base: w.base_probability, final: w.final_probability, fmt: (v) => fmtProb(v), deltaFmt: (v) => `${(v * 100).toFixed(1)} pts`, label: "Contribution of each factor to the predicted churn probability",
      steps: w.steps.map((st) => ({ label: st.feature === "__other__" || !st.display_value ? st.label : `${st.label}: ${st.display_value}`, after: st.probability_after })) }),
    h("div", { class: "legend" }, h("span", null, h("span", { class: "swatch sw-red" }), "raises the predicted risk"), h("span", null, h("span", { class: "swatch sw-green" }), "lowers it")),
    h("p", { class: "muted small" }, "Each bar shows how many percentage points a factor moves the predicted probability. ", w.disclaimer)),
  { sub: `${ex.method} · reproduces the stored score: ${ex.contributions.reproduces_stored_probability ? "yes" : "no"}` });
}
