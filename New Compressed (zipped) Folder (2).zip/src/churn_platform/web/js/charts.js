// Dependency-free SVG charts.  Colours and geometry are SVG attributes (allowed by the CSP).
import { h, isNum } from "./core.js";

const NS = "http://www.w3.org/2000/svg";
export const COLORS = { accent: "#0e7c66", grey: "#98a2b3", red: "#d92d20", blue: "#1570ef", amber: "#dc6803", violet: "#7a5af8", green: "#12b76a" };

export function s(tag, attrs, ...children) {
  const el = document.createElementNS(NS, tag);
  if (attrs) for (const [k, v] of Object.entries(attrs)) if (v !== null && v !== undefined && v !== false) el.setAttribute(k, String(v));
  for (const child of children.flat(Infinity)) if (child !== null && child !== undefined && child !== false) el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return el;
}

function ticks(min, max, count = 5) {
  if (!(max > min)) return [min];
  const raw = (max - min) / count;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((m) => m >= raw) || raw;
  const out = [];
  for (let v = Math.ceil(min / step - 1e-9) * step; v <= max + step * 1e-9; v += step) out.push(Math.abs(v) < 1e-12 ? 0 : Number(v.toPrecision(12)));
  return out;
}
/** Axis label for a share: 0.075 -> "7.5%".  Never rounds a tick onto a neighbouring value (7.5% must not read "8%"). */
export const pctTick = (v) => `${Number((v * 100).toPrecision(3))}%`;
const defFmt = (v) => (Math.abs(v) >= 1000 ? v.toLocaleString("en-US") : String(Number(v.toPrecision(3))));

function frame({ width, height, xDomain, yDomain, xLabel, yLabel, xFmt = defFmt, yFmt = defFmt, label, xTicks }) {
  const m = { l: 54, r: 14, t: 10, b: xLabel ? 44 : 28 };
  const iw = width - m.l - m.r; const ih = height - m.t - m.b;
  const X = (v) => m.l + ((v - xDomain[0]) / (xDomain[1] - xDomain[0] || 1)) * iw;
  const Y = (v) => m.t + ih - ((v - yDomain[0]) / (yDomain[1] - yDomain[0] || 1)) * ih;
  const svg = s("svg", { class: "chart", viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": label || "chart" });
  for (const t of ticks(yDomain[0], yDomain[1])) {
    svg.append(s("line", { class: "gridline", x1: m.l, x2: m.l + iw, y1: Y(t), y2: Y(t) }), s("text", { x: m.l - 8, y: Y(t) + 4, "text-anchor": "end" }, yFmt(t)));
  }
  for (const t of xTicks || ticks(xDomain[0], xDomain[1], 6)) svg.append(s("text", { x: X(t), y: m.t + ih + 16, "text-anchor": "middle" }, xFmt(t)));
  svg.append(s("line", { class: "axis", x1: m.l, x2: m.l + iw, y1: m.t + ih, y2: m.t + ih }));
  if (xLabel) svg.append(s("text", { class: "title-x", x: m.l + iw / 2, y: height - 6, "text-anchor": "middle" }, xLabel));
  if (yLabel) svg.append(s("text", { class: "title-y", x: 13, y: m.t + ih / 2, "text-anchor": "middle", transform: `rotate(-90 13 ${m.t + ih / 2})` }, yLabel));
  return { svg, X, Y, m, iw, ih };
}

function legend(items) {
  return h("div", { class: "legend" }, items.map((it) => h("span", null, h("span", { class: `swatch sw-${it.color || "accent"}` }), it.name)));
}
function extent(values, pad = 0) {
  const clean = values.filter(isNum);
  if (!clean.length) return [0, 1];
  let lo = Math.min(...clean); let hi = Math.max(...clean);
  if (lo === hi) { lo -= 1; hi += 1; }
  const span = hi - lo;
  return [lo - span * pad, hi + span * pad];
}

/** series: [{name, points: [[x, y]], color, dashed, band: [[x, low, high]], step}] */
export function lineChart({ series, width = 640, height = 270, xLabel, yLabel, xDomain, yDomain, xFmt, yFmt, label, showLegend = true }) {
  const all = series.flatMap((se) => se.points);
  const xd = xDomain || extent(all.map((p) => p[0]));
  const yd = yDomain || extent(all.map((p) => p[1]).concat(series.flatMap((se) => (se.band || []).flatMap((b) => [b[1], b[2]]))), 0.06);
  const f = frame({ width, height, xDomain: xd, yDomain: yd, xLabel, yLabel, xFmt, yFmt, label });
  for (const se of series) {
    const color = COLORS[se.color || "accent"];
    if (se.band && se.band.length) {
      const upper = se.band.map((b) => `${f.X(b[0]).toFixed(1)},${f.Y(b[2]).toFixed(1)}`);
      const lower = se.band.slice().reverse().map((b) => `${f.X(b[0]).toFixed(1)},${f.Y(b[1]).toFixed(1)}`);
      f.svg.append(s("polygon", { points: upper.concat(lower).join(" "), fill: color, "fill-opacity": 0.12, stroke: "none" }));
    }
    const pts = se.points.filter((p) => isNum(p[0]) && isNum(p[1]));
    if (!pts.length) continue;
    let d = "";
    pts.forEach((p, i) => {
      const x = f.X(p[0]).toFixed(1); const y = f.Y(p[1]).toFixed(1);
      if (i === 0) d += `M${x},${y}`;
      else if (se.step) d += `H${x}V${y}`;
      else d += `L${x},${y}`;
    });
    f.svg.append(s("path", { d, fill: "none", stroke: color, "stroke-width": se.dashed ? 1.5 : 2, "stroke-dasharray": se.dashed ? "5 4" : null, "stroke-linejoin": "round" }));
    if (se.dots) for (const p of pts) f.svg.append(s("circle", { cx: f.X(p[0]), cy: f.Y(p[1]), r: 3, fill: color }, s("title", null, `${se.name}: ${(yFmt || defFmt)(p[1])} at ${(xFmt || defFmt)(p[0])}`)));
  }
  return h("div", null, f.svg, showLegend && series.length > 1 ? legend(series) : null);
}

/** Grouped vertical bars.  labels: [..], series: [{name, color, values: [..]}] */
export function barChart({ labels, series, width = 640, height = 250, yLabel, xLabel, yFmt, yDomain, label, maxLabels = 14 }) {
  const values = series.flatMap((se) => se.values);
  const yd = yDomain || [Math.min(0, ...values.filter(isNum)), Math.max(1e-9, ...values.filter(isNum)) * 1.08];
  const f = frame({ width, height, xDomain: [0, labels.length], yDomain: yd, xLabel, yLabel, yFmt, label, xTicks: [] });
  const band = f.iw / Math.max(1, labels.length);
  const inner = band * 0.72; const bw = inner / series.length;
  const every = Math.ceil(labels.length / maxLabels);
  labels.forEach((name, i) => {
    series.forEach((se, k) => {
      const v = se.values[i];
      if (!isNum(v)) return;
      const y0 = f.Y(0); const y1 = f.Y(v);
      f.svg.append(s("rect", { x: f.m.l + i * band + (band - inner) / 2 + k * bw, y: Math.min(y0, y1), width: Math.max(1, bw - 1), height: Math.max(0.5, Math.abs(y1 - y0)), fill: COLORS[se.color || "accent"], rx: 1.5 },
        s("title", null, `${name} — ${se.name}: ${(yFmt || defFmt)(v)}`)));
    });
    if (i % every === 0) f.svg.append(s("text", { x: f.m.l + i * band + band / 2, y: f.m.t + f.ih + 16, "text-anchor": "middle" }, name));
  });
  return h("div", null, f.svg, series.length > 1 ? legend(series) : null);
}

/** points: [{x, y, color, title}] */
export function scatter({ points, width = 520, height = 380, xLabel, yLabel, domain = [0, 1], diagonal = true, fmt, label, legendItems }) {
  const f = frame({ width, height, xDomain: domain, yDomain: domain, xLabel, yLabel, xFmt: fmt, yFmt: fmt, label });
  if (diagonal) f.svg.append(s("line", { x1: f.X(domain[0]), y1: f.Y(domain[0]), x2: f.X(domain[1]), y2: f.Y(domain[1]), stroke: COLORS.grey, "stroke-dasharray": "4 4" }));
  for (const p of points) if (isNum(p.x) && isNum(p.y)) f.svg.append(s("circle", { cx: f.X(p.x).toFixed(1), cy: f.Y(p.y).toFixed(1), r: 2.6, fill: COLORS[p.color || "accent"], "fill-opacity": 0.55 }));
  return h("div", null, f.svg, legendItems ? legend(legendItems) : null);
}

/** Horizontal waterfall in probability space.  steps: [{label, after, delta}] */
export function waterfall({ base, steps, final, fmt, deltaFmt, width = 640, label }) {
  const dfmt = deltaFmt || fmt;
  const rowH = 26; const top = 8; const left = 250; const right = 64;
  const rows = [{ label: "Average customer (baseline)", from: 0, to: base, kind: "total" }];
  let prev = base;
  for (const st of steps) { rows.push({ label: st.label, from: prev, to: st.after, kind: st.after >= prev ? "up" : "down", delta: st.after - prev }); prev = st.after; }
  rows.push({ label: "This customer's predicted risk", from: 0, to: final, kind: "total" });
  const height = top * 2 + rows.length * rowH;
  const hi = Math.max(...rows.map((r) => Math.max(r.from, r.to))) * 1.05 || 1;
  const X = (v) => left + (v / hi) * (width - left - right);
  const svg = s("svg", { class: "chart", viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": label || "waterfall" });
  rows.forEach((r, i) => {
    const y = top + i * rowH;
    const x0 = X(Math.min(r.from, r.to)); const x1 = X(Math.max(r.from, r.to));
    const fill = r.kind === "total" ? "#475467" : r.kind === "up" ? COLORS.red : COLORS.green;
    const text = String(r.label).length > 38 ? String(r.label).slice(0, 37) + "…" : r.label;
    svg.append(s("text", { x: left - 10, y: y + 17, "text-anchor": "end" }, text, s("title", null, r.label)),
      s("rect", { x: x0, y: y + 5, width: Math.max(1.5, x1 - x0), height: rowH - 10, fill, rx: 2 }),
      s("text", { x: x1 + 6, y: y + 17 }, r.kind === "total" ? fmt(r.to) : `${r.delta >= 0 ? "+" : "−"}${dfmt(Math.abs(r.delta))}`));
    if (i < rows.length - 1) svg.append(s("line", { class: "axis", x1: X(r.to), x2: X(r.to), y1: y + rowH - 5, y2: y + rowH + 5, "stroke-dasharray": "2 2" }));
  });
  return svg;
}

/** Cohort heatmap.  rows: [{label, size, cells: [rate|null]}] */
export function heatTable({ rows, periods, caption, fmt }) {
  const cls = (v) => (isNum(v) ? `heat-${Math.max(0, Math.min(9, Math.floor(v * 10 - 1e-9)))}` : "na");
  return h("div", { class: "table-wrap" }, h("table", { class: "heat" }, h("caption", { class: "sr-only" }, caption),
    h("thead", null, h("tr", null, h("th", { scope: "col" }, "Cohort"), h("th", { scope: "col" }, "Size"), periods.map((p) => h("th", { scope: "col" }, `M${p}`)))),
    h("tbody", null, rows.map((r) => h("tr", null, h("th", { scope: "row" }, r.label), h("th", null, r.size),
      r.cells.map((v) => h("td", { class: cls(v), title: isNum(v) ? fmt(v) : "not observed yet" }, isNum(v) ? Math.round(v * 100) : "")))))));
}
