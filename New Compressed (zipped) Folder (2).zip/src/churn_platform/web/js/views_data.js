// Screens: overview, data sources & imports, data quality, churn labels, feature store, analytics, policies.
import { api, can, h, card, kpi, kv, notice, badge, tierBadge, pageHead, button, dataTable, pagedTable, tabs, empty, jsonBlock, bar, link, go, words,
  fmtInt, fmtPct, fmtProb, fmtMoney, fmtDate, fmtDateTime, shortHash, formDialog, openDialog, startJob, trackJob, toast, errorNotice, clear, isNum } from "./core.js";
import { lineChart, barChart, heatTable, pctTick } from "./charts.js";

export const safe = async (promise) => { try { return await promise; } catch { return null; } };
const pct0 = (v) => `${Math.round(v * 100)}%`;

// ------------------------------------------------------------------ overview
export async function overview() {
  const [summary, portfolio, batches, top, recs, monitoring, alerts] = await Promise.all([
    can("data:read") ? safe(api("/data/summary")) : null,
    can("analytics:read") ? safe(api("/analytics/reports/latest", { query: { kind: "overview" } })) : null,
    can("predict:read") ? safe(api("/predictions/batches", { query: { page_size: 10 } })) : null,
    can("customers:read") ? safe(api("/customers", { query: { page_size: 8, sort: "risk" } })) : null,
    can("retention:read") ? safe(api("/retention/recommendations", { query: { page_size: 1 } })) : null,
    can("mlops:read") ? safe(api("/monitoring/latest")) : null,
    can("mlops:read") ? safe(api("/alerts", { query: { status: "open" } })) : null,
  ]);
  const latest = batches && batches.items.find((b) => b.kind !== "backtest" && b.status === "completed");
  const batch = latest ? await safe(api(`/predictions/batches/${latest.id}`)) : null;
  const result = portfolio && portfolio.report ? portfolio.report.result : null;
  const model = monitoring && monitoring.production_model;
  const root = h("div", null, pageHead("Overview", "Where the subscriber base stands today, who is most likely to leave in the next 30 days and what is being done about it."));

  const kpis = h("div", { class: "grid kpis" });
  if (result) {
    kpis.append(kpi("Active customers", fmtInt(result.active_customers), `of ${fmtInt(result.customers)} ever loaded`),
      kpi("Active MRR", fmtMoney(result.active_mrr), "monthly recurring revenue"));
    const complete = result.monthly.filter((m) => m.complete && isNum(m.churn_rate));
    if (complete.length) { const last = complete[complete.length - 1]; kpis.append(kpi("Monthly churn", fmtPct(last.churn_rate), `${last.month}: ${last.voluntary} voluntary, ${last.involuntary} involuntary`)); }
  }
  if (batch) kpis.append(kpi("High-risk customers", fmtInt(batch.summary.tiers.high), `top ${pct0(batch.summary.tiers.high / batch.summary.customers_scored)} of ${fmtInt(batch.summary.customers_scored)} scored on ${batch.as_of_date}`, "high"));
  if (summary) kpis.append(kpi("Data quality", isNum(summary.dq_score) ? fmtPct(summary.dq_score, 2) : "–", `${fmtInt(summary.open_quarantine)} rows in quarantine`, summary.dq_score >= 0.95 ? "ok" : ""));
  if (alerts) kpis.append(kpi("Open alerts", fmtInt(alerts.total), alerts.total ? "see Monitoring" : "none", alerts.total ? "high" : "ok"));
  if (kpis.children.length) root.append(kpis);

  if (!batch && can("predict:read")) {
    root.append(notice("info", h("strong", null, "No scores yet. "), "Load data, approve a churn definition and feature contract, train and approve a model, then run batch scoring. ",
      link("Go to data sources", "#/data")));
  }

  const grid = h("div", { class: "grid cols-2" });
  if (result) {
    const months = result.monthly.filter((m) => m.complete);
    grid.append(card("Customers gained and lost per month", barChart({
      labels: months.map((m) => m.month.slice(2)), label: "New and churned customers per month",
      series: [{ name: "New", color: "accent", values: months.map((m) => m.new) }, { name: "Voluntary churn", color: "red", values: months.map((m) => m.voluntary) },
        { name: "Involuntary churn (payment)", color: "amber", values: months.map((m) => m.involuntary) }] }),
    { sub: "Observed history; the current month is excluded because it is incomplete", actions: link("Analytics", "#/analytics") }));
  }
  if (batch) {
    const edges = batch.distribution.histogram.edges; const counts = batch.distribution.histogram.counts;
    grid.append(card("Predicted 30-day churn risk", h("div", null,
      barChart({ labels: counts.map((_, i) => pct0(edges[i])), series: [{ name: "Customers", color: "accent", values: counts }], xLabel: "Predicted probability of churning (lower bound of bin)", yLabel: "Customers", label: "Histogram of predicted churn probability" }),
      h("div", { class: "chips" }, ["high", "medium", "low"].map((t) => h("span", { class: `badge tier-${t}` }, `${t}: ${fmtInt(batch.summary.tiers[t])}`)))),
    { sub: `${batch.summary.model.name} v${batch.summary.model.version} · scored for ${batch.as_of_date}`, actions: link("Predictions", `#/predictions/${batch.id}`) }));
  }
  if (grid.children.length) root.append(grid);

  const lower = h("div", { class: "grid cols-2 stack" });
  if (top && top.items.length && top.batch) {
    lower.append(card("Customers most at risk", dataTable([
      { label: "Customer", value: (r) => h("span", null, r.name || r.external_id, h("span", { class: "sub" }, r.external_id)) },
      { label: "Risk", value: (r) => (isNum(r.probability) ? bar(r.probability, r.risk_tier, fmtProb(r.probability)) : "–") },
      { label: "Main factor", value: (r) => (r.top_reasons && r.top_reasons[0] ? String(r.top_reasons[0]).replace(/ \((raises|lowers) the predicted risk\)/, "") : "–") },
    ], top.items, { onRow: (r) => go(`#/customers/${r.id}`), caption: "Customers most at risk" }), { flush: true, actions: link("All customers", "#/customers") }));
  }
  if (recs && recs.summary) {
    const rows = Object.entries(recs.summary.by_segment).map(([segment, counts]) => ({ segment, ...counts }));
    lower.append(card("Retention actions waiting", dataTable([
      { label: "Segment", value: (r) => SEGMENT_LABEL[r.segment] || words(r.segment) },
      { label: "Proposed", align: "right", value: (r) => fmtInt(r.proposed || 0) },
      { label: "Approved", align: "right", value: (r) => fmtInt(r.approved || 0) },
      { label: "Executed", align: "right", value: (r) => fmtInt(r.executed || 0) },
      { label: "Blocked", align: "right", value: (r) => fmtInt(r.blocked || 0) },
    ], rows, { emptyText: "No recommendations have been generated for the latest scores." }),
    { flush: true, actions: link("Recommendations", "#/retention"), foot: "Blocked = consent missing, contact cooldown, or an uplift rule." }));
  }
  if (lower.children.length) root.append(h("div", { class: "stack" }, lower));

  if (model) {
    const reports = monitoring.reports || {};
    root.append(h("div", { class: "stack" }, card("Model in production", kv([
      ["Model", link(`${model.name} v${model.version}`, "#/registry")],
      ["Decision threshold", h("span", null, fmtProb(model.threshold), model.threshold_basis && model.threshold_basis.is_example ? [" ", h("span", { class: "badge warn" }, "from an example cost matrix")] : null)],
      ["Feature drift", reports.feature ? badge(reports.feature.status) : "not measured"],
      ["Score drift", reports.prediction ? badge(reports.prediction.status) : "not measured"],
      ["Realised performance", reports.concept ? badge(reports.concept.status) : "not measured"],
    ]), { actions: link("Monitoring", "#/monitoring") })));
  }
  return root;
}
export const SEGMENT_LABEL = { high_risk_high_value: "High risk · high value", medium_risk_low_value: "At risk · lower value (automated)", involuntary: "Involuntary (payment) risk" };

// ------------------------------------------------------------------ data sources
export async function dataSources() {
  const root = h("div", null, pageHead("Data sources & imports", "Register sources, upload files, map columns and import. Every file is versioned by checksum; rows that fail validation go to quarantine instead of being dropped."));
  const summary = await safe(api("/data/summary"));
  if (summary) {
    root.append(h("div", { class: "grid kpis" }, Object.entries(summary.rows).filter(([, n]) => n).slice(0, 10).map(([name, n]) => kpi(words(name), fmtInt(n)))),
      h("p", { class: "muted small" }, `Data cutoff (latest event loaded): ${fmtDateTime(summary.data_cutoff)}. Features and scores never use anything after their as-of date.`));
  }
  root.append(tabs([
    { id: "sources", label: "Sources", render: sourcesTab },
    { id: "imports", label: "Import runs", render: importsTab },
    { id: "quarantine", label: `Quarantine${summary && summary.open_quarantine ? ` (${summary.open_quarantine})` : ""}`, render: quarantineTab },
    { id: "schemas", label: "Expected schemas", render: schemasTab },
  ]));
  return root;
}

async function sourcesTab() {
  const holder = h("div");
  async function render() {
    const [sources, schemas] = await Promise.all([api("/data/sources"), api("/data/schemas")]);
    const actions = can("data:write") ? button("New source", async () => {
      const created = await formDialog({ title: "New data source", submitLabel: "Create source", fields: [
        { name: "name", label: "Name", required: true, placeholder: "Billing export" },
        { name: "entity_type", label: "What it contains", type: "select", options: schemas.load_order, value: "customers" },
        { name: "kind", label: "How data arrives", type: "select", options: [["file", "File upload (CSV, JSON, Parquet, Excel)"], ["rest_api", "REST API pull"], ["webhook", "Webhook push"]], value: "file" },
        { name: "description", label: "Description" },
      ], onSubmit: (v) => api("/data/sources", { method: "POST", body: v }) });
      if (created) { toast("Source created", "success"); await render(); }
    }, "primary") : null;
    clear(holder).append(card("Sources", dataTable([
      { label: "Name", value: (r) => h("span", null, r.name, r.description ? h("span", { class: "sub" }, r.description) : null) },
      { label: "Entity", value: (r) => words(r.entity_type) },
      { label: "Arrives by", value: (r) => words(r.kind) },
      { label: "Mapped columns", align: "right", value: (r) => (r.mapping && r.mapping.columns ? Object.keys(r.mapping.columns).length : r.mapping ? Object.keys(r.mapping).length : 0) },
      { label: "Updated", value: (r) => fmtDateTime(r.updated_at) },
    ], sources.items, { onRow: (r) => sourceDialog(r, render), emptyText: "Create a source for each kind of data: customers first, then accounts, plans, subscriptions and events.", caption: "Data sources" }),
    { flush: true, actions, foot: `Load order: ${schemas.load_order.map(words).join(" → ")}` }));
  }
  await render();
  return holder;
}

async function sourceDialog(source, refresh) {
  const versions = await api(`/data/sources/${source.id}/versions`);
  const body = h("div", { class: "stack" });
  const dialog = openDialog({ title: source.name, description: `${words(source.entity_type)} · ${words(source.kind)}`, body, wide: true });
  const cols = (source.discovered_schema && source.discovered_schema.columns) || [];
  body.append(h("h3", null, "File versions"), dataTable([
    { label: "Version", value: (v) => `v${v.version_no}` }, { label: "File", value: (v) => v.file_name },
    { label: "Rows", align: "right", value: (v) => fmtInt(v.row_count) }, { label: "SHA-256", value: (v) => h("code", null, shortHash(v.checksum_sha256)) },
    { label: "Origin", value: (v) => (v.is_synthetic ? badge("warning", "synthetic") : words(v.origin)) }, { label: "Registered", value: (v) => fmtDateTime(v.created_at) },
  ], versions.items, { emptyText: "No file has been uploaded for this source yet." }));
  if (cols.length) body.append(h("h3", null, "Columns found in the latest file"), dataTable([
    { label: "Column", value: (c) => h("code", null, c.name) }, { label: "Type", value: (c) => c.inferred_type },
    { label: "Examples", value: (c) => (c.examples || []).slice(0, 3).join(", ") },
  ], cols));
  body.append(h("h3", null, "Column mapping"), jsonBlock(source.mapping || {}));
  const foot = h("div", { class: "dialog-foot" }, h("button", { type: "button", class: "btn", onclick: () => dialog.close() }, "Close"));
  if (can("data:write")) {
    const file = h("input", { type: "file", class: "sr-only", accept: ".csv,.json,.jsonl,.parquet,.xlsx" });
    file.addEventListener("change", async () => {
      if (!file.files.length) return;
      const form = new FormData(); form.append("file", file.files[0]);
      try {
        const res = await api(`/data/sources/${source.id}/files`, { method: "POST", form });
        toast(res.already_registered ? "This exact file was already registered (same checksum); nothing was duplicated." : `File registered as version ${res.dataset_version.version_no}`, "success");
        dialog.close(); await refresh();
      } catch (err) { toast(err.message, "error", err.correlationId); }
    });
    foot.prepend(file, button("Upload file", () => file.click()),
      button("Edit mapping", async () => {
        const saved = await formDialog({ title: "Column mapping", description: "Maps the file's column names to the platform's field names.", wide: true,
          fields: [{ name: "mapping", label: "Mapping (JSON)", type: "json", value: (source.mapping && source.mapping.columns) || source.mapping || {} }],
          onSubmit: (v) => api(`/data/sources/${source.id}/mapping`, { method: "PUT", body: { mapping: v.mapping } }) });
        if (saved) { toast("Mapping saved as a new version", "success"); dialog.close(); await refresh(); }
      }),
      versions.items.length ? button("Import latest file", async () => { dialog.close(); await startJob(`Import ${source.name}`, `/data/sources/${source.id}/imports`, {}, refresh); }, "primary") : null);
  }
  body.append(foot);
}

async function importsTab() {
  const sources = new Map((await api("/data/sources")).items.map((s) => [s.id, s]));
  const table = pagedTable({ load: (page, size) => api("/data/imports", { query: { page, page_size: size } }), caption: "Import runs", columns: [
    { label: "Run", value: (r) => `#${r.id}` },
    { label: "Source", value: (r) => (sources.get(r.source_id) || {}).name || `source ${r.source_id}` },
    { label: "Status", value: (r) => badge(r.status) },
    { label: "Read", align: "right", value: (r) => fmtInt(r.rows_read) },
    { label: "Inserted", align: "right", value: (r) => fmtInt(r.rows_inserted) },
    { label: "Updated", align: "right", value: (r) => fmtInt(r.rows_updated) },
    { label: "Quarantined", align: "right", value: (r) => fmtInt(r.rows_quarantined) },
    { label: "Reconciled", value: (r) => (r.reconciliation ? badge(r.reconciliation.balanced ? "balanced" : "mismatch") : "–") },
    { label: "Finished", value: (r) => fmtDateTime(r.finished_at) },
  ], onRow: (r) => openDialog({ title: `Import run #${r.id}`, description: "Row accounting: every row read is inserted, updated, unchanged, a duplicate or quarantined.", wide: true,
    body: h("div", null, r.error ? notice("danger", r.error) : null, jsonBlock(r.reconciliation || {}), closeFoot()) }),
  emptyNode: empty("No imports yet", "Upload a file to a source and import it.") });
  return card("Import runs", table.el, { flush: true });
}
function closeFoot() { return h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close")); }

async function quarantineTab() {
  const status = h("select", { "aria-label": "Status" }, ["open", "corrected", "rejected", "reprocessed"].map((s) => h("option", { value: s }, words(s))));
  const table = pagedTable({ load: (page, size) => api("/data/quarantine", { query: { page, page_size: size, status: status.value } }), caption: "Quarantined rows", columns: [
    { label: "Entity", value: (r) => words(r.entity_type) }, { label: "Row", align: "right", value: (r) => fmtInt(r.row_number) },
    { label: "Why it was held back", value: (r) => h("ul", { class: "reason-list" }, r.reasons.map((x) => h("li", null, x))) },
    { label: "Row content", value: (r) => h("code", null, JSON.stringify(r.payload).slice(0, 110)) },
    { label: "Status", value: (r) => badge(r.status) },
    { label: "", value: (r) => (can("quality:review") && (r.status === "open" || r.status === "corrected") ? h("div", { class: "actions" },
      button("Fix & reprocess", async () => {
        const done = await formDialog({ title: "Correct quarantined row", description: r.reasons.join("; "), submitLabel: "Save and reprocess", wide: true,
          fields: [{ name: "corrected", label: "Corrected row (JSON, source column names)", type: "json", value: r.corrected_payload || r.payload }, { name: "note", label: "Note" }],
          // one request: the corrected row is saved with the record and loading is attempted again
          onSubmit: (v) => api("/data/quarantine/review", { method: "POST", body: { ids: [r.id], action: "reprocess", corrected: { [r.id]: v.corrected }, note: v.note } }) });
        if (!done) return;
        if (done.reprocessed) toast("Row corrected and loaded", "success");
        else toast("The corrected row still fails validation; the reasons were updated.", "error");
        table.reload(false);
      }, "small"),
      button("Reject", async () => {
        const done = await formDialog({ title: "Reject this row?", description: "The row stays on record as rejected and is not loaded.", submitLabel: "Reject row", danger: true,
          fields: [{ name: "note", label: "Reason" }], onSubmit: (v) => api("/data/quarantine/review", { method: "POST", body: { ids: [r.id], action: "reject", note: v.note } }) });
        if (done) table.reload(false);
      }, "small danger")) : null) },
  ], emptyNode: empty("Nothing in quarantine", "Rows that fail validation (unknown references, missing keys, impossible dates) appear here.") });
  status.addEventListener("change", () => table.reload());
  return card("Quarantine", h("div", null, h("div", { class: "toolbar" }, h("label", { class: "small muted" }, "Status ", status)), table.el), { flush: true });
}

async function schemasTab() {
  const schemas = await api("/data/schemas");
  return h("div", { class: "grid cols-2" }, schemas.load_order.map((name) => card(words(name), dataTable([
    { label: "Field", value: (f) => h("code", null, f.name) }, { label: "Type", value: (f) => f.type }, { label: "Required", value: (f) => (f.required ? badge("info", "required") : "optional") },
  ], schemas.entities[name]), { flush: true })));
}

// ------------------------------------------------------------------ data quality
export async function quality() {
  const root = h("div");
  async function render() {
    const runs = await api("/quality/runs", { query: { page_size: 10 } });
    const run = runs.items.find((r) => r.status === "completed");
    clear(root).append(pageHead("Data quality", "Rule-based checks on the loaded data. The score is the severity-weighted share of rows passing each rule; failures are listed so they can be corrected at the source or through a reviewed correction.",
      [can("quality:write") ? button("Run checks now", () => startJob("Data quality checks", "/quality/runs", {}, render), "primary") : null]));
    if (!run) { root.append(card(null, empty("No data-quality run yet", "Import data, then run the checks."))); return; }
    const sc = run.scorecard;
    root.append(h("div", { class: "grid kpis" }, kpi("Overall score", fmtPct(sc.overall, 2), `run #${run.id} · ${fmtDateTime(run.finished_at)}`, sc.overall >= 0.95 ? "ok" : "high"),
      kpi("Rules evaluated", fmtInt(run.rules_evaluated)), kpi("Findings", fmtInt(run.findings_count), "individual failing records")));
    root.append(h("div", { class: "grid cols-2" },
      card("By dimension", dataTable([{ label: "Dimension", value: (r) => words(r[0]) }, { label: "Score", value: (r) => bar(r[1], r[1] >= 0.99 ? "low" : "medium", fmtPct(r[1], 2)) }], Object.entries(sc.dimensions)), { flush: true }),
      card("By entity", dataTable([{ label: "Entity", value: (r) => words(r[0]) }, { label: "Score", value: (r) => bar(r[1], r[1] >= 0.99 ? "low" : "medium", fmtPct(r[1], 2)) }], Object.entries(sc.entities)), { flush: true })));
    const findings = pagedTable({ pageSize: 15, load: (page, size) => api(`/quality/runs/${run.id}/findings`, { query: { page, page_size: size } }), caption: "Findings", columns: [
      { label: "Rule", value: (f) => f.rule_name }, { label: "Record", value: (f) => h("span", null, f.entity_ref || `#${f.entity_id}`, h("span", { class: "sub" }, words(f.entity_type))) },
      { label: "Severity", value: (f) => badge(f.severity === "error" ? "critical" : "warning", f.severity) }, { label: "Detail", value: (f) => h("code", null, JSON.stringify(f.detail).slice(0, 120)) },
      { label: "", value: (f) => (can("quality:write") && f.entity_id ? button("Propose correction", async () => {
        const made = await formDialog({ title: "Propose a correction", description: `${words(f.entity_type)} ${f.entity_ref || f.entity_id}. A second person must approve before the value changes; later imports will not overwrite an approved correction.`,
          fields: [{ name: "field", label: "Field to change", required: true }, { name: "new_value", label: "New value" }, { name: "reason", label: "Reason", required: true }],
          onSubmit: (v) => api("/quality/corrections", { method: "POST", body: { entity_type: f.entity_type, entity_id: f.entity_id, field: v.field, new_value: v.new_value, reason: v.reason, finding_id: f.id } }) });
        if (made) { toast("Correction proposed for review", "success"); await render(); }
      }, "small") : null) },
    ], emptyNode: empty("No failing records", "Every checked row passed.") });
    root.append(h("div", { class: "stack" },
      card("Rules", dataTable([
        { label: "Rule", value: (r) => r.name }, { label: "Entity", value: (r) => words(r.entity_type) }, { label: "Dimension", value: (r) => words(r.dimension) },
        { label: "Severity", value: (r) => words(r.severity) }, { label: "Checked", align: "right", value: (r) => fmtInt(r.rows_checked) },
        { label: "Failed", align: "right", value: (r) => fmtInt(r.rows_failed) }, { label: "Pass rate", align: "right", value: (r) => fmtPct(r.pass_rate, 2) },
        { label: "Result", value: (r) => badge(r.status) },
      ], sc.rules, { caption: "Data-quality rules" }), { flush: true, foot: sc.scoring }),
      card("Failing records", findings.el, { flush: true, sub: `At most ${sc.findings_stored_per_rule_limit} examples are stored per rule` }),
      await correctionsCard(render)));
  }
  await render();
  return root;
}
async function correctionsCard(refresh) {
  const data = await api("/quality/corrections");
  return card("Corrections", dataTable([
    { label: "Record", value: (c) => `${words(c.entity_type)} #${c.entity_id}` }, { label: "Field", value: (c) => h("code", null, c.field) },
    { label: "Change", value: (c) => `${JSON.stringify(c.old_value)} → ${JSON.stringify(c.new_value)}` }, { label: "Reason", value: (c) => c.reason },
    { label: "Status", value: (c) => badge(c.status) },
    { label: "", value: (c) => (can("quality:review") && c.status === "proposed" ? h("div", { class: "actions" },
      button("Approve", async () => { await api(`/quality/corrections/${c.id}/review`, { method: "POST", body: { approve: true } }); toast("Correction applied", "success"); await refresh(); }, "small primary"),
      button("Reject", async () => { await api(`/quality/corrections/${c.id}/review`, { method: "POST", body: { approve: false } }); await refresh(); }, "small")) : null) },
  ], data.items, { emptyText: "No corrections have been proposed." }), { flush: true, sub: "Changes to loaded values need a second person's approval" });
}

// ------------------------------------------------------------------ labels
export async function labels() {
  const root = h("div");
  async function render() {
    const summary = await api("/labels/summary");
    clear(root).append(pageHead("Churn labels", "For each month-start date T a customer is labelled from what happened in the following window. Labels whose window has not fully passed are kept as 'immature' and never used for training.",
      [can("labels:write") && summary.policy ? button("Generate labels", async () => {
        const res = await formDialog({ title: "Generate labels", description: "Leave both dates empty to label every month start covered by the data.", submitLabel: "Generate",
          fields: [{ name: "start", label: "From (as-of date)", type: "date" }, { name: "end", label: "To (as-of date)", type: "date" }],
          onSubmit: (v) => api("/labels/runs", { method: "POST", body: v }) });
        if (res && res.job) { await trackJob(res.job, "Label generation"); await render(); }
      }, "primary") : null]));
    if (!summary.policy) { root.append(notice("warn", h("strong", null, "No approved churn definition. "), "Labels need an approved definition of churn. ", link("Open policies", "#/policies"))); return; }
    const p = summary.policy.payload;
    const rows = summary.dates || [];
    root.append(h("div", { class: "grid cols-2" },
      card("Definition in force", kv([
        ["Policy", h("span", null, `${summary.policy.name} v${summary.policy.version} `, badge(summary.policy.status))],
        ["Prediction window", `${p.horizon_days} days after the as-of date`],
        ["Grace period", `${p.grace_period_days} days (a failed payment recovered within it is not churn)`],
        ["Voluntary churn", p.voluntary_reasons.map(words).join(", ")],
        ["Involuntary churn", p.involuntary_reasons.map(words).join(", ")],
        ["Not counted as churn", p.excluded_reasons.map(words).join(", ")],
        ["Trials", p.include_trials ? "included" : "excluded until they convert to paid"],
      ]), { actions: link("Policies", "#/policies") }),
      card("Churn rate by as-of date", rows.length ? lineChart({ series: [{ name: "30-day churn rate", color: "red", dots: true, points: rows.filter((r) => isNum(r.churn_rate)).map((r, i) => [i, r.churn_rate]) }],
        xFmt: (i) => (rows.filter((r) => isNum(r.churn_rate))[Math.round(i)] || {}).as_of_date?.slice(2, 7) || "", yFmt: pctTick, yDomain: [0, Math.max(0.1, ...rows.map((r) => r.churn_rate || 0)) * 1.15], label: "Churn rate by as-of date" }) : empty("No labels yet", "Generate labels to see churn by date."),
      { sub: "Share of eligible customers at T who churned within the window" })));
    root.append(h("div", { class: "stack" }, card("Labels per as-of date", dataTable([
      { label: "As-of date (T)", value: (r) => r.as_of_date }, { label: "Churned", align: "right", value: (r) => fmtInt(r.churned) },
      { label: "Voluntary", align: "right", value: (r) => fmtInt(r.voluntary) }, { label: "Involuntary", align: "right", value: (r) => fmtInt(r.involuntary) },
      { label: "Retained", align: "right", value: (r) => fmtInt(r.retained) }, { label: "Immature", align: "right", value: (r) => fmtInt(r.immature) },
      { label: "Not eligible", align: "right", value: (r) => fmtInt(r.ineligible) }, { label: "Churn rate", align: "right", value: (r) => fmtPct(r.churn_rate) },
    ], rows, { emptyText: "No labels have been generated.", caption: "Labels per as-of date" }), { flush: true, foot: "Not eligible = not a paying subscriber at T. Immature = the outcome window has not finished yet." }), labelBrowser(rows)));
  }
  await render();
  return root;
}
function labelBrowser(dates) {
  const date = h("select", { "aria-label": "As-of date" }, h("option", { value: "" }, "All dates"), dates.slice().reverse().map((d) => h("option", { value: d.as_of_date }, d.as_of_date)));
  const status = h("select", { "aria-label": "Status" }, h("option", { value: "churned" }, "churned"), ["retained", "immature", "ineligible"].map((s) => h("option", { value: s }, words(s))), h("option", { value: "" }, "all statuses"));
  const table = pagedTable({ pageSize: 12, load: (page, size) => api("/labels", { query: { page, page_size: size, as_of_date: date.value, status: status.value } }), caption: "Customer labels", columns: [
    { label: "Customer", value: (r) => h("span", null, r.customer_name || r.customer_external_id, h("span", { class: "sub" }, r.customer_external_id)) },
    { label: "As-of date", value: (r) => r.as_of_date }, { label: "Outcome", value: (r) => badge(r.status) },
    { label: "Type", value: (r) => words(r.churn_type) }, { label: "Reason", value: (r) => words(r.churn_reason) }, { label: "Churn date", value: (r) => fmtDate(r.churn_date) },
  ], onRow: (r) => go(`#/customers/${r.customer_id}`) });
  date.addEventListener("change", () => table.reload()); status.addEventListener("change", () => table.reload());
  return card("Browse labels", h("div", null, h("div", { class: "toolbar" }, date, status), table.el), { flush: true });
}

// ------------------------------------------------------------------ feature store
export async function features() {
  const root = h("div");
  async function render() {
    const [catalog, contracts, store] = await Promise.all([api("/features/catalog"), api("/features/contracts"), api("/features/store")]);
    const approved = contracts.items.find((c) => c.status === "approved");
    clear(root).append(pageHead("Feature store", "A 360° view of each customer as it was known at a point in time: account, billing, product usage and support. Every feature uses only records dated strictly before the as-of date.",
      [can("features:write") ? button("New contract", async () => {
        const made = await formDialog({ title: "New feature contract", description: "A contract freezes a named list of features. Models are trained and served against one approved contract.", submitLabel: "Create draft",
          fields: [{ name: "name", label: "Name", value: "churn_core", required: true }, { name: "exclude_snapshot", label: "Exclude snapshot-only attributes", type: "checkbox", hint: "leave out attributes whose history is not tracked (they are read as of load time)" }],
          onSubmit: (v) => api("/features/contracts", { method: "POST", body: v }) });
        if (made) { toast("Contract created; it needs approval before use", "success"); await render(); }
      }) : null,
      can("features:write") && approved ? button("Materialise features", async () => {
        const res = await formDialog({ title: "Materialise features", description: `Compute ${approved.name} v${approved.version} for each month-start as-of date in the range (empty = all dates covered by the data).`, submitLabel: "Start",
          fields: [{ name: "start", label: "From", type: "date" }, { name: "end", label: "To", type: "date" }, { name: "publish_online", label: "Publish the newest date to the online store", type: "checkbox", value: true }],
          onSubmit: (v) => api("/features/materializations", { method: "POST", body: { contract_id: approved.id, ...v } }) });
        if (res && res.job) { await trackJob(res.job, "Feature materialisation"); await render(); }
      }, "primary") : null]));
    const groups = {};
    for (const f of catalog.items) (groups[f.group] ||= []).push(f);
    root.append(h("div", { class: "grid kpis" }, kpi("Features", fmtInt(catalog.total), `${Object.keys(groups).length} groups`),
      kpi("Offline snapshots", fmtInt(store.offline.length), store.offline.length ? `${store.offline[0].as_of_date} → ${store.offline[store.offline.length - 1].as_of_date}` : "none yet"),
      kpi("Online store", store.online.length ? fmtInt(store.online[0].rows) : "–", store.online.length ? `customers as of ${store.online[0].as_of_date}` : "not published"),
      kpi("Logic version", shortHash(catalog.engine_hash), "hash of the feature code")));
    root.append(notice("info", h("strong", null, "Leakage guard. "), `Current-state columns (${catalog.forbidden_source_columns.join(", ")}) can never feed a feature: they describe the present, not what was known at the as-of date.`));
    root.append(h("div", { class: "stack" },
      card("Contracts", dataTable([
        { label: "Contract", value: (c) => `${c.name} v${c.version}` }, { label: "Features", align: "right", value: (c) => fmtInt(c.feature_count) },
        { label: "Schema hash", value: (c) => h("code", null, shortHash(c.schema_hash)) }, { label: "Status", value: (c) => badge(c.status) },
        { label: "Logic", value: (c) => (c.logic_current ? badge("ok", "matches current code") : badge("warning", "code changed since")) },
        { label: "", value: (c) => (can("features:approve") && c.status === "pending" ? h("div", { class: "actions" },
          button("Approve", async () => { await api(`/features/contracts/${c.id}/review`, { method: "POST", body: { approve: true } }); toast("Contract approved", "success"); await render(); }, "small primary"),
          button("Reject", async () => { await api(`/features/contracts/${c.id}/review`, { method: "POST", body: { approve: false } }); await render(); }, "small")) : null) },
      ], contracts.items, { emptyText: "Create a contract to freeze a feature list." }), { flush: true, sub: "The author of a contract cannot approve it" }),
      card("Feature catalogue", tabs(Object.keys(groups).sort().map((g) => ({ id: g, label: `${words(g)} (${groups[g].length})`, render: () => dataTable([
        { label: "Feature", value: (f) => h("span", null, f.label, h("span", { class: "sub mono" }, f.name)) }, { label: "Meaning", value: (f) => f.description },
        { label: "Window", align: "right", value: (f) => (f.window_days ? `${f.window_days} d` : "–") }, { label: "Sources", value: (f) => f.sources.map(words).join(", ") },
        { label: "Time rule", value: (f) => (f.pit_class === "snapshot" ? badge("warning", "snapshot") : badge("ok", "event time")) },
      ], groups[g], { caption: `Features in group ${g}` }) }))), { foot: "Snapshot = the source keeps no history, so the value is the one at load time; these can be excluded from a contract." })));
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ analytics
export async function analytics() {
  const root = h("div", null, pageHead("Analytics", "Descriptive views of observed history: how many customers leave, when in their lifetime, and which characteristics go with higher churn. These describe the past; they are not predictions.",
    [can("analytics:run") ? button("Refresh all", async () => {
      for (const kind of ["overview", "cohort", "survival", "profile"]) await startJob(`Analytics: ${kind}`, "/analytics/reports", { kind });
      window.dispatchEvent(new HashChangeEvent("hashchange"));
    }) : null]));
  root.append(tabs([
    { id: "overview", label: "Portfolio", render: analyticsOverview }, { id: "cohort", label: "Cohort retention", render: analyticsCohort },
    { id: "survival", label: "Survival curve", render: () => analyticsSurvival(null) }, { id: "profile", label: "Churn by characteristic", render: analyticsProfile },
  ]));
  return root;
}
function noReport(kind) { return card(null, empty("Not computed yet", `Use "Refresh all" to compute the ${kind} report.`)); }
async function analyticsOverview() {
  const data = await api("/analytics/reports/latest", { query: { kind: "overview" } });
  if (!data.report) return noReport("portfolio");
  const r = data.report.result; const months = r.monthly.filter((m) => m.complete && isNum(m.churn_rate));
  return h("div", { class: "stack" },
    h("div", { class: "grid kpis" }, kpi("Active customers", fmtInt(r.active_customers)), kpi("Active MRR", fmtMoney(r.active_mrr)), kpi("Churned", fmtInt(r.churned_periods ?? r.ended_periods), r.excluded_periods ? `all time; ${fmtInt(r.excluded_periods)} more ended for an excluded reason` : "paid periods ended, all time"),
      kpi("Voluntary", fmtInt(r.ended_by_kind.voluntary || 0), "cancelled or did not renew"), kpi("Involuntary", fmtInt(r.ended_by_kind.involuntary || 0), "payment failure")),
    h("div", { class: "grid cols-2" },
      card("Monthly churn rate", lineChart({ series: [{ name: "Churn rate", color: "red", dots: true, points: months.map((m, i) => [i, m.churn_rate]) }], xFmt: (i) => (months[Math.round(i)] || {}).month?.slice(2) || "",
        yFmt: pctTick, yDomain: [0, Math.max(0.08, ...months.map((m) => m.churn_rate)) * 1.2], label: "Monthly churn rate" }), { sub: r.definitions.churn_rate }),
      card("Why paid periods ended", dataTable([{ label: "Reason", value: (x) => words(x[0]) }, { label: "Count", value: (x) => bar(x[1] / Math.max(...Object.values(r.ended_by_reason)), "", fmtInt(x[1])) }], Object.entries(r.ended_by_reason)), { flush: true })),
    h("p", { class: "muted small" }, `${r.note} Churn definition: ${r.churn_definition}. Data cutoff ${fmtDateTime(r.data_cutoff)}.`));
}
async function analyticsCohort() {
  const data = await api("/analytics/reports/latest", { query: { kind: "cohort" } });
  if (!data.report) return noReport("cohort");
  const r = data.report.result;
  return card("Share of each signup cohort still subscribed", heatTable({ caption: "Cohort retention heatmap", periods: r.periods, fmt: (v) => fmtPct(v),
    rows: r.cohorts.map((c) => ({ label: c.cohort, size: c.size, cells: r.periods.map((p) => { const cell = c.cells.find((x) => x.period === p); return cell && cell.observable === c.size ? cell.rate : null; }) })) }),
  { sub: `Columns are ${r.period_days}-day periods since signup. A cell is shown only once the whole cohort has reached that age.`, foot: r.definitions.rate });
}
async function analyticsSurvival(segment) {
  const holder = h("div");
  async function render(seg) {
    const data = await api("/analytics/reports/latest", { query: { kind: "survival", segment: seg } });
    const select = h("select", { "aria-label": "Compare by" }, h("option", { value: "" }, "All customers"), data.segments.map((s) => h("option", { value: s, selected: s === seg || null }, `By ${words(s)}`)));
    select.addEventListener("change", async () => {
      const chosen = select.value || null;
      const existing = await api("/analytics/reports/latest", { query: { kind: "survival", segment: chosen } });
      if (!existing.report && can("analytics:run")) await startJob("Survival analysis", "/analytics/reports", { kind: "survival", segment: chosen });
      await render(chosen);
    });
    if (!data.report) { clear(holder).append(h("div", { class: "toolbar" }, select), noReport("survival")); return; }
    const r = data.report.result; const palette = ["accent", "blue", "amber", "violet", "red", "green", "grey"];
    clear(holder).append(card("Probability of still being subscribed, by days since first paid period", h("div", null,
      lineChart({ height: 320, xLabel: "Days since first paid period", yLabel: "Still subscribed", yDomain: [0, 1], yFmt: pctTick, label: "Kaplan-Meier survival curve",
        series: r.groups.map((g, i) => ({ name: `${words(g.group)} (n=${fmtInt(g.n)})`, color: palette[i % palette.length], step: true, points: g.curve.map((p) => [p.day, p.survival]),
          band: r.groups.length === 1 ? g.curve.map((p) => [p.day, p.lower, p.upper]) : null })) }),
      dataTable([{ label: "Group", value: (g) => words(g.group) }, { label: "Customers", align: "right", value: (g) => fmtInt(g.n) }, { label: "Churned", align: "right", value: (g) => fmtInt(g.events) },
        { label: "Still subscribed (censored)", align: "right", value: (g) => fmtInt(g.censored) }, { label: "At 90 days", align: "right", value: (g) => fmtPct(g.survival_at["90"]) },
        { label: "At 180 days", align: "right", value: (g) => fmtPct(g.survival_at["180"]) }, { label: "At 365 days", align: "right", value: (g) => fmtPct(g.survival_at["365"]) },
        { label: "Median lifetime", align: "right", value: (g) => (g.median_survival_days ? `${fmtInt(g.median_survival_days)} d` : "not reached") }], r.groups)),
    { actions: h("label", { class: "small muted" }, "Compare ", select), sub: "Kaplan-Meier estimate; the shaded band is the 95% confidence interval",
      foot: `${r.logrank ? `Log-rank test across groups: p = ${Number(r.logrank.p_value).toPrecision(2)}. ` : ""}${r.definitions.censored}` }));
  }
  await render(segment);
  return holder;
}
async function analyticsProfile() {
  const data = await api("/analytics/reports/latest", { query: { kind: "profile" } });
  if (!data.report) return noReport("profile");
  const r = data.report.result; const detail = h("div");
  const show = (f) => { clear(detail).append(card(f.label, barChart({ labels: f.bins.map((b) => String(b.bin).slice(0, 14)), series: [{ name: "Churn rate", color: "red", values: f.bins.map((b) => b.churn_rate) }], yFmt: pctTick, yLabel: "Churn rate", label: `Churn rate by ${f.label}`, maxLabels: 8 }),
    { sub: `Observed churn rate per value range · ${f.bins.map((b) => `${b.bin}: n=${fmtInt(b.n)}`).join(" · ")}` })); };
  const table = dataTable([{ label: "Characteristic", value: (f) => h("span", null, f.label, h("span", { class: "sub" }, words(f.group))) },
    { label: "Gap between highest and lowest churn rate", value: (f) => bar(f.spread / r.features[0].spread, "high", fmtPct(f.spread)) }], r.features.slice(0, 25), { onRow: show, caption: "Characteristics ranked by churn-rate spread" });
  show(r.features[0]);
  return h("div", { class: "stack" }, notice("info", `Based on ${fmtInt(r.rows)} labelled customer-months with an average churn rate of ${fmtPct(r.base_rate)}. A large gap shows association, not cause.`),
    h("div", { class: "grid cols-2" }, card("Ranked by spread", table, { flush: true, sub: "Select a row to see the breakdown" }), detail));
}

// ------------------------------------------------------------------ policies
const POLICY_INFO = {
  churn_definition: ["Churn definition", "What counts as churn, the prediction window and the payment grace period."],
  cost_matrix: ["Cost matrix", "Cost of an intervention and value of a retained customer; used to choose the decision threshold."],
  risk_policy: ["Risk tiers", "How scores become high / medium / low tiers and what counts as high value."],
  retention_playbook: ["Retention playbook", "Which action each segment gets and which actions need human review or marketing consent."],
  alert_rules: ["Alert rules", "Thresholds for drift, data quality and performance that raise alerts or call for retraining."],
  promotion_gates: ["Promotion gates", "What a model version must show on the sealed test period before it can be validated, approved and promoted."],
  activity_definition: ["Active-user definition", "Which usage events count as activity, the time zone of a day, and which identifiers are staff or tests."],
};
export async function policies() {
  const root = h("div");
  async function render() {
    const data = await api("/policies");
    clear(root).append(pageHead("Policies", "Business rules are versioned documents. A new version takes effect only after someone other than its author approves it."));
    for (const [kind, [title, text]] of Object.entries(POLICY_INFO)) {
      const versions = data.items.filter((p) => p.kind === kind).sort((a, b) => b.version - a.version);
      const active = versions.find((p) => p.status === "approved");
      root.append(h("div", { class: "stack" }, card(title, h("div", null,
        active ? h("div", null, active.payload.is_example ? notice("warn", h("strong", null, "Example figures. "), active.payload.evidence || "Not measured business values.") : null, jsonBlock(active.payload)) : empty("No approved version", "Create and approve a version to enable the features that depend on it."),
        versions.length ? dataTable([{ label: "Version", value: (p) => `${p.name} v${p.version}` }, { label: "Status", value: (p) => badge(p.status) }, { label: "Note", value: (p) => p.note || "–" },
          { label: "Created", value: (p) => fmtDateTime(p.created_at) },
          { label: "", value: (p) => h("div", { class: "actions" },
            can("policy:write") && p.status === "draft" ? button("Submit for approval", async () => { await api(`/policies/${p.id}/submit`, { method: "POST" }); toast("Submitted for approval", "success"); await render(); }, "small") : null,
            can("policy:approve") && p.status === "pending" ? button("Approve", async () => { await api(`/policies/${p.id}/review`, { method: "POST", body: { approve: true } }); toast("Policy approved and in force", "success"); await render(); }, "small primary") : null,
            can("policy:approve") && p.status === "pending" ? button("Reject", async () => { await api(`/policies/${p.id}/review`, { method: "POST", body: { approve: false } }); await render(); }, "small") : null,
            button("View", () => openDialog({ title: `${title} v${p.version}`, wide: true, body: h("div", null, jsonBlock(p.payload), closeFoot()) }), "small")) }], versions) : null),
      { sub: text, actions: can("policy:write") ? button("New version", async () => {
        const base = active ? active.payload : (await api(`/policies/defaults/${kind}`)).payload;
        const made = await formDialog({ title: `New ${title.toLowerCase()} version`, description: "Saved as a draft. Submit it, then ask an approver to review.", wide: true, submitLabel: "Save draft",
          fields: [{ name: "payload", label: "Rules (JSON)", type: "json", value: base }, { name: "note", label: "What changed and why" }],
          onSubmit: (v) => api("/policies", { method: "POST", body: { kind, name: active ? active.name : "default", payload: v.payload, note: v.note } }) });
        if (made) { toast("Draft saved", "success"); await render(); }
      }, "small") : null })));
    }
  }
  await render();
  return root;
}
