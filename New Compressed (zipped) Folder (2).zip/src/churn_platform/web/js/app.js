// Application shell: sign-in, navigation and hash routing.
import { api, state, saveToken, loadToken, can, h, clear, toast, errorNotice, words, ApiError } from "./core.js";
import * as dataViews from "./views_data.js";
import * as mlViews from "./views_ml.js";
import * as actViews from "./views_act.js";
import * as opsViews from "./views_ops.js";
import * as signalViews from "./views_signals.js";
import * as platformViews from "./views_platform.js";

const app = document.getElementById("app");

const NAV = [
  { group: null, items: [{ path: "overview", label: "Overview" }] },
  { group: "Data", items: [
    { path: "data", label: "Sources & imports", need: "data:read" }, { path: "quality", label: "Data quality", need: "quality:read" },
    { path: "labels", label: "Churn labels", need: "labels:read" }, { path: "features", label: "Feature store", need: "features:read" },
    { path: "analytics", label: "Analytics", need: "analytics:read" }] },
  { group: "Signals", items: [
    { path: "sentiment", label: "Support sentiment", need: "signals:read" }, { path: "adoption", label: "Feature adoption", need: "signals:read" },
    { path: "identity", label: "Active users & identity", need: "signals:read" }, { path: "attributes", label: "Attribute history", need: "signals:read" }] },
  { group: "Models", items: [
    { path: "models", label: "Training", need: "ml:read" }, { path: "registry", label: "Registry", need: "ml:read" }, { path: "predictions", label: "Predictions", need: "predict:read" }] },
  { group: "Retention", items: [
    { path: "customers", label: "Customers", need: "customers:read" }, { path: "retention", label: "Recommendations", need: "retention:read" },
    { path: "experiments", label: "Experiments & uplift", need: "retention:read" }, { path: "campaigns", label: "Campaigns", need: "notify:read" },
    { path: "messages", label: "Messages", need: "notify:read" }, { path: "crm", label: "CRM sync", need: "crm:read" }, { path: "syncs", label: "Syncs & exports", need: "crm:read" }, { path: "exports", label: "Destination exports", need: "customers:read" }] },
  { group: "Operations", items: [
    { path: "monitoring", label: "Monitoring", need: "mlops:read" }, { path: "jobs", label: "Jobs & pipeline", need: "jobs:read" },
    { path: "orchestration", label: "Orchestration", need: "jobs:read" }, { path: "policies", label: "Policies" }, { path: "security", label: "Security", need: "admin:security" },
    { path: "admin", label: "Administration", anyOf: ["admin:users", "admin:audit", "admin:sessions"] }] },
];

const ROUTES = [
  [/^overview$/, () => dataViews.overview()], [/^data$/, () => dataViews.dataSources()], [/^quality$/, () => dataViews.quality()], [/^labels$/, () => dataViews.labels()],
  [/^features$/, () => dataViews.features()], [/^analytics$/, () => dataViews.analytics()], [/^policies$/, () => dataViews.policies()],
  [/^models$/, () => mlViews.models()], [/^models\/run\/(\d+)$/, (m) => mlViews.runDetail(m[1])], [/^registry$/, () => mlViews.registry()],
  [/^predictions$/, () => mlViews.predictions()], [/^predictions\/(\d+)$/, (m) => mlViews.batchDetail(m[1])],
  [/^customers$/, () => actViews.customers()], [/^customers\/(\d+)$/, (m) => actViews.customer360(m[1])], [/^retention$/, () => actViews.retention()],
  [/^experiments$/, () => actViews.experiments()], [/^experiments\/(\d+)$/, (m) => actViews.experimentDetail(m[1])], [/^crm$/, () => actViews.crm()],
  [/^sentiment$/, () => signalViews.sentiment()], [/^adoption$/, () => signalViews.adoption()], [/^identity$/, () => signalViews.identity()],
  [/^attributes$/, () => signalViews.attributeHistory()],
  [/^campaigns$/, () => platformViews.campaigns()], [/^messages$/, () => platformViews.notifications()], [/^syncs$/, () => platformViews.syncs()], [/^exports$/, () => platformViews.exports()],
  [/^orchestration$/, () => platformViews.orchestration()], [/^security$/, () => platformViews.security()],
  [/^monitoring$/, () => opsViews.monitoring()], [/^jobs$/, () => opsViews.jobs()], [/^admin$/, () => opsViews.admin()], [/^account$/, () => opsViews.account()],
];

const allowed = (item) => (item.need ? can(item.need) : item.anyOf ? item.anyOf.some(can) : true);
const currentPath = () => (window.location.hash.replace(/^#\/?/, "") || "overview").split("?")[0];
const logo = () => {
  const NS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(NS, "svg"); svg.setAttribute("viewBox", "0 0 32 32"); svg.setAttribute("aria-hidden", "true");
  const rect = document.createElementNS(NS, "rect"); for (const [k, v] of Object.entries({ width: 32, height: 32, rx: 7, fill: "#1d2939" })) rect.setAttribute(k, v);
  const path = document.createElementNS(NS, "path"); for (const [k, v] of Object.entries({ d: "M6 22l6-7 5 4 9-11", fill: "none", stroke: "#3ccfb0", "stroke-width": 3, "stroke-linecap": "round", "stroke-linejoin": "round" })) path.setAttribute(k, v);
  svg.append(rect, path); return svg;
};

// ------------------------------------------------------------------ sign-in
function renderLogin(message) {
  document.title = "Sign in · Churn Platform";
  const error = h("p", { class: "form-error hidden", role: "alert" });
  if (message) { error.textContent = message; error.classList.remove("hidden"); }
  const email = h("input", { type: "email", id: "login-email", name: "email", autocomplete: "username", required: true });
  const password = h("input", { type: "password", id: "login-password", name: "password", autocomplete: "current-password", required: true });
  const otp = h("input", { type: "text", id: "login-otp", name: "otp", inputmode: "numeric", autocomplete: "one-time-code", placeholder: "only if two-factor is on" });
  const submit = h("button", { type: "submit", class: "btn primary" }, "Sign in");
  // single sign-on: the organisation's name tells which identity providers to offer
  const org = h("input", { type: "text", id: "login-org", name: "organisation", autocomplete: "organization", placeholder: "your organisation's short name" });
  const ssoList = h("div", { class: "sso-list" });
  const ssoButton = h("button", { type: "button", class: "btn" }, "Continue");
  ssoButton.addEventListener("click", async () => {
    clear(ssoList);
    if (!org.value.trim()) { org.focus(); return; }
    try {
      const found = await api("/auth/oidc/providers", { query: { tenant: org.value.trim() } });
      if (!found.items.length) ssoList.append(h("p", { class: "muted small" }, "No single sign-on is set up for this organisation. Use email and password."));
      for (const p of found.items) ssoList.append(h("a", { class: "btn", href: new URL(`api/v1/auth/oidc/${p.id}/start`, document.baseURI).href }, `Sign in with ${p.name}`));
    } catch (err) { ssoList.append(h("p", { class: "form-error", role: "alert" }, err.message || "Single sign-on is not available right now.")); }
  });
  const sso = h("details", { class: "sso" }, h("summary", null, "Use single sign-on"),
    h("label", { class: "field", for: "login-org" }, "Organisation", org), ssoButton, ssoList);
  const form = h("form", null, h("h2", null, "Sign in"), h("p", { class: "muted" }, "Use your work email and password."), error,
    h("label", { class: "field", for: "login-email" }, "Email", email), h("label", { class: "field", for: "login-password" }, "Password", password),
    h("label", { class: "field", for: "login-otp" }, "Authenticator code", otp), submit, sso);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const show = (text) => { error.textContent = text; error.classList.remove("hidden"); };
    error.classList.add("hidden");
    submit.disabled = true;
    try {
      const res = await api("/auth/login", { method: "POST", body: { email: email.value.trim(), password: password.value, otp: otp.value.trim() || null } });
      saveToken(res.token);
      await start();
    } catch (err) {
      if (err instanceof ApiError && err.code === "mfa_required") {
        // the password was accepted: keep it and ask for the second factor only
        show("Enter the 6-digit code from your authenticator app."); otp.focus();
      } else {
        show(err instanceof ApiError && err.status === 429 ? "Too many attempts. Wait a minute and try again." : (err.message || "Sign-in failed"));
        password.value = ""; otp.value = ""; password.focus();
      }
    } finally { submit.disabled = false; }
  });
  clear(app).append(h("div", { class: "login" },
    h("div", { class: "login-art" }, h("div", null, h("div", { class: "brand" }, logo(), h("span", null, "Churn Platform")),
      h("h1", null, "See who is about to leave, why, and what to do about it."),
      h("p", null, "Churn prediction and retention for subscription businesses: one governed path from raw billing, usage and support data to actions in your CRM."),
      h("ul", null, h("li", null, "Point-in-time features: nothing from the future leaks into a score"), h("li", null, "Every score comes with its three main reasons"),
        h("li", null, "Models, policies and experiments need a second person's approval"), h("li", null, "Drift and realised accuracy are monitored after deployment"))),
      h("p", { class: "small" }, "Scores rank risk. Whether an action changes the outcome is measured with experiments.")),
    h("div", { class: "login-form" }, form)));
  email.focus();
}

// ------------------------------------------------------------------ shell
let shellNodes = null;
function renderShell() {
  const me = state.me; const info = state.info || {};
  const nav = h("nav", { class: "nav", id: "main-nav", "aria-label": "Main" });
  for (const section of NAV) {
    const items = section.items.filter(allowed);
    if (!items.length) continue;
    if (section.group) nav.append(h("div", { class: "nav-group" }, section.group));
    for (const item of items) nav.append(h("a", { href: `#/${item.path}`, dataset: { path: item.path } }, item.label));
  }
  const content = h("main", { class: "content", id: "content", tabindex: "-1" });
  const jobsPill = h("a", { class: "jobs-pill hidden", href: "#/jobs", title: "Background jobs in progress" }, h("span", { class: "dot" }), h("span", { class: "txt" }, ""));
  const initials = (me.full_name || me.email).split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  // narrow screens: the navigation is a drawer opened with the Menu button and closed by choosing a screen, by Escape or by a tap on the backdrop
  const setNav = (open) => { shell.classList.toggle("nav-open", open); menuToggle.setAttribute("aria-expanded", String(open)); };
  const menuToggle = h("button", { type: "button", class: "btn small menu-toggle", "aria-label": "Navigation", "aria-expanded": "false", "aria-controls": "main-nav",
    onclick: (event) => { event.stopPropagation(); setNav(!shell.classList.contains("nav-open")); } }, "Menu");
  const shell = h("div", { class: "shell" },
    h("aside", { class: "sidebar" }, h("div", { class: "brand" }, logo(), h("span", null, "Churn Platform", h("small", null, info.tenant ? info.tenant.name : ""))), nav,
      h("div", { class: "sidebar-foot" }, `v${info.version || ""} · ${words(info.environment || "")}`)),
    h("div", { class: "main" },
      h("div", { class: "topbar" },
        menuToggle,
        h("span", { class: "tenant" }, info.tenant ? info.tenant.name : ""), h("span", { class: "spacer" }), jobsPill,
        h("div", { class: "user-chip" }, h("a", { class: "avatar", href: "#/account", "aria-label": "My account", title: "My account" }, initials), h("a", { class: "who", href: "#/account" }, me.full_name || me.email, h("span", { class: "muted small" }, ` · ${words(me.role)}`)),
          h("button", { type: "button", class: "btn small", onclick: signOut }, "Sign out"))),
      state.synthetic ? h("div", { class: "synthetic-banner", role: "note" }, h("strong", null, "Synthetic demonstration data. "), "Every customer, payment and outcome in this tenant was generated by a simulator. Figures illustrate how the platform works; they are not evidence of real-world accuracy or return.") : null,
      content));
  nav.addEventListener("click", () => setNav(false));
  shell.append(h("div", { class: "nav-backdrop", onclick: () => setNav(false) }));
  shell.addEventListener("keydown", (event) => { if (event.key === "Escape" && shell.classList.contains("nav-open")) { setNav(false); menuToggle.focus(); } });
  clear(app).append(shell);
  shellNodes = { nav, content, jobsPill };
}

let renderToken = 0;
async function route() {
  if (!state.me) return;
  if (!shellNodes) renderShell();
  const path = currentPath();
  const token = ++renderToken;
  for (const a of shellNodes.nav.querySelectorAll("a")) {
    if (a.dataset.path === path.split("/")[0]) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  }
  const content = shellNodes.content;
  clear(content).append(h("div", { class: "loading" }, "Loading…"));
  let node;
  try {
    const match = ROUTES.map(([re, fn]) => [path.match(re), fn]).find(([m]) => m);
    node = match ? await match[1](match[0]) : h("div", null, h("h1", null, "Page not found"), h("p", { class: "muted" }, "That address does not exist. "), h("a", { href: "#/overview" }, "Back to the overview"));
  } catch (err) {
    if (err instanceof ApiError && err.status === 401) return;
    node = h("div", null, h("h1", null, "This page could not be shown"), errorNotice(err));
  }
  if (token !== renderToken) return;
  clear(content).append(node);
  const title = content.querySelector("h1");
  document.title = `${title ? title.textContent : "Churn Platform"} · Churn Platform`;
  window.scrollTo(0, 0);
}

async function pollJobs() {
  if (!state.me || !shellNodes || !can("jobs:read") || document.hidden) return;
  try {
    const active = await api("/jobs/active");
    const n = active.items.length;
    shellNodes.jobsPill.classList.toggle("hidden", n === 0);
    shellNodes.jobsPill.querySelector(".txt").textContent = `${n} job${n === 1 ? "" : "s"} running`;
  } catch { /* shown elsewhere */ }
}

async function signOut() {
  try { await api("/auth/logout", { method: "POST" }); } catch { /* the session may already be gone */ }
  saveToken(null); state.me = null; shellNodes = null;
  // whoever signs in next starts at the overview, not on the screen the previous user left
  if (currentPath() !== "overview") window.location.hash = "#/overview";
  renderLogin();
}

// Back from the identity provider: trade the one-time code for the session, or show why the sign-in was refused.
async function finishSingleSignOn() {
  const match = window.location.hash.match(/^#\/sso\?(.*)$/);
  if (!match) return false;
  const params = new URLSearchParams(match[1]);
  window.history.replaceState(null, "", window.location.pathname);
  if (params.get("error")) { renderLogin(params.get("message") || "Single sign-on did not complete."); return true; }
  try {
    const res = await api("/auth/oidc/exchange", { method: "POST", body: { code: params.get("code") || "" } });
    saveToken(res.token);
  } catch (err) { renderLogin(err.message || "Single sign-on did not complete."); return true; }
  return false;
}

async function start() {
  if (await finishSingleSignOn()) return;
  if (!loadToken()) { renderLogin(); return; }
  try {
    const [me, info] = await Promise.all([api("/auth/me"), api("/system/info")]);
    state.me = me; state.info = info;
    state.rotateAt = me.session && me.session.rotate_after ? Date.parse(me.session.rotate_after) : null;
    state.synthetic = Boolean(info.synthetic_data);
  } catch (err) {
    if (!(err instanceof ApiError && err.status === 401)) renderLogin("The application could not start. " + (err.message || ""));
    return;
  }
  shellNodes = null;
  renderShell();
  if (state.me.mfa_enrollment_required) toast("Your role requires two-factor sign-in. Set it up under My account.");
  await route();
}

window.addEventListener("hashchange", route);
window.addEventListener("auth:expired", () => { if (state.me) { state.me = null; shellNodes = null; renderLogin("Your session has ended. Sign in again."); } else if (!document.querySelector(".login")) renderLogin(); });
window.addEventListener("unhandledrejection", (event) => { if (!(event.reason instanceof ApiError && event.reason.status === 401)) toast(event.reason && event.reason.message ? event.reason.message : "Something went wrong", "error"); });
setInterval(pollJobs, 5000);
start();
