// Screens: monitoring, jobs & pipeline, administration, my account.
import { api, can, h, card, kpi, kv, notice, badge, pageHead, button, dataTable, pagedTable, tabs, empty, jsonBlock, bar, link, words,
  fmtInt, fmtNum, fmtPct, fmtProb, fmtDateTime, fmtDuration, shortHash, formDialog, openDialog, startJob, trackJob, toast, clear, isNum, state, jobError } from "./core.js";
import { safe } from "./views_data.js";

const closeFoot = () => h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"));
const f3 = (v) => fmtNum(v, 3);

// ------------------------------------------------------------------ monitoring
export async function monitoring() {
  const root = h("div");
  async function render() {
    const [latest, alerts] = await Promise.all([api("/monitoring/latest"), safe(api("/alerts"))]);
    const reports = latest.reports || {}; const model = latest.production_model;
    clear(root).append(pageHead("Monitoring", "Customer behaviour changes, so a model's inputs and accuracy drift. This compares today's inputs and scores with the training period and, once outcomes are known, measures how well past predictions held up.", [
      can("mlops:write") ? button("Run monitoring now", () => startJob("Monitoring", "/monitoring/runs", {}, render), "primary") : null]));
    if (!model) { root.append(notice("info", h("strong", null, "No production model. "), "Monitoring starts once a model version is approved and promoted.")); return; }
    root.append(h("div", { class: "grid kpis" },
      kpi("Production model", `${model.name} v${model.version}`, `threshold ${fmtProb(model.threshold)}`),
      kpi("Input drift", reports.feature ? badge(reports.feature.status) : "–", !reports.feature ? "not measured" : unmeasured(reports.feature) ? "too few rows to compare" : `${fmtInt(reports.feature.result.drifted_features)} of ${fmtInt(reports.feature.result.features.length)} features moved`),
      kpi("Score drift", reports.prediction ? badge(reports.prediction.status) : "–", !reports.prediction ? "not measured" : unmeasured(reports.prediction) ? "too few scores to compare" : `PSI ${f3(reports.prediction.result.psi)}`),
      kpi("Realised performance", reports.concept ? badge(reports.concept.status) : "–", reports.concept && reports.concept.result.latest && isNum(reports.concept.result.latest.pr_auc) ? `PR-AUC ${f3(reports.concept.result.latest.pr_auc)} vs ${f3(reports.concept.result.reference_pr_auc)} at approval` : "no matured outcomes yet")));
    const openAlerts = alerts ? alerts.items.filter((a) => a.status !== "resolved") : [];
    root.append(card("Alerts", dataTable([
      { label: "Raised", value: (a) => fmtDateTime(a.created_at) }, { label: "Severity", value: (a) => badge(a.severity === "critical" ? "critical" : "warning", a.severity) },
      { label: "Alert", value: (a) => h("span", null, a.title, a.message ? h("span", { class: "sub" }, a.message) : null) }, { label: "Status", value: (a) => badge(a.status) },
      { label: "", value: (a) => (can("mlops:write") ? h("div", { class: "actions" },
        a.status === "open" ? button("Acknowledge", async () => { await api(`/alerts/${a.id}/acknowledge`, { method: "POST", body: {} }); await render(); }, "small") : null,
        button("Resolve", async () => { await api(`/alerts/${a.id}/acknowledge`, { method: "POST", body: { resolve: true } }); await render(); }, "small")) : null) },
    ], openAlerts, { empty: empty("No open alerts", "Alerts are raised by the approved alert rules (drift share, score shift, PR-AUC drop, data-quality score). A breached performance rule also starts automatic retraining."), caption: "Alerts" }),
    { flush: true, actions: link("Alert rules", "#/policies") }));
    const defs = [];
    if (reports.concept) defs.push({ id: "concept", label: "Realised performance", render: () => conceptTab(reports.concept) });
    if (reports.feature) defs.push({ id: "feature", label: "Input drift", render: () => featureTab(reports.feature) });
    if (reports.prediction) defs.push({ id: "prediction", label: "Score drift", render: () => predictionTab(reports.prediction) });
    defs.push({ id: "history", label: "History", render: historyTab });
    root.append(h("div", { class: "stack" }, tabs(defs)));
  }
  await render();
  return root;
}
// A report whose comparison could not be made: the latest batch is too small, or the model has not scored a batch yet.
const unmeasured = (report) => report.result.status === "insufficient_data";
function unmeasuredNotice(report, what) {
  const r = report.result; const rows = r.rows || {}; const batch = report.current;
  return notice("info", h("strong", null, "Not enough data to compare. "),
    batch ? `The latest batch (scored for ${batch.as_of_date}) gives ${fmtInt(rows.current || 0)} customers to compare with ${fmtInt(rows.reference || 0)} reference rows. ` : "This model version has not scored a batch yet. ",
    `${what} could not be measured: ${r.reason || "too few rows"}.`);
}
function conceptTab(report) {
  const r = report.result; const legend = r.sample_legend || {};
  return h("div", { class: "stack" },
    notice("info", h("strong", null, "How to read this. "), "A prediction can only be checked once its 30-day window has passed. Only dates scored after the model's own data window are new evidence; earlier dates are shown for completeness and never trigger alerts."),
    card("Past predictions against what happened", dataTable([
      { label: "Scored for", cls: "nowrap", value: (b) => b.as_of_date }, { label: "Evidence type", value: (b) => (b.sample ? h("span", null, words(b.sample), h("span", { class: "sub" }, legend[b.sample] || "")) : "–") },
      { label: "Outcomes known", align: "right", value: (b) => fmtInt(b.labelled) }, { label: "Churners", align: "right", value: (b) => fmtInt(b.positives) },
      { label: "PR-AUC", align: "right", value: (b) => f3(b.pr_auc) }, { label: "ROC-AUC", align: "right", value: (b) => f3(b.roc_auc) },
      { label: "Change vs approval", align: "right", value: (b) => (isNum(b.pr_auc_drop) ? `${b.pr_auc_drop > 0 ? "−" : "+"}${f3(Math.abs(b.pr_auc_drop))}` : "–") },
      { label: "Status", value: (b) => h("span", null, badge(b.status), b.reason ? h("span", { class: "sub" }, b.reason) : null) },
    ], r.batches, { caption: "Realised performance per scoring date", emptyText: "This model version has not scored a batch yet." }), { flush: true, sub: `PR-AUC at approval (sealed test period): ${f3(r.reference_pr_auc)}`, foot: "When PR-AUC on new dates breaches the approved alert rule, new candidate models are trained automatically on the latest outcomes. A candidate replaces this model only after it has been evaluated and approved by a second person." }));
}
function featureTab(report) {
  if (unmeasured(report)) return unmeasuredNotice(report, "Input drift");
  const r = report.result; const rows = r.features.slice().sort((a, b) => (b.psi || 0) - (a.psi || 0));
  const source = report.current.feature_source ? `; feature values: ${report.current.feature_source}` : "";
  return h("div", { class: "stack" },
    notice("info", h("strong", null, "Expected drift. "), "Measures of age (tenure, subscription age, lifetime spend) rise as a customer base matures, so they drift by construction against an older training period. Look for drift in behaviour: usage, support and billing."),
    card("Features compared with the training period", dataTable([
      { label: "Feature", value: (f) => h("span", null, f.label, h("span", { class: "sub" }, words(f.group))) },
      { label: "Population stability index", value: (f) => bar(Math.min(1, (f.psi || 0) / 0.5), f.status === "alert" ? "high" : f.status === "warning" ? "medium" : "low", f3(f.psi)) },
      { label: "Mean in training", align: "right", value: (f) => fmtNum(f.mean_reference, 2) }, { label: "Mean now", align: "right", value: (f) => fmtNum(f.mean_current, 2) },
      { label: "Missing now", align: "right", value: (f) => fmtPct(f.missing_current) }, { label: "Test", value: (f) => (f.test ? `${f.test}, p ${Number(f.p_value) < 0.001 ? "< 0.001" : f3(f.p_value)}` : "–") }, { label: "Status", value: (f) => badge(f.status) },
    ], rows, { caption: "Feature drift" }), { flush: true, sub: `${fmtInt(r.rows.reference)} training rows vs ${fmtInt(r.rows.current)} customers in the latest batch (${report.current.as_of_date})${source}`,
      foot: `PSI ≥ ${r.thresholds.psi_warning} is flagged as warning and ≥ ${r.thresholds.psi_alert} as alert (${r.thresholds.basis}).` }));
}
function predictionTab(report) {
  if (unmeasured(report)) return unmeasuredNotice(report, "Score drift");
  const r = report.result;
  return card("Distribution of scores", kv([["Status", badge(r.status)], ["Population stability index", f3(r.psi)], ["Mean score in the reference", fmtProb(r.mean_reference)], ["Mean score now", fmtProb(r.mean_current)],
    ["Reference", `${r.reference} (${fmtInt(r.rows.reference)} rows)`], ["Current", `${fmtInt(r.rows.current)} customers scored for ${report.current.as_of_date}`]]),
  { foot: "A shift in the score distribution with stable inputs can mean the customer mix changed; with drifting inputs it usually follows from them." });
}
function historyTab() {
  const table = pagedTable({ pageSize: 15, load: (page, size) => api("/monitoring/reports", { query: { page, page_size: size } }), caption: "Monitoring reports", columns: [
    { label: "Report", value: (r) => `#${r.id}` }, { label: "Kind", value: (r) => words(r.kind) }, { label: "Status", value: (r) => badge(r.status) }, { label: "Engine", value: (r) => r.engine },
    { label: "Scoring date", value: (r) => (r.current || {}).as_of_date || "–" }, { label: "Created", value: (r) => fmtDateTime(r.created_at) },
  ], onRow: (r) => openDialog({ title: `${words(r.kind)} report #${r.id}`, wide: true, body: h("div", null, jsonBlock({ reference: r.reference, current: r.current, result: r.kind === "feature" ? { ...r.result, features: `${(r.result.features || []).length} features` } : r.result }), closeFoot()) }) });
  return card(null, table.el, { flush: true });
}

// ------------------------------------------------------------------ jobs & pipeline
const STEP_LABEL = { data_quality: "Data quality checks", signals: "Refresh customer signals", labels: "Refresh labels", features: "Compute features", scoring: "Score customers", recommendations: "Recommend actions", monitoring: "Monitor drift" };
export async function jobs() {
  const root = h("div");
  async function render() {
    const pipe = can("mlops:read") ? await safe(api("/pipeline")) : null;
    clear(root).append(pageHead("Jobs & pipeline", "Long-running work (imports, training, scoring) runs in a background worker. The nightly pipeline chains the daily steps and stops at the first failure.", [
      pipe && can("mlops:write") ? button("Change schedule", async () => {
        const s = pipe.schedule;
        const ok = await formDialog({ title: "Nightly schedule", submitLabel: "Save", fields: [{ name: "hour_utc", label: "Hour of day (UTC, 0–23)", type: "number", value: s ? new Date(s.next_run_at).getUTCHours() : 2, min: 0, max: 23 }, { name: "enabled", label: "Run automatically every night", type: "checkbox", value: s ? s.enabled : true }],
          onSubmit: (v) => api("/pipeline/schedule", { method: "PUT", body: v }) });
        if (ok) { toast("Schedule saved", "success"); await render(); }
      }) : null,
      pipe && can("mlops:write") ? button("Run pipeline now", async () => { const res = await api("/pipeline/runs", { method: "POST" }); await pipelineProgress(res.job); await render(); }, "primary") : null]));
    if (pipe) {
      const last = pipe.runs[0]; const steps = last && last.result && last.result.steps ? Object.fromEntries(last.result.steps.map((s) => [s.step, s])) : {};
      const partial = last && last.payload && last.payload.log ? Object.fromEntries(last.payload.log.map((s) => [s.step, s])) : {};
      root.append(card("Nightly pipeline", h("div", null, h("ol", { class: "steps" }, pipe.steps.map((name) => {
        const st = steps[name] || partial[name];
        return h("li", { class: st ? (st.status === "failed" ? "fail" : "done") : null }, STEP_LABEL[name] || words(name), h("span", { class: "sub" }, st ? (st.status === "skipped" ? "skipped: already up to date" : words(st.status)) : "not run"));
      })), last && last.status === "failed" ? notice("danger", h("strong", null, "Last run failed. "), jobError(last)) : null),
      { sub: pipe.schedule ? `${pipe.schedule.enabled ? "Scheduled" : "Schedule paused"} · next run ${fmtDateTime(pipe.schedule.next_run_at)}` : "No schedule",
        foot: last ? `Last run: job #${last.id}, ${words(last.status)}, finished ${fmtDateTime(last.finished_at)}` : "The pipeline has not run yet." }));
    }
    const status = h("select", { "aria-label": "Status" }, h("option", { value: "" }, "All statuses"), ["queued", "running", "succeeded", "failed", "cancelled"].map((s) => h("option", { value: s }, s)));
    const table = pagedTable({ pageSize: 20, load: (page, size) => api("/jobs", { query: { page, page_size: size, status: status.value } }), caption: "Jobs", columns: [
      { label: "Job", value: (j) => `#${j.id}` }, { label: "Type", value: (j) => h("code", null, j.job_type) }, { label: "Status", value: (j) => badge(j.status) },
      { label: "Progress", value: (j) => (j.status === "running" ? bar(j.progress || 0, "", fmtPct(j.progress || 0, 0))
        : j.status === "queued" && j.run_after && new Date(j.run_after).getTime() - Date.now() > 60000 ? `waits until ${fmtDateTime(j.run_after)}` : j.progress_message || "–") }, { label: "Attempts", align: "right", value: (j) => `${j.attempts}/${j.max_attempts}` },
      { label: "Created", value: (j) => fmtDateTime(j.created_at) }, { label: "Took", align: "right", value: (j) => fmtDuration(j.started_at, j.finished_at) },
      { label: "", value: (j) => (can("jobs:manage") ? h("div", { class: "actions" },
        j.status === "queued" || j.status === "running" ? button("Cancel", async () => { await api(`/jobs/${j.id}/cancel`, { method: "POST" }); table.reload(false); }, "small danger") : null,
        j.status === "failed" || j.status === "cancelled" ? button("Retry", async () => { const r = await api(`/jobs/${j.id}/retry`, { method: "POST" }); await trackJob(r.job || r, `Job #${j.id}`); table.reload(false); }, "small") : null) : null) },
    ], onRow: (j) => openDialog({ title: `Job #${j.id} · ${j.job_type}`, wide: true, body: h("div", { class: "stack" }, j.error ? notice("danger", jobError(j)) : null, h("h3", null, "Input"), jsonBlock(j.payload), h("h3", null, "Result"), jsonBlock(j.result), j.error ? h("details", null, h("summary", null, "Technical detail"), h("pre", { class: "json" }, j.error)) : null, closeFoot()) }) });
    status.addEventListener("change", () => table.reload());
    root.append(h("div", { class: "stack" }, card("Background jobs", h("div", null, h("div", { class: "toolbar" }, status, button("Refresh", () => table.reload(false), "small")), table.el), { flush: true, foot: "Failed jobs are retried with back-off up to the attempt limit; a job is never run twice at once." })));
  }
  await render();
  return root;
}
async function pipelineProgress(job) {
  if (!job) return;
  const el = toast("Nightly pipeline started…");
  for (let i = 0; i < 600; i += 1) {
    await new Promise((r) => setTimeout(r, 1200));
    const pipe = await safe(api("/pipeline"));
    const run = pipe && pipe.runs.find((r) => r.id >= job.id && (r.status === "succeeded" || r.status === "failed") && r.result && (r.result.state === "completed" || r.status === "failed"));
    if (run) { el.remove(); toast(run.status === "succeeded" ? "Nightly pipeline finished" : `Nightly pipeline failed: ${jobError(run)}`, run.status === "succeeded" ? "success" : "error"); return; }
  }
  el.remove();
}

// ------------------------------------------------------------------ admin
export async function admin() {
  const defs = [];
  if (can("admin:users")) defs.push({ id: "users", label: "Users", render: usersTab });
  defs.push({ id: "roles", label: "Roles & permissions", render: rolesTab });
  if (can("admin:sessions")) defs.push({ id: "sessions", label: "Sessions", render: sessionsTab });
  if (can("admin:audit")) defs.push({ id: "audit", label: "Audit log", render: auditTab });
  defs.push({ id: "system", label: "System", render: systemTab });
  return h("div", null, pageHead("Administration", "Users, roles, sign-in sessions and the tamper-evident audit log."), tabs(defs));
}
async function usersTab() {
  const holder = h("div");
  async function render() {
    const [users, roles] = await Promise.all([api("/admin/users"), api("/admin/roles")]);
    const roleNames = roles.roles.map((r) => r.role);
    clear(holder).append(card("Users", dataTable([
      { label: "User", value: (u) => h("span", null, u.full_name, h("span", { class: "sub" }, u.email)) }, { label: "Role", value: (u) => words(u.role) },
      { label: "Status", value: (u) => (u.is_active ? (u.locked_until && new Date(u.locked_until) > new Date() ? badge("locked") : badge("active")) : badge("disabled")) },
      { label: "Two-factor", value: (u) => (u.mfa_enabled ? badge("ok", "on") : h("span", { class: "muted" }, "off")) }, { label: "Last sign-in", value: (u) => fmtDateTime(u.last_login_at) },
      { label: "", value: (u) => button("Edit", async () => {
        const ok = await formDialog({ title: `Edit ${u.email}`, submitLabel: "Save", fields: [{ name: "role", label: "Role", type: "select", options: roleNames, value: u.role }, { name: "is_active", label: "Account is active", type: "checkbox", value: u.is_active },
          { name: "password", label: "Set a new password", type: "password", hint: "leave empty to keep the current one; setting it signs the user out everywhere" }],
          onSubmit: (v) => api(`/admin/users/${u.id}`, { method: "PATCH", body: { role: v.role, is_active: v.is_active, ...(v.password ? { password: v.password } : {}) } }) });
        if (ok) { toast("User updated", "success"); await render(); }
      }, "small") },
    ], users.items, { caption: "Users" }), { flush: true, actions: button("New user", async () => {
      const ok = await formDialog({ title: "New user", submitLabel: "Create user", fields: [{ name: "full_name", label: "Full name", required: true }, { name: "email", label: "Email", type: "email", required: true },
        { name: "role", label: "Role", type: "select", options: roleNames, value: "viewer" }, { name: "password", label: "Initial password", type: "password", required: true, hint: "at least 12 characters with letters and digits" }],
        onSubmit: (v) => api("/admin/users", { method: "POST", body: v }) });
      if (ok) { toast("User created", "success"); await render(); }
    }, "primary") }));
  }
  await render();
  return holder;
}
async function rolesTab() {
  const roles = (await api("/admin/roles")).roles;
  const all = [...new Set(roles.flatMap((r) => r.permissions))].sort();
  const areas = [...new Set(all.map((p) => p.split(":")[0]))];
  return card("What each role may do", dataTable([{ label: "Area", value: (a) => words(a) }, ...roles.map((r) => ({ label: words(r.role), value: (a) => {
    const verbs = r.permissions.filter((p) => p.startsWith(`${a}:`)).map((p) => p.split(":")[1]);
    return verbs.length ? verbs.join(", ") : h("span", { class: "muted" }, "–");
  } }))], areas, { caption: "Role permissions" }), { flush: true, foot: `Approvals follow the four-eyes principle: the person who created a policy, feature contract, model version or experiment cannot approve it${state.info && state.info.self_approval_allowed ? " (self-approval is currently ENABLED for this environment)" : ""}.` });
}
async function sessionsTab() {
  const holder = h("div");
  async function render() {
    const [sessions, users] = await Promise.all([api("/admin/sessions"), can("admin:users") ? safe(api("/admin/users")) : null]);
    const names = new Map(users ? users.items.map((u) => [u.id, u.email]) : []);
    clear(holder).append(card("Sign-in sessions", dataTable([
      { label: "User", value: (s) => names.get(s.user_id) || `user #${s.user_id}` }, { label: "Signed in", value: (s) => fmtDateTime(s.created_at) }, { label: "Last seen", value: (s) => fmtDateTime(s.last_seen_at) },
      { label: "From", value: (s) => h("span", null, s.ip || "–", h("span", { class: "sub" }, String(s.user_agent || "").slice(0, 60))) },
      { label: "Status", value: (s) => (s.revoked_at ? badge("disabled", `ended: ${words(s.revoked_reason)}`) : new Date(s.expires_at) < new Date() ? badge("disabled", "expired") : badge("active")) },
      { label: "", value: (s) => (!s.revoked_at && new Date(s.expires_at) > new Date() ? button("End session", async () => { await api(`/admin/sessions/${s.id}/revoke`, { method: "POST" }); await render(); }, "small danger") : null) },
    ], sessions.items, { caption: "Sessions" }), { flush: true }));
  }
  await render();
  return holder;
}
async function auditTab() {
  const verify = h("div");
  const action = h("input", { type: "search", placeholder: "Filter by action, e.g. model.approved", "aria-label": "Filter by action", class: "grow" });
  const table = pagedTable({ pageSize: 20, load: (page, size) => api("/admin/audit", { query: { page, page_size: size, action: action.value.trim() } }), caption: "Audit log", columns: [
    { label: "#", align: "right", value: (a) => a.seq }, { label: "When", value: (a) => fmtDateTime(a.created_at) }, { label: "Who", value: (a) => a.actor_label || "system" },
    { label: "Action", value: (a) => h("code", null, a.action) }, { label: "On", value: (a) => (a.entity_type ? `${words(a.entity_type)} ${a.entity_id ?? ""}` : "–") }, { label: "Hash", value: (a) => h("code", null, shortHash(a.hash)) },
  ], onRow: (a) => openDialog({ title: `Audit entry #${a.seq}`, description: a.action, wide: true, body: h("div", null, jsonBlock({ detail: a.detail, correlation_id: a.correlation_id, prev_hash: a.prev_hash, hash: a.hash }), closeFoot()) }) });
  let timer; action.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => table.reload(), 300); });
  return card("Audit log", h("div", null, h("div", { class: "toolbar" }, action, button("Verify integrity", async () => {
    const r = await api("/admin/audit/verify");
    clear(verify).append(h("div", { class: "card-body" }, notice(r.valid ? "ok" : "danger", h("strong", null, r.valid ? "Chain intact. " : "Chain broken. "), `${fmtInt(r.checked)} of ${fmtInt(r.total)} entries verified; head hash ${shortHash(r.head_hash)}…`)));
  })), verify, table.el), { flush: true, sub: "Each entry includes the hash of the one before it, so an edited or removed entry breaks the chain" });
}
async function systemTab() {
  const info = await api("/system/info");
  return h("div", { class: "grid cols-2" },
    card("Installation", kv([["Version", info.version], ["Environment", words(info.environment)], ["Tenant", `${info.tenant.name} (${info.tenant.slug})`], ["Database", info.database], ["Background worker", info.embedded_worker ? "embedded in the web process" : "separate process"],
      ["Self-approval", info.self_approval_allowed ? badge("warning", "allowed") : badge("ok", "not allowed")], ["MLflow mirror", info.integrations.mlflow_configured ? "configured" : "not configured"], ["Single sign-on", info.integrations.single_sign_on],
      ["CRM production sends", info.integrations.crm_production_allowed ? badge("warning", "allowed") : badge("ok", "blocked")]])),
    card("Algorithms", dataTable([{ label: "Algorithm", value: (a) => words(a[0]) }, { label: "Library version", value: (a) => a[1].version || "–" }, { label: "Available", value: (a) => (a[1].available ? badge("ok", "yes") : badge("unavailable", a[1].reason || "no")) }], Object.entries(info.algorithms)), { flush: true }));
}

// ------------------------------------------------------------------ account
export async function account() {
  const root = h("div");
  async function render() {
    const me = await api("/auth/me"); state.me = me;
    clear(root).append(pageHead("My account", `${me.full_name} · ${me.email} · ${words(me.role)}`));
    root.append(h("div", { class: "grid cols-2" },
      card("Password", h("div", null, h("p", { class: "muted" }, `Last changed ${fmtDateTime(me.password_changed_at)}. Changing it signs out your other sessions.`), button("Change password", async () => {
        const ok = await formDialog({ title: "Change password", submitLabel: "Change", fields: [{ name: "current_password", label: "Current password", type: "password", required: true }, { name: "new_password", label: "New password", type: "password", required: true, hint: "at least 12 characters with letters and digits" }],
          onSubmit: (v) => api("/auth/password", { method: "POST", body: v }) });
        if (ok) toast("Password changed", "success");
      }))),
      card("Two-factor sign-in", h("div", null, h("p", null, me.mfa_enabled ? badge("ok", "on") : badge("warning", "off"), me.mfa_enrollment_required ? " Your role requires two-factor sign-in." : ""),
        me.mfa_enabled ? button("Turn off", async () => {
          const ok = await formDialog({ title: "Turn off two-factor sign-in", submitLabel: "Turn off", danger: true, fields: [{ name: "password", label: "Confirm with your password", type: "password", required: true }], onSubmit: (v) => api("/auth/mfa/disable", { method: "POST", body: v }) });
          if (ok) await render();
        }, "danger") : button("Set up", async () => {
          const begin = await api("/auth/mfa/begin", { method: "POST" });
          const ok = await formDialog({ title: "Set up two-factor sign-in", description: "Add this key to an authenticator app (TOTP), then enter the 6-digit code it shows.", submitLabel: "Confirm",
            fields: [{ name: "secret", label: "Setup key", value: begin.secret }, { name: "code", label: "6-digit code", required: true, placeholder: "123456" }], onSubmit: (v) => api("/auth/mfa/confirm", { method: "POST", body: { code: v.code } }) });
          if (ok) { toast("Two-factor sign-in is on", "success"); await render(); }
        }, "primary"))),
      card("What you can do", h("div", { class: "chips" }, me.permissions.map((p) => h("span", { class: "chip mono" }, p))), { sub: `Permissions of the ${words(me.role)} role` })));
  }
  await render();
  return root;
}
