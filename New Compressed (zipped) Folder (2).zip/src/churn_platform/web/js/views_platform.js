// Screens: campaigns, messages, syncs & exports (reverse ETL, CRM sign-in), orchestration, security.
import { api, can, h, card, kpi, kv, notice, badge, pageHead, button, dataTable, pagedTable, tabs, empty, link, words,
  fmtInt, fmtDate, fmtDateTime, shortHash, formDialog, confirmDialog, openDialog, startJob, trackJob, toast, clear } from "./core.js";

const closeFoot = () => h("form", { method: "dialog", class: "dialog-foot" }, h("button", { class: "btn" }, "Close"));
const filled = (nodes) => nodes.filter(Boolean);
const MODE_BADGE = { DRY_RUN: "skipped", SANDBOX: "sandbox", LIVE: "alert", TEST_ONLY: "test_only", PRODUCTION: "alert" };
const modeBadge = (mode) => badge(MODE_BADGE[mode] || "pending", words(mode).toLowerCase());
const MESSAGE_BADGE = { dry_run: "skipped", queued: "pending", sent: "ok", delivered: "ok", bounced: "alert", complained: "alert", failed: "failed", suppressed: "warning", blocked: "warning", cancelled: "skipped" };
const messageBadge = (status) => badge(MESSAGE_BADGE[status] || "pending", words(status));
async function post(path, body, message, after) { const res = await api(path, { method: "POST", body: body ?? {} }); if (message) toast(message, "success"); if (after) await after(res); return res; }

// ------------------------------------------------------------------ messages (notifications)
export async function notifications() {
  const root = h("div");
  async function render() {
    const data = await api("/notifications");
    const s = data.by_status || {};
    const head = pageHead("Messages", "E-mail, text, push and in-app messages to customers. Every provider starts in dry run: messages are built and checked, and nothing is sent.", filled([
      can("notify:write") ? button("Add a provider", addProvider) : null, can("notify:write") ? button("New template", () => templateDialog()) : null,
      can("notify:write") ? button("Send one message", sendOne, "primary") : null]));
    const kpis = h("div", { class: "grid kpis" },
      kpi("Really sent", fmtInt(data.really_sent), `last ${data.window_days} days · accepted by a vendor`), kpi("Dry run", fmtInt(data.dry_run), "built and checked, sent nowhere"),
      kpi("Delivered", fmtInt(s.delivered || 0), "confirmed by the vendor or the product"), kpi("Held back", fmtInt((s.blocked || 0) + (s.suppressed || 0)), "consent, opt-out, suppression, caps"),
      kpi("Failed or bounced", fmtInt((s.failed || 0) + (s.bounced || 0) + (s.complained || 0)), "refused by the vendor or the recipient", (s.failed || s.bounced || s.complained) ? "high" : ""));
    const providers = dataTable([
      { label: "Provider", value: (p) => h("span", null, h("strong", null, p.name), h("span", { class: "sub" }, `${p.provider} · ${words(p.channel)}`)) },
      { label: "Mode", value: (p) => modeBadge(p.mode) }, { label: "Default for channel", value: (p) => (p.is_default ? "yes" : "no") },
      { label: "Credentials", value: (p) => (p.has_credentials ? badge("ok", "stored (encrypted)") : badge("skipped", "none")) },
      { label: "", value: (p) => (can("notify:approve") ? button("Change mode", () => changeMode(p), "small") : null) },
    ], data.providers, { caption: "Message providers", empty: empty("No provider yet", "Without a provider every message is held back. Add one; it starts in dry run.") });
    const reasons = dataTable([{ label: "Why a message was not sent", value: (r) => r.reason || "no reason recorded" }, { label: "Messages", align: "right", value: (r) => fmtInt(r.messages) }],
      data.not_sent_reasons, { caption: "Reasons", emptyText: "Nothing was held back or failed in this period." });
    const body = tabs([
      { id: "overview", label: "Overview", render: () => h("div", { class: "stack" }, kpis,
        !data.live_allowed_by_configuration ? notice("info", "Live delivery is switched off for this installation (CHURN_NOTIFY_ALLOW_LIVE). Providers can run in dry run or sandbox only.") : notice("warning", "Live delivery is allowed for this installation. A provider in LIVE mode sends real messages."),
        !data.public_base_url_set ? notice("warning", "CHURN_PUBLIC_BASE_URL is not set, so unsubscribe links cannot be built and marketing e-mails are held back.") : null,
        card("Providers", providers, { flush: true }), card("Held back or failed", reasons, { flush: true, sub: data.note })) },
      { id: "templates", label: `Templates (${data.templates.length})`, render: () => templatesTab(data) },
      { id: "messages", label: "Messages", render: () => messagesTab() },
      { id: "suppressions", label: `Suppression list (${data.suppression_list.filter((x) => !x.lifted_at).length})`, render: () => suppressionsTab(data) },
    ]);
    clear(root).append(head, body);
  }
  function templatesTab(data) {
    return card("Templates", dataTable([
      { label: "Template", value: (t) => h("span", null, h("strong", null, t.code), h("span", { class: "sub" }, `${words(t.channel)} · ${t.locale} · v${t.version}`)) },
      { label: "Kind", value: (t) => words(t.category) }, { label: "State", value: (t) => badge(t.status) },
      { label: "Subject", cls: "wrap", value: (t) => t.subject }, { label: "Text", cls: "wrap", value: (t) => (t.body || "").slice(0, 160) + ((t.body || "").length > 160 ? "…" : "") },
      { label: "", value: (t) => h("div", { class: "actions" }, filled([
        t.status === "draft" && can("notify:write") ? button("Submit", () => post(`/notifications/templates/${t.id}/submit`, {}, "Submitted for review", render), "small") : null,
        t.status === "pending" && can("notify:approve") ? button("Review", () => decide(`/notifications/templates/${t.id}/review`, `${t.code} (${t.channel}) v${t.version}`, render), "small primary") : null,
        can("notify:write") ? button("New version", () => templateDialog(t), "small") : null])) },
    ], data.templates, { caption: "Message templates", empty: empty("No templates yet", "Create one, or create a campaign from a preset: it brings its templates as drafts.") }),
    { flush: true, sub: `placeholders: ${data.variables.map((v) => `{{${v}}}`).join(" ")}` });
  }
  function messagesTab() {
    const filters = { status: "", channel: "" };
    const table = pagedTable({ caption: "Messages", pageSize: 25,
      load: (page, pageSize) => api(`/notifications/messages?page=${page}&page_size=${pageSize}` + Object.entries(filters).filter(([, v]) => v).map(([k, v]) => `&${k}=${encodeURIComponent(v)}`).join("")),
      columns: [
        { label: "Created", value: (m) => fmtDateTime(m.created_at) }, { label: "Customer", value: (m) => (m.customer_id ? link(m.customer_name || m.customer_external_id, `#/customers/${m.customer_id}`) : "–") },
        { label: "Channel", value: (m) => words(m.channel) }, { label: "To", value: (m) => m.recipient_hint || "–" }, { label: "State", value: (m) => messageBadge(m.status) },
        { label: "Why", cls: "wrap", value: (m) => m.status_reason }, { label: "Subject", cls: "wrap", value: (m) => m.subject },
        { label: "", value: (m) => button("Details", () => openDialog({ title: `Message ${m.id}`, wide: true, body: h("div", null, kv([["State", messageBadge(m.status)], ["Dry run", m.is_dry_run ? "yes" : "no"],
          ["Channel", words(m.channel)], ["To", m.recipient_hint], ["Subject", m.subject], ["Text", h("pre", { class: "json" }, m.body || "")], ["Why", m.status_reason], ["Attempts", m.attempts],
          ["Request (no credentials, no recipient)", h("pre", { class: "json" }, JSON.stringify(m.request, null, 2))], ["Vendor answer", m.response ? JSON.stringify(m.response) : "–"],
          ["Campaign", m.campaign_id ? `#${m.campaign_id}, step ${(m.step_index ?? 0) + 1}, group ${m.variant}` : "–"]]), closeFoot()) }), "small") }],
      emptyNode: empty("No messages", "Nothing has been created yet, or nothing matches the filters.") });
    const sel = (name, options) => { const el = h("select", { "aria-label": name }, options.map((o) => h("option", { value: o }, o === "" ? `Any ${name}` : words(o)))); el.addEventListener("change", () => { filters[name] = el.value; table.reload(); }); return el; };
    return card("Messages", h("div", null, h("div", { class: "toolbar" }, sel("status", ["", "dry_run", "queued", "sent", "delivered", "blocked", "suppressed", "failed", "bounced", "complained"]), sel("channel", ["", "email", "sms", "push", "in_app"])), table.el), { flush: true });
  }
  function suppressionsTab(data) {
    return card("Suppression list", dataTable([
      { label: "Recipient", value: (x) => x.recipient_hint }, { label: "Channel", value: (x) => words(x.channel) }, { label: "Reason", value: (x) => badge(x.reason === "manual" ? "pending" : "alert", x.reason) },
      { label: "Source", value: (x) => x.source }, { label: "Since", value: (x) => fmtDate(x.created_at) }, { label: "State", value: (x) => (x.lifted_at ? badge("skipped", `lifted ${fmtDate(x.lifted_at)}`) : badge("ok", "in force")) },
      { label: "", value: (x) => (!x.lifted_at && can("notify:approve") && !["complaint", "unsubscribe"].includes(x.reason) ? button("Lift", async () => {
        const ok = await formDialog({ title: "Lift this suppression?", description: "The address can be written to again. Only do this when the cause is fixed.", submitLabel: "Lift", fields: [{ name: "note", label: "Why", required: true }],
          onSubmit: (v) => api(`/notifications/suppressions/${x.id}/lift`, { method: "POST", body: v }) });
        if (ok) await render();
      }, "small") : null) },
    ], data.suppression_list, { caption: "Suppression list", empty: empty("Nobody is suppressed", "Bounces, complaints and unsubscribes appear here and stop further messages.") }),
    { flush: true, sub: "complaints and unsubscribes cannot be lifted here: they are the customer's decision" });
  }
  async function addProvider() {
    const res = await formDialog({ title: "Add a message provider", wide: true, submitLabel: "Add (dry run)", description: "The provider starts in dry run. Credentials are stored encrypted and never shown again.",
      fields: [{ name: "name", label: "Name", required: true }, { name: "channel", label: "Channel", type: "select", options: ["email", "sms", "push", "in_app"] },
        { name: "provider", label: "Vendor", type: "select", options: ["sendgrid", "ses", "twilio", "fcm", "apns", "inbox"] },
        { name: "config", label: "Settings (JSON)", type: "json", value: { from_email: "retention@example.com" }, hint: "sendgrid: from_email · ses: from_email, region · twilio: account_sid, from_number · fcm: project_id · apns: bundle_id, team_id, key_id" },
        { name: "credentials", label: "Credentials (JSON, optional in dry run)", type: "json", value: {}, hint: "sendgrid: api_key · ses: access_key_id, secret_access_key · twilio: auth_token · fcm: access_token" }],
      onSubmit: (v) => api("/notifications/providers", { method: "POST", body: { ...v, credentials: Object.keys(v.credentials || {}).length ? v.credentials : null } }) });
    if (res) { toast("Provider added in dry run", "success"); await render(); }
  }
  async function changeMode(p) {
    const res = await formDialog({ title: `Mode of ${p.name}`, submitLabel: "Change", danger: true,
      description: "Dry run: nothing is sent. Sandbox: the vendor validates the request and delivers nothing. Live: real messages to real people.",
      fields: [{ name: "mode", label: "Mode", type: "select", options: ["DRY_RUN", "SANDBOX", "LIVE"], value: p.mode }], onSubmit: (v) => api(`/notifications/providers/${p.id}/mode`, { method: "POST", body: v }) });
    if (res) { toast("Mode changed", "success"); await render(); }
  }
  async function templateDialog(from) {
    const res = await formDialog({ title: from ? `New version of ${from.code}` : "New template", wide: true, submitLabel: "Save draft",
      description: "Use {{placeholders}} for the parts that differ per customer. A marketing e-mail must contain {{unsubscribe_url}}.",
      fields: [{ name: "code", label: "Code", required: true, value: from ? from.code : "" }, { name: "channel", label: "Channel", type: "select", options: ["email", "sms", "push", "in_app"], value: from ? from.channel : "email" },
        { name: "category", label: "Kind", type: "select", options: ["marketing", "transactional"], value: from ? from.category : "marketing" },
        { name: "subject", label: "Subject (e-mail, push, in-app)", value: from ? from.subject : "" }, { name: "body", label: "Text", type: "textarea", required: true, value: from ? from.body : "" }],
      onSubmit: (v) => api("/notifications/templates", { method: "POST", body: v }) });
    if (res) { toast("Draft saved", "success"); await render(); }
  }
  async function sendOne() {
    const res = await formDialog({ title: "Send one message", submitLabel: "Send", description: "Goes through the same checks as a campaign. With a provider in dry run, nothing leaves the platform.",
      fields: [{ name: "customer_id", label: "Customer number (from the customer's page)", type: "number", required: true }, { name: "channel", label: "Channel", type: "select", options: ["email", "sms", "push", "in_app"] },
        { name: "template_code", label: "Template code", required: true }, { name: "variables", label: "Values for placeholders (JSON)", type: "json", value: {} }],
      onSubmit: (v) => api("/notifications/messages", { method: "POST", body: v }) });
    if (res) { toast(`Message is ${words(res.status)}${res.status_reason ? `: ${res.status_reason}` : ""}`, res.status === "sent" || res.status === "dry_run" ? "success" : "info"); await render(); }
  }
  await render();
  return root;
}

async function decide(path, what, after) {
  const res = await formDialog({ title: `Review ${what}`, submitLabel: "Record decision", fields: [{ name: "approve", label: "Decision", type: "select", options: [["true", "Approve"], ["false", "Reject"]] }, { name: "note", label: "Note" }],
    onSubmit: (v) => api(path, { method: "POST", body: { approve: v.approve === "true", note: v.note } }) });
  if (res) { toast("Decision recorded", "success"); if (after) await after(); }
}

// ------------------------------------------------------------------ campaigns
export async function campaigns() {
  const root = h("div");
  async function render() {
    const data = await api("/campaigns");
    const head = pageHead("Campaigns", "Sequences of messages for a group of customers: who is eligible, what they receive and when, with a control group and a dry run before anything is sent.",
      can("notify:write") ? Object.entries(data.presets).map(([key, p]) => button(`Add: ${p.name}`, () => post("/campaigns/presets", { preset: key }, "Draft campaign and draft templates created", render))) : []);
    const table = dataTable([
      { label: "Campaign", value: (c) => h("span", null, h("strong", null, c.name), h("span", { class: "sub" }, c.description || "")) },
      { label: "Approval", value: (c) => badge(c.status === "running" || c.status === "completed" ? "approved" : c.status) },
      { label: "Run", value: (c) => h("span", null, badge({ idle: "skipped", running: "running", paused: "warning", cancelled: "cancelled", completed: "completed", scheduled: "pending" }[c.run_state], words(c.run_state)), c.started_at ? (c.dry_run ? badge("skipped", "dry run") : badge("alert", "live")) : null) },
      { label: "Steps", value: (c) => c.steps.map((x) => `${x.delay_hours ? `+${x.delay_hours}h ` : ""}${words(x.channel)}: ${x.template_code}`).join(" → "), cls: "wrap" },
      { label: "Enrolled", align: "right", value: (c) => fmtInt(Object.values(c.enrollments).reduce((a, b) => a + b, 0)) },
      { label: "Messages", value: (c) => Object.entries(c.messages).map(([k, v]) => `${words(k)} ${v}`).join(" · ") || "–" },
      { label: "", value: (c) => h("div", { class: "actions" }, filled([
        c.status === "draft" && can("notify:write") ? button("Submit", () => post(`/campaigns/${c.id}/submit`, {}, "Submitted for review", render), "small") : null,
        c.status === "pending" && can("notify:approve") ? button("Review", () => decide(`/campaigns/${c.id}/review`, c.name, render), "small primary") : null,
        c.status === "approved" && c.run_state === "idle" && can("notify:approve") ? button("Start", () => startDialog(c), "small primary") : null,
        c.run_state === "running" && can("notify:approve") ? button("Pause", () => post(`/campaigns/${c.id}/state`, { action: "pause" }, "Paused", render), "small") : null,
        c.run_state === "paused" && can("notify:approve") ? button("Resume", () => post(`/campaigns/${c.id}/state`, { action: "resume" }, "Resumed", render), "small") : null,
        ["running", "paused"].includes(c.run_state) && can("notify:approve") ? button("Cancel", () => post(`/campaigns/${c.id}/state`, { action: "cancel" }, "Cancelled", render), "small danger") : null,
        button("Results", () => resultsDialog(c), "small")])) },
    ], data.items, { caption: "Campaigns", empty: empty("No campaigns yet", "Add one of the prepared campaigns above: e-mails for the automated tier (medium risk, lower value), with content or with the 15 % offer, or a reminder for a card that is about to expire.") });
    clear(root).append(head, notice("info", "A campaign needs approved templates and the approval of a second person. It starts as a dry run unless that is switched off when starting, and even then a provider in dry run sends nothing."), card("Campaigns", table, { flush: true }));
  }
  async function startDialog(c) {
    const preview = await api(`/campaigns/${c.id}/preview`);
    const res = await formDialog({ title: `Start ${c.name}`, submitLabel: "Start",
      description: `${fmtInt(preview.eligible)} customer(s) are eligible now (${fmtInt(preview.matched)} match the rule; left out: ${Object.entries(preview.excluded).map(([k, v]) => `${words(k)} ${v}`).join(", ")}). Groups: ${Object.entries(preview.groups).map(([k, v]) => `${k} ${v}`).join(", ") || "none"}.${preview.recommendations ? ` Recommendations of ${preview.recommendations.as_of_date} that are not cleared and were not taken: ${Object.entries(preview.recommendations.left_out).map(([k, v]) => `${words(k)} ${v}`).join(", ")}.` : ""}`,
      fields: [{ name: "dry_run", label: "Dry run", type: "checkbox", value: true, hint: "build and check every message, send nothing" }],
      onSubmit: (v) => api(`/campaigns/${c.id}/start`, { method: "POST", body: { dry_run: v.dry_run } }) });
    if (res) { await trackJob(res.job, "Campaign"); await render(); }
  }
  async function resultsDialog(c) {
    const res = await api(`/campaigns/${c.id}`);
    const groups = Object.entries(res.groups);
    openDialog({ title: `Results: ${c.name}`, wide: true, body: h("div", null, notice("info", res.effect),
      dataTable([{ label: "Group", value: (g) => g[0] }, { label: "Customers", align: "right", value: (g) => fmtInt(g[1].customers) },
        { label: "Enrolment", value: (g) => Object.entries(g[1].by_status).map(([k, v]) => `${words(k)} ${v}`).join(" · ") },
        { label: "Messages", value: (g) => Object.entries(g[1].messages || {}).map(([k, v]) => `${words(k)} ${v}`).join(" · ") || "none" },
        { label: "Churned after the start", value: (g) => (g[1].churned_after_start ? `${g[1].churned_after_start.churned} of ${g[1].churned_after_start.labelled_customers} with a label` : "no labels yet") }],
      groups, { caption: "Results by group", emptyText: "Nobody is enrolled yet." }), closeFoot()) });
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ destination exports (1.3.0)
// The delivery layer window: where each destination stands, what has been delivered, and what is outstanding.
export async function exports() {
  const root = h("div");
  const STATE = { configured: ["ok", "configured"], unconfigured: ["skipped", "not configured here"] };
  const RUN = { pending: "pending", running: "pending", completed: "ok", partial: "warning", failed: "failed" };
  async function render() {
    const data = await api("/exports/overview");
    const head = pageHead("Destination exports",
      "Send the canonical prediction record to a warehouse. Every record carries its own outcome, so a refused record stops the watermark instead of being stepped over, and a resumed run sends only what was not delivered.",
      filled([can("customers:export") ? button("Start an export", startDialog, "primary") : null]));
    const destinations = dataTable([
      { label: "Destination", value: (d) => h("span", null, h("strong", null, d.name), d.reason ? h("span", { class: "sub" }, d.reason) : null) },
      { label: "State", value: (d) => badge(...(STATE[d.state] || ["pending", d.state])) },
      { label: "Watermark", value: (d) => (d.watermark ? fmtDateTime(d.watermark) : "nothing delivered yet") },
      { label: "Last run", value: (d) => d.last_run_id || "–" },
      { label: "Outstanding", align: "right", value: (d) => fmtInt(d.outstanding) },
    ], data.destinations, { caption: "Destinations", emptyText: "This installation knows no destination." });
    const runs = dataTable([
      { label: "Run", value: (r) => h("span", null, `#${r.id}`, h("span", { class: "sub" }, r.run_id)) },
      { label: "Destination", value: (r) => r.destination },
      { label: "Started", value: (r) => fmtDateTime(r.started_at) },
      { label: "State", value: (r) => badge(RUN[r.status] || "pending", r.status === "partial" ? "partial" : words(r.status)) },
      { label: "Selected", align: "right", value: (r) => fmtInt(r.selected) },
      { label: "Acknowledged", align: "right", value: (r) => fmtInt(r.acknowledged) },
      { label: "Failed", align: "right", value: (r) => (r.failed ? h("strong", null, fmtInt(r.failed)) : "0") },
      { label: "Checksum", value: (r) => (r.checksum ? h("code", { title: r.checksum }, shortHash(r.checksum)) : "–") },
      { label: "", value: (r) => h("div", { class: "actions" }, filled([
        can("customers:export") && ["partial", "failed"].includes(r.status) ? button("Resume", () => startJob(`Resume run #${r.id}`, `/exports/runs/${r.id}/resume`, {}, render), "small primary") : null,
        can("customers:export") && ["completed", "partial"].includes(r.status) ? button("Reconcile", () => post(`/exports/runs/${r.id}/reconcile`, {}, "Reconciled", render), "small") : null,
        r.error ? button("Why", () => openDialog({ title: `Run #${r.id}`, wide: true, body: h("div", { class: "stack" }, notice("danger", r.error), kv([["Selection", JSON.stringify(r.selection)], ["State", r.state]])), foot: closeFoot() }), "small") : null])) },
    ], data.runs, { caption: "Export runs", empty: empty("No export has run yet", "An export selects the latest completed prediction batch and delivers it to a destination.") });
    clear(root).append(...filled([head,
      notice("info", data.note),
      card("Destinations", destinations, { flush: true, sub: "a vendor is usable here only when this installation is configured for it" }),
      card("Runs", runs, { flush: true, sub: "selected, acknowledged and failed are counted per record, not per batch" })]));
  }
  async function startDialog() {
    const data = await api("/exports/overview");
    const usable = data.destinations.filter((d) => d.state === "configured");
    if (!usable.length) { toast("No destination is configured on this installation", "error"); return; }
    const res = await formDialog({ title: "Start an export", submitLabel: "Start",
      description: "The latest completed prediction batch is selected, unless you name another. A full export ignores the watermark and rewrites the same rows.",
      fields: [{ name: "destination", label: "Destination", type: "select", options: usable.map((d) => [d.name, d.name]) },
        { name: "batch_id", label: "Batch id (blank = the latest completed batch)", type: "number" },
        { name: "limit", label: "At most this many records (blank = all of them)", type: "number" },
        { name: "full", label: "Full export, ignoring the watermark", type: "checkbox", value: false }],
      onSubmit: (v) => api("/exports/runs", { method: "POST", body: { destination: v.destination,
        batch_id: v.batch_id ? Number(v.batch_id) : null, limit: v.limit ? Number(v.limit) : null, full: !!v.full } }) });
    if (res) { toast("Export queued", "success"); await render(); }
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ syncs & exports (reverse ETL, CRM sign-in)
export async function syncs() {
  const root = h("div");
  async function render() {
    const [data, connections] = await Promise.all([api("/crm/reverse-etl"), api("/crm/connections")]);
    const byId = new Map(data.syncs.map((s) => [s.id, s]));
    const head = pageHead("Syncs & exports", "Send risk scores and recommendations to the CRM, or write them to a file that a reverse-ETL tool (Hightouch, Census) loads into Salesforce, Zendesk, Marketo and others.",
      filled([can("crm:write") ? button("New sync", () => syncDialog(connections.items), "primary") : null]));
    const syncsTable = dataTable([
      { label: "Sync", value: (s) => h("span", null, h("strong", null, s.name), h("span", { class: "sub" }, `${words(s.entity)} → ${s.destination === "crm" ? "CRM connection" : `${(s.export_format || "").toUpperCase()} file`}`)) },
      { label: "State", value: (s) => badge(s.status) }, { label: "Columns", cls: "wrap", value: (s) => Object.keys(s.field_mapping).join(", ") },
      { label: "Filter", value: (s) => (Object.keys(s.filters || {}).length ? JSON.stringify(s.filters) : "all scored customers") },
      { label: "", value: (s) => h("div", { class: "actions" }, filled([
        s.status === "draft" && can("crm:write") ? button("Submit", () => post(`/crm/reverse-etl/syncs/${s.id}/submit`, {}, "Submitted for review", render), "small") : null,
        s.status === "pending" && can("crm:approve") ? button("Review", () => decide(`/crm/reverse-etl/syncs/${s.id}/review`, s.name, render), "small primary") : null,
        s.status === "approved" && can("crm:write") ? button("Run now", () => startJob(`Sync ${s.name}`, `/crm/reverse-etl/syncs/${s.id}/runs`, {}, render), "small primary") : null,
        ["approved", "disabled"].includes(s.status) && can("crm:approve") ? button(s.status === "approved" ? "Switch off" : "Switch on", () => post(`/crm/reverse-etl/syncs/${s.id}/enabled`, { enabled: s.status !== "approved" }, "Saved", render), "small") : null])) },
    ], data.syncs, { caption: "Syncs", empty: empty("No syncs yet", "Define what to send and where. A second person approves it before it can run.") });
    const runs = dataTable([
      { label: "Run", value: (r) => `#${r.id}` }, { label: "Sync", value: (r) => (byId.get(r.sync_id) || {}).name || r.sync_id }, { label: "When", value: (r) => fmtDateTime(r.finished_at || r.created_at) },
      { label: "State", value: (r) => badge(r.status) }, { label: "Rows", align: "right", value: (r) => fmtInt(r.rows) }, { label: "Mode", value: (r) => (r.mode ? modeBadge(r.mode) : "file") },
      { label: "Checksum", value: (r) => (r.export_sha256 ? h("code", { title: r.export_sha256 }, shortHash(r.export_sha256)) : "–") },
      { label: "Verification", cls: "wrap", value: (r) => { const v = r.verification || {}; return r.has_file ? (v.matches ? `file has ${v.rows_in_file} rows, as selected${v.unchanged === false ? " — CHANGED since" : ""}` : "row count differs") : (v.by_status ? Object.entries(v.by_status).map(([k, n]) => `${words(k)} ${n}`).join(" · ") + (v.confirmed_by_the_crm ? ` · confirmed by the CRM ${v.confirmed_by_the_crm}` : "") : v.checked || "–"); } },
      { label: "", value: (r) => h("div", { class: "actions" }, filled([
        r.status === "completed" && can("crm:write") ? button("Verify", () => post(`/crm/reverse-etl/runs/${r.id}/verify`, {}, "Verified", render), "small") : null,
        r.has_file && can("customers:export") ? button("Download", async () => {
          const res = await api(`/crm/reverse-etl/runs/${r.id}/download`, { raw: true });
          const blob = await res.blob(); const a = h("a", { href: URL.createObjectURL(blob), download: `sync-run-${r.id}` }); document.body.append(a); a.click(); a.remove();
        }, "small") : null])) },
    ], data.runs, { caption: "Sync runs", emptyText: "No sync has run yet." });
    const conns = dataTable([
      { label: "Connection", value: (c) => h("span", null, h("strong", null, c.name), h("span", { class: "sub" }, c.provider)) }, { label: "Mode", value: (c) => modeBadge(c.mode) },
      { label: "Sign-in", value: (c) => (c.auth_type === "oauth" ? "OAuth" : "access token") },
      { label: "State", value: (c) => badge({ connected: "connected", ok: "ok", test_only: "test_only", reauthorisation_required: "alert", disconnected: "disabled", error: "error" }[c.status] || "pending", words((c.health || {}).state || c.status)) },
      { label: "Token expires", value: (c) => fmtDateTime(c.token_expires_at) },
      { label: "", value: (c) => (can("crm:write") ? h("div", { class: "actions" }, filled([
        button("Set up OAuth", () => oauthDialog(c), "small"),
        c.auth_type === "oauth" ? button("Connect", async () => { const res = await api(`/crm/connections/${c.id}/oauth/start`, { method: "POST", body: {} }); window.location.href = res.authorization_url; }, "small primary") : null,
        c.has_credentials ? button("Disconnect", async () => { const ok = await confirmDialog("Disconnect this CRM?", "The stored token is erased and, where the CRM allows it, revoked there.", "Disconnect", () => api(`/crm/connections/${c.id}/disconnect`, { method: "POST", body: {} }), { danger: true }); if (ok) await render(); }, "small danger") : null,
        button("Events", async () => { const ev = await api(`/crm/connections/${c.id}/events`); openDialog({ title: `Events from ${c.name}`, wide: true, body: h("div", null, dataTable([
          { label: "Received", value: (e) => fmtDateTime(e.received_at) }, { label: "Type", value: (e) => e.event_type }, { label: "State", value: (e) => badge(e.status === "processed" ? "ok" : "skipped", e.status) },
          { label: "Outcome", value: (e) => (e.outcome ? JSON.stringify(e.outcome) : "–") }], ev.items, { emptyText: "No signed event has arrived from this CRM." }), closeFoot()) }); }, "small")])) : null) },
    ], connections.items, { caption: "CRM connections", empty: empty("No CRM connection", "Create one under CRM sync first.") });
    const params = new URLSearchParams((window.location.hash.split("?")[1]) || "");
    clear(root).append(...filled([head, params.get("oauth_error") ? notice("danger", `The CRM did not grant access: ${params.get("oauth_error")}`) : null,
      params.get("connected") ? notice("info", "The CRM connection is authorised.") : null,
      card("Syncs", syncsTable, { flush: true }), card("Runs", runs, { flush: true, sub: "each run records what was selected and what became of it" }),
      card("CRM sign-in", conns, { flush: true, sub: "OAuth tokens are stored encrypted and refreshed before they expire" })]));
  }
  async function syncDialog(connections) {
    const res = await formDialog({ title: "New sync", wide: true, submitLabel: "Save draft",
      fields: [{ name: "name", label: "Name", required: true }, { name: "entity", label: "What", type: "select", options: ["risk_scores", "recommendations"] },
        { name: "destination", label: "Where to", type: "select", options: [["export", "A file for a reverse-ETL tool"], ["crm", "A CRM connection"]] },
        { name: "connection_id", label: "CRM connection (when sending to a CRM)", type: "select", options: [["", "–"], ...connections.map((c) => [c.id, `${c.name} (${c.mode})`])] },
        { name: "export_format", label: "File format", type: "select", options: ["csv", "jsonl"] },
        { name: "field_mapping", label: "Columns: output name → source field (JSON; {} = all fields)", type: "json", value: {} },
        { name: "filters", label: "Filter (JSON; e.g. {\"risk_tiers\": [\"high\"]})", type: "json", value: { risk_tiers: ["high", "medium"] } }],
      onSubmit: (v) => api("/crm/reverse-etl/syncs", { method: "POST", body: { ...v, connection_id: v.connection_id ? Number(v.connection_id) : null, field_mapping: Object.keys(v.field_mapping || {}).length ? v.field_mapping : null } }) });
    if (res) { toast("Draft saved", "success"); await render(); }
  }
  async function oauthDialog(c) {
    const res = await formDialog({ title: `OAuth application for ${c.name}`, wide: true, submitLabel: "Save",
      description: `Register an app in ${c.provider} with the redirect address shown under Security, then enter its id and secret here. The secret is stored encrypted.`,
      fields: [{ name: "client_id", label: "Client id", required: true, value: c.client_id || "" }, { name: "client_secret", label: "Client secret", type: "password", required: true },
        { name: "webhook_secret", label: "Secret for signed events (optional, 16+ characters)", type: "password" }],
      onSubmit: (v) => api(`/crm/connections/${c.id}/oauth`, { method: "POST", body: { client_id: v.client_id, client_secret: v.client_secret, webhook_secret: v.webhook_secret || null } }) });
    if (res) { toast("Saved. Choose Connect to authorise.", "success"); await render(); }
  }
  await render();
  return root;
}

// ------------------------------------------------------------------ orchestration
export async function orchestration() {
  const [data, mlflow] = await Promise.all([api("/pipeline/orchestration"), can("mlops:read") ? api("/ml/registry/mlflow") : Promise.resolve(null)]);
  const runs = dataTable([
    { label: "Step", value: (r) => words(r.step) }, { label: "Run key", value: (r) => h("code", null, r.run_key) }, { label: "By", value: (r) => r.orchestrator },
    { label: "State", value: (r) => badge(r.status === "succeeded" ? "ok" : r.status) }, { label: "Attempts", align: "right", value: (r) => r.attempts }, { label: "Date scored", value: (r) => fmtDate(r.as_of_date) },
    { label: "Started", value: (r) => fmtDateTime(r.started_at) }, { label: "Finished", value: (r) => fmtDateTime(r.finished_at) }, { label: "Error", cls: "wrap", value: (r) => r.error },
  ], data.runs, { caption: "Steps run for an external orchestrator", empty: empty("No external runs", "Nothing has been run through `churn-platform pipeline-step` yet.") });
  const aliases = mlflow && mlflow.status === "reachable" ? dataTable([
    { label: "Alias", value: (a) => a[0] }, { label: "MLflow version", value: (a) => (a[1] ? `v${a[1].mlflow_version}` : "not set") },
    { label: "Platform version", value: (a) => (a[1] ? `#${a[1].platform_version_id}` : "–") }, { label: "Lifecycle", value: (a) => (a[1] ? a[1].lifecycle_state : "–") },
    { label: "Model file checksum", value: (a) => (a[1] ? h("code", { title: a[1].artifact_sha256 }, shortHash(a[1].artifact_sha256)) : "–") }], Object.entries(mlflow.aliases)) : null;
  return h("div", null, pageHead("Orchestration", "Who starts the nightly pipeline, and which model registry decides what serves."),
    h("div", { class: "grid cols-2" },
      card("Nightly pipeline", kv([["Started by", data.who_fires_the_nightly_run], ["Setting", h("code", null, `CHURN_ORCHESTRATOR=${data.orchestrator}`)], ["Steps, in order", data.steps.map(words).join(" → ")],
        ["With Airflow", "one task per step calls `churn-platform pipeline-step`; a step runs once per run key, however often the task is retried"]])),
      card("Model registry of record", mlflow ? kv([["Registry", mlflow.registry_of_record === "mlflow" ? "MLflow (its production alias decides what serves)" : "this platform (MLflow, when configured, follows it)"],
        ["MLflow", mlflow.status === "not_configured" ? "not configured" : mlflow.status === "reachable" ? badge("ok", "reachable") : badge("error", "unreachable")],
        ["Registered model", mlflow.registered_model], ["Problem", mlflow.error]]) : empty("Not visible", "Your role cannot see the registry settings."))),
    aliases ? card("What MLflow's aliases name", aliases, { flush: true }) : null,
    card("Steps run for an external orchestrator", runs, { flush: true }));
}

// ------------------------------------------------------------------ security
export async function security() {
  const root = h("div");
  async function render() {
    const [overview, providers] = await Promise.all([api("/admin/security/overview"), api("/admin/security/identity-providers")]);
    const limits = overview.rate_limits;
    const table = dataTable([
      { label: "Identity provider", value: (p) => h("span", null, h("strong", null, p.name), h("span", { class: "sub" }, p.issuer)) }, { label: "State", value: (p) => badge(p.enabled ? "enabled" : "disabled") },
      { label: "New accounts", value: (p) => (p.auto_provision ? "created on first sign-in" : "must exist already") },
      { label: "Roles", cls: "wrap", value: (p) => (Object.keys(p.role_mapping || {}).length ? `${p.role_claim}: ` + Object.entries(p.role_mapping).map(([k, v]) => `${k} → ${v}`).join(", ") : (p.default_role ? `everyone: ${p.default_role}` : "kept as set here")) },
      { label: "Second factor", value: (p) => (p.trust_idp_mfa ? "the provider's is accepted" : "not accepted from the provider") },
      { label: "Signing keys", align: "right", value: (p) => p.signing_keys_cached }, { label: "Last problem", cls: "wrap", value: (p) => p.last_error },
      { label: "", value: (p) => h("div", { class: "actions" },
        button("Test", async () => { const res = await api(`/admin/security/identity-providers/${p.id}/test`, { method: "POST", body: {} }); toast(`Reachable: ${res.signing_keys} signing key(s), ${res.algorithms.join(", ") || "no accepted algorithm"}`, "success"); await render(); }, "small"),
        button("Edit", () => providerDialog(p), "small"),
        button(p.enabled ? "Switch off" : "Switch on", async () => { await api(`/admin/security/identity-providers/${p.id}`, { method: "PATCH", body: { enabled: !p.enabled } }); await render(); }, "small")) },
    ], providers.items, { caption: "Identity providers", empty: empty("No single sign-on yet", "Add your organisation's OpenID Connect provider (Entra ID, Okta, Google Workspace, Keycloak …).") });
    clear(root).append(...filled([pageHead("Security", "Single sign-on, request limits, sessions and what is believed from a reverse proxy.", [button("Add an identity provider", () => providerDialog(), "primary")]),
      !providers.public_base_url_set ? notice("warning", "CHURN_PUBLIC_BASE_URL is not set. Set it to the address users reach this platform at; the redirect address below depends on it.") : null,
      card("Single sign-on (OpenID Connect)", table, { flush: true, sub: `redirect address to register with the provider: ${providers.redirect_uri}` }),
      h("div", { class: "grid cols-2" },
        card("Request limits", kv([["Counted in", limits.store], ["Switched on", limits.enabled ? "yes" : "no"], ["If the counter store fails", limits.when_the_store_fails === "deny" ? "requests are refused" : "each server process counts on its own"],
          ...Object.entries(limits.per_minute).map(([k, v]) => [`${words(k)}, per minute`, fmtInt(v)])])),
        card("Sessions and proxy", kv([["Session lifetime", `${overview.sessions.lifetime_minutes} minutes`], ["Ends when idle for", `${overview.sessions.idle_minutes} minutes`],
          ["Token replaced every", `${overview.sessions.token_replaced_every_minutes} minutes`], ["Carried in", overview.sessions.transport],
          ["Trusted proxies", overview.proxy.trusted_proxies.length ? overview.proxy.trusted_proxies.join(", ") : "none"], ["Forwarded headers", overview.proxy.forwarded_headers],
          ["Strict transport security", `${fmtInt(overview.proxy.hsts_seconds)} seconds, on HTTPS responses`], ["Public address", overview.proxy.public_base_url || "not set"]]))),
      card("Your users against the per-user limits, this minute", dataTable([{ label: "Limit", value: (b) => words(b.limit) }, { label: "User", value: (b) => b.user },
        { label: "Requests this minute", align: "right", value: (b) => fmtInt(b.requests) }, { label: "Allowed per minute", align: "right", value: (b) => (b.allowed == null ? "–" : fmtInt(b.allowed)) }],
        limits.own_users_this_minute, { emptyText: "None of your users has made an export, a single prediction or a CRM sync in the current minute." }),
        { flush: true, foot: "Limits per address and per account are counted for the whole installation and are not shown here." })]));
  }
  async function providerDialog(p) {
    const res = await formDialog({ title: p ? `Edit ${p.name}` : "Add an identity provider", wide: true, submitLabel: "Save",
      description: "The platform reads the provider's settings and signing keys from its discovery document. Use Test afterwards.",
      fields: [{ name: "name", label: "Name shown on the sign-in page", required: true, value: p ? p.name : "" }, { name: "issuer", label: "Issuer (https://…)", required: true, value: p ? p.issuer : "" },
        { name: "client_id", label: "Client id", required: true, value: p ? p.client_id : "" }, { name: "client_secret", label: p ? "Client secret (leave empty to keep)" : "Client secret", type: "password" },
        { name: "allowed_email_domains", label: "Allowed e-mail domains (JSON list; [] = any)", type: "json", value: p ? p.allowed_email_domains || [] : [] },
        { name: "role_claim", label: "Claim that carries groups or roles", value: p ? p.role_claim : "groups" }, { name: "role_mapping", label: "Claim value → role (JSON)", type: "json", value: p ? p.role_mapping || {} : {} },
        { name: "default_role", label: "Role when nothing maps", type: "select", options: [["", "none (refuse)"], "viewer", "analyst", "csm", "data_scientist", "data_engineer", "approver", "auditor", "admin"], value: p ? p.default_role || "" : "" },
        { name: "auto_provision", label: "Create accounts on first sign-in", type: "checkbox", value: p ? p.auto_provision : false },
        { name: "trust_idp_mfa", label: "Accept the provider's second factor", type: "checkbox", value: p ? p.trust_idp_mfa : false }],
      onSubmit: (v) => { const body = { ...v, default_role: v.default_role || null }; if (!body.client_secret) delete body.client_secret;
        return p ? api(`/admin/security/identity-providers/${p.id}`, { method: "PATCH", body }) : api("/admin/security/identity-providers", { method: "POST", body }); } });
    if (res) { toast("Saved", "success"); await render(); }
  }
  await render();
  return root;
}
