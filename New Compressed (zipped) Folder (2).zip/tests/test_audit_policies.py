"""Tamper-evident audit log and versioned, four-eyes-approved policies."""

from __future__ import annotations

import itertools

import pytest
from sqlalchemy import select, text

from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, Forbidden, NotFound, ValidationFailed
from churn_platform.logging_setup import REDACTED, redact
from churn_platform.models import AuditEvent, Policy
from churn_platform.services import audit, policies
from tests.conftest import activate

COST = {"currency": "USD", "intervention_cost": "50", "clv_mode": "fixed", "clv": "5000", "contribution_margin": "1", "save_rate": "1",
        "evidence": "Illustrative figures from the project brief", "is_example": True}  # fmt: skip


# ----------------------------------------------------------------------------- audit
@pytest.mark.req("REQ-SEC-03")
def test_audit_chain_links_and_verifies(empty):
    tid, other = empty.tenant(), empty.tenant("other", "Other Ltd")
    admin = empty.user(tid, "admin")
    with session_scope() as s:
        for n in range(3):
            audit.record(s, tenant_id=tid, actor=admin, action="thing.done", entity_type="thing", entity_id=n, detail={"n": n})
        audit.record(s, tenant_id=other, action="other.done")
    with read_session() as s:
        events = s.execute(select(AuditEvent).where(AuditEvent.tenant_id == tid).order_by(AuditEvent.seq)).scalars().all()
        assert [e.seq for e in events] == list(range(1, len(events) + 1))
        assert events[0].prev_hash == audit.GENESIS
        assert all(b.prev_hash == a.hash for a, b in itertools.pairwise(events))
        report = audit.verify_chain(s, tid)
        assert report["valid"] and report["checked"] == report["total"] == len(events) and report["head_hash"] == events[-1].hash
        assert audit.verify_chain(s, other)["valid"], "each tenant has an independent chain"
        assert audit.verify_chain(s, 999_999) == {"valid": True, "checked": 0, "total": 0, "head_hash": audit.GENESIS}


@pytest.mark.req("REQ-SEC-03")
@pytest.mark.parametrize(("tamper", "problem"), [
    ("UPDATE audit_events SET action = 'thing.undone' WHERE seq = 3 AND tenant_id = :t", "does not match its hash"),
    ("UPDATE audit_events SET actor_label = 'someone.else' WHERE seq = 3 AND tenant_id = :t", "does not match its hash"),
    ("DELETE FROM audit_events WHERE seq = 3 AND tenant_id = :t", "sequence gap"),
    ("UPDATE audit_events SET prev_hash = '" + "f" * 64 + "' WHERE seq = 3 AND tenant_id = :t", "previous-hash link"),
])  # fmt: skip
def test_audit_tampering_is_detected(empty, tamper, problem):
    tid = empty.tenant()
    admin = empty.user(tid, "admin")
    with session_scope() as s:
        for n in range(5):
            audit.record(s, tenant_id=tid, actor=admin, action="thing.done", detail={"n": n})
    with session_scope() as s:
        s.execute(text(tamper), {"t": tid})
    with read_session() as s:
        report = audit.verify_chain(s, tid)
    assert report["valid"] is False and problem in report["problem"]
    assert report["first_invalid_seq"] in (3, 4) and report["checked"] == 2


@pytest.mark.req("REQ-SEC-03")
def test_audit_detail_is_redacted_and_rolled_back_with_the_business_change(empty):
    tid = empty.tenant()
    with session_scope() as s:
        audit.record(s, tenant_id=tid, action="conn.created", detail={"api_key": "sk-live-123", "nested": {"password": "hunter2", "name": "ok"},
                                                                     "note": "Authorization: Bearer abc.def.ghi"})  # fmt: skip
    with read_session() as s:
        detail = s.execute(select(AuditEvent.detail).where(AuditEvent.action == "conn.created")).scalar_one()
    assert detail["api_key"] == REDACTED and detail["nested"] == {"password": REDACTED, "name": "ok"}
    assert "abc.def.ghi" not in detail["note"]
    assert redact({"token": "x", "list": [{"secret": "y"}, "password=hunter2 next"]}) == {"token": REDACTED, "list": [{"secret": REDACTED}, f"password={REDACTED} next"]}
    for text_in, leaked in (("Authorization: Basic dXNlcjpwYXNz tail", "dXNlcjpwYXNz"), ("authorization: abc123", "abc123"), ("got bearer   xyz.123 ok", "xyz.123"),
                            ("postgresql+psycopg://churn:s3cr3t@db:5432/churn failed", "s3cr3t"), ("db_password=hunter2&x=1", "hunter2")):
        assert leaked not in redact(text_in) and REDACTED in redact(text_in), text_in
    # ordinary words that merely contain "pass"/"otp" are not masked
    assert redact({"passed": True, "bypass": 1, "top_reasons": [1], "hotplug": 2}) == {"passed": True, "bypass": 1, "top_reasons": [1], "hotplug": 2}
    assert redact("https://example.com/a:b/c passed 3 checks") == "https://example.com/a:b/c passed 3 checks"

    with pytest.raises(RuntimeError), session_scope() as s:
        audit.record(s, tenant_id=tid, action="will.rollback")
        raise RuntimeError("business change failed")
    with read_session() as s:
        assert s.execute(select(AuditEvent).where(AuditEvent.action == "will.rollback")).first() is None
        assert audit.verify_chain(s, tid)["valid"]


# ----------------------------------------------------------------------------- policies
@pytest.mark.req("REQ-GOV-01")
def test_policy_four_eyes_lifecycle_and_versioning(empty):
    tid = empty.tenant()
    author, reviewer = empty.user(tid, "admin"), empty.user(tid, "approver")
    with session_scope() as s:
        p1 = policies.create(s, author, kind="cost_matrix", name="default", payload=COST)
        assert (p1.version, p1.status) == (1, "draft")
        with pytest.raises(Conflict, match="pending"):
            policies.review(s, reviewer, p1.id, approve=True)
        policies.submit(s, author, p1.id)
        with pytest.raises(Conflict, match="draft"):
            policies.submit(s, author, p1.id)
        with pytest.raises(Forbidden) as exc:
            policies.review(s, author, p1.id, approve=True)
        assert exc.value.code == "self_approval_forbidden"
        assert policies.get_active(s, tid, "cost_matrix", required=False) is None
        with pytest.raises(NotFound) as nf:
            policies.get_active(s, tid, "cost_matrix")
        assert nf.value.code == "policy_not_approved"
        with pytest.raises(Conflict):
            policies.get_approved(s, tid, p1.id, "cost_matrix")
        policies.review(s, reviewer, p1.id, approve=True, note="checked against finance figures")
        first_id = p1.id
    with session_scope() as s:
        p2 = policies.create(s, author, kind="cost_matrix", name="default", payload={**COST, "intervention_cost": "75"})
        assert p2.version == 2
        policies.submit(s, author, p2.id)
        assert policies.get_active(s, tid, "cost_matrix").id == first_id, "a pending version does not replace the approved one"
        policies.review(s, reviewer, p2.id, approve=True)
        assert policies.get_active(s, tid, "cost_matrix").id == p2.id
        assert s.get(Policy, first_id).status == "retired"
        assert policies.get_approved(s, tid, first_id, "cost_matrix").version == 1, "retired versions stay resolvable for reproducibility"
        with pytest.raises(ValidationFailed, match="not a risk_policy"):
            policies.get_approved(s, tid, first_id, "risk_policy")
        p3 = policies.create(s, author, kind="cost_matrix", name="default", payload=COST)
        policies.submit(s, author, p3.id)
        assert policies.review(s, reviewer, p3.id, approve=False, note="no").status == "rejected"
        assert policies.get_active(s, tid, "cost_matrix").id == p2.id
        parsed = policies.parse(s.get(Policy, p2.id))
        assert str(parsed.intervention_cost) == "75" and parsed.is_example is True
        actions = [e.action for e in s.execute(select(AuditEvent).where(AuditEvent.entity_type == "policy").order_by(AuditEvent.seq)).scalars()]
    assert actions.count("policy.approved") == 2 and actions.count("policy.rejected") == 1 and actions.count("policy.created") == 3


@pytest.mark.req("REQ-GOV-01")
def test_self_approval_only_with_explicit_non_production_switch(empty):
    tid = empty.tenant()
    author = empty.user(tid, "admin")
    with session_scope() as s:
        pid = policies.create(s, author, kind="risk_policy", name="default", payload=policies.default_payload("risk_policy")).id
        policies.submit(s, author, pid)
    activate(empty.db_path, empty.data_dir, CHURN_ALLOW_SELF_APPROVAL="true")
    with session_scope() as s:
        assert policies.review(s, author, pid, approve=True).status == "approved"


@pytest.mark.req("REQ-SEC-04")
def test_policies_are_tenant_scoped(empty):
    tid, other = empty.tenant(), empty.tenant("other", "Other Ltd")
    author, stranger = empty.user(tid, "admin"), empty.user(other, "approver")
    with session_scope() as s:
        pid = policies.create(s, author, kind="risk_policy", name="default", payload=policies.default_payload("risk_policy")).id
        policies.submit(s, author, pid)
    with session_scope() as s, pytest.raises(NotFound):
        policies.review(s, stranger, pid, approve=True)
    with read_session() as s:
        assert policies.get_active(s, other, "risk_policy", required=False) is None


@pytest.mark.req("REQ-GOV-01")
@pytest.mark.parametrize(("kind", "payload", "fragment"), [
    ("nope", {}, "kind must be one of"),
    ("churn_definition", {"horizon_days": 0}, "horizon_days"),
    ("churn_definition", {"voluntary_reasons": ["x"], "involuntary_reasons": ["x"]}, ""),
    ("churn_definition", {"unknown_field": 1}, "unknown_field"),
    ("cost_matrix", {**COST, "clv": None}, ""),
    ("cost_matrix", {**COST, "clv_mode": "mrr_multiple"}, ""),
    ("cost_matrix", {**COST, "save_rate": "1.5"}, "save_rate"),
    ("cost_matrix", {**COST, "intervention_cost": "-1"}, "intervention_cost"),
    ("cost_matrix", {**COST, "evidence": "short"}, "evidence"),
    ("cost_matrix", {k: v for k, v in COST.items() if k != "currency"}, "currency"),
    ("risk_policy", {"high_risk_top_share": 0.5, "medium_risk_top_share": 0.4}, ""),
    ("risk_policy", {"high_risk_top_share": 1.2}, "high_risk_top_share"),
    ("retention_playbook", {"actions": []}, "actions"),
    ("retention_playbook", {"actions": [policies.DEFAULT_PLAYBOOK["actions"][0]] * 2}, ""),
    ("alert_rules", {"rules": [{"metric": "made_up", "operator": ">", "threshold": 1}]}, "rules.0.metric"),
])  # fmt: skip
def test_invalid_policy_payloads_are_rejected(kind, payload, fragment):
    with pytest.raises(ValidationFailed) as exc:
        policies.validate_payload(kind, payload)
    assert fragment in str(exc.value.details) or fragment in str(exc.value)


@pytest.mark.req("REQ-GOV-01")
def test_policy_defaults_are_structural_and_money_has_no_default():
    for kind in ("churn_definition", "risk_policy", "retention_playbook", "alert_rules"):
        assert policies.validate_payload(kind, policies.default_payload(kind)) == policies.default_payload(kind)
    with pytest.raises(ValidationFailed, match="must be supplied explicitly"):
        policies.default_payload("cost_matrix")
    assert policies.default_payload("churn_definition")["horizon_days"] == 30
    risk = policies.default_payload("risk_policy")
    assert (risk["high_risk_top_share"], risk["involuntary_payment_expiry_days"]) == (0.10, 15)
    discount = next(a for a in policies.DEFAULT_PLAYBOOK["actions"] if a["code"] == "retention_discount_offer")
    assert discount["offer"] == {"discount_pct": 15, "is_example": True} and discount["requires_human_review"] is True
