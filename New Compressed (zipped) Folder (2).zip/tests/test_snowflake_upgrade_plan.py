"""The warehouse upgrade plan: statements that can be read before they are run (1.3.0).

The 1.2.0 table has no tenant column and a primary key that lets two tenants collide.  The adapter's statements are
fixed; the table in a customer's warehouse is not, and this module is the plan that changes it.  It is not executed
here — there is no warehouse, GATE 12 is BLOCKED — so what is asserted is the thing that *can* be asserted: every
identifier is validated and quoted, every value is a bound parameter, the destructive step is marked and withheld
unless asked for, the fill refuses to run without a tenant, and the plan says what each step is for.

A plan that is wrong in a warehouse costs a rebuild of a table; that is why this file tests the text.
"""

from __future__ import annotations

import pytest

from churn_platform.errors import ValidationFailed
from churn_platform.services.destinations import snowflake_upgrade as upgrade

pytestmark = pytest.mark.req("REQ-ACT-02")


def test_the_plan_leads_with_the_tenant_in_the_identity():
    document = upgrade.plan(tenant_id=7)
    assert document["identity"][0] == "TENANT_ID"
    assert document["identity"] == ["TENANT_ID", "EXTERNAL_CUSTOMER_ID", "MODEL_NAME", "MODEL_VERSION", "DATA_CUTOFF_TIMESTAMP"]


def test_adding_the_column_is_additive_and_idempotent():
    statements = [step["sql"] for step in upgrade.plan(tenant_id=7)["steps"]]
    added = [sql for sql in statements if isinstance(sql, str) and "ADD COLUMN" in sql]
    assert added and all("IF NOT EXISTS" in sql for sql in added), "a second run must be harmless"


def test_the_fill_takes_the_tenant_as_a_parameter_and_never_guesses_one():
    fill = next(step for step in upgrade.plan(tenant_id=7)["steps"] if "UPDATE" in str(step["sql"]))
    assert "%(tenant_id)s" in fill["sql"], "the tenant is a bound parameter, not interpolated"
    assert fill["parameters"] == {"tenant_id": 7}
    assert "7" not in fill["sql"].replace("%(tenant_id)s", ""), "the value never appears in the statement text"


def test_a_fill_without_a_tenant_is_not_produced_at_all():
    document = upgrade.plan(tenant_id=None)
    planned = upgrade.statements(document, destructive=True, tenant_id=None)
    assert not any("UPDATE" in item["sql"] for item in planned), "an upgrade cannot pick a tenant for the customer"


def test_dropping_the_old_key_needs_to_be_asked_for():
    document = upgrade.plan(tenant_id=7)
    safe = upgrade.statements(document, destructive=False, tenant_id=7)
    allowed = upgrade.statements(document, destructive=True, tenant_id=7)
    assert not any(item["destructive"] for item in safe)
    assert any("DROP PRIMARY KEY" in item["sql"] for item in allowed)
    assert len(allowed) == len(safe) + 2, "the key is dropped and the new one added"


def test_the_destructive_step_is_named_and_explained():
    drop = next(step for step in upgrade.plan(tenant_id=7)["steps"] if step["destructive"])
    assert "rebuild" in drop["why"], "a person deciding about this needs to know what it costs"
    assert "collide" in drop["why"], "and why the old key has to go"


def test_a_bad_identifier_is_refused_rather_than_quoted_into_a_statement():
    for bad in ("PUBLIC; DROP TABLE X", "a-name", "", "1TABLE"):
        with pytest.raises(ValidationFailed):
            upgrade.plan(table=bad, tenant_id=7)


def test_the_schema_is_quoted_when_it_is_named():
    document = upgrade.plan(schema="analytics", tenant_id=7)
    assert document["table"] == '"ANALYTICS"."CHURN_PREDICTIONS"'
    assert document["runs_table"] == '"ANALYTICS"."CHURN_EXPORT_RUNS"'


def test_a_tenant_id_must_be_a_positive_integer():
    with pytest.raises(ValidationFailed):
        upgrade.plan(tenant_id=0)
    with pytest.raises(ValidationFailed):
        upgrade.plan(tenant_id="seven")  # type: ignore[arg-type]


def test_every_step_says_what_it_is_for():
    for step in upgrade.plan(tenant_id=7)["steps"]:
        assert step["why"].strip(), f"{step['step']} has no reason"
        assert step["sql"]


def test_the_plan_does_not_pretend_it_was_executed():
    document = upgrade.plan(tenant_id=7)
    assert "BLOCKED" in document["note"] and "not executed" in document["note"]
