"""Retention experiments (randomised control) and uplift modelling with its guardrails."""

from __future__ import annotations

import hashlib
import math
from datetime import date

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import delete, func, select

from churn_platform import storage
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, Forbidden, NotFound, ValidationFailed
from churn_platform.models import (
    AuditEvent,
    ChurnLabel,
    Experiment,
    ExperimentAssignment,
    FeatureContract,
    FeatureVector,
    Job,
    Prediction,
    RetentionRecommendation,
    UpliftModel,
    UpliftScore,
)
from churn_platform.services import experiments, features, predictions, retention
from churn_platform.worker.runner import Worker

pytestmark = pytest.mark.req("REQ-ACT-03")


# ----------------------------------------------------------------------------- design and assignment
def test_sample_size_matches_the_textbook_two_proportion_formula():
    assert experiments.sample_size(0.10, 0.02) == {"control": 3213, "treatment": 3213, "total": 6426}, "10% -> 8% churn, alpha 0.05, power 0.80"
    bigger_effect, more_power = experiments.sample_size(0.10, 0.04), experiments.sample_size(0.10, 0.02, power=0.9)
    assert bigger_effect["total"] < 6426 < more_power["total"]
    uneven = experiments.sample_size(0.10, 0.02, treatment_share=0.8)
    assert uneven["treatment"] == pytest.approx(4 * uneven["control"], abs=4) and uneven["total"] > 6426, "an uneven split costs sample size"
    for baseline, effect in ((0.10, 0.0), (0.10, 0.10), (0.0, 0.02), (1.0, 0.02), (0.10, 0.2)):
        with pytest.raises(ValidationFailed):
            experiments.sample_size(baseline, effect)


def test_assignment_is_deterministic_per_salt_and_close_to_the_designed_share():
    customers = range(1, 20_001)
    for salt, share in (("a", 0.5), ("b", 0.5), ("c", 0.2), ("d", 0.8)):
        arms = [experiments.arm_for(salt, cid, share) for cid in customers]
        assert arms == [experiments.arm_for(salt, cid, share) for cid in customers], "the same customer always gets the same arm"
        observed = arms.count("treatment") / len(arms)
        assert abs(observed - share) < 0.012, (salt, observed)
        assert experiments.srm_check(arms.count("treatment"), arms.count("control"), share)["status"] == "ok"
    first, second = ([experiments.arm_for(salt, cid, 0.5) for cid in customers] for salt in ("a", "b"))
    agreement = sum(x == y for x, y in zip(first, second, strict=True)) / len(first)
    assert 0.48 < agreement < 0.52, "a new experiment re-randomises: arms are independent across salts"
    assert {experiments.arm_for("a", cid, 0.5) for cid in customers} == {"treatment", "control"}


def test_sample_ratio_mismatch_is_detected():
    assert experiments.srm_check(500, 500, 0.5)["status"] == "ok" and experiments.srm_check(520, 480, 0.5)["status"] == "ok"
    broken = experiments.srm_check(600, 400, 0.5)
    assert broken["status"] == "mismatch" and broken["p_value"] < experiments.SRM_ALPHA == 0.001 and broken["observed_share"] == 0.6
    assert experiments.srm_check(200, 800, 0.2)["status"] == "ok" and experiments.srm_check(200, 800, 0.5)["status"] == "mismatch"
    assert experiments.srm_check(0, 0, 0.5) == {"status": "insufficient_data", "p_value": None}


def test_arm_comparison_uses_the_newcombe_interval_and_a_two_proportion_z_test():
    # Newcombe (1998), the worked example for the hybrid score interval: 56/70 versus 48/80
    published = experiments.compare_arms(56, 70, 48, 80)
    assert published["difference"] == pytest.approx(0.2) and (round(published["ci_low"], 4), round(published["ci_high"], 4)) == (0.0524, 0.3339)
    from statsmodels.stats.proportion import confint_proportions_2indep, proportions_ztest

    for churn_t, n_t, churn_c, n_c in ((30, 200, 50, 200), (12, 150, 15, 160), (0, 40, 5, 60), (90, 100, 10, 100)):
        got = experiments.compare_arms(churn_t, n_t, churn_c, n_c)
        low, high = confint_proportions_2indep(churn_t, n_t, churn_c, n_c, method="newcomb", compare="diff")
        assert (got["ci_low"], got["ci_high"]) == pytest.approx((low, high), abs=1e-9)
        assert got["p_value"] == pytest.approx(proportions_ztest([churn_t, churn_c], [n_t, n_c])[1], abs=1e-9)
        assert got["ci_low"] <= got["difference"] <= got["ci_high"] and got["significant"] == (got["p_value"] < 0.05)
    better = experiments.compare_arms(30, 200, 50, 200)
    assert better["p_value"] == pytest.approx(0.0124, abs=1e-4) and better["reading"] == "treatment churn is lower" and better["relative_change"] == pytest.approx(-0.4)
    assert experiments.compare_arms(50, 200, 30, 200)["reading"] == "treatment churn is higher"
    same = experiments.compare_arms(12, 150, 15, 160)
    assert same["significant"] is False and same["reading"] == "no statistically significant difference" and same["ci_low"] < 0 < same["ci_high"]
    assert experiments.compare_arms(0, 100, 0, 100)["p_value"] == 1.0
    small = experiments.compare_arms(3, 29, 5, 200)
    assert small["status"] == "insufficient_data" and "at least 30 matured outcomes" in small["reason"] and "difference" not in small


# ----------------------------------------------------------------------------- uplift
def test_the_four_uplift_segments():
    p_treated = np.array([0.90, 0.30, 0.91, 0.10, 0.53, 0.47, 0.51, 0.41])
    p_control = np.array([0.60, 0.70, 0.90, 0.11, 0.50, 0.50, 0.50, 0.42])
    assert experiments.classify_segments(p_treated, p_control, delta=0.02).tolist() == [
        "persuadable",   # stays only if contacted
        "sleeping_dog",  # contacting makes it worse
        "sure_thing",    # stays either way
        "lost_cause",    # leaves either way
        "persuadable",   # +3 points is beyond the dead band of 2
        "sleeping_dog",  # -3 points
        "sure_thing",    # +1 point is inside the dead band: no claim of an effect
        "lost_cause"]    # -1 point, and unlikely to stay anyway  # fmt: skip
    wide = experiments.classify_segments(p_treated, p_control, delta=0.25).tolist()
    assert wide == ["persuadable", "sleeping_dog", "sure_thing", "lost_cause", "sure_thing", "sure_thing", "sure_thing", "lost_cause"], "a wider dead band claims less"
    assert experiments.SEGMENTS == ("persuadable", "sure_thing", "lost_cause", "sleeping_dog")


def test_qini_curve_by_hand_and_against_random_and_reversed_rankings():
    out = experiments.qini(np.array([4.0, 3.0, 2.0, 1.0]), np.array([1, 0, 1, 0]), np.array([1, 0, 0, 1]))
    assert [p["incremental"] for p in out["curve"]] == [1.0, 1.0, 1.0, 0.0] and [p["random"] for p in out["curve"]] == [0.0] * 4
    assert out["coefficient"] == pytest.approx(3 / 16) and out["incremental_at_full_targeting"] == 0.0
    rng = np.random.default_rng(3)
    n = 4000
    x, treated = rng.random(n), rng.integers(0, 2, n)
    # contacting helps when x is high and harms when x is low
    retained = (rng.random(n) < np.where(treated == 1, 0.2 + 0.6 * x, 0.5)).astype(int)
    good, reversed_, noise = (experiments.qini(score, treated, retained)["coefficient"] for score in (x, -x, rng.random(n)))
    assert good > 0.01 and reversed_ < -0.01 and abs(noise) < good / 4
    assert experiments.qini(pd.Series(x), pd.Series(treated), pd.Series(retained))["coefficient"] == pytest.approx(good)


def _experiment_frame(n: int, seed: int, effect: bool) -> tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    frame = pd.DataFrame({"logins_30d": rng.normal(20, 6, n), "tenure_days": rng.uniform(30, 900, n), "mrr": rng.lognormal(4, 0.5, n),
                          "industry": rng.choice(["software", "retail", "health"], n)})  # fmt: skip
    treated = rng.integers(0, 2, n)
    lift = np.where(frame["logins_30d"] > 20, 0.3, -0.3) if effect else 0.0
    retained = (rng.random(n) < 0.5 + treated * lift).astype(int)
    return frame, treated, retained


def test_the_t_learner_recovers_a_planted_heterogeneous_effect_out_of_fold():
    frame, treated, retained = _experiment_frame(1200, seed=1, effect=True)
    names = list(frame.columns)
    oof = experiments.t_learner_oof(frame, treated, retained, names, seed=0)
    assert oof.shape == (1200, 2) and ((oof >= 0) & (oof <= 1)).all()
    np.testing.assert_array_equal(oof, experiments.t_learner_oof(frame, treated, retained, names, seed=0))
    uplift = oof[:, 0] - oof[:, 1]
    helped = frame["logins_30d"] > 20
    assert uplift[helped].mean() > 0.15 and uplift[~helped].mean() < -0.15, "the sign of the effect is found on both sides"
    segments = pd.Series(experiments.classify_segments(oof[:, 0], oof[:, 1], 0.02))
    assert (segments[helped.to_numpy()] == "persuadable").mean() > 0.8 and (segments[~helped.to_numpy()] == "sleeping_dog").mean() > 0.8
    report = experiments.validate_uplift(oof, treated, retained, seed=0)
    assert report["passed"] is True and report["qini_ci90"][0] > 0 and report["qini_ci90"][0] <= report["qini_coefficient"] <= report["qini_ci90"][1]
    observed = [b["observed_uplift"] for b in report["buckets"]]
    assert len(observed) == 5 and observed[0] > 0.15 and observed[-1] < -0.15, "the top bucket really gains, the bottom bucket really loses"
    assert report["method"].startswith("T-learner") and "5th percentile" in report["rule"]


def test_an_uplift_model_fitted_on_an_experiment_without_any_effect_fails_validation():
    failures = 0
    for seed in range(5):
        frame, treated, retained = _experiment_frame(800, seed=seed, effect=False)
        report = experiments.validate_uplift(experiments.t_learner_oof(frame, treated, retained, list(frame.columns), seed=0), treated, retained, seed=0)
        failures += not report["passed"]
        assert report["qini_ci90"][0] < 0.02
    assert failures >= 4, "noise must not be mistaken for a targeting model"


def test_an_a_a_split_is_called_significant_about_as_often_as_alpha_says(ro):
    """Calibration of the whole chain (hash assignment + two-proportion test) on the seeded outcomes: with no
    treatment at all, the share of random splits declared significant must be near alpha, not far above it."""
    with read_session() as s:
        experiment = s.execute(select(Experiment)).scalar_one()
        outcomes = dict(s.execute(select(ExperimentAssignment.customer_id, ExperimentAssignment.outcome).where(
            ExperimentAssignment.experiment_id == experiment.id)).all())  # fmt: skip
    assert len(outcomes) == 217 and set(outcomes.values()) == {"churned", "retained"}
    significant = evaluated = 0
    for n in range(400):
        arms = {cid: experiments.arm_for(f"calibration-{n}", cid, 0.5) for cid in outcomes}
        treated = [cid for cid, arm in arms.items() if arm == "treatment"]
        control = [cid for cid, arm in arms.items() if arm == "control"]
        result = experiments.compare_arms(sum(outcomes[c] == "churned" for c in treated), len(treated),
                                          sum(outcomes[c] == "churned" for c in control), len(control), 0.05)  # fmt: skip
        if result["status"] == "ok":
            evaluated += 1
            significant += bool(result["significant"])
    assert evaluated == 400
    assert significant / evaluated <= 0.09, f"{significant} of {evaluated} A/A splits were called significant at alpha 0.05"


def test_the_resplit_check_separates_an_unlucky_split_from_a_biased_assignment(monkeypatch):
    rng = np.random.default_rng(11)
    outcomes = {cid: bool(rng.random() < 0.08) for cid in range(1, 601)}
    fair = experiments.resplit_check(outcomes, "salt", 0.5, 0.05)
    assert fair["status"] == "ok" and (fair["splits"], fair["evaluated"]) == (400, 400) and 0.01 <= fair["rate"] <= 0.09
    # the limit, by hand: the smallest count that a test of true size 1.5 x alpha stays at or below in 999 of 1000 runs of 400 splits
    cumulative, limit = 0.0, -1
    while cumulative < 0.999:
        limit += 1
        cumulative += math.comb(400, limit) * 0.075**limit * 0.925 ** (400 - limit)
    assert fair["limit"] == limit == 47
    assert experiments.resplit_check(outcomes, "salt", 0.5, 0.05) == fair, "reproducible: the splits derive from the experiment's salt"
    # a significant single split next to a healthy re-split rate is reported as bad luck ...
    unlucky = {"status": "ok", "significant": True}
    notes = experiments._aa_notes(unlucky, fair, 0.05)
    assert "about 1 split in 20 still crosses the 5% threshold by chance" in notes[0] and notes[1].endswith("and this split is one of the unlucky ones.")
    # ... an assignment rule that looks at the outcome is not: churners are sent to control far too often
    real_arm_for = experiments.arm_for

    def biased(salt: str, customer_id: int, share: float) -> str:
        return "control" if outcomes[customer_id] and real_arm_for(salt + "x", customer_id, 0.5) == "control" else real_arm_for(salt, customer_id, share)

    monkeypatch.setattr(experiments, "arm_for", biased)
    flawed = experiments.resplit_check(outcomes, "salt", 0.5, 0.05)
    assert flawed["status"] == "excess" and flawed["significant"] > flawed["limit"] and flawed["rate"] > 0.5
    assert experiments._aa_notes(unlucky, flawed, 0.05)[1].endswith("must be investigated before a real experiment is run.")
    monkeypatch.undo()
    # too few customers to compare: nothing is claimed; a very large population gets fewer splits, never none
    tiny = experiments.resplit_check({cid: cid % 2 == 0 for cid in range(1, 21)}, "salt", 0.5, 0.05)
    assert tiny == {"status": "insufficient_data", "splits": 400, "evaluated": 0, "alpha": 0.05}
    assert experiments._aa_notes({"status": "ok", "significant": False}, tiny, 0.05) == [
        "A/A back-test: NO treatment was delivered and the arms do not differ significantly, which is the expected result."]
    assert experiments.resplit_check(dict.fromkeys(range(1, 2001), False) | {1: True, 2: True, 3: True}, "salt", 0.5, 0.05, splits=3)["splits"] == 3
    assert min(experiments.RESPLITS, max(experiments.RESPLITS_MIN, experiments.RESPLIT_HASH_BUDGET // 200_000)) == 20


# ----------------------------------------------------------------------------- lifecycle on the seeded tenant
def test_seeded_a_a_backtest_is_analysed_as_assigned_and_shows_the_guardrails(ro):
    with read_session() as s:
        experiment = s.execute(select(Experiment)).scalar_one()
        rows = s.execute(select(ExperimentAssignment).where(ExperimentAssignment.experiment_id == experiment.id)).scalars().all()
        results = experiment.results
        as_of = date.fromisoformat(results["assignment"]["as_of_date"])
        labels = dict(s.execute(select(ChurnLabel.customer_id, ChurnLabel.status).where(ChurnLabel.as_of_date == as_of)).all())
        view = experiments.view(experiment)
        assert s.execute(select(func.count()).select_from(UpliftModel)).scalar_one() == 0
    assert (experiment.origin, experiment.status) == ("aa_backtest", "completed") and "assignment_salt" not in view
    assert experiment.reviewed_by is not None and experiment.reviewed_by != experiment.created_by, "approved by a second person"
    assignment, analysis = results["assignment"], results["analysis"]
    arms = {arm: [r for r in rows if r.arm == arm] for arm in ("treatment", "control")}
    assert (assignment["treatment"], assignment["control"]) == (len(arms["treatment"]), len(arms["control"])) and len(rows) == 217
    assert all(r.arm == experiments.arm_for(experiment.assignment_salt, r.customer_id, experiment.treatment_share) for r in rows)
    assert assignment["srm"]["status"] == "ok" and assignment["method"] == "sha256(salt:customer_id) < treatment_share"
    assert all(r.outcome == labels[r.customer_id] for r in rows), "outcomes are the matured churn labels for the assignment date"
    comparison = analysis["comparison"]
    assert comparison["status"] == "ok" and (comparison["n_treatment"], comparison["n_control"]) == (len(arms["treatment"]), len(arms["control"]))
    assert comparison["churned_treatment"] == sum(r.outcome == "churned" for r in arms["treatment"])
    assert comparison["churned_control"] == sum(r.outcome == "churned" for r in arms["control"])
    # No treatment was delivered, so any difference is chance.  The verdict must be exactly what the counts imply;
    # it is NOT asserted to be "not significant": an A/A comparison crosses the threshold for about alpha of all splits.
    recomputed = experiments.compare_arms(comparison["churned_treatment"], comparison["n_treatment"], comparison["churned_control"],
                                          comparison["n_control"], experiment.alpha)  # fmt: skip
    assert comparison["significant"] == recomputed["significant"] == (comparison["p_value"] < experiment.alpha)
    assert comparison["p_value"] == pytest.approx(recomputed["p_value"], abs=1e-12)
    assert experiment.assignment_salt == hashlib.sha256(b"churn-platform-demo:7").hexdigest()[:32], "the demo split is reproducible from its seed"
    assert analysis["matured"] == analysis["assigned"] == 217 and analysis["mature_share"] == 1.0 and analysis["churn_definition"] == "default v1"
    assert analysis["notes"][0].startswith("Intention-to-treat") and any("NO treatment was delivered" in note for note in analysis["notes"])
    # ... and nothing in the wording may read like an effect, or like a flaw that the single split cannot prove
    assert comparison["reading"] == ("the arms differ although no treatment was delivered" if comparison["significant"]
                                     else "no statistically significant difference, as expected without a treatment")  # fmt: skip
    assert not any("would indicate a flaw" in note for note in analysis["notes"])
    # the same customers split again with fresh salts: the stored count equals an independent repetition with the public functions
    resplit = analysis["resplit"]
    churned = {r.customer_id: r.outcome == "churned" for r in rows}
    again = 0
    for k in range(resplit["splits"]):
        treated = [c for c in churned if experiments.arm_for(f"{experiment.assignment_salt}:resplit:{k}", c, experiment.treatment_share) == "treatment"]
        control = [c for c in churned if c not in set(treated)]
        again += experiments.compare_arms(sum(churned[c] for c in treated), len(treated), sum(churned[c] for c in control), len(control), experiment.alpha)["significant"]
    assert (resplit["splits"], resplit["evaluated"], resplit["alpha"]) == (400, 400, 0.05) and resplit["significant"] == again
    assert resplit["status"] == "ok" and resplit["rate"] == again / 400 <= 0.09 and resplit["significant"] <= resplit["limit"]
    assert f"{again} of them ({again / 400:.1%}) significant, in line with chance" in analysis["notes"][2]
    assert ro.summary["experiment"]["uplift"]["status"] == "not_fitted" and "not enough experiment data" in ro.summary["experiment"]["uplift"]["reason"]


def test_experiment_lifecycle_requires_design_checks_and_a_second_approver(demo):
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    for overrides, message in (({"name": " "}, "name is required"), ({"origin": "guess"}, "origin must be one of"), ({"treatment_share": 0.99}, "treatment_share"),
                               ({"alpha": 0.6}, "alpha must be"), ({"power": 0.3}, "alpha must be"), ({"baseline_rate": 0.05, "min_detectable_effect": 0.05}, "strictly between")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            experiments.create(s, scientist, **{"name": "x", **overrides})
    with session_scope() as s:
        experiment = experiments.create(s, scientist, name="Drip campaign Q4", hypothesis="The re-engagement drip lowers 30-day churn", baseline_rate=0.10,
                                        min_detectable_effect=0.02, treatment_share=0.5)  # fmt: skip
        experiment_id = experiment.id
        assert (experiment.status, experiment.required_per_arm, experiment.outcome_window_days) == ("draft", 3213, 30)
        assert len(experiment.assignment_salt) == 32 and experiment.results["design"]["total"] == 6426
    with session_scope() as s, pytest.raises(Conflict, match="already exists"):
        experiments.create(s, scientist, name="Drip campaign Q4")
    with session_scope() as s, pytest.raises(Conflict) as unapproved:
        experiments.assign(s, scientist, experiment_id, demo.summary["batch_id"])
    assert unapproved.value.code == "not_approved"
    with session_scope() as s, pytest.raises(Conflict, match="only a pending experiment"):
        experiments.review(s, approver, experiment_id, approve=True)
    with session_scope() as s:
        assert experiments.submit(s, scientist, experiment_id).status == "pending"
    with session_scope() as s, pytest.raises(Forbidden) as own:
        experiments.review(s, scientist, experiment_id, approve=True)
    assert own.value.code == "self_approval_forbidden"
    with session_scope() as s, pytest.raises(Conflict, match="no assignment yet"):
        experiments.analyse(s, scientist, experiment_id)
    with session_scope() as s:
        assert experiments.review(s, approver, experiment_id, approve=True).status == "approved"
        for bad in (("extreme",), ()):
            with pytest.raises(ValidationFailed, match="tiers must be chosen from high, medium, low"):
                experiments.assign(s, scientist, experiment_id, demo.summary["batch_id"], tiers=bad)
        with pytest.raises(NotFound):
            experiments.assign(s, scientist, experiment_id, 999_999)
        view = experiments.assign(s, scientist, experiment_id, demo.summary["batch_id"])
        at_risk = s.execute(select(func.count()).select_from(Prediction).where(Prediction.batch_id == demo.summary["batch_id"], Prediction.risk_tier.in_(("high", "medium")))).scalar_one()
        assigned = s.execute(select(ExperimentAssignment).where(ExperimentAssignment.experiment_id == experiment_id)).scalars().all()
    assignment = view["results"]["assignment"]
    assert view["status"] == "running" and assignment["treatment"] + assignment["control"] == at_risk == len(assigned) == 85, "high and medium tiers by default"
    assert len({a.customer_id for a in assigned}) == len(assigned) and assignment["as_of_date"] == "2026-11-01"
    with session_scope() as s, pytest.raises(Conflict):
        experiments.assign(s, scientist, experiment_id, demo.summary["batch_id"])
    # the 30-day outcome window of 1 November has not elapsed: nothing can be compared yet
    with session_scope() as s:
        early = experiments.analyse(s, scientist, experiment_id)
    analysis = early["results"]["analysis"]
    assert early["status"] == "running" and (analysis["matured"], analysis["mature_share"]) == (0, 0.0)
    assert analysis["comparison"]["status"] == "insufficient_data"
    with session_scope() as s, pytest.raises(Conflict) as too_little:
        experiments.fit_uplift(s, scientist, experiment_id, demo.summary["contract_id"])
    assert too_little.value.code == "insufficient_data" and "0 matured outcomes" in too_little.value.message
    with read_session() as s:
        actions = s.execute(select(AuditEvent.action).where(AuditEvent.entity_type == "experiment", AuditEvent.entity_id == str(experiment_id)).order_by(AuditEvent.id)).scalars().all()
    assert actions == ["experiment.created", "experiment.submitted", "experiment.approved", "experiment.assigned", "experiment.analysed"]
    # a rejected experiment can never be assigned
    with session_scope() as s:
        other = experiments.create(s, scientist, name="Discount test").id
        experiments.submit(s, scientist, other)
    with session_scope() as s:
        assert experiments.review(s, approver, other, approve=False).status == "rejected"
    with session_scope() as s, pytest.raises(Conflict):
        experiments.assign(s, scientist, other, demo.summary["batch_id"])


def _imported_experiment(demo, effect: bool) -> int:
    """An experiment over the whole October book whose outcomes are planted (as if imported from a finished campaign)."""
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    with read_session() as s:
        backtest = s.execute(select(Prediction.batch_id).where(Prediction.as_of_date == date(2026, 10, 1)).limit(1)).scalar_one()
        contract = s.get(FeatureContract, demo.summary["contract_id"])
        vectors = features.offline_frame(s, demo.tenant_id, contract, dates=[date(2026, 10, 1)]).set_index("customer_id")
    with session_scope() as s:
        experiment_id = experiments.create(s, scientist, name=f"Imported campaign ({'effect' if effect else 'no effect'})", origin="imported").id
        experiments.submit(s, scientist, experiment_id)
    with session_scope() as s:
        experiments.review(s, approver, experiment_id, approve=True)
        s.get(Experiment, experiment_id).assignment_salt = "fixed-salt-for-a-balanced-split-3"
        experiments.assign(s, scientist, experiment_id, backtest, tiers=("high", "medium", "low"))
        experiments.analyse(s, scientist, experiment_id)
    median = vectors["tenure_days"].median()
    rng = np.random.default_rng(5)
    with session_scope() as s:
        for row in s.execute(select(ExperimentAssignment).where(ExperimentAssignment.experiment_id == experiment_id)).scalars():
            long_standing = vectors.loc[row.customer_id, "tenure_days"] > median
            if effect:  # contacting long-standing customers keeps them; contacting new ones drives them away
                stays = long_standing if row.arm == "treatment" else rng.random() < 0.5
            else:
                stays = rng.random() < 0.5
            row.outcome = "retained" if stays else "churned"
    return experiment_id


def test_a_validated_and_approved_uplift_model_steers_recommendations_end_to_end(demo):
    scientist, approver, admin = demo.principal("data_scientist"), demo.principal("approver"), demo.principal("admin")
    experiment_id = _imported_experiment(demo, effect=True)
    with session_scope() as s:
        counts = dict(s.execute(select(ExperimentAssignment.arm, func.count()).where(ExperimentAssignment.experiment_id == experiment_id).group_by(ExperimentAssignment.arm)).all())
        assert min(counts.values()) >= experiments.MIN_UPLIFT_PER_ARM, counts
        with pytest.raises(ValidationFailed, match="delta must be"):
            experiments.fit_uplift(s, scientist, experiment_id, demo.summary["contract_id"], delta=0.7)
        model = experiments.fit_uplift(s, scientist, experiment_id, demo.summary["contract_id"])
        model_id = model.id
        assert model.status == "validated" and model.validation["passed"] is True and model.validation["qini_ci90"][0] > 0
        assert model.metrics["rows"] == 217 and model.metrics["treated"] + model.metrics["control"] == 217 and model.metrics["origin"] == "imported"
        assert not model.artifact_path.startswith("/") and storage.resolve(model.artifact_path).is_file() and len(model.artifact_sha256) == 64
    # not approved yet: scoring is diagnostic and the recommendation engine ignores it
    with session_scope() as s:
        diagnostic = experiments.score(s, scientist, model_id)
        assert diagnostic["diagnostic"] is True and diagnostic["as_of_date"] == "2026-11-01" and diagnostic["customers"] == 212
        assert experiments.approved_segments(s, demo.tenant_id, date(2026, 11, 1)) == {}
        summary = experiments.segment_summary(s, demo.tenant_id, model_id)
        assert summary["usable_for_targeting"] is False and summary["warning"].startswith("DIAGNOSTIC ONLY")
        assert sum(seg["customers"] for seg in summary["segments"].values()) == 212 == sum(diagnostic["segments"].values())
    with session_scope() as s, pytest.raises(Forbidden) as own:
        experiments.review_uplift(s, scientist, model_id, approve=True)
    assert own.value.code == "self_approval_forbidden"
    with session_scope() as s:
        assert experiments.review_uplift(s, approver, model_id, approve=True).status == "approved"
    with session_scope() as s, pytest.raises(Conflict):
        experiments.review_uplift(s, approver, model_id, approve=False)
    with session_scope() as s:
        scored = experiments.score(s, scientist, model_id)
        assert scored["diagnostic"] is False
        segments = experiments.approved_segments(s, demo.tenant_id, date(2026, 11, 1))
        rows = s.execute(select(UpliftScore).where(UpliftScore.uplift_model_id == model_id)).scalars().all()
        contract = s.get(FeatureContract, demo.summary["contract_id"])
        tenure = features.offline_frame(s, demo.tenant_id, contract, dates=[date(2026, 11, 1)]).set_index("customer_id")["tenure_days"]
        assert experiments.segment_summary(s, demo.tenant_id, model_id)["warning"] is None
    assert len(rows) == len(segments) == 212, "re-scoring replaces the earlier scores instead of duplicating them"
    assert all(r.uplift == pytest.approx(r.p_retain_treated - r.p_retain_control) and r.segment == segments[r.customer_id] for r in rows)
    assert scored["segments"]["persuadable"] > 40 and scored["segments"]["sleeping_dog"] > 40
    dogs = [cid for cid, seg in segments.items() if seg == "sleeping_dog"]
    keen = [cid for cid, seg in segments.items() if seg == "persuadable"]
    assert tenure[keen].median() > tenure[dogs].median(), "the planted pattern is what the model learnt: long-standing customers respond well"
    # the recommendation engine now applies the approved segments
    with session_scope() as s:
        retention.start_generation(s, admin, demo.summary["batch_id"])
    Worker().drain()
    with read_session() as s:
        generated = s.execute(select(AuditEvent.detail).where(AuditEvent.action == "retention.recommendations_generated").order_by(AuditEvent.id.desc())).scalars().first()
    assert generated["uplift"] == {"applied": True, "model_id": model_id, "scored_for_this_batch": False, "note": f"approved uplift model #{model_id} applied"}
    with read_session() as s:
        recs = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == demo.summary["batch_id"])).scalars().all()
    assert recs and all(r.rationale["uplift_segment"] == segments[r.customer_id] for r in recs)
    for rec in recs:
        if segments[rec.customer_id] == "sleeping_dog" and rec.segment != "involuntary" and not (rec.blocked_reason or "").startswith("marketing consent"):
            assert rec.status == "blocked" and "sleeping dog" in rec.blocked_reason
        if segments[rec.customer_id] == "persuadable" and rec.status == "proposed":
            assert rec.priority == 0
        if rec.segment == "involuntary":
            assert rec.status == "proposed", "payment reminders are never withheld"
    assert any("sleeping dog" in (r.blocked_reason or "") for r in recs) and any(r.priority == 0 for r in recs)
    # DEF-030: a batch for a NEW date is targeted with the model in force without anybody scoring it by hand
    with session_scope() as s:
        new_batch, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-10-20")
        new_batch_id = new_batch.id
    Worker().drain()
    with session_scope() as s:
        assert experiments.approved_segments(s, demo.tenant_id, date(2026, 10, 20)) == {}
        retention.start_generation(s, admin, new_batch_id)
    Worker().drain()
    with read_session() as s:
        job = s.execute(select(Job).where(Job.job_type == "retention.generate").order_by(Job.id.desc())).scalars().first()
        new_segments = experiments.approved_segments(s, demo.tenant_id, date(2026, 10, 20))
        new_recs = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == new_batch_id)).scalars().all()
        scored_event = s.execute(select(AuditEvent).where(AuditEvent.action == "uplift.scored").order_by(AuditEvent.id.desc())).scalars().first()
    assert job.status == "succeeded" and job.result["uplift"] == {"applied": True, "model_id": model_id, "scored_for_this_batch": True,
                                                                  "note": f"approved uplift model #{model_id} applied"}  # fmt: skip
    assert len(new_segments) > 200 and new_recs and all(r.rationale["uplift_segment"] == new_segments[r.customer_id] for r in new_recs)
    assert any("sleeping dog" in (r.blocked_reason or "") for r in new_recs)
    assert scored_event.actor_label == "system" and scored_event.detail["automatic"] is True and scored_event.detail["as_of_date"] == "2026-10-20"
    assert scored_event.detail["diagnostic"] is False and sum(scored_event.detail["segments"].values()) == len(new_segments)
    # integrity: a modified artefact is refused, and recommendations stop instead of silently ignoring the model
    with read_session() as s:
        path = storage.resolve(s.get(UpliftModel, model_id).artifact_path)
    path.write_bytes(path.read_bytes() + b"\x00")
    with session_scope() as s, pytest.raises(Conflict) as tampered:
        experiments.score(s, scientist, model_id)
    assert tampered.value.code == "artifact_integrity"
    with session_scope() as s:
        third, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-10-21")
        third_id = third.id
    Worker().drain()
    with session_scope() as s:
        retention.start_generation(s, admin, third_id)
    Worker().drain()
    with read_session() as s:
        failed = s.execute(select(Job).where(Job.job_type == "retention.generate").order_by(Job.id.desc())).scalars().first()
        assert s.execute(select(func.count()).select_from(RetentionRecommendation).where(RetentionRecommendation.batch_id == third_id)).scalar_one() == 0
    assert failed.status == "failed" and failed.attempts == 1 and f"the approved uplift model #{model_id} cannot be used" in failed.error
    assert "integrity check" in failed.error
    with session_scope() as s, pytest.raises(Conflict) as no_features:
        experiments.score(s, scientist, model_id, "2020-01-01")
    assert no_features.value.code == "features_missing"


def test_the_uplift_training_frame_is_computed_when_the_store_does_not_hold_the_assignment_date(demo):
    """Customers assigned from a batch that computed its own vectors (a date never materialised) used to give an empty
    training frame: the fit then failed for lack of rows although every outcome was known."""
    scientist = demo.principal("data_scientist")
    experiment_id = _imported_experiment(demo, effect=False)

    def frame():
        with read_session() as s:
            data, treated, retained = experiments._training_frame(s, s.get(Experiment, experiment_id), s.get(FeatureContract, demo.summary["contract_id"]))
        return data.sort_values("customer_id").reset_index(drop=True), int(treated.sum()), int(retained.sum())

    stored, stored_treated, stored_retained = frame()
    assert len(stored) == 217 and stored.shape[1] == 3 + 1 + 84 and 0 < stored_treated < 217
    with session_scope() as s:  # as if 1 October had never been materialised
        assert s.execute(delete(FeatureVector).where(FeatureVector.tenant_id == demo.tenant_id, FeatureVector.as_of_date == date(2026, 10, 1))).rowcount >= 217
    computed, treated, retained = frame()
    pd.testing.assert_frame_equal(computed, stored)  # every value and every column type, for all 84 features
    assert (treated, retained) == (stored_treated, stored_retained)
    with session_scope() as s:
        model = experiments.fit_uplift(s, scientist, experiment_id, demo.summary["contract_id"])
        assert model.metrics["rows"] == 217 and model.metrics["treated"] == stored_treated and model.status == "validation_failed"
        assert s.execute(select(func.count()).select_from(FeatureVector).where(FeatureVector.as_of_date == date(2026, 10, 1))).scalar_one() == 0


def test_an_uplift_model_that_fails_validation_can_never_be_approved_or_used(demo):
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    experiment_id = _imported_experiment(demo, effect=False)
    with session_scope() as s:
        model = experiments.fit_uplift(s, scientist, experiment_id, demo.summary["contract_id"])
        model_id = model.id
        assert model.status == "validation_failed" and model.validation["passed"] is False and model.validation["qini_ci90"][0] <= 0
    with session_scope() as s, pytest.raises(Conflict) as blocked:
        experiments.review_uplift(s, approver, model_id, approve=True)
    assert blocked.value.code == "not_validated"
    with session_scope() as s:
        scored = experiments.score(s, scientist, model_id)
        assert scored["diagnostic"] is True and experiments.approved_segments(s, demo.tenant_id, date(2026, 11, 1)) == {}
        warning = experiments.segment_summary(s, demo.tenant_id, model_id)["warning"]
        assert "did not beat random targeting in validation" in warning and "must not drive targeting" in warning
        assert "artifact_path" not in experiments.uplift_view(s.get(UpliftModel, model_id))
