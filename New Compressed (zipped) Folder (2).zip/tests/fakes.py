"""Stand-ins for systems outside the platform, shared by several test modules."""

from __future__ import annotations

import json
from datetime import datetime
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse


# A paginated, bearer-authenticated customer API (see the ``api_server`` fixture).  ``seen`` records every request,
# ``failures_left`` makes the next requests answer 503, ``/redirect`` answers a redirect that must not be followed.
class RestApi(BaseHTTPRequestHandler):
    pages = [[{"id": "R1", "name": "Rest One", "updated": "2026-01-01T00:00:00Z"}, {"id": "R2", "name": "Rest Two", "updated": "2026-01-02T00:00:00Z"}],
             [{"id": "R3", "name": "Rest Three", "updated": "2026-01-03T00:00:00Z"}]]  # fmt: skip
    seen: list = []
    failures_left = 0

    def do_GET(self):
        url = urlparse(self.path)
        query = {k: v[0] for k, v in parse_qs(url.query).items()}
        RestApi.seen.append((url.path, query, self.headers.get("Authorization")))
        if url.path == "/redirect":
            self.send_response(302)
            self.send_header("Location", "/customers")
            self.end_headers()
            return
        if RestApi.failures_left > 0:
            RestApi.failures_left -= 1
            self.send_response(503)
            self.send_header("Retry-After", "0")
            self.end_headers()
            return
        if self.headers.get("Authorization") != "Bearer rest-secret-token":
            self.send_response(401)
            self.end_headers()
            return
        records = [r for page in RestApi.pages for r in page]
        if "since" in query:
            since = datetime.fromisoformat(query["since"])
            records = [r for r in records if datetime.fromisoformat(r["updated"].replace("Z", "+00:00")) > since]
        page = int(query.get("page", 1))
        body = json.dumps({"data": records[(page - 1) * 2 : page * 2]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


# An OpenID Connect identity provider that lives in an httpx transport (no sockets): discovery document, signing
# keys, token endpoint.  A test drives it by setting what the next ID token should claim; ``calls`` records requests.
class FakeIdp:
    def __init__(self, issuer: str = "https://idp.example", client_id: str = "churn-client") -> None:
        from cryptography.hazmat.primitives.asymmetric import rsa

        self.issuer, self.client_id = issuer, client_id
        self.keys = {"k1": rsa.generate_private_key(public_exponent=65537, key_size=2048)}
        self.signing_kid = "k1"
        self.claims: dict = {}  # overrides for the next ID token
        self.calls: list[tuple[str, str, dict]] = []
        self.expected_code = "good-code"
        self.expected_challenge: str | None = None
        self.nonce: str | None = None
        self.algorithm = "RS256"
        self.discovery_overrides: dict = {}

    @staticmethod
    def b64(data: bytes) -> str:
        import base64

        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    def jwks(self) -> dict:
        out = []
        for kid, key in self.keys.items():
            numbers = key.public_key().public_numbers()
            out.append({"kty": "RSA", "use": "sig", "alg": "RS256", "kid": kid, "n": self.b64(numbers.n.to_bytes((numbers.n.bit_length() + 7) // 8, "big")),
                        "e": self.b64(numbers.e.to_bytes(3, "big"))})  # fmt: skip
        return {"keys": out}

    def rotate_key(self, kid: str) -> None:
        from cryptography.hazmat.primitives.asymmetric import rsa

        self.keys = {kid: rsa.generate_private_key(public_exponent=65537, key_size=2048)}
        self.signing_kid = kid

    def id_token(self, key=None) -> str:
        import time

        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import padding

        now = int(time.time())
        claims = {"iss": self.issuer, "aud": self.client_id, "sub": "subject-1", "email": "sso.user@corp.example", "email_verified": True, "name": "Sso User",
                  "iat": now, "exp": now + 300, "nonce": self.nonce, **self.claims}  # fmt: skip
        header = {"alg": self.algorithm, "typ": "JWT", "kid": self.signing_kid}
        signing_input = f"{self.b64(json.dumps(header).encode())}.{self.b64(json.dumps(claims).encode())}"
        if self.algorithm == "none":
            return signing_input + "."
        signature = (key or self.keys[self.signing_kid]).sign(signing_input.encode(), padding.PKCS1v15(), hashes.SHA256())
        return f"{signing_input}.{self.b64(signature)}"

    def handler(self, request):
        import base64
        import hashlib

        import httpx

        path = request.url.path
        form = dict(parse_qs(request.content.decode())) if request.method == "POST" else {}
        form = {k: v[0] for k, v in form.items()}
        self.calls.append((request.method, path, form))
        if path == "/.well-known/openid-configuration":
            return httpx.Response(200, json={"issuer": self.issuer, "authorization_endpoint": f"{self.issuer}/authorize", "token_endpoint": f"{self.issuer}/token",
                                             "jwks_uri": f"{self.issuer}/keys", "id_token_signing_alg_values_supported": ["RS256"],
                                             "token_endpoint_auth_methods_supported": ["client_secret_basic"], **self.discovery_overrides})  # fmt: skip
        if path == "/keys":
            return httpx.Response(200, json=self.jwks())
        if path == "/token":
            basic = request.headers.get("authorization", "")
            if basic != "Basic " + base64.b64encode(f"{self.client_id}:s3cret-of-the-client".encode()).decode():
                return httpx.Response(401, json={"error": "invalid_client"})
            if form.get("code") != self.expected_code or form.get("grant_type") != "authorization_code":
                return httpx.Response(400, json={"error": "invalid_grant"})
            if self.expected_challenge is not None:
                challenge = self.b64(hashlib.sha256(form.get("code_verifier", "").encode()).digest())
                if challenge != self.expected_challenge:
                    return httpx.Response(400, json={"error": "invalid_grant", "error_description": "PKCE verification failed"})
            return httpx.Response(200, json={"access_token": "at", "token_type": "Bearer", "expires_in": 300, "id_token": self.id_token()})
        return httpx.Response(404, json={"error": "not_found"})

    def transport(self):
        import httpx

        return httpx.MockTransport(self.handler)
