"""The HTTP API: access control for every route, the error envelope, tenant isolation and the write flows."""

from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import re
import time

import pytest
from sqlalchemy import delete, func, select, update

from churn_platform.api import create_app, routes_data
from churn_platform.db import read_session, session_scope
from churn_platform.models import (
    AdoptionRun,
    Alert,
    AuditEvent,
    Base,
    Campaign,
    Correction,
    CRMConnection,
    Customer,
    DataSource,
    DQRun,
    Experiment,
    ExportRun,
    FeatureContract,
    FeatureDefinition,
    IdentityLink,
    IdentityMergeCandidate,
    ImportRun,
    Intervention,
    Job,
    MLDataset,
    ModelRun,
    ModelVersion,
    NotificationMessage,
    NotificationProvider,
    NotificationSuppression,
    NotificationTemplate,
    Policy,
    Prediction,
    ProductFeature,
    QuarantineRecord,
    RetentionRecommendation,
    ReverseEtlRun,
    ReverseEtlSync,
    SentimentAnnotationItem,
    Subscription,
)
from churn_platform.security import ROLE_PERMISSIONS, ROLES
from churn_platform.services import annotations, audit, auth, features, monitoring, notify, quality, retention, sso
from tests.conftest import PASSWORD, activate

API = "/api/v1"
MISSING = "987654321"  # an id that exists in no table

# The access-control contract, one line per operation: who may call it.
#   public = no session (the route authenticates differently), any = every signed-in user, otherwise the permission
#   ("a|b" = either permission is enough).
ACCESS = """
GET    /admin/audit                                               admin:audit
GET    /admin/audit/verify                                        admin:audit
GET    /admin/roles                                               any
GET    /admin/security/identity-providers                         admin:security
POST   /admin/security/identity-providers                         admin:security
DELETE /admin/security/identity-providers/{provider_id}           admin:security
PATCH  /admin/security/identity-providers/{provider_id}           admin:security
POST   /admin/security/identity-providers/{provider_id}/test      admin:security
GET    /admin/security/overview                                   admin:security
GET    /admin/sessions                                            admin:sessions
POST   /admin/sessions/{session_id}/revoke                        admin:sessions
GET    /admin/users                                               admin:users
POST   /admin/users                                               admin:users
PATCH  /admin/users/{user_id}                                     admin:users
GET    /alerts                                                    mlops:read
POST   /alerts/{alert_id}/acknowledge                             mlops:write
POST   /analytics/reports                                         analytics:run
GET    /analytics/reports/latest                                  analytics:read
POST   /auth/login                                                public
POST   /auth/logout                                               any
GET    /auth/me                                                   any
POST   /auth/mfa/begin                                            any
POST   /auth/mfa/confirm                                          any
POST   /auth/mfa/disable                                          any
GET    /auth/oidc/callback                                        public
POST   /auth/oidc/exchange                                        public
GET    /auth/oidc/providers                                       public
GET    /auth/oidc/{provider_id}/start                             public
POST   /auth/password                                             any
POST   /auth/rotate                                               any
GET    /campaigns                                                 notify:read
POST   /campaigns                                                 notify:write
POST   /campaigns/presets                                         notify:write
GET    /campaigns/{campaign_id}                                   notify:read
GET    /campaigns/{campaign_id}/enrollments                       notify:read
GET    /campaigns/{campaign_id}/preview                           notify:read
POST   /campaigns/{campaign_id}/review                            notify:approve
POST   /campaigns/{campaign_id}/start                             notify:approve
POST   /campaigns/{campaign_id}/state                             notify:approve
POST   /campaigns/{campaign_id}/submit                            notify:write
GET    /crm/connections                                           crm:read
POST   /crm/connections                                           crm:write
POST   /crm/connections/{connection_id}/disconnect                crm:write
GET    /crm/connections/{connection_id}/events                    crm:read
POST   /crm/connections/{connection_id}/oauth                     crm:write
POST   /crm/connections/{connection_id}/oauth/start               crm:write
POST   /crm/connections/{connection_id}/sync                      crm:write
GET    /crm/deliveries                                            crm:read
GET    /crm/oauth/callback                                        public
GET    /crm/reverse-etl                                           crm:read
GET    /crm/reverse-etl/runs/{run_id}/download                    customers:export
POST   /crm/reverse-etl/runs/{run_id}/verify                      crm:write
POST   /crm/reverse-etl/syncs                                     crm:write
POST   /crm/reverse-etl/syncs/{sync_id}/enabled                   crm:approve
POST   /crm/reverse-etl/syncs/{sync_id}/review                    crm:approve
POST   /crm/reverse-etl/syncs/{sync_id}/runs                      crm:write
POST   /crm/reverse-etl/syncs/{sync_id}/submit                    crm:write
POST   /crm/webhooks/{connection_id}                              public
GET    /customers                                                 customers:read
GET    /customers/{customer_id}                                   customers:read
POST   /customers/{customer_id}/predict                           predict:run
GET    /data/imports                                              data:read
GET    /data/imports/{run_id}                                     data:read
GET    /data/quarantine                                           data:read
POST   /data/quarantine/review                                    quality:review
GET    /data/schemas                                              data:read
GET    /data/sources                                              data:read
POST   /data/sources                                              data:write
POST   /data/sources/{source_id}/files                            data:write
POST   /data/sources/{source_id}/imports                          data:write
PUT    /data/sources/{source_id}/mapping                          data:write
POST   /data/sources/{source_id}/pull                             data:write
GET    /data/sources/{source_id}/versions                         data:read
GET    /data/summary                                              data:read
POST   /data/webhooks/{source_id}                                 public
GET    /experiments                                               retention:read
POST   /experiments                                               retention:write
POST   /experiments/sample-size                                   retention:read
GET    /experiments/{experiment_id}                               retention:read
POST   /experiments/{experiment_id}/analyse                       retention:write
POST   /experiments/{experiment_id}/assign                        retention:write
POST   /experiments/{experiment_id}/review                        retention:approve
POST   /experiments/{experiment_id}/submit                        retention:write
GET    /exports/backlog                                           customers:read
GET    /exports/destinations                                      customers:read
GET    /exports/overview                                          customers:read
GET    /exports/runs                                              customers:read
POST   /exports/runs                                              customers:export
GET    /exports/runs/{run_id}                                     customers:read
POST   /exports/runs/{run_id}/reconcile                           customers:export
POST   /exports/runs/{run_id}/resume                              customers:export
GET    /features/catalog                                          features:read
GET    /features/contracts                                        features:read
POST   /features/contracts                                        features:write
POST   /features/contracts/{contract_id}/review                   features:approve
POST   /features/materializations                                 features:write
GET    /features/online/{contract_id}/{customer_id}               features:read
GET    /features/runs                                             features:read
GET    /features/store                                            features:read
GET    /jobs                                                      jobs:read
GET    /jobs/active                                               jobs:read
GET    /jobs/{job_id}                                             jobs:read
POST   /jobs/{job_id}/cancel                                      jobs:manage
POST   /jobs/{job_id}/retry                                       jobs:manage
GET    /labels                                                    labels:read
GET    /labels/runs                                               labels:read
POST   /labels/runs                                               labels:write
GET    /labels/summary                                            labels:read
GET    /ml/algorithms                                             ml:read
GET    /ml/datasets                                               ml:read
POST   /ml/datasets                                               ml:train
GET    /ml/datasets/{dataset_id}                                  ml:read
GET    /ml/registry                                               ml:read
POST   /ml/registry                                               ml:train
GET    /ml/registry/gates                                         ml:read
GET    /ml/registry/mlflow                                        mlops:read
POST   /ml/registry/{version_id}/review                           ml:approve
POST   /ml/registry/{version_id}/stage                            ml:train
GET    /ml/registry/{version_id}/transitions                      ml:read
POST   /ml/registry/{version_id}/validate                         ml:train
GET    /ml/runs                                                   ml:read
GET    /ml/runs/{run_id}                                          ml:read
POST   /ml/runs/{run_id}/evaluate                                 ml:train
POST   /ml/runs/{run_id}/explain                                  ml:train
POST   /ml/training                                               ml:train
GET    /monitoring/latest                                         mlops:read
GET    /monitoring/reports                                        mlops:read
POST   /monitoring/runs                                           mlops:write
GET    /notifications                                             notify:read
GET    /notifications/messages                                    notify:read
POST   /notifications/messages                                    notify:write
POST   /notifications/messages/{message_id}/read                  notify:write
POST   /notifications/providers                                   notify:write
POST   /notifications/providers/{provider_id}/mode                notify:approve
POST   /notifications/suppressions/{suppression_id}/lift          notify:approve
POST   /notifications/templates                                   notify:write
POST   /notifications/templates/{template_id}/review              notify:approve
POST   /notifications/templates/{template_id}/submit              notify:write
GET    /notifications/unsubscribe                                 public
POST   /notifications/webhooks/{provider_id}                      public
GET    /pipeline                                                  mlops:read
GET    /pipeline/orchestration                                    jobs:read
POST   /pipeline/runs                                             mlops:write
PUT    /pipeline/schedule                                         mlops:write
GET    /policies                                                  any
POST   /policies                                                  policy:write
GET    /policies/defaults/{kind}                                  any
POST   /policies/{policy_id}/review                               policy:approve
POST   /policies/{policy_id}/submit                               policy:write
GET    /predictions/batches                                       predict:read
POST   /predictions/batches                                       predict:run
GET    /predictions/batches/{batch_id}                            predict:read
GET    /predictions/batches/{batch_id}/export.csv                 customers:export
GET    /predictions/batches/{batch_id}/predictions                predict:read
GET    /predictions/{prediction_id}/explanation                   predict:read
GET    /quality/corrections                                       quality:read
POST   /quality/corrections                                       quality:write
POST   /quality/corrections/{correction_id}/review                quality:review
GET    /quality/rules                                             quality:read
GET    /quality/runs                                              quality:read
POST   /quality/runs                                              quality:write
GET    /quality/runs/{run_id}/findings                            quality:read
GET    /retention/interventions                                   retention:read
POST   /retention/interventions/{intervention_id}/outcome         retention:write
GET    /retention/recommendations                                 retention:read
POST   /retention/recommendations/generate                        retention:write
POST   /retention/recommendations/{recommendation_id}/execute     retention:write
POST   /retention/recommendations/{recommendation_id}/review      retention:write|retention:approve
GET    /signals/adoption                                          signals:read
POST   /signals/adoption/runs                                     signals:write
GET    /signals/adoption/runs/{run_id}                            signals:read
GET    /signals/adoption/runs/{run_id}/facts                      signals:read
GET    /signals/attributes                                        signals:read
GET    /signals/attributes/customers/{customer_id}                signals:read
POST   /signals/attributes/customers/{customer_id}                signals:approve
GET    /signals/catalog                                           signals:read
POST   /signals/catalog                                           signals:write
POST   /signals/catalog/{feature_id}/active                       signals:approve
POST   /signals/catalog/{feature_id}/review                       signals:approve
POST   /signals/catalog/{feature_id}/submit                       signals:write
GET    /signals/identity                                          signals:read
POST   /signals/identity/candidates/{candidate_id}/review         signals:approve
GET    /signals/identity/links                                    signals:read
POST   /signals/identity/links/import                             signals:write
POST   /signals/identity/links/{link_id}/status                   signals:approve
POST   /signals/identity/merge                                    signals:approve
POST   /signals/identity/reconciliations                          signals:write
POST   /signals/identity/unmerge                                  signals:approve
GET    /signals/sentiment                                         signals:read
GET    /signals/sentiment/annotation-batches                      signals:read
POST   /signals/sentiment/annotation-batches                      signals:write
GET    /signals/sentiment/annotation-batches/{batch_id}           signals:read
GET    /signals/sentiment/annotation-batches/{batch_id}/agreement signals:read
GET    /signals/sentiment/annotation-batches/{batch_id}/disagreements-with-model signals:read
GET    /signals/sentiment/annotation-batches/{batch_id}/export    signals:read
GET    /signals/sentiment/annotation-batches/{batch_id}/items     signals:read
POST   /signals/sentiment/annotation-batches/{batch_id}/adjudications signals:approve
POST   /signals/sentiment/annotation-batches/{batch_id}/evaluate  signals:write
POST   /signals/sentiment/annotation-batches/{batch_id}/freeze    signals:approve
POST   /signals/sentiment/annotation-batches/{batch_id}/labels    signals:annotate
POST   /signals/sentiment/analyse                                 signals:write
POST   /signals/sentiment/evaluations                             signals:write
POST   /signals/sentiment/runs                                    signals:write
GET    /signals/sentiment/scores                                  signals:read
GET    /system/info                                               any
GET    /uplift/models                                             retention:read
POST   /uplift/models                                             ml:train
POST   /uplift/models/{model_id}/review                           ml:approve
POST   /uplift/models/{model_id}/score                            ml:train
GET    /uplift/models/{model_id}/segments                         retention:read
"""
OPERATIONS = [tuple(line.split()) for line in ACCESS.strip().splitlines()]


def _url(path: str, value: str = MISSING) -> str:
    return API + re.sub(r"\{[a-z_]+\}", value, path)


def _error(response, status: int, code: str) -> dict:
    """Assert the standard error envelope and return its ``error`` object."""
    assert response.status_code == status, response.text
    body = response.json()
    assert set(body) == {"error"} and set(body["error"]) == {"code", "message", "details", "correlation_id"}, body
    assert body["error"]["code"] == code, body
    assert body["error"]["correlation_id"] == response.headers["X-Correlation-ID"]
    return body["error"]


def _audit(action: str) -> list[AuditEvent]:
    with read_session() as s:
        return list(s.execute(select(AuditEvent).where(AuditEvent.action == action).order_by(AuditEvent.id)).scalars())


def _jobs(job_type: str) -> int:
    with read_session() as s:
        return s.execute(select(func.count()).select_from(Job).where(Job.job_type == job_type)).scalar_one()


# ----------------------------------------------------------------------------- access control
@pytest.mark.req("REQ-SEC-02")
def test_every_operation_of_the_api_has_a_declared_access_rule():
    actual = {(method.upper(), path[len(API):]) for path, item in create_app().openapi()["paths"].items() for method in item}
    declared = {(method, path) for method, path, _ in OPERATIONS}
    assert declared == actual, f"undeclared: {sorted(actual - declared)}; gone: {sorted(declared - actual)}"
    assert len(OPERATIONS) == len(declared) == 210
    permissions = {permission for _, _, rule in OPERATIONS for permission in rule.split("|")} - {"public", "any"}
    assert permissions <= set().union(*ROLE_PERMISSIONS.values()), "every rule names a permission that some role can hold"
    # Routes without a session.  Each one authenticates in its own way: a password, a signature, a one-time code,
    # or a state value that only a login started here can know.
    assert {(m, p) for m, p, rule in OPERATIONS if rule == "public"} == {
        ("POST", "/auth/login"), ("POST", "/data/webhooks/{source_id}"),
        ("GET", "/auth/oidc/providers"), ("GET", "/auth/oidc/{provider_id}/start"), ("GET", "/auth/oidc/callback"), ("POST", "/auth/oidc/exchange"),
        ("GET", "/crm/oauth/callback"), ("POST", "/crm/webhooks/{connection_id}"),
        ("POST", "/notifications/webhooks/{provider_id}"), ("GET", "/notifications/unsubscribe"),
    }  # fmt: skip


@pytest.mark.req("REQ-SEC-02")
def test_every_route_enforces_its_permission_for_every_role(demo):
    with demo.client() as c:
        admin = demo.login(c, "admin")
        for role in ("data_engineer", "auditor"):  # the seeded tenant has no user with these roles
            created = c.post(f"{API}/admin/users", headers=admin, json={"email": demo.email(role), "full_name": role, "role": role, "password": PASSWORD})
            assert created.status_code == 201, created.text
        assert set(ROLES) == {"admin", "approver", "data_engineer", "data_scientist", "analyst", "csm", "auditor", "viewer"}
        checked = denied = 0
        for role in ROLES:
            headers = demo.login(c, role)
            for method, path, rule in OPERATIONS:
                if path.startswith("/auth/") or rule == "public":
                    continue  # session routes are exercised in their own tests (logout would end this session)
                body = None if method == "GET" else {}
                response = c.request(method, _url(path), headers=headers, json=body)
                allowed = rule == "any" or any(permission in ROLE_PERMISSIONS[role] for permission in rule.split("|"))
                if allowed:
                    assert response.status_code not in (401, 403), f"{role} holds {rule} but {method} {path} answered {response.status_code}: {response.text}"
                else:
                    error = _error(response, 403, "permission_denied")
                    wanted = " or ".join(f"'{permission}'" for permission in rule.split("|"))
                    assert error["message"] == f"This action requires the {wanted} permission", f"{role} {method} {path}"
                    denied += 1
                checked += 1
    exercised = [op for op in OPERATIONS if not op[1].startswith("/auth/") and op[2] != "public"]
    assert checked == len(ROLES) * len(exercised) and denied > 300, (checked, len(ROLES) * len(exercised), denied)


@pytest.mark.req("REQ-SEC-01")
def test_no_route_answers_without_a_valid_session(demo):
    with demo.client() as c:
        token = demo.login(c, "admin")["Authorization"]
        for method, path, rule in OPERATIONS:
            if rule == "public":
                continue
            attempts = (({}, "unauthorized"), ({"Authorization": token.replace("Bearer", "Basic")}, "unauthorized"),
                        ({"Authorization": "Bearer not-a-session-token"}, "session_invalid"),
                        ({"Authorization": token[:-2] + ("ab" if not token.endswith("ab") else "cd")}, "session_invalid"))  # fmt: skip
            for headers, code in attempts:
                response = c.request(method, _url(path, "1"), headers=headers, json=None if method == "GET" else {})
                _error(response, 401, code)
        # a session cookie or a token in the query string is not a way in
        assert c.get(f"{API}/auth/me", params={"token": token.split()[1], "access_token": token.split()[1]}).status_code == 401
        for name in ("session", "token", "Authorization"):
            c.cookies.set(name, token.split()[1])
        assert c.get(f"{API}/auth/me").status_code == 401, "cookies are ignored, so there is no cross-site request forgery surface"
        c.cookies.clear()
        assert c.get(f"{API}/auth/me", headers={"Authorization": token}).status_code == 200


# ----------------------------------------------------------------------------- errors, headers, health
@pytest.mark.req("REQ-OPS-05")
def test_every_failure_uses_one_error_envelope_with_a_correlation_id(demo, monkeypatch):
    with demo.client() as c:
        h = demo.login(c, "admin")
        assert _error(c.get(f"{API}/customers/{MISSING}", headers=h), 404, "not_found")["message"] == f"Customer {MISSING} was not found"
        assert _error(c.get(f"{API}/no/such/route", headers=h), 404, "not_found")["message"] == "No API route matches /api/v1/no/such/route"
        assert _error(c.delete(f"{API}/customers/1", headers=h), 404, "not_found")["message"] == "No API route matches /api/v1/customers/1"
        assert _error(c.get("/assets/missing.js"), 404, "not_found")["message"] == "File not found"
        # request validation: a list of field / message pairs
        invalid = _error(c.post(f"{API}/auth/login", json={"email": "a@b.example"}), 422, "validation_failed")
        assert invalid["message"] == "The request is not valid" and invalid["details"] == [{"field": "password", "message": "Field required"}]
        unknown = _error(c.post(f"{API}/auth/login", json={"email": "a@b.example", "password": "x", "remember_me": True}), 422, "validation_failed")
        assert unknown["details"] == [{"field": "remember_me", "message": "Extra inputs are not permitted"}], "unknown fields are refused, not ignored"
        assert _error(c.get(f"{API}/customers/abc", headers=h), 422, "validation_failed")["details"][0]["field"] == "path.customer_id"
        broken = c.post(f"{API}/auth/login", content=b'{"email": ', headers={"Content-Type": "application/json"})
        assert _error(broken, 422, "validation_failed")["details"][0]["message"].startswith("JSON decode error")
        # service validation: the service names the field
        kind = _error(c.get(f"{API}/analytics/reports/latest", params={"kind": "bogus"}, headers=h), 422, "validation_failed")
        assert kind["details"] == {"field": "kind"} and kind["message"] == "kind must be one of overview, cohort, survival, profile"
        assert _error(c.get(f"{API}/customers", params={"page_size": 100000}, headers=h), 422, "validation_failed")
        # a state conflict
        with read_session() as s:
            gone = s.execute(select(Subscription.customer_id).where(Subscription.status == "ended").order_by(Subscription.id)).scalars().first()
        conflict = _error(c.post(f"{API}/customers/{gone}/predict", headers=h), 409, "customer_not_active")
        assert conflict["message"] == "this customer has no active subscription, so there is nothing to predict"
        # a caller-supplied correlation id is kept when it is safe to echo, replaced when it is not
        assert c.get(f"{API}/customers/{MISSING}", headers={**h, "X-Correlation-ID": "trace-2026.11_10"}).json()["error"]["correlation_id"] == "trace-2026.11_10"
        for unsafe in ("has space", "x" * 200, "<script>"):
            generated = c.get(f"{API}/auth/me", headers={**h, "X-Correlation-ID": unsafe}).headers["X-Correlation-ID"]
            assert generated != unsafe and re.fullmatch(r"[0-9a-f]{32}", generated)
        # an unexpected failure never leaks internals
        from churn_platform.services import customer360

        def explode(*_args, **_kwargs):
            raise RuntimeError("connection to db.internal:5432 failed for user churn password=hunter2")

        monkeypatch.setattr(customer360, "detail", explode)
        crashed = c.get(f"{API}/customers/1", headers=h)
        error = _error(crashed, 500, "internal_error")
        assert error["message"] == "An unexpected error occurred. Quote the correlation id when reporting it." and error["details"] is None
        assert "hunter2" not in crashed.text and "db.internal" not in crashed.text and "Traceback" not in crashed.text


@pytest.mark.req("REQ-SEC-06")
def test_upload_size_limit_is_enforced_before_and_while_reading_the_body(demo):
    activate(demo.db_path, demo.data_dir, CHURN_MAX_UPLOAD_MB="1")
    row = "customer_id,timestamp,event,feature,duration_seconds,count\n" + "C000001,2026-10-01T10:00:00Z,login,,60,1\n" * 40_000
    assert 1.5e6 < len(row) < 2e6
    with demo.client() as c:
        h = demo.login(c, "admin")
        declared = c.post(f"{API}/data/sources/8/files", headers=h, files={"file": ("big.csv", row * 2, "text/csv")})
        assert _error(declared, 413, "payload_too_large")["message"] == "Request body exceeds 1 MB", "refused from the declared length, before reading"
        counted = c.post(f"{API}/data/sources/8/files", headers=h, files={"file": ("big.csv", row, "text/csv")})
        assert _error(counted, 413, "payload_too_large")["message"] == "File exceeds the 1 MB upload limit", "refused while streaming"
        assert _error(c.post(f"{API}/data/sources/8/files", headers=h, files={"file": ("empty.csv", b"", "text/csv")}), 422, "validation_failed")
        # a body sent in chunks declares no length: the bytes that actually arrive are counted
        boundary = "x-test-boundary"
        head = f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="big.csv"\r\nContent-Type: text/csv\r\n\r\n'.encode()

        def chunks():
            yield head
            for _ in range(48):
                yield b"x" * 65536  # 3 MB in total
            yield f"\r\n--{boundary}--\r\n".encode()

        chunked = c.post(f"{API}/data/sources/8/files", headers={**h, "Content-Type": f"multipart/form-data; boundary={boundary}"}, content=chunks())
        assert "content-length" not in chunked.request.headers and chunked.request.headers["transfer-encoding"] == "chunked"
        assert _error(chunked, 413, "payload_too_large")["message"] == "Request body exceeds 1 MB"
        assert c.get(f"{API}/data/sources/8/versions", headers=h).json()["total"] == 1, "nothing was registered"
    from churn_platform.config import get_settings

    assert list((get_settings().data_dir / "tmp").iterdir()) == [], "rejected uploads leave no temporary file behind"


@pytest.mark.req("REQ-SEC-06")
def test_security_headers_and_caching_rules(demo):
    with demo.client() as c:
        h = demo.login(c, "viewer")
        api, page, script = c.get(f"{API}/auth/me", headers=h), c.get("/"), c.get("/js/app.js")
        for response in (api, page, script, c.get(f"{API}/auth/me")):
            assert response.headers["X-Content-Type-Options"] == "nosniff" and response.headers["Referrer-Policy"] == "no-referrer"
            csp = response.headers["Content-Security-Policy"]
            assert "default-src 'self'" in csp and "script-src 'self';" in csp and "object-src 'none'" in csp and "unsafe" not in csp
            assert "Strict-Transport-Security" not in response.headers, "only sent over HTTPS"
            assert "X-Frame-Options" not in response.headers and "frame-ancestors" not in csp, "framing is allowed by default (embedded preview)"
        assert api.headers["Cache-Control"] == "no-store" and page.headers["Cache-Control"] == "no-cache" == script.headers["Cache-Control"]
        assert page.headers["content-type"].startswith("text/html") and script.headers["content-type"].split(";")[0] in {"text/javascript", "application/javascript"}
        assert c.get("/customers/12").text == page.text, "client-side routes get the single-page app"
        assert c.get("/js/../../../../etc/passwd").status_code in (200, 404) and "root:" not in c.get("/js/%2e%2e/%2e%2e/%2e%2e/etc/passwd").text
        # 1.1.0 (DEF-068): a client that merely says "X-Forwarded-Proto: https" is no longer believed ...
        assert "Strict-Transport-Security" not in c.get(f"{API}/auth/me", headers={**h, "X-Forwarded-Proto": "https"}).headers
        assert c.get("/healthz").json() == {"status": "ok", "version": "1.3.0"} and c.get("/readyz").json() == {"status": "ready", "database": "ok"}
        assert c.get("/api/openapi.json").status_code == 200 and c.get("/api/docs").status_code == 200, "interactive docs outside production"
    # ... the header is sent when the installation is served over HTTPS (tests/test_security_platform.py covers trusted proxies)
    activate(demo.db_path, demo.data_dir, CHURN_FORCE_HTTPS="true")
    with demo.client() as c:
        assert c.get("/healthz").headers["Strict-Transport-Security"] == "max-age=31536000; includeSubDomains"
    activate(demo.db_path, demo.data_dir, CHURN_ALLOW_FRAMING="false")
    with demo.client() as c:
        locked = c.get("/")
        assert locked.headers["X-Frame-Options"] == "DENY" and locked.headers["Content-Security-Policy"].endswith("; frame-ancestors 'none'")


@pytest.mark.req("REQ-OPS-05")
def test_readiness_reports_a_broken_database_and_production_hides_the_docs(demo, tmp_path):
    secret = "k" * 40
    activate("postgresql+psycopg://nobody:nothing@127.0.0.1:1/none", tmp_path / "data", CHURN_ENV="production", CHURN_SECRET_KEY=secret,
             CHURN_ALLOW_FRAMING="false")  # fmt: skip
    with demo.client() as c:
        down = c.get("/readyz")
        assert down.status_code == 503 and down.json() == {"status": "unavailable", "database": "error"}
        assert c.get("/healthz").status_code == 200, "liveness does not depend on the database"
        assert c.get("/api/docs").status_code == 404 and c.get("/api/openapi.json").status_code == 404
        assert secret not in down.text and "nothing" not in down.text


# ----------------------------------------------------------------------------- sessions and accounts
@pytest.mark.req("REQ-SEC-01")
def test_session_lifecycle_over_http(demo):
    new_password = "Another-Passphrase-2026"
    with demo.client() as c:
        login = c.post(f"{API}/auth/login", json={"email": "  ANALYST@demo.example ", "password": PASSWORD}, headers={"User-Agent": "pytest-browser"})
        assert login.status_code == 200 and set(login.json()) == {"token", "expires_at", "user", "mfa_enrollment_required"}
        body = login.json()
        assert body["user"]["email"] == "analyst@demo.example" and body["user"]["role"] == "analyst" and body["mfa_enrollment_required"] is False
        assert not {"password_hash", "mfa_secret_enc", "failed_logins"} & set(body["user"]), "credentials never leave the server"
        h = {"Authorization": f"Bearer {body['token']}"}
        me = c.get(f"{API}/auth/me", headers=h).json()
        assert me["permissions"] == sorted(ROLE_PERMISSIONS["analyst"]) and me["email"] == "analyst@demo.example"
        second = demo.login(c, "analyst")
        # wrong current password, weak new password, then a good one: the other session is revoked, this one survives
        wrong = _error(c.post(f"{API}/auth/password", headers=h, json={"current_password": "nope", "new_password": new_password}), 422, "validation_failed")
        assert wrong["details"] == {"field": "current_password"}
        weak = _error(c.post(f"{API}/auth/password", headers=h, json={"current_password": PASSWORD, "new_password": "short"}), 422, "validation_failed")
        assert weak["details"] == {"field": "new_password"} and "at least 12 characters" in weak["message"]
        assert c.post(f"{API}/auth/password", headers=h, json={"current_password": PASSWORD, "new_password": new_password}).json() == {"ok": True}
        _error(c.get(f"{API}/auth/me", headers=second), 401, "session_revoked")
        assert c.get(f"{API}/auth/me", headers=h).status_code == 200
        _error(c.post(f"{API}/auth/login", json={"email": "analyst@demo.example", "password": PASSWORD}), 401, "invalid_credentials")
        assert c.post(f"{API}/auth/login", json={"email": "analyst@demo.example", "password": new_password}).status_code == 200
        assert c.post(f"{API}/auth/logout", headers=h).json() == {"ok": True}
        _error(c.get(f"{API}/auth/me", headers=h), 401, "session_revoked")
        _error(c.post(f"{API}/auth/logout", headers=h), 401, "session_revoked")
        # the admin sees the sessions (never the token) and the trail
        admin = demo.login(c, "admin")
        sessions = c.get(f"{API}/admin/sessions", headers=admin).json()["items"]
        assert all("token_hash" not in s and "token" not in s for s in sessions)
        first = next(s for s in sessions if s["user_agent"] == "pytest-browser")
        assert first["revoked_reason"] == "logout" and first["auth_method"] == "password"
        trail = c.get(f"{API}/admin/audit", headers=admin, params={"action": "auth.", "page_size": 100}).json()["items"]
        assert [e["action"] for e in reversed(trail)][:4] == ["auth.login", "auth.login", "auth.login_failed", "auth.login"]
        assert {e["action"] for e in trail} == {"auth.login", "auth.login_failed", "auth.logout"}
        assert all(body["token"] not in str(e) and PASSWORD not in str(e) and new_password not in str(e) for e in trail)
        verified = c.get(f"{API}/admin/audit/verify", headers=admin).json()
        assert verified["valid"] is True and verified["checked"] == verified["total"] > 50


@pytest.mark.req("REQ-SEC-01")
def test_wrong_credentials_lockout_and_rate_limit_over_http(demo, monkeypatch):
    with demo.client() as c:
        unknown = _error(c.post(f"{API}/auth/login", json={"email": "nobody@demo.example", "password": PASSWORD}), 401, "invalid_credentials")
        wrong = _error(c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": "wrong"}), 401, "invalid_credentials")
        assert unknown["message"] == wrong["message"] == "Invalid email or password", "the answer does not reveal whether the account exists"
        for _ in range(4):
            _error(c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": "wrong"}), 401, "invalid_credentials")
        locked = _error(c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": PASSWORD}), 401, "account_locked")
        assert locked["message"] == "Account is temporarily locked after repeated failed sign-ins"
        # an administrator resets the password, which lifts the lock
        admin = demo.login(c, "admin")
        users = {u["email"]: u for u in c.get(f"{API}/admin/users", headers=admin).json()["items"]}
        viewer = users[demo.email("viewer")]
        assert viewer["locked_until"] is not None and "failed_logins" not in viewer
        reset = c.patch(f"{API}/admin/users/{viewer['id']}", headers=admin, json={"password": "Reset-Passphrase-2026"})
        assert reset.status_code == 200 and reset.json()["locked_until"] is None
        assert c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": "Reset-Passphrase-2026"}).status_code == 200
    # the per-address limiter stops a guessing loop long before passwords can be enumerated
    activate(demo.db_path, demo.data_dir, CHURN_RATE_LIMIT_LOGIN_PER_MINUTE="3")
    from churn_platform.models import RateLimitCounter
    from churn_platform.services import ratelimit

    monkeypatch.setattr(ratelimit, "WINDOW_SECONDS", 10**9)  # one window for the whole test: no minute boundary in between
    with session_scope() as s:
        s.execute(delete(RateLimitCounter))  # the attempts above were counted too
    with demo.client() as c:
        for _ in range(3):
            _error(c.post(f"{API}/auth/login", json={"email": "nobody@demo.example", "password": "x"}), 401, "invalid_credentials")
        limited = _error(c.post(f"{API}/auth/login", json={"email": demo.email("admin"), "password": PASSWORD}), 429, "rate_limited")
        assert limited["message"] == "Too many sign-in attempts; wait a minute and try again"
        failed = _audit("auth.login_failed")
        assert len(failed) == 10 and {e.detail["reason"] for e in failed} == {"unknown_user", "bad_password", "locked"}


@pytest.mark.req("REQ-SEC-01")
def test_multi_factor_enrolment_and_a_role_that_requires_it(demo):
    from churn_platform.security import totp_code

    with demo.client() as c:
        h, elsewhere = demo.login(c, "approver"), demo.login(c, "approver")
        begin = c.post(f"{API}/auth/mfa/begin", headers=h).json()
        assert set(begin) == {"secret", "otpauth_uri"} and begin["otpauth_uri"].startswith("otpauth://totp/") and begin["secret"] in begin["otpauth_uri"]
        bad = _error(c.post(f"{API}/auth/mfa/confirm", headers=h, json={"code": "000000"}), 422, "validation_failed")
        assert bad["details"] == {"field": "code"}
        assert c.post(f"{API}/auth/mfa/confirm", headers=h, json={"code": totp_code(begin["secret"])}).json() == {"ok": True}
        # the session that proved the code stays; a session opened elsewhere with the password alone does not
        assert c.get(f"{API}/auth/me", headers=h).json()["mfa_enabled"] is True
        _error(c.get(f"{API}/auth/me", headers=elsewhere), 401, "session_revoked")
        _error(c.post(f"{API}/auth/mfa/begin", headers=h), 409, "conflict")
        # from now on the password alone is not enough, and a used code cannot be replayed
        credentials = {"email": demo.email("approver"), "password": PASSWORD}
        assert _error(c.post(f"{API}/auth/login", json=credentials), 401, "mfa_required")["message"] == "A one-time code is required"
        _error(c.post(f"{API}/auth/login", json={**credentials, "otp": totp_code(begin["secret"])}), 401, "invalid_credentials")
        fresh = totp_code(begin["secret"], at=time.time() + 30)
        with_code = c.post(f"{API}/auth/login", json={**credentials, "otp": fresh})
        assert with_code.status_code == 200 and with_code.json()["user"]["mfa_enabled"] is True
        assert begin["secret"] not in with_code.text and "mfa_secret_enc" not in with_code.text
        _error(c.post(f"{API}/auth/mfa/disable", headers=h, json={"password": "wrong"}), 422, "validation_failed")
        assert c.post(f"{API}/auth/mfa/disable", headers=h, json={"password": PASSWORD}).json() == {"ok": True}
        assert c.post(f"{API}/auth/login", json=credentials).status_code == 200
    assert [e.action for e in _audit("user.mfa_enabled") + _audit("user.mfa_disabled")] == ["user.mfa_enabled", "user.mfa_disabled"]
    assert _audit("user.mfa_enabled")[0].detail == {"other_sessions_revoked": 1}
    # a role for which MFA is mandatory can sign in, but can do nothing except enrol
    activate(demo.db_path, demo.data_dir, CHURN_MFA_REQUIRED_ROLES="admin")
    with demo.client() as c:
        login = c.post(f"{API}/auth/login", json={"email": demo.email("admin"), "password": PASSWORD}).json()
        assert login["mfa_enrollment_required"] is True
        h = {"Authorization": f"Bearer {login['token']}"}
        gate = _error(c.get(f"{API}/admin/users", headers=h), 403, "mfa_enrollment_required")
        assert gate["message"] == "Multi-factor authentication must be set up before this account can be used"
        _error(c.post(f"{API}/pipeline/runs", headers=h), 403, "mfa_enrollment_required")
        assert c.get(f"{API}/auth/me", headers=h).json()["mfa_enrollment_required"] is True
        secret = c.post(f"{API}/auth/mfa/begin", headers=h).json()["secret"]
        assert c.post(f"{API}/auth/mfa/confirm", headers=h, json={"code": totp_code(secret)}).status_code == 200
        assert c.get(f"{API}/admin/users", headers=h).status_code == 200, "enrolled: the same session may now work"
        enrolled = c.post(f"{API}/auth/login", json={"email": demo.email("admin"), "password": PASSWORD, "otp": totp_code(secret, at=time.time() + 30)})
        assert enrolled.json()["mfa_enrollment_required"] is False
        assert c.get(f"{API}/admin/users", headers={"Authorization": f"Bearer {enrolled.json()['token']}"}).status_code == 200


@pytest.mark.req("REQ-SEC-02")
def test_user_administration_over_http(demo):
    with demo.client() as c:
        admin = demo.login(c, "admin")
        payload = {"email": "New.Hire@demo.example", "full_name": " New Hire ", "role": "csm", "password": "Welcome-Passphrase-2026"}
        created = c.post(f"{API}/admin/users", headers=admin, json=payload)
        assert created.status_code == 201
        user = created.json()
        assert (user["email"], user["full_name"], user["role"], user["is_active"], user["mfa_enabled"]) == ("new.hire@demo.example", "New Hire", "csm", True, False)
        assert "password" not in created.text.replace("password_changed_at", "") and user["permissions"] == sorted(ROLE_PERMISSIONS["csm"])
        assert _error(c.post(f"{API}/admin/users", headers=admin, json=payload), 409, "conflict")["message"] == "a user with this email already exists"
        for change, field in (({"role": "superuser"}, "role"), ({"password": "weak"}, "password"), ({"email": "no-at-sign"}, "email")):
            assert _error(c.post(f"{API}/admin/users", headers=admin, json={**payload, "email": "x@demo.example", **change}), 422, "validation_failed")["details"] == {"field": field}
        hire = {"Authorization": "Bearer " + c.post(f"{API}/auth/login", json={"email": payload["email"], "password": payload["password"]}).json()["token"]}
        assert c.get(f"{API}/customers", headers=hire).status_code == 200
        _error(c.get(f"{API}/ml/runs", headers=hire), 403, "permission_denied")
        # a role change takes effect at once: the old session is revoked and the next one carries the new permissions
        promoted = c.patch(f"{API}/admin/users/{user['id']}", headers=admin, json={"role": "data_scientist"})
        assert promoted.json()["role"] == "data_scientist"
        _error(c.get(f"{API}/customers", headers=hire), 401, "session_revoked")
        hire = {"Authorization": "Bearer " + c.post(f"{API}/auth/login", json={"email": payload["email"], "password": payload["password"]}).json()["token"]}
        assert c.get(f"{API}/ml/runs", headers=hire).status_code == 200
        # deactivation ends every session and blocks sign-in
        assert c.patch(f"{API}/admin/users/{user['id']}", headers=admin, json={"is_active": False}).json()["is_active"] is False
        _error(c.get(f"{API}/ml/runs", headers=hire), 401, "session_revoked")
        _error(c.post(f"{API}/auth/login", json={"email": payload["email"], "password": payload["password"]}), 401, "invalid_credentials")
        # an administrator cannot lock themselves out or change their own role
        me = c.get(f"{API}/auth/me", headers=admin).json()["id"]
        assert _error(c.patch(f"{API}/admin/users/{me}", headers=admin, json={"is_active": False}), 403, "forbidden")["message"] == "You cannot deactivate yourself"
        assert _error(c.patch(f"{API}/admin/users/{me}", headers=admin, json={"role": "viewer"}), 403, "forbidden")["message"] == "You cannot change your own role"
        _error(c.patch(f"{API}/admin/users/{MISSING}", headers=admin, json={"role": "viewer"}), 404, "not_found")
        # sessions can be revoked one by one
        other = demo.login(c, "csm")
        target = next(s for s in c.get(f"{API}/admin/sessions", headers=admin).json()["items"] if s["revoked_at"] is None and s["user_id"] != me)
        revoked = c.post(f"{API}/admin/sessions/{target['id']}/revoke", headers=admin).json()
        assert revoked["revoked_reason"] == "revoked_by_admin" and "token_hash" not in revoked
        _error(c.get(f"{API}/customers", headers=other), 401, "session_revoked")
        roles = {r["role"]: r["permissions"] for r in c.get(f"{API}/admin/roles", headers=admin).json()["roles"]}
        assert roles == {role: sorted(ROLE_PERMISSIONS[role]) for role in ROLES}
    events = _audit("user.updated")
    assert [e.detail for e in events] == [{"role": ["csm", "data_scientist"], "sessions_revoked": 1}, {"is_active": [True, False], "sessions_revoked": 1}]
    assert _audit("user.created")[-1].detail == {"email": "new.hire@demo.example", "role": "csm"} and len(_audit("auth.session_revoked")) == 1


# ----------------------------------------------------------------------------- governance: policies
def _staff(demo, c, admin: dict, *roles: str) -> list[dict]:
    """Create the roles the seeded tenant has no user for (data_engineer, auditor) and sign them in."""
    headers = []
    for role in roles:
        created = c.post(f"{API}/admin/users", headers=admin, json={"email": demo.email(role), "full_name": role, "role": role, "password": PASSWORD})
        assert created.status_code == 201, created.text
        headers.append(demo.login(c, role))
    return headers


@pytest.mark.req("REQ-GOV-01")
def test_a_policy_takes_effect_only_after_a_second_person_approves_it(demo):
    with demo.client() as c:
        admin, approver, scientist, csm = (demo.login(c, role) for role in ("admin", "approver", "data_scientist", "csm"))
        default = c.get(f"{API}/policies/defaults/risk_policy", headers=csm).json()
        assert default["kind"] == "risk_policy" and default["payload"]["high_risk_top_share"] == 0.1
        assert _error(c.get(f"{API}/policies/defaults/bogus", headers=csm), 422, "validation_failed")["details"] == {"field": "kind"}
        no_default = _error(c.get(f"{API}/policies/defaults/cost_matrix", headers=csm), 422, "validation_failed")
        assert "no default exists" in no_default["message"], "money values are never invented"
        draft = c.post(f"{API}/policies", headers=scientist, json={"kind": "risk_policy", "name": "default", "note": "tighter top tier",
                                                                   "payload": {**default["payload"], "high_risk_top_share": 0.05}})  # fmt: skip
        assert draft.status_code == 201
        policy = draft.json()
        assert (policy["status"], policy["version"], policy["payload"]["high_risk_top_share"]) == ("draft", 2, 0.05)
        bad = _error(c.post(f"{API}/policies", headers=scientist, json={"kind": "risk_policy", "name": "default", "payload": {"high_risk_top_share": 2}}), 422, "validation_failed")
        assert bad["details"] == [{"field": "high_risk_top_share", "message": "Input should be less than 1"}]
        _error(c.post(f"{API}/policies", headers=scientist, json={"kind": "nope", "name": "default", "payload": {}}), 422, "validation_failed")
        _error(c.post(f"{API}/policies", headers=scientist, json={"kind": "risk_policy", "name": "default", "payload": {}, "approved": True}), 422, "validation_failed")
        pid = policy["id"]
        assert "pending" in _error(c.post(f"{API}/policies/{pid}/review", headers=approver, json={"approve": True}), 409, "conflict")["message"]
        assert c.post(f"{API}/policies/{pid}/submit", headers=scientist).json()["status"] == "pending"
        # the draft does not steer anything yet
        active = [p for p in c.get(f"{API}/policies", headers=csm, params={"kind": "risk_policy"}).json()["items"] if p["status"] == "approved"]
        assert [p["version"] for p in active] == [1]
        # the author cannot approve, even when holding the approval permission (admin holds both)
        own = c.post(f"{API}/policies", headers=admin, json={"kind": "risk_policy", "name": "default", "payload": default["payload"]}).json()
        c.post(f"{API}/policies/{own['id']}/submit", headers=admin)
        four_eyes = _error(c.post(f"{API}/policies/{own['id']}/review", headers=admin, json={"approve": True}), 403, "self_approval_forbidden")
        assert four_eyes["message"] == "Four-eyes control: a policy cannot be approved or rejected by its author"
        rejected = c.post(f"{API}/policies/{own['id']}/review", headers=approver, json={"approve": False, "note": "superseded"}).json()
        assert rejected["status"] == "rejected"
        approved = c.post(f"{API}/policies/{pid}/review", headers=approver, json={"approve": True, "note": "agreed in the retention board"}).json()
        assert (approved["status"], approved["review_note"]) == ("approved", "agreed in the retention board") and approved["reviewed_by"] != approved["created_by"]
        listed = c.get(f"{API}/policies", headers=csm, params={"kind": "risk_policy"}).json()
        assert {p["version"]: p["status"] for p in listed["items"]} == {1: "retired", 2: "approved", 3: "rejected"}
        _error(c.post(f"{API}/policies/{pid}/review", headers=approver, json={"approve": True}), 409, "conflict")
        _error(c.post(f"{API}/policies/{MISSING}/submit", headers=scientist), 404, "not_found")
    assert [e.detail["version"] for e in _audit("policy.approved") if e.detail.get("kind") == "risk_policy"][-1] == 2


# ----------------------------------------------------------------------------- jobs
@pytest.mark.req("REQ-OPS-02")
def test_jobs_can_be_followed_cancelled_and_retried_over_http(demo):
    with demo.client() as c:
        admin, analyst = demo.login(c, "admin"), demo.login(c, "analyst")
        (engineer,) = _staff(demo, c, admin, "data_engineer")
        started = c.post(f"{API}/quality/runs", headers=engineer)
        assert started.status_code == 202
        job, run = started.json()["job"], started.json()["dq_run"]
        assert job["job_type"] == "quality.run" and job["status"] == "queued" and run["status"] == "running" and run["job_id"] == job["id"]
        seen = c.get(f"{API}/jobs/{job['id']}", headers=analyst).json()
        assert (seen["status"], seen["payload"], seen["progress"]) == ("queued", {"dq_run_id": run["id"]}, 0.0)
        active = c.get(f"{API}/jobs/active", headers=analyst).json()
        assert [j["id"] for j in active["items"]] == [job["id"]] and active["scheduled"] == 1, "the seeded campaign step due in three days is scheduled, not active"
        _error(c.post(f"{API}/jobs/{job['id']}/cancel", headers=analyst), 403, "permission_denied")
        cancelled = c.post(f"{API}/jobs/{job['id']}/cancel", headers=engineer).json()
        assert (cancelled["status"], cancelled["cancel_requested"]) == ("cancelled", True)
        assert _error(c.post(f"{API}/jobs/{job['id']}/cancel", headers=engineer), 409, "conflict")["message"] == "job is already cancelled"
        assert demo.drain() is not None and c.get(f"{API}/jobs/{job['id']}", headers=analyst).json()["status"] == "cancelled", "a cancelled job is not run"
        retried = c.post(f"{API}/jobs/{job['id']}/retry", headers=engineer).json()
        assert (retried["status"], retried["attempts"]) == ("queued", 0)
        demo.drain()
        done = c.get(f"{API}/jobs/{job['id']}", headers=analyst).json()
        assert done["status"] == "succeeded" and done["progress"] == 1.0 and done["result"]["dq_run_id"] == run["id"] and done["result"]["rules_evaluated"] == 18
        assert "only failed or cancelled jobs" in _error(c.post(f"{API}/jobs/{job['id']}/retry", headers=engineer), 409, "conflict")["message"]
        assert c.get(f"{API}/jobs/active", headers=analyst).json()["items"] == []
        listed = c.get(f"{API}/jobs", headers=analyst, params={"job_type": "quality.run", "status": "succeeded"}).json()
        assert listed["total"] == 2 and {j["job_type"] for j in listed["items"]} == {"quality.run"}
        assert c.get(f"{API}/jobs", headers=analyst, params={"page_size": 5}).json()["page_size"] == 5
        _error(c.get(f"{API}/jobs/{MISSING}", headers=analyst), 404, "not_found")
        _error(c.post(f"{API}/jobs/{MISSING}/retry", headers=engineer), 404, "not_found")
        # the finished run is visible with its findings and scorecard
        runs = c.get(f"{API}/quality/runs", headers=analyst).json()
        latest = runs["items"][0]
        assert runs["total"] == 2 and latest["id"] == run["id"] and latest["status"] == "completed" and latest["score"] == pytest.approx(0.953409)
        findings = c.get(f"{API}/quality/runs/{run['id']}/findings", headers=analyst).json()
        assert findings["total"] == latest["findings_count"] == 9 and {f["run_id"] for f in findings["items"]} == {run["id"]}
        _error(c.get(f"{API}/quality/runs/{MISSING}/findings", headers=analyst), 404, "not_found")
        assert c.get(f"{API}/quality/rules", headers=analyst).json()["total"] == 18
    assert [e.action for e in _audit("job.cancel_requested") + _audit("job.retried")] == ["job.cancel_requested", "job.retried"]


# ----------------------------------------------------------------------------- data quality: reviewed corrections
@pytest.mark.req("REQ-DATA-04")
def test_a_correction_changes_the_record_only_after_review_by_someone_else(demo):
    with demo.client() as c:
        admin, approver, analyst = (demo.login(c, role) for role in ("admin", "approver", "analyst"))
        (engineer,) = _staff(demo, c, admin, "data_engineer")
        before = c.get(f"{API}/customers/1", headers=analyst).json()["customer"]
        proposal = {"entity_type": "customers", "entity_id": 1, "field": "industry", "new_value": "retail", "reason": "wrong industry in the CRM export"}
        created = c.post(f"{API}/quality/corrections", headers=engineer, json=proposal)
        assert created.status_code == 201
        correction = created.json()
        assert (correction["status"], correction["old_value"], correction["new_value"]) == ("proposed", before["industry"], "retail")
        assert c.get(f"{API}/customers/1", headers=analyst).json()["customer"]["industry"] == before["industry"], "nothing changes before review"
        assert _error(c.post(f"{API}/quality/corrections", headers=engineer, json={**proposal, "reason": "typo"}), 422, "validation_failed")["details"] == [
            {"field": "reason", "message": "String should have at least 5 characters"}]
        # only business fields of business records can be corrected: no ids, no tenant, no keys, no other tables
        for change, field in (({"entity_type": "users"}, "entity_type"), ({"field": "id"}, "field"), ({"field": "tenant_id"}, "field"),
                              ({"field": "external_id"}, "field"), ({"field": "no_such_column"}, "field"), ({"new_value": before["industry"]}, "new_value"),
                              ({"field": "employee_count", "new_value": "many"}, "new_value")):  # fmt: skip
            assert _error(c.post(f"{API}/quality/corrections", headers=engineer, json={**proposal, **change}), 422, "validation_failed")["details"] == {"field": field}, change
        _error(c.post(f"{API}/quality/corrections", headers=engineer, json={**proposal, "entity_id": int(MISSING)}), 404, "not_found")
        _error(c.post(f"{API}/quality/corrections", headers=engineer, json={**proposal, "finding_id": int(MISSING)}), 404, "not_found")
        _error(c.post(f"{API}/quality/corrections/{correction['id']}/review", headers=engineer, json={"approve": True}), 403, "permission_denied")
        # admin proposes and tries to approve the own proposal
        own = c.post(f"{API}/quality/corrections", headers=admin, json={**proposal, "field": "country", "new_value": "DE"}).json()
        four_eyes = _error(c.post(f"{API}/quality/corrections/{own['id']}/review", headers=admin, json={"approve": True}), 403, "self_approval_forbidden")
        assert four_eyes["message"] == "Four-eyes control: a correction cannot be reviewed by the person who proposed it"
        declined = c.post(f"{API}/quality/corrections/{own['id']}/review", headers=approver, json={"approve": False, "note": "country is right"}).json()
        assert declined["status"] == "rejected" and declined["applied_at"] is None
        applied = c.post(f"{API}/quality/corrections/{correction['id']}/review", headers=approver, json={"approve": True, "note": "checked with sales"}).json()
        assert applied["status"] == "applied" and applied["applied_at"] is not None and applied["reviewed_by"] != applied["proposed_by"]
        after = c.get(f"{API}/customers/1", headers=analyst).json()["customer"]
        assert (after["industry"], after["country"]) == ("retail", before["country"])
        _error(c.post(f"{API}/quality/corrections/{correction['id']}/review", headers=approver, json={"approve": True}), 409, "conflict")
        listed = c.get(f"{API}/quality/corrections", headers=analyst, params={"status": "applied"}).json()
        assert listed["total"] == 1 and listed["items"][0]["id"] == correction["id"]
        assert c.get(f"{API}/quality/corrections", headers=analyst).json()["total"] == 2
    assert _audit("dq.correction_applied")[-1].detail["field"] == "industry" and len(_audit("dq.correction_rejected")) == 1


# ----------------------------------------------------------------------------- ingestion over HTTP
NEW_CUSTOMERS = ("customer_id,company,email,industry,employees,acquired_at\n"
                 "N1,New One,ops@n1.example,software,120,2026-10-10\n"
                 "N2,New Two,hello@n2.example,retail,15,2026-10-11\n"
                 "N3,New Three,x@n3.example,retail,abc,2026-10-11\n")  # fmt: skip
NEW_MAPPING = {"external_id": "customer_id", "name": "company", "email": "email", "industry": "industry", "employee_count": "employees", "acquired_at": "acquired_at"}


@pytest.mark.req("REQ-DATA-02")
def test_a_file_travels_from_upload_through_mapping_import_and_quarantine_review(demo):
    with demo.client() as c:
        admin, approver, analyst = (demo.login(c, role) for role in ("admin", "approver", "analyst"))
        (engineer,) = _staff(demo, c, admin, "data_engineer")
        created = c.post(f"{API}/data/sources", headers=engineer, json={"name": "CRM export", "entity_type": "customers", "description": "weekly export"})
        assert created.status_code == 201
        source = created.json()
        assert (source["kind"], source["is_active"], source["webhook_secret_set"]) == ("file", True, False)
        assert _error(c.post(f"{API}/data/sources", headers=engineer, json={"name": "CRM export", "entity_type": "customers"}), 409, "conflict")["message"] == "a source named 'CRM export' already exists"
        assert _error(c.post(f"{API}/data/sources", headers=engineer, json={"name": "x", "entity_type": "nope"}), 422, "validation_failed")["details"] == {"field": "entity_type"}
        sid = source["id"]
        # upload: the client's file name is reduced to its base name; the same bytes are registered once
        uploaded = c.post(f"{API}/data/sources/{sid}/files", headers=engineer, files={"file": ("../../crm export.csv", NEW_CUSTOMERS, "text/csv")})
        assert uploaded.status_code == 201
        version = uploaded.json()["dataset_version"]
        assert uploaded.json()["already_registered"] is False and (version["file_name"], version["version_no"], version["row_count"]) == ("crm export.csv", 1, 3)
        assert [col["name"] for col in uploaded.json()["discovered_schema"]["columns"]] == ["customer_id", "company", "email", "industry", "employees", "acquired_at"]
        again = c.post(f"{API}/data/sources/{sid}/files", headers=engineer, files={"file": ("renamed.csv", NEW_CUSTOMERS, "text/csv")}).json()
        assert again["already_registered"] is True and again["dataset_version"]["id"] == version["id"]
        assert "cannot determine the format" in _error(c.post(f"{API}/data/sources/{sid}/files", headers=engineer, files={"file": ("crm.exe", b"MZ\x00\x00", "application/octet-stream")}), 422, "unreadable_file")["message"]
        _error(c.post(f"{API}/data/sources/{sid}/files", headers=engineer, files={"file": ("empty.csv", b"", "text/csv")}), 422, "validation_failed")
        _error(c.post(f"{API}/data/sources/{MISSING}/files", headers=engineer, files={"file": ("a.csv", "a\n1\n", "text/csv")}), 404, "not_found")
        # mapping: unknown canonical fields and a column the file does not have are refused
        _error(c.put(f"{API}/data/sources/{sid}/mapping", headers=engineer, json={"mapping": {"favourite_colour": "x"}}), 422, "validation_failed")
        c.put(f"{API}/data/sources/{sid}/mapping", headers=engineer, json={"mapping": {**NEW_MAPPING, "external_id": "customer_ref"}})
        missing = _error(c.post(f"{API}/data/sources/{sid}/imports", headers=engineer, json={"dataset_version_id": version["id"]}), 422, "mapped_column_missing")
        assert missing["details"]["missing"] == ["customer_ref"]
        mapped = c.put(f"{API}/data/sources/{sid}/mapping", headers=engineer, json={"mapping": NEW_MAPPING}).json()
        assert mapped["mapping"]["mapping"] == NEW_MAPPING and mapped["mapping"]["version"] >= 2
        assert _error(c.post(f"{API}/data/sources/{sid}/imports", headers=engineer, json={"dataset_version_id": version["id"], "mode": "nope"}), 422, "validation_failed")["details"] == {"field": "mode"}
        _error(c.post(f"{API}/data/sources/{sid}/pull", headers=engineer, json={}), 422, "validation_failed")
        started = c.post(f"{API}/data/sources/{sid}/imports", headers=engineer, json={"dataset_version_id": version["id"]})
        assert started.status_code == 202 and started.json()["import_run"]["status"] == "pending" and started.json()["job"]["job_type"] == "ingest.import"
        run_id = started.json()["import_run"]["id"]
        demo.drain()
        run = c.get(f"{API}/data/imports/{run_id}", headers=analyst).json()
        assert (run["status"], run["rows_read"], run["rows_inserted"], run["rows_quarantined"]) == ("completed", 3, 2, 1)
        assert run["reconciliation"]["balanced"] is True and run["reconciliation"]["accounted_for"] == 3
        _error(c.get(f"{API}/data/imports/{MISSING}", headers=analyst), 404, "not_found")
        assert c.get(f"{API}/customers", headers=analyst, params={"q": "New "}).json()["total"] == 2
        held = c.get(f"{API}/data/quarantine", headers=analyst, params={"entity_type": "customers"}).json()
        assert held["total"] == 1
        record = held["items"][0]
        assert record["reasons"] == ["employee_count: 'abc' is not a number"] and record["payload"]["customer_id"] == "N3" and record["status"] == "open"
        # review needs the reviewer permission (the engineer who loaded the file cannot wave the row through)
        review = f"{API}/data/quarantine/review"
        _error(c.post(review, headers=engineer, json={"ids": [record["id"]], "action": "reject"}), 403, "permission_denied")
        assert _error(c.post(review, headers=approver, json={"ids": [record["id"]], "action": "bless"}), 422, "validation_failed")["details"] == {"field": "action"}
        _error(c.post(review, headers=approver, json={"ids": [int(MISSING)], "action": "reject"}), 404, "not_found")
        _error(c.post(review, headers=approver, json={"ids": [], "action": "reject"}), 422, "validation_failed")
        # exactly what the screen sends: one request that saves the corrected row and loads it
        still = c.post(review, headers=approver, json={"ids": [record["id"]], "action": "reprocess", "corrected": {str(record["id"]): {**record["payload"], "employees": "many"}}}).json()
        assert still == {"rejected": 0, "corrected": 0, "reprocessed": 0, "still_failing": 1}
        pending = c.get(f"{API}/data/quarantine", headers=analyst, params={"entity_type": "customers"}).json()["items"][0]
        assert pending["status"] == "open" and pending["reasons"] == ["employee_count: 'many' is not a number"] and pending["corrected_payload"]["employees"] == "many"
        fixed = c.post(review, headers=approver, json={"ids": [record["id"]], "action": "reprocess", "note": "employee count confirmed by phone",
                                                       "corrected": {str(record["id"]): {**record["payload"], "employees": "40"}}}).json()  # fmt: skip
        assert fixed == {"rejected": 0, "corrected": 0, "reprocessed": 1, "still_failing": 0}
        assert c.get(f"{API}/data/quarantine", headers=analyst, params={"entity_type": "customers"}).json()["total"] == 0
        reprocessed = c.get(f"{API}/data/quarantine", headers=analyst, params={"entity_type": "customers", "status": "reprocessed"}).json()
        assert reprocessed["total"] == 1 and reprocessed["items"][0]["review_note"] == "employee count confirmed by phone"
        _error(c.post(review, headers=approver, json={"ids": [record["id"]], "action": "reject"}), 409, "conflict")
        loaded = c.get(f"{API}/customers", headers=analyst, params={"q": "New Three"}).json()
        assert loaded["total"] == 1
        after = c.get(f"{API}/data/imports/{run_id}", headers=analyst).json()
        assert (after["rows_inserted"], after["rows_quarantined"]) == (3, 0)
        versions = c.get(f"{API}/data/sources/{sid}/versions", headers=analyst).json()
        assert versions["total"] == 1 and versions["items"][0]["checksum_sha256"] == version["checksum_sha256"]
        assert c.get(f"{API}/data/imports", headers=analyst, params={"page_size": 1}).json()["items"][0]["id"] == run_id
        summary = c.get(f"{API}/data/summary", headers=analyst).json()
        assert summary["customers"] == 303 and summary["rows"]["customers"] == 303 and summary["open_quarantine"] == 15
    with read_session() as s:
        new = s.execute(select(Customer).where(Customer.external_id == "N3")).scalar_one()
        assert (new.name, new.employee_count, new.tenant_id) == ("New Three", 40, demo.tenant_id)
    assert _audit("quarantine.reprocess")[-1].detail["reprocessed"] == 1 and _audit("import.started")[-1].detail["source_id"] == sid


@pytest.mark.req("REQ-DATA-03")
def test_a_signed_webhook_is_accepted_once_and_everything_else_is_refused(demo):
    secret = "whsec_0123456789abcdef"
    with demo.client() as c:
        admin = demo.login(c, "admin")
        refused = _error(c.post(f"{API}/data/sources", headers=admin, json={"name": "billing hook", "entity_type": "customers", "kind": "webhook"}), 422, "validation_failed")
        assert refused["details"] == {"field": "webhook_secret"}
        created = c.post(f"{API}/data/sources", headers=admin, json={"name": "billing hook", "entity_type": "customers", "kind": "webhook", "webhook_secret": secret})
        assert created.status_code == 201 and created.json()["webhook_secret_set"] is True and secret not in created.text
        sid = created.json()["id"]
        c.put(f"{API}/data/sources/{sid}/mapping", headers=admin, json={"mapping": {"external_id": "id", "name": "name"}})
        hook = f"{API}/data/webhooks/{sid}"
        body = json.dumps({"event_id": "evt-1", "records": [{"id": "W1", "name": "Webhook One"}]}).encode()
        signature = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        for headers in ({}, {"X-Signature": "sha256=" + "0" * 64}, {"X-Signature": signature[7:]}, {"Authorization": admin["Authorization"]}):
            assert _error(c.post(hook, content=body, headers=headers), 401, "invalid_signature")["message"] == "webhook signature is missing or invalid"
        _error(c.post(hook, content=body + b" ", headers={"X-Signature": signature}), 401, "invalid_signature")
        accepted = c.post(hook, content=body, headers={"X-Signature": signature})
        assert accepted.status_code == 202 and accepted.json()["status"] == "accepted" and accepted.json()["records"] == 1
        duplicate = c.post(hook, content=body, headers={"X-Signature": signature})
        assert duplicate.status_code == 202 and duplicate.json() == {"status": "duplicate", "event_id": accepted.json()["event_id"]}
        # unknown sources and sources of another kind look the same from outside
        file_source = c.post(f"{API}/data/sources", headers=admin, json={"name": "plain file", "entity_type": "customers"}).json()["id"]
        for target in (file_source, MISSING):
            assert _error(c.post(f"{API}/data/webhooks/{target}", content=body, headers={"X-Signature": signature}), 404, "not_found")["message"] == "webhook source not found"
        not_json = b"<xml/>"
        _error(c.post(hook, content=not_json, headers={"X-Signature": "sha256=" + hmac.new(secret.encode(), not_json, hashlib.sha256).hexdigest()}), 422, "validation_failed")
        too_big = b"x" * (routes_data.WEBHOOK_MAX_BYTES + 1)
        _error(c.post(hook, content=too_big, headers={"X-Signature": "sha256=" + hmac.new(secret.encode(), too_big, hashlib.sha256).hexdigest()}), 413, "payload_too_large")
        demo.drain()
        assert c.get(f"{API}/customers", headers=admin, params={"q": "Webhook One"}).json()["total"] == 1
    assert len(_audit("webhook.rejected")) == 5 and _jobs("ingest.webhook_flush") == 1


@pytest.mark.req("REQ-DATA-03")
def test_a_rest_source_is_vetted_at_creation_and_pulled_through_either_route(demo, api_server):
    with demo.client() as c:
        admin, analyst = demo.login(c, "admin"), demo.login(c, "analyst")
        config = {"url": f"{api_server}/customers", "records_path": "data", "pagination": {"type": "page", "page_size": 2},
                  "auth": {"type": "bearer", "secret": "rest-secret-token"}}  # fmt: skip
        body = {"name": "billing api", "entity_type": "customers", "kind": "rest_api", "config": config}
        internal = _error(c.post(f"{API}/data/sources", headers=admin, json=body), 422, "validation_failed")
        assert internal["details"] == {"field": "config.url", "reason": "non_public"} and "non-public address" in internal["message"]
        for url, reason in (("http://169.254.169.254/latest/meta-data", "non_public"), ("http://no-such-host.invalid/x", "unresolvable")):
            assert _error(c.post(f"{API}/data/sources", headers=admin, json={**body, "config": {**config, "url": url}}), 422, "validation_failed")["details"]["reason"] == reason
        _error(c.post(f"{API}/data/sources", headers=admin, json={**body, "config": {**config, "url": "file:///etc/passwd"}}), 422, "validation_failed")
    # the same server is reachable only when the operator allows private hosts (a development setting)
    activate(demo.db_path, demo.data_dir, CHURN_INGEST_ALLOW_PRIVATE_HOSTS="true")
    with demo.client() as c:
        admin, analyst = demo.login(c, "admin"), demo.login(c, "analyst")
        created = c.post(f"{API}/data/sources", headers=admin, json=body)
        assert created.status_code == 201
        source = created.json()
        assert source["config"]["auth"] == {"type": "bearer", "secret_set": True} and "rest-secret-token" not in created.text
        sid = source["id"]
        c.put(f"{API}/data/sources/{sid}/mapping", headers=admin, json={"mapping": {"external_id": "id", "name": "name"}})
        pulled = c.post(f"{API}/data/sources/{sid}/pull", headers=admin, json={})
        assert pulled.status_code == 202 and pulled.json()["job"]["job_type"] == "ingest.rest_pull"
        demo.drain()
        result = c.get(f"{API}/jobs/{pulled.json()['job']['id']}", headers=analyst).json()["result"]
        assert (result["records_fetched"], result["inserted"], result["status"]) == (3, 3, "completed")
        assert c.get(f"{API}/customers", headers=analyst, params={"q": "Rest "}).json()["total"] == 3
        # the generic import route works for a REST source too (it used to answer 500): there is no import run until the pull has fetched something
        via_imports = c.post(f"{API}/data/sources/{sid}/imports", headers=admin, json={})
        assert via_imports.status_code == 202 and via_imports.json()["import_run"] is None and via_imports.json()["job"]["job_type"] == "ingest.rest_pull"
        demo.drain()
        assert c.get(f"{API}/jobs/{via_imports.json()['job']['id']}", headers=analyst).json()["result"]["status"] == "duplicate_payload"
        listed = next(s for s in c.get(f"{API}/data/sources", headers=analyst).json()["items"] if s["id"] == sid)
        assert "rest-secret-token" not in json.dumps(listed) and listed["mapping"]["mapping"] == {"external_id": "id", "name": "name"}
    assert [e.detail["mode"] for e in _audit("import.rest_pull_requested")] == ["full", "full"], "both routes are audited"


# ----------------------------------------------------------------------------- labels, features, analytics
@pytest.mark.req("REQ-ML-01")
def test_labels_features_and_analytics_are_computed_by_jobs_and_read_back(demo):
    with demo.client() as c:
        admin, approver, scientist, analyst, viewer = (demo.login(c, role) for role in ("admin", "approver", "data_scientist", "analyst", "viewer"))
        # labels for one extra date
        started = c.post(f"{API}/labels/runs", headers=scientist, json={"as_of_dates": ["2026-09-15"]})
        assert started.status_code == 202 and started.json()["job"]["job_type"] == "labels.run" and started.json()["label_run"]["as_of_dates"] == ["2026-09-15"]
        assert _error(c.post(f"{API}/labels/runs", headers=scientist, json={"as_of_dates": ["2026-13-45"]}), 422, "validation_failed")["details"] == {"field": "as_of_dates"}
        _error(c.post(f"{API}/labels/runs", headers=scientist, json={"policy_id": int(MISSING)}), 404, "not_found")
        demo.drain()
        run = c.get(f"{API}/labels/runs", headers=viewer, params={"page_size": 1}).json()["items"][0]
        assert run["id"] == started.json()["label_run"]["id"] and run["counts"]["total"] == sum(run["counts"]["by_status"].values()) == 291
        assert sum(run["counts"]["churned_by_type"].values()) == run["counts"]["by_status"]["churned"]
        labels = c.get(f"{API}/labels", headers=viewer, params={"as_of_date": "2026-09-15", "page_size": 500}).json()
        assert labels["total"] == 291 and {item["as_of_date"] for item in labels["items"]} == {"2026-09-15"}
        assert {item["status"] for item in labels["items"]} == {"retained", "churned", "ineligible"} and all(item["horizon_days"] == 30 for item in labels["items"])
        churned = c.get(f"{API}/labels", headers=viewer, params={"as_of_date": "2026-09-15", "status": "churned"}).json()
        assert churned["total"] == run["counts"]["by_status"]["churned"] and all(item["churn_type"] in ("voluntary", "involuntary") for item in churned["items"])
        summary = c.get(f"{API}/labels/summary", headers=viewer).json()
        assert summary["policy"]["kind"] == "churn_definition" and "2026-09-15" in {d["as_of_date"] for d in summary["dates"]}
        # a feature contract: created, reviewed by someone else, then materialised
        catalog = c.get(f"{API}/features/catalog", headers=viewer).json()
        assert catalog["total"] == 84 and {"name", "group", "dtype", "label", "pit_class", "description", "sources"} <= set(catalog["items"][0])
        assert {item["pit_class"] for item in catalog["items"]} == {"event_time", "snapshot", "history"}
        contract = c.post(f"{API}/features/contracts", headers=admin, json={"name": "lean", "features": ["tenure_days", "mrr", "logins_30d"]})
        assert contract.status_code == 201 and (contract.json()["status"], contract.json()["feature_count"], contract.json()["logic_current"]) == ("pending", 3, True)
        cid = contract.json()["id"]
        assert _error(c.post(f"{API}/features/contracts", headers=admin, json={"name": "bad", "features": ["tenure_days", "nope"]}), 422, "validation_failed")["message"] == "unknown features: nope"
        materialise = {"contract_id": cid, "as_of_dates": ["2026-10-01"]}
        _error(c.post(f"{API}/features/materializations", headers=scientist, json=materialise), 409, "contract_not_approved")
        assert _error(c.post(f"{API}/features/contracts/{cid}/review", headers=admin, json={"approve": True}), 403, "self_approval_forbidden")["message"] == (
            "Four-eyes control: a feature contract cannot be reviewed by its author")
        approved = c.post(f"{API}/features/contracts/{cid}/review", headers=approver, json={"approve": True}).json()
        assert approved["status"] == "approved" and approved["reviewed_by"] != approved["created_by"]
        _error(c.post(f"{API}/features/contracts/{cid}/review", headers=approver, json={"approve": False}), 409, "conflict")
        queued = c.post(f"{API}/features/materializations", headers=scientist, json=materialise)
        assert queued.status_code == 202 and queued.json()["job"]["job_type"] == "features.materialize"
        _error(c.post(f"{API}/features/materializations", headers=scientist, json={"contract_id": int(MISSING)}), 404, "not_found")
        demo.drain()
        feature_run = c.get(f"{API}/features/runs", headers=viewer, params={"page_size": 1}).json()["items"][0]
        assert (feature_run["status"], feature_run["row_count"], feature_run["stats"]["features"]) == ("completed", 217, 3)
        store = c.get(f"{API}/features/store", headers=viewer).json()
        assert {"contract_id": cid, "as_of_date": "2026-10-01", "rows": 217} in store["offline"]
        online = c.get(f"{API}/features/online/{cid}/1", headers=viewer).json()
        assert set(online["values"]) == {"tenure_days", "mrr", "logins_30d"} and online["as_of_date"] == "2026-10-01" and online["age_hours"] < 1
        _error(c.get(f"{API}/features/online/{cid}/{MISSING}", headers=viewer), 404, "not_found")
        _error(c.get(f"{API}/features/online/{MISSING}/1", headers=viewer), 404, "not_found")
        assert {item["name"]: item["status"] for item in c.get(f"{API}/features/contracts", headers=viewer).json()["items"]} == {"churn_core": "approved", "lean": "approved"}
        # analytics
        analysis = c.post(f"{API}/analytics/reports", headers=analyst, json={"kind": "survival", "segment": "plan_tier"})
        assert analysis.status_code == 202 and analysis.json()["report"]["title"] == "Survival analysis by plan tier" and "result" not in analysis.json()["report"]
        assert _error(c.post(f"{API}/analytics/reports", headers=analyst, json={"kind": "nope"}), 422, "validation_failed")["details"] == {"field": "kind"}
        _error(c.post(f"{API}/analytics/reports", headers=viewer, json={"kind": "overview"}), 403, "permission_denied")
        demo.drain()
        latest = c.get(f"{API}/analytics/reports/latest", headers=viewer, params={"kind": "survival", "segment": "plan_tier"}).json()
        assert latest["report"]["id"] == analysis.json()["report"]["id"] and latest["report"]["result"]["segment"] == "plan_tier"
        groups = latest["report"]["result"]["groups"]
        assert len(groups) >= 2 and all(g["n"] == g["events"] + g["censored"] and g["curve"][0]["survival"] == 1.0 for g in groups)
        _error(c.get(f"{API}/analytics/reports/latest", headers=viewer, params={"kind": "nope"}), 422, "validation_failed")
    assert _audit("features.contract_approved")[-1].detail == {"name": "lean", "version": 1}


@pytest.mark.req("REQ-ML-02")
def test_reading_the_feature_catalog_writes_only_when_the_registry_is_out_of_date(demo, monkeypatch):
    """DEF-027: every read of the catalog used to take the database write lock."""
    calls = []
    real_sync = features.sync_registry
    monkeypatch.setattr(features, "sync_registry", lambda session: calls.append(1) or real_sync(session))
    with demo.client() as c:
        viewer = demo.login(c, "viewer")
        first = c.get(f"{API}/features/catalog", headers=viewer).json()
        assert first["total"] == 84 and calls == [], "the registry is current: nothing is written"
        assert first["engine_hash"] == features.feature_engine.engine_hash()
        assert {"status", "ended_at", "end_reason"} <= set(first["forbidden_source_columns"]), "columns that reveal the outcome are named as off limits"
        # after an upgrade that changed the feature code, the first read brings the registry up to date, once
        with session_scope() as s:
            s.execute(update(FeatureDefinition).values(code_hash="outdated"))
        refreshed = c.get(f"{API}/features/catalog", headers=viewer).json()
        assert calls == [1] and [item["name"] for item in refreshed["items"]] == [item["name"] for item in first["items"]]
        assert {item["code_hash"] for item in refreshed["items"]} == {first["engine_hash"]}
        assert c.get(f"{API}/features/catalog", headers=viewer).json()["total"] == 84 and calls == [1]
    with read_session() as s:
        assert features.registry_is_current(s) is True


# ----------------------------------------------------------------------------- the model lifecycle
@pytest.mark.req("REQ-ML-06")
def test_a_model_goes_from_dataset_to_production_only_through_evaluation_and_a_second_approver(demo):
    with demo.client() as c:
        admin, approver, scientist, viewer = (demo.login(c, role) for role in ("admin", "approver", "data_scientist", "viewer"))
        built = c.post(f"{API}/ml/datasets", headers=scientist, json={"name": "api-ds", "contract_id": demo.summary["contract_id"]})
        assert built.status_code == 202 and built.json()["dataset"]["status"] == "building" and built.json()["job"]["job_type"] == "ml.build_dataset"
        dataset_id = built.json()["dataset"]["id"]
        _error(c.post(f"{API}/ml/datasets", headers=scientist, json={"name": "x", "contract_id": int(MISSING)}), 404, "not_found")
        not_ready = _error(c.post(f"{API}/ml/training", headers=scientist, json={"dataset_id": dataset_id}), 409, "dataset_not_ready")
        assert not_ready["message"] == "dataset api-ds v1 is not ready (status: building)"
        demo.drain()
        dataset = c.get(f"{API}/ml/datasets/{dataset_id}", headers=viewer).json()
        assert dataset["status"] == "ready" and {k: dataset["row_counts"][k] for k in ("train", "valid", "test")} == {"train": 982, "valid": 395, "test": 424}
        assert dataset["leakage_report"]["passed"] is True and c.get(f"{API}/ml/datasets", headers=viewer).json()["total"] == 2
        _error(c.get(f"{API}/ml/datasets/{MISSING}", headers=viewer), 404, "not_found")
        assert set(c.get(f"{API}/ml/algorithms", headers=viewer).json()["algorithms"]) == {"logistic_regression", "random_forest", "xgboost", "lightgbm"}
        # training
        assert _error(c.post(f"{API}/ml/training", headers=scientist, json={"dataset_id": dataset_id, "algorithms": ["nope"]}), 422, "validation_failed")["details"] == {"field": "algorithms"}
        _error(c.post(f"{API}/ml/training", headers=scientist, json={"dataset_id": dataset_id, "n_iter": 0}), 422, "validation_failed")
        trained = c.post(f"{API}/ml/training", headers=admin, json={"dataset_id": dataset_id, "algorithms": ["logistic_regression"], "n_iter": 1, "cv_folds": 2})
        assert trained.status_code == 202 and [r["algorithm"] for r in trained.json()["runs"]] == ["logistic_regression"]
        run_id = trained.json()["runs"][0]["id"]
        _error(c.post(f"{API}/ml/runs/{run_id}/evaluate", headers=scientist, json={"split": "valid"}), 409, "conflict")  # still training
        demo.drain()
        run = c.get(f"{API}/ml/runs/{run_id}", headers=viewer).json()
        assert run["status"] == "completed" and run["test_evaluated_at"] is None and run["test_metrics"] is None and 0 < run["valid_metrics"]["pr_auc"] <= 1
        ranking = c.get(f"{API}/ml/runs", headers=viewer).json()
        assert ranking["total"] == 5 and ranking["ranking"].startswith("validation PR-AUC")
        _error(c.get(f"{API}/ml/runs/{MISSING}", headers=viewer), 404, "not_found")
        # registration needs a validation evaluation (the operating threshold comes from it)
        _error(c.post(f"{API}/ml/registry", headers=admin, json={"run_id": run_id}), 409, "not_evaluated")
        assert _error(c.post(f"{API}/ml/runs/{run_id}/evaluate", headers=scientist, json={"split": "holdout"}), 422, "validation_failed")["details"] == {"field": "split"}
        validation = c.post(f"{API}/ml/runs/{run_id}/evaluate", headers=scientist, json={"split": "valid"}).json()
        assert validation["split"] == "valid" and validation["metrics"]["n"] == 395 and validation["metrics"]["pr_auc_baseline"] == pytest.approx(validation["metrics"]["base_rate"])
        registered = c.post(f"{API}/ml/registry", headers=admin, json={"run_id": run_id, "name": "churn-model"})
        assert registered.status_code == 201
        version = registered.json()
        assert (version["version"], version["stage"], version["approval_status"], version["threshold_basis"]["selected_on"]) == (2, "none", "pending", "validation split")
        vid = version["id"]
        assert _error(c.post(f"{API}/ml/registry", headers=admin, json={"run_id": run_id}), 409, "conflict")["message"] == "this model run is already registered"
        # promotion gates, in the order they bite
        _error(c.post(f"{API}/ml/registry/{vid}/stage", headers=scientist, json={"stage": "production"}), 409, "model_not_approved")
        _error(c.post(f"{API}/ml/registry/{vid}/review", headers=admin, json={"approve": True}), 403, "self_approval_forbidden")
        _error(c.post(f"{API}/ml/registry/{vid}/review", headers=approver, json={"approve": True}), 409, "test_evaluation_required")
        final = c.post(f"{API}/ml/runs/{run_id}/evaluate", headers=scientist, json={"split": "test"}).json()
        assert final["split"] == "test" and final["metrics"]["n"] == 424
        once = _error(c.post(f"{API}/ml/runs/{run_id}/evaluate", headers=scientist, json={"split": "test"}), 409, "test_already_evaluated")
        assert once["details"] == {"evaluation_id": final["id"]}, "the test split is spent once"
        approved = c.post(f"{API}/ml/registry/{vid}/review", headers=approver, json={"approve": True, "note": "beats nothing, but it is a test"}).json()
        assert approved["approval_status"] == "approved" and approved["reviewed_by"] != approved["created_by"] and approved["stage"] == "none"
        _error(c.post(f"{API}/ml/registry/{vid}/review", headers=approver, json={"approve": False}), 409, "conflict")
        assert _error(c.post(f"{API}/ml/registry/{vid}/stage", headers=scientist, json={"stage": "live"}), 422, "validation_failed")["details"] == {"field": "stage"}
        promoted = c.post(f"{API}/ml/registry/{vid}/stage", headers=scientist, json={"stage": "production"}).json()
        assert promoted["stage"] == "production"
        stages = {v["version"]: (v["stage"], v["approval_status"]) for v in c.get(f"{API}/ml/registry", headers=viewer).json()["items"]}
        assert stages == {1: ("archived", "approved"), 2: ("production", "approved")}, "one production version; the previous one is archived, not deleted"
        # explanations
        explained = c.post(f"{API}/ml/runs/{run_id}/explain", headers=scientist).json()
        assert explained["scope"] == "global" and explained["status"] == "available" and explained["space"] == "log_odds"
        shares = [f["share"] for f in explained["contributions"]["features"]]
        assert shares == sorted(shares, reverse=True) and sum(shares) == pytest.approx(1.0)
        # scoring uses the new production model
        scored = c.post(f"{API}/predictions/batches", headers=scientist, json={"as_of_date": "2026-10-15"})
        assert scored.status_code == 202 and scored.json()["already_exists"] is False and scored.json()["batch"]["model_version_id"] == vid
        repeat = c.post(f"{API}/predictions/batches", headers=scientist, json={"as_of_date": "2026-10-15"}).json()
        assert repeat["already_exists"] is True and repeat["job"] is None and repeat["batch"]["id"] == scored.json()["batch"]["id"]
        assert _error(c.post(f"{API}/predictions/batches", headers=scientist, json={"as_of_date": "2027-01-01"}), 422, "validation_failed")["details"] == {"field": "as_of_date"}
        _error(c.post(f"{API}/predictions/batches", headers=scientist, json={"model_version_id": 1}), 409, "model_not_servable")  # archived
        demo.drain()
        batch = c.get(f"{API}/predictions/batches/{scored.json()['batch']['id']}", headers=viewer).json()
        assert (batch["status"], batch["total"], batch["succeeded"], batch["failed"]) == ("completed", 214, 214, 0)
        assert sum(batch["summary"]["tiers"].values()) == 214 and batch["summary"]["horizon_days"] == 30
    assert [e.detail["to"] for e in _audit("ml.model_stage_changed")][-1] == "production" and _audit("ml.model_approved")[-1].detail["version"] == 2
    spent = _audit("ml.evaluated_test")[-1]
    assert spent.entity_id == str(run_id) and spent.detail["evaluation_id"] == final["id"], "using the test split is on the audit trail"


@pytest.mark.req("REQ-ML-06")
def test_scores_can_be_read_explained_and_exported_and_the_export_is_audited(demo):
    batch_id = demo.summary["batch_id"]
    with demo.client() as c:
        scientist, analyst, viewer, csm = (demo.login(c, role) for role in ("data_scientist", "analyst", "viewer", "csm"))
        batches = c.get(f"{API}/predictions/batches", headers=viewer).json()
        assert batches["total"] == 2 and {b["kind"] for b in batches["items"]} == {"batch", "backtest"}
        _error(c.get(f"{API}/predictions/batches/{MISSING}", headers=viewer), 404, "not_found")
        everything = c.get(f"{API}/predictions/batches/{batch_id}/predictions", headers=viewer, params={"page_size": 500}).json()
        assert everything["total"] == 212 and len(everything["items"]) == 212
        probabilities = [p["probability"] for p in everything["items"]]
        assert probabilities == sorted(probabilities, reverse=True), "highest risk first"
        assert all(0 <= p <= 1 for p in probabilities) and {p["risk_tier"] for p in everything["items"]} == {"high", "medium", "low"}
        high = c.get(f"{API}/predictions/batches/{batch_id}/predictions", headers=viewer, params={"tier": "high"}).json()
        assert high["total"] == 22 and {p["risk_tier"] for p in high["items"]} == {"high"} and all(len(p["top_reasons"]) == 3 for p in high["items"])
        top = high["items"][0]
        explanation = c.get(f"{API}/predictions/{top['id']}/explanation", headers=viewer).json()
        assert explanation["scope"] == "local" and explanation["prediction_id"] == top["id"] and explanation["customer_id"] == top["customer_id"]
        assert explanation["additivity_error"] < 1e-6, "the contributions add up to the model output"
        assert explanation["base_value"] + sum(explanation["contributions"]["values"].values()) == pytest.approx(explanation["output_value"])
        _error(c.get(f"{API}/predictions/{MISSING}/explanation", headers=viewer), 404, "not_found")
        # export: only roles allowed to take customer data out, and every export leaves a trace
        _error(c.get(f"{API}/predictions/batches/{batch_id}/export.csv", headers=viewer), 403, "permission_denied")
        _error(c.get(f"{API}/predictions/batches/{batch_id}/export.csv", headers=csm), 403, "permission_denied")
        assert _audit("predictions.exported") == []
        exported = c.get(f"{API}/predictions/batches/{batch_id}/export.csv", headers=analyst)
        assert exported.status_code == 200 and exported.headers["content-type"] == "text/csv; charset=utf-8"
        assert exported.headers["content-disposition"] == f'attachment; filename="churn-predictions-batch-{batch_id}.csv"'
        rows = list(csv.DictReader(io.StringIO(exported.text)))
        assert len(rows) == 212 and list(rows[0]) == ["user_id", "customer_name", "as_of_date", "churn_probability", "risk_tier", "risk_decile",
                                                      "top_reason_1", "top_reason_2", "top_reason_3", "model_version_id"]  # fmt: skip
        assert rows[0]["user_id"].startswith("C0") and float(rows[0]["churn_probability"]) == pytest.approx(top["probability"], abs=1e-6)
        _error(c.get(f"{API}/predictions/batches/{MISSING}/export.csv", headers=analyst), 404, "not_found")
        # one customer on demand: the customer was scored in the batch, so that prediction is returned rather than a second one
        single = c.post(f"{API}/customers/{top['customer_id']}/predict", headers=scientist).json()
        assert single["id"] == top["id"] and single["probability"] == top["probability"]
        _error(c.post(f"{API}/customers/{MISSING}/predict", headers=scientist), 404, "not_found")
        _error(c.post(f"{API}/customers/{top['customer_id']}/predict", headers=viewer), 403, "permission_denied")
    events = _audit("predictions.exported")
    assert len(events) == 1 and events[0].actor_label == demo.email("analyst")
    assert (events[0].entity_type, events[0].entity_id) == ("prediction_batch", str(batch_id))
    assert events[0].detail["rows"] == 212 and events[0].detail["format"] == "csv" and "churn_probability" in events[0].detail["columns"]


@pytest.mark.req("REQ-AN-01")
def test_customers_can_be_searched_sorted_filtered_and_opened(demo):
    with demo.client() as c:
        csm = demo.login(c, "csm")
        first = c.get(f"{API}/customers", headers=csm, params={"page_size": 25}).json()
        assert (first["total"], first["page"], first["page_size"], len(first["items"])) == (300, 1, 25, 25)
        assert first["batch"] == {"id": demo.summary["batch_id"], "as_of_date": "2026-11-01"}
        scored = [item["probability"] for item in first["items"]]
        assert scored == sorted(scored, reverse=True) and first["items"][0]["risk_tier"] == "high", "the default order puts the highest risk first"
        by_name = c.get(f"{API}/customers", headers=csm, params={"sort": "name", "page_size": 5}).json()["items"]
        assert [item["name"] for item in by_name] == sorted(item["name"] for item in by_name)
        by_id = c.get(f"{API}/customers", headers=csm, params={"sort": "external_id", "page_size": 3}).json()["items"]
        assert [item["external_id"] for item in by_id] == ["C000001", "C000002", "C000003"]
        assert _error(c.get(f"{API}/customers", headers=csm, params={"sort": "password"}), 422, "validation_failed")["details"] == {"field": "sort"}
        found = c.get(f"{API}/customers", headers=csm, params={"q": "C000002"}).json()
        assert found["total"] == 1 and found["items"][0]["external_id"] == "C000002"
        assert c.get(f"{API}/customers", headers=csm, params={"q": "%"}).json()["total"] == 0, "a wildcard typed by a user is searched for literally"
        assert c.get(f"{API}/customers", headers=csm, params={"tier": "high"}).json()["total"] == 22
        last = c.get(f"{API}/customers", headers=csm, params={"page": 12, "page_size": 25}).json()
        assert len(last["items"]) == 25 and c.get(f"{API}/customers", headers=csm, params={"page": 13, "page_size": 25}).json()["items"] == []
        # the customer page
        detail = c.get(f"{API}/customers/{first['items'][0]['id']}", headers=csm).json()
        assert {"customer", "accounts", "subscriptions", "subscription_events", "predictions", "usage", "support", "invoices", "payments",
                "recommendations", "interventions", "labels", "data_cutoff"} == set(detail)  # fmt: skip
        assert detail["customer"]["id"] == first["items"][0]["id"] and detail["predictions"][0]["probability"] == first["items"][0]["probability"]
        _error(c.get(f"{API}/customers/{MISSING}", headers=csm), 404, "not_found")


# ----------------------------------------------------------------------------- retention work queue
def _first(c, headers: dict, **params) -> dict:
    return c.get(f"{API}/retention/recommendations", headers=headers, params={"page_size": 1, **params}).json()["items"][0]


@pytest.mark.req("REQ-ACT-01")
def test_recommendations_are_reviewed_carried_out_and_their_outcome_recorded(demo):
    with demo.client() as c:
        admin, approver, csm, viewer = (demo.login(c, role) for role in ("admin", "approver", "csm", "viewer"))
        queue = c.get(f"{API}/retention/recommendations", headers=viewer, params={"page_size": 200}).json()
        assert queue["total"] == 91 and queue["scope"] == {"mode": "current", "batch_id": demo.summary["batch_id"], "as_of_date": "2026-11-01"}
        assert [item["priority"] for item in queue["items"]] == sorted(item["priority"] for item in queue["items"]), "most urgent first"
        assert queue["summary"]["by_segment"]["high_risk_high_value"] == {"proposed": 4} and queue["summary"]["uplift_model_in_force"] is None
        assert c.get(f"{API}/retention/recommendations", headers=viewer, params={"scope": "all"}).json()["scope"]["mode"] == "all"
        assert _error(c.get(f"{API}/retention/recommendations", headers=viewer, params={"scope": "mine"}), 422, "validation_failed")["details"] == {"field": "scope"}
        _error(c.get(f"{API}/retention/recommendations", headers=viewer, params={"batch_id": MISSING}), 404, "not_found")
        blocked = c.get(f"{API}/retention/recommendations", headers=viewer, params={"status": "blocked"}).json()
        assert blocked["total"] == 3 and all(item["blocked_reason"] for item in blocked["items"])
        # a personal call needs an approver; the success manager cannot approve it, the approver cannot carry it out
        call = _first(c, viewer, segment="high_risk_high_value")
        assert call["rationale"]["requires_human_review"] is True and call["customer_name"].startswith("Synthetic Co")
        review = f"{API}/retention/recommendations/{call['id']}/review"
        _error(c.post(review, headers=viewer, json={"approve": True}), 403, "permission_denied")
        needs_approver = _error(c.post(review, headers=csm, json={"approve": True}), 403, "approval_required")
        assert "retention:approve" in needs_approver["message"]
        _error(c.post(f"{API}/retention/recommendations/{call['id']}/execute", headers=csm, json={}), 409, "not_approved")
        approved = c.post(review, headers=approver, json={"approve": True, "note": "call this week"}).json()
        assert approved["status"] == "approved" and approved["reviewed_at"] is not None
        _error(c.post(f"{API}/retention/recommendations/{call['id']}/execute", headers=approver, json={}), 403, "permission_denied")
        # carried out through the CRM connection (TEST_ONLY: the request is rendered and recorded, nothing is sent)
        connection = c.get(f"{API}/crm/connections", headers=csm).json()["items"][0]
        _error(c.post(f"{API}/retention/recommendations/{call['id']}/execute", headers=csm, json={"connection_id": int(MISSING)}), 404, "not_found")
        done = c.post(f"{API}/retention/recommendations/{call['id']}/execute", headers=csm, json={"connection_id": connection["id"]}).json()
        assert done["recommendation"]["status"] == "executed" and done["crm_delivery_id"] is not None
        assert (done["intervention"]["status"], done["intervention"]["customer_id"], done["intervention"]["action_code"]) == ("queued_for_crm", call["customer_id"], call["action_code"])
        _error(c.post(f"{API}/retention/recommendations/{call['id']}/execute", headers=csm, json={}), 409, "conflict")
        demo.drain()
        delivery = next(d for d in c.get(f"{API}/crm/deliveries", headers=viewer, params={"page_size": 100}).json()["items"] if d["id"] == done["crm_delivery_id"])
        assert (delivery["kind"], delivery["status"], delivery["response"]["sent"]) == ("task", "skipped", False)
        # an automated action is approved by the success manager, then withdrawn before anybody acted on it
        drip = _first(c, viewer, segment="medium_risk_low_value", status="proposed")
        assert drip["rationale"]["requires_human_review"] is False
        own = f"{API}/retention/recommendations/{drip['id']}/review"
        assert c.post(own, headers=csm, json={"approve": True}).json()["status"] == "approved"
        _error(c.post(own, headers=csm, json={"approve": True}), 409, "conflict")
        withdrawn = c.post(own, headers=csm, json={"approve": False, "note": "customer is already in a renewal conversation"}).json()
        assert withdrawn["status"] == "dismissed"
        _error(c.post(f"{API}/retention/recommendations/{drip['id']}/execute", headers=csm, json={}), 409, "not_approved")
        _error(c.post(f"{API}/retention/recommendations/{MISSING}/review", headers=csm, json={"approve": True}), 404, "not_found")
        # a payment reminder without a CRM is recorded for manual follow-up
        reminder = _first(c, viewer, segment="involuntary", status="proposed")
        manual = c.post(f"{API}/retention/recommendations/{reminder['id']}/execute", headers=csm, json={}).json()
        assert manual["crm_delivery_id"] is None and manual["intervention"]["status"] == "recorded" and "nothing was sent" in manual["intervention"]["note"]
        # outcomes
        interventions = c.get(f"{API}/retention/interventions", headers=viewer).json()
        assert interventions["total"] == 2 and {i["customer_name"] for i in interventions["items"]} == {call["customer_name"], reminder["customer_name"]}
        outcome = f"{API}/retention/interventions/{done['intervention']['id']}/outcome"
        assert "outcome must be" in _error(c.post(outcome, headers=csm, json={"outcome": "saved"}), 422, "validation_failed")["message"]
        _error(c.post(outcome, headers=viewer, json={"outcome": "retained"}), 403, "permission_denied")
        recorded = c.post(outcome, headers=csm, json={"outcome": "retained", "note": "renewed after the training session"}).json()
        assert (recorded["outcome"], recorded["note"]) == ("retained", "renewed after the training session") and recorded["outcome_at"] is not None
        _error(c.post(f"{API}/retention/interventions/{MISSING}/outcome", headers=csm, json={"outcome": "churned"}), 404, "not_found")
        summary = c.get(f"{API}/retention/recommendations", headers=viewer, params={"page_size": 1}).json()["summary"]
        assert summary["interventions_by_outcome"] == {"retained": 1, "pending": 1} and "Only a randomised experiment" in summary["note"]
        assert summary["by_segment"]["high_risk_high_value"] == {"executed": 1, "proposed": 3}
        # the customer page shows the action
        page = c.get(f"{API}/customers/{call['customer_id']}", headers=csm).json()
        assert [r["status"] for r in page["recommendations"]] == ["executed"] and [i["outcome"] for i in page["interventions"]] == ["retained"]
        # regenerating keeps every decision that was taken
        generated = c.post(f"{API}/retention/recommendations/generate", headers=csm, json={"batch_id": demo.summary["batch_id"]})
        assert generated.status_code == 202 and generated.json()["job"]["job_type"] == "retention.generate"
        _error(c.post(f"{API}/retention/recommendations/generate", headers=csm, json={"batch_id": int(MISSING)}), 404, "not_found")
        backtest = _error(c.post(f"{API}/retention/recommendations/generate", headers=admin, json={"batch_id": demo.summary["experiment"]["backtest_batch_id"]}), 409, "backtest_batch")
        assert backtest["message"].startswith("a back-test batch scores a past date for evaluation")
        demo.drain()
        after = c.get(f"{API}/retention/recommendations", headers=viewer, params={"page_size": 200}).json()
        statuses = {item["id"]: item["status"] for item in after["items"]}
        assert after["total"] == 91 and (statuses[call["id"]], statuses[drip["id"]], statuses[reminder["id"]]) == ("executed", "dismissed", "executed")
    actions = [e.action for e in _audit("retention.recommendation_approved") + _audit("retention.recommendation_dismissed") + _audit("retention.recommendation_executed")]
    assert actions == ["retention.recommendation_approved"] * 2 + ["retention.recommendation_dismissed"] + ["retention.recommendation_executed"] * 2
    assert _audit("retention.recommendation_dismissed")[0].detail["withdrawn"] is True


# ----------------------------------------------------------------------------- CRM
@pytest.mark.req("REQ-ACT-02")
def test_crm_connections_are_vetted_and_a_sync_queues_each_score_once(demo):
    with demo.client() as c:
        admin, csm, viewer = (demo.login(c, role) for role in ("admin", "csm", "viewer"))
        existing = c.get(f"{API}/crm/connections", headers=viewer).json()
        assert existing["total"] == 1 and existing["providers"] == ["salesforce", "hubspot", "intercom"] and existing["modes"] == ["TEST_ONLY", "SANDBOX", "PRODUCTION"]
        base = {"provider": "salesforce", "name": "SF sandbox", "base_url": "https://example.my.salesforce.com", "mode": "SANDBOX", "access_token": "token-12345678"}
        _error(c.post(f"{API}/crm/connections", headers=csm, json=base), 403, "permission_denied")
        for change, field in (({"provider": "zoho"}, "provider"), ({"mode": "LIVE"}, "mode"), ({"access_token": None}, "access_token"), ({"field_mapping": {"nope": "x"}}, "field_mapping")):
            assert _error(c.post(f"{API}/crm/connections", headers=admin, json={**base, **change}), 422, "validation_failed")["details"] == {"field": field}, change
        # a connection that really transmits must point at a public https host
        for url, reason in (("https://127.0.0.1/", "non_public"), ("https://169.254.169.254/", "non_public"), ("https://no-such-host.invalid/", "unresolvable")):
            refused = _error(c.post(f"{API}/crm/connections", headers=admin, json={**base, "base_url": url}), 422, "validation_failed")
            assert refused["details"] == {"field": "base_url", "reason": reason}, url
        _error(c.post(f"{API}/crm/connections", headers=admin, json={**base, "mode": "PRODUCTION"}), 409, "crm_production_disabled")
        created = c.post(f"{API}/crm/connections", headers=admin, json={"provider": "intercom", "name": "Intercom (test)", "base_url": "https://api.intercom.io", "access_token": "token-12345678"})
        assert created.status_code == 201
        connection = created.json()
        assert (connection["mode"], connection["status"], connection["has_credentials"]) == ("TEST_ONLY", "unverified", True)
        assert "token-12345678" not in created.text and "credentials_enc" not in connection
        _error(c.post(f"{API}/crm/connections", headers=admin, json={"provider": "intercom", "name": "Intercom (test)", "base_url": "https://api.intercom.io"}), 409, "conflict")
        # reverse ETL of the batch output: each score is queued once
        sync = f"{API}/crm/connections/{connection['id']}/sync"
        queued = c.post(sync, headers=admin, json={"batch_id": demo.summary["batch_id"], "tiers": ["high"]})
        assert queued.status_code == 202 and queued.json() == {"queued": 22, "already_queued": 0, "mode": "TEST_ONLY"}
        assert c.post(sync, headers=admin, json={"batch_id": demo.summary["batch_id"], "tiers": ["high"]}).json() == {"queued": 0, "already_queued": 22, "mode": "TEST_ONLY"}
        _error(c.post(sync, headers=admin, json={"batch_id": int(MISSING)}), 404, "not_found")
        _error(c.post(f"{API}/crm/connections/{MISSING}/sync", headers=admin, json={"batch_id": demo.summary["batch_id"]}), 404, "not_found")
        demo.drain()
        deliveries = c.get(f"{API}/crm/deliveries", headers=viewer, params={"page_size": 100}).json()
        mine = [d for d in deliveries["items"] if d["connection_id"] == connection["id"]]
        assert deliveries["total"] == 44 and len(mine) == 22 and {d["status"] for d in mine} == {"skipped"}
        sample = mine[0]
        assert sample["response"]["sent"] is False and sample["response"]["mode"] == "TEST_ONLY" and sample["payload"]["risk_tier"] == "high"
        assert "token-12345678" not in json.dumps(deliveries), "the stored request never contains the credential"
        assert next(x for x in c.get(f"{API}/crm/connections", headers=viewer).json()["items"] if x["id"] == connection["id"])["status"] == "test_only"
    assert [e.detail["queued"] for e in _audit("crm.risk_sync_queued")][-2:] == [22, 0] and _audit("crm.connection_created")[-1].detail["provider"] == "intercom"


# ----------------------------------------------------------------------------- monitoring, alerts, pipeline
@pytest.mark.req("REQ-OPS-03")
def test_monitoring_raises_alerts_under_approved_rules_and_alerts_are_acknowledged_and_resolved(demo):
    rules = {"rules": [{"metric": "feature_drift_share", "operator": ">=", "threshold": 0.2, "severity": "warning"},
                       {"metric": "dq_score_min", "operator": "<", "threshold": 1.0, "severity": "warning"}], "retrain_on": [], "auto_retrain": False}  # fmt: skip
    with demo.client() as c:
        approver, scientist, viewer = (demo.login(c, role) for role in ("approver", "data_scientist", "viewer"))
        assert c.get(f"{API}/alerts", headers=viewer).json()["total"] == 0
        policy = c.post(f"{API}/policies", headers=scientist, json={"kind": "alert_rules", "name": "default", "payload": rules}).json()
        c.post(f"{API}/policies/{policy['id']}/submit", headers=scientist)
        assert c.post(f"{API}/policies/{policy['id']}/review", headers=approver, json={"approve": True}).json()["status"] == "approved"
        started = c.post(f"{API}/monitoring/runs", headers=scientist, json={})
        assert started.status_code == 202 and started.json()["job"]["job_type"] == "monitoring.run"
        _error(c.post(f"{API}/monitoring/runs", headers=viewer, json={}), 403, "permission_denied")
        _error(c.post(f"{API}/monitoring/runs", headers=scientist, json={"model_version_id": int(MISSING)}), 404, "not_found")
        demo.drain()
        result = c.get(f"{API}/jobs/{started.json()['job']['id']}", headers=viewer).json()["result"]
        assert {f["metric"] for f in result["rules_fired"]} == {"feature_drift_share", "dq_score_min"} and result["alerts_created"] == 2
        latest = c.get(f"{API}/monitoring/latest", headers=viewer).json()
        assert set(latest["reports"]) == {"feature", "prediction", "concept"} and latest["production_model"]["stage"] == "production"
        assert latest["reports"]["feature"]["status"] in ("warning", "alert") and latest["reports"]["feature"]["current"]["as_of_date"] == "2026-11-01"
        history = c.get(f"{API}/monitoring/reports", headers=viewer, params={"page_size": 100}).json()
        assert history["total"] == 9 and c.get(f"{API}/monitoring/reports", headers=viewer, params={"kind": "feature"}).json()["total"] == 3
        alerts = c.get(f"{API}/alerts", headers=viewer).json()
        assert alerts["total"] == 2 and {a["kind"] for a in alerts["items"]} == {"rule:feature_drift_share", "rule:dq_score_min"} and {a["status"] for a in alerts["items"]} == {"open"}
        drift = next(a for a in alerts["items"] if a["kind"] == "rule:feature_drift_share")
        assert drift["severity"] == "warning" and drift["title"].startswith("feature drift share >= 0.2 (observed 0.2")
        acknowledge = f"{API}/alerts/{drift['id']}/acknowledge"
        _error(c.post(acknowledge, headers=viewer, json={}), 403, "permission_denied")
        acknowledged = c.post(acknowledge, headers=scientist, json={}).json()
        assert acknowledged["status"] == "acknowledged" and acknowledged["acknowledged_at"] is not None
        assert c.get(f"{API}/alerts", headers=viewer, params={"status": "open"}).json()["total"] == 1
        assert c.post(acknowledge, headers=scientist, json={"resolve": True}).json()["status"] == "resolved"
        assert _error(c.post(acknowledge, headers=scientist, json={}), 409, "conflict")["message"] == "this alert is already resolved"
        _error(c.post(f"{API}/alerts/{MISSING}/acknowledge", headers=scientist, json={}), 404, "not_found")
    assert [e.action for e in _audit("alert.acknowledged") + _audit("alert.resolved")] == ["alert.acknowledged", "alert.resolved"]


@pytest.mark.req("REQ-OPS-04")
def test_the_nightly_pipeline_is_started_once_followed_and_scheduled_over_http(demo):
    with demo.client() as c:
        scientist, viewer = demo.login(c, "data_scientist"), demo.login(c, "viewer")
        status = c.get(f"{API}/pipeline", headers=viewer).json()
        assert status["steps"] == ["data_quality", "signals", "labels", "features", "scoring", "recommendations", "monitoring"] and status["runs"] == []
        assert (status["schedule"]["name"], status["schedule"]["enabled"], status["schedule"]["interval_seconds"]) == ("nightly-pipeline", True, 86400)
        _error(c.post(f"{API}/pipeline/runs", headers=viewer), 403, "permission_denied")
        started = c.post(f"{API}/pipeline/runs", headers=scientist)
        assert started.status_code == 202 and started.json()["already_running"] is False and started.json()["job"]["job_type"] == "pipeline.nightly"
        again = c.post(f"{API}/pipeline/runs", headers=scientist)
        assert again.status_code == 202 and again.json()["already_running"] is True and again.json()["job"]["id"] == started.json()["job"]["id"]
        assert _jobs("pipeline.nightly") == 1
        demo.drain()
        runs = c.get(f"{API}/pipeline", headers=viewer).json()["runs"]
        assert len(runs) == 1 and runs[0]["status"] == "succeeded" and runs[0]["result"]["state"] == "completed"
        assert [(s["step"], s["status"]) for s in runs[0]["result"]["steps"]] == [
            ("data_quality", "succeeded"), ("signals", "succeeded"), ("labels", "succeeded"), ("features", "succeeded"), ("scoring", "skipped"),
            ("recommendations", "succeeded"), ("monitoring", "succeeded")]  # fmt: skip
        assert c.get(f"{API}/jobs/active", headers=viewer).json()["items"] == []
        # schedule
        saved = c.put(f"{API}/pipeline/schedule", headers=scientist, json={"hour_utc": 4, "enabled": False}).json()
        assert saved["enabled"] is False and saved["next_run_at"][11:16] == "04:00"
        assert _error(c.put(f"{API}/pipeline/schedule", headers=scientist, json={"hour_utc": 24}), 422, "validation_failed")["details"] == [
            {"field": "hour_utc", "message": "Input should be less than or equal to 23"}]
        _error(c.put(f"{API}/pipeline/schedule", headers=viewer, json={"hour_utc": 1}), 403, "permission_denied")
        assert c.get(f"{API}/pipeline", headers=viewer).json()["schedule"]["enabled"] is False
    assert len(_audit("pipeline.started")) == 1 and len(_audit("pipeline.completed")) == 1
    assert _audit("pipeline.schedule_saved")[-1].detail == {"hour_utc": 4, "enabled": False}


# ----------------------------------------------------------------------------- experiments and uplift
@pytest.mark.req("REQ-ACT-03")
def test_an_experiment_is_designed_approved_by_a_second_person_assigned_and_analysed(demo):
    with demo.client() as c:
        admin, approver, scientist, csm, viewer = (demo.login(c, role) for role in ("admin", "approver", "data_scientist", "csm", "viewer"))
        size = c.post(f"{API}/experiments/sample-size", headers=viewer, json={"baseline_rate": 0.1, "min_detectable_effect": -0.03}).json()
        assert size == {"control": 1774, "treatment": 1774, "total": 3548}
        _error(c.post(f"{API}/experiments/sample-size", headers=viewer, json={"baseline_rate": 1.5, "min_detectable_effect": -0.03}), 422, "validation_failed")
        design = {"name": "Call vs nothing", "hypothesis": "A personal call reduces churn among high-risk accounts", "baseline_rate": 0.1, "min_detectable_effect": -0.03}
        created = c.post(f"{API}/experiments", headers=admin, json=design)
        assert created.status_code == 201
        experiment = created.json()
        assert (experiment["status"], experiment["origin"], experiment["required_per_arm"], experiment["outcome_window_days"]) == ("draft", "platform", 1774, 30)
        assert "assignment_salt" not in experiment, "the salt that decides the arms is never shown"
        _error(c.post(f"{API}/experiments", headers=admin, json=design), 409, "conflict")
        _error(c.post(f"{API}/experiments", headers=admin, json={**design, "name": "x", "assignment_salt": "chosen-by-me"}), 422, "validation_failed")
        _error(c.post(f"{API}/experiments", headers=viewer, json={**design, "name": "y"}), 403, "permission_denied")
        eid, batch_id = experiment["id"], demo.summary["batch_id"]
        _error(c.post(f"{API}/experiments/{eid}/assign", headers=csm, json={"batch_id": batch_id}), 409, "not_approved")
        _error(c.post(f"{API}/experiments/{eid}/review", headers=approver, json={"approve": True}), 409, "conflict")  # not submitted yet
        assert c.post(f"{API}/experiments/{eid}/submit", headers=admin).json()["status"] == "pending"
        four_eyes = _error(c.post(f"{API}/experiments/{eid}/review", headers=admin, json={"approve": True}), 403, "self_approval_forbidden")
        assert four_eyes["message"] == "Four-eyes control: an experiment cannot be approved or rejected by its author"
        approved = c.post(f"{API}/experiments/{eid}/review", headers=approver, json={"approve": True}).json()
        assert approved["status"] == "approved" and approved["reviewed_by"] != approved["created_by"]
        _error(c.post(f"{API}/experiments/{eid}/assign", headers=csm, json={"batch_id": int(MISSING)}), 404, "not_found")
        assert _error(c.post(f"{API}/experiments/{eid}/assign", headers=csm, json={"batch_id": batch_id, "tiers": ["hgih"]}), 422, "validation_failed")["details"] == {"field": "tiers"}
        assigned = c.post(f"{API}/experiments/{eid}/assign", headers=csm, json={"batch_id": batch_id, "tiers": ["high", "medium"]}).json()
        assignment = assigned["results"]["assignment"]
        assert assigned["status"] == "running" and assignment["treatment"] + assignment["control"] == 85 and assignment["srm"]["status"] == "ok"
        assert assignment["method"] == "sha256(salt:customer_id) < treatment_share" and assignment["as_of_date"] == "2026-11-01"
        assert assignment["excluded_in_other_experiment"] == 0
        # a second experiment cannot enrol the same customers while the first one is running
        second = c.post(f"{API}/experiments", headers=admin, json={**design, "name": "Discount vs nothing"}).json()
        c.post(f"{API}/experiments/{second['id']}/submit", headers=admin)
        c.post(f"{API}/experiments/{second['id']}/review", headers=approver, json={"approve": True})
        overlap = _error(c.post(f"{API}/experiments/{second['id']}/assign", headers=csm, json={"batch_id": batch_id, "tiers": ["high"]}), 409, "conflict")
        assert overlap["message"] == "every customer in the selected risk tiers is already enrolled in another running experiment"
        wider = c.post(f"{API}/experiments/{second['id']}/assign", headers=csm, json={"batch_id": batch_id, "tiers": ["high", "medium", "low"]}).json()["results"]["assignment"]
        assert wider["excluded_in_other_experiment"] == 85 and wider["treatment"] + wider["control"] == 212 - 85
        assert _error(c.post(f"{API}/experiments/{eid}/assign", headers=csm, json={"batch_id": batch_id}), 409, "already_assigned")["message"] == (
            "customers were already assigned to this experiment (status: running); assignment happens once")
        # outcomes are not known yet: the analysis says so instead of reporting a difference
        analysed = c.post(f"{API}/experiments/{eid}/analyse", headers=csm).json()["results"]["analysis"]
        assert (analysed["assigned"], analysed["matured"]) == (85, 0) and analysed["comparison"]["status"] == "insufficient_data"
        assert analysed["notes"][0].startswith("Intention-to-treat")
        shown = c.get(f"{API}/experiments/{eid}", headers=viewer).json()
        assert shown["status"] == "running" and "assignment_salt" not in shown
        assert c.get(f"{API}/experiments", headers=viewer).json()["total"] == 3
        _error(c.get(f"{API}/experiments/{MISSING}", headers=viewer), 404, "not_found")
        # an uplift model needs matured outcomes in both arms
        too_early = _error(c.post(f"{API}/uplift/models", headers=scientist, json={"experiment_id": eid, "contract_id": demo.summary["contract_id"]}), 409, "insufficient_data")
        assert "minimum 100" in too_early["message"]
        assert c.get(f"{API}/uplift/models", headers=viewer).json() == {"items": [], "total": 0}
        for path, body in ((f"/uplift/models/{MISSING}/score", {}), (f"/uplift/models/{MISSING}/review", {"approve": True})):
            _error(c.post(f"{API}{path}", headers=admin, json=body), 404, "not_found")
        _error(c.get(f"{API}/uplift/models/{MISSING}/segments", headers=viewer), 404, "not_found")
    assert [e.entity_id for e in _audit("experiment.approved")][-2:] == [str(eid), str(second["id"])]
    assert [e.detail["batch_id"] for e in _audit("experiment.assigned")][-2:] == [batch_id, batch_id]


# ----------------------------------------------------------------------------- tenant isolation over HTTP
def _fingerprint(tenant_id: int) -> dict[str, str]:
    """Row count and content hash of everything one tenant owns, table by table."""
    out = {}
    with read_session() as s:
        for table in Base.metadata.sorted_tables:
            column = table.c.id if table.name == "tenants" else table.c.get("tenant_id")
            if column is None:
                continue
            digest, rows = hashlib.sha256(), 0
            for row in s.execute(select(table).where(column == tenant_id).order_by(*table.primary_key.columns)):
                digest.update(repr(tuple(row)).encode())
                rows += 1
            out[table.name] = f"{rows}:{digest.hexdigest()}"
    return out


def _owned(model, tenant_id: int, *where) -> int:
    with read_session() as s:
        found = s.execute(select(model.id).where(model.tenant_id == tenant_id, *where).order_by(model.id).limit(1)).scalar_one_or_none()
    assert found is not None, f"the seeded tenant has no {model.__name__}"
    return found


# Bodies that pass request validation, so that the request reaches the ownership check.
BODIES = {
    ("PATCH", "/admin/users/{user_id}"): {"role": "viewer"},
    ("POST", "/policies/{policy_id}/review"): {"approve": True},
    ("PUT", "/data/sources/{source_id}/mapping"): {"mapping": {"external_id": "customer_id"}},
    ("POST", "/quality/corrections/{correction_id}/review"): {"approve": True},
    ("POST", "/features/contracts/{contract_id}/review"): {"approve": True},
    ("POST", "/ml/runs/{run_id}/evaluate"): {"split": "valid"},
    ("POST", "/ml/registry/{version_id}/review"): {"approve": True},
    ("POST", "/ml/registry/{version_id}/stage"): {"stage": "archived"},
    ("POST", "/retention/recommendations/{recommendation_id}/review"): {"approve": True},
    ("POST", "/retention/interventions/{intervention_id}/outcome"): {"outcome": "churned"},
    ("POST", "/crm/connections/{connection_id}/sync"): {"batch_id": 1},
    ("POST", "/experiments/{experiment_id}/review"): {"approve": True},
    ("POST", "/signals/sentiment/annotation-batches/{batch_id}/labels"): {"interaction_id": 1, "label": "neutral"},
    ("POST", "/signals/sentiment/annotation-batches/{batch_id}/adjudications"): {"interaction_id": 1, "label": "neutral"},
    ("POST", "/experiments/{experiment_id}/assign"): {"batch_id": 1},
    ("POST", "/uplift/models/{model_id}/review"): {"approve": True},
    # 1.1.0
    ("POST", "/signals/catalog/{feature_id}/review"): {"approve": True},
    ("POST", "/signals/catalog/{feature_id}/active"): {"active": False},
    ("POST", "/signals/identity/links/{link_id}/status"): {"status": "quarantined"},
    ("POST", "/signals/identity/candidates/{candidate_id}/review"): {"merge": False},
    ("POST", "/signals/attributes/customers/{customer_id}"): {"attribute": "region", "value": "x", "basis": "backfill", "note": "not my customer"},
    ("POST", "/crm/connections/{connection_id}/oauth"): {"client_id": "x", "client_secret": "y"},
    ("POST", "/crm/reverse-etl/syncs/{sync_id}/review"): {"approve": True},
    ("POST", "/crm/reverse-etl/syncs/{sync_id}/enabled"): {"enabled": False},
    ("POST", "/notifications/providers/{provider_id}/mode"): {"mode": "DRY_RUN"},
    ("POST", "/notifications/templates/{template_id}/review"): {"approve": True},
    ("POST", "/notifications/suppressions/{suppression_id}/lift"): {"note": "not mine"},
    ("POST", "/campaigns/{campaign_id}/review"): {"approve": True},
    ("POST", "/campaigns/{campaign_id}/state"): {"action": "pause"},
}
GLOBAL = {"/admin/roles", "/policies/defaults/{kind}", "/system/info", "/data/schemas", "/ml/algorithms", "/features/catalog"}  # the same for every tenant


@pytest.mark.req("REQ-SEC-04")
def test_a_second_tenant_sees_nothing_of_the_first_and_cannot_touch_it(demo):
    tid, admin = demo.tenant_id, demo.principal("admin")
    # give the first tenant one of everything that can be addressed by id
    with session_scope() as s:
        customer_id = s.execute(select(Customer.id).where(Customer.tenant_id == tid).order_by(Customer.id).limit(1)).scalar_one()
        quality.propose_correction(s, admin, entity_type="customers", entity_id=customer_id, field="industry", new_value="isolation-test", reason="object for the isolation test")
        monitoring.raise_alert(s, tid, kind="rule:isolation", severity="info", title="alert for the isolation test", source_type="job", source_id=None, detail={})
        reminder = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.tenant_id == tid, RetentionRecommendation.action_code == "payment_method_reminder",
                                                                   RetentionRecommendation.status == "proposed").order_by(RetentionRecommendation.id).limit(1)).scalar_one()  # fmt: skip
        retention.execute(s, admin, reminder.id)
        # 1.1.0: an identity provider and a suppressed recipient (the seeded tenant has every other new kind of object)
        provider = sso.create_provider(s, admin, {"name": "Isolation SSO", "issuer": "https://idp.isolation.example", "client_id": "x"})
        notify.suppress(s, tid, "email", "someone@isolation.example", reason="manual", source="isolation test")
        assert provider.id == _owned(NotificationProvider, tid), "one id that names an identity provider and a message provider of the first tenant"
        # 1.2.0: a frozen annotation batch - two reviewers agreed on every text, so the owner can open and export it
        batch = annotations.create_batch(s, admin, name="Isolation batch", is_synthetic=True, sample=2)
        for item in s.execute(select(SentimentAnnotationItem).where(SentimentAnnotationItem.batch_id == batch.id)).scalars():
            for reviewer in (admin, demo.principal("analyst")):
                annotations.submit(s, reviewer, batch.id, item.interaction_id, "neutral")
        annotations.freeze(s, admin, batch.id)
        annotation_batch_id = batch.id
        # 1.3.0: a delivery run, so the run-detail route has one id of the first tenant to answer for
        export_run = ExportRun(tenant_id=tid, destination="stand-in", run_id="isolation-export", status="pending")
        s.add(export_run)
        s.flush()
        export_run_id = export_run.id
        rival_id = auth.create_tenant(s, "rival", "Rival Inc").id
        auth.create_user(s, tenant_id=rival_id, email="admin@rival.example", full_name="Rival Admin", role="admin", password=PASSWORD)
    ids = {
        "user_id": admin.user_id, "job_id": _owned(Job, tid), "policy_id": _owned(Policy, tid), "source_id": _owned(DataSource, tid),
        "correction_id": _owned(Correction, tid), "contract_id": _owned(FeatureContract, tid), "customer_id": customer_id, "dataset_id": _owned(MLDataset, tid),
        "version_id": _owned(ModelVersion, tid), "batch_id": demo.summary["batch_id"], "prediction_id": _owned(Prediction, tid),
        "recommendation_id": _owned(RetentionRecommendation, tid, RetentionRecommendation.status == "proposed"), "intervention_id": _owned(Intervention, tid),
        "connection_id": _owned(CRMConnection, tid), "alert_id": _owned(Alert, tid), "experiment_id": _owned(Experiment, tid), "model_id": MISSING, "kind": "risk_policy",
    }  # fmt: skip
    ids.update({"batch_id": annotation_batch_id, "feature_id": _owned(ProductFeature, tid), "link_id": _owned(IdentityLink, tid), "candidate_id": _owned(IdentityMergeCandidate, tid),
                "provider_id": _owned(NotificationProvider, tid), "sync_id": _owned(ReverseEtlSync, tid), "template_id": _owned(NotificationTemplate, tid),
                "message_id": _owned(NotificationMessage, tid), "suppression_id": _owned(NotificationSuppression, tid), "campaign_id": _owned(Campaign, tid)})  # fmt: skip
    run_ids = {"/exports/runs": export_run_id, "/data/imports": _owned(ImportRun, tid), "/quality/runs": _owned(DQRun, tid), "/ml/runs": _owned(ModelRun, tid),
               "/signals/adoption/runs": _owned(AdoptionRun, tid), "/crm/reverse-etl/runs": _owned(ReverseEtlRun, tid)}  # fmt: skip

    def url(path: str) -> str:
        values = {**ids, "run_id": next((v for prefix, v in run_ids.items() if path.startswith(prefix)), MISSING)}
        return API + re.sub(r"\{([a-z_]+)\}", lambda m: str(values[m.group(1)]), path)

    params = {"/analytics/reports/latest": {"kind": "overview"}, "/exports/backlog": {"destination": "stand-in"}}
    by_id = [(m, p) for m, p, rule in OPERATIONS if "{" in p and p not in GLOBAL and rule != "public" and not p.startswith("/auth/")]
    lists = [p for m, p, rule in OPERATIONS if m == "GET" and "{" not in p and p not in GLOBAL and rule != "public" and not p.startswith("/auth/")]
    assert (len(by_id), len(lists)) == (90, 57), "every route that takes an id, and every list, is covered"
    with demo.client() as c:
        owner = demo.login(c, "admin")
        ids["session_id"] = c.get(f"{API}/admin/sessions", headers=owner).json()["items"][0]["id"]
        # control: for their owner the same addresses exist (otherwise a 404 below would prove nothing)
        for method, path in by_id:
            if method == "GET" and "model_id" not in path:
                assert c.get(url(path), headers=owner).status_code == 200, path
        before = _fingerprint(tid)
        rival = {"Authorization": "Bearer " + c.post(f"{API}/auth/login", json={"email": "admin@rival.example", "password": PASSWORD}).json()["token"]}
        assert c.get(f"{API}/auth/me", headers=rival).json()["tenant_id"] == rival_id
        # 1. nothing of the first tenant is listed
        markers = (f'"tenant_id":{tid}', f'"tenant_id": {tid}', "Synthetic", "@demo.example", "C000")
        for path in lists:
            response = c.get(API + path, headers=rival, params=params.get(path))
            assert response.status_code == 200, (path, response.text)
            assert not any(marker in response.text for marker in markers), f"{path} shows another tenant's data: {response.text[:300]}"
            body = response.json()
            if {"total", "items"} <= set(body) and path not in ("/admin/users", "/admin/sessions", "/admin/audit"):
                assert body["total"] == 0 and body["items"] == [], path
        assert c.get(f"{API}/admin/users", headers=rival).json()["total"] == 1 and c.get(f"{API}/customers", headers=rival).json()["batch"] is None
        assert c.get(f"{API}/data/summary", headers=rival).json()["customers"] == 0
        # 2. nothing of the first tenant can be opened or changed by id
        for method, path in by_id:
            if path.endswith("/files"):
                response = c.post(url(path), headers=rival, files={"file": ("a.csv", "customer_id\nX1\n", "text/csv")})
            else:
                response = c.request(method, url(path), headers=rival, json=None if method == "GET" else BODIES.get((method, path), {}))
            _error(response, 404, "not_found")
        # 3. ... nor by naming its ids in a request body
        foreign = [("/ml/datasets", {"name": "x", "contract_id": ids["contract_id"]}), ("/ml/training", {"dataset_id": ids["dataset_id"]}),
                   ("/ml/registry", {"run_id": run_ids["/ml/runs"]}), ("/predictions/batches", {"model_version_id": ids["version_id"]}),
                   ("/retention/recommendations/generate", {"batch_id": ids["batch_id"]}), ("/features/materializations", {"contract_id": ids["contract_id"]}),
                   ("/uplift/models", {"experiment_id": ids["experiment_id"], "contract_id": ids["contract_id"]}), ("/labels/runs", {"policy_id": ids["policy_id"]}),
                   ("/quality/corrections", {"entity_type": "customers", "entity_id": customer_id, "field": "industry", "new_value": "x", "reason": "not my customer"}),
                   ("/data/quarantine/review", {"ids": [_owned(QuarantineRecord, tid)], "action": "reject"}),
                   ("/monitoring/runs", {"model_version_id": ids["version_id"]}),
                   ("/crm/reverse-etl/syncs", {"name": "x", "destination": "crm", "connection_id": ids["connection_id"]}),
                   (f"/crm/reverse-etl/syncs/{MISSING}/runs", {"batch_id": ids["batch_id"]}),
                   ("/notifications/messages", {"customer_id": customer_id, "channel": "email", "template_code": "offer_intro"})]  # fmt: skip
        for path, body in foreign:
            _error(c.post(API + path, headers=rival, json=body), 404, "not_found")
        assert c.get(f"{API}/retention/recommendations", headers=rival, params={"batch_id": ids["batch_id"]}).status_code == 404
        assert c.get(f"{API}/labels", headers=rival, params={"as_of_date": "2026-11-01"}).json()["total"] == 0
        # 4. the same names can be used independently
        twin = c.post(f"{API}/data/sources", headers=rival, json={"name": "Synthetic customers", "entity_type": "customers"})
        assert twin.status_code == 201 and twin.json()["tenant_id"] == rival_id
        c.post(f"{API}/data/sources/{twin.json()['id']}/files", headers=rival, files={"file": ("c.csv", "customer_id,company\nC000001,Rival Customer\n", "text/csv")})
        assert c.post(f"{API}/data/sources/{twin.json()['id']}/imports", headers=rival, json={}).status_code == 202
        demo.drain()
        mine = c.get(f"{API}/customers", headers=rival).json()
        assert mine["total"] == 1 and mine["items"][0]["name"] == "Rival Customer" and mine["items"][0]["external_id"] == "C000001"
        # the audit trail of each tenant is its own
        trail = c.get(f"{API}/admin/audit", headers=rival, params={"page_size": 200}).json()
        assert trail["total"] > 0 and {e["tenant_id"] for e in trail["items"]} == {rival_id} and c.get(f"{API}/admin/audit/verify", headers=rival).json()["valid"] is True
    assert _fingerprint(tid) == before, "not one row of the first tenant changed"
    with read_session() as s:
        assert audit.verify_chain(s, tid)["valid"] is True
        assert s.execute(select(Customer.name).where(Customer.tenant_id == tid, Customer.external_id == "C000001")).scalar_one().startswith("Synthetic Co")
