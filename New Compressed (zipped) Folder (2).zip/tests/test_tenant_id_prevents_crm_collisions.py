"""Tenant identity: two tenants' records must never collide (1.3.0, BUG 3).

The reproduction this file was written from, run against the code as it stood at ``b4fd131``::

    identity(t1) == identity(t2)? True -> C1|m|1|2026-11-05
    tenant_id in the canonical schema? False

The canonical record had no tenant at all, so the identity of a row was ``customer|model|version|day``.  Two things
follow, and both are silent:

* inside one export, two tenants holding the same external customer id were *deduplicated into one record* — the second
  tenant's row vanished, and its probability was replaced by the first's;
* at the warehouse, the MERGE key was ``EXTERNAL_CUSTOMER_ID, MODEL_NAME, MODEL_VERSION, DATA_CUTOFF_TIMESTAMP``, so
  tenant B's export **updated tenant A's row in place**.  Tenant A's business reads a churn probability computed from
  tenant B's data.

There is no way to express that in a test that passes, which is why the reproduction above is a one-line assertion of
equality.  The fix is structural: ``tenant_id`` is the record's first field, it is required, it leads the identity, the
deduplication key, the idempotency key, the primary key and the MERGE's ON clause — and ``from_prediction`` refuses a
prediction whose tenant cannot be established rather than defaulting to anything.

This file also states what it does not prove: nothing here writes to a real Snowflake account, so the MERGE's behaviour
on a real warehouse is GATE 12 and remains BLOCKED.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from types import SimpleNamespace

import pytest

from churn_platform.errors import ValidationFailed
from churn_platform.services import export_record as record
from churn_platform.services.destinations import snowflake
from churn_platform.services.destinations.base import deduplicate, deliver, idempotency_key, identity

pytestmark = pytest.mark.req("REQ-ACT-02")

APPROVED = "a" * 64


def _row(customer: str = "C000123", *, tenant: int | None = 1, day: int = 5, probability: float = 0.81) -> dict:
    row = {
        "tenant_id": tenant,
        "customer_id": 7,
        "account_id": None,
        "external_customer_id": customer,
        "crm_contact_id": None,
        "churn_probability": probability,
        "risk_tier": "high",
        "risk_decile": 1,
        "prediction_horizon_days": 30,
        "prediction_timestamp": datetime(2026, 11, day, 6, tzinfo=UTC),
        "data_cutoff_timestamp": datetime(2026, 11, day, tzinfo=UTC),
        "model_name": "churn-gbm",
        "model_version": "4",
        "feature_version": "contract-3",
        "model_checksum": APPROVED,
        "top_reason_1": "No login for 21 days",
        "top_reason_2": None,
        "top_reason_3": None,
        "recommended_intervention": "Success call",
        "approval_status": "approved",
    }
    if tenant is None:
        row.pop("tenant_id")
    return row


class Memory:
    """A destination that keys rows the way a warehouse would: by the record's identity, tenant included."""

    name = "memory"

    def __init__(self):
        self.rows: dict[str, dict] = {}

    def test_connection(self):
        return {"ok": True}

    def ensure_schema(self):
        return None

    def write(self, records, *, run_id):
        for item in records:
            self.rows[identity(item)] = dict(item)
        return len(self.rows)

    def count_stored(self, *, run_id):
        return len(self.rows)


# --------------------------------------------------------------------------- the schema
def test_the_canonical_record_carries_the_tenant_as_its_first_required_field():
    assert record.FIELD_NAMES[0] == "tenant_id"
    assert "tenant_id" in record.REQUIRED_FIELDS
    assert record.FIELDS[0].kind == "integer"
    assert record.describe()["schema_version"] == "1.1.0", "adding a required field is a schema change and says so"


def test_a_record_without_a_tenant_is_refused_instead_of_defaulted():
    problems = record.validate(_row(tenant=None))
    assert any("tenant_id is missing" in problem for problem in problems)
    with pytest.raises(ValidationFailed):
        record.ensure_valid(_row(tenant=None))


def test_a_tenant_that_is_not_an_integer_is_refused():
    assert record.validate(_row(tenant="1")) != []
    assert record.validate(_row(tenant=1.0)) != []


# --------------------------------------------------------------------------- the identity
def test_tenant_id_prevents_crm_collisions():
    """The defect, verbatim: the same customer id in two tenants is two records, not one."""
    first = record.ensure_valid(_row(tenant=1))
    second = record.ensure_valid(_row(tenant=2))

    assert identity(first) != identity(second)
    assert identity(first).startswith("1|") and identity(second).startswith("2|")
    assert idempotency_key("snowflake", first) != idempotency_key("snowflake", second)


def test_deduplication_inside_one_run_keeps_both_tenants_rows():
    rows, duplicates = deduplicate([record.ensure_valid(_row(tenant=1)), record.ensure_valid(_row(tenant=2))])
    assert len(rows) == 2 and duplicates == 0, "these are different records, not a duplicate"

    rows, duplicates = deduplicate([record.ensure_valid(_row(tenant=1, probability=0.2)),
                                   record.ensure_valid(_row(tenant=1, probability=0.9))])  # fmt: skip
    assert len(rows) == 1 and duplicates == 1, "the same tenant's same customer-day is still one record"
    assert rows[0]["churn_probability"] == 0.9


def test_a_run_writes_both_tenants_records_and_neither_overwrites_the_other():
    destination = Memory()
    result = deliver(destination, [_row(tenant=1, probability=0.2), _row(tenant=2, probability=0.9)], run_id="run-1")
    assert result.written == 2 and result.duplicates_within_batch == 0
    assert len(destination.rows) == 2
    stored = sorted(item["churn_probability"] for item in destination.rows.values())
    assert stored == [0.2, 0.9], "tenant 2's probability did not replace tenant 1's"


def test_the_watermark_of_one_tenant_is_not_the_other_tenants():
    destination = Memory()
    result = deliver(destination, [_row(tenant=1, day=1), _row(tenant=2, day=9)], run_id="run-2")
    assert result.watermarks[1].day == 1 and result.watermarks[2].day == 9
    assert result.watermark == datetime(2026, 11, 9, 6, tzinfo=UTC), "the run's own watermark is the newest instant"


# --------------------------------------------------------------------------- the warehouse
def test_the_primary_key_leads_with_the_tenant():
    statement = snowflake.ddl()
    assert ('PRIMARY KEY ("TENANT_ID", "EXTERNAL_CUSTOMER_ID", "MODEL_NAME", "MODEL_VERSION", "DATA_CUTOFF_TIMESTAMP")'
            in statement)  # fmt: skip


def test_the_merge_can_only_match_a_row_of_the_same_tenant():
    statement = snowflake.merge_statement()
    on_clause = statement.split(" ON ", 1)[1].split(" WHEN MATCHED", 1)[0]
    assert on_clause.startswith('target."TENANT_ID" = source."TENANT_ID"')
    assert "TENANT_ID" in on_clause and on_clause.count(" AND ") == 4
    assert 'source."TENANT_ID"' in statement.split("WHEN NOT MATCHED", 1)[1], "the tenant is inserted too"


def test_the_tenant_is_never_in_the_update_set_because_it_is_part_of_the_key():
    statement = snowflake.merge_statement()
    updates = statement.split("UPDATE SET", 1)[1].split("WHEN NOT MATCHED", 1)[0]
    assert '"TENANT_ID"' not in updates


def test_the_tenant_column_is_not_nullable_in_the_warehouse():
    assert '"TENANT_ID" NUMBER(38,0) NOT NULL' in snowflake.ddl()


# --------------------------------------------------------------------------- building a record from the database
def _prediction(**overrides):
    base = {"id": 11, "tenant_id": 3, "customer_id": 7, "probability": 0.8, "risk_tier": "high", "risk_decile": 1, "horizon_days": 30,
                "as_of_date": date(2026, 10, 31), "created_at": datetime(2026, 11, 1, 6, 30), "top_reasons": []}  # fmt: skip
    base.update(overrides)
    return SimpleNamespace(**base)


def _model(approval="approved"):
    return SimpleNamespace(name="churn-gbm", version=4, approval_status=approval)


def test_a_built_record_takes_its_tenant_from_the_prediction():
    built = record.from_prediction(_prediction(), SimpleNamespace(id=7, external_id="C000007"), _model(),
                                   feature_version="contract-3", model_checksum=APPROVED)  # fmt: skip
    assert built["tenant_id"] == 3


def test_a_built_record_falls_back_to_the_customer_and_then_refuses():
    built = record.from_prediction(_prediction(tenant_id=None), SimpleNamespace(id=7, external_id="C000007", tenant_id=5),
                                   _model(), feature_version="contract-3", model_checksum=APPROVED)  # fmt: skip
    assert built["tenant_id"] == 5

    with pytest.raises(ValidationFailed) as refused:
        record.from_prediction(_prediction(tenant_id=None), SimpleNamespace(id=7, external_id="C000007"), _model(),
                               feature_version="contract-3", model_checksum=APPROVED)  # fmt: skip
    assert refused.value.details["field"] == "tenant_id"


def test_an_explicit_tenant_wins_over_the_rows_own():
    built = record.from_prediction(_prediction(tenant_id=3), SimpleNamespace(id=7, external_id="C000007"), _model(),
                                   feature_version="contract-3", model_checksum=APPROVED, tenant_id=9)  # fmt: skip
    assert built["tenant_id"] == 9
