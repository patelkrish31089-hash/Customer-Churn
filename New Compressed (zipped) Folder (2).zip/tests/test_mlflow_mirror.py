"""MLflow: off by default; with a tracking store, every registry entry is created there once and kept in line (tags and
aliases follow the lifecycle).  MLflow as registry of record is covered in test_lifecycle_orchestration.py."""

from __future__ import annotations

import importlib.util
import json
import warnings
from pathlib import Path

import pytest
from sqlalchemy import select

from churn_platform import config
from churn_platform.db import read_session, session_scope
from churn_platform.models import AuditEvent, Job, ModelRun, ModelVersion
from churn_platform.services import mlflow_mirror, registry
from churn_platform.worker.runner import Worker
from tests.conftest import require_or_skip
from tests.test_registry_predictions import _algorithm, _promote, _run_id

pytestmark = pytest.mark.req("REQ-ML-06")


def _mirror_jobs() -> list[Job]:
    with read_session() as s:
        return list(s.execute(select(Job).where(Job.job_type == "mlops.mlflow_mirror").order_by(Job.id)).scalars())


def test_without_a_tracking_store_nothing_is_mirrored_and_nothing_is_imported(demo):
    assert mlflow_mirror.enabled() is False
    with session_scope() as s:
        version = registry.register(s, demo.principal("data_scientist"), _run_id("xgboost"))
        version_id = version.id
    assert _mirror_jobs() == [], "registration queues no mirror job"
    assert mlflow_mirror.mirror(version_id) == {"status": "disabled", "reason": "CHURN_MLFLOW_TRACKING_URI is not set"}
    with read_session() as s:
        assert s.get(ModelVersion, version_id).mlflow_model_version is None


@pytest.mark.mlflow_live
@pytest.mark.slow
def test_registered_versions_are_copied_to_mlflow_and_the_production_alias_follows_the_stage(demo, tmp_path, monkeypatch):
    require_or_skip(importlib.util.find_spec("mlflow") is not None, "the optional 'mlflow' package is not installed (pip install -e '.[mlops]')")
    store = tmp_path / "mlflow"
    store.mkdir()
    monkeypatch.chdir(store)  # a local store keeps its artefacts next to the working directory
    monkeypatch.setenv("CHURN_MLFLOW_TRACKING_URI", f"sqlite:///{store / 'tracking.db'}")
    config.reset_settings_cache()
    assert mlflow_mirror.enabled() is True
    # a second model goes through the gate.  Each step queues one synchronisation: registered, approved, promoted - and one
    # for the seeded model that the promotion archived
    with read_session() as s:
        seeded_id = s.execute(select(ModelVersion.id).where(ModelVersion.stage == "production")).scalar_one()
    version_id = _promote(demo, "random_forest")
    algorithm = _algorithm("random_forest")
    queued = _mirror_jobs()
    assert [j.payload for j in queued] == [{"version_id": version_id}] * 2 + [{"version_id": seeded_id}, {"version_id": version_id}] and {j.status for j in queued} == {"queued"}
    worker = Worker()
    worker.drain()
    done = _mirror_jobs()
    assert [j.status for j in done] == ["succeeded"] * 4, [j.error for j in done]
    assert [j.result["status"] for j in done] == ["mirrored", "synchronised", "mirrored", "synchronised"], "an entry is created in MLflow once; afterwards only tags and aliases move"
    result = done[-1].result
    assert result["production_alias"] is True and result["mlflow_version"] == "1" and result["lifecycle_state"] == "production"
    assert result["registered_model"] == f"churn-platform.tenant-{demo.tenant_id}.churn-model" and result["aliases"] == {"production": "1", "staging": None, "validated": "1"}
    with read_session() as s:
        version = s.get(ModelVersion, version_id)
        run = s.get(ModelRun, version.model_run_id)
        assert version.mlflow_model_version == "1" and version.stage == "production" and version.mlflow_run_id == result["run_id"]
        assert s.get(ModelVersion, seeded_id).mlflow_model_version == "2"
        mirrored = s.execute(select(AuditEvent).where(AuditEvent.action == "mlflow.mirrored").order_by(AuditEvent.id)).scalars().all()
        assert [(e.entity_id, e.detail["mlflow_version"]) for e in mirrored] == [(str(version_id), "1"), (str(seeded_id), "2")]
    # what MLflow holds now
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")  # MLflow's own import-time deprecation warnings
        from mlflow.tracking import MlflowClient

        client = MlflowClient(tracking_uri=f"sqlite:///{store / 'tracking.db'}")
        name = result["registered_model"]
        versions = sorted(client.search_model_versions(f"name = '{name}'"), key=lambda v: int(v.version))
        assert [int(v.version) for v in versions] == [1, 2]
        assert int(client.get_model_version_by_alias(name, "production").version) == 1 == int(client.get_model_version_by_alias(name, "validated").version)
        tags = client.get_model_version(name, "1").tags
        archived = client.get_model_version(name, "2").tags
        logged = client.get_run(result["run_id"])
        artifacts = sorted(a.path for a in client.list_artifacts(result["run_id"], "model"))
        card_file = client.download_artifacts(result["run_id"], "model/model_card.json", str(tmp_path))
    assert logged.data.params["algorithm"] == algorithm and logged.data.params["seed"] == str(run.seed)
    assert logged.data.metrics["valid.pr_auc"] == pytest.approx(run.valid_metrics["pr_auc"]) and logged.data.metrics["test.pr_auc"] == pytest.approx(run.test_metrics["pr_auc"])
    # tags say where the version stands (both jobs of this version ran after it had been promoted)
    assert tags["platform.model_version_id"] == str(version_id) and tags["platform.stage"] == "production" and tags["platform.lifecycle_state"] == "production"
    assert tags["platform.approval_status"] == "approved" and tags["platform.validated"] == "true" and tags["artifact.sha256"] == run.artifact_sha256
    assert archived["platform.lifecycle_state"] == "archived" and logged.data.tags["platform.model_version_id"] == str(version_id)
    assert artifacts == ["model/model_card.json", f"model/{Path(run.artifact_path).name}"]
    card = json.loads(Path(card_file).read_text())
    assert card["algorithm"] == algorithm and len(card["features"]) == 84 and card["threshold"] == version.threshold
    assert card["stage"] == "production" and card["approval_status"] == "approved", "the model card is written once, when the entry is created (here: after promotion)"


@pytest.mark.mlflow_live
def test_an_unreachable_tracking_store_fails_the_mirror_job_and_never_the_registry(demo, tmp_path, monkeypatch):
    require_or_skip(importlib.util.find_spec("mlflow") is not None, "the optional 'mlflow' package is not installed (pip install -e '.[mlops]')")
    monkeypatch.chdir(tmp_path)
    (tmp_path / "not-a-directory").write_text("a file where the store's directory should be")
    monkeypatch.setenv("CHURN_MLFLOW_TRACKING_URI", f"sqlite:///{tmp_path / 'not-a-directory' / 'tracking.db'}")
    monkeypatch.setenv("CHURN_JOB_MAX_ATTEMPTS", "1")
    config.reset_settings_cache()
    with session_scope() as s:
        version_id = registry.register(s, demo.principal("data_scientist"), _run_id("lightgbm")).id
    with read_session() as s:
        assert s.get(ModelVersion, version_id).approval_status == "pending", "the version is registered whatever happens to the mirror"
    Worker().drain()
    (job,) = _mirror_jobs()
    assert job.status == "failed" and job.error, "the failure is visible on the job"
    with read_session() as s:
        version = s.get(ModelVersion, version_id)
        assert version.mlflow_model_version is None and version.approval_status == "pending"
        assert s.execute(select(AuditEvent).where(AuditEvent.action == "mlflow.mirrored")).first() is None
