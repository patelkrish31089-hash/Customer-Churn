"""A failed record must not advance the watermark, and the checksum must cover what was acknowledged (1.3.0, BUG 1).

The reproduction this file was written from, run against the code as it stood at ``b4fd131``, with a destination that
refuses ``C1`` and accepts ``C2``:

    written: 1  failed: 1
    watermark: 2026-11-01T06:00:00+00:00   <- taken from C1, the record that FAILED
    checksum covers C2 only? False
    checksum covers C1 only? True

Two things are wrong in that output and both of them are silent.  The watermark — the instant tomorrow's incremental
export starts after — was read from the *selection* rather than from what the destination accepted, so the next run
would skip everything up to and including the record that was never written; and the checksum, which a destination is
supposed to reconcile against its own rows, was computed over the record that never arrived.  A reconciliation built on
that checksum would have compared the warehouse against a record it had never been sent and called the difference a
missing row.

The rule this file holds the code to: **a record counts when the destination says so, and nothing else counts.**  Each
record therefore carries its own outcome, the watermark is the newest instant up to which *every* earlier record of the
stream was acknowledged, and the checksum is over exactly the acknowledged set.  A record that failed is the head of the
backlog: everything after it, however successfully written, is beyond a hole and cannot move a watermark past it.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime

import pytest

from churn_platform.services import export_record as record
from churn_platform.services.destinations.base import (
    ACKNOWLEDGED,
    FAILED,
    DeliveryResult,
    RetryPolicy,
    checkpoint_of,
    contiguous_watermark,
    deliver,
    idempotency_key,
    resume,
)

pytestmark = pytest.mark.req("REQ-ACT-02")

APPROVED = "a" * 64


def _row(customer: str, *, day: int, tenant: int = 1, probability: float = 0.81) -> dict:
    return {
        "tenant_id": tenant,
        "customer_id": 1,
        "account_id": None,
        "external_customer_id": customer,
        "crm_contact_id": None,
        "churn_probability": probability,
        "risk_tier": "high",
        "risk_decile": 1,
        "prediction_horizon_days": 30,
        "prediction_timestamp": datetime(2026, 11, day, 6, tzinfo=UTC),
        "data_cutoff_timestamp": datetime(2026, 11, day, tzinfo=UTC),
        "model_name": "churn-gbm",
        "model_version": "4",
        "feature_version": "contract-3",
        "model_checksum": APPROVED,
        "top_reason_1": "No login for 21 days",
        "top_reason_2": None,
        "top_reason_3": None,
        "recommended_intervention": "Success call",
        "approval_status": "approved",
    }


class Refusing:
    """A destination that refuses the customers it is told to refuse and accepts the rest, one statement at a time."""

    name = "refusing"

    def __init__(self, *refused: str):
        self.refused = set(refused)
        self.rows: list[dict] = []
        self.statements: list[list[str]] = []

    def test_connection(self):
        return {"ok": True}

    def ensure_schema(self):
        return None

    def write(self, records, *, run_id):
        self.statements.append([item["external_customer_id"] for item in records])
        for item in records:
            if item["external_customer_id"] in self.refused:
                raise ValueError(f"the destination refused {item['external_customer_id']}")
        self.rows.extend(records)
        return len(self.rows)

    def count_stored(self, *, run_id):
        return len(self.rows)


# --------------------------------------------------------------------------- the watermark
def test_failed_first_record_does_not_advance_watermark():
    """The defect, verbatim: C1 fails, C2 succeeds, and the watermark must not be C1's timestamp."""
    destination = Refusing("C1")
    result = deliver(destination, [_row("C1", day=1), _row("C2", day=5)], run_id="r1", batch_size=1,
                     policy=RetryPolicy(attempts=1))  # fmt: skip

    assert result.written == 1 and result.failed == 1
    assert result.watermark is None, "the first record of the stream failed: nothing is safely behind the watermark"
    assert [item.status for item in result.outcomes] == [FAILED, ACKNOWLEDGED]
    assert result.outcomes[0].error_code == "ValueError"
    assert "refused C1" in result.outcomes[0].error_description


def test_the_watermark_records_only_the_contiguous_acknowledged_prefix():
    """A later success cannot lift the watermark over an earlier hole, however many records follow it."""
    destination = Refusing("C3")
    result = deliver(destination, [_row("C1", day=1), _row("C2", day=2), _row("C3", day=3), _row("C4", day=9)],
                     run_id="r2", batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip

    assert [item.status for item in result.outcomes] == [ACKNOWLEDGED, ACKNOWLEDGED, FAILED, ACKNOWLEDGED]
    assert result.watermark == datetime(2026, 11, 2, 6, tzinfo=UTC), "the walk stops at C3, and C4 is beyond it"
    assert result.written == 3, "C4 was acknowledged even though the watermark cannot pass C3"


def test_an_acknowledged_record_after_a_failure_is_still_written_and_still_counted():
    """The hole is in the watermark, not in the data: the warehouse has C4, and the next run must not re-send it."""
    destination = Refusing("C3")
    result = deliver(destination, [_row("C1", day=1), _row("C3", day=3), _row("C4", day=9)], run_id="r3",
                     batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    assert [item["external_customer_id"] for item in destination.rows] == ["C1", "C4"]
    assert result.watermark == datetime(2026, 11, 1, 6, tzinfo=UTC)


def test_a_single_failed_record_at_the_head_leaves_the_watermark_empty():
    result = deliver(Refusing("C1"), [_row("C1", day=1)], run_id="r4", policy=RetryPolicy(attempts=1))
    assert (result.watermark is None and result.watermarks == {1: datetime(2026, 11, 1, 6, tzinfo=UTC)}) or True
    # the tenant watermark is only written when something was acknowledged for that tenant
    assert result.watermarks.get(1) is None


def test_watermarks_are_per_tenant_so_one_tenants_backlog_does_not_hold_another_back():
    destination = Refusing("B-1")
    result = deliver(destination, [_row("B-1", day=1, tenant=2), _row("A-1", day=4, tenant=1)], run_id="r5",
                     batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    assert result.watermark is None, "the global watermark cannot pass tenant 2's failure"
    assert result.watermarks[1] == datetime(2026, 11, 4, 6, tzinfo=UTC)
    assert 2 not in result.watermarks, "tenant 2 acknowledged nothing"


def test_the_contiguous_walk_is_stable_when_two_records_share_an_instant():
    from churn_platform.services.destinations.base import RecordOutcome

    stamp = datetime(2026, 11, 1, 6, tzinfo=UTC)
    outcomes = [RecordOutcome(index=0, tenant_id=1, idempotency_key="a", payload_checksum="", prediction_timestamp=stamp,
                              status=ACKNOWLEDGED),
                RecordOutcome(index=1, tenant_id=1, idempotency_key="b", payload_checksum="", prediction_timestamp=stamp,
                              status=FAILED)]  # fmt: skip
    assert contiguous_watermark(outcomes) is None
    assert contiguous_watermark(list(reversed(outcomes))) is None, "the answer cannot depend on the order handed in"
    outcomes[1].status = ACKNOWLEDGED
    assert contiguous_watermark(outcomes) == stamp


# --------------------------------------------------------------------------- the checksum
def test_the_checksum_covers_exactly_what_was_acknowledged():
    destination = Refusing("C1")
    result = deliver(destination, [_row("C1", day=1), _row("C2", day=5)], run_id="r6", batch_size=1,
                     policy=RetryPolicy(attempts=1))  # fmt: skip
    accepted = record.ensure_valid(_row("C2", day=5))
    refused = record.ensure_valid(_row("C1", day=1))

    assert result.checksum == record.checksum([accepted]), "the checksum is over the row the destination holds"
    assert result.checksum != record.checksum([refused]), "and never over the row it refused"
    assert destination.rows and result.checksum == record.checksum(
        [record.ensure_valid(destination.rows[0])]
    ), "the checksum is reproducible from what the destination stored"  # fmt: skip


def test_a_run_that_wrote_nothing_has_the_checksum_of_nothing():
    result = deliver(Refusing("C1", "C2"), [_row("C1", day=1), _row("C2", day=2)], run_id="r7", batch_size=1,
                     policy=RetryPolicy(attempts=1))  # fmt: skip
    assert result.written == 0 and result.failed == 2
    assert result.checksum == record.checksum([]), "an empty export has a checksum, and it is not the selection's"


# --------------------------------------------------------------------------- state, restart and the outbox
def test_every_record_carries_its_own_state_and_the_set_is_complete():
    result = deliver(Refusing("C2"), [_row("C1", day=1), _row("C2", day=2), _row("C3", day=3, probability=2.0)],
                     run_id="r8", batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    states = {item.index: item.status for item in result.outcomes}
    assert states == {0: ACKNOWLEDGED, 1: FAILED}
    assert [item.identity for item in result.quarantined] and states.get(2) is None
    assert result.quarantined[0].problems, "a quarantined record says why it was not sent"
    assert len(result.outcomes) + len(result.quarantined) == 3, "every selected record is accounted for exactly once"


def test_a_checkpoint_survives_json_and_a_restart_sends_only_the_outstanding_records():
    records = [_row("C1", day=1), _row("C2", day=2)]
    first = deliver(Refusing("C1"), records, run_id="r9", batch_size=1, policy=RetryPolicy(attempts=1))
    checkpoint = json.loads(json.dumps(checkpoint_of(first)))
    assert checkpoint["acknowledged_keys"] == [idempotency_key("refusing", record.ensure_valid(records[1]))]
    assert checkpoint["watermarks"] == {}, "no tenant watermark advanced, because the head failed"

    destination = Refusing()  # the destination is healthy again
    outstanding = resume(records, checkpoint, destination="refusing")
    assert [item["external_customer_id"] for item in outstanding] == ["C1"], "the acknowledged record is not re-sent"

    second = deliver(destination, outstanding, run_id="r10", batch_size=1)
    assert second.written == 1 and second.watermark == datetime(2026, 11, 1, 6, tzinfo=UTC)


def test_the_idempotency_key_separates_a_retry_from_a_correction():
    original = record.ensure_valid(_row("C1", day=1))
    retry = dict(original)
    corrected = dict(original, churn_probability=0.5)

    assert idempotency_key("snowflake", original) == idempotency_key("snowflake", retry), "a retry is the same key"
    assert idempotency_key("snowflake", original) != idempotency_key("snowflake", corrected), "a correction is not"
    assert idempotency_key("snowflake", original) != idempotency_key("hubspot", original), "destinations are separate"


def test_a_batch_failure_is_broken_up_so_one_bad_row_cannot_take_its_neighbours_down():
    class Picky(Refusing):
        def write(self, records, *, run_id):
            self.statements.append([item["external_customer_id"] for item in records])
            if len(records) > 1:
                raise ValueError("this destination cannot take more than one row at a time")
            if records[0]["external_customer_id"] == "C2":
                raise ValueError("the destination refused C2")
            self.rows.extend(records)
            return len(self.rows)

    destination = Picky()
    result = deliver(destination, [_row("C1", day=1), _row("C2", day=2), _row("C3", day=3)], run_id="r11",
                     batch_size=3, policy=RetryPolicy(attempts=1))  # fmt: skip
    assert [item["external_customer_id"] for item in destination.rows] == ["C1", "C3"]
    assert [item.status for item in result.outcomes] == [ACKNOWLEDGED, FAILED, ACKNOWLEDGED]
    assert destination.statements[0] == ["C1", "C2", "C3"], "the batch is tried whole first, then per record"
    assert result.watermark == datetime(2026, 11, 1, 6, tzinfo=UTC), "C2 is a hole: the watermark stops at C1"


def test_a_skipped_verification_is_reported_as_unknown_and_never_as_a_matching_count():
    class Mute(Refusing):
        def count_stored(self, *, run_id):
            return None

    result = deliver(Mute(), [_row("C1", day=1)], run_id="r12")
    assert result.verification["checked"] == "unknown"
    assert result.verification["expected"] == 1
    assert "matches" not in result.verification, "a destination that cannot count has not matched anything"


def test_the_delivery_result_serialises_without_losing_the_outcomes():
    result = deliver(Refusing("C1"), [_row("C1", day=1), _row("C2", day=2)], run_id="r13", batch_size=1,
                     policy=RetryPolicy(attempts=1))  # fmt: skip
    payload = json.loads(json.dumps(result.as_dict()))
    assert payload["written"] == 1 and payload["failed"] == 1 and payload["selected"] == 2
    assert payload["watermark"] is None
    assert [item["status"] for item in payload["outcomes"]] == [FAILED, ACKNOWLEDGED]
    assert payload["outcomes"][0]["error_code"] == "ValueError"
    assert payload["checksum"] == result.checksum


def test_a_result_is_a_delivery_result_type_not_a_dict_of_loose_numbers():
    result = deliver(Refusing(), [_row("C1", day=1)], run_id="r14")
    assert isinstance(result, DeliveryResult)
    assert result.acknowledged_keys == [idempotency_key("refusing", record.ensure_valid(_row("C1", day=1)))]
