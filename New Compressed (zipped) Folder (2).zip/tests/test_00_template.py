"""The seeded template itself: built by migrations + the real seed service."""

from __future__ import annotations

import pytest
from sqlalchemy import func, select

from churn_platform.db import read_session
from churn_platform.models import Customer, Job, ModelVersion, Prediction, PredictionBatch, Tenant
from churn_platform.services import audit


@pytest.mark.req("REQ-OPS-06")
def test_seed_runs_whole_lifecycle_without_failed_jobs(ro, template):
    with read_session() as s:
        statuses = dict(s.execute(select(Job.status, func.count()).group_by(Job.status)).all())
        waiting = s.execute(select(Job.job_type).where(Job.status != "succeeded")).scalars().all()
        # 1.1.0: the seeded offer campaign has its next step in three days, so one tick waits for that day
        assert set(statuses) == {"succeeded", "queued"} and waiting == ["campaign.tick"], statuses
        assert s.execute(select(func.count()).select_from(Customer).where(Customer.tenant_id == ro.tenant_id)).scalar_one() == 300
        version = s.execute(select(ModelVersion).where(ModelVersion.tenant_id == ro.tenant_id)).scalar_one()
        assert (version.approval_status, version.stage) == ("approved", "production")
        batch = s.get(PredictionBatch, ro.summary["batch_id"])
        scored = s.execute(select(func.count()).select_from(Prediction).where(Prediction.batch_id == batch.id)).scalar_one()
        assert batch.status == "completed" and scored == batch.succeeded > 0 and batch.failed == 0
        assert audit.verify_chain(s, ro.tenant_id)["valid"] is True
        assert "SYNTHETIC" in s.get(Tenant, ro.tenant_id).name
    assert template.summary["synthetic"] is True
