"""Destinations: the obligations every one of them shares, and the Snowflake adapter in particular (1.3.0).

What these tests can and cannot establish is stated here once, because it matters for every claim made downstream:

* they **do** establish the pipeline — that an unapproved record never reaches a destination, that the same
  customer-day is written once, that a transient failure is retried and a permanent one quarantined, that the watermark
  reflects only what was written, and that reconciliation reports a mismatch instead of a tick;
* they **do** establish the shape of the Snowflake statements — the columns, the types, the identity of the MERGE, the
  fact that values are parameters and never interpolated;
* they **do not** establish that a Snowflake account accepts any of it.  No Snowflake SDK is installed and no account
  exists here; GATE 12 is BLOCKED and says so.  The stand-in connection below is a stand-in, and is named as one.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from churn_platform.errors import Conflict, ValidationFailed
from churn_platform.services import export_record as record
from churn_platform.services.destinations import snowflake
from churn_platform.services.destinations.base import (
    DeliveryResult,
    Destination,
    RetryPolicy,
    deduplicate,
    deliver,
    filter_after,
    identity,
    reconcile,
    watermark_of,
)

APPROVED = "a" * 64

pytestmark = pytest.mark.req("REQ-ACT-02")


def _row(customer: str = "C000001", *, day: int = 30, hour: int = 6, probability: float = 0.81, approval: str = "approved",
         tenant: int = 1, **overrides):  # fmt: skip
    base = {
        "tenant_id": tenant,
        "customer_id": 1,
        "account_id": "acc-1",
        "external_customer_id": customer,
        "crm_contact_id": None,
        "churn_probability": probability,
        "risk_tier": "high",
        "risk_decile": 1,
        "prediction_horizon_days": 30,
        "prediction_timestamp": datetime(2026, 11, day, hour, tzinfo=UTC),
        "data_cutoff_timestamp": datetime(2026, 11, day, tzinfo=UTC),
        "model_name": "churn-gbm",
        "model_version": "4",
        "feature_version": "contract-3",
        "model_checksum": APPROVED,
        "top_reason_1": "No login for 21 days",
        "top_reason_2": None,
        "top_reason_3": None,
        "recommended_intervention": "Success call",
        "approval_status": approval,
    }
    base.update(overrides)
    return base


class FakeCursor:
    def __init__(self, connection):
        self.connection = connection
        self.description = None
        self._rows: list[tuple] = []

    def execute(self, statement, parameters=None):
        self.connection.statements.append((statement, parameters))
        rows = self.connection.answer(statement, parameters)
        if rows is None:
            self.description = None
            self._rows = []
        else:
            self.description = [("col",)]
            self._rows = rows
        return self

    def fetchall(self):
        return self._rows

    def close(self):
        pass


class FakeConnection:
    """A stand-in for a Snowflake session: it records statements and answers the two the adapter asks about."""

    def __init__(self, *, counts=True, raise_on_merge=None, session=None):
        self.statements: list[tuple[str, object]] = []
        self.rows: dict[str, int] = {}
        self.counts = counts
        self.raise_on_merge = raise_on_merge
        self.session = session or ("8.20.0", "CHURN_SVC", "CHURN_WRITER", "CHURN_WH", "CHURN_DB", "PUBLIC", "XY12345",
                                   "EU-WEST-1")  # fmt: skip
        self.closed = False

    def cursor(self):
        return FakeCursor(self)

    def answer(self, statement, parameters):
        upper = statement.upper()
        if upper.startswith("SELECT CURRENT_VERSION"):
            return [self.session]
        if "COUNT(*)" in upper and "SYNC_RUN_ID" in upper:
            if not self.counts:
                raise RuntimeError("the role may not read the table")
            return [(self.rows.get((parameters or {}).get("run_id"), 0),)]
        if "COUNT(*)" in upper:
            return [(sum(self.rows.values()),)]
        if upper.startswith("MERGE"):
            if self.raise_on_merge is not None:
                raise self.raise_on_merge
            run_id = parameters[f"v{len(record.FIELDS)}"]  # the columns come first, then the run and the time
            self.rows[run_id] = self.rows.get(run_id, 0) + 1
            return None
        return None

    def close(self):
        self.closed = True


def _destination(connection: FakeConnection, **config) -> snowflake.SnowflakeDestination:
    options = {"account": "xy12345.eu-west-1", "user": "CHURN_SVC", "warehouse": "CHURN_WH", "database": "CHURN_DB", "schema": "PUBLIC", "role": "CHURN_WRITER"}
    options.update(config)
    return snowflake.SnowflakeDestination(config=snowflake.SnowflakeConfig(**options), connect=lambda **_: connection)


# --------------------------------------------------------------------------- the statements
def test_the_destination_table_is_the_canonical_record_with_the_types_a_warehouse_uses():
    """Identifiers are quoted, and the primary key leads with the tenant: two tenants share customer ids."""
    statement = snowflake.ddl()
    assert statement.startswith('CREATE TABLE IF NOT EXISTS "CHURN_PREDICTIONS"')
    for definition in record.FIELDS:
        assert f'"{definition.name.upper()}" ' in statement, definition.name
    assert '"CHURN_PROBABILITY" FLOAT NOT NULL' in statement
    assert '"PREDICTION_TIMESTAMP" TIMESTAMP_TZ NOT NULL' in statement
    assert '"MODEL_CHECKSUM" VARCHAR(64) NOT NULL' in statement
    assert '"TENANT_ID" NUMBER(38,0) NOT NULL' in statement
    assert '"CRM_CONTACT_ID" VARCHAR,' in statement, "an optional field is nullable"
    assert ('PRIMARY KEY ("TENANT_ID", "EXTERNAL_CUSTOMER_ID", "MODEL_NAME", "MODEL_VERSION", "DATA_CUTOFF_TIMESTAMP")'
            in statement)  # fmt: skip


def test_the_merge_upserts_on_the_record_identity_and_fills_every_column_from_the_source():
    statement = snowflake.merge_statement()
    assert statement.startswith('MERGE INTO "CHURN_PREDICTIONS" AS target USING (SELECT %(v0)s AS "TENANT_ID", %(v1)s AS "CUSTOMER_ID"')
    # the identity leads with the tenant, so one tenant's row can never update another's
    assert ('ON target."TENANT_ID" = source."TENANT_ID" AND target."EXTERNAL_CUSTOMER_ID" = source."EXTERNAL_CUSTOMER_ID"'
            ' AND target."MODEL_NAME" = source."MODEL_NAME"') in statement  # fmt: skip
    assert 'WHEN MATCHED THEN UPDATE SET "CUSTOMER_ID" = source."CUSTOMER_ID"' in statement
    assert "WHEN NOT MATCHED THEN INSERT (" in statement
    # values are parameters: a record containing SQL cannot become SQL
    assert "CHURN_PROBABILITY = %(v4)s AS" not in statement
    assert "EXTERNAL_CUSTOMER_ID = %(" not in statement


def test_the_run_table_records_what_a_reconciliation_needs():
    statement = snowflake.runs_ddl()
    for column in ("RUN_ID", "ROWS_EXPECTED", "ROWS_WRITTEN", "CHECKSUM", "WATERMARK", "ACTOR", "STARTED_AT", "FINISHED_AT"):
        assert column in statement


def test_the_configuration_never_carries_a_secret_and_refuses_an_incomplete_or_dangerous_one():
    config = snowflake.SnowflakeConfig(account="xy12345", user="svc", warehouse="WH", database="DB")
    safe = config.safe()
    assert set(safe) == {"account", "user", "warehouse", "database", "schema", "role", "authenticator", "table"}
    assert not any(secret in repr(safe).lower() for secret in ("password", "token", "private"))
    assert snowflake.SnowflakeConfig(account="", user="svc", warehouse="WH", database="DB").problems() == ["account"]
    assert snowflake.SnowflakeConfig(account="a", user="u", warehouse="W", database="D", authenticator="password").problems()
    assert snowflake.SnowflakeConfig(account="a", user="u", warehouse="W", database="D", table="T; DROP TABLE X").problems()


# --------------------------------------------------------------------------- the connection
def test_a_connection_test_reads_the_session_back_and_refuses_one_that_is_not_the_configured_one():
    connection = FakeConnection()
    health = _destination(connection).test_connection()
    assert health["ok"] is True and health["session"]["warehouse"] == "CHURN_WH"
    assert "CURRENT_WAREHOUSE()" in connection.statements[0][0]

    wrong = FakeConnection(session=("8.20.0", "OTHER", "SYSADMIN", "OTHER_WH", "CHURN_DB", "PUBLIC", "XY12345", "EU-WEST-1"))
    with pytest.raises(ValidationFailed) as refused:
        _destination(wrong).test_connection()
    assert "warehouse is OTHER_WH" in refused.value.message and "role is SYSADMIN" in refused.value.message


def test_the_health_check_reports_a_broken_table_instead_of_raising():
    connection = FakeConnection()
    assert _destination(connection).health()["ok"] is True
    broken = FakeConnection()
    broken.answer = lambda statement, parameters: (_ for _ in ()).throw(RuntimeError("insufficient privileges"))  # type: ignore[assignment]
    health = _destination(broken).health()
    assert health["ok"] is False and "insufficient privileges" in health["error"]


def test_a_destination_that_cannot_count_says_so_rather_than_zero():
    assert _destination(FakeConnection(counts=False)).count_stored(run_id="run-1") is None


# --------------------------------------------------------------------------- the pipeline
def test_an_unapproved_record_never_reaches_the_destination():
    connection = FakeConnection()
    result = deliver(_destination(connection), [_row(approval="pending")], run_id="run-1", policy=RetryPolicy(backoff_seconds=0))
    assert result.written == 0 and len(result.quarantined) == 1
    assert "may not be exported" in " ".join(result.quarantined[0].problems)
    assert not any("MERGE" in statement for statement, _ in connection.statements), "nothing was sent at all"


def test_the_same_customer_day_twice_is_written_once_and_the_last_statement_wins():
    connection = FakeConnection()
    records = [_row(probability=0.5), _row(probability=0.9)]
    result = deliver(_destination(connection), records, run_id="run-1", policy=RetryPolicy(backoff_seconds=0))
    assert result.selected == 2 and result.written == 1 and result.duplicates_within_batch == 1
    assert result.verification["stored"] == 1 and result.verification["matches"] is True
    merged = [parameters for statement, parameters in connection.statements if statement.startswith("MERGE")]
    probability = f"v{record.FIELD_NAMES.index('churn_probability')}"  # the parameter order follows the schema
    assert merged[0][probability] == 0.9, "the newer statement is the one that is written"


def test_a_batch_of_records_becomes_one_merge_each_and_the_count_is_read_back():
    connection = FakeConnection()
    records = [_row(f"C00000{n}", day=1 + n) for n in range(5)]
    result = deliver(_destination(connection), records, run_id="run-9", batch_size=2, policy=RetryPolicy(backoff_seconds=0))
    assert result.batches == 3 and result.written == 5
    assert len([1 for statement, _ in connection.statements if statement.startswith("MERGE")]) == 5
    assert result.verification == {"checked": "counted the rows the destination holds for this run", "expected": 5, "stored": 5, "matches": True}


def test_a_transient_failure_is_retried_and_a_permanent_one_fails_the_record_rather_than_losing_it():
    """A delivery failure is now a FAILED outcome with its error, not a quarantine: nothing was refused, it was lost."""
    waiting: list[float] = []
    transient = FakeConnection(raise_on_merge=TimeoutError("the warehouse did not answer"))
    result = deliver(_destination(transient), [_row()], run_id="run-1", policy=RetryPolicy(attempts=3, backoff_seconds=0.5), sleep=waiting.append)
    assert result.retries == 2 and waiting == [0.5, 1.0]
    assert result.written == 0 and result.failed == 1 and result.watermark is None
    assert result.outcomes[0].error_code == "TimeoutError" and result.outcomes[0].attempts == 3

    permanent = FakeConnection(raise_on_merge=ValueError("the column does not exist"))
    result = deliver(_destination(permanent), [_row()], run_id="run-1", policy=RetryPolicy(attempts=3, backoff_seconds=0))
    assert result.retries == 0 and result.outcomes[0].attempts == 1 and result.outcomes[0].error_code == "ValueError"


def test_the_watermark_only_reflects_records_that_were_written():
    connection = FakeConnection()
    records = [_row("C1", day=1), _row("C2", day=5), _row("C3", day=3, approval="rejected")]
    result = deliver(_destination(connection), records, run_id="run-1", policy=RetryPolicy(backoff_seconds=0))
    assert result.watermark == datetime(2026, 11, 5, 6, tzinfo=UTC)
    assert filter_after(records, result.watermark) == []


def test_the_checksum_covers_exactly_what_was_written():
    connection = FakeConnection()
    records = [_row("C1", day=1), _row("C2", day=2)]
    result = deliver(_destination(connection), records, run_id="run-1", policy=RetryPolicy(backoff_seconds=0))
    assert result.checksum == record.checksum([record.ensure_valid(row) for row in records])


def test_reconciliation_reports_a_shortfall_as_a_conflict_and_unknown_as_unknown():
    result = DeliveryResult(destination="snowflake", run_id="run-1", written=4)
    assert reconcile(result, 4)["matches"] is True
    assert reconcile(result, 6)["matches"] is False
    with pytest.raises(Conflict) as refused:
        reconcile(result, 3)
    assert "1 of 4 rows are missing" in refused.value.message
    assert reconcile(result, None)["checked"] == "unknown"


def test_an_empty_selection_writes_nothing_and_says_zero_rather_than_failing():
    connection = FakeConnection()
    result = deliver(_destination(connection), [], run_id="run-1")
    assert result.selected == 0 and result.written == 0 and result.batches == 0
    assert result.checksum == record.checksum([])


def test_the_identity_of_a_record_is_the_tenant_the_customer_the_model_and_the_day():
    assert identity(_row("C9", day=7)) == "1|C9|churn-gbm|4|2026-11-07"
    assert deduplicate([_row("C9", day=7), _row("C9", day=7)])[0].__len__() == 1
    assert watermark_of([_row(day=2), _row(day=9), {}]) == datetime(2026, 11, 9, 6, tzinfo=UTC)


def test_a_destination_is_a_thing_that_can_be_tested_and_written_to():
    assert isinstance(_destination(FakeConnection()), Destination)
