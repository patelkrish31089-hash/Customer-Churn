"""Shared fixtures.

The expensive part of the suite is a fully seeded tenant (synthetic data taken through the real
ingestion -> labels -> features -> training -> approval -> scoring -> retention -> monitoring
path).  It is built ONCE per session by running the migrations and the same `seed_demo` service
that `churn-platform seed-demo` uses; tests then work on file copies:

* ``ro``    - one shared copy for tests that only read (logins may add sessions/audit rows),
* ``demo``  - a private copy for tests that change state,
* ``empty`` - a private migrated database without tenant data.

Nothing is mocked except outbound HTTP (CRM / REST pulls), which uses ``httpx.MockTransport``.
"""

from __future__ import annotations

import contextlib
import json
import os
import shutil
import sqlite3
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

import pytest

# --- environment: must be fixed before the application package reads its settings
for _name in [k for k in os.environ if k.startswith("CHURN_") and not k.startswith("CHURN_TEST_")]:
    os.environ.pop(_name)
os.environ["CHURN_ENV"] = "test"
os.environ["CHURN_LOG_LEVEL"] = "WARNING"
os.environ["CHURN_SECRET_KEY"] = "test-suite-only-key-0123456789abcdef0123456789abcdef"
os.environ["CHURN_RATE_LIMIT_LOGIN_PER_MINUTE"] = "10000"
# The suite sends thousands of requests a minute from one address; the limits are tested where a test sets them.
for _limit in ("LOGIN_ACCOUNT", "API", "IP", "EXPORT", "PREDICT", "SYNC"):
    os.environ[f"CHURN_RATE_LIMIT_{_limit}_PER_MINUTE"] = "1000000"
# Sentiment: the suite scores with the word-list baseline unless a test asks for the transformer
# (one test in tests/test_signals.py uses the real model from CHURN_TEST_SENTIMENT_MODEL_DIR).
os.environ["CHURN_SENTIMENT_PROVIDER"] = "lexicon_baseline"

PASSWORD = "Correct-Horse-Battery-9!"
DEMO_ARGS: dict[str, Any] = {"customers": 300, "months": 15, "seed": 7, "end_date": date(2026, 10, 31), "n_iter": 3}
STRICT = os.environ.get("CHURN_TEST_STRICT") == "1"


def require_or_skip(condition: bool, reason: str) -> None:
    """Optional prerequisites skip locally; the release run (CHURN_TEST_STRICT=1) fails instead."""
    if condition:
        return
    if STRICT:
        pytest.fail(f"prerequisite missing in strict mode: {reason}")
    pytest.skip(reason)


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    for item in items:
        if "req" not in item.keywords:
            continue
        for mark in item.iter_markers("req"):
            for req_id in mark.args:
                item.user_properties.append(("requirement", req_id))


def activate(db_path: Path | str, data_dir: Path | str, **env: str) -> None:
    """Point the application at a database / data directory and drop every cached handle."""
    from churn_platform import config, db

    url = str(db_path) if "://" in str(db_path) else f"sqlite:///{db_path}"
    os.environ["CHURN_DATABASE_URL"] = url
    os.environ["CHURN_DATA_DIR"] = str(data_dir)
    for key, value in env.items():
        os.environ[key] = value
    db.dispose_engine()
    config.reset_settings_cache()


def _reset_process_state() -> None:
    from churn_platform import config, db
    from churn_platform.services import crm, crm_oauth, ingestion, mlflow_mirror, notify, ratelimit, sentiment, sso, training
    from churn_platform.worker import runner

    runner.stop_embedded_worker()
    for module in (crm, crm_oauth, notify, sso):
        module.set_transport(None)
    training._BUNDLE_CACHE.clear()
    ratelimit.reset_local()
    sentiment.reset_provider_cache()
    mlflow_mirror.reset_cache()
    ingestion._rejections.clear()
    db.dispose_engine()
    config.reset_settings_cache()


@pytest.fixture(autouse=True)
def _isolation() -> Iterator[None]:
    before = {k: v for k, v in os.environ.items() if k.startswith("CHURN_")}
    yield
    _reset_process_state()
    for key in [k for k in os.environ if k.startswith("CHURN_")]:
        if key not in before:
            del os.environ[key]
    os.environ.update(before)
    from churn_platform import config

    config.reset_settings_cache()


def _checkpoint(db_path: Path) -> None:
    con = sqlite3.connect(db_path)
    try:
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    finally:
        con.close()


def _copy_db(src: Path, dst: Path) -> Path:
    shutil.copyfile(src, dst)
    return dst


def _source_fingerprint() -> str:
    import hashlib

    import churn_platform

    digest = hashlib.sha256(json.dumps(DEMO_ARGS, default=str, sort_keys=True).encode())
    package = Path(churn_platform.__file__).parent
    for path in sorted(package.rglob("*.py")):
        digest.update(path.relative_to(package).as_posix().encode() + b"\0" + path.read_bytes())
    return digest.hexdigest()[:16]


@dataclass
class Template:
    root: Path
    empty_db: Path
    demo_db: Path
    demo_data: Path
    summary: dict
    seed_seconds: float


@pytest.fixture(scope="session")
def template(tmp_path_factory: pytest.TempPathFactory) -> Template:
    """Build the migrated-empty and the seeded template databases (once per session)."""
    import time

    from churn_platform import db, dbadmin
    from churn_platform.services import demo as demo_service

    # Optional developer shortcut: reuse a template across runs, but only for byte-identical sources.
    cache = os.environ.get("CHURN_TEST_TEMPLATE_DIR")
    if cache:
        root = Path(cache) / _source_fingerprint()
        if (root / "summary.json").exists():
            return Template(root, root / "empty.db", root / "demo.db", root / "demo_data", json.loads((root / "summary.json").read_text()), 0.0)
        shutil.rmtree(Path(cache), ignore_errors=True)
        root.mkdir(parents=True)
    else:
        root = tmp_path_factory.mktemp("template")
    empty_db, demo_db, demo_data = root / "empty.db", root / "demo.db", root / "demo_data"
    activate(empty_db, root / "empty_data")
    dbadmin.upgrade()
    db.dispose_engine()
    _checkpoint(empty_db)

    activate(demo_db, demo_data)
    dbadmin.upgrade()
    started = time.monotonic()
    summary = demo_service.seed_demo(password=PASSWORD, work_dir=root / "synthetic_files", log=lambda *_: None, **DEMO_ARGS)
    seconds = time.monotonic() - started
    db.dispose_engine()
    _checkpoint(demo_db)
    (root / "summary.json").write_text(json.dumps(summary, default=str, indent=1))
    _reset_process_state()
    return Template(root, empty_db, demo_db, demo_data, json.loads((root / "summary.json").read_text()), seconds)


@dataclass
class Tenant:
    """Handle on a seeded tenant: principals, an API client and a worker drain helper."""

    db_path: Path
    data_dir: Path
    summary: dict
    slug: str = "demo"
    tenant_id: int = 0
    _tokens: dict = field(default_factory=dict)

    def email(self, role: str) -> str:
        return f"{role.replace('_', '.')}@{self.slug}.example"

    def principal(self, role: str = "admin") -> Any:
        from churn_platform.db import read_session
        from churn_platform.services import demo as demo_service

        with read_session() as s:
            return demo_service.system_principal(s, self.tenant_id, self.email(role))

    def drain(self, *, expect_success: bool = True) -> Any:
        """Run every queued job in-process, exactly as `churn-platform worker` would."""
        from sqlalchemy import select

        from churn_platform.db import read_session
        from churn_platform.models import Job
        from churn_platform.worker.runner import Worker

        worker = Worker()
        worker.drain()
        if expect_success:
            with read_session() as s:
                # the seeded dry-run campaign keeps one job queued for its next step (three days ahead): that is not a failure
                waiting = (Job.job_type == "campaign.tick") & (Job.status == "queued")
                bad = s.execute(select(Job.id, Job.job_type, Job.status, Job.error).where(Job.status.notin_(("succeeded", "cancelled")), ~waiting)).all()
            assert not bad, f"jobs did not succeed: {bad}"
            assert worker.progress_skipped == 0, "a handler reported progress while holding the write lock"
        return worker

    @contextlib.contextmanager
    def client(self) -> Iterator[Any]:
        from starlette.testclient import TestClient

        from churn_platform.api import create_app

        with TestClient(create_app()) as c:
            yield c

    def login(self, client: Any, role: str = "admin") -> dict[str, str]:
        r = client.post("/api/v1/auth/login", json={"email": self.email(role), "password": PASSWORD})
        assert r.status_code == 200, r.text
        return {"Authorization": "Bearer " + r.json()["token"]}


def _tenant(db_path: Path, data_dir: Path, summary: dict) -> Tenant:
    activate(db_path, data_dir)
    return Tenant(db_path, data_dir, summary, tenant_id=summary["tenant_id"])


@pytest.fixture(scope="session")
def _shared_copy(template: Template, tmp_path_factory: pytest.TempPathFactory) -> tuple[Path, Path]:
    root = tmp_path_factory.mktemp("shared")
    shutil.copytree(template.demo_data, root / "data")
    return _copy_db(template.demo_db, root / "demo.db"), root / "data"


@pytest.fixture
def ro(template: Template, _shared_copy: tuple[Path, Path]) -> Tenant:
    """Seeded tenant shared by read-only tests.  Do not change business state through it."""
    return _tenant(_shared_copy[0], _shared_copy[1], template.summary)


@pytest.fixture
def demo(template: Template, tmp_path: Path) -> Tenant:
    """Private copy of the seeded tenant for tests that change state."""
    shutil.copytree(template.demo_data, tmp_path / "data")
    return _tenant(_copy_db(template.demo_db, tmp_path / "demo.db"), tmp_path / "data", template.summary)


@dataclass
class Empty:
    db_path: Path
    data_dir: Path

    def tenant(self, slug: str = "acme", name: str = "Acme Ltd") -> int:
        from churn_platform.db import session_scope
        from churn_platform.services import auth

        with session_scope() as s:
            return auth.create_tenant(s, slug, name).id

    def user(self, tenant_id: int, role: str = "admin", email: str | None = None, password: str = PASSWORD) -> Any:
        from churn_platform.db import session_scope
        from churn_platform.security import ROLE_PERMISSIONS, Principal
        from churn_platform.services import auth

        email = email or f"{role}@t{tenant_id}.example"
        with session_scope() as s:
            user = auth.create_user(s, tenant_id=tenant_id, email=email, full_name=role.title(), role=role, password=password)
            return Principal(user_id=user.id, tenant_id=tenant_id, email=email, role=role, session_id=0, permissions=ROLE_PERMISSIONS[role])


@pytest.fixture
def empty(template: Template, tmp_path: Path) -> Empty:
    """Private migrated database with no tenant data."""
    db_path = _copy_db(template.empty_db, tmp_path / "empty.db")
    activate(db_path, tmp_path / "data")
    return Empty(db_path, tmp_path / "data")


@pytest.fixture(scope="session")
def postgres_url() -> str:
    url = os.environ.get("CHURN_TEST_POSTGRES_URL", "")
    require_or_skip(bool(url), "set CHURN_TEST_POSTGRES_URL to run the PostgreSQL tests")
    return url


@pytest.fixture
def api_server() -> Iterator[str]:
    """A real HTTP server on localhost that plays a customer's REST API; yields its base URL."""
    import threading
    from http.server import ThreadingHTTPServer

    from tests.fakes import RestApi

    RestApi.seen, RestApi.failures_left = [], 0
    server = ThreadingHTTPServer(("127.0.0.1", 0), RestApi)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_address[1]}"
    server.shutdown()
    server.server_close()
    thread.join(timeout=5)
