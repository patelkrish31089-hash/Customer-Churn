"""SHAP explanations: exact additivity, feature-level aggregation, waterfalls that end at the served probability."""

from __future__ import annotations

import numpy as np
import pytest
from sqlalchemy import select

from churn_platform.db import read_session, session_scope
from churn_platform.errors import NotFound
from churn_platform.models import Explanation, MLDataset, ModelRun
from churn_platform.services import explain, mlprep, training
from churn_platform.services import feature_engine as fe

pytestmark = pytest.mark.req("REQ-ML-05")


@pytest.fixture
def models(ro):
    with read_session() as s:
        runs = s.execute(select(ModelRun).where(ModelRun.tenant_id == ro.tenant_id).order_by(ModelRun.id)).scalars().all()
        dataset = s.get(MLDataset, ro.summary["dataset_id"])
    return {r.algorithm: training.load_bundle(r) for r in runs}, mlprep.load_split(dataset, "valid")


@pytest.mark.parametrize("algorithm", training.ALGORITHMS)
def test_shap_values_add_up_to_the_model_output_for_every_row(models, algorithm):
    bundles, valid = models
    result = explain.shap_values(bundles[algorithm], valid)
    assert result["status"] == "available", result.get("reason")
    values, base, raw = result["values"], result["base_value"], result["raw_output"]
    assert values.shape == (len(valid), len(bundles[algorithm]["columns"])) and np.isfinite(values).all()
    np.testing.assert_allclose(base + values.sum(axis=1), raw, atol=explain.ADDITIVITY_TOLERANCE, rtol=0)
    assert result["additivity_error"].max() <= explain.ADDITIVITY_TOLERANCE == 1e-3
    assert result["space"] == ("probability" if algorithm == "random_forest" else "log_odds")
    # one-hot and missing-indicator columns fold back onto the 84 contract features without losing anything
    per_feature = explain.aggregate_to_features(bundles[algorithm], values)
    assert list(per_feature.columns) == bundles[algorithm]["features"] and len(per_feature.columns) == 84
    np.testing.assert_allclose(per_feature.sum(axis=1).to_numpy(), values.sum(axis=1), atol=1e-9, rtol=0)
    # the explained output is the model's own output: converted to a probability it is what gets served
    served = training.predict_proba(bundles[algorithm], valid)
    # (1e-6: XGBoost computes its margin in single precision)
    np.testing.assert_allclose(explain.to_probability(bundles[algorithm], raw, result["space"]), served, atol=1e-6, rtol=0)


def test_explanations_take_the_same_path_whatever_the_warning_filters_are(models):
    """Regression (DEF-045): the suite turns warnings into errors.  A library warning inside an explainer used to send the
    tests down a fallback path that production (warnings are only printed) never took."""
    import warnings

    bundles, valid = models
    expected = {"logistic_regression": "exact linear SHAP (independent features)", "random_forest": "shap.TreeExplainer (path-dependent)",
                "xgboost": "shap.TreeExplainer (path-dependent)", "lightgbm": "lightgbm pred_contrib (TreeSHAP)"}  # fmt: skip
    assert set(expected) == set(training.ALGORITHMS)
    strict = {a: explain.shap_values(bundles[a], valid.head(40)) for a in training.ALGORITHMS}  # warnings are errors here
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")  # what a production process does: report, carry on
        lenient = {a: explain.shap_values(bundles[a], valid.head(40)) for a in training.ALGORITHMS}
    assert [str(w.message) for w in caught] == [], "explaining a prediction prints no warnings"
    for algorithm in training.ALGORITHMS:
        assert strict[algorithm]["method"] == lenient[algorithm]["method"] == expected[algorithm], algorithm
        np.testing.assert_array_equal(strict[algorithm]["values"], lenient[algorithm]["values"])
        assert strict[algorithm]["base_value"] == lenient[algorithm]["base_value"]


def test_linear_shap_is_the_exact_closed_form(models):
    bundles, valid = models
    bundle = bundles["logistic_regression"]
    result = explain.shap_values(bundle, valid)
    pipeline = bundle["model"]
    scaled = pipeline.named_steps["scale"].transform(mlprep.transform(bundle["prep"], valid[bundle["features"]]).to_numpy())
    model = pipeline.named_steps["model"]
    np.testing.assert_allclose(result["values"], scaled * model.coef_[0][None, :], atol=1e-12, rtol=0)
    assert result["base_value"] == float(model.intercept_[0]) and result["additivity_error"].max() < 1e-9
    assert "exact linear SHAP" in result["method"]


@pytest.mark.parametrize("algorithm", training.ALGORITHMS)
def test_waterfall_runs_from_the_base_rate_to_the_served_probability(models, algorithm):
    bundles, valid = models
    bundle = bundles[algorithm]
    served = training.predict_proba(bundle, valid)
    for position in (int(np.argmax(served)), int(np.argmin(served)), len(valid) // 2):
        row = valid.iloc[[position]]
        one = explain.explain_one(bundle, row)
        assert one["status"] == "available"
        wf = one["waterfall"]
        assert wf["final_probability"] == pytest.approx(served[position], abs=1e-6), "the waterfall ends at the probability the customer is shown"
        assert wf["base_probability"] + sum(s["probability_delta"] for s in wf["steps"]) == pytest.approx(wf["final_probability"], abs=1e-12)
        assert one["base_value"] + sum(one["contributions"].values()) == pytest.approx(one["output_value"], abs=explain.ADDITIVITY_TOLERANCE)
        named = [s for s in wf["steps"] if s["feature"] != "__other__"]
        assert len(named) == 8 and wf["steps"][-1]["feature"] == "__other__" and wf["steps"][-1]["label"] == "All other features (76)"
        sizes = [abs(s["contribution"]) for s in named]
        assert sizes == sorted(sizes, reverse=True), "largest contributions first"
        for step in named:
            assert step["feature"] in fe.SPECS and step["label"] == fe.SPECS[step["feature"]].label
            assert step["direction"] == ("raises" if step["contribution"] > 0 else "lowers") and step["direction"] in step["text"]
            assert step["probability_after"] == pytest.approx(wf["base_probability"] + sum(s["probability_delta"] for s in wf["steps"][: wf["steps"].index(step) + 1]))
        assert wf["disclaimer"] == explain.NOT_CAUSAL and "not causes of churn" in wf["disclaimer"]


def test_top_reasons_are_the_largest_risk_raising_features(models):
    bundles, valid = models
    out = explain.explain_rows(bundles["xgboost"], valid, top_k=3)
    assert out["status"] == "available" and len(out["top_reasons"]) == len(valid)
    contributions = out["contributions"].to_numpy()
    for i, reasons in enumerate(out["top_reasons"]):
        assert len(reasons) <= 3 and all(r["contribution"] > 0 and r["direction"] == "raises" for r in reasons)
        top = np.sort(contributions[i])[::-1][:3]
        assert [r["contribution"] for r in reasons] == [c for c in top if c > 0]
        assert all(r["text"].startswith(r["label"] + ": ") and "raises the predicted risk" in r["text"] for r in reasons)
    assert sum(len(r) == 3 for r in out["top_reasons"]) > 0.9 * len(valid)


def test_explanations_are_reported_unavailable_rather_than_invented(models, monkeypatch):
    bundles, valid = models
    monkeypatch.setattr(explain, "ADDITIVITY_TOLERANCE", -1.0)
    failed = explain.shap_values(bundles["lightgbm"], valid.head(5))
    assert failed["status"] == "unavailable" and "additivity check failed" in failed["reason"] and "values" not in failed
    assert explain.explain_one(bundles["lightgbm"], valid.head(1))["status"] == "unavailable"
    assert explain.explain_rows(bundles["lightgbm"], valid.head(5))["status"] == "unavailable"
    monkeypatch.undo()
    unknown = explain.shap_values({**bundles["lightgbm"], "algorithm": "neural_net"}, valid.head(5))
    assert unknown == {"status": "unavailable", "reason": "no SHAP explainer is implemented for algorithm 'neural_net'"}
    broken = explain.shap_values({**bundles["logistic_regression"], "model": object()}, valid.head(5))
    assert broken["status"] == "unavailable" and broken["reason"].startswith("SHAP computation failed")


def test_value_formatting_for_reason_texts():
    assert explain.format_value("mrr", 1234.6) == "1,235" and explain.format_value("mrr", 99.5) == "99.50"
    assert explain.format_value("avg_csat_90d", 3.456) == "3.46" and explain.format_value("logins_30d", 12.0) == "12"
    assert explain.format_value("pending_cancellation", 1.0) == "yes" and explain.format_value("last_payment_failed", 0.0) == "no"
    assert explain.format_value("login_delta_7d_30d_pct", -0.42) == "-42%" and explain.format_value("discount_pct", 15.0) == "15"
    assert explain.format_value("industry", "software") == "software" and explain.format_value("avg_csat_90d", float("nan")) == "not available"
    r = explain.reason("recency_days", 30.0, 0.8)
    assert r["text"] == "Days since last activity: 30 (raises the predicted risk)" and r["display_value"] == "30" and r["group"] == "rfm"
    assert explain.reason("logins_30d", 40.0, -0.2)["direction"] == "lowers"


def test_global_summary_ranks_features_by_mean_absolute_shap_on_validation_data(demo):
    scientist = demo.principal("data_scientist")
    with session_scope() as s:
        run = s.execute(select(ModelRun).where(ModelRun.algorithm == "random_forest")).scalar_one()
        explanation = explain.global_explanation(s, scientist, run.id)
        view = explain.explanation_view(explanation)
        assert explain.latest_global(s, demo.tenant_id, run.id).id == explanation.id
    assert (view["status"], view["scope"], view["space"]) == ("available", "global", "probability") and view["additivity_error"] <= 1e-3
    body = view["contributions"]
    rows = body["features"]
    assert len(rows) == 84 and [r["mean_abs_shap"] for r in rows] == sorted((r["mean_abs_shap"] for r in rows), reverse=True)
    assert sum(r["share"] for r in rows) == pytest.approx(1.0) and all(r["mean_abs_shap"] >= 0 for r in rows)
    assert sum(body["groups"].values()) == pytest.approx(sum(r["mean_abs_shap"] for r in rows))
    assert set(body["groups"]) <= {"customer", "subscription", "rfm", "usage", "trend", "inactivity", "support", "billing", "adoption"}
    assert body["sample_source"] == "validation split" and body["sample_rows"] == 395, "the TEST split is not used for explanations"
    assert body["disclaimer"] == explain.NOT_CAUSAL
    directions = {r["direction"] for r in rows}
    assert directions <= {None, "higher value -> higher predicted risk", "higher value -> lower predicted risk"} and len(directions) >= 2
    with session_scope() as s, pytest.raises(NotFound):
        explain.global_explanation(s, scientist, 999_999)
    with read_session() as s:
        assert s.execute(select(Explanation).where(Explanation.model_run_id == run.id)).scalars().first() is not None
