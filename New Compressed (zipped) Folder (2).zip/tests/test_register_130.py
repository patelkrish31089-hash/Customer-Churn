"""The 1.3.0 register: one file, generated summaries, and checks that refuse to flatter.

The 1.2.0 register shipped a hand-written ``meta.counts`` that disagreed with its own entries and a gate table that
said NOT_IMPLEMENTED about work its own report called PASS.  These tests hold the replacement to the rule that makes
those failures impossible: the counts are computed, a status that asserts something must carry its evidence and the
commit it was verified at, a BLOCKED entry must name its blocker, and the document on disk must be exactly what the
register says.
"""

from __future__ import annotations

import copy
import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "build_1_3_0_register.py"
REGISTER = ROOT / "docs" / "1_3_0_requirements.json"
DOCUMENT = ROOT / "docs" / "1_3_0_REQUIREMENT_TRACEABILITY.md"

pytestmark = pytest.mark.req("REQ-QA-01")


def _tool():
    spec = importlib.util.spec_from_file_location("build_1_3_0_register", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(spec.name, None)
    return module


def _entry(rid: str, status: str = "PASS", **overrides) -> dict:
    entry = {
        "id": rid,
        "area": "Test",
        "requirement": "Something the platform must do",
        "status": status,
        "evidence": "tests/test_register_130.py exercises this entry well enough to satisfy the minimum length",
        "blocked_by": "",
        "next_step": "",
        "verified_at": "abc1234" if status == "PASS" else "",
    }
    entry.update(overrides)
    if not entry.get("verified_at"):
        entry.pop("verified_at")
    return entry


def _gate(number: int, **overrides) -> dict:
    gate = {
        "id": f"GATE {number}",
        "kind": "technical" if number <= 10 else "external",
        "title": "Something a gate checks",
        "owner": "engineering",
        "environment": "the build machine",
        "command": "python -m pytest -q",
        "result": "PARTIAL",
        "evidence": "",
        "timestamp": "",
        "source_commit": "",
        "remaining_limitation": "the rest of it",
    }
    gate.update(overrides)
    return gate


def _register(entries: list[dict], gates: list[dict] | None = None) -> dict:
    return {
        "meta": {"document": "test register", "source_commit": "abc1234"},
        "entries": entries,
        "gates": gates if gates is not None else [_gate(n) for n in range(1, 16)],
    }


# --------------------------------------------------------------------------- the counts
def test_the_counts_are_computed_from_the_entries_and_never_trusted():
    """The 1.2.0 register's ``meta.counts`` said 23/16/9 while its 58 entries said 28/14/6."""
    tool = _tool()
    register = _register([_entry("R-01"), _entry("R-02", "BLOCKED", blocked_by="a vendor account"), _entry("R-03", "NOT_IMPLEMENTED", evidence="", verified_at=None)])
    register["meta"]["counts"] = {"PASS": 99, "PARTIAL": 0}
    tool.recount(register)
    assert register["meta"]["counts"] == {"BLOCKED": 1, "NOT_IMPLEMENTED": 1, "PASS": 1}
    assert register["meta"]["entries"] == 3
    assert "computed" in register["meta"]["counts_note"]


def test_the_document_states_the_counts_it_computed_and_totals_them():
    tool = _tool()
    entry = _entry("R-01")
    register = tool.recount(_register([entry]))
    document = tool.render(register)
    assert "| PASS | 1 |" in document and "| **total** | **1** |" in document
    assert "R-01" in document


# --------------------------------------------------------------------------- the statuses
def test_a_pass_without_evidence_or_a_commit_is_refused():
    tool = _tool()
    problems = tool.validate(_register([_entry("R-01", evidence="")]))
    assert any("R-01" in problem and "no evidence" in problem for problem in problems)
    problems = tool.validate(_register([_entry("R-01", verified_at=None)]))
    assert any("R-01" in problem and "verified at" in problem for problem in problems)


def test_a_pass_from_an_earlier_commit_fails_a_release_but_not_an_ordinary_run():
    """History is evidence for the commit it names and for no other, which is what ``--release`` insists on."""
    tool = _tool()
    register = _register([_entry("R-01", verified_at="0000old")])
    register["meta"]["source_commit"] = "abc1234"
    assert tool.validate(register, source_commit="abc1234") == []
    release_problems = tool.validate(register, source_commit="abc1234", release=True)
    assert any("not at the release commit" in problem for problem in release_problems)


def test_a_blocked_entry_must_say_what_blocks_it():
    tool = _tool()
    problems = tool.validate(_register([_entry("R-01", "BLOCKED", evidence="")]))
    assert any("BLOCKED without saying what blocks it" in problem for problem in problems)


def test_a_status_outside_the_vocabulary_is_refused():
    tool = _tool()
    problems = tool.validate(_register([_entry("R-01", "MOSTLY_DONE")]))
    assert any("is not in the vocabulary" in problem for problem in problems)


def test_a_requirement_that_was_never_executed_cannot_survive_a_release():
    tool = _tool()
    register = _register([_entry("R-01", "NOT_TESTED", evidence="")])
    assert tool.validate(register, source_commit="abc1234") == []
    assert any("never executed" in problem for problem in tool.validate(register, source_commit="abc1234", release=True))


def test_duplicate_ids_are_refused_so_a_citation_means_one_thing():
    tool = _tool()
    problems = tool.validate(_register([_entry("R-01"), _entry("R-01", "PARTIAL")]))
    assert any("duplicate id" in problem for problem in problems)


# --------------------------------------------------------------------------- the gates
def test_the_fifteen_gates_are_numbered_and_split_ten_technical_five_external():
    tool = _tool()
    assert tool.validate(_register([_entry("R-01")])) == []
    wrong_kind = [_gate(n) for n in range(1, 16)]
    wrong_kind[10]["kind"] = "technical"  # gate 11 is external
    problems = tool.validate(_register([_entry("R-01")], wrong_kind))
    assert any("GATE 11: kind" in problem for problem in problems)
    missing = tool.validate(_register([_entry("R-01")], [_gate(n) for n in range(1, 15)]))
    assert any("14 gates, expected 15" in problem for problem in missing)
    gap = tool.validate(_register([_entry("R-01")], [_gate(n) for n in range(1, 15)] + [_gate(16)]))
    assert any("gate numbers" in problem for problem in gap)


def test_a_gate_without_an_owner_command_or_limitation_is_a_claim_not_evidence():
    tool = _tool()
    for field in ("owner", "environment", "command", "remaining_limitation"):
        gates = [_gate(n) for n in range(1, 16)]
        gates[0][field] = ""
        problems = tool.validate(_register([_entry("R-01")], gates))
        assert any(f"GATE 1: no {field}" in problem for problem in problems), field


def test_a_passed_gate_must_carry_its_evidence_timestamp_and_commit():
    tool = _tool()
    gates = [_gate(n) for n in range(1, 16)]
    gates[0]["result"] = "PASS"
    problems = tool.validate(_register([_entry("R-01")], gates))
    for field in ("evidence", "timestamp", "source_commit"):
        assert any(f"GATE 1: PASS without {field}" in problem for problem in problems), field


# --------------------------------------------------------------------------- the register of record
def test_the_register_in_the_repository_is_valid_and_its_document_is_current():
    register = json.loads(REGISTER.read_text())
    tool = _tool()
    assert tool.validate(tool.recount(copy.deepcopy(register)), source_commit=register["meta"]["source_commit"]) == []
    assert tool.render(tool.recount(copy.deepcopy(register))) == DOCUMENT.read_text(), (
        "the traceability document is generated: run python scripts/build_1_3_0_register.py"
    )


def test_every_carried_requirement_keeps_its_1_2_0_id_so_evidence_can_be_traced():
    register = json.loads(REGISTER.read_text())
    carried = [entry for entry in register["entries"] if entry.get("carried_from") == "1.2.0"]
    assert len(carried) == 58
    assert [entry["id"] for entry in carried] == [f"R-{number:02d}" for number in range(1, 59)]
