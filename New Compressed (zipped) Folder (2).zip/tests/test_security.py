"""Credentials, tokens, TOTP, secrets at rest, role model and configuration guard rails."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from churn_platform import security
from churn_platform.config import DEV_SECRET, Settings

pytestmark = pytest.mark.req("REQ-SEC-01")


def test_password_hash_is_salted_and_verifies():
    a, b = security.hash_password("Correct-Horse-Battery-9!"), security.hash_password("Correct-Horse-Battery-9!")
    assert a != b and a.startswith("scrypt$")
    assert security.verify_password("Correct-Horse-Battery-9!", a)
    assert not security.verify_password("correct-horse-battery-9!", a)
    assert "Correct-Horse" not in a


@pytest.mark.parametrize("stored", [None, "", "plain", "md5$1$2$3$4$5", "scrypt$x$8$1$AAAA$AAAA", "scrypt$16384$8$1$!!!$???"])
def test_verify_password_rejects_malformed_hashes(stored):
    assert security.verify_password("anything", stored) is False


@pytest.mark.parametrize(("password", "fragment"), [
    ("short1", "at least 12"), ("onlyletterslong", "letters and digits"), ("123456789012345", "letters and digits"), ("Password123", "at least 12"),
    ("letmein12345", "too common"),
])  # fmt: skip
def test_password_policy(password, fragment):
    assert any(fragment in p for p in security.password_problems(password, 12))
    assert security.password_problems("Correct-Horse-Battery-9!", 12) == []


def test_session_tokens_are_random_and_only_the_hash_is_derivable():
    t1, h1 = security.new_token()
    t2, h2 = security.new_token()
    assert t1 != t2 and h1 != h2 and len(t1) >= 40
    assert security.hash_token(t1) == h1 and t1 not in h1 and len(h1) == 64


def test_totp_matches_rfc6238_test_vectors():
    # RFC 6238 appendix B, SHA-1, secret "12345678901234567890" (8-digit codes; ours are the last 6 digits)
    secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    for at, expected in ((59, "94287082"), (1111111109, "07081804"), (1111111111, "14050471"), (1234567890, "89005924"), (2000000000, "69279037")):
        assert security.totp_code(secret, at=at) == expected[-6:]


def test_totp_window_and_replay_protection():
    secret = security.totp_new_secret()
    now = 1_700_000_000.0
    code = security.totp_code(secret, at=now)
    counter = security.totp_verify(secret, code, at=now)
    assert counter == int(now // 30)
    assert security.totp_verify(secret, code, at=now + 30) == counter, "one step of clock skew is tolerated"
    assert security.totp_verify(secret, code, at=now + 90) is None
    assert security.totp_verify(secret, code, at=now, last_counter=counter) is None, "a used code cannot be replayed"
    assert security.totp_verify(secret, "abcdef", at=now) is None and security.totp_verify(secret, "", at=now) is None
    assert security.totp_uri(secret, "a b@example.com").startswith("otpauth://totp/Churn%20Platform:a%20b%40example.com?secret=" + secret)


def test_secret_box_round_trip_and_tamper_detection():
    box = security.SecretBox("k" * 40)
    token = box.encrypt("api-token-value")
    assert "api-token-value" not in token and box.decrypt(token) == "api-token-value"
    assert box.encrypt("api-token-value") != token, "encryption is randomised"
    with pytest.raises(ValueError, match="decrypt"):
        security.SecretBox("another-key" * 5).decrypt(token)
    with pytest.raises(ValueError, match="decrypt"):
        box.decrypt(token[:-4] + "AAAA")


def test_hmac_helpers():
    sig = security.hmac_sha256_hex("secret", b'{"a":1}')
    assert len(sig) == 64 and sig != security.hmac_sha256_hex("secret", b'{"a":2}')
    assert security.constant_time_equals(sig, sig) and not security.constant_time_equals(sig, sig[:-1] + "0")


@pytest.mark.req("REQ-SEC-02")
def test_role_model_is_least_privilege():
    perms = security.ROLE_PERMISSIONS
    assert perms["admin"] == security.ALL_PERMISSIONS
    assert all(p.endswith(":read") for p in perms["viewer"])
    for role, granted in perms.items():
        assert granted <= security.ALL_PERMISSIONS, role
    # separation of duties: those who build models or policies cannot approve them (admin aside)
    for role in ("data_scientist", "data_engineer", "analyst", "csm", "viewer", "auditor"):
        assert not {"ml:approve", "policy:approve", "features:approve", "retention:approve"} & perms[role], role
    assert "ml:train" not in perms["approver"] and "policy:write" not in perms["approver"]
    assert "admin:users" not in perms["approver"] and "admin:users" not in perms["auditor"]
    assert "customers:export" not in perms["csm"] and "customers:export" not in perms["viewer"]
    assert "data:read" not in perms["csm"], "customer-success staff do not see raw imports"


@pytest.mark.req("REQ-SEC-06")
@pytest.mark.parametrize(("overrides", "fragment"), [
    ({}, "CHURN_SECRET_KEY"),
    ({"secret_key": "x" * 40}, "PostgreSQL"),
    ({"secret_key": "x" * 40, "database_url": "postgresql+psycopg://u:p@h/db", "allow_self_approval": True}, "ALLOW_SELF_APPROVAL"),
    ({"secret_key": "x" * 40, "database_url": "postgresql+psycopg://u:p@h/db", "embedded_worker": True}, "EMBEDDED_WORKER"),
    ({"secret_key": "x" * 40, "database_url": "postgresql+psycopg://u:p@h/db"}, "ALLOW_FRAMING"),
    ({"secret_key": DEV_SECRET, "database_url": "postgresql+psycopg://u:p@h/db", "allow_framing": False}, "CHURN_SECRET_KEY"),
])  # fmt: skip
def test_production_refuses_unsafe_configuration(overrides, fragment, monkeypatch):
    monkeypatch.delenv("CHURN_SECRET_KEY", raising=False)
    with pytest.raises(ValidationError, match=fragment):
        Settings(env="production", **overrides)


@pytest.mark.req("REQ-SEC-06")
def test_production_accepts_a_safe_configuration_and_test_profile_is_lenient(monkeypatch):
    monkeypatch.delenv("CHURN_SECRET_KEY", raising=False)
    ok = Settings(env="production", secret_key="x" * 40, database_url="postgresql+psycopg://u:p@h/db", allow_framing=False)
    assert ok.is_production_like and not ok.is_sqlite
    assert Settings(env="staging", secret_key="x" * 40, database_url="postgresql+psycopg://u:p@h/db").allow_framing is True
    dev = Settings(env="development")
    assert dev.secret_key.get_secret_value() == DEV_SECRET and "x" * 5 not in repr(ok.secret_key)
    assert Settings(mfa_required_roles="admin, approver").mfa_required_role_set == {"admin", "approver"}
