"""Training data assembly: chronological splits, purging, train-only preprocessing, leakage checks, TEST quarantine."""

from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from churn_platform import storage
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, NotFound, ValidationFailed
from churn_platform.models import FeatureContract, MLDataset, Policy
from churn_platform.services import feature_engine as fe
from churn_platform.services import mlprep

pytestmark = pytest.mark.req("REQ-ML-03")
MONTHS = [date(2026, m, 1) for m in range(1, 10)]


# ----------------------------------------------------------------------------- splitting
def test_chronological_split_keeps_the_latest_dates_for_validation_and_test():
    split = mlprep.chronological_split([*list(reversed(MONTHS)), MONTHS[0]], valid_dates=2, test_dates=2)
    assert split == {"train": MONTHS[:5], "valid": MONTHS[5:7], "test": MONTHS[7:]}
    assert max(split["train"]) < min(split["valid"]) and max(split["valid"]) < min(split["test"])
    with pytest.raises(ValidationFailed) as exc:
        mlprep.chronological_split(MONTHS[:5], 2, 2)
    assert exc.value.code == "not_enough_history"
    with pytest.raises(ValidationFailed):
        mlprep.chronological_split(MONTHS, 0, 2)


def test_purging_drops_as_of_dates_whose_label_window_reaches_into_the_next_split():
    kept, dropped = mlprep.purge(MONTHS[:5], date(2026, 6, 1), horizon_days=30, embargo_days=0)
    assert (kept, dropped) == (MONTHS[:5], []), "1 May + 30 days = 31 May, which closes before 1 June"
    kept, dropped = mlprep.purge(MONTHS[:2], date(2026, 3, 1), horizon_days=30, embargo_days=0)
    assert (kept, dropped) == ([date(2026, 1, 1)], [date(2026, 2, 1)]), "1 Feb + 30 days = 3 March: the window overlaps the next split"
    kept, dropped = mlprep.purge(MONTHS[:5], date(2026, 6, 1), horizon_days=30, embargo_days=7)
    assert dropped == [date(2026, 5, 1)], "an embargo widens the gap"
    kept, dropped = mlprep.purge(MONTHS[:5], date(2026, 6, 1), horizon_days=60, embargo_days=0)
    assert (kept, dropped) == (MONTHS[:4], [date(2026, 5, 1)]), "1 April + 60 days = 31 May still closes in time; 1 May does not"
    assert mlprep.purge(MONTHS[:5], date(2026, 6, 1), horizon_days=61, embargo_days=0)[1] == [date(2026, 5, 1)], (
        "1 April + 61 days = 1 June: a window may close exactly when the next split starts, because it only covers events before that instant")
    assert mlprep.purge(MONTHS[:5], date(2026, 6, 1), horizon_days=62, embargo_days=0)[1] == [date(2026, 4, 1), date(2026, 5, 1)]


def test_temporal_folds_validate_only_on_later_dates_with_closed_label_windows():
    for n_folds in (1, 2, 3, 5, 20):
        folds = mlprep.temporal_folds(MONTHS, n_folds, horizon_days=30)
        assert 1 <= len(folds) <= min(n_folds, len(MONTHS) - 1)
        for fit, validate in folds:
            assert fit and validate
            assert all(d + timedelta(days=30) <= min(validate) for d in fit), "no training label window overlaps the validation period"
        later = [min(v) for _, v in folds]
        assert later == sorted(later), "folds move forward in time (expanding window)"
    assert mlprep.temporal_folds(MONTHS[:2], 3, horizon_days=30) == [([date(2026, 1, 1)], [date(2026, 2, 1)])]


# ----------------------------------------------------------------------------- preprocessing
def _frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows)


def test_preprocessor_is_fitted_on_train_only_and_handles_unseen_and_missing_values():
    names = ["mrr", "avg_csat_90d", "industry"]
    train = _frame([{"mrr": 100.0, "avg_csat_90d": 4.0, "industry": "software"}, {"mrr": 300.0, "avg_csat_90d": np.nan, "industry": "retail"},
                    {"mrr": 200.0, "avg_csat_90d": 2.0, "industry": "software"}])  # fmt: skip
    spec = mlprep.fit_preprocessor(train, names)
    assert spec["numeric"] == {"mrr": {"median": 200.0, "indicator": False}, "avg_csat_90d": {"median": 3.0, "indicator": True}}
    assert spec["categorical"] == {"industry": ["retail", "software"]}
    assert spec["columns"] == ["mrr", "avg_csat_90d", "avg_csat_90d__missing", "industry=retail", "industry=software", "industry=__other__", "industry=__missing__"]
    assert spec["source"]["industry=__other__"] == "industry" and spec["source"]["avg_csat_90d__missing"] == "avg_csat_90d"
    later = _frame([{"mrr": np.nan, "avg_csat_90d": np.nan, "industry": "brand-new"}, {"mrr": 1e9, "avg_csat_90d": 5.0, "industry": None},
                    {"mrr": 50.0, "avg_csat_90d": 1.0, "industry": "retail"}])  # fmt: skip
    out = mlprep.transform(spec, later)
    assert list(out.columns) == spec["columns"] and not out.isna().any().any()
    assert out["mrr"].tolist() == [200.0, 1e9, 50.0], "missing values get the TRAIN median, whatever the later data looks like"
    assert out["avg_csat_90d"].tolist() == [3.0, 5.0, 1.0] and out["avg_csat_90d__missing"].tolist() == [1.0, 0.0, 0.0]
    assert out["industry=__other__"].tolist() == [1.0, 0.0, 0.0] and out["industry=__missing__"].tolist() == [0.0, 1.0, 0.0]
    assert out["industry=retail"].tolist() == [0.0, 0.0, 1.0] and (out.filter(like="industry=").sum(axis=1) == 1).all()
    assert mlprep.fit_preprocessor(later, names)["numeric"]["mrr"]["median"] != spec["numeric"]["mrr"]["median"], "refitting on other data would differ"
    pd.testing.assert_frame_equal(out, mlprep.transform(spec, later))
    empty = mlprep.fit_preprocessor(_frame([{"mrr": np.nan, "avg_csat_90d": np.nan, "industry": None}]), names)
    assert empty["numeric"]["mrr"] == {"median": 0.0, "indicator": True} and empty["categorical"]["industry"] == []


def test_rare_categories_are_capped():
    train = _frame([{"industry": f"industry-{n % 30:02d}"} for n in range(300)] + [{"industry": "industry-00"}] * 5)
    spec = mlprep.fit_preprocessor(train, ["industry"])
    assert len(spec["categorical"]["industry"]) == mlprep.MAX_CATEGORIES == 20 and "industry-00" in spec["categorical"]["industry"]


# ----------------------------------------------------------------------------- the seeded dataset
@pytest.fixture
def dataset(ro):
    with read_session() as s:
        return s.get(MLDataset, ro.summary["dataset_id"])


def test_seeded_dataset_passes_every_leakage_check(dataset):
    assert dataset.status == "ready" and dataset.leakage_report["passed"] is True
    checks = {c["check"]: c["passed"] for c in dataset.leakage_report["checks"]}
    assert checks == dict.fromkeys(["chronological_order", "train_label_windows_close_before_validation", "validation_label_windows_close_before_test",
                                    "no_duplicate_rows", "features_strictly_before_as_of_date", "no_outcome_columns_in_features",
                                    "no_single_feature_separates_classes"], True)  # fmt: skip
    balance, horizon = dataset.class_balance, dataset.config["horizon_days"]
    spans = {k: [date.fromisoformat(d) for d in balance[k]["as_of_dates"]] for k in ("train", "valid", "test")}
    assert max(spans["train"]) + timedelta(days=horizon) <= min(spans["valid"]) and max(spans["valid"]) + timedelta(days=horizon) <= min(spans["test"])
    assert all(d.day == 1 for dates in spans.values() for d in dates), "as-of dates are month starts"
    assert dataset.leakage_report["information"]["customers_in_both_train_and_test"] > 0, "panel data: stated openly, not hidden"
    for name in ("train", "valid", "test"):
        assert 0 < balance[name]["positives"] < balance[name]["rows"] and balance[name]["positive_rate"] < 0.2, "churn is the minority class"
    assert not Path(dataset.storage_path).is_absolute(), "stored relative to the data directory"


def test_stored_splits_match_their_fingerprints_and_the_recorded_balance(dataset):
    frames = {"train": mlprep.load_split(dataset, "train"), "valid": mlprep.load_split(dataset, "valid"),
              "test": mlprep.load_split(dataset, "test", purpose=mlprep.TEST_PURPOSE)}  # fmt: skip
    seen: set = set()
    for name, frame in frames.items():
        assert len(frame) == dataset.row_counts[name] == dataset.class_balance[name]["rows"]
        assert int(frame["label"].sum()) == dataset.class_balance[name]["positives"]
        assert mlprep.fingerprint_frame(frame) == dataset.row_counts["fingerprints"][name]
        assert list(frame.columns[:4]) == ["customer_id", "as_of_date", "label", "churn_type"] and set(frame["label"]) == {0, 1}
        assert not set(frame.columns) & set(fe.FORBIDDEN_SOURCE_COLUMNS), "no outcome column travels with the features"
        keys = set(zip(frame["customer_id"], frame["as_of_date"], strict=True))
        assert len(keys) == len(frame) and not keys & seen, "no row appears twice or in two splits"
        seen |= keys
    assert frames["train"]["as_of_date"].max() < frames["valid"]["as_of_date"].min() <= frames["valid"]["as_of_date"].max() < frames["test"]["as_of_date"].min()
    spec = dataset.preprocessing
    names = list(dict.fromkeys(spec["source"].values()))
    assert spec == mlprep.fit_preprocessor(frames["train"], names), "the stored preprocessing was fitted on TRAIN"
    assert spec != mlprep.fit_preprocessor(pd.concat([frames["train"], frames["test"]]), names), "... and not on TRAIN plus TEST"


def test_test_split_is_released_only_for_the_final_evaluation(dataset):
    for purpose in ("training", "selection", "tuning", ""):
        with pytest.raises(mlprep.TestSplitAccessError):
            mlprep.load_split(dataset, "test", purpose=purpose)
    with pytest.raises(mlprep.TestSplitAccessError):
        mlprep.load_split(dataset, "test")
    with pytest.raises(ValueError, match="unknown split"):
        mlprep.load_split(dataset, "holdout")
    assert len(mlprep.load_split(dataset, "test", purpose=mlprep.TEST_PURPOSE)) == dataset.row_counts["test"]


def test_a_modified_split_file_is_refused(demo):
    with read_session() as s:
        dataset = s.get(MLDataset, demo.summary["dataset_id"])
    path = storage.resolve(dataset.storage_path) / "train.parquet"
    frame = pd.read_parquet(path)
    frame.loc[0, "label"] = 1 - frame.loc[0, "label"]
    frame.to_parquet(path, index=False)
    with pytest.raises(RuntimeError, match="does not match its recorded fingerprint"):
        mlprep.load_split(dataset, "train")
    assert len(mlprep.load_split(dataset, "valid")) == dataset.row_counts["valid"]


def test_leakage_report_catches_a_planted_leak_and_broken_ordering(dataset):
    parts = {"train": mlprep.load_split(dataset, "train"), "valid": mlprep.load_split(dataset, "valid"),
             "test": mlprep.load_split(dataset, "test", purpose=mlprep.TEST_PURPOSE)}  # fmt: skip
    names = list(dict.fromkeys(dataset.preprocessing["source"].values()))
    none_dropped = {"train": [], "valid": []}
    clean = mlprep.leakage_report(parts, none_dropped, 30, 0, names, True)
    assert clean["passed"] is True
    leaky = {**parts, "train": parts["train"].assign(tenure_days=parts["train"]["label"] * 1000.0 + parts["train"]["tenure_days"] % 7)}
    report = mlprep.leakage_report(leaky, none_dropped, 30, 0, names, True)
    failed = {c["check"]: c for c in report["checks"] if not c["passed"]}
    assert report["passed"] is False and list(failed) == ["no_single_feature_separates_classes"]
    assert failed["no_single_feature_separates_classes"]["detail"]["suspicious"] == [{"feature": "tenure_days", "single_feature_auc": 1.0}]
    swapped = mlprep.leakage_report({"train": parts["valid"], "valid": parts["train"], "test": parts["test"]}, none_dropped, 30, 0, names, True)
    assert {c["check"] for c in swapped["checks"] if not c["passed"]} >= {"chronological_order", "train_label_windows_close_before_validation"}
    assert mlprep.leakage_report(parts, none_dropped, 30, 0, names, False)["passed"] is False, "a feature vector newer than its as-of date fails the dataset"
    assert mlprep.leakage_report(parts, none_dropped, 30, 45, names, True)["passed"] is False, "an embargo the split does not respect is reported"
    doubled = {**parts, "valid": pd.concat([parts["valid"], parts["valid"].head(1)])}
    assert {c["check"] for c in mlprep.leakage_report(doubled, none_dropped, 30, 0, names, True)["checks"] if not c["passed"]} == {"no_duplicate_rows"}


def test_target_specific_datasets_drop_the_competing_churn_type(ro):
    with read_session() as s:
        ds = s.get(MLDataset, ro.summary["dataset_id"])
        contract, policy = s.get(FeatureContract, ds.contract_id), s.get(Policy, ds.policy_id)
        everything = mlprep.assemble(s, ro.tenant_id, contract, policy, "all")
        voluntary = mlprep.assemble(s, ro.tenant_id, contract, policy, "voluntary")
        involuntary = mlprep.assemble(s, ro.tenant_id, contract, policy, "involuntary")
    positives = everything[everything["label"] == 1]
    n_vol, n_inv = (positives["churn_type"] == "voluntary").sum(), (positives["churn_type"] == "involuntary").sum()
    assert n_vol > 0 and n_inv > 0
    assert voluntary["label"].sum() == n_vol and set(voluntary.loc[voluntary["label"] == 1, "churn_type"]) == {"voluntary"}
    assert involuntary["label"].sum() == n_inv
    assert len(voluntary) == len(everything) - (len(positives) - n_vol), "other churn types are removed, not relabelled as retained"
    assert (everything["label"] == 0).sum() == (voluntary["label"] == 0).sum() == (involuntary["label"] == 0).sum()


def test_build_requests_are_validated(demo):
    admin = demo.principal("admin")
    contract_id = demo.summary["contract_id"]
    bad = [({"name": " "}, "name is required"), ({"target": "everything"}, "target must be"), ({"embargo_days": -1}, "embargo_days"),
           ({"embargo_days": 400}, "embargo_days"), ({"valid_dates": 0}, "at least 1"), ({"test_dates": 0}, "at least 1")]  # fmt: skip
    for overrides, message in bad:
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            mlprep.start_build(s, admin, **{"name": "x", "contract_id": contract_id, **overrides})
    with session_scope() as s, pytest.raises(NotFound):
        mlprep.start_build(s, admin, name="x", contract_id=999_999)
    # too little history for the requested split fails the job permanently with a clear message
    with session_scope() as s:
        ds, job = mlprep.start_build(s, admin, name="too_greedy", contract_id=contract_id, valid_dates=40, test_dates=40)
        ds_id, job_id = ds.id, job.id
        assert ds.version == 1
    from churn_platform.models import Job
    from churn_platform.worker.runner import Worker

    Worker().drain()
    with read_session() as s:
        ds, job = s.get(MLDataset, ds_id), s.get(Job, job_id)
        assert (ds.status, job.status, job.attempts) == ("failed", "failed", 1) and "mature as-of dates" in ds.error
        with pytest.raises(Conflict) as exc:
            mlprep.require_ready(ds)
        assert exc.value.code == "dataset_not_ready"
    # an embargo creates a new dataset version whose purged dates are recorded
    with read_session() as s:
        seeded = s.get(MLDataset, demo.summary["dataset_id"])
    with session_scope() as s:
        ds_id = mlprep.start_build(s, admin, name=seeded.name, contract_id=contract_id, embargo_days=7)[0].id
    Worker().drain()
    with read_session() as s:
        ds = s.get(MLDataset, ds_id)
        purged = {c["check"]: c["detail"].get("purged_as_of_dates") for c in ds.leakage_report["checks"]}
    assert (ds.status, ds.version, ds.config["embargo_days"]) == ("ready", seeded.version + 1, 7), ds.error
    assert purged["train_label_windows_close_before_validation"] and purged["validation_label_windows_close_before_test"]
    assert ds.fingerprint != seeded.fingerprint and ds.row_counts["train"] < seeded.row_counts["train"]
