"""Backup and restore, with a real restore (1.2.0).

A backup that has never been restored is a hope.  These tests take an archive of the seeded tenant, destroy the
database, restore it into an empty place, and compare the result with what was there before — then check that a
tampered archive is refused instead of half-restored.
"""

from __future__ import annotations

import shutil
import tarfile
from pathlib import Path

import pytest

from churn_platform import backup
from churn_platform.errors import ValidationFailed

pytestmark = pytest.mark.req("REQ-OPS-05")


def _counts() -> dict:
    return backup._health(backup._database_url())["counts"]


def test_an_archive_restores_to_the_same_database_and_a_tampered_one_does_not_restore_at_all(demo, tmp_path):
    demo.drain()
    before = _counts()
    assert before["customers"] > 0 and before["audit_events"] > 0
    archive = tmp_path / "backup.tar.gz"
    manifest = backup.backup(archive, data_dir=demo.data_dir, note="the test's own backup")

    assert archive.exists() and manifest["engine"] == "sqlite-vacuum-into"
    assert manifest["revision"] == backup.current_revision(backup._database_url())
    assert {m["name"] for m in manifest["members"]} == {"database"} | {m["name"] for m in manifest["members"] if m["name"].startswith("data/")}
    assert manifest["archive"]["sha256"] == backup._sha256(archive)

    report = backup.inspect(archive)
    assert report["valid"] is True and report["problems"] == []

    # destroy the database and the data directory, then restore from the archive alone
    destroyed = Path(demo.db_path)
    shutil.rmtree(demo.data_dir)
    destroyed.unlink()
    assert not destroyed.exists()
    result = backup.restore(archive, data_dir=demo.data_dir)
    assert result["restored"] is True and result["revision_matches"] is True
    assert result["health"]["counts"] == before, "every table came back with the same number of rows"
    assert result["health"]["newest_audit_event"] == backup._health(backup._database_url())["newest_audit_event"]
    assert Path(demo.data_dir).is_dir()

    # a restore over an existing database needs --force, so that a mistake is not a silent overwrite
    with pytest.raises(ValidationFailed) as existing:
        backup.restore(archive, data_dir=demo.data_dir)
    assert existing.value.details["field"] == "database"
    assert backup.restore(archive, data_dir=demo.data_dir, force=True)["revision_matches"] is True

    # an archive whose bytes were changed is refused before anything is touched
    tampered = tmp_path / "tampered.tar.gz"
    raw = archive.read_bytes()
    tampered.write_bytes(raw[: len(raw) // 2])
    with pytest.raises((ValidationFailed, tarfile.TarError, EOFError)):
        backup.restore(tampered, data_dir=demo.data_dir, force=True)
    assert _counts() == before, "a refused archive leaves the database alone"

    # a member whose content no longer matches its checksum is reported, not restored
    import io
    import json as json_module

    edited = tmp_path / "edited.tar.gz"
    with tarfile.open(archive, "r:gz") as source:
        original = json_module.loads(source.extractfile("manifest.json").read())
    doctored = b"not the database that was backed up"
    with tarfile.open(edited, "w:gz") as target:
        info = tarfile.TarInfo("database")
        info.size = len(doctored)
        target.addfile(info, io.BytesIO(doctored))
        blob = json_module.dumps(original).encode()
        manifest_info = tarfile.TarInfo("manifest.json")
        manifest_info.size = len(blob)
        target.addfile(manifest_info, io.BytesIO(blob))
    report = backup.inspect(edited)
    assert report["valid"] is False and report["problems"] and "checksum" in report["problems"][0]
    with pytest.raises(ValidationFailed) as tampered_member:
        backup.restore(edited, data_dir=demo.data_dir, force=True)
    assert tampered_member.value.code == "validation_failed"
    assert _counts() == before, "a checksum failure leaves the database alone"

    with pytest.raises(ValidationFailed):
        backup.inspect(tmp_path / "does-not-exist.tar.gz")


def test_the_postgres_client_tools_are_given_a_url_they_understand(monkeypatch, tmp_path):
    """pg_dump does not know what ``+psycopg`` is.

    Handing it the SQLAlchemy URL makes libpq fall back to its defaults — a local socket and the operating system's
    user name — and the backup fails on a server that is running perfectly well.  The scheme is translated, and the
    credentials, host, port, database and query survive untouched.
    """
    url = "postgresql+psycopg://churn:s3cret@db.internal:6432/churn_prod?sslmode=require"
    assert backup.libpq_url(url) == "postgresql://churn:s3cret@db.internal:6432/churn_prod?sslmode=require"
    assert backup.libpq_url("postgresql://plain@127.0.0.1/churn") == "postgresql://plain@127.0.0.1/churn"
    assert backup.libpq_url("sqlite:////var/lib/churn/churn.db") == "sqlite:////var/lib/churn/churn.db"
    assert backup.libpq_url("postgresql+psycopg2://a@b/c") == "postgresql://a@b/c"

    seen: list[list[str]] = []

    class _Done:
        returncode = 0
        stderr = ""

    def _run(argv, **kwargs):
        seen.append(list(argv))
        Path(argv[argv.index("--file") + 1]).write_bytes(b"PGDMP fake dump")  # what pg_dump would have written
        return _Done()

    monkeypatch.setattr(backup.shutil, "which", lambda name: f"/usr/bin/{name}")
    monkeypatch.setattr(backup.subprocess, "run", _run)
    target = tmp_path / "dump"
    assert backup._dump_database(url, target) == "pg_dump"
    assert seen and seen[0][-1] == "postgresql://churn:s3cret@db.internal:6432/churn_prod?sslmode=require"
    assert "+psycopg" not in " ".join(seen[0])
