"""The release validator must not pass on evidence from another commit (1.3.0, BUG 4).

The reproduction this file was written from, run against the tool as it stood at ``b4fd131``::

    actual HEAD: b4fd131  register says source_commit: 0224654
    problems reported in --release mode: []
    -> a release PASS is possible with evidence from a commit that is not the tree: True

``--release`` compared the register's ``meta.source_commit`` with the ``--source-commit`` argument, and ``main`` passed
it the register's own value.  The check asked the document to confirm itself, so a register nobody had touched since the
1.2.0 release passed with 26 PASSes that had been earned at ``0224654``.  That is the false PASS this file exists to
prevent, and the reason the real behaviour is now: **the claim is compared with ``git``, and the evidence is compared
with the claim.**

Four questions are asked of a release, and each of them can only answer "no":

1. does the register name the tree's commit — or a documentation-only commit above it, the one exception spelled out in
   ``release_commits`` because the register cannot contain its own commit hash?
2. is every PASS and FAIL verified at that commit, and not at an older one? (A PARTIAL is exempt: it states what is
   missing rather than what ran, and holding it to a commit made sixteen honest entries into release blockers.)
3. is the working tree clean, so the commit can be named at all?
4. was any test actually run — is there a JUnit file, does its sidecar name that commit and that command, does its digest
   still match, are there no failures, no errors and **no skips**, and do two runs of the suite agree test by test?

A skipped test is a test that did not run.  A suite that reports 558 tests with 58 of them skipped is not a 558-test
baseline, and 1.3.0's own audit had to correct two reports for exactly that arithmetic.
"""

from __future__ import annotations

import copy
import json
import subprocess

import pytest

from churn_platform.errors import ValidationFailed  # noqa: F401 - imported so the module fails loudly if it is moved

pytestmark = pytest.mark.req("REQ-QA-01")

TOOL = __import__("importlib").import_module("importlib")
import importlib.util  # noqa: E402
from pathlib import Path  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def _tool():
    spec = importlib.util.spec_from_file_location("register_tool", ROOT / "scripts" / "build_1_3_0_register.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _entry(rid="R-01", status="PASS", *, verified_at="abc1234", evidence="tests/test_something.py: 7 passed at the commit named here"):
    return {
        "id": rid,
        "area": "test",
        "requirement": "a thing that must be true",
        "status": status,
        "verified_at": verified_at,
        "evidence": evidence,
        "blocked_by": "a vendor sandbox" if status == "BLOCKED" else "",
        "next_step": "",
    }


def _gate(number, result="PASS", commit="abc1234"):
    return {
        "id": f"GATE {number}",
        "kind": "technical" if number <= 10 else "external",
        "result": result,
        "title": "a gate",
        "owner": "platform",
        "environment": "the build machine",
        "command": "python3 -m pytest -q",
        "evidence": "a log",
        "timestamp": "2026-11-10T00:00:00Z",
        "source_commit": commit,
        "remaining_limitation": "none known",
    }


def _register(entries, gates=None):
    return {
        "meta": {"baseline_release": "1.2.0", "baseline_commit": "0224654", "source_commit": "abc1234", "document": "test"},
        "entries": entries,
        "gates": gates if gates is not None else [_gate(n) for n in range(1, 16)],
    }


# --------------------------------------------------------------------------- the register against the tree
def test_a_register_that_claims_another_commit_than_the_tree_fails_a_release():
    """The defect, verbatim: ``0224654`` in the register, ``b4fd131`` in the source, and ``--release`` said nothing."""
    tool = _tool()
    register = _register([_entry()])
    register["meta"]["source_commit"] = "0224654"
    problems = tool.validate(register, source_commit="0224654", release=True, actual_commit="b4fd131")
    assert any("claims" in problem and "0224654" in problem and "b4fd131" in problem for problem in problems), problems


def test_every_pass_belonging_to_an_older_commit_fails_a_release():
    tool = _tool()
    register = _register([_entry(verified_at="0224654")])
    problems = tool.validate(register, source_commit="abc1234", release=True, actual_commit="abc1234")
    assert any("not at the release commit abc1234" in problem for problem in problems)


def test_a_release_never_silently_accepts_a_pass_with_no_commit():
    """The old condition let ``verified_at is None`` through in release mode — the one entry that could not be checked."""
    tool = _tool()
    register = _register([_entry(verified_at=None)])
    problems = tool.validate(register, source_commit="abc1234", release=True, actual_commit="abc1234")
    assert any("without a commit it was verified at" in problem for problem in problems)


def test_a_gate_that_passed_at_another_commit_fails_a_release():
    tool = _tool()
    register = _register([_entry()], [_gate(n, commit="0224654") for n in range(1, 16)])
    problems = tool.validate(register, source_commit="abc1234", release=True, actual_commit="abc1234")
    assert any("GATE 1: PASS recorded at 0224654" in problem for problem in problems)


def test_a_consistent_register_at_the_tree_has_no_register_problems():
    tool = _tool()
    register = _register([_entry()])
    assert tool.validate(register, source_commit="abc1234", release=True, actual_commit="abc1234") == []


def test_the_documentation_only_commit_exception_is_however_many_documents_and_no_code(tmp_path, monkeypatch):
    """The register cannot contain the hash of the commit that contains it; that is the only exception, and it is checked.

    The register, the reports and the generated documents are written and rewritten after the last test run, so the
    evidence commit can be several documentation-only commits below the tree. What must never happen is a source, test
    or script file in between, because then the tested source is not the released source.
    """
    tool = _tool()
    monkeypatch.setattr(tool, "ROOT", tmp_path)
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.email", "test@example.invalid"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "test"], cwd=tmp_path, check=True)
    (tmp_path / "docs").mkdir()
    (tmp_path / "docs" / "a.md").write_text("one\n")
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-qm", "first"], cwd=tmp_path, check=True)
    first = tool.head_commit()

    (tmp_path / "docs" / "a.md").write_text("two\n")
    subprocess.run(["git", "commit", "-qam", "docs"], cwd=tmp_path, check=True)
    second = tool.head_commit()
    assert tool.release_commits(second, [first]) == {second, first}
    assert tool.release_commits(second) == {second}, "a candidate has to be named before it can be allowed"

    (tmp_path / "CHANGELOG.md").write_text("two\n")
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-qm", "changelog"], cwd=tmp_path, check=True)
    third = tool.head_commit()
    assert tool.release_commits(third, [first]) == {third, first}, \
        "two documentation-only commits above the evidence commit are still documentation only"

    (tmp_path / "src.py").write_text("x = 1\n")
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-qm", "code"], cwd=tmp_path, check=True)
    fourth = tool.head_commit()
    assert tool.release_commits(fourth, [first, third]) == {fourth}, \
        "a commit that changed code cannot lend its evidence to anything below it"


def test_a_dirty_tree_cannot_name_a_commit(tmp_path, monkeypatch):
    tool = _tool()
    monkeypatch.setattr(tool, "ROOT", tmp_path)
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    (tmp_path / "a.txt").write_text("x\n")
    assert tool.working_tree_problems(), "an untracked file is a tree that is not clean"


# --------------------------------------------------------------------------- the JUnit evidence
def _write_junit(path: Path, outcomes: dict[str, str], suite="tests.test_example") -> Path:
    cases = []
    for name, outcome in outcomes.items():
        inner = {"passed": "", "failed": "<failure message='assert False'/>", "error": "<error message='boom'/>",
                 "skipped": "<skipped message='no vendor credentials'/>"}[outcome]  # fmt: skip
        cases.append(f'<testcase classname="{suite}" name="{name}">{inner}</testcase>')
    path.write_text(f'<?xml version="1.0"?><testsuite tests="{len(cases)}">' + "".join(cases) + "</testsuite>")
    return path


def _sidecar(path: Path, *, commit="abc1234", sha256=True, command="python3 -m pytest -q", digest=None):
    import hashlib

    meta = {
        "junit": path.name,
        "commit": commit,
        "command": command,
        "started_at": "2026-11-10T06:00:00Z",
        "sha256": digest or (hashlib.sha256(path.read_bytes()).hexdigest() if sha256 else ""),
    }
    path.with_suffix(path.suffix + ".meta.json").write_text(json.dumps(meta))
    return path


def test_a_clean_run_at_the_named_commit_is_accepted(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {f"test_{n}": "passed" for n in range(5)}))
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=5)
    assert problems == []


def test_a_junit_file_with_a_failure_is_not_a_passing_suite(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed", "test_b": "failed"}))
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("1 failure(s) and 0 error(s)" in problem for problem in problems)


def test_a_skipped_test_is_not_an_executed_test_and_cannot_support_a_release(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed", "test_b": "skipped"}))
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("skipped test(s); a skip is not an executed test" in problem for problem in problems)


def test_a_junit_file_without_a_sidecar_cannot_be_tied_to_a_commit(tmp_path):
    tool = _tool()
    junit = _write_junit(tmp_path / "run.xml", {"test_a": "passed"})
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any(".meta.json is missing, so run.xml cannot be tied to a commit" in problem for problem in problems), problems


def test_a_sidecar_naming_an_older_commit_is_refused(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed"}), commit="0224654")
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("produced at 0224654, which is not the release commit abc1234" in problem for problem in problems)


def test_a_sidecar_that_does_not_say_how_the_suite_was_run_is_refused(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed"}), command="")
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("does not say how the suite was run" in problem for problem in problems)


def test_a_junit_file_edited_after_it_was_recorded_is_refused(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed"}), digest="0" * 64)
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("has changed since it was recorded" in problem for problem in problems)


def test_a_suite_smaller_than_the_recorded_baseline_is_refused(tmp_path):
    tool = _tool()
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed", "test_b": "passed"}))
    problems = tool.check_evidence([junit], commit="abc1234", allowed_commits={"abc1234"}, min_tests=558)
    assert any("fewer than the recorded baseline of 558" in problem for problem in problems)


def test_two_runs_of_the_same_commit_must_agree_test_by_test(tmp_path):
    tool = _tool()
    first = _sidecar(_write_junit(tmp_path / "run1.xml", {"test_a": "passed", "test_b": "passed"}))
    second = _sidecar(_write_junit(tmp_path / "run2.xml", {"test_a": "passed", "test_b": "failed"}))
    problems = tool.check_evidence([first, second], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("disagree on 1 test(s)" in problem for problem in problems)

    third = _sidecar(_write_junit(tmp_path / "run3.xml", {"test_a": "passed"}))
    problems = tool.check_evidence([first, third], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("not of the same suite" in problem for problem in problems)


def test_a_release_without_any_junit_file_was_not_executed(tmp_path):
    tool = _tool()
    problems = tool.check_evidence([], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("nothing was executed for this release" in problem for problem in problems)


def test_a_missing_junit_file_is_named(tmp_path):
    tool = _tool()
    problems = tool.check_evidence([tmp_path / "absent.xml"], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("absent.xml does not exist" in problem for problem in problems)


def test_a_file_that_is_not_junit_is_named(tmp_path):
    tool = _tool()
    bogus = tmp_path / "run.xml"
    bogus.write_text("this is not xml")
    problems = tool.check_evidence([bogus], commit="abc1234", allowed_commits={"abc1234"}, min_tests=1)
    assert any("not readable JUnit XML" in problem for problem in problems)


# --------------------------------------------------------------------------- the command line
def test_the_release_command_returns_non_zero_on_the_stale_register_and_says_why(tmp_path, capsys):
    tool = _tool()
    register = json.loads((ROOT / "docs" / "1_3_0_requirements.json").read_text())
    stale = copy.deepcopy(register)
    stale["meta"]["source_commit"] = "0224654"
    path = tmp_path / "register.json"
    path.write_text(json.dumps(stale))
    document = tmp_path / "traceability.md"
    exit_code = tool.main(["--release", "--allow-dirty", "--register", str(path), "--document", str(document)])
    captured = capsys.readouterr()
    assert exit_code == 1
    assert "the register claims" in captured.err and "0224654" in captured.err


def test_the_release_command_refuses_a_junit_with_a_failure_even_when_the_register_is_consistent(tmp_path, capsys):
    tool = _tool()
    register = json.loads((ROOT / "docs" / "1_3_0_requirements.json").read_text())
    consistent = copy.deepcopy(register)
    consistent["meta"]["source_commit"] = tool.head_commit()
    for entry in consistent["entries"]:
        if entry["status"] in ("PASS", "PARTIAL", "FAIL"):
            entry["verified_at"] = tool.head_commit()
    for gate in consistent["gates"]:
        if gate["result"] == "PASS":
            gate["source_commit"] = tool.head_commit()
    path = tmp_path / "register.json"
    path.write_text(json.dumps(consistent))
    junit = _sidecar(_write_junit(tmp_path / "run.xml", {"test_a": "passed", "test_b": "failed"}), commit=tool.head_commit())
    exit_code = tool.main(["--release", "--allow-dirty", "--register", str(path), "--document", str(tmp_path / "doc.md"),
                           "--junit", str(junit), "--min-tests", "1"])  # fmt: skip
    captured = capsys.readouterr()
    assert exit_code == 1
    assert "1 failure(s)" in captured.err
