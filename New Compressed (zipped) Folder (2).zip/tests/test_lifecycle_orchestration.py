"""Model lifecycle with promotion gates, the MLflow registry as registry of record, and pipeline steps run for an
external orchestrator (Apache Airflow)."""

from __future__ import annotations

import importlib.util
import json
import warnings

import pytest
from sqlalchemy import select, update

from churn_platform import cli, config
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, ServiceUnavailable, ValidationFailed
from churn_platform.models import AuditEvent, Job, MLDataset, ModelRun, ModelStageTransition, ModelVersion, OrchestratorRun, PredictionBatch
from churn_platform.services import evaluation, mlflow_mirror, orchestration, pipeline, policies, registry
from churn_platform.worker.runner import Worker
from tests.conftest import activate, require_or_skip

API = "/api/v1"


@pytest.fixture(autouse=True)
def default_gates(request):
    """The seeded demo has an approved promotion-gate policy with illustrative thresholds.  These tests state the
    gates they need, so each starts with the built-in defaults."""
    if "demo" not in request.fixturenames:
        return
    request.getfixturevalue("demo")
    from churn_platform.models import Policy

    with session_scope() as s:
        s.execute(Policy.__table__.delete().where(Policy.kind == "promotion_gates"))


def spare_run(demo, index: int = 0) -> int:
    """A seeded, completed run that is not in the registry yet (whichever algorithm it happens to be)."""
    with read_session() as s:
        taken = set(s.execute(select(ModelVersion.model_run_id)).scalars())
        runs = s.execute(select(ModelRun.id).where(ModelRun.status == "completed").order_by(ModelRun.id)).scalars().all()
    return [r for r in runs if r not in taken][index]


def candidate(demo, index: int = 0, *, test: bool = True) -> int:
    scientist = demo.principal("data_scientist")
    run_id = spare_run(demo, index)
    with session_scope() as s:
        if test:
            evaluation.evaluate(s, scientist, run_id, split="test")
        return registry.register(s, scientist, run_id).id


def history(version_id: int) -> list[tuple]:
    with read_session() as s:
        rows = s.execute(select(ModelStageTransition).where(ModelStageTransition.model_version_id == version_id).order_by(ModelStageTransition.id)).scalars().all()
        return [(r.from_state, r.to_state, r.decision) for r in rows]


def set_gates(demo, **gates) -> None:
    with session_scope() as s:
        policy = policies.create(s, demo.principal("admin"), kind="promotion_gates", name="default", payload=gates)
        policies.submit(s, demo.principal("admin"), policy.id)
        policies.review(s, demo.principal("approver"), policy.id, approve=True)


# ============================================================================= lifecycle and gates
@pytest.mark.req("REQ-ML-07")
def test_a_version_moves_through_the_lifecycle_and_every_step_is_on_record(demo):
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    with read_session() as s:
        seeded = s.execute(select(ModelVersion).where(ModelVersion.stage == "production")).scalar_one()
        assert seeded.lifecycle_state == "production" == registry.lifecycle_of(seeded) and seeded.validated_at is not None
        seeded_id = seeded.id
    assert history(seeded_id) == [("unregistered", "candidate", "applied"), ("candidate", "validated", "applied"), ("validated", "approved", "applied"),
                                  ("approved", "production", "applied")], "the seeded model went through every state"  # fmt: skip
    version_id = candidate(demo)
    with session_scope() as s:
        assert s.get(ModelVersion, version_id).lifecycle_state == "candidate"
        outcome = registry.validate(s, scientist, version_id)
        assert outcome["decision"] == "applied" and outcome["version"]["lifecycle_state"] == "validated" and outcome["policy_id"] is None
        by_gate = {g["gate"]: g for g in outcome["gates"]}
        assert by_gate["require_leakage_checks"]["status"] == by_gate["require_reproducible_training"]["status"] == by_gate["require_model_card"]["status"] == "pass"
        assert by_gate["min_test_pr_auc"]["status"] == "not_checked" and "no threshold" in by_gate["min_test_pr_auc"]["detail"]
        assert {g["status"] for g in outcome["gates"]} == {"pass", "not_checked"} and len(outcome["gates"]) == 10
    with session_scope() as s:
        registry.review(s, approver, version_id, approve=True, note="reviewed")
        assert s.get(ModelVersion, version_id).lifecycle_state == "approved"
        registry.set_stage(s, approver, version_id, "staging")
        registry.set_stage(s, approver, version_id, "production")
        assert s.get(ModelVersion, seeded_id).lifecycle_state == "archived" and s.get(ModelVersion, version_id).lifecycle_state == "production"
    assert history(version_id) == [("unregistered", "candidate", "applied"), ("candidate", "validated", "applied"), ("validated", "approved", "applied"),
                                   ("approved", "staging", "applied"), ("staging", "production", "applied")]  # fmt: skip
    assert history(seeded_id)[-1] == ("production", "archived", "applied")
    # rolling back to the earlier version is one more recorded transition
    with session_scope() as s:
        registry.set_stage(s, approver, seeded_id, "production")
        rows = s.execute(select(ModelStageTransition).where(ModelStageTransition.model_version_id == seeded_id).order_by(ModelStageTransition.id)).scalars().all()
        assert (rows[-1].from_state, rows[-1].to_state, rows[-1].note) == ("archived", "production", "rolled back to this version")
        assert registry.production_version(s, demo.tenant_id).id == seeded_id
    with demo.client() as c:
        viewer = demo.login(c, "viewer")
        listed = {v["id"]: v for v in c.get(f"{API}/ml/registry", headers=viewer).json()["items"]}
        assert listed[version_id]["lifecycle_state"] == "archived" and listed[seeded_id]["lifecycle_state"] == "production"
        trail = c.get(f"{API}/ml/registry/{version_id}/transitions", headers=viewer).json()
        assert trail["total"] == 6 and trail["items"][1]["gates"] and trail["items"][-1]["note"] == f"replaced by v{listed[seeded_id]['version']}"
        assert c.get(f"{API}/ml/registry/gates", headers=viewer).json()["source"].startswith("built-in defaults")


@pytest.mark.req("REQ-ML-07")
def test_promotion_gates_block_a_version_that_does_not_meet_them_and_the_block_is_recorded(demo):
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    version_id = candidate(demo)
    with read_session() as s:
        run = s.get(ModelRun, s.get(ModelVersion, version_id).model_run_id)
        pr_auc, positives = run.test_metrics["pr_auc"], run.test_metrics["positives"]
    set_gates(demo, min_test_pr_auc=round(pr_auc + 0.05, 4), min_test_positives=positives, max_pr_auc_drop_vs_production=0.9)
    with session_scope() as s:
        blocked = registry.validate(s, scientist, version_id)
        assert blocked["decision"] == "blocked" and blocked["version"]["lifecycle_state"] == "candidate" and blocked["policy_id"] is not None
        failed = [g for g in blocked["gates"] if g["status"] == "fail"]
        assert [(g["gate"], g["value"], g["threshold"]) for g in failed] == [("min_test_pr_auc", pr_auc, round(pr_auc + 0.05, 4))]
        assert {g["gate"]: g["status"] for g in blocked["gates"]}["min_test_positives"] == "pass"
    assert history(version_id)[-1] == ("candidate", "validated", "blocked")
    with session_scope() as s, pytest.raises(Conflict) as refused:
        registry.review(s, approver, version_id, approve=True)
    assert refused.value.code == "promotion_gates_failed" and refused.value.details[0]["gate"] == "min_test_pr_auc"
    with read_session() as s:
        assert s.get(ModelVersion, version_id).approval_status == "pending", "a version that fails a gate cannot be approved"
        assert s.execute(select(AuditEvent).where(AuditEvent.action == "ml.model_validation_blocked")).scalar_one().detail["failed_gates"] == ["min_test_pr_auc"]
    # the gates are relaxed (a new policy version): the same version now passes and can be approved
    set_gates(demo, min_test_pr_auc=round(pr_auc - 0.01, 4))
    with session_scope() as s:
        assert registry.validate(s, scientist, version_id)["decision"] == "applied"
        registry.review(s, approver, version_id, approve=True)
    assert [h[2] for h in history(version_id)] == ["applied", "blocked", "applied", "applied"]
    # a rejected version cannot be validated; a version without a test evaluation fails every gate that needs one
    untested = candidate(demo, 1, test=False)
    with session_scope() as s:
        result = registry.validate(s, scientist, untested)
        by_gate = {g["gate"]: g for g in result["gates"]}
        assert result["decision"] == "blocked" and by_gate["min_test_pr_auc"]["status"] == "fail" and "no final test evaluation" in by_gate["min_test_pr_auc"]["detail"]
        assert by_gate["require_model_card"]["status"] == "fail"
    with pytest.raises(ValidationFailed):
        policies.validate_payload("promotion_gates", {"min_test_pr_auc": 1.5})
    # every gate a policy may set is a gate that is checked and reported: a key nothing evaluates is refused, not stored and ignored
    assert set(policies.PromotionGates.model_fields) - {"description"} == set(registry.DEFAULT_GATES) == set(by_gate)
    with pytest.raises(ValidationFailed):
        policies.validate_payload("promotion_gates", {"require_different_approver": False})


@pytest.mark.req("REQ-ML-07")
def test_gates_catch_a_leaky_dataset_and_a_model_file_that_changed(demo):
    scientist = demo.principal("data_scientist")
    version_id = candidate(demo)
    with session_scope() as s:
        run = s.get(ModelRun, s.get(ModelVersion, version_id).model_run_id)
        dataset = s.get(MLDataset, run.dataset_id)
        dataset.leakage_report = {**dataset.leakage_report, "passed": False}
        original = run.artifact_sha256
        run.artifact_sha256 = "0" * 64
    with session_scope() as s:
        gates = {g["gate"]: g["status"] for g in registry.validate(s, scientist, version_id)["gates"]}
        assert gates["require_leakage_checks"] == "fail" and gates["require_reproducible_training"] == "fail"
        s.execute(update(ModelRun).where(ModelRun.id == s.get(ModelVersion, version_id).model_run_id).values(artifact_sha256=original))
    set_gates(demo, require_leakage_checks=False)
    with session_scope() as s:
        gates = {g["gate"]: g for g in registry.validate(s, scientist, version_id)["gates"]}
        assert gates["require_leakage_checks"]["status"] == "not_checked" and gates["require_reproducible_training"]["status"] == "pass"


# ============================================================================= MLflow as registry of record
def use_mlflow(demo, tmp_path, monkeypatch, *, registry_of_record: bool) -> str:
    require_or_skip(importlib.util.find_spec("mlflow") is not None, "the optional 'mlflow' package is not installed (pip install -e '.[mlops]')")
    store = tmp_path / "mlflow"
    store.mkdir()
    monkeypatch.chdir(store)
    uri = f"sqlite:///{store / 'tracking.db'}"
    env = {"CHURN_MLFLOW_TRACKING_URI": uri, **({"CHURN_MODEL_REGISTRY": "mlflow"} if registry_of_record else {})}
    activate(demo.db_path, demo.data_dir, **env)
    mlflow_mirror.reset_cache()
    return uri


@pytest.mark.mlflow_live
@pytest.mark.slow
@pytest.mark.req("REQ-ML-07", "REQ-ML-06")
def test_mlflow_follows_the_lifecycle_and_names_the_latest_validated_and_the_production_model(demo, tmp_path, monkeypatch):
    uri = use_mlflow(demo, tmp_path, monkeypatch, registry_of_record=False)
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    version_id = candidate(demo)
    Worker().drain()
    with read_session() as s:
        version = s.get(ModelVersion, version_id)
        assert version.mlflow_model_version == "1" and version.mlflow_registered_name == f"churn-platform.tenant-{demo.tenant_id}.churn-model" and version.mlflow_run_id
    assert mlflow_mirror.latest_validated(demo.tenant_id) is None, "a candidate is not validated: the alias does not exist yet"
    with session_scope() as s:
        registry.validate(s, scientist, version_id)
    Worker().drain()
    validated = mlflow_mirror.latest_validated(demo.tenant_id)
    with read_session() as s:
        run = s.get(ModelRun, s.get(ModelVersion, version_id).model_run_id)
    assert validated["platform_version_id"] == version_id and validated["mlflow_version"] == "1" and validated["artifact_sha256"] == run.artifact_sha256
    assert validated["lifecycle_state"] == "validated" and validated["tags"]["platform.validated"] == "true"
    assert mlflow_mirror.resolve_alias(demo.tenant_id, "churn-model", "production") is None
    with session_scope() as s:
        registry.review(s, approver, version_id, approve=True)
        registry.set_stage(s, approver, version_id, "production")
    Worker().drain()
    production = mlflow_mirror.resolve_alias(demo.tenant_id, "churn-model", "production", use_cache=False)
    assert production["platform_version_id"] == version_id and production["lifecycle_state"] == "production"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        from mlflow.tracking import MlflowClient

        client = MlflowClient(tracking_uri=uri)
        versions = client.search_model_versions(f"name = 'churn-platform.tenant-{demo.tenant_id}.churn-model'")
    mine = [v for v in versions if v.tags.get("platform.model_version_id") == str(version_id)]
    assert len(mine) == 1 and len(versions) == 2, "one MLflow version per registry entry, however often it is synchronised (the archived model got its own)"
    with read_session() as s:
        synced = [e.action for e in s.execute(select(AuditEvent).where(AuditEvent.action.like("mlflow.%")).order_by(AuditEvent.id)).scalars()]
        jobs = [j.status for j in s.execute(select(Job).where(Job.job_type == "mlops.mlflow_mirror")).scalars()]
    assert synced[0] == "mlflow.mirrored" and synced.count("mlflow.mirrored") == 2 and synced.count("mlflow.synchronised") >= 3
    assert set(jobs) == {"succeeded"} and len(jobs) == len(synced)
    with demo.client() as c:
        page = c.get(f"{API}/ml/registry/mlflow", headers=demo.login(c, "admin")).json()
        assert page["status"] == "reachable" and page["registry_of_record"] == "platform" and page["aliases"]["production"]["platform_version_id"] == version_id
        assert page["aliases"]["staging"] is None and page["aliases"]["validated"]["mlflow_version"] == "1"


@pytest.mark.mlflow_live
@pytest.mark.slow
@pytest.mark.req("REQ-ML-07")
def test_with_mlflow_as_registry_of_record_nothing_serves_until_both_registries_agree(demo, tmp_path, monkeypatch):
    use_mlflow(demo, tmp_path, monkeypatch, registry_of_record=True)
    approver = demo.principal("approver")
    with session_scope() as s, pytest.raises(Conflict) as missing:
        registry.production_version(s, demo.tenant_id)
    assert missing.value.code == "registry_mismatch", "the seeded production model was never registered in this MLflow store"
    version_id = candidate(demo)
    with session_scope() as s:
        registry.review(s, approver, version_id, approve=True)
        registry.set_stage(s, approver, version_id, "production")
    with session_scope() as s, pytest.raises(Conflict):
        registry.production_version(s, demo.tenant_id)  # promoted here, MLflow not told yet
    Worker().drain()
    mlflow_mirror.reset_cache()
    with session_scope() as s:
        assert registry.production_version(s, demo.tenant_id).id == version_id, "MLflow's production alias names the same version and the same model file"
    # the model file recorded here no longer matches what MLflow registered: nothing serves
    with session_scope() as s:
        run_id = s.get(ModelVersion, version_id).model_run_id
        original = s.get(ModelRun, run_id).artifact_sha256
        s.execute(update(ModelRun).where(ModelRun.id == run_id).values(artifact_sha256="f" * 64))
    with session_scope() as s, pytest.raises(Conflict) as mismatch:
        registry.production_version(s, demo.tenant_id)
    assert mismatch.value.code == "registry_mismatch"
    with session_scope() as s:
        s.execute(update(ModelRun).where(ModelRun.id == run_id).values(artifact_sha256=original))
    # the registry cannot be reached: fail closed
    activate(demo.db_path, demo.data_dir, CHURN_MLFLOW_TRACKING_URI="http://127.0.0.1:9/", CHURN_MODEL_REGISTRY="mlflow", CHURN_MLFLOW_HTTP_TIMEOUT_SECONDS="2")
    monkeypatch.setenv("MLFLOW_HTTP_REQUEST_TIMEOUT", "2")
    monkeypatch.setenv("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "0")
    mlflow_mirror.reset_cache()
    with session_scope() as s, pytest.raises(ServiceUnavailable) as down:
        registry.production_version(s, demo.tenant_id)
    assert down.value.code == "registry_unavailable"
    with pytest.raises(Exception, match="CHURN_MODEL_REGISTRY=mlflow needs"):
        activate(demo.db_path, demo.data_dir, CHURN_ENV="production", CHURN_MODEL_REGISTRY="mlflow", CHURN_MLFLOW_TRACKING_URI="")
        config.get_settings()


# ============================================================================= external orchestration
def orchestrated(demo) -> None:
    activate(demo.db_path, demo.data_dir, CHURN_ORCHESTRATOR="airflow")


def runs() -> list[OrchestratorRun]:
    with read_session() as s:
        return list(s.execute(select(OrchestratorRun).order_by(OrchestratorRun.id)).scalars())


@pytest.mark.req("REQ-OPS-07")
def test_a_pipeline_step_runs_once_per_run_key_however_often_the_orchestrator_asks(demo):
    orchestrated(demo)
    first = orchestration.claim(demo.tenant_id, "data_quality", "scheduled__2026-11-01", dag_id="churn_nightly_pipeline", task_id="data_quality_demo")
    assert first["action"] == "started" and first["run"]["status"] == "running" and first["run"]["attempts"] == 1 and len(first["run"]["job_ids"]) == 1
    # the task is retried while the step is still running: it waits for the same job, nothing new starts
    again = orchestration.claim(demo.tenant_id, "data_quality", "scheduled__2026-11-01")
    assert again["action"] == "in_progress" and again["run"]["job_ids"] == first["run"]["job_ids"]
    demo.drain()
    done = orchestration.refresh(demo.tenant_id, first["run"]["id"])
    assert done["status"] == "succeeded" and done["finished_at"] and done["as_of_date"] == "2026-11-01"
    # retried after it finished: a no-op
    with read_session() as s:
        jobs_before = s.execute(select(Job.id).order_by(Job.id.desc()).limit(1)).scalar_one()
    replay = orchestration.run_step(demo.tenant_id, "data_quality", "scheduled__2026-11-01", wait=True)
    with read_session() as s:
        assert s.execute(select(Job.id).order_by(Job.id.desc()).limit(1)).scalar_one() == jobs_before, "no job was queued"
    assert replay["action"] == "already_done" and replay["run"]["attempts"] == 1
    # another run key is another run
    other = orchestration.run_step(demo.tenant_id, "data_quality", "scheduled__2026-11-02", wait=True, inline=True)
    assert other["action"] == "started" and other["run"]["status"] == "succeeded"
    assert [(r.step, r.run_key, r.status, r.attempts) for r in runs()] == [("data_quality", "scheduled__2026-11-01", "succeeded", 1), ("data_quality", "scheduled__2026-11-02", "succeeded", 1)]
    for bad_step, bad_key in (("training", "k"), ("scoring", ""), ("scoring", "x" * 300)):
        with pytest.raises(ValidationFailed):
            orchestration.claim(demo.tenant_id, bad_step, bad_key)


@pytest.mark.req("REQ-OPS-07")
def test_a_whole_night_driven_step_by_step_scores_once_and_a_second_pass_changes_nothing(demo):
    orchestrated(demo)
    with read_session() as s:
        batches_before = s.execute(select(PredictionBatch.id).order_by(PredictionBatch.id)).scalars().all()
    for step in pipeline.STEPS:
        result = orchestration.run_step(demo.tenant_id, step, "manual__night-1", wait=True, inline=True, dag_id="churn_nightly_pipeline")
        assert result["run"]["status"] in ("succeeded", "skipped"), (step, result["run"]["error"])
    states = {r.step: (r.status, r.attempts) for r in runs()}
    assert set(states) == set(pipeline.STEPS) and all(attempts == 1 for _status, attempts in states.values())
    assert states["scoring"][0] == "skipped", "this date was scored when the demo was seeded: there is nothing to score again"
    with read_session() as s:
        assert s.execute(select(PredictionBatch.id).order_by(PredictionBatch.id)).scalars().all() == batches_before
        jobs_after_first = s.execute(select(Job.id).order_by(Job.id.desc()).limit(1)).scalar_one()
    # Airflow re-runs the whole DAG run (cleared tasks): every step answers "already done"
    for step in pipeline.STEPS:
        assert orchestration.run_step(demo.tenant_id, step, "manual__night-1", wait=True, inline=True)["action"] == "already_done"
    with read_session() as s:
        assert s.execute(select(Job.id).order_by(Job.id.desc()).limit(1)).scalar_one() == jobs_after_first
        started = [e.detail["step"] for e in s.execute(select(AuditEvent).where(AuditEvent.action == "orchestrator.step_started").order_by(AuditEvent.id)).scalars()]
    assert started == list(pipeline.STEPS)


@pytest.mark.req("REQ-OPS-07")
def test_a_failed_step_is_started_again_by_the_retry_and_only_the_failed_one(demo):
    orchestrated(demo)
    activate(demo.db_path, demo.data_dir, CHURN_ORCHESTRATOR="airflow", CHURN_JOB_MAX_ATTEMPTS="1")
    first = orchestration.claim(demo.tenant_id, "monitoring", "night-7")
    with session_scope() as s:  # the job dies
        s.execute(update(Job).where(Job.id == first["run"]["job_ids"][0]).values(status="failed", error="Traceback ...\nRuntimeError: disk full"))
    failed = orchestration.refresh(demo.tenant_id, first["run"]["id"])
    assert failed["status"] == "failed" and "disk full" in failed["error"]
    retry = orchestration.run_step(demo.tenant_id, "monitoring", "night-7", wait=True, inline=True)
    assert retry["action"] == "retried" and retry["run"]["status"] == "succeeded" and retry["run"]["attempts"] == 2 and len(retry["run"]["job_ids"]) == 2
    assert retry["run"]["error"] is None


@pytest.mark.req("REQ-OPS-07")
def test_exactly_one_orchestrator_starts_the_nightly_work(demo):
    # the platform orchestrates (the default): Airflow's calls are refused, because every step would run twice
    with pytest.raises(Conflict) as refused:
        orchestration.claim(demo.tenant_id, "data_quality", "night-1")
    assert refused.value.code == "orchestrator_conflict" and "CHURN_ORCHESTRATOR=airflow" in refused.value.message
    assert orchestration.claim(demo.tenant_id, "data_quality", "operator-run", orchestrator="operator")["action"] == "started", "a one-off operator run is allowed"
    with session_scope() as s, pytest.raises(Conflict):
        pipeline.start(s, demo.principal("admin"))  # ... and the platform's own chain does not start beside it
    demo.drain()
    orchestration.refresh(demo.tenant_id, runs()[0].id)
    with session_scope() as s:
        job, started = pipeline.start(s, demo.principal("admin"))
        assert started and job.payload["manual"] is True
    with pytest.raises(Conflict):
        orchestration.claim(demo.tenant_id, "labels", "operator-run-2", orchestrator="operator")  # the platform's chain is running
    demo.drain()
    # Airflow orchestrates: the platform's schedule stands down, with the reason on the job
    orchestrated(demo)
    from churn_platform.services import jobs

    with session_scope() as s:
        scheduled = jobs.enqueue(s, tenant_id=demo.tenant_id, job_type="pipeline.nightly", payload={"step": 0, "log": []})
        scheduled_id = scheduled.id
    demo.drain()
    with read_session() as s:
        result = s.get(Job, scheduled_id).result
        assert result["state"] == "skipped" and "orchestrated by airflow" in result["reason"]
        assert orchestration.status(s, demo.tenant_id)["who_fires_the_nightly_run"].startswith("Apache Airflow")
    with demo.client() as c:
        page = c.get(f"{API}/pipeline/orchestration", headers=demo.login(c, "viewer")).json()
        assert page["orchestrator"] == "airflow" and page["steps"] == list(pipeline.STEPS) and len(page["runs"]) == 1


@pytest.mark.req("REQ-OPS-07")
def test_the_pipeline_step_command_reports_through_its_exit_code(demo, capsys):
    orchestrated(demo)
    assert cli.main(["pipeline-step", "--tenant", "demo", "--step", "data_quality", "--run-key", "cli-1"]) == 3, "queued, not waited for: still running"
    assert json.loads(capsys.readouterr().out)["status"] == "running"
    assert cli.main(["pipeline-step", "--tenant", "demo", "--step", "data_quality", "--run-key", "cli-1", "--wait", "--inline", "--dag-id", "d", "--task-id", "t"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert (out["action"], out["status"], out["attempts"]) == ("in_progress", "succeeded", 1)
    assert cli.main(["pipeline-step", "--tenant", "demo", "--step", "data_quality", "--run-key", "cli-1", "--wait"]) == 0
    assert json.loads(capsys.readouterr().out)["action"] == "already_done"
    with session_scope() as s:  # a step whose job failed
        entry = s.execute(select(OrchestratorRun)).scalar_one()
        entry.status = "running"
        s.execute(update(Job).where(Job.id == entry.job_ids[0]).values(status="failed", error="boom"))
        s.add(OrchestratorRun(tenant_id=demo.tenant_id, orchestrator="airflow", step="labels", run_key="cli-2", status="failed", attempts=5, job_ids=[], error="earlier"))
    assert cli.main(["pipeline-step", "--tenant", "demo", "--step", "data_quality", "--run-key", "cli-1"]) in (0, 3), "a failed step is started again"
    capsys.readouterr()
    with pytest.raises(SystemExit, match="does not exist"):
        cli.main(["pipeline-step", "--tenant", "nobody", "--step", "labels", "--run-key", "k"])
    activate(demo.db_path, demo.data_dir, CHURN_ORCHESTRATOR="platform")
    assert cli.main(["pipeline-step", "--tenant", "demo", "--step", "labels", "--run-key", "cli-3"]) == 2, "refused while the platform orchestrates"
    assert "CHURN_ORCHESTRATOR=airflow" in capsys.readouterr().err
    # the shipped DAG calls exactly this command, once per step, with the DAG run id as the run key
    from pathlib import Path

    dag = (Path(__file__).parents[1] / "deploy" / "airflow" / "churn_nightly_dag.py").read_text()
    assert f"STEPS = {pipeline.STEPS!r}".replace("'", '"') in dag and "--run-key '{{ dag_run.run_id }}'" in dag and "pipeline-step" in dag
