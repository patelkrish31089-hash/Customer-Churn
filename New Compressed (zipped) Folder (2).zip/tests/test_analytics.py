"""Descriptive analytics: churn overview, cohort retention, Kaplan-Meier survival, churn-rate profile."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import select

from churn_platform.db import read_session, session_scope
from churn_platform.errors import ValidationFailed
from churn_platform.models import AnalysisReport, Job
from churn_platform.services import analytics, policies
from churn_platform.worker.runner import Worker
from tests.builders import World

pytestmark = pytest.mark.req("REQ-AN-01")
CUTOFF = pd.Timestamp("2026-06-30 23:59:59")
DEFN = policies.ChurnDefinition()


def _book() -> World:
    """Four January starters (two leave), one March starter, one trial that never converts."""
    w = World()
    w.plan(1, "pro")
    w.plan(2, "basic")
    for cid in range(1, 7):
        w.customer(cid, region="EMEA" if cid % 2 else "AMER")
    for cid in (1, 2, 3, 4):
        w.subscription(cid, cid, "2026-01-01", plan_id=1 if cid <= 2 else 2, mrr=100.0 * cid)
    w.event(1, "ended", "2026-02-15", reason="cancellation")
    w.event(2, "ended", "2026-04-10", reason="payment_failure")
    w.subscription(5, 5, "2026-03-01", plan_id=2, mrr=50.0)
    w.subscription(6, 6, "2026-05-01", plan_id=2, mrr=70.0, trial_end_at="2026-05-15")
    w.event(6, "ended", "2026-05-15", reason="trial_expired")
    return w


# ----------------------------------------------------------------------------- overview
def test_overview_counts_monthly_churn_by_type_and_marks_the_partial_month():
    out = analytics.overview(_book().frames(), DEFN, pd.Timestamp("2026-06-20 12:00:00"))
    assert (out["customers"], out["ever_subscribed"], out["active_customers"], out["ended_periods"]) == (6, 5, 3, 2)
    assert out["active_mrr"] == 300.0 + 400.0 + 50.0
    assert out["ended_by_reason"] == {"cancellation": 1, "payment_failure": 1} and out["ended_by_kind"] == {"voluntary": 1, "involuntary": 1}
    monthly = {m["month"]: m for m in out["monthly"]}
    assert list(monthly) == ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06"]
    assert (monthly["2026-01"]["active_at_start"], monthly["2026-01"]["new"], monthly["2026-01"]["churned"]) == (4, 4, 0), "a start on the 1st counts as active at the start"
    assert (monthly["2026-02"]["active_at_start"], monthly["2026-02"]["churned"], monthly["2026-02"]["voluntary"], monthly["2026-02"]["churn_rate"]) == (4, 1, 1, 0.25)
    assert (monthly["2026-03"]["active_at_start"], monthly["2026-03"]["new"], monthly["2026-03"]["churned"]) == (4, 1, 0)
    assert (monthly["2026-04"]["active_at_start"], monthly["2026-04"]["involuntary"], monthly["2026-04"]["churn_rate"]) == (4, 1, 0.25)
    assert (monthly["2026-05"]["active_at_start"], monthly["2026-05"]["churned"], monthly["2026-05"]["new"]) == (3, 0, 0), "an unconverted trial is neither a customer nor churn"
    assert [m["complete"] for m in out["monthly"]] == [True] * 5 + [False], "the month containing the data cutoff is partial"
    assert out["note"] == analytics.DESCRIPTIVE and "not causal" in out["note"]


def test_overview_respects_the_churn_definition():
    frames = _book().frames()
    with_trials = analytics.overview(frames, policies.ChurnDefinition(include_trials=True), CUTOFF)
    assert with_trials["ever_subscribed"] == 6 and with_trials["ended_by_reason"]["trial_expired"] == 1
    assert with_trials["ended_by_kind"] == {"voluntary": 1, "involuntary": 1, "unknown": 1}
    may = next(m for m in with_trials["monthly"] if m["month"] == "2026-05")
    assert (may["churned"], may["excluded"], may["churn_rate"]) == (1, 0, round(1 / 4, 6)), "with trials counted, an expired trial is an ending like any other"
    excluded = analytics.overview(frames, policies.ChurnDefinition(include_trials=True, excluded_reasons=["trial_expired"]), CUTOFF)
    assert excluded["ended_by_kind"] == {"voluntary": 1, "involuntary": 1, "excluded": 1}
    assert (excluded["ended_periods"], excluded["churned_periods"], excluded["excluded_periods"]) == (3, 2, 1)
    may = next(m for m in excluded["monthly"] if m["month"] == "2026-05")
    assert (may["churned"], may["excluded"], may["churn_rate"]) == (0, 1, 0.0), "an excluded reason never enters the churn rate"
    assert sum(m["churned"] for m in excluded["monthly"]) == 2


# ----------------------------------------------------------------------------- cohorts
def test_cohort_retention_uses_only_observable_anniversaries():
    out = analytics.cohort_retention(_book().frames(), DEFN, CUTOFF)
    cohorts = {c["cohort"]: c for c in out["cohorts"]}
    assert list(cohorts) == ["2026-01", "2026-03"] and (cohorts["2026-01"]["size"], cohorts["2026-03"]["size"]) == (4, 1)
    assert out["periods"] == [0, 1, 2, 3, 4, 5, 6] and out["period_days"] == 30
    january = [(c["observable"], c["retained"], c["rate"]) for c in cohorts["2026-01"]["cells"]]
    # day 0, 30 (31 Jan), 60 (2 Mar), 90 (1 Apr), 120 (1 May), 150 (31 May), 180 (30 Jun)
    assert january == [(4, 4, 1.0), (4, 4, 1.0), (4, 3, 0.75), (4, 3, 0.75), (4, 2, 0.5), (4, 2, 0.5), (4, 2, 0.5)]
    march = [(c["observable"], c["retained"], c["rate"]) for c in cohorts["2026-03"]["cells"]]
    assert march == [(1, 1, 1.0)] * 5 + [(0, 0, None)] * 2, "day 150 of the March cohort lies after the data cutoff: no rate is invented"
    assert analytics.cohort_retention(World().frames(), DEFN, CUTOFF) == {"cohorts": [], "periods": [], "note": analytics.DESCRIPTIVE}


def test_customers_who_left_for_an_excluded_reason_leave_the_cohort_population():
    frames = _book().frames()
    counted = analytics.cohort_retention(frames, policies.ChurnDefinition(include_trials=True), CUTOFF)
    may = next(c for c in counted["cohorts"] if c["cohort"] == "2026-05")
    assert [(c["observable"], c["retained"]) for c in may["cells"]][:3] == [(1, 1), (1, 0), (1, 0)], "an ordinary ending counts as lost"
    excluded = analytics.cohort_retention(frames, policies.ChurnDefinition(include_trials=True, excluded_reasons=["trial_expired"]), CUTOFF)
    may = next(c for c in excluded["cohorts"] if c["cohort"] == "2026-05")
    assert [(c["observable"], c["retained"], c["rate"]) for c in may["cells"]][:3] == [(1, 1, 1.0), (0, 0, None), (0, 0, None)]


def test_a_reactivated_customer_counts_as_retained_again():
    w = World()
    w.plan(1)
    w.customer(1)
    w.subscription(1, 1, "2026-01-01", plan_id=1)
    w.event(1, "ended", "2026-02-10", reason="cancellation")
    w.event(1, "reactivated", "2026-04-20", mrr=100.0, plan_id=1)
    cells = analytics.cohort_retention(w.frames(), DEFN, CUTOFF)["cohorts"][0]["cells"]
    assert [c["retained"] for c in cells] == [1, 1, 0, 0, 1, 1, 1], "gone on day 60 and 90, back from day 120"


# ----------------------------------------------------------------------------- survival
def _kaplan_meier(durations: list[float], events: list[bool]) -> dict[float, float]:
    """Product-limit estimator written out longhand: S(t) = prod over event times <= t of (1 - d / n)."""
    survival, curve = 1.0, {}
    for t in sorted({d for d, e in zip(durations, events, strict=True) if e}):
        at_risk = sum(d >= t for d in durations)
        died = sum(d == t and e for d, e in zip(durations, events, strict=True))
        survival *= 1 - died / at_risk
        curve[t] = survival
    return curve


def _logrank(durations: np.ndarray, events: np.ndarray, in_group: np.ndarray) -> float:
    observed = expected = variance = 0.0
    for t in np.unique(durations[events]):
        at_risk, at_risk_group = (durations >= t).sum(), ((durations >= t) & in_group).sum()
        died = ((durations == t) & events).sum()
        observed += ((durations == t) & events & in_group).sum()
        expected += died * at_risk_group / at_risk
        if at_risk > 1:
            variance += died * (at_risk_group / at_risk) * (1 - at_risk_group / at_risk) * (at_risk - died) / (at_risk - 1)
    return float((observed - expected) ** 2 / variance)


def _survival_world() -> tuple[World, list[float], list[bool], list[str]]:
    w = World()
    w.plan(1)
    ends = {1: "2026-01-31", 2: "2026-03-02", 3: "2026-03-02", 4: None, 5: "2026-05-01", 6: None, 7: "2026-02-10", 8: None, 9: "2026-06-10", 10: None,
            11: "2026-04-01", 12: None}  # fmt: skip
    durations, events, regions = [], [], []
    for cid, end in ends.items():
        region = "EMEA" if cid <= 6 else "AMER"
        start = "2026-01-01" if cid % 2 else "2026-02-01"
        w.customer(cid, region=region)
        w.subscription(cid, cid, start, plan_id=1)
        if end:
            w.event(cid, "ended", end, reason="cancellation")
        stop = pd.Timestamp(end) if end else CUTOFF
        durations.append((stop - pd.Timestamp(start)).total_seconds() / 86400.0)
        events.append(end is not None)
        regions.append(region)
    return w, durations, events, regions


def test_survival_curve_is_the_kaplan_meier_estimate_with_right_censoring():
    w, durations, events, _ = _survival_world()
    out = analytics.survival(w.frames(), DEFN, CUTOFF)
    (group,) = out["groups"]
    assert (group["group"], group["n"], group["events"], group["censored"]) == ("all customers", 12, 7, 5) and (out["n"], out["events"]) == (12, 7)
    expected = _kaplan_meier(durations, events)
    curve = {p["day"]: p["survival"] for p in group["curve"]}
    assert curve[0.0] == 1.0
    for day, value in expected.items():
        assert curve[day] == pytest.approx(value, abs=1e-12), f"S({day})"
    assert set(curve) == {0.0, *durations}, "one point per distinct duration, censored ones included"
    values = [p["survival"] for p in group["curve"]]
    assert values == sorted(values, reverse=True) and all(p["lower"] <= p["survival"] <= p["upper"] for p in group["curve"])
    # still-subscribed customers are censored, not counted as survivors forever and not dropped:
    naive_share_ended = sum(events) / len(events)
    assert 1 - values[-1] > naive_share_ended, "ignoring censoring would understate churn"
    assert group["median_survival_days"] == min(day for day, value in expected.items() if value <= 0.5)
    assert group["survival_at"]["30"] == pytest.approx(expected[30.0]) == pytest.approx(10 / 12), "S(t) includes the event at t itself"
    assert group["survival_at"]["90"] == pytest.approx(expected[90.0]) == pytest.approx(7 / 12)
    assert "365" not in group["survival_at"], "no survival figure beyond the observed time"
    assert out["logrank"] is None and "right-censored" not in out["note"] and "censored" in out["definitions"]


def test_survival_by_segment_reports_the_log_rank_test():
    w, durations, events, regions = _survival_world()
    out = analytics.survival(w.frames(), DEFN, CUTOFF, segment="region")
    assert [(g["group"], g["n"], g["events"]) for g in out["groups"]] == [("AMER", 6, 3), ("EMEA", 6, 4)]
    d, e, emea = np.array(durations), np.array(events), np.array(regions) == "EMEA"
    assert out["logrank"]["statistic"] == pytest.approx(_logrank(d, e, emea), rel=1e-9) and out["logrank"]["degrees_of_freedom"] == 1
    from scipy.stats import chi2

    assert out["logrank"]["p_value"] == pytest.approx(float(chi2.sf(out["logrank"]["statistic"], 1)), rel=1e-9)
    for group in out["groups"]:
        mask = emea if group["group"] == "EMEA" else ~emea
        expected = _kaplan_meier(list(d[mask]), list(e[mask]))
        curve = {p["day"]: p["survival"] for p in group["curve"]}
        assert all(curve[day] == pytest.approx(value, abs=1e-12) for day, value in expected.items())
    with pytest.raises(ValidationFailed, match="segment must be one of"):
        analytics.survival(w.frames(), DEFN, CUTOFF, segment="favourite_colour")


def test_survival_handles_small_groups_excluded_reasons_and_no_median():
    w = World()
    w.plan(1)
    for cid in range(1, 9):
        w.customer(cid, region="EMEA" if cid <= 6 else "APAC")
        w.subscription(cid, cid, "2026-01-01", plan_id=1)
    w.event(1, "ended", "2026-03-01", reason="cancellation")
    w.event(2, "ended", "2026-03-15", reason="fraud")
    defn = policies.ChurnDefinition(excluded_reasons=["fraud"])
    out = analytics.survival(w.frames(), defn, CUTOFF, segment="region")
    emea, apac = out["groups"]
    assert (emea["n"], emea["events"], emea["median_survival_days"]) == (5, 1, None), "the excluded ending is removed; fewer than half churned: no median"
    assert apac == {"group": "APAC", "n": 2, "events": 0, "insufficient_data": True, "curve": []}
    assert out["logrank"] is None, "nothing to compare against one usable group"
    assert analytics.survival(World().frames(), DEFN, CUTOFF) == {"groups": [], "note": analytics.DESCRIPTIVE}


# ----------------------------------------------------------------------------- churn-rate profile
def test_churn_profile_reports_observed_rates_per_bin_and_sorts_by_spread():
    n = 200
    logins = np.arange(n, dtype="float64")
    label = (logins < 40).astype(int)  # everybody in the lowest fifth churns
    industry = np.where(np.arange(n) % 2 == 0, "software", "retail")
    data = pd.DataFrame({"label": label, "logins_30d": logins, "industry": industry, "seats": 5.0, "avg_csat_90d": np.where(np.arange(n) < 100, np.nan, logins)})
    out = analytics.churn_profile(data, ["logins_30d", "industry", "seats", "avg_csat_90d"])
    assert out["base_rate"] == 0.2 and out["rows"] == n
    by_name = {f["feature"]: f for f in out["features"]}
    assert list(by_name) == ["logins_30d", "avg_csat_90d", "industry"], "largest spread first"
    assert [(c["n"], c["churned"], c["churn_rate"]) for c in by_name["logins_30d"]["bins"]] == [(40, 40, 1.0)] + [(40, 0, 0.0)] * 4
    assert by_name["logins_30d"]["spread"] == 1.0 and by_name["industry"]["spread"] == 0.0
    assert {c["bin"]: c["n"] for c in by_name["industry"]["bins"]} == {"retail": 100, "software": 100}
    assert "seats" not in by_name, "a constant feature has no profile"
    csat = by_name["avg_csat_90d"]["bins"]
    assert [c["n"] for c in csat] == [20] * 5 + [100] and csat[-1] == {"bin": "(missing)", "n": 100, "churned": 40, "churn_rate": 0.4}
    assert by_name["avg_csat_90d"]["spread"] == 0.4, "missing values get their own bin: missingness can itself be the signal"
    assert sum(c["n"] for f in out["features"] for c in f["bins"] if f["feature"] == "logins_30d") == n


# ----------------------------------------------------------------------------- the seeded tenant
def test_seeded_overview_matches_the_generators_ground_truth(ro):
    with read_session() as s:
        overview = analytics.latest(s, ro.tenant_id, "overview")["result"]
        cohort = analytics.latest(s, ro.tenant_id, "cohort")["result"]
        survival = analytics.latest(s, ro.tenant_id, "survival")["result"]
        by_tier = analytics.latest(s, ro.tenant_id, "survival", segment="plan_tier")["result"]
        profile = analytics.latest(s, ro.tenant_id, "profile")["result"]
        headline = analytics.headline(s, ro.tenant_id)
    truth = ro.summary["expected"]
    kinds = overview["ended_by_kind"]
    assert kinds == {"voluntary": truth["voluntary_churn"], "involuntary": truth["involuntary_churn"], "excluded": truth["trial_expired"]}
    assert (kinds["voluntary"], kinds["involuntary"], kinds["excluded"]) == (59, 16, 14)
    assert overview["churn_definition"] == "default v1" and overview["customers"] == 300
    assert overview["ended_periods"] == sum(overview["ended_by_reason"].values()) == 89
    assert sum(m["churned"] for m in overview["monthly"]) == overview["churned_periods"] == 75, "expired trials are excluded by the approved definition"
    assert sum(m["excluded"] for m in overview["monthly"]) == overview["excluded_periods"] == 14
    assert sum(m["voluntary"] for m in overview["monthly"]) == 59 and sum(m["involuntary"] for m in overview["monthly"]) == 16
    assert sum(m["new"] for m in overview["monthly"]) == overview["active_customers"] + overview["ended_periods"], "every period that began is active or ended"
    assert all(m["voluntary"] + m["involuntary"] == m["churned"] for m in overview["monthly"])
    assert [m["complete"] for m in overview["monthly"]] == [True] * (len(overview["monthly"]) - 1) + [False], "the last event is not at midnight: October is partial"
    for row in cohort["cohorts"]:
        assert row["cells"][0]["rate"] == 1.0 and all(c["retained"] <= c["observable"] <= row["size"] for c in row["cells"])
        observable = [c["observable"] for c in row["cells"]]
        assert observable == sorted(observable, reverse=True), "older anniversaries are observable for at least as many customers"
    assert sum(row["size"] for row in cohort["cohorts"]) == overview["ever_subscribed"]
    (everyone,) = survival["groups"]
    assert everyone["n"] == overview["ever_subscribed"] - overview["excluded_periods"] == 285, "first periods that ended for an excluded reason are left out"
    assert everyone["events"] + everyone["censored"] == everyone["n"]
    assert survival["segment"] is None and by_tier["segment"] == "plan_tier" and by_tier["logrank"]["p_value"] <= 1
    assert sum(g["n"] for g in by_tier["groups"]) == everyone["n"]
    assert profile["rows"] == 1801 and profile["base_rate"] == pytest.approx(68 / 1801) and len(profile["features"]) > 40, "68 churned + 1,733 retained mature labels"
    spreads = [f["spread"] for f in profile["features"]]
    assert spreads == sorted(spreads, reverse=True)
    assert headline["customers"] == 300 and headline["data_cutoff"].startswith("2026-10-31") and headline["dq_score"] is not None


def test_reports_run_as_jobs_and_are_retrievable_by_kind_and_segment(demo):
    analyst = demo.principal("analyst")
    with session_scope() as s, pytest.raises(ValidationFailed, match="kind must be one of"):
        analytics.start(s, analyst, "forecast")
    with session_scope() as s, pytest.raises(ValidationFailed, match="segment must be one of"):
        analytics.start(s, analyst, "survival", {"segment": "favourite_colour"})
    with session_scope() as s:
        report, job = analytics.start(s, analyst, "survival", {"segment": "region"})
        report_id, job_id = report.id, job.id
        assert report.title == "Survival analysis by region" and report.result is None
        assert analytics.latest(s, demo.tenant_id, "survival", segment="region") is None, "not available until the job has run"
    Worker().drain()
    with read_session() as s:
        stored = analytics.latest(s, demo.tenant_id, "survival", segment="region")
        assert stored["id"] == report_id and stored["result"]["segment"] == "region" and s.get(Job, job_id).status == "succeeded"
        assert analytics.latest(s, demo.tenant_id, "survival")["id"] != report_id, "the unsegmented report is a different one"
        assert analytics.latest(s, demo.tenant_id + 1, "survival") is None
        assert s.execute(select(AnalysisReport).where(AnalysisReport.id == report_id)).scalar_one().created_by == analyst.user_id
