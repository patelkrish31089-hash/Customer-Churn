"""Monitoring: feature drift (PSI + two-sample tests), prediction drift, realised performance, alert rules,
and the automatic retraining that a breached performance rule starts."""

from __future__ import annotations

import math
from datetime import date

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import delete, func, select, update

from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, NotFound
from churn_platform.models import (
    Alert,
    AuditEvent,
    DriftReport,
    FeatureContract,
    FeatureVector,
    Job,
    MLDataset,
    ModelRun,
    ModelVersion,
    Prediction,
    PredictionBatch,
)
from churn_platform.services import features, mlprep, monitoring, policies, registry, retraining, training
from tests.conftest import require_or_skip

pytestmark = pytest.mark.req("REQ-OPS-03")


def _psi(reference_shares: list[float], current_shares: list[float]) -> float:
    """PSI written out: sum over bins of (current - reference) * ln(current / reference), empty bins floored at 0.0001."""
    ref = np.clip(np.array(reference_shares, dtype=float), 1e-4, None)
    cur = np.clip(np.array(current_shares, dtype=float), 1e-4, None)
    ref, cur = ref / ref.sum(), cur / cur.sum()
    return float(sum((c - r) * math.log(c / r) for r, c in zip(ref, cur, strict=True)))


# ----------------------------------------------------------------------------- PSI
def test_psi_by_hand():
    assert monitoring.psi_from_shares(np.array([0.5, 0.5]), np.array([0.8, 0.2])) == pytest.approx(0.3 * math.log(1.6) + (-0.3) * math.log(0.4))
    assert monitoring.psi_from_shares(np.array([0.5, 0.5]), np.array([0.8, 0.2])) == pytest.approx(0.415888, abs=1e-6)
    assert monitoring.psi_from_shares(np.array([0.2, 0.3, 0.5]), np.array([0.2, 0.3, 0.5])) == 0.0
    a, b = np.array([0.1, 0.9]), np.array([0.4, 0.6])
    assert monitoring.psi_from_shares(a, b) == pytest.approx(monitoring.psi_from_shares(b, a)), "PSI is symmetric"
    assert math.isfinite(monitoring.psi_from_shares(np.array([1.0, 0.0]), np.array([0.0, 1.0]))), "an empty bin does not divide by zero"
    assert [monitoring.status_for(v) for v in (0.0, 0.0999, 0.10, 0.2499, 0.25, 3.0)] == ["ok", "ok", "warning", "warning", "alert", "alert"]


def test_numeric_psi_bins_on_reference_deciles_and_counts_missing_values():
    reference = np.arange(100, dtype=float)
    assert monitoring.psi_numeric(reference, reference.copy()) == 0.0
    assert monitoring.psi_numeric(reference, np.tile(reference, 3)) == pytest.approx(0.0, abs=1e-12), "sample size alone is not drift"
    top = np.full(50, 95.0)  # everything lands in the top reference decile
    assert monitoring.psi_numeric(reference, top) == pytest.approx(_psi([0.1] * 10 + [0.0], [0.0] * 9 + [1.0] + [0.0]))
    half_low = np.concatenate([np.full(50, 5.0), reference[:50] * 2])  # 50% in the bottom decile, the rest spread evenly
    assert monitoring.psi_numeric(reference, half_low) == pytest.approx(_psi([0.1] * 10 + [0.0], [0.55] + [0.05] * 9 + [0.0]))
    beyond = np.array([-50.0] * 10 + [500.0] * 10)  # outside the reference range: still counted, in the outer bins
    assert monitoring.psi_numeric(reference, beyond) == pytest.approx(_psi([0.1] * 10 + [0.0], [0.5] + [0.0] * 8 + [0.5] + [0.0]))
    with_gaps = np.concatenate([reference[::2], np.full(50, np.nan)])  # half of the values went missing
    assert monitoring.psi_numeric(reference, with_gaps) == pytest.approx(_psi([0.1] * 10 + [0.0], [0.05] * 10 + [0.5]))
    assert monitoring.psi_numeric(reference, with_gaps) > monitoring.PSI_ALERT, "a feature that stops arriving is drift"
    all_missing = np.full(40, np.nan)
    assert monitoring.psi_numeric(reference, all_missing) == pytest.approx(_psi([0.0, 1.0], [1.0, 0.0]))


def test_numeric_psi_sees_change_in_a_feature_that_was_constant_in_the_reference():
    """DEF-017: with a constant reference every current value used to fall into one catch-all bin (PSI 0)."""
    constant = np.full(60, 7.0)  # bins: below 7 | exactly 7 | above 7 | missing
    assert monitoring.psi_numeric(constant, constant) == 0.0
    assert monitoring.psi_numeric(constant, np.full(60, 9.0)) == pytest.approx(_psi([0, 1, 0, 0], [0, 0, 1, 0]))
    assert monitoring.psi_numeric(constant, np.full(60, 5.0)) == pytest.approx(_psi([0, 1, 0, 0], [1, 0, 0, 0]))
    # "nobody had an overdue invoice in training, now 40% have one"
    overdue = np.concatenate([np.zeros(60), np.ones(40)])
    assert monitoring.psi_numeric(np.zeros(100), overdue) == pytest.approx(_psi([0, 1, 0, 0], [0, 0.6, 0.4, 0]))
    assert monitoring.status_for(monitoring.psi_numeric(np.zeros(100), overdue)) == "alert"
    assert monitoring.psi_numeric(np.zeros(100), np.concatenate([np.zeros(99), [1.0]])) < monitoring.PSI_WARNING, "one customer in a hundred is not drift"
    binary = np.concatenate([np.zeros(80), np.ones(20)])  # two distinct values: split half-way between them
    assert monitoring.psi_numeric(binary, np.concatenate([np.zeros(50), np.ones(50)])) == pytest.approx(_psi([0.8, 0.2, 0], [0.5, 0.5, 0]))
    report = monitoring.feature_drift(pd.DataFrame({"overdue_invoices": np.zeros(100)}), pd.DataFrame({"overdue_invoices": overdue}), ["overdue_invoices"])
    assert report["features"][0]["status"] == "alert" and report["status"] == "alert"


def test_categorical_psi_handles_new_vanished_and_missing_categories():
    reference = pd.Series(["a"] * 50 + ["b"] * 30 + ["c"] * 20)
    assert monitoring.psi_categorical(reference, reference.sample(frac=1.0, random_state=1)) == pytest.approx(0.0, abs=1e-12)
    current = pd.Series(["a"] * 20 + ["b"] * 30 + ["d"] * 40 + [None] * 10)  # c vanished, d is new, some values are missing
    # categories in sorted order: (missing), a, b, c, d
    assert monitoring.psi_categorical(reference, current) == pytest.approx(_psi([0.0, 0.5, 0.3, 0.2, 0.0], [0.1, 0.2, 0.3, 0.0, 0.4]))


# ----------------------------------------------------------------------------- feature drift report
def _frame(n: int, seed: int, *, login_shift: float = 0.0, missing_csat: float = 0.0, industries: tuple = ("software", "retail")) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    csat = rng.normal(4.0, 0.5, n)
    csat[: int(n * missing_csat)] = np.nan
    return pd.DataFrame({"logins_30d": rng.normal(20 + login_shift, 5, n), "seats": rng.integers(1, 50, n).astype(float), "avg_csat_90d": csat,
                         "industry": rng.choice(list(industries), n)})  # fmt: skip


NAMES = ["logins_30d", "seats", "avg_csat_90d", "industry"]


def test_feature_drift_finds_a_planted_shift_and_leaves_stable_features_alone():
    reference = _frame(2000, 1)
    same = monitoring.feature_drift(reference, _frame(2000, 2), NAMES)
    assert same["status"] == "ok" and same["drifted_features"] == 0 and all(f["status"] == "ok" and f["psi"] < 0.05 for f in same["features"])
    assert all(f["p_value"] > 0.001 for f in same["features"]), "the two-sample tests agree: same distribution"
    shifted = monitoring.feature_drift(reference, _frame(2000, 3, login_shift=-12.0), NAMES)  # e.g. a tracking bug loses most logins
    by_name = {f["feature"]: f for f in shifted["features"]}
    assert shifted["features"][0]["feature"] == "logins_30d", "sorted by PSI: the drifted feature comes first"
    logins = by_name["logins_30d"]
    assert logins["status"] == "alert" and logins["psi"] > 1 and logins["test"] == "Kolmogorov-Smirnov" and logins["p_value"] < 1e-50
    assert logins["mean_current"] == pytest.approx(8, abs=0.5) and logins["mean_reference"] == pytest.approx(20, abs=0.5)
    assert logins["label"] and logins["group"], "reports carry the business label of the feature"
    assert [by_name[n]["status"] for n in ("seats", "avg_csat_90d", "industry")] == ["ok", "ok", "ok"]
    assert by_name["industry"]["test"] == "chi-square"
    assert (shifted["status"], shifted["drifted_features"], shifted["drifted_share"]) == ("warning", 1, 0.25), "one of four features: below the 30% share for an alert"
    assert shifted["thresholds"] == {"psi_warning": 0.10, "psi_alert": 0.25, "basis": "customary rule of thumb"}
    assert shifted["rows"] == {"reference": 2000, "current": 2000}


def test_feature_drift_covers_categories_missing_rates_and_small_samples():
    reference = _frame(2000, 1)
    changed = monitoring.feature_drift(reference, _frame(2000, 4, login_shift=-12.0, missing_csat=0.4, industries=("software", "health")), NAMES)
    by_name = {f["feature"]: f for f in changed["features"]}
    assert by_name["industry"]["status"] == "alert" and by_name["industry"]["p_value"] < 1e-50, "a new category replaced an old one"
    csat = by_name["avg_csat_90d"]
    assert csat["status"] == "alert" and csat["missing_reference"] == 0.0 and csat["missing_current"] == 0.4 and csat["missing_rate_increase"] == 0.4
    assert changed["max_missing_rate_increase"] == 0.4
    assert (changed["status"], changed["drifted_features"], changed["drifted_share"]) == ("alert", 3, 0.75)
    small = monitoring.feature_drift(reference, _frame(29, 5), NAMES)
    assert small["status"] == "insufficient_data" and small["features"] == [] and small["rows"] == {"reference": 2000, "current": 29}
    assert "at least 30 rows" in small["reason"]


def test_realised_performance_needs_both_classes_and_reports_the_drop():
    rng = np.random.default_rng(0)
    y = (rng.random(400) < 0.1).astype(int)
    good = np.clip(np.where(y == 1, 0.8, 0.1) + rng.normal(0, 0.05, 400), 0.0, 1.0)
    out = monitoring.realised_performance(y, good, reference_pr_auc=0.60)
    assert out["status"] == "ok" and out["pr_auc"] > 0.95 and out["pr_auc_drop"] == pytest.approx(0.60 - out["pr_auc"]) and out["pr_auc_drop"] < 0
    noise = monitoring.realised_performance(y, rng.random(400), reference_pr_auc=0.60)
    assert noise["pr_auc_drop"] > 0.4 and noise["pr_auc"] < 0.2 and "accuracy" not in noise
    assert monitoring.realised_performance(y, good, None)["pr_auc_drop"] is None
    nobody_left = monitoring.realised_performance(np.zeros(50, dtype=int), rng.random(50), 0.6)
    assert nobody_left["status"] == "insufficient_data" and nobody_left["pr_auc"] is None and "single class" in nobody_left["reason"]


# ----------------------------------------------------------------------------- the seeded tenant
def test_seeded_reports_equal_a_recomputation_from_the_training_split_and_the_latest_batch(ro):
    with read_session() as s:
        reports = monitoring.latest_reports(s, ro.tenant_id)
        version = registry.production_version(s, ro.tenant_id)
        run = s.get(ModelRun, version.model_run_id)
        dataset = s.get(MLDataset, run.dataset_id)
        contract = s.get(FeatureContract, version.contract_id)
        current = features.offline_frame(s, ro.tenant_id, contract, dates=[pd.Timestamp("2026-11-01").date()])
        scores = np.array(s.execute(select(Prediction.probability).where(Prediction.batch_id == ro.summary["batch_id"])).scalars().all())
        alerts = s.execute(select(func.count()).select_from(Alert)).scalar_one()
    names = list(contract.features)
    train, valid = mlprep.load_split(dataset, "train"), mlprep.load_split(dataset, "valid")
    feature, prediction, concept = reports["feature"], reports["prediction"], reports["concept"]
    assert feature["current"] == {"batch_id": ro.summary["batch_id"], "as_of_date": "2026-11-01", "feature_source": "offline feature store"}
    assert prediction["current"] == concept["current"] == {"batch_id": ro.summary["batch_id"], "as_of_date": "2026-11-01"}
    assert feature["reference"]["rows"] == len(train) == 982
    expected = monitoring.feature_drift(train[names], current[names], names)
    stored = feature["result"]["features"]
    assert [f["feature"] for f in stored] == [f["feature"] for f in expected["features"]] and len(stored) == 84
    for got, want in zip(stored, expected["features"], strict=True):
        assert got["status"] == want["status"] and got.get("test") == want.get("test")
        for key in ("psi", "missing_reference", "missing_current", "missing_rate_increase", "statistic", "p_value", "mean_reference", "mean_current"):
            if want.get(key) is None:  # e.g. no two-sample test for a feature that is empty on one side
                assert got.get(key) is None, (got["feature"], key)
            else:
                assert got[key] == pytest.approx(want[key], rel=1e-9, abs=1e-12), (got["feature"], key)
    assert feature["status"] == expected["status"] == "warning" and feature["result"]["drifted_features"] == expected["drifted_features"]
    assert 0 < feature["result"]["drifted_share"] < 0.3
    # the customer base is still growing, so tenure drifts against the whole training period (documented limitation)
    assert feature["result"]["features"][0]["feature"] == "tenure_days" and feature["result"]["features"][0]["psi"] > 1
    reference_scores = training.predict_proba(training.load_bundle(run), valid)
    assert prediction["result"]["psi"] == pytest.approx(monitoring.psi_numeric(reference_scores, scores)) and prediction["result"]["rows"] == {"reference": 395, "current": 212}
    assert prediction["status"] == monitoring.status_for(prediction["result"]["psi"])
    result = concept["result"]
    assert result["reference_pr_auc"] == pytest.approx(run.test_metrics["pr_auc"]) and concept["status"] == "ok"
    by_batch = {b["batch_id"]: b for b in result["batches"]}
    live, backtest = by_batch[ro.summary["batch_id"]], by_batch[2]
    assert live["status"] == "insufficient_data" and live["labelled"] == 0, "outcomes for 1 November are not mature: no performance figure is made up"
    assert (backtest["sample"], backtest["labelled"], backtest["as_of_date"]) == ("test_period", 217, "2026-10-01")
    assert result["latest"] == backtest and backtest["pr_auc_drop"] == pytest.approx(result["reference_pr_auc"] - backtest["pr_auc"])
    assert set(result["sample_legend"]) == {"test_period", "after_model_data", "in_sample_training", "validation_period"}
    assert alerts == 0, "none of the approved default rules is breached on the seeded tenant"


def test_a_batch_scored_for_a_date_the_feature_store_does_not_hold_is_monitored_all_the_same(demo):
    """A batch started between two pipeline runs computes its vectors and does not keep them.  The default demo scores for
    "today", which is such a date: its input drift used to read "insufficient data" with 0 current rows."""
    with read_session() as s:
        seeded = monitoring.latest_reports(s, demo.tenant_id)["feature"]
    assert seeded["current"]["feature_source"] == "offline feature store" and seeded["status"] == "warning"
    with session_scope() as s:  # as if 1 November had never been materialised
        removed = s.execute(delete(FeatureVector).where(FeatureVector.tenant_id == demo.tenant_id, FeatureVector.as_of_date == date(2026, 11, 1))).rowcount
    assert removed >= 212, "the store held the scoring date"
    result = _monitor(demo)
    with read_session() as s:
        computed = monitoring.latest_reports(s, demo.tenant_id)["feature"]
        kept = s.execute(select(func.count()).select_from(FeatureVector).where(FeatureVector.as_of_date == date(2026, 11, 1))).scalar_one()
    assert kept == 0, "a report never writes to the feature store"
    assert computed["id"] > seeded["id"] and result["statuses"]["feature"] == "warning"
    assert computed["current"] == {**seeded["current"], "feature_source": "computed for this report"}
    assert computed["result"]["rows"] == {"reference": 982, "current": 212}
    assert computed["result"] == seeded["result"], "the same vectors, so the same report to the last digit"


def test_a_report_that_cannot_be_computed_says_why_and_carries_the_row_counts(demo, monkeypatch):
    """The screen shows these reports too: every one of them needs a reason and the two row counts."""
    monkeypatch.setattr(monitoring, "MIN_ROWS", 215)  # the latest batch (212 customers) is too small, the back-test (217 outcomes) is not
    assert _monitor(demo)["statuses"] == {"feature": "insufficient_data", "prediction": "insufficient_data", "concept": "ok"}
    with read_session() as s:
        reports = monitoring.latest_reports(s, demo.tenant_id)
    batch = {"batch_id": demo.summary["batch_id"], "as_of_date": "2026-11-01"}
    assert reports["feature"]["current"] == {**batch, "feature_source": "offline feature store"} and reports["prediction"]["current"] == batch
    assert reports["feature"]["result"] == {"status": "insufficient_data", "rows": {"reference": 982, "current": 212}, "features": [],
                                            "reason": "at least 215 rows are needed on each side"}  # fmt: skip
    assert reports["prediction"]["result"] == {"status": "insufficient_data", "rows": {"reference": 395, "current": 212}, "psi": None,
                                               "reason": "a completed batch with at least 215 scored customers is needed"}  # fmt: skip
    monkeypatch.undo()
    with session_scope() as s:  # a model that has not scored a batch yet
        s.execute(update(PredictionBatch).where(PredictionBatch.tenant_id == demo.tenant_id).values(status="failed"))
    result = _monitor(demo)
    assert result["statuses"] == {"feature": "insufficient_data", "prediction": "insufficient_data", "concept": "insufficient_data"}
    assert result["rules_fired"] == [] and result["alerts_created"] == 0, "nothing measured, nothing to alert on"
    with read_session() as s:
        reports = monitoring.latest_reports(s, demo.tenant_id)
    assert reports["feature"]["current"] is None and reports["prediction"]["current"] is None and reports["concept"]["current"] is None
    assert reports["feature"]["result"]["rows"] == {"reference": 982, "current": 0} and "at least 30 rows" in reports["feature"]["result"]["reason"]
    assert reports["prediction"]["result"]["rows"] == {"reference": 395, "current": 0} and "at least 30 scored customers" in reports["prediction"]["result"]["reason"]
    assert reports["concept"]["result"]["batches"] == [] and reports["concept"]["result"]["reason"] == "no scored batch has mature outcomes yet"


def _approve_rules(demo, rules: list[dict], **extra) -> None:
    admin, approver = demo.principal("admin"), demo.principal("approver")
    with session_scope() as s:
        policy = policies.create(s, admin, kind="alert_rules", name="default", payload={"rules": rules, **extra}, note="tighter thresholds")
        policies.submit(s, admin, policy.id)
        policy_id = policy.id
    with session_scope() as s:
        policies.review(s, approver, policy_id, approve=True)


def _monitor(demo) -> dict:
    with session_scope() as s:
        job_id = monitoring.start(s, demo.principal("admin"), tenant_id=demo.tenant_id).id
    demo.drain()
    with read_session() as s:
        return s.get(Job, job_id).result


TIGHT = [{"metric": "feature_drift_share", "operator": ">=", "threshold": 0.2, "severity": "warning"},
         {"metric": "prediction_psi", "operator": ">=", "threshold": 0.01, "severity": "info"},
         {"metric": "missing_rate_increase", "operator": ">", "threshold": 0.05, "severity": "warning"},
         {"metric": "dq_score_min", "operator": "<", "threshold": 1.0, "severity": "warning"},
         {"metric": "pr_auc_drop", "operator": ">=", "threshold": 0.1, "severity": "critical"},
         {"metric": "pr_auc_min", "operator": "<", "threshold": 0.9, "severity": "critical"}]  # fmt: skip


def test_alert_rules_fire_once_per_condition_and_alerts_follow_acknowledge_and_resolve(demo):
    _approve_rules(demo, TIGHT, retrain_on=["pr_auc_min"], auto_retrain=False)
    result = _monitor(demo)
    fired = {f["metric"]: f for f in result["rules_fired"]}
    assert set(fired) == {"feature_drift_share", "prediction_psi", "missing_rate_increase", "dq_score_min", "pr_auc_min"}
    assert "pr_auc_drop" not in fired, "performance did not drop against the approval figure, so that rule stays quiet"
    assert result["rules"] == "approved policy v2" and result["statuses"]["concept"] == "alert" and result["alerts_created"] == 6
    assert result["retraining_recommended"] is True and result["retraining"] == {
        "triggered": False, "job_id": None, "reason": "automatic retraining is switched off in the alert rules policy"}  # fmt: skip
    with read_session() as s:
        alerts = {a.kind: a for a in s.execute(select(Alert)).scalars()}
        reports = monitoring.latest_reports(s, demo.tenant_id)
    assert set(alerts) == {f"rule:{metric}" for metric in fired} | {"retraining_recommended"}
    assert {a.status for a in alerts.values()} == {"open"}
    drift = alerts["rule:feature_drift_share"]
    assert drift.title.startswith("feature drift share >= 0.2 (observed 0.2") and drift.severity == "warning"
    assert (drift.source_type, drift.source_id) == ("drift_report", reports["feature"]["id"])
    assert drift.detail["value"] == pytest.approx(reports["feature"]["result"]["drifted_share"]) and 0.2 <= drift.detail["value"] < 0.3
    assert (alerts["rule:pr_auc_min"].severity, alerts["rule:pr_auc_min"].source_id) == ("critical", reports["concept"]["id"])
    assert alerts["rule:dq_score_min"].source_type == "dq_run" and alerts["rule:prediction_psi"].severity == "info"
    recommended = alerts["retraining_recommended"]
    assert recommended.severity == "critical" and recommended.detail["triggered_by"] == ["pr_auc_min"] and "nothing is promoted automatically" in recommended.message
    # the same breach on the next run refreshes the alerts instead of duplicating them
    assert _monitor(demo)["alerts_created"] == 0
    viewer, analyst = demo.principal("viewer"), demo.principal("analyst")
    with session_scope() as s:
        acknowledged = monitoring.acknowledge(s, analyst, drift.id)
        assert (acknowledged.status, acknowledged.acknowledged_by) == ("acknowledged", analyst.user_id) and acknowledged.acknowledged_at is not None
    assert _monitor(demo)["alerts_created"] == 0, "an acknowledged alert is not raised again while the condition lasts"
    with session_scope() as s:
        assert monitoring.acknowledge(s, analyst, drift.id, resolve=True).status == "resolved"
    with session_scope() as s, pytest.raises(Conflict, match="already resolved"):
        monitoring.acknowledge(s, viewer, drift.id)
    with session_scope() as s, pytest.raises(NotFound):
        monitoring.acknowledge(s, analyst, 999_999)
    assert _monitor(demo)["alerts_created"] == 1, "once resolved, a breach that is still there raises a fresh alert"
    with read_session() as s:
        states = s.execute(select(Alert.status).where(Alert.kind == "rule:feature_drift_share").order_by(Alert.id)).scalars().all()
        actions = s.execute(select(AuditEvent.action).where(AuditEvent.entity_type == "alert").order_by(AuditEvent.id)).scalars().all()
        assert s.execute(select(func.count()).select_from(Job).where(Job.job_type == "ml.retrain")).scalar_one() == 0
    assert states == ["resolved", "open"] and actions == ["alert.acknowledged", "alert.resolved"]


def test_monitoring_needs_a_servable_model_and_uses_structural_defaults_without_a_policy(demo):
    admin = demo.principal("admin")
    with session_scope() as s:
        s.execute(policies.Policy.__table__.update().where(policies.Policy.kind == "alert_rules").values(status="retired"))
    assert _monitor(demo)["rules"] == "structural default (not an approved policy)"
    with session_scope() as s:
        s.execute(ModelVersion.__table__.update().values(stage="archived"))
    with session_scope() as s, pytest.raises(NotFound) as nothing:
        monitoring.start(s, admin, tenant_id=demo.tenant_id)
    assert nothing.value.code == "no_production_model"
    with read_session() as s:
        assert monitoring.model_version_or_none(s, demo.tenant_id) is None


# ----------------------------------------------------------------------------- automatic retraining
@pytest.mark.slow
def test_a_breached_performance_rule_starts_retraining_and_never_promotes_by_itself(demo):
    _approve_rules(demo, TIGHT[-1:], retrain_on=["pr_auc_min"])  # auto_retrain defaults to true
    with read_session() as s:
        before = {"versions": s.execute(select(func.count()).select_from(ModelVersion)).scalar_one(),
                  "production": registry.production_version(s, demo.tenant_id).id,
                  "vectors": s.execute(select(func.count()).select_from(FeatureVector)).scalar_one()}  # fmt: skip
        # one labelled month lost its feature vectors (for example a purge): retraining has to notice and refill it
        lost = s.execute(select(func.count()).select_from(FeatureVector).where(FeatureVector.as_of_date == pd.Timestamp("2026-06-01").date())).scalar_one()
    with session_scope() as s:
        s.execute(FeatureVector.__table__.delete().where(FeatureVector.as_of_date == pd.Timestamp("2026-06-01").date()))
    result = _monitor(demo)  # drains the queue: monitoring, then the whole retraining chain
    retrain = result["retraining"]
    assert result["retraining_recommended"] is True and retrain["triggered"] is True and retrain["reason"] == "realised performance breached: pr_auc_min"
    with read_session() as s:
        chain = s.execute(select(Job).where(Job.job_type == "ml.retrain").order_by(Job.id)).scalars().all()
        final = chain[-1].result
        steps = {entry["step"]: entry for entry in final["steps"]}
        datasets = s.execute(select(MLDataset).order_by(MLDataset.id)).scalars().all()
        runs = s.execute(select(ModelRun).where(ModelRun.dataset_id == datasets[-1].id)).scalars().all()
        alerts = {a.kind: a for a in s.execute(select(Alert)).scalars()}
        after = {"versions": s.execute(select(func.count()).select_from(ModelVersion)).scalar_one(),
                 "production": registry.production_version(s, demo.tenant_id).id,
                 "vectors": s.execute(select(func.count()).select_from(FeatureVector)).scalar_one()}  # fmt: skip
        audit_actions = s.execute(select(AuditEvent.action).where(AuditEvent.action.like("retraining.%")).order_by(AuditEvent.id)).scalars().all()
    assert chain[0].id == retrain["job_id"] and chain[0].idempotency_key == f"ml.retrain:auto:v{before['production']}:2026-10-01"
    assert final["state"] == "completed" and list(steps) == ["labels", "features", "dataset", "training"] == list(retraining.STEPS)
    assert all(entry["status"] == "succeeded" for entry in steps.values())
    assert (steps["labels"]["from"], steps["labels"]["to"]) == ("2025-08-01", "2026-11-01"), "labels are refreshed over the whole history"
    assert steps["features"]["dates"] == ["2026-06-01"] and after["vectors"] == before["vectors"] and lost > 0, "only the missing month is recomputed"
    old, new = datasets
    assert (new.name, new.version, new.status) == (old.name, old.version + 1, "ready") and steps["dataset"]["dataset_id"] == new.id
    assert {k: new.config[k] for k in ("valid_dates", "test_dates", "embargo_days", "target")} == {k: old.config[k] for k in ("valid_dates", "test_dates", "embargo_days", "target")}
    assert new.leakage_report["passed"] is True, "the retrained dataset went through the same leakage checks"
    assert sorted(r.algorithm for r in runs) == sorted(training.ALGORITHMS) and {r.status for r in runs} == {"completed"}
    assert all(r.seed == 7 and (r.search["n_iter"], r.search["cv_folds"]) == (3, 3) for r in runs), "same seed and search budget as the production run"
    assert all(not r.test_metrics for r in runs), "the sealed TEST split was not touched"
    best = max(runs, key=lambda r: r.valid_metrics["pr_auc"])
    assert final["candidates"][0] == {"run_id": best.id, "algorithm": best.algorithm, "valid_pr_auc": best.valid_metrics["pr_auc"]}
    assert len(final["candidates"]) == 4 and final["production_model_version_id"] == before["production"]
    # governance: nothing was registered, approved or promoted by the machine
    assert after["versions"] == before["versions"] and after["production"] == before["production"]
    started, completed = alerts["retraining_started"], alerts["retraining_completed"]
    assert (started.severity, started.source_type, started.source_id) == ("critical", "job", retrain["job_id"])
    assert "approved by a second person" in started.message and "retraining_recommended" not in alerts
    assert completed.title == "Retrained candidates await review" and f"run {best.id}" in completed.message
    assert "stays in place until a second person approves a replacement" in completed.message and completed.detail["dataset_id"] == new.id
    assert audit_actions == ["retraining.triggered", "retraining.completed"]
    # the breach persists on the next night, but no new outcomes have matured: no second retraining
    again = _monitor(demo)["retraining"]
    assert again["triggered"] is False and again["job_id"] == retrain["job_id"] and "already retrained for this model version" in again["reason"]
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(MLDataset)).scalar_one() == 2
        waiting = s.execute(select(Alert).where(Alert.kind == "retraining_recommended")).scalar_one()
    assert "No automatic retraining was started: already retrained" in waiting.message


def test_retraining_stops_with_a_clear_reason_when_a_step_cannot_run(demo):
    admin = demo.principal("admin")
    with session_scope() as s:
        version_id = registry.production_version(s, demo.tenant_id).id
        outcome = retraining.trigger(s, tenant_id=demo.tenant_id, model_version_id=version_id, triggered_by=["pr_auc_min"], created_by=admin.user_id, enabled=True)
        assert outcome["triggered"] is True
        s.execute(policies.Policy.__table__.update().where(policies.Policy.kind == "churn_definition").values(status="retired"))
    from churn_platform.worker.runner import Worker

    Worker().drain()
    with read_session() as s:
        job = s.get(Job, outcome["job_id"])
        assert job.status == "failed" and job.attempts == 1, "a missing prerequisite is not retried"
        assert "PermanentJobError: automatic retraining stopped at 'labels': No approved churn definition policy exists yet" in job.error
        assert s.execute(select(func.count()).select_from(MLDataset)).scalar_one() == 1 and s.execute(select(func.count()).select_from(DriftReport)).scalar_one() == 6


# ----------------------------------------------------------------------------- optional second opinion
@pytest.mark.evidently_live
def test_evidently_gives_a_second_opinion_and_its_absence_never_breaks_monitoring(demo, monkeypatch):
    import importlib.util

    require_or_skip(importlib.util.find_spec("evidently") is not None, "the optional 'evidently' package is not installed")
    reference = _frame(400, 1)[NAMES[:3]]
    summary = monitoring.evidently_summary(reference, _frame(400, 3, login_shift=-12.0)[NAMES[:3]])
    assert summary["status"] == "available" and summary["engine"] == "evidently" and summary["metrics"] > 0, summary
    assert summary["drifted_columns"]["count"] >= 1, "Evidently sees the planted shift as well"
    with session_scope() as s:
        job_id = monitoring.start(s, demo.principal("admin"), tenant_id=demo.tenant_id, with_evidently=True).id
    demo.drain()
    with read_session() as s:
        assert s.get(Job, job_id).status == "succeeded"
        stored = monitoring.latest_reports(s, demo.tenant_id)["feature"]["result"]["evidently"]
    # DEF-018: a column that is empty in the training period used to make the whole second opinion "unavailable"
    assert stored["status"] == "available" and stored["excluded_columns"] == ["days_since_reactivation"] and stored["columns"] == 83
    assert stored["drifted_columns"]["count"] >= 1
    nothing = monitoring.evidently_summary(pd.DataFrame({"a": [np.nan] * 40}), pd.DataFrame({"a": [1.0] * 40}))
    assert nothing == {"status": "unavailable", "engine": "evidently", "reason": "every column is empty on at least one side", "excluded_columns": ["a"]}
    monkeypatch.setitem(__import__("sys").modules, "evidently", None)  # as if the optional package were missing
    missing = monitoring.evidently_summary(reference, reference)
    assert missing["status"] == "unavailable" and missing["reason"].startswith("ModuleNotFoundError"), "reported, never raised"
