"""Durable job queue and worker: idempotency, retries, cancellation, leases, schedules."""

from __future__ import annotations

import threading
import time
from datetime import timedelta

import pytest
from sqlalchemy import select, update

from churn_platform.db import get_engine, read_session, session_scope, utcnow
from churn_platform.errors import Conflict, NotFound, ValidationFailed
from churn_platform.models import Job, Schedule
from churn_platform.services import jobs
from churn_platform.worker.runner import Worker
from tests.conftest import activate, require_or_skip

pytestmark = pytest.mark.req("REQ-OPS-02")
CALLS: list = []
LOCK = threading.Lock()


@pytest.fixture(autouse=True)
def _handlers():
    jobs.load_handlers()
    CALLS.clear()

    @jobs.job_handler("test.ok")
    def ok(ctx):
        with LOCK:
            CALLS.append(ctx.job_id)
        ctx.progress(0.5, "half way", force=True)
        return {"echo": ctx.payload.get("value"), "attempt": ctx.attempt}

    @jobs.job_handler("test.flaky")
    def flaky(ctx):
        CALLS.append(ctx.attempt)
        if ctx.attempt < ctx.payload.get("succeed_on", 99):
            raise RuntimeError(f"boom on attempt {ctx.attempt}")
        return {"attempt": ctx.attempt}

    @jobs.job_handler("test.permanent")
    def permanent(ctx):
        raise jobs.PermanentJobError("input can never work")

    @jobs.job_handler("test.loop")
    def loop(ctx):
        CALLS.append("started")
        action = ctx.payload.get("action")
        if action == "cancel":
            with session_scope() as s:
                job = s.get(Job, ctx.job_id)
                job.cancel_requested = True
        elif action == "steal":
            with session_scope() as s:
                s.execute(update(Job).where(Job.id == ctx.job_id).values(lease_owner="another-worker"))
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            ctx.check()
            time.sleep(0.02)
        raise AssertionError("the job was never interrupted")

    @jobs.job_handler("test.finish_after_steal")
    def finish_after_steal(ctx):
        with session_scope() as s:
            s.execute(update(Job).where(Job.id == ctx.job_id).values(lease_owner="another-worker"))
        return {"done": True}

    @jobs.job_handler("test.progress_in_tx")
    def progress_in_tx(ctx):
        with session_scope() as s:
            s.execute(update(Job).where(Job.id == ctx.job_id).values(priority=1))  # holds the write lock
            ctx.progress(0.3, "inside a write transaction", force=True)
        return {}

    yield
    for name in [n for n in jobs.HANDLERS if n.startswith("test.")]:
        del jobs.HANDLERS[name]


def _enqueue(tid: int, job_type: str, payload: dict | None = None, **kw) -> int:
    with session_scope() as s:
        return jobs.enqueue(s, tenant_id=tid, job_type=job_type, payload=payload, **kw).id


def _job(job_id: int) -> Job:
    with read_session() as s:
        return s.get(Job, job_id)


def test_enqueue_validates_type_and_is_idempotent(empty):
    tid = empty.tenant()
    with session_scope() as s, pytest.raises(ValidationFailed, match="unknown job type"):
        jobs.enqueue(s, tenant_id=tid, job_type="does.not.exist")
    a = _enqueue(tid, "test.ok", {"value": 1}, idempotency_key="same")
    b = _enqueue(tid, "test.ok", {"value": 2}, idempotency_key="same")
    c = _enqueue(tid, "test.ok", {"value": 3})
    assert a == b != c
    other = empty.tenant("other", "Other")
    assert _enqueue(other, "test.ok", idempotency_key="same") not in (a, c), "idempotency keys are scoped to the tenant"


def test_success_stores_result_progress_and_clears_the_lease(empty):
    tid = empty.tenant()
    jid = _enqueue(tid, "test.ok", {"value": 42})
    worker = Worker()
    assert worker.drain() == 1 and worker.run_once() is False
    job = _job(jid)
    assert (job.status, job.result, job.progress, job.attempts) == ("succeeded", {"echo": 42, "attempt": 1}, 1.0, 1)
    assert job.lease_owner is None and job.lease_expires_at is None and job.finished_at >= job.started_at
    assert job.progress_message == "half way" and worker.progress_skipped == 0


def test_failure_is_retried_with_backoff_then_parked(empty):
    activate(empty.db_path, empty.data_dir, CHURN_JOB_BACKOFF_BASE_SECONDS="60")
    tid = empty.tenant()
    jid = _enqueue(tid, "test.flaky", {"succeed_on": 99})
    worker = Worker()
    assert worker.drain() == 1
    job = _job(jid)
    assert job.status == "queued" and "boom on attempt 1" in job.error
    assert timedelta(seconds=50) < job.run_after - utcnow() <= timedelta(seconds=60), "first retry waits one back-off interval"
    assert worker.drain() == 0, "the retry is not due yet"
    for expected_attempt in (2, 3):
        with session_scope() as s:
            s.get(Job, jid).run_after = utcnow()
        assert worker.drain() == 1 and CALLS[-1] == expected_attempt
    job = _job(jid)
    assert (job.status, job.attempts) == ("failed", 3) and "boom on attempt 3" in job.error and job.finished_at is not None


def test_transient_failure_then_success_and_permanent_failure(empty):
    activate(empty.db_path, empty.data_dir, CHURN_JOB_BACKOFF_BASE_SECONDS="0")
    tid = empty.tenant()
    flaky, permanent = _enqueue(tid, "test.flaky", {"succeed_on": 2}), _enqueue(tid, "test.permanent")
    Worker().drain()
    assert (_job(flaky).status, _job(flaky).result, _job(flaky).error) == ("succeeded", {"attempt": 2}, None)
    job = _job(permanent)
    assert (job.status, job.attempts) == ("failed", 1) and "input can never work" in job.error, "permanent errors are not retried"


def test_cancel_and_retry_rules(empty):
    tid, other = empty.tenant(), empty.tenant("other", "Other")
    admin, stranger = empty.user(tid, "admin"), empty.user(other, "admin")
    jid = _enqueue(tid, "test.ok")
    with session_scope() as s, pytest.raises(NotFound):
        jobs.request_cancel(s, stranger, jid)
    with session_scope() as s:
        assert jobs.request_cancel(s, admin, jid).status == "cancelled"
    assert Worker().drain() == 0 and CALLS == []
    with session_scope() as s, pytest.raises(Conflict, match="already cancelled"):
        jobs.request_cancel(s, admin, jid)
    with session_scope() as s:
        assert jobs.retry(s, admin, jid).status == "queued"
    assert Worker().drain() == 1 and _job(jid).status == "succeeded"
    with session_scope() as s, pytest.raises(Conflict, match="only failed or cancelled"):
        jobs.retry(s, admin, jid)


def test_running_job_is_cancelled_cooperatively(empty):
    activate(empty.db_path, empty.data_dir, CHURN_WORKER_HEARTBEAT_SECONDS="0.05")
    tid = empty.tenant()
    jid = _enqueue(tid, "test.loop", {"action": "cancel"})
    Worker().drain()
    job = _job(jid)
    assert job.status == "cancelled" and job.error == "cancelled by request" and job.lease_owner is None


def test_lost_lease_stops_the_job_and_never_overwrites_the_new_owner(empty):
    activate(empty.db_path, empty.data_dir, CHURN_WORKER_HEARTBEAT_SECONDS="0.05")
    tid = empty.tenant()
    looping, finishing = _enqueue(tid, "test.loop", {"action": "steal"}), _enqueue(tid, "test.finish_after_steal")
    Worker().drain()
    for jid in (looping, finishing):
        job = _job(jid)
        assert (job.status, job.lease_owner) == ("running", "another-worker"), "the previous owner must not change the job"
        assert job.result is None


def test_stale_running_jobs_are_recovered(empty):
    tid = empty.tenant()
    first, second = _enqueue(tid, "test.ok"), _enqueue(tid, "test.ok")
    engine = get_engine()
    assert jobs.claim_next(engine, "dead-worker", 60)["id"] == first
    assert jobs.claim_next(engine, "dead-worker", 60)["id"] == second
    with session_scope() as s:
        s.execute(update(Job).values(lease_expires_at=utcnow() - timedelta(seconds=1)))
        s.get(Job, second).attempts = 3
    assert Worker().maintenance() == {"requeued": 1, "failed": 1, "scheduled": 0}
    assert _job(first).status == "queued" and "lease expired" in _job(first).error
    assert _job(second).status == "failed" and "attempts exhausted" in _job(second).error
    assert jobs.heartbeat(engine, first, "dead-worker", 60) == (False, False), "the dead worker no longer owns it"
    Worker().drain()
    assert _job(first).status == "succeeded" and _job(first).attempts == 2


def test_shutdown_releases_the_running_job_without_consuming_an_attempt(empty):
    activate(empty.db_path, empty.data_dir, CHURN_WORKER_SHUTDOWN_GRACE_SECONDS="0")
    tid = empty.tenant()
    jid = _enqueue(tid, "test.ok")
    worker = Worker()
    with session_scope() as s:
        s.get(Job, jid).job_type = "test.loop"
    # the handler asks its own worker to stop, as SIGTERM would
    original = jobs.HANDLERS["test.loop"]
    jobs.HANDLERS["test.loop"] = lambda ctx: (worker.stop(), original(ctx))[1]
    assert worker.run_once() is True
    job = _job(jid)
    assert (job.status, job.attempts) == ("queued", 0) and job.error == "released: worker shutting down" and job.lease_owner is None


def test_progress_inside_a_write_transaction_is_skipped_and_counted(empty):
    """The diagnostic behind the 'report progress outside transactions' rule (SQLite single writer)."""
    tid = empty.tenant()
    jid = _enqueue(tid, "test.progress_in_tx")
    worker = Worker()
    worker.drain()
    assert _job(jid).status == "succeeded"
    assert worker.progress_skipped == 1


def test_schedule_creates_one_job_per_slot_and_collapses_missed_slots(empty):
    tid = empty.tenant()
    slot = utcnow() - timedelta(hours=49)
    with session_scope() as s:
        s.add(Schedule(tenant_id=tid, name="nightly", job_type="test.ok", payload={"value": 7}, interval_seconds=86400, next_run_at=slot, enabled=True))
        s.add(Schedule(tenant_id=tid, name="paused", job_type="test.ok", payload={}, interval_seconds=60, next_run_at=slot, enabled=False))
    w1, w2 = Worker(), Worker()
    assert w1.enqueue_due_schedules() == 1 and w2.enqueue_due_schedules() == 0
    with read_session() as s:
        sched = s.execute(select(Schedule).where(Schedule.name == "nightly")).scalar_one()
        queued = s.execute(select(Job)).scalars().all()
    assert len(queued) == 1 and queued[0].payload == {"value": 7} and queued[0].idempotency_key == f"schedule:{sched.id}:{slot.isoformat()}"
    assert sched.last_job_id == queued[0].id and sched.next_run_at == slot + timedelta(days=3) and sched.next_run_at > utcnow()


def _race(n_jobs: int, tid: int) -> list:
    ids = [_enqueue(tid, "test.ok") for _ in range(n_jobs)]
    workers = [Worker(worker_id=f"w{i}") for i in range(3)]
    threads = [threading.Thread(target=w.drain) for w in workers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=120)
    assert sorted(CALLS) == ids, "every job ran exactly once"
    with read_session() as s:
        assert {j.status for j in s.execute(select(Job)).scalars()} == {"succeeded"}
    return [w.processed for w in workers]


def test_competing_workers_never_run_a_job_twice(empty):
    processed = _race(30, empty.tenant())
    assert sum(processed) == 30


@pytest.mark.postgres
@pytest.mark.req("REQ-OPS-01")
def test_competing_workers_on_postgresql(postgres_url, tmp_path):
    from churn_platform import dbadmin
    from tests.test_migrations import reset_postgres

    require_or_skip(True, "")
    reset_postgres(postgres_url)
    activate(postgres_url, tmp_path / "data")
    dbadmin.upgrade()
    from churn_platform.services import auth

    with session_scope() as s:
        tid = auth.create_tenant(s, "race", "Race Ltd").id
    processed = _race(40, tid)
    assert sum(processed) == 40
    reset_postgres(postgres_url)


# ----------------------------------------------------------------------------- the demo seeder waits for its jobs
@pytest.mark.req("REQ-OPS-02", "REQ-OPS-06")
def test_demo_seeding_moves_on_only_when_the_jobs_of_a_step_are_finished(empty):
    """`seed-demo` runs its jobs itself, but "nothing left for me to claim" is not "done": a job can be waiting
    for a retry, or a worker that is running next to the seeder can have taken it."""
    from churn_platform.services import demo

    tid, other = empty.tenant(), empty.tenant("globex", "Globex Ltd")
    engine, lines = get_engine(), []
    # a job that is not due yet (the state of a job waiting for its retry)
    later = _enqueue(tid, "test.ok", run_after=utcnow() + timedelta(seconds=0.6))
    demo._drain("retry", lines.append, tid)
    assert _job(later).status == "succeeded" and lines == ["retry: 1 job(s) completed"]
    # a job another worker claimed first: wait while it runs there, and count it
    elsewhere = _enqueue(tid, "test.ok")
    assert jobs.claim_next(engine, "other-worker", 60)["id"] == elsewhere
    finisher = threading.Timer(0.6, lambda: jobs.mark_succeeded(engine, elsewhere, "other-worker", {"by": "other-worker"}))
    finisher.start()
    demo._drain("elsewhere", lines.append, tid)
    finisher.join()
    assert _job(elsewhere).result == {"by": "other-worker"} and lines[-1] == "elsewhere: 1 job(s) completed"
    assert len(CALLS) == 1, "the job the other worker owned was not run a second time here"
    # a job whose worker died: taken over as soon as its lease has run out
    orphan = _enqueue(tid, "test.ok")
    assert jobs.claim_next(engine, "dead-worker", 0.5)["id"] == orphan
    demo._drain("orphan", lines.append, tid)
    assert _job(orphan).status == "succeeded" and _job(orphan).attempts == 2
    # another tenant's failed job is none of this seed's business
    foreign = _enqueue(other, "test.permanent")
    Worker().drain()
    assert _job(foreign).status == "failed"
    demo._drain("foreign failure", lines.append, tid)
    assert lines[-1] == "foreign failure: 0 job(s) completed"
    # a job that never becomes due ends the seed with a message instead of hanging
    stuck = _enqueue(tid, "test.ok", run_after=utcnow() + timedelta(hours=1))
    with pytest.raises(demo.DemoError, match=r"stuck: 1 job\(s\) still unfinished after 0 s"):
        demo._drain("stuck", lines.append, tid, timeout_seconds=0.3)
    with session_scope() as s:
        s.execute(update(Job).where(Job.id == stuck).values(status="cancelled"))
    # and the seed's own failed job stops it, naming the job
    own = _enqueue(tid, "test.permanent")
    with pytest.raises(demo.DemoError, match=rf"own failure: job\(s\) failed: #{own} test\.permanent: .*input can never work"):
        demo._drain("own failure", lines.append, tid)
