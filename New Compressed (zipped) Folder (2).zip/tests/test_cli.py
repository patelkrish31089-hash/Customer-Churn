"""The command line.  Commands run as real subprocesses (``python -m churn_platform ...``), the way an operator,
cron or a container entrypoint runs them.  The password prompt is exercised in-process and, as a real process, on a
pseudo-terminal."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

import httpx2
import pytest
from sqlalchemy import create_engine, func, inspect, select

from churn_platform import __version__, cli, dbadmin, security
from churn_platform.db import Base, read_session, session_scope
from churn_platform.models import AuditEvent, Customer, Job, Prediction, Tenant, User
from churn_platform.services import demo as demo_service
from churn_platform.services import quality
from tests.conftest import DEMO_ARGS, PASSWORD, activate
from tests.test_migrations import reset_postgres

API = "/api/v1"
HEAD = dbadmin.head_revision()
SEED_ARGS = ("seed-demo", "--slug", "demo", "--customers", str(DEMO_ARGS["customers"]), "--months", str(DEMO_ARGS["months"]), "--seed", str(DEMO_ARGS["seed"]),
             "--end-date", DEMO_ARGS["end_date"].isoformat(), "--n-iter", str(DEMO_ARGS["n_iter"]), "--password-env", "DEMO_PW")  # fmt: skip
SUMMARY_KEYS = ("tenant", "synthetic", "users", "model", "batch", "recommendations", "experiment")

pytestmark = pytest.mark.runtime


def _env(db: Path | str, data: Path, **extra: str) -> dict[str, str]:
    env = {k: v for k, v in os.environ.items() if not k.startswith("CHURN_")}
    env.update({"CHURN_ENV": "test", "CHURN_LOG_LEVEL": "ERROR", "CHURN_SECRET_KEY": os.environ["CHURN_SECRET_KEY"],
                "CHURN_DATABASE_URL": str(db) if "://" in str(db) else f"sqlite:///{db}", "CHURN_DATA_DIR": str(data), **extra})  # fmt: skip
    return env


def _run(db: Path | str, data: Path, *args: str, timeout: int = 600, **extra: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, "-m", "churn_platform", *args], env=_env(db, data, **extra), capture_output=True, text=True,
                          timeout=timeout, stdin=subprocess.DEVNULL, check=False)  # fmt: skip


def _ok(db: Path | str, data: Path, *args: str, **extra: str) -> dict:
    done = _run(db, data, *args, **extra)
    assert done.returncode == 0, f"{args}: exit {done.returncode}\nstdout: {done.stdout}\nstderr: {done.stderr}"
    return json.loads(done.stdout)


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _stop(process: subprocess.Popen, timeout: float = 30) -> tuple[int, str]:
    process.send_signal(signal.SIGTERM)
    try:
        _, err = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        process.kill()
        _, err = process.communicate()
        pytest.fail(f"the process did not stop within {timeout}s of SIGTERM\n{err}")
    return process.returncode, err


# ----------------------------------------------------------------------------- basics
@pytest.mark.req("REQ-OPS-06")
def test_version_usage_and_the_installed_console_script(tmp_path):
    shown = _run(tmp_path / "x.db", tmp_path, "--version")
    assert (shown.returncode, shown.stdout.strip()) == (0, f"churn-platform {__version__}")
    nothing = _run(tmp_path / "x.db", tmp_path)
    assert nothing.returncode == 2 and "usage: churn-platform" in nothing.stderr
    unknown = _run(tmp_path / "x.db", tmp_path, "frobnicate")
    assert unknown.returncode == 2 and "invalid choice" in unknown.stderr
    script = Path(sys.executable).parent / "churn-platform"
    assert script.exists(), "the package installs a console script"
    via_script = subprocess.run([str(script), "--version"], capture_output=True, text=True, env=_env(tmp_path / "x.db", tmp_path), check=False)
    assert via_script.stdout == shown.stdout
    commands = _run(tmp_path / "x.db", tmp_path, "--help").stdout
    for command in ("migrate", "downgrade", "db-status", "create-tenant", "create-user", "worker", "serve", "seed-demo", "nightly", "verify-audit"):
        assert command in commands
    assert not (tmp_path / "x.db").exists(), "asking for help or the version touches no database"


# ----------------------------------------------------------------------------- database, tenants, users, audit
@pytest.mark.req("REQ-OPS-01")
def test_an_operator_brings_up_a_database_creates_a_tenant_and_a_user_and_verifies_the_audit_trail(tmp_path):
    db, data = tmp_path / "ops.db", tmp_path / "data"
    fresh = _run(db, data, "db-status")
    assert fresh.returncode == 1, "an empty database is reported as not ready"
    assert json.loads(fresh.stdout) == {"current": None, "head": HEAD, "up_to_date": False, "schema_drift": ["database is not migrated"]}
    assert _ok(db, data, "migrate") == {"current": HEAD, "head": HEAD, "up_to_date": True}
    assert _ok(db, data, "db-status")["schema_drift"] == []
    assert _ok(db, data, "migrate")["up_to_date"] is True, "migrating twice is harmless"
    # tenant
    tenant = _ok(db, data, "create-tenant", "--slug", "acme", "--name", "Acme Ltd")
    assert (tenant["slug"], tenant["name"]) == ("acme", "Acme Ltd")
    twice = _run(db, data, "create-tenant", "--slug", "acme")
    assert (twice.returncode, twice.stderr.strip()) == (2, "error: tenant 'acme' already exists")
    assert _run(db, data, "create-tenant", "--slug", "not a slug!").returncode == 2
    # user: the password comes from an environment variable and is never echoed
    secret = "Owner-Passphrase-2026!"
    user_args = ("create-user", "--tenant", "acme", "--email", "Owner@Acme.example", "--name", "The Owner", "--role", "admin")
    created = _run(db, data, *user_args, "--password-env", "OWNER_PW", OWNER_PW=secret)
    assert created.returncode == 0 and secret not in created.stdout + created.stderr
    assert json.loads(created.stdout) == {"user_id": json.loads(created.stdout)["user_id"], "email": "owner@acme.example", "role": "admin", "tenant": "acme"}
    for args, extra, code, message in (
        (user_args, {}, 1, "no password given: use --password-env VAR"),
        ((*user_args, "--password-env", "OWNER_PW"), {}, 1, "environment variable OWNER_PW is empty or not set"),
        ((*user_args, "--password-env", "OWNER_PW"), {"OWNER_PW": secret}, 2, "error: a user with this email already exists"),
        (("create-user", "--tenant", "nope", "--email", "a@b.example", "--password-env", "OWNER_PW"), {"OWNER_PW": secret}, 1, "tenant 'nope' does not exist"),
        (("create-user", "--tenant", "acme", "--email", "weak@acme.example", "--password-env", "OWNER_PW"), {"OWNER_PW": "short"}, 2, "error: "),
        (("create-user", "--tenant", "acme", "--email", "x@acme.example", "--role", "superuser", "--password-env", "OWNER_PW"), {"OWNER_PW": secret}, 2, "error: role must be one of"),
    ):  # fmt: skip
        failed = _run(db, data, *args, **extra)
        assert failed.returncode == code and message in failed.stderr, (args, failed.returncode, failed.stderr)
        assert "Traceback" not in failed.stderr, "operator mistakes are answered with a message, not a stack trace"
    activate(db, data)
    with read_session() as s:
        owner = s.execute(select(User)).scalar_one()
        assert (owner.email, owner.full_name, owner.role) == ("owner@acme.example", "The Owner", "admin") and secret not in (owner.password_hash or "")
        assert security.verify_password(secret, owner.password_hash)
    # audit chain
    verified = _ok(db, data, "verify-audit", "--tenant", "acme")
    assert verified["valid"] is True and verified["checked"] == verified["total"] >= 1
    con = sqlite3.connect(db)
    con.execute("UPDATE audit_events SET action = 'user.deleted' WHERE id = (SELECT MIN(id) FROM audit_events WHERE tenant_id = ?)", (tenant["tenant_id"],))
    con.commit()
    con.close()
    broken = _run(db, data, "verify-audit", "--tenant", "acme")
    assert broken.returncode == 1 and json.loads(broken.stdout)["valid"] is False, "a changed audit row is detected and signalled through the exit code"
    assert _run(db, data, "verify-audit", "--tenant", "nope").returncode == 1
    # downgrade removes the schema; migrating again starts clean
    assert _ok(db, data, "downgrade", "base") == {"current": None, "head": HEAD, "up_to_date": False}
    assert _run(db, data, "db-status").returncode == 1
    assert _ok(db, data, "migrate")["up_to_date"] is True
    assert _ok(db, data, "create-tenant", "--slug", "acme")["name"] == "acme", "the old tenant went with the schema"


@pytest.mark.req("REQ-OPS-01")
@pytest.mark.postgres
def test_the_same_commands_manage_a_postgresql_database(postgres_url, tmp_path):
    reset_postgres(postgres_url)
    data = tmp_path / "data"
    assert _run(postgres_url, data, "db-status").returncode == 1
    assert _ok(postgres_url, data, "migrate")["up_to_date"] is True
    assert _ok(postgres_url, data, "db-status")["schema_drift"] == []
    assert _ok(postgres_url, data, "create-tenant", "--slug", "pg")["slug"] == "pg"
    assert _ok(postgres_url, data, "create-user", "--tenant", "pg", "--email", "a@pg.example", "--password-env", "PW", PW=PASSWORD)["role"] == "admin"
    assert _ok(postgres_url, data, "verify-audit", "--tenant", "pg")["valid"] is True
    assert _ok(postgres_url, data, "downgrade", "base")["current"] is None
    reset_postgres(postgres_url)


# ----------------------------------------------------------------------------- passwords (in-process, then on a pseudo-terminal)
@pytest.mark.req("REQ-SEC-01")
def test_passwords_come_from_the_environment_a_prompt_or_are_generated(monkeypatch, capsys):
    monkeypatch.setenv("PW_VAR", "From-The-Environment-1!")
    assert cli._password(argparse.Namespace(password_env="PW_VAR")) == ("From-The-Environment-1!", False)
    generated, was_generated = cli._password(argparse.Namespace(password_env=None), generate=True)
    assert was_generated is True and len(generated) >= 16 and security.password_problems(generated, 12) == []
    assert generated != cli._password(argparse.Namespace(password_env=None), generate=True)[0]
    # at a terminal the password is asked twice and must match
    monkeypatch.setattr(cli.sys.stdin, "isatty", lambda: True)
    answers = iter(["Typed-At-The-Prompt-1!", "Typed-At-The-Prompt-1!", "one", "another"])
    monkeypatch.setattr(cli.getpass, "getpass", lambda prompt: next(answers))
    assert cli._password(argparse.Namespace(password_env=None)) == ("Typed-At-The-Prompt-1!", False)
    with pytest.raises(SystemExit, match="passwords do not match"):
        cli._password(argparse.Namespace(password_env=None))
    assert capsys.readouterr().out == "", "nothing typed is echoed"


def _at_a_terminal(db: Path, data: Path, args: tuple[str, ...], script: list[tuple[str, str]], timeout: float = 120) -> tuple[int, str, list[bool]]:
    """Run the command line as its own process on a pseudo-terminal, the way a shell runs it for an operator: the
    process has a controlling terminal, nothing is patched.  ``script`` is a list of (text to wait for, keys to
    press).  Returns the exit code, everything the terminal displayed, and whether the terminal was echoing keys
    each time some were pressed."""
    import pty
    import select
    import termios

    pid, fd = pty.fork()
    if pid == 0:  # the child: becomes the command (this interpreter, fixed arguments, no shell)
        # A shell starts a command with Ctrl-C enabled.  This test run may itself have been started with the signal
        # ignored (a background job, nohup); an ignored signal stays ignored across exec, so it is reset here.
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        os.execve(sys.executable, [sys.executable, "-m", "churn_platform", *args], _env(db, data))  # noqa: S606
    shown, seen, steps, echoing, deadline = b"", 0, list(script), [], time.monotonic() + timeout
    try:
        while time.monotonic() < deadline:
            if select.select([fd], [], [], 0.2)[0]:
                try:
                    chunk = os.read(fd, 4096)
                except OSError:  # Linux reports the end of the terminal's output this way
                    break
                if not chunk:
                    break
                shown += chunk
            if steps and steps[0][0].encode() in shown[seen:]:
                time.sleep(0.3)  # the prompt is written before echo is switched off
                echoing.append(bool(termios.tcgetattr(fd)[3] & termios.ECHO))
                seen = len(shown)
                os.write(fd, steps.pop(0)[1].encode())
        else:
            os.kill(pid, signal.SIGKILL)
        code = os.waitstatus_to_exitcode(os.waitpid(pid, 0)[1])
    finally:
        os.close(fd)
    return code, shown.decode(errors="replace").replace("\r\n", "\n"), echoing


@pytest.mark.req("REQ-SEC-01")
def test_at_a_real_terminal_the_password_is_typed_twice_unseen_and_the_prompt_can_be_abandoned(tmp_path):
    db, data = tmp_path / "tty.db", tmp_path / "data"
    _ok(db, data, "migrate")
    _ok(db, data, "create-tenant", "--slug", "acme")
    user, typed = ("create-user", "--tenant", "acme", "--email"), "Typed-On-A-Terminal-42"
    # a missing tenant is reported before anything is asked
    code, shown, echoing = _at_a_terminal(db, data, ("create-user", "--tenant", "nope", "--email", "a@nope.example"), [])
    assert (code, echoing) == (1, []) and "tenant 'nope' does not exist" in shown and "Password" not in shown
    # the password is asked twice, the terminal does not echo the keys, and what was typed is the password
    code, shown, echoing = _at_a_terminal(db, data, (*user, "typed@acme.example"), [("Password: ", typed + "\n"), ("Repeat password: ", typed + "\n")])
    assert (code, echoing) == (0, [False, False]), shown
    assert typed not in shown and json.loads(shown[shown.index("{"):])["email"] == "typed@acme.example"
    # two different entries, a password that breaks the rules, Ctrl-C and Ctrl-D: a message and an exit code, never a stack trace
    for email, script, expected, message in (
        ("differs@acme.example", [("Password: ", typed + "\n"), ("Repeat password: ", "Something-Else-43\n")], 1, "passwords do not match"),
        ("short@acme.example", [("Password: ", "short\n"), ("Repeat password: ", "short\n")], 2, "error: password must be at least 12 characters"),
        ("ctrl-c@acme.example", [("Password: ", "\x03")], 130, "cancelled: no password was entered, nothing was changed"),
        ("ctrl-c-later@acme.example", [("Password: ", typed + "\n"), ("Repeat password: ", "\x03")], 130, "cancelled: no password was entered"),
        ("ctrl-d@acme.example", [("Password: ", "\x04")], 1, "cancelled: no password was entered, nothing was changed"),
    ):  # fmt: skip
        code, shown, echoing = _at_a_terminal(db, data, (*user, email), script)
        assert code == expected and message in shown, (email, code, shown)
        assert "Traceback" not in shown and not any(echoing), (email, shown, echoing)
        assert typed not in shown and "Something-Else-43" not in shown and "short\n" not in shown, "nothing typed is displayed"
    activate(db, data)
    with read_session() as s:
        created = s.execute(select(User)).scalars().all()
        assert [u.email for u in created] == ["typed@acme.example"], "an abandoned or refused prompt creates nobody"
        assert security.verify_password(typed, created[0].password_hash)


@pytest.mark.req("REQ-OPS-06")
def test_seed_demo_shows_a_generated_password_once_and_reports_seed_failures(empty, monkeypatch, capsys):
    seen = {}

    def fake_seed(**kwargs):
        seen.update(kwargs)
        kwargs["log"]("step one")
        return {"tenant": {"slug": kwargs["slug"]}, "synthetic": True, "users": ["admin@x.example"], "model": {}, "batch": {}, "recommendations": {},
                "experiment": {}, "internal": "not shown"}  # fmt: skip

    monkeypatch.setattr(demo_service, "seed_demo", fake_seed)
    assert cli.main(["seed-demo", "--slug", "x", "--customers", "50", "--months", "13", "--seed", "5", "--end-date", "2026-06-30", "--n-iter", "2"]) == 0
    printed = capsys.readouterr()
    out = json.loads(printed.out)
    assert out["generated_password"] == seen["password"] and "shown once" in out["note"] and "internal" not in out
    assert (seen["slug"], seen["customers"], seen["months"], seen["seed"], seen["n_iter"], seen["end_date"].isoformat()) == ("x", 50, 13, 5, 2, "2026-06-30")
    assert "step one" in printed.err and "step one" not in printed.out, "progress goes to stderr so that stdout stays machine-readable"
    monkeypatch.setenv("DEMO_PW", PASSWORD)
    assert cli.main(["seed-demo", "--slug", "y", "--password-env", "DEMO_PW"]) == 0
    assert "generated_password" not in json.loads(capsys.readouterr().out) and seen["password"] == PASSWORD and seen["end_date"] is None

    def failing_seed(**kwargs):
        raise demo_service.DemoError("tenant 'x' already exists; choose another --slug")

    monkeypatch.setattr(demo_service, "seed_demo", failing_seed)
    with pytest.raises(SystemExit, match="tenant 'x' already exists"):
        cli.main(["seed-demo", "--slug", "x"])


# ----------------------------------------------------------------------------- seed-demo and the nightly run, for real
@pytest.mark.slow
@pytest.mark.req("REQ-OPS-04")
def test_seed_demo_builds_the_documented_demo_and_the_nightly_command_runs_it(template, tmp_path):
    """As the README has it: the first command in a fresh checkout, with no configuration at all.  The database and the data
    directory then default to ./var, which does not exist yet; the first command used to stop there with a traceback."""
    home = tmp_path / "fresh-checkout"
    home.mkdir()
    db, data = home / "var" / "churn.db", home / "var" / "data"  # the default locations, relative to the working directory
    unconfigured = {k: v for k, v in os.environ.items() if not k.startswith("CHURN_")} | {"DEMO_PW": PASSWORD}

    def _run(_db, _data, *arguments: str) -> subprocess.CompletedProcess:
        return subprocess.run([sys.executable, "-m", "churn_platform", *arguments], env=unconfigured, cwd=home, capture_output=True, text=True,
                              timeout=600, stdin=subprocess.DEVNULL, check=False)  # fmt: skip

    def _ok(_db, _data, *arguments: str) -> dict:
        done = _run(_db, _data, *arguments)
        assert done.returncode == 0, f"{arguments}: exit {done.returncode}\nstdout: {done.stdout}\nstderr: {done.stderr}"
        return json.loads(done.stdout)

    fresh = _run(db, data, "db-status")
    assert fresh.returncode == 1 and json.loads(fresh.stdout)["schema_drift"] == ["database is not migrated"], fresh.stderr[-2000:]
    args = SEED_ARGS
    seeded = _run(db, data, *args)  # on a database that does not exist yet: the command migrates it first
    assert seeded.returncode == 0, seeded.stderr[-3000:]
    assert db.is_file() and data.is_dir() and sorted(p.name for p in home.iterdir()) == ["var"]
    out = json.loads(seeded.stdout)
    assert set(out) == {"tenant", "synthetic", "users", "model", "batch", "recommendations", "experiment"} and PASSWORD not in seeded.stdout + seeded.stderr
    assert "Traceback" not in seeded.stderr and "Warning" not in seeded.stderr, seeded.stderr[-2000:]
    # the command builds exactly what the service builds: the suite's seeded template was made in-process with the same
    # arguments, so every reported figure (metrics, threshold, tier counts, mean probability) must be identical
    expected = template.summary
    for key in SUMMARY_KEYS:
        assert out[key] == expected[key], key
    assert out["tenant"] == "demo" and out["batch"]["tiers"] == {"high": 22, "medium": 63, "low": 127} and out["batch"]["customers_scored"] == 212
    assert out["recommendations"] == {"high_risk_high_value": {"proposed": 4}, "involuntary": {"proposed": 41},
                                      "medium_risk_low_value": {"blocked": 3, "proposed": 43}}  # fmt: skip
    again = _run(db, data, *args)
    assert again.returncode == 1 and "already exists" in again.stderr and "Traceback" not in again.stderr
    # nightly: run here and report
    nightly = _run(db, data, "nightly", "--tenant", "demo", "--wait")
    assert nightly.returncode == 0, nightly.stderr[-3000:]
    report = json.loads(nightly.stdout)
    assert report["status"] == "completed" and [(s["step"], s["status"]) for s in report["steps"]] == [
        ("data_quality", "succeeded"), ("signals", "succeeded"), ("labels", "succeeded"), ("features", "succeeded"), ("scoring", "skipped"),
        ("recommendations", "succeeded"), ("monitoring", "succeeded")]  # fmt: skip
    # nightly without --wait only queues (for cron next to a worker); a second call joins the queued run; the worker finishes it
    queued = _ok(db, data, "nightly", "--tenant", "demo")
    assert queued["already_running"] is False and _ok(db, data, "nightly", "--tenant", "demo") == {"queued_job_id": queued["queued_job_id"], "already_running": True}
    worked = _ok(db, data, "worker", "--once")
    assert worked["processed"] >= 8 and worked["progress_skipped"] == 0
    missing = _run(db, data, "nightly", "--tenant", "nope")
    assert missing.returncode == 1 and "tenant 'nope' does not exist" in missing.stderr
    assert _ok(db, data, "verify-audit", "--tenant", "demo")["valid"] is True
    activate(db, data)
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(Customer)).scalar_one() == 300
        assert s.execute(select(Job.job_type).where(Job.status != "succeeded")).scalars().all() == ["campaign.tick"], "only the campaign step dated three days ahead waits"
        chains = s.execute(select(func.count()).select_from(AuditEvent).where(AuditEvent.action == "pipeline.completed")).scalar_one()
        assert chains == 2 and s.execute(select(Tenant.slug).where(Tenant.slug == "demo")).scalar_one() == "demo"
    assert not list(Path(data).rglob("*.tmp")), "no temporary files are left in the data directory"


@pytest.mark.slow
@pytest.mark.postgres
@pytest.mark.req("REQ-OPS-01")
def test_the_demo_seeded_on_postgresql_equals_the_demo_seeded_on_sqlite(postgres_url, template, tmp_path):
    """The whole chain (ingestion, quality, labels, features, training, scoring, retention, experiment, monitoring) runs on
    PostgreSQL and arrives at the same rows and the same figures as on SQLite."""
    reset_postgres(postgres_url)
    data = tmp_path / "data"
    try:
        seeded = _run(postgres_url, data, *SEED_ARGS, DEMO_PW=PASSWORD)
        assert seeded.returncode == 0, seeded.stderr[-3000:]
        assert "Traceback" not in seeded.stderr and "Warning" not in seeded.stderr, seeded.stderr[-2000:]
        out = json.loads(seeded.stdout)
        for key in SUMMARY_KEYS:
            assert out[key] == template.summary[key], key
        # row counts, table by table, and every stored probability
        def snapshot(url: str) -> tuple[dict[str, int], list[float]]:
            engine = create_engine(url)
            try:
                with engine.connect() as conn:
                    assert set(inspect(conn).get_table_names()) - {"alembic_version"} == set(Base.metadata.tables)
                    counts = {t.name: conn.execute(select(func.count()).select_from(t)).scalar_one() for t in Base.metadata.sorted_tables}
                    scores = conn.execute(select(Prediction.probability).order_by(Prediction.batch_id, Prediction.customer_id)).scalars().all()
                    return counts, [float(v) for v in scores]
            finally:
                engine.dispose()

        counts_lite, scores_lite = snapshot(f"sqlite:///{template.demo_db}")
        counts_pg, scores_pg = snapshot(postgres_url)
        tables = sorted(counts_pg)
        # the template's tenant is the second one in its database (ids differ, contents must not); sessions depend on logins
        different = {t: (counts_lite[t], counts_pg[t]) for t in tables if counts_lite[t] != counts_pg[t] and t not in ("tenants", "auth_sessions")}
        assert different == {}, f"row counts differ between SQLite and PostgreSQL: {different}"
        assert counts_pg["customers"] == 300 and counts_pg["predictions"] == 429 and len(scores_pg) == 429
        assert scores_pg == pytest.approx(scores_lite, abs=1e-12), "every customer gets the same probability on both databases"
        # the operational commands work on PostgreSQL too
        nightly = _run(postgres_url, data, "nightly", "--tenant", "demo", "--wait")
        assert nightly.returncode == 0 and json.loads(nightly.stdout)["status"] == "completed", nightly.stdout + nightly.stderr[-2000:]
        assert _ok(postgres_url, data, "verify-audit", "--tenant", "demo")["valid"] is True
        assert _ok(postgres_url, data, "db-status")["schema_drift"] == []
    finally:
        reset_postgres(postgres_url)


# ----------------------------------------------------------------------------- long-running processes
def _wait_for(check, timeout: float = 60, interval: float = 0.25):
    deadline = time.monotonic() + timeout
    last = None
    while time.monotonic() < deadline:
        try:
            last = check()
            if last:
                return last
        except (httpx2.HTTPError, OSError) as exc:
            last = exc
        time.sleep(interval)
    pytest.fail(f"condition not met within {timeout}s (last: {last!r})")


@pytest.mark.req("REQ-OPS-02")
def test_serve_answers_requests_runs_jobs_on_the_embedded_worker_and_stops_on_sigterm(template, tmp_path):
    db, data = tmp_path / "served.db", tmp_path / "data"
    shutil.copyfile(template.demo_db, db)
    shutil.copytree(template.demo_data, data)
    port = _free_port()
    process = subprocess.Popen([sys.executable, "-m", "churn_platform", "serve", "--port", str(port)],
                               env=_env(db, data, CHURN_EMBEDDED_WORKER="true", CHURN_LOG_LEVEL="INFO"),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, stdin=subprocess.DEVNULL)  # fmt: skip
    base = f"http://127.0.0.1:{port}"
    try:
        with httpx2.Client(base_url=base, timeout=20) as http:
            _wait_for(lambda: http.get("/healthz").status_code == 200)
            ready = http.get("/readyz")
            assert ready.status_code == 200 and ready.json() == {"status": "ready", "database": "ok"}
            assert "server" not in {k.lower() for k in http.get("/healthz").headers}, "the server software is not advertised"
            page = http.get("/")
            assert page.status_code == 200 and "<title>" in page.text and page.headers["content-type"].startswith("text/html")
            login = http.post(f"{API}/auth/login", json={"email": "admin@demo.example", "password": PASSWORD})
            assert login.status_code == 200
            headers = {"Authorization": "Bearer " + login.json()["token"]}
            # a job submitted over HTTP is picked up by the worker thread inside the server process
            started = http.post(f"{API}/quality/runs", headers=headers)
            assert started.status_code == 202
            job_id = started.json()["job"]["id"]
            job = _wait_for(lambda: (lambda j: j if j["status"] not in ("queued", "running") else None)(http.get(f"{API}/jobs/{job_id}", headers=headers).json()))
            assert job["status"] == "succeeded" and job["result"]["rules_evaluated"] == 18
    finally:
        code, err = _stop(process)
    assert code == 0, f"serve exits with status 0 after a graceful shutdown (exit {code})\n{err[-2000:]}"
    assert "Traceback" not in err, err[-2000:]
    lines = [line for line in err.splitlines() if line.strip()]
    records = [json.loads(line) for line in lines]  # every line: the server's own messages use the application's JSON format too
    messages = [r["message"] for r in records]
    for expected in ("Application startup complete.", "worker started", "shutdown requested", "worker stopped", "Application shutdown complete."):
        assert expected in messages, (expected, messages)
    assert messages.index("worker stopped") < messages.index("Application shutdown complete."), "the server waits for its worker thread"
    assert PASSWORD not in err and login.json()["token"] not in err
    activate(db, data)
    with read_session() as s:
        done = s.get(Job, job_id)
        assert done.status == "succeeded" and done.lease_owner is None


@pytest.mark.req("REQ-OPS-02")
def test_the_worker_process_picks_up_jobs_and_finishes_the_current_one_before_it_stops(template, tmp_path):
    db, data = tmp_path / "worked.db", tmp_path / "data"
    shutil.copyfile(template.demo_db, db)
    shutil.copytree(template.demo_data, data)
    process = subprocess.Popen([sys.executable, "-m", "churn_platform", "worker"], env=_env(db, data, CHURN_LOG_LEVEL="INFO"),
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, stdin=subprocess.DEVNULL)  # fmt: skip
    try:
        activate(db, data)
        with session_scope() as s:
            tenant_id = s.execute(select(Tenant.id).where(Tenant.slug == "demo")).scalar_one()
            _, job = quality.start_run(s, demo_service.system_principal(s, tenant_id, "admin@demo.example"))
            job_id = job.id

        def finished():
            with read_session() as s:
                return s.get(Job, job_id).status == "succeeded"

        _wait_for(finished)
    finally:
        code, err = _stop(process)
    assert code == 0, f"the worker exits cleanly on SIGTERM (exit {code})\n{err[-2000:]}"
    lines = [json.loads(line) for line in err.splitlines() if line.startswith("{")]
    messages = [line["message"] for line in lines]
    assert "worker started" in messages and "worker stopped" in messages and "Traceback" not in err
    assert all({"ts", "level", "logger", "message"} <= set(line) for line in lines), "logs are structured JSON, one object per line"
