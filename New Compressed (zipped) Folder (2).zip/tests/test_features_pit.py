"""Point-in-time correctness of the feature engine.

The contract: a feature vector for as-of date T uses only what was knowable strictly before
T 00:00:00 UTC.  It is proven three ways: (1) hand-computed values, (2) removing everything at or
after T changes nothing, (3) adding or changing records at or after T changes nothing.
"""

from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import func, select

from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, Forbidden, ValidationFailed
from churn_platform.models import FeatureContract, FeatureRun, FeatureVector, OnlineFeature
from churn_platform.services import feature_engine as fe
from churn_platform.services import features, timeline
from tests.builders import World

pytestmark = pytest.mark.req("REQ-ML-02")
T = date(2026, 4, 1)
SEEDED_DATES = [date(2026, 3, 1), date(2026, 7, 1), date(2026, 10, 1)]
SNAPSHOT = {f.name for f in fe.CATALOG if f.pit == "snapshot"}


def vector(world: World, as_of: date = T, customer_id: int = 1) -> dict:
    out = fe.compute_features(world.frames(), [as_of])
    rows = out[out["customer_id"] == customer_id]
    assert len(rows) == 1, f"expected one vector for customer {customer_id}, got {len(rows)}"
    return rows.iloc[0].to_dict()


def base_world(**sub) -> World:
    w = World()
    w.plan(1, tier="pro", billing_period="monthly")
    w.plan(2, tier="enterprise", billing_period="annual")
    w.customer(1, industry="software", employee_count=100, company_size="mid_market", region="emea", acquisition_channel="organic", acquired_at="2026-01-01")
    w.account(1, payment_method_expires_on="2026-12-31")
    w.subscription(1, 1, "2026-01-01", plan_id=1, mrr=200.0, quantity=10, discount_pct=0.0, **sub)
    return w


def assert_same(a: pd.DataFrame, b: pd.DataFrame) -> None:
    key = ["as_of_date", "customer_id"]
    a, b = (x.sort_values(key).reset_index(drop=True) for x in (a, b))
    pd.testing.assert_frame_equal(a, b, check_exact=True, check_dtype=False)


def changed_features(a: pd.DataFrame, b: pd.DataFrame) -> set[str]:
    key = ["as_of_date", "customer_id"]
    a, b = (x.sort_values(key).reset_index(drop=True) for x in (a, b))
    assert a[key].equals(b[key])
    return {c for c in fe.FEATURE_NAMES if not ((a[c] == b[c]) | (a[c].isna() & b[c].isna())).all()}


# ----------------------------------------------------------------------------- catalogue
def test_catalogue_covers_the_engineered_features_of_the_brief():
    names = fe.FEATURE_NAMES
    assert len(names) == len(set(names)) == 84
    assert {f.group for f in fe.CATALOG} == {"customer", "subscription", "rfm", "usage", "trend", "inactivity", "support", "billing", "adoption"}
    assert all(f.description and f.label and f.sources and f.dtype in ("float", "int", "bool", "category") for f in fe.CATALOG)
    for required in ("recency_days", "frequency_30d", "monetary_90d",  # RFM
                     "logins_7d", "logins_30d", "login_delta_7d_30d_pct", "login_ratio_7d_30d",  # 7-day vs 30-day velocity
                     "support_friction_index_90d",  # tickets x resolution time
                     "feature_use_delta_7d_30d_pct", "key_action_delta_7d_30d_pct", "minutes_delta_7d_30d_pct",  # ... for every core product action
                     "avg_daily_active_users_30d", "avg_session_minutes_30d", "distinct_features_30d", "days_to_first_key_action",  # DAU, session length, adoption, TTV
                     "open_tickets", "avg_resolution_hours_90d", "last_nps_score", "negative_ticket_share_90d",  # support and sentiment
                     "inactivity_streak_days", "ew_inactivity_score"):  # exponentially weighted inactivity
        assert required in fe.SPECS, required
    out = fe.compute_features(base_world().frames(), [T])
    assert list(out.columns) == ["customer_id", "as_of_date", "max_source_ts", *names], "every catalogued feature is computed"
    assert {"billing_period", "seats", "discount_pct", "days_to_card_expiry", "days_to_renewal", "active_user_seat_share_30d"} == SNAPSHOT
    # 1.1.0: customer attributes are read from their history (the value that held at T), no longer from today's row
    assert {f.name for f in fe.CATALOG if f.pit == "history"} == {"employee_count", "company_size", "industry", "region", "acquisition_channel"}


# ----------------------------------------------------------------------------- hand-computed values
def _rich_world() -> World:
    w = base_world()
    w.usage(1, "2026-03-31 10:00", "session", duration_seconds=1800, user_ref="ana")
    w.usage(1, "2026-03-28 09:00", "login", user_ref="ana")
    w.usage(1, "2026-03-28 15:00", "login", user_ref="ben")
    w.usage(1, "2026-03-28 15:05", "feature_use", feature_name="reports", user_ref="ben")
    w.usage(1, "2026-03-28 15:10", "feature_use", feature_name="export", quantity=2, user_ref="cy")
    w.usage(1, "2026-03-10 08:00", "login", user_ref="ana")
    w.usage(1, "2026-03-10 08:30", "key_action", quantity=4, user_ref="ana")
    w.usage(1, "2026-02-15 12:00", "login")
    w.usage(1, "2026-02-15 12:10", "feature_use", feature_name="reports")
    w.invoice(1, "2026-01-01", 200.0, due_at="2026-01-15", paid_at="2026-01-03")
    w.invoice(1, "2026-02-01", 200.0, due_at="2026-02-15", paid_at="2026-02-20")
    w.invoice(1, "2026-03-01", 200.0, due_at="2026-03-15")
    w.payment(1, "2026-01-03", "succeeded")
    w.payment(1, "2026-02-20", "succeeded")
    w.payment(1, "2026-03-16", "failed")
    w.payment(1, "2026-03-20", "failed")
    w.ticket(1, "2025-12-20 09:00", resolved_at="2025-12-21 09:00", body="old question")
    w.ticket(1, "2026-03-01 09:00", resolved_at="2026-03-02 09:00", escalated=True, csat=2.0, body="The export is broken and slow")
    w.ticket(1, "2026-03-20 00:00", body="How do I add a user?")
    w.ticket(1, "2026-03-05 00:00", kind="nps_survey", nps_score=3)
    for ticket, label, score in ((1, "neutral", 0.0), (2, "negative", -0.8), (3, "neutral", 0.05)):  # what the sentiment model said about the three tickets
        w.sentiment(ticket, label, score)
    return w


def test_usage_velocity_and_rfm_values():
    v = vector(_rich_world())
    assert (v["tenure_days"], v["subscription_age_days"], v["is_first_90_days"], v["active_subscriptions"]) == (90, 90, 0, 1)
    assert (v["logins_7d"], v["logins_30d"], v["logins_90d"]) == (3, 4, 5)
    assert (v["active_days_7d"], v["frequency_30d"], v["active_days_90d"]) == (2, 3, 4)
    assert (v["session_minutes_7d"], v["session_minutes_30d"], v["avg_session_minutes_30d"]) == (30, 30, 7.5)
    assert (v["feature_uses_30d"], v["key_actions_30d"], v["distinct_features_30d"], v["distinct_features_90d"]) == (3, 4, 2, 2)
    # velocity: average logins per day in the last 7 days against the last 30 days
    assert v["logins_daily_avg_7d"] == pytest.approx(3 / 7) and v["logins_daily_avg_30d"] == pytest.approx(4 / 30)
    assert v["login_ratio_7d_30d"] == pytest.approx((3 / 7) / (4 / 30)) and v["login_delta_7d_30d_pct"] == pytest.approx((3 / 7) / (4 / 30) - 1)
    assert v["login_delta_30d_prev30d_pct"] == pytest.approx((4 - 1) / 1) and v["active_days_delta_30d_prev30d"] == 2
    # the same comparison for the other core product actions: 3 feature uses and no key action in the last 7 days, 3 and 4 in the last 30
    assert v["feature_use_delta_7d_30d_pct"] == pytest.approx((3 / 7) / (3 / 30) - 1) and v["key_action_delta_7d_30d_pct"] == -1.0
    # DAU: 1 user on 31 March, 3 on 28 March, 1 on 10 March; the events of 15 February name nobody and lie outside the window anyway
    assert v["avg_daily_active_users_30d"] == pytest.approx((1 + 3 + 1) / 30)
    # time to value: subscribed on 1 January, first core workflow completed on 10 March
    assert v["days_to_first_key_action"] == (date(2026, 3, 10) - date(2026, 1, 1)).days == 68
    # RFM
    assert (v["recency_days"], v["frequency_30d"], v["monetary_90d"], v["monetary_lifetime"]) == (1, 3, 400, 400)


def test_daily_active_users_and_time_to_value_are_unknown_rather_than_zero_without_evidence():
    anonymous = base_world()
    anonymous.usage(1, "2026-03-28 09:00", "login")  # telemetry that does not say who was active
    a = vector(anonymous)
    assert np.isnan(a["avg_daily_active_users_30d"]) and a["logins_30d"] == 1, "no user reference: the number of active users is unknown"
    assert np.isnan(a["days_to_first_key_action"]) and np.isnan(a["key_action_delta_7d_30d_pct"]), "no core workflow completed yet"
    quiet = base_world()
    quiet.usage(1, "2026-01-20 09:00", "key_action", user_ref="ana")
    quiet.usage(1, "2026-01-20 10:00", "login", user_ref="ben")
    q = vector(quiet)
    assert q["avg_daily_active_users_30d"] == 0, "users are identified, and none of them was active in the last 30 days"
    assert q["days_to_first_key_action"] == 19
    # the same user on the same day counts once; different days add up; a young subscription is averaged over its own age
    young = base_world()
    young.rows["subscriptions"][0]["started_at"] = young.rows["sub_events"][0]["occurred_at"] = "2026-03-22"
    for stamp, user in (("2026-03-30 09:00", "ana"), ("2026-03-30 17:00", "ana"), ("2026-03-30 17:30", "ben"), ("2026-03-31 08:00", "ana")):
        young.usage(1, stamp, "login", user_ref=user)
    y = vector(young)
    assert y["tenure_days"] == 10 and y["avg_daily_active_users_30d"] == pytest.approx((2 + 1) / 10)
    # a core workflow completed during a trial or before the first paid day counts as value on day 0
    early = base_world()
    early.usage(1, "2025-12-28 09:00", "key_action", user_ref="ana")
    assert vector(early)["days_to_first_key_action"] == 0


def test_inactivity_streaks_match_an_independent_day_by_day_calculation():
    v = vector(_rich_world())
    active = {date(2026, 2, 15), date(2026, 3, 10), date(2026, 3, 28), date(2026, 3, 31)}
    start, streaks, run = date(2026, 1, 1), [], 0
    day = start
    while day < T:
        run = 0 if day in active else run + 1
        streaks.append(run)
        day = date.fromordinal(day.toordinal() + 1)
    last90 = streaks[-90:]
    expected_score = (1 - fe.EW_LAMBDA) * sum(s * fe.EW_LAMBDA ** (len(last90) - 1 - n) for n, s in enumerate(last90))
    assert v["inactivity_streak_days"] == 0 and v["max_inactivity_streak_90d"] == max(last90) == 45
    assert v["ew_inactivity_score"] == pytest.approx(expected_score, rel=1e-12)
    # a customer who goes quiet gets a strictly higher score than one who stays active
    quiet = base_world()
    quiet.usage(1, "2026-02-15 12:00", "login")
    q = vector(quiet)
    # last active on 15 Feb: 44 fully inactive days (16 Feb .. 31 Mar), 45 days between the last active day and T
    assert q["inactivity_streak_days"] == 44 and q["recency_days"] == 45 and q["ew_inactivity_score"] > v["ew_inactivity_score"]
    never = vector(base_world())
    assert never["recency_days"] == 90 and never["inactivity_streak_days"] == 90 and never["logins_30d"] == 0
    assert np.isnan(never["login_ratio_7d_30d"]) and np.isnan(never["avg_session_minutes_30d"]), "ratios without a denominator are missing, not zero"


def test_support_and_billing_values():
    v = vector(_rich_world())
    assert (v["tickets_30d"], v["tickets_90d"], v["open_tickets"], v["escalations_90d"]) == (1, 2, 1, 1)
    assert v["avg_resolution_hours_90d"] == 24 and v["avg_csat_90d"] == 2 and v["last_nps_score"] == 3 and v["days_since_last_ticket"] == 12
    assert v["negative_ticket_share_90d"] == 0.5
    # friction index = (tickets in 90 days / 3) x mean hours a ticket has been open (resolved: 24 h, open: 12 days = 288 h)
    assert v["support_friction_index_90d"] == pytest.approx((2 / 3) * ((24 + 288) / 2))
    assert (v["failed_payments_30d"], v["failed_payments_90d"], v["days_since_last_failed_payment"], v["last_payment_failed"]) == (2, 2, 12, 1)
    assert (v["overdue_invoices"], v["late_payments_180d"], v["avg_days_late_180d"], v["invoices_180d"]) == (1, 1, 2.5, 3)
    assert v["days_to_renewal"] == -1, "last invoice 1 March + 30 days = 31 March, one day before T"
    assert v["days_to_card_expiry"] == 274
    assert (v["mrr"], v["plan_tier"], v["billing_period"], v["seats"], v["discount_pct"]) == (200, "pro", "monthly", 10, 0)
    assert v["max_source_ts"] == pd.Timestamp("2026-03-31 10:00"), "provenance: the newest record that fed the vector"


# ----------------------------------------------------------------------------- the T boundary
def test_a_record_at_exactly_T_is_excluded_and_one_second_earlier_is_included():
    w = base_world()
    w.usage(1, "2026-03-31 23:59:59", "login")
    w.usage(1, "2026-04-01 00:00:00", "login")
    w.usage(1, "2026-04-01 00:00:01", "login")
    w.payment(1, "2026-04-01 00:00:00", "failed")
    w.ticket(1, "2026-04-01 00:00:00", body="broken")
    w.invoice(1, "2026-04-01 00:00:00", 999.0, due_at="2026-04-01", paid_at="2026-04-01")
    v = vector(w)
    assert (v["logins_7d"], v["failed_payments_30d"], v["tickets_30d"], v["invoices_180d"], v["monetary_lifetime"]) == (1, 0, 0, 0, 0)
    assert v["max_source_ts"] == pd.Timestamp("2026-03-31 23:59:59") and v["max_source_ts"] < timeline.ts(T)


def test_facts_that_became_known_after_T_are_hidden():
    w = base_world()
    w.ticket(1, "2026-03-20 00:00", resolved_at="2026-04-03 00:00", escalated=True, csat=1.0, body="it is broken")
    w.invoice(1, "2026-03-01", 200.0, due_at="2026-03-15", paid_at="2026-04-02")
    v = vector(w)
    assert (v["open_tickets"], v["escalations_90d"], v["overdue_invoices"], v["monetary_lifetime"]) == (1, 0, 1, 0)
    assert np.isnan(v["avg_csat_90d"]) and np.isnan(v["avg_resolution_hours_90d"]), "resolution and satisfaction were not known at T"
    assert v["support_friction_index_90d"] == pytest.approx((1 / 3) * 12 * 24), "the ticket is still open at T: open time runs to T, not to its later resolution"
    later = vector(w, date(2026, 5, 1))
    assert (later["open_tickets"], later["escalations_90d"], later["overdue_invoices"], later["monetary_lifetime"]) == (0, 1, 0, 200)


def test_only_customers_subscribed_at_T_get_a_vector():
    w = base_world()
    w.customer(2, acquired_at="2026-01-01")
    w.subscription(2, 2, "2026-01-01")
    w.event(2, "ended", "2026-03-31 12:00", reason="cancellation")  # gone before T
    w.customer(3, acquired_at="2026-04-01")
    w.subscription(3, 3, "2026-04-01 00:00:00")  # starts at T: not yet a subscriber strictly before T
    w.customer(4, acquired_at="2026-01-01")
    w.subscription(4, 4, "2026-01-01")
    w.event(4, "ended", "2026-04-01 00:00:00", reason="cancellation")  # ends at T: still active just before it
    w.customer(5, acquired_at="2026-01-01")  # never subscribed
    out = fe.compute_features(w.frames(), [T])
    assert sorted(out["customer_id"]) == [1, 4]
    assert fe.compute_features(w.frames(), [date(2025, 12, 1)]).empty


# ----------------------------------------------------------------------------- leakage traps
def test_pending_cancellation_comes_only_from_events_before_T():
    assert "cancel_requested_at" not in timeline.FRAME_COLUMNS["subscriptions"][1], "the current-state column is not even loaded"
    none, requested, revoked, future = base_world(), base_world(), base_world(), base_world()
    requested.event(1, "cancel_requested", "2026-03-27")
    revoked.event(1, "cancel_requested", "2026-03-27")
    revoked.event(1, "cancel_revoked", "2026-03-30")
    future.event(1, "cancel_requested", "2026-04-01 00:00:00")
    future.event(1, "ended", "2026-04-20", reason="cancellation")
    assert [vector(w)["pending_cancellation"] for w in (none, requested, revoked, future)] == [0, 1, 0, 0]
    assert vector(future, date(2026, 4, 2))["pending_cancellation"] == 1, "one day later the request is history and may be used"
    # the subscription row may already say "cancelled": it must not reach the feature
    rowstate = base_world(status="cancelled", ended_at="2026-04-20", end_reason="cancellation")
    assert_same(fe.compute_features(rowstate.frames(), [T]), fe.compute_features(none.frames(), [T]))


def test_current_state_columns_never_feed_a_feature():
    loaded = {name: set(columns) for name, (_, columns) in timeline.FRAME_COLUMNS.items()}
    for column in ("cancel_requested_at", "current_period_end", "auto_renew", "closed_at"):
        assert column in fe.FORBIDDEN_SOURCE_COLUMNS and not any(column in cols for cols in loaded.values()), column
    assert set(fe.FORBIDDEN_SOURCE_COLUMNS) - {"cancel_requested_at", "current_period_end", "auto_renew", "closed_at"} == {"status", "ended_at", "end_reason"}
    w = base_world(status="cancelled", ended_at="2026-04-20", end_reason="cancellation")
    w.customer(2, acquired_at="2026-01-01")
    w.subscription(2, 2, "2026-01-01", events=False, status="ended", ended_at="2026-03-01", end_reason="non_renewal")
    cut = fe._truncate(w.frames(), timeline.ts(T))["subscriptions"].set_index("id")
    assert cut["status"].isna().all(), "status is blanked for every row"
    assert pd.isna(cut.loc[1, "ended_at"]) and cut.loc[1, "end_reason"] is None, "an end after T is unknown at T"
    assert cut.loc[2, "ended_at"] == pd.Timestamp("2026-03-01") and cut.loc[2, "end_reason"] == "non_renewal", "an end before T is history"


def test_card_expiry_is_reconstructed_from_recorded_changes():
    w = base_world()
    assert vector(w)["days_to_card_expiry"] == 274
    w.rows["accounts"][0]["payment_method_expires_on"] = "2028-01-31"  # the customer replaced the card on 10 April ...
    w.card_expiry_changed(1, "2026-04-10 09:00", "2026-04-15")  # ... and the platform recorded what it replaced
    assert vector(w)["days_to_card_expiry"] == 14, "at T the old card (expiring 15 April) was on file"
    assert vector(w, date(2026, 5, 1))["days_to_card_expiry"] == 640, "after the change the new card applies"


def test_mrr_and_plan_use_events_and_report_any_fallback_to_the_subscription_row():
    w = base_world()
    w.event(1, "plan_changed", "2026-03-15", mrr=900.0, plan_id=2)
    w.event(1, "plan_changed", "2026-04-10", mrr=5000.0, plan_id=1)  # after T
    w.rows["subscriptions"][0].update(mrr=5000.0, plan_id=1)  # the row shows today's state
    out = fe.compute_features(w.frames(), [date(2026, 3, 1), T, date(2026, 5, 1)]).set_index("as_of_date")
    assert out["mrr"].tolist() == [200, 900, 5000] and out["plan_tier"].tolist() == ["pro", "enterprise", "pro"]
    assert out["plan_changes_90d"].tolist() == [0, 1, 2] and out.attrs["row_fallback"] == {"mrr": 0, "plan_tier": 0, "attributes": 0}
    # a source that sends no MRR / plan on its events: the row value is used and the approximation is counted
    bare = World()
    bare.plan(1, tier="basic")
    bare.customer(1, acquired_at="2026-01-01")
    bare.account(1)
    bare.subscription(1, 1, "2026-01-01", events=False, plan_id=1, mrr=70.0)
    out = fe.compute_features(bare.frames(), [T])
    assert (out["mrr"].iloc[0], out["plan_tier"].iloc[0]) == (70, "basic") and out.attrs["row_fallback"] == {"mrr": 1, "plan_tier": 1, "attributes": 0}


def test_reactivation_trial_and_multi_subscription_state():
    w = base_world(trial_end_at="2026-01-15")
    w.event(1, "trial_converted", "2026-01-15")
    w.event(1, "ended", "2026-02-10", reason="cancellation")
    w.event(1, "reactivated", "2026-03-02", mrr=250.0)
    w.subscription(2, 1, "2026-03-10", plan_id=2, mrr=50.0)
    v = vector(w)
    assert (v["tenure_days"], v["subscription_age_days"], v["prior_churn_count"], v["days_since_reactivation"]) == (90, 30, 1, 30)
    assert (v["active_subscriptions"], v["mrr"], v["plan_tier"], v["had_trial"]) == (2, 300, "pro", 1), "the larger subscription is the primary one"


# ----------------------------------------------------------------------------- the seeded tenant: delete / add / change the future
_SEEDED: dict = {}


@pytest.fixture
def seeded(ro):
    """Frames of the seeded tenant and their features (computed once; both are only read)."""
    if "value" not in _SEEDED:
        with read_session() as s:
            frames = timeline.load_frames(s, ro.tenant_id)
        _SEEDED["value"] = (frames, fe.compute_features(frames, SEEDED_DATES))
    return _SEEDED["value"]


def _world_as_known_at(frames: dict, t0: pd.Timestamp) -> dict:
    """Physically remove everything that happened at or after t0 (independent of the engine's own truncation)."""
    out = {k: v.copy() for k, v in frames.items()}
    for name, column in (("usage", "occurred_at"), ("sub_events", "occurred_at"), ("payments", "attempted_at"), ("support", "opened_at"),
                         ("invoices", "issued_at"), ("subscriptions", "started_at")):  # fmt: skip
        out[name] = out[name][out[name][column] < t0].copy()
    sup, inv, subs = out["support"], out["invoices"], out["subscriptions"]
    late = sup["resolved_at"] >= t0
    sup.loc[late, "resolved_at"], sup.loc[late, "csat"], sup.loc[late, "escalated"] = pd.NaT, np.nan, False
    inv.loc[inv["paid_at"] >= t0, "paid_at"] = pd.NaT
    ended_later = subs["ended_at"] >= t0
    subs.loc[ended_later, "ended_at"], subs.loc[ended_later, "end_reason"] = pd.NaT, None
    subs["status"] = "active"
    return out


def test_removing_everything_at_or_after_T_changes_nothing(seeded):
    frames, full = seeded
    assert len(full) > 400 and full["max_source_ts"].notna().all()
    assert (full["max_source_ts"] < pd.to_datetime(full["as_of_date"])).all()
    for as_of in SEEDED_DATES:
        past_only = fe.compute_features(_world_as_known_at(frames, timeline.ts(as_of)), [as_of])
        assert_same(full[full["as_of_date"] == as_of], past_only)


def _poisoned_future(frames: dict, t0: pd.Timestamp) -> dict:
    """Add and change records at or after t0 as adversarially as possible."""
    out = {k: v.copy() for k, v in frames.items()}
    cust = frames["customers"]["id"].to_numpy()
    subs = frames["subscriptions"]
    stamps = [t0, t0 + pd.Timedelta(seconds=1), t0 + pd.Timedelta(days=9)]
    usage = [pd.DataFrame({"customer_id": cust, "occurred_at": when, "event_type": kind, "feature_name": feature, "duration_seconds": 86000.0, "quantity": 50.0})
             for when in stamps for kind, feature in (("login", None), ("session", None), ("feature_use", "brand_new_feature"), ("key_action", None))]  # fmt: skip
    out["usage"] = pd.concat([frames["usage"], *usage], ignore_index=True)
    next_id = int(frames["sub_events"]["id"].max()) + 1
    events = []
    for when in stamps:
        for kind, reason in (("cancel_requested", None), ("payment_failed", None), ("plan_changed", None), ("ended", "cancellation"), ("reactivated", None),
                             ("trial_converted", None), ("recovered", None)):  # fmt: skip
            part = pd.DataFrame({"id": np.arange(next_id, next_id + len(subs)), "subscription_id": subs["id"].to_numpy(), "customer_id": subs["customer_id"].to_numpy(),
                                 "event_type": kind, "occurred_at": when, "plan_id": frames["plans"]["id"].iloc[0], "mrr": 99999.0, "reason": reason})  # fmt: skip
            next_id += len(subs)
            events.append(part)
    out["sub_events"] = pd.concat([frames["sub_events"], *events], ignore_index=True)
    pay_id = int(frames["payments"]["id"].max()) + 1
    payments = [pd.DataFrame({"id": np.arange(pay_id + n * len(cust), pay_id + (n + 1) * len(cust)), "customer_id": cust, "attempted_at": when, "status": status, "amount": 1e6})
                for n, (when, status) in enumerate(((t0, "failed"), (t0 + pd.Timedelta(hours=1), "succeeded"), (t0 + pd.Timedelta(days=2), "failed")))]  # fmt: skip
    out["payments"] = pd.concat([frames["payments"], *payments], ignore_index=True)
    sup = frames["support"].copy()
    unresolved_at_t0 = (sup["opened_at"] < t0) & (sup["resolved_at"].isna() | (sup["resolved_at"] >= t0))
    sup.loc[unresolved_at_t0, "resolved_at"], sup.loc[unresolved_at_t0, "csat"], sup.loc[unresolved_at_t0, "escalated"] = t0 + pd.Timedelta(minutes=1), 1.0, True
    sup_id = int(sup["id"].max()) + 1
    new_tickets = pd.DataFrame({"id": np.arange(sup_id, sup_id + len(cust)), "customer_id": cust, "kind": "ticket", "opened_at": t0, "resolved_at": pd.NaT,
                                "escalated": True, "csat": 1.0, "nps_score": np.nan, "body": "broken unacceptable cancel refund"})  # fmt: skip
    new_nps = new_tickets.assign(id=new_tickets["id"] + len(cust), kind="nps_survey", nps_score=0.0, opened_at=t0 + pd.Timedelta(days=1))
    out["support"] = pd.concat([sup, new_tickets, new_nps], ignore_index=True)
    inv = frames["invoices"].copy()
    unpaid_at_t0 = (inv["issued_at"] < t0) & (inv["paid_at"].isna() | (inv["paid_at"] >= t0))
    inv.loc[unpaid_at_t0, "paid_at"] = t0
    inv_id = int(inv["id"].max()) + 1
    new_inv = pd.DataFrame({"id": np.arange(inv_id, inv_id + len(cust)), "customer_id": cust, "issued_at": t0, "due_at": t0, "paid_at": t0, "amount": 1e6})
    out["invoices"] = pd.concat([inv, new_inv], ignore_index=True)
    s2 = subs.copy()
    open_at_t0 = s2["ended_at"].isna() | (s2["ended_at"] >= t0)
    s2.loc[open_at_t0, "ended_at"], s2.loc[open_at_t0, "end_reason"] = t0 + pd.Timedelta(days=3), "cancellation"
    s2["status"] = "cancelled"
    sub_id = int(s2["id"].max()) + 1
    new_subs = pd.DataFrame({"id": np.arange(sub_id, sub_id + len(cust)), "customer_id": cust, "plan_id": frames["plans"]["id"].iloc[-1], "status": "active",
                             "billing_period": "annual", "started_at": t0, "trial_end_at": pd.NaT, "ended_at": pd.NaT, "end_reason": None, "mrr": 1e6,
                             "discount_pct": 90.0, "quantity": 999.0})  # fmt: skip
    out["subscriptions"] = pd.concat([s2, new_subs], ignore_index=True)
    return out


def test_adding_or_changing_records_at_or_after_T_changes_nothing(seeded):
    frames, full = seeded
    for as_of in SEEDED_DATES:
        poisoned = _poisoned_future(frames, timeline.ts(as_of))
        assert len(poisoned["usage"]) > len(frames["usage"]) and len(poisoned["sub_events"]) > len(frames["sub_events"])
        assert_same(full[full["as_of_date"] == as_of], fe.compute_features(poisoned, [as_of]))
    # the same poison placed one second BEFORE T does change the result, so the check above is not vacuous
    as_of = SEEDED_DATES[1]
    shifted = _poisoned_future(frames, timeline.ts(as_of) - pd.Timedelta(seconds=1))
    moved = fe.compute_features(shifted, [as_of])
    reference = full[full["as_of_date"] == as_of]
    common = sorted(set(moved["customer_id"]) & set(reference["customer_id"]))
    assert common, "some customers are active in both versions"
    differing = changed_features(reference[reference["customer_id"].isin(common)], moved[moved["customer_id"].isin(common)])
    assert {"logins_7d", "failed_payments_30d", "pending_cancellation", "mrr"} <= differing


def test_only_declared_snapshot_features_depend_on_current_row_values(seeded):
    frames, full = seeded
    assert full.attrs["row_fallback"] == {"mrr": 0, "plan_tier": 0, "attributes": 0}, "the seeded source carries MRR and plan on its events, and every customer has attribute history"
    changed = {k: v.copy() for k, v in frames.items()}
    cust, subs, acc = changed["customers"], changed["subscriptions"], changed["accounts"]
    cust["employee_count"] = cust["employee_count"].fillna(0) + 1000
    for column in ("industry", "company_size", "region", "acquisition_channel"):
        cust[column] = "changed-later"
    subs["quantity"], subs["discount_pct"] = subs["quantity"].fillna(0) + 5, 99.0
    subs["billing_period"] = np.where(subs["billing_period"] == "annual", "monthly", "annual")
    subs["mrr"], subs["plan_id"], subs["status"] = subs["mrr"] * 3 + 1, subs["plan_id"].iloc[::-1].to_numpy(), "cancelled"
    acc["payment_method_expires_on"] = acc["payment_method_expires_on"] + pd.Timedelta(days=100)
    assert changed_features(full, fe.compute_features(changed, SEEDED_DATES)) == SNAPSHOT


# ----------------------------------------------------------------------------- the feature store
def test_offline_store_equals_a_recomputation_and_online_store_serves_the_latest_date(ro):
    with read_session() as s:
        contract = s.get(FeatureContract, ro.summary["contract_id"])
        features.require_usable(contract)
        stored = features.offline_frame(s, ro.tenant_id, contract)
        newest_ts = s.execute(select(func.max(FeatureVector.max_source_ts)).where(FeatureVector.tenant_id == ro.tenant_id)).scalar_one()
        violations = s.execute(select(func.count()).select_from(FeatureVector).where(FeatureVector.max_source_ts >= func.datetime(FeatureVector.as_of_date))).scalar_one()
        frames = timeline.load_frames(s, ro.tenant_id)
        run = s.execute(select(FeatureRun).where(FeatureRun.tenant_id == ro.tenant_id, FeatureRun.status == "completed").order_by(FeatureRun.id).limit(1)).scalar_one()
        online = s.execute(select(OnlineFeature).where(OnlineFeature.tenant_id == ro.tenant_id)).scalars().all()
        status = features.store_status(s, ro.tenant_id)
    assert violations == 0 and newest_ts is not None
    assert list(stored.columns) == ["customer_id", "as_of_date", *contract.features] and len(contract.features) == 84
    dates = sorted(stored["as_of_date"].unique())
    again = fe.compute_features(frames, dates)[["customer_id", "as_of_date", *contract.features]]
    key = ["as_of_date", "customer_id"]
    a, b = (x.sort_values(key).reset_index(drop=True) for x in (stored, again))
    assert a[key].equals(b[key]), "same customers on the same dates"
    for name in contract.features:
        if fe.SPECS[name].dtype == "category":
            assert (a[name].fillna("∅") == b[name].fillna("∅")).all(), name
        else:
            np.testing.assert_allclose(a[name].to_numpy(dtype=float), b[name].to_numpy(dtype=float), rtol=1e-9, atol=1e-9, equal_nan=True, err_msg=name)
    assert run.stats["row_fallback"] == {"mrr": 0, "plan_tier": 0, "attributes": 0} and run.stats["features"] == 84 and sum(run.stats["rows_by_date"].values()) == run.row_count
    latest = max(dates)
    assert {o.as_of_date for o in online} == {max(o.as_of_date for o in online)} and len(online) > 100
    assert max(o.as_of_date for o in online) >= latest, "the online store holds the most recent vectors"
    assert status["online"] and status["offline"]
    with read_session() as s:
        one = features.online_vector(s, ro.tenant_id, contract.id, online[0].customer_id)
    assert one["values"] == online[0].values and set(one["values"]) == set(contract.features)


@pytest.mark.req("REQ-GOV-01")
def test_contracts_are_reviewed_versioned_and_bound_to_the_feature_logic(empty, monkeypatch):
    tid = empty.tenant()
    author, reviewer = empty.user(tid, "admin"), empty.user(tid, "approver")
    with session_scope() as s:
        full = features.create_contract(s, author)
        strict = features.create_contract(s, author, name="event_time_only", exclude_snapshot=True)
        assert (full.version, full.status, len(full.features)) == (1, "pending", 84)
        assert not SNAPSHOT & set(strict.features) and len(strict.features) == 84 - len(SNAPSHOT)
        assert features.create_contract(s, author, features=["mrr", "tenure_days"]).version == 2
        assert len(features.catalog_view(s)) == 84 and {c["pit_class"] for c in features.catalog_view(s)} == {"event_time", "snapshot", "history"}
        with pytest.raises(Conflict) as not_approved:
            features.require_usable(full)
        assert not_approved.value.code == "contract_not_approved"
        with pytest.raises(Forbidden):
            features.review_contract(s, author, full.id, approve=True)
        features.review_contract(s, reviewer, full.id, approve=True)
        features.require_usable(full)
        for bad, message in (({"features": ["mrr", "made_up"]}, "unknown features"), ({"features": ["mrr"]}, "at least two"), ({"features": ["mrr", "mrr"]}, "at least two"),
                             ({"name": " "}, "name is required")):  # fmt: skip
            with pytest.raises(ValidationFailed, match=message):
                features.create_contract(s, author, **bad)
        # if the feature code changes, an approved contract stops being usable until a new version is approved
        monkeypatch.setattr(fe, "engine_hash", lambda: "0" * 64)
        with pytest.raises(Conflict) as stale:
            features.require_usable(full)
        assert stale.value.code == "contract_stale" and features.contract_view(full)["logic_current"] is False
