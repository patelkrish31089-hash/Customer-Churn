"""Schema migrations: upgrade, drift against the ORM models, downgrade, on SQLite and PostgreSQL."""

from __future__ import annotations

import sqlite3

import pytest
from sqlalchemy import create_engine, inspect, text

from churn_platform import dbadmin
from churn_platform.db import Base, get_engine, session_scope
from tests.conftest import activate

pytestmark = pytest.mark.req("REQ-OPS-01")


def reset_postgres(url: str) -> None:
    engine = create_engine(url)
    try:
        with engine.begin() as conn:
            conn.execute(text("DROP SCHEMA public CASCADE"))
            conn.execute(text("CREATE SCHEMA public"))
    finally:
        engine.dispose()


def _cycle() -> None:
    assert dbadmin.status() == {"current": None, "head": dbadmin.head_revision(), "up_to_date": False}
    dbadmin.upgrade()
    assert dbadmin.status()["up_to_date"] is True
    assert dbadmin.schema_drift() == [], "the migrated schema must equal the ORM models"
    tables = set(inspect(get_engine()).get_table_names())
    assert tables == set(Base.metadata.tables) | {"alembic_version"}
    dbadmin.upgrade()  # idempotent
    dbadmin.downgrade("base")
    from churn_platform.db import dispose_engine

    dispose_engine()
    assert set(inspect(get_engine()).get_table_names()) == {"alembic_version"}
    dbadmin.upgrade()
    assert dbadmin.schema_drift() == []


def test_sqlite_upgrade_drift_downgrade_cycle(tmp_path):
    activate(tmp_path / "fresh.db", tmp_path / "data")
    _cycle()


def test_sqlite_connections_enforce_foreign_keys_and_wal(empty):
    with get_engine().connect() as conn:
        assert conn.execute(text("PRAGMA foreign_keys")).scalar_one() == 1
        assert conn.execute(text("PRAGMA journal_mode")).scalar_one() == "wal"
    with pytest.raises(Exception, match="FOREIGN KEY"), session_scope() as s:
        s.execute(text("INSERT INTO users (tenant_id, email, full_name, role, is_active, mfa_enabled, failed_logins, created_at) "
                       "VALUES (424242, 'x@example.com', 'X', 'viewer', 1, 0, 0, '2026-01-01 00:00:00')"))  # fmt: skip


def test_database_constraints_reject_invalid_states(empty):
    tid = empty.tenant()
    con = sqlite3.connect(empty.db_path)
    try:
        con.execute("PRAGMA foreign_keys=ON")
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("INSERT INTO jobs (tenant_id, job_type, payload, status, priority, attempts, max_attempts, run_after, progress, cancel_requested, created_at) "
                        "VALUES (?, 'x', '{}', 'exploded', 0, 0, 3, '2026-01-01', 0, 0, '2026-01-01')", (tid,))  # fmt: skip
        with pytest.raises(sqlite3.IntegrityError):
            con.execute("INSERT INTO tenants (slug, name, is_system, created_at) VALUES ('acme', 'Duplicate slug', 0, '2026-01-01')")
    finally:
        con.close()


@pytest.mark.postgres
def test_postgresql_upgrade_drift_downgrade_cycle(postgres_url, tmp_path):
    reset_postgres(postgres_url)
    activate(postgres_url, tmp_path / "data")
    try:
        _cycle()
        with get_engine().connect() as conn:
            kinds = dict(conn.execute(text("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'invoices'")).all())
        assert kinds["amount"] == "numeric" and kinds["issued_at"] == "timestamp with time zone"
    finally:
        from churn_platform.db import dispose_engine

        dispose_engine()
        reset_postgres(postgres_url)
