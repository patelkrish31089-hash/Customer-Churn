"""The web application in a real browser, against a real server."""

from __future__ import annotations

import json
import re
import sqlite3
import time

import httpx2
import pytest

from churn_platform import security
from tests.conftest import PASSWORD
from tests.e2e.conftest import API, PHONE, ROLES, email_of

pytestmark = [pytest.mark.e2e, pytest.mark.runtime]

SIGNALS = ["Support sentiment", "Feature adoption", "Active users & identity", "Attribute history"]
OUTBOUND = ["Campaigns", "Messages", "CRM sync", "Syncs & exports", "Destination exports"]
EVERYTHING = ["Overview", "Sources & imports", "Data quality", "Churn labels", "Feature store", "Analytics", *SIGNALS, "Training", "Registry", "Predictions", "Customers",
              "Recommendations", "Experiments & uplift", *OUTBOUND, "Monitoring", "Jobs & pipeline", "Orchestration", "Policies", "Security", "Administration"]  # fmt: skip
NO_SECURITY = [label for label in EVERYTHING if label != "Security"]  # only the administrator configures single sign-on and limits
NAVIGATION = {
    "admin": EVERYTHING, "approver": NO_SECURITY, "auditor": NO_SECURITY,
    "data_engineer": NO_SECURITY[:-1], "data_scientist": NO_SECURITY[:-1], "analyst": NO_SECURITY[:-1], "viewer": NO_SECURITY[:-1],
    "csm": ["Overview", "Analytics", *SIGNALS, "Predictions", "Customers", "Recommendations", "Experiments & uplift", *OUTBOUND, "Jobs & pipeline", "Orchestration",
            "Policies"],
}  # fmt: skip
# Gridlines are evenly spaced, so the numbers printed next to them must be too: "10%, 8%, 5%, 3%, 0%" is a 2.5-point grid
# whose labels were rounded, and a bar ending at the "8%" line would really be 7.5%.
AXIS_CHECK = """() => {
  const uneven = [];
  for (const svg of document.querySelectorAll('#content svg.chart')) {
    const labels = [...svg.querySelectorAll('text[text-anchor=end]')].filter((t) => !t.getAttribute('class')).map((t) => t.textContent.trim());
    if (labels.length < 3 || !labels.every((t) => /^-?[0-9,]+([.][0-9]+)?[%k]?$/.test(t))) continue;
    const values = labels.map((t) => Number(t.replace(/[,%k]/g, '')));
    const steps = values.slice(1).map((v, i) => v - values[i]);
    const scale = Math.max(...values.map(Math.abs)) || 1;
    if (steps.some((d) => Math.abs(d - steps[0]) > 1e-9 * scale) || steps[0] === 0) uneven.push((svg.getAttribute('aria-label') || 'chart') + ': ' + labels.join(' '));
  }
  return uneven;
}"""
BROKEN = ("Could not load this.", "Not permitted.", "This page could not be shown", "Page not found")


def _check_screen(tab, where: str) -> None:
    content = tab.content
    assert content.locator("h1").count() == 1, f"{where}: exactly one page heading"
    text = content.inner_text()
    for marker in BROKEN:
        assert marker not in text, f"{where}: the screen shows '{marker}'\n{text[:600]}"
    assert "undefined" not in text and "NaN" not in text and "[object Object]" not in text, f"{where}: unformatted value on screen\n{text[:1500]}"
    assert tab.page.title().endswith("· Churn Platform") and tab.page.title() != "· Churn Platform"
    assert tab.overflow() == 0, f"{where}: the page scrolls sideways by {tab.overflow()}px"
    uneven = tab.page.evaluate(AXIS_CHECK)
    assert uneven == [], f"{where}: axis labels that do not sit where they say (rounded onto a neighbour): {uneven}"


@pytest.mark.req("REQ-SEC-02")
@pytest.mark.parametrize("role", ROLES)
def test_every_screen_a_role_can_reach_loads_cleanly(open_tab, site, role):
    """Each role signs in, walks its whole navigation, opens every tab and the detail screens: no screen is broken, no request
    is refused (a role is never shown something it then may not load), nothing is logged to the console."""
    tab = open_tab(role)
    links = tab.page.locator("nav.nav a").all_inner_texts()
    assert links == NAVIGATION[role], f"navigation offered to {role}"
    visited = 0
    for label in links:
        tab.nav(label)
        assert tab.page.locator("nav.nav a[aria-current=page]").inner_text() == label
        _check_screen(tab, f"{role}: {label}")
        tab.shot(f"{role}-{label}")
        visited += 1
        tabs = tab.content.locator("[role=tab]")
        for index in range(tabs.count()):
            name = tabs.nth(index).inner_text()
            tabs.nth(index).click()
            tab.settle()
            assert tabs.nth(index).get_attribute("aria-selected") == "true"
            _check_screen(tab, f"{role}: {label} / {name}")
            if index:
                tab.shot(f"{role}-{label}-{name}")
            visited += 1
    # detail screens
    permissions = site.permissions(role)
    customer_id = site.get("admin", "/customers", page_size=1, sort="risk")["items"][0]["id"]
    details = [("account", True), (f"customers/{customer_id}", "customers:read" in permissions), (f"predictions/{site.summary['batch_id']}", "predict:read" in permissions),
               ("models/run/4", "ml:read" in permissions), (f"experiments/{site.summary['experiment']['experiment_id']}", "retention:read" in permissions)]  # fmt: skip
    for route, allowed in details:
        if not allowed:
            continue
        tab.go(route)
        _check_screen(tab, f"{role}: #{route}")
        tab.shot(f"{role}-detail-{route}")
        visited += 1
        tabs = tab.content.locator("[role=tab]")
        for index in range(1, tabs.count()):
            tabs.nth(index).click()
            tab.settle()
            _check_screen(tab, f"{role}: #{route} / {tabs.nth(index).inner_text()}")
            visited += 1
    assert visited >= (24 if role == "csm" else 44), visited
    assert tab.problems == [], f"{role}: {tab.problems}"


# ----------------------------------------------------------------------------- signing in and out
@pytest.mark.req("REQ-SEC-01")
def test_sign_in_errors_lockout_reload_sign_out_and_a_session_ended_elsewhere(open_tab, site):
    tab = open_tab()
    page = tab.page
    page.goto("/")
    alert = page.locator(".login [role=alert]")
    sign_in = page.get_by_role("button", name="Sign in")
    assert page.title() == "Sign in · Churn Platform" and page.evaluate("() => document.activeElement.id") == "login-email"
    assert alert.is_hidden()
    # nothing typed, or no real address: the browser points at the field and the server is not asked
    sign_in.click()
    page.fill("#login-email", "not-an-address")
    page.fill("#login-password", "x")
    sign_in.click()
    assert page.evaluate("() => [...document.querySelectorAll('.login form input:invalid')].map((i) => i.id)") == ["login-email"]
    assert not [r for r in tab.requests if "/auth/login" in r] and alert.is_hidden()
    # wrong password and unknown address get the same answer; the password field is emptied
    page.fill("#login-email", email_of("viewer"))
    page.fill("#login-password", "not-the-password")
    page.keyboard.press("Enter")
    alert.filter(has_text="Invalid email or password").wait_for()
    assert page.input_value("#login-password") == "" and page.evaluate("() => document.activeElement.id") == "login-password"
    page.fill("#login-email", "nobody@demo.example")
    page.fill("#login-password", "not-the-password")
    sign_in.click()
    tab.settle()
    assert alert.inner_text() == "Invalid email or password"
    tab.expected(*[f"401 POST {API}/auth/login"] * 2)
    assert page.locator(".shell").count() == 0
    # five wrong passwords lock the account; the right password is then refused too, with the reason
    page.fill("#login-email", email_of("locked_out"))
    for _ in range(5):
        page.fill("#login-password", "wrong-again")
        sign_in.click()
        tab.settle()
        assert alert.inner_text() == "Invalid email or password"
    page.fill("#login-password", PASSWORD)
    sign_in.click()
    tab.settle()
    assert alert.inner_text() == "Account is temporarily locked after repeated failed sign-ins"
    tab.expected(*[f"401 POST {API}/auth/login"] * 6)
    # the right credentials: signed in, and still signed in after a reload
    page.fill("#login-email", "  " + email_of("viewer").upper() + " ")  # stray blanks and capitals do not matter
    page.fill("#login-password", PASSWORD)
    sign_in.click()
    page.wait_for_selector(".shell")
    tab.settle()
    assert tab.heading() == "Overview" and "Vera Viewer" in page.locator(".user-chip").inner_text()
    page.reload()
    page.wait_for_selector(".shell")
    tab.settle()
    assert tab.heading() == "Overview"
    # a second tab does not inherit the session (it lives in this tab only)
    other = tab.context.new_page()
    other.goto("/")
    other.wait_for_selector(".login")
    other.close()
    # signing out returns to the form, ends the session on the server and leaves nothing behind in the tab
    token = page.evaluate("() => window.sessionStorage.getItem('churn.session')")
    assert token
    page.get_by_role("button", name="Sign out").click()
    page.wait_for_selector(".login")
    assert page.evaluate("() => window.sessionStorage.getItem('churn.session')") is None and page.locator(".shell").count() == 0
    assert httpx2.get(f"{site.base}{API}/auth/me", headers={"Authorization": "Bearer " + token}).status_code == 401
    page.go_back()
    assert page.locator(".shell").count() == 0, "the back button shows nothing of the ended session"
    # a session ended elsewhere (an administrator revoked it, or it expired): the next click leads back to the form with the reason
    tab.sign_in("viewer")
    token = page.evaluate("() => window.sessionStorage.getItem('churn.session')")
    assert httpx2.post(f"{site.base}{API}/auth/logout", headers={"Authorization": "Bearer " + token}).status_code in (200, 204)
    page.locator("nav.nav").get_by_role("link", name="Customers", exact=True).click()
    page.wait_for_selector(".login")
    assert page.locator(".login [role=alert]").inner_text() == "Your session has ended. Sign in again."
    tab.settle()
    left = [p for p in tab.problems if not p.startswith("401 GET ")]
    assert left == [], left
    tab.problems.clear()


@pytest.mark.req("REQ-SEC-01")
def test_two_factor_sign_in_is_set_up_on_the_account_screen_and_then_required(open_tab, site):
    tab = open_tab("two_factor")
    page = tab.page
    page.locator(".user-chip a.who").click()
    tab.settle()
    assert tab.heading() == "My account"
    card = tab.content.locator("section.card", has_text="Two-factor sign-in")
    assert "off" in card.inner_text()
    card.get_by_role("button", name="Set up").click()
    dialog = tab.dialog()
    secret = dialog.locator("#f-secret").input_value()
    assert len(secret) >= 32
    # a wrong code is refused inside the dialog
    dialog.locator("#f-code").fill("000000")
    dialog.get_by_role("button", name="Confirm").click()
    dialog.locator("[role=alert]").filter(has_text="The one-time code is not valid").wait_for()
    tab.expected(f"422 POST {API}/auth/mfa/confirm")
    dialog.locator("#f-code").fill(security.totp_code(secret))
    dialog.get_by_role("button", name="Confirm").click()
    tab.wait_toast("Two-factor sign-in is on")
    tab.settle()
    assert "on" in tab.content.locator("section.card", has_text="Two-factor sign-in").inner_text()
    assert tab.content.get_by_role("button", name="Turn off").is_visible()
    page.get_by_role("button", name="Sign out").click()
    page.wait_for_selector(".login")
    # the password alone is no longer enough; the form keeps it and asks for the code
    page.fill("#login-email", email_of("two_factor"))
    page.fill("#login-password", PASSWORD)
    page.get_by_role("button", name="Sign in").click()
    alert = page.locator(".login [role=alert]")
    alert.filter(has_text="Enter the 6-digit code from your authenticator app.").wait_for()
    assert page.input_value("#login-password") == PASSWORD and page.evaluate("() => document.activeElement.id") == "login-otp"
    page.fill("#login-otp", "000000")
    page.keyboard.press("Enter")
    alert.filter(has_text="Invalid email or password").wait_for()
    tab.expected(*[f"401 POST {API}/auth/login"] * 2)
    # the code of the next 30-second step (the one used for the set-up cannot be replayed)
    page.fill("#login-password", PASSWORD)
    page.fill("#login-otp", security.totp_code(secret, at=time.time() + 30))
    page.keyboard.press("Enter")
    page.wait_for_selector(".shell")
    tab.settle()
    assert tab.heading() == "Overview"


def _audit_actions(site, prefix: str) -> list[dict]:
    return site.get("admin", "/admin/audit", action=prefix, page_size=100)["items"]


def _rows(site, sql: str, *args) -> list[tuple]:
    """Read the server's database directly (to verify what a screen did, independently of the API it used)."""
    con = sqlite3.connect(f"file:{site.db}?mode=ro", uri=True)
    try:
        return con.execute(sql, args).fetchall()
    finally:
        con.close()


# ----------------------------------------------------------------------------- quarantine review
@pytest.mark.req("REQ-DATA-02", "REQ-SEC-02")
def test_quarantined_rows_are_corrected_reprocessed_and_rejected_on_screen(open_tab, site):
    assert _rows(site, "SELECT count(*) FROM payments WHERE external_id = 'P0000001'") == [(0,)]
    tab = open_tab("approver")
    tab.nav("Sources & imports")
    tab.content.get_by_role("tab", name="Quarantine (15)").click()
    tab.settle()
    assert tab.content.locator("table.data tbody tr").count() == 15
    # 1. a payment whose status was garbled at the source
    row = tab.row("P0000001")
    assert "is not one of succeeded, failed, refunded" in row.inner_text()
    row.get_by_role("button", name="Fix & reprocess").click()
    dialog = tab.dialog()
    box = dialog.locator("#f-corrected")
    original = box.input_value()
    assert json.loads(original)["status"] == "pending??" and "is not one of succeeded, failed, refunded" in dialog.inner_text()
    box.fill(original.rstrip().rstrip("}"))  # a typing slip in the JSON is caught before anything is sent
    dialog.get_by_role("button", name="Save and reprocess").click()
    assert dialog.locator("[role=alert]").inner_text() == "The JSON is not valid. Check brackets, quotes and commas." and dialog.is_visible()
    box.fill(original.replace("pending??", "succeeded"))
    dialog.locator("#f-note").fill("status confirmed with billing")
    dialog.get_by_role("button", name="Save and reprocess").click()
    tab.wait_toast("Row corrected and loaded")
    tab.settle()
    assert tab.dialog().count() == 0 and tab.content.locator("table.data tbody tr", has_text="P0000001").count() == 0, "the row left the open list"
    assert _rows(site, "SELECT status, amount FROM payments WHERE external_id = 'P0000001'") == [("succeeded", 149)], "the corrected payment is loaded"
    # 2. a correction that does not help: the row stays, with the reason
    row = tab.row("GHOST0")
    row.get_by_role("button", name="Fix & reprocess").click()
    tab.dialog().get_by_role("button", name="Save and reprocess").click()
    tab.wait_toast("The corrected row still fails validation")
    tab.settle()
    assert "unknown customer reference 'GHOST0'" in tab.row("GHOST0").inner_text()
    # 3. a row that cannot be repaired is rejected, with a reason; cancelling the dialog changes nothing
    tab.row("GHOST1").get_by_role("button", name="Reject").click()
    tab.dialog().get_by_role("button", name="Cancel").click()
    assert tab.dialog().count() == 0 and tab.row("GHOST1").is_visible()
    tab.row("GHOST1").get_by_role("button", name="Reject").click()
    tab.dialog().locator("#f-note").fill("test account, never a customer")
    tab.dialog().get_by_role("button", name="Reject row").click()
    tab.settle()
    assert tab.content.locator("table.data tbody tr", has_text="GHOST1").count() == 0 and tab.content.locator("table.data tbody tr").count() == 13
    status = tab.content.get_by_label("Status")
    status.select_option("rejected")
    tab.settle()
    assert tab.content.locator("table.data tbody tr").count() == 1 and tab.row("GHOST1").get_by_role("button").count() == 0, "a rejected row offers no further action"
    status.select_option("reprocessed")
    tab.settle()
    assert tab.content.locator("table.data tbody tr").count() == 1 and "P0000001" in tab.content.locator("table.data tbody tr").inner_text()
    # the tab's counter follows after a reload of the screen
    tab.nav("Data quality")
    tab.nav("Sources & imports")
    assert tab.content.get_by_role("tab", name="Quarantine (13)").is_visible()
    # on record: who decided what
    by_action = {e["action"]: e for e in _audit_actions(site, "quarantine.")}
    assert {"quarantine.reprocess", "quarantine.reject"} <= set(by_action), sorted(by_action)
    assert all(e["actor_label"] == "approver@demo.example" for e in by_action.values())
    # a role without the review permission sees the same rows and no buttons
    viewer = open_tab("viewer")
    viewer.nav("Sources & imports")
    viewer.content.get_by_role("tab", name="Quarantine (13)").click()
    viewer.settle()
    assert viewer.content.locator("table.data tbody tr").count() == 13 and viewer.content.locator("table.data tbody button").count() == 0


# ----------------------------------------------------------------------------- retention work queue
def _external_id(row) -> str:
    return row.locator("td").first.locator(".sub").inner_text()


@pytest.mark.req("REQ-ACT-01", "REQ-ACT-02", "REQ-GOV-01")
def test_recommendations_are_approved_carried_out_and_withdrawn_on_screen(open_tab, site):
    csm = open_tab("csm")
    csm.nav("Recommendations")
    assert "Work queue for the scores of 2026-11-01." in csm.content.inner_text()
    segment = csm.content.get_by_label("Segment")
    rows = csm.content.locator("table.data tbody tr")
    # white-glove actions for high-value accounts wait for an approver: the success manager can dismiss, not approve
    segment.select_option("high_risk_high_value")
    csm.settle()
    calls = site.summary["recommendations"]["high_risk_high_value"]["proposed"]
    assert rows.count() == calls >= 2
    for index in range(calls):
        assert "awaits an approver" in rows.nth(index).inner_text() and "needs human review" in rows.nth(index).inner_text()
        assert rows.nth(index).get_by_role("button").all_inner_texts() == ["Dismiss"]
    # a payment reminder needs no second person: approve it
    segment.select_option("involuntary")
    csm.settle()
    assert rows.first.get_by_role("button").all_inner_texts() == ["Approve", "Dismiss"]
    first, second = _external_id(rows.nth(0)), _external_id(rows.nth(1))
    csm_customer_name = rows.nth(0).locator("td").first.inner_text().split("\n")[0].strip()
    csm.row(first).get_by_role("button", name="Approve").click()
    csm.wait_toast("Recommendation approved")
    csm.settle()
    csm.row(second).get_by_role("button", name="Approve").click()
    csm.settle()
    csm.content.get_by_label("Status").select_option("approved")
    csm.settle()
    assert sorted(_external_id(rows.nth(i)) for i in range(rows.count())) == sorted([first, second])
    assert csm.row(first).get_by_role("button").all_inner_texts() == ["Carry out", "Withdraw"]
    # the details of a recommendation open from its row
    csm.row(first).locator("td").nth(1).click()
    detail = csm.dialog()
    assert "Why the model scores this customer as it does" in detail.inner_text() and "Payment-method update reminder" in detail.inner_text()
    detail.get_by_role("button", name="Close").click()
    # carry out: handed to the CRM connection (test-only: recorded, nothing leaves the platform)
    csm.row(first).get_by_role("button", name="Carry out").click()
    dialog = csm.dialog()
    assert "The platform never contacts customers itself" in dialog.inner_text()
    options = dialog.locator("#f-connection_id option").all_inner_texts()
    assert options == ["No CRM: record for manual follow-up", "HubSpot (TEST_ONLY demo) (test only, nothing is sent)"]
    dialog.locator("#f-connection_id").select_option(label=options[1])
    dialog.get_by_role("button", name="Carry out").click()
    csm.wait_toast("Intervention recorded and queued for the CRM")
    csm.settle()
    # withdraw the other one, with a reason
    csm.content.get_by_label("Status").select_option("approved")
    csm.settle()
    assert [_external_id(rows.nth(i)) for i in range(rows.count())] == [second]
    csm.row(second).get_by_role("button", name="Withdraw").click()
    csm.dialog().locator("#f-note").fill("customer already updated the card")
    csm.dialog().get_by_role("button", name="Withdraw").click()
    csm.settle()
    csm.content.get_by_label("Status").select_option("dismissed")
    csm.settle()
    assert [_external_id(rows.nth(i)) for i in range(rows.count())] == [second]
    assert csm.row(second).get_by_role("button").count() == 0
    # the action taken is listed; its outcome can be recorded
    csm.content.get_by_role("tab", name="Actions taken & outcomes").click()
    csm.settle()
    assert rows.count() == 1 and "not recorded" in rows.first.inner_text() and "payment method reminder" in rows.first.inner_text()
    assert rows.first.get_by_role("link").inner_text() == csm_customer_name
    rows.first.get_by_role("button", name="Record outcome").click()
    csm.dialog().locator("#f-outcome").select_option("retained")
    csm.dialog().get_by_role("button", name="Save").click()
    csm.settle()
    assert "retained" in rows.first.inner_text() and "not recorded" not in rows.first.inner_text()
    # in the database: one intervention, one test-only CRM delivery for that customer (never sent)
    customer_id = _rows(site, "SELECT id FROM customers WHERE external_id = ?", first)[0][0]
    assert _rows(site, "SELECT outcome, status FROM interventions WHERE customer_id = ?", customer_id)[0][0] == "retained"

    def delivery():
        found = _rows(site, "SELECT status, sent_at FROM crm_deliveries WHERE customer_id = ? AND kind != 'risk_score'", customer_id)
        return found if found and found[0][0] not in ("pending", "queued") else None

    deadline = time.monotonic() + 30
    while delivery() is None and time.monotonic() < deadline:
        time.sleep(0.2)
    assert delivery() == [("skipped", None)], "a test-only connection records the delivery and sends nothing"

    # the approver decides on the white-glove actions and cannot carry anything out
    approver = open_tab("approver")
    approver.nav("Recommendations")
    approver.content.get_by_label("Segment").select_option("high_risk_high_value")
    approver.settle()
    a_rows = approver.content.locator("table.data tbody tr")
    assert a_rows.first.get_by_role("button").all_inner_texts() == ["Approve", "Dismiss"]
    vip = _external_id(a_rows.first)
    approver.row(vip).get_by_role("button", name="Approve").click()
    approver.wait_toast("Recommendation approved")
    approver.settle()
    approver.content.get_by_label("Status").select_option("approved")
    approver.settle()
    assert approver.row(vip).get_by_role("button").all_inner_texts() == ["Withdraw"]
    # ... the success manager now can
    csm.nav("Overview")
    csm.nav("Recommendations")
    csm.content.get_by_label("Status").select_option("approved")
    csm.settle()
    assert csm.row(vip).get_by_role("button").all_inner_texts() == ["Carry out", "Withdraw"]
    # a reader sees the queue without any button
    viewer = open_tab("viewer")
    viewer.nav("Recommendations")
    assert viewer.content.locator("table.data tbody tr").count() == 25 and viewer.content.locator("table.data tbody button").count() == 0
    assert viewer.content.get_by_role("button", name="Regenerate from latest scores").count() == 0
    actions = {e["action"] for e in _audit_actions(site, "retention.")}
    assert {"retention.recommendation_approved", "retention.recommendation_dismissed", "retention.recommendation_executed"} <= actions, actions


# ----------------------------------------------------------------------------- policies: author, approver, self-approval
def _policy_card(tab, title: str):
    return tab.content.locator("section.card").filter(has=tab.page.locator("h2", has_text=title))


@pytest.mark.req("REQ-GOV-01")
def test_a_policy_version_is_drafted_submitted_and_approved_by_a_second_person_on_screen(open_tab, site):
    author = open_tab("data_scientist")
    author.nav("Policies")
    card = _policy_card(author, "Alert rules")
    assert card.locator("table.data tbody tr").count() == 1 and "approved" in card.locator("table.data tbody tr").inner_text()
    card.get_by_role("button", name="New version").click()
    dialog = author.dialog()
    box = dialog.locator("#f-payload")
    in_force = json.loads(box.input_value())
    assert in_force, "the dialog starts from the rules in force"
    # rules the server refuses are explained inside the dialog; nothing is saved
    box.fill("{}")
    dialog.get_by_role("button", name="Save draft").click()
    refusal = dialog.locator("[role=alert]")
    refusal.filter(has_text=re.compile(r"\w")).wait_for()
    assert dialog.is_visible() and len(refusal.inner_text()) > 20
    author.expected(f"422 POST {API}/policies")
    box.fill(json.dumps(in_force, indent=2))
    dialog.locator("#f-note").fill("reviewed for Q4, thresholds unchanged")
    dialog.get_by_role("button", name="Save draft").click()
    author.wait_toast("Draft saved")
    author.settle()
    draft = _policy_card(author, "Alert rules").locator("table.data tbody tr", has_text="default v2")
    assert "draft" in draft.inner_text() and "reviewed for Q4" in draft.inner_text()
    assert draft.get_by_role("button").all_inner_texts() == ["Submit for approval", "View"]
    draft.get_by_role("button", name="Submit for approval").click()
    author.wait_toast("Submitted for approval")
    author.settle()
    pending = _policy_card(author, "Alert rules").locator("table.data tbody tr", has_text="default v2")
    assert "pending" in pending.inner_text() and pending.get_by_role("button").all_inner_texts() == ["View"], "the author cannot approve"
    version_id = _rows(site, "SELECT id FROM policies WHERE kind = 'alert_rules' AND version = 2")[0][0]
    # the approver puts it in force
    approver = open_tab("approver")
    approver.nav("Policies")
    row = _policy_card(approver, "Alert rules").locator("table.data tbody tr", has_text="default v2")
    assert row.get_by_role("button").all_inner_texts() == ["Approve", "Reject", "View"]
    assert _policy_card(approver, "Alert rules").get_by_role("button", name="New version").count() == 0, "approvers do not author"
    row.get_by_role("button", name="Approve").click()
    approver.wait_toast("Policy approved and in force")
    approver.settle()
    rows = _policy_card(approver, "Alert rules").locator("table.data tbody tr")
    assert "approved" in rows.filter(has_text="default v2").inner_text() and "approved" not in rows.filter(has_text="default v1").inner_text()
    assert _rows(site, "SELECT status FROM policies WHERE id = ?", version_id) == [("approved",)]
    # an administrator holds both permissions and still cannot approve a version of their own
    admin = open_tab("admin")
    admin.nav("Policies")
    _policy_card(admin, "Alert rules").get_by_role("button", name="New version").click()
    admin.dialog().locator("#f-note").fill("administrator's own change")
    admin.dialog().get_by_role("button", name="Save draft").click()
    admin.wait_toast("Draft saved")
    admin.settle()
    own = _policy_card(admin, "Alert rules").locator("table.data tbody tr", has_text="default v3")
    own.get_by_role("button", name="Submit for approval").click()
    admin.wait_toast("Submitted for approval")
    admin.settle()
    own = _policy_card(admin, "Alert rules").locator("table.data tbody tr", has_text="default v3")
    own.get_by_role("button", name="Approve").click()
    refused = admin.page.locator(".toasts .toast.error").first
    refused.wait_for()
    assert "own" in refused.inner_text().lower() or "author" in refused.inner_text().lower(), refused.inner_text()
    own_id = _rows(site, "SELECT id FROM policies WHERE kind = 'alert_rules' AND version = 3")[0][0]
    admin.expected(f"403 POST {API}/policies/{own_id}/review")
    assert _rows(site, "SELECT status FROM policies WHERE id = ?", own_id) == [("pending",)]
    # the approver turns it down; version 2 stays in force
    approver.nav("Overview")
    approver.nav("Policies")
    _policy_card(approver, "Alert rules").locator("table.data tbody tr", has_text="default v3").get_by_role("button", name="Reject").click()
    approver.settle()
    assert "rejected" in _policy_card(approver, "Alert rules").locator("table.data tbody tr", has_text="default v3").inner_text()
    assert _rows(site, "SELECT version, status FROM policies WHERE kind = 'alert_rules' ORDER BY version") == [(1, "retired"), (2, "approved"), (3, "rejected")]


# ----------------------------------------------------------------------------- export, forbidden and unknown addresses
@pytest.mark.req("REQ-SEC-02", "REQ-SEC-03")
def test_the_score_export_is_offered_only_to_roles_that_may_export_and_is_audited(open_tab, site, tmp_path):
    batch = site.summary["batch_id"]
    before = len(_audit_actions(site, "predictions.exported"))
    analyst = open_tab("analyst")
    analyst.go(f"predictions/{batch}")
    assert analyst.heading() == "Scores for 2026-11-01"
    with analyst.page.expect_download() as download:
        analyst.content.get_by_role("button", name="Download CSV").click()
    assert download.value.suggested_filename == "churn-scores-2026-11-01.csv"
    target = tmp_path / "scores.csv"
    download.value.save_as(target)
    lines = target.read_text().splitlines()
    assert len(lines) == 1 + 212 and lines[0] == "user_id,customer_name,as_of_date,churn_probability,risk_tier,risk_decile,top_reason_1,top_reason_2,top_reason_3,model_version_id"
    assert re.fullmatch(r"C\d{6}", lines[1].split(",")[0]) and lines[1].split(",")[2] == "2026-11-01"
    exported = _audit_actions(site, "predictions.exported")
    assert len(exported) == before + 1 and exported[0]["actor_label"] == "analyst@demo.example" and exported[0]["detail"]["rows"] == 212
    assert analyst.content.get_by_role("button", name="Generate recommendations").count() == 0
    for role, buttons in (("viewer", []), ("csm", ["Generate recommendations"])):
        other = open_tab(role)
        other.go(f"predictions/{batch}")
        assert other.heading() == "Scores for 2026-11-01"
        assert other.content.locator("header.page-head button").all_inner_texts() == buttons, role


@pytest.mark.req("REQ-SEC-02")
def test_an_address_typed_by_hand_is_refused_or_reported_not_found_without_breaking_the_application(open_tab, site):
    tab = open_tab("csm")
    tab.go("models")  # not in this role's navigation
    text = tab.content.inner_text()
    assert "Not permitted." in text and tab.content.locator("table").count() == 0
    assert tab.problems and all(p.startswith("403 GET ") for p in tab.problems), tab.problems
    tab.problems.clear()
    tab.go("no/such/screen")
    assert tab.heading() == "Page not found"
    tab.content.get_by_role("link", name="Back to the overview").click()
    tab.settle()
    assert tab.heading() == "Overview"
    tab.go("customers/99999999")  # a customer that does not exist (or belongs to someone else)
    assert "Could not load this." in tab.content.inner_text() or "not found" in tab.content.inner_text().lower()
    tab.expected(f"404 GET {API}/customers/99999999")
    tab.nav("Customers")
    assert tab.heading() == "Customers" and tab.content.locator("table.data tbody tr").count() == 25, "the application carries on"


# ----------------------------------------------------------------------------- background jobs from the screen
@pytest.mark.req("REQ-OPS-02", "REQ-OPS-04")
def test_jobs_started_from_the_screen_run_on_the_worker_and_report_back(open_tab, site):
    tab = open_tab("admin")
    jobs_before = _rows(site, "SELECT count(*) FROM jobs")[0][0]
    tab.nav("Data quality")
    tab.content.get_by_role("button", name="Run checks now").click()
    tab.page.locator(".toasts .toast.success").first.wait_for(timeout=60_000)
    tab.settle()
    assert _rows(site, "SELECT count(*) FROM jobs")[0][0] == jobs_before + 1
    assert _rows(site, "SELECT status FROM jobs ORDER BY id DESC LIMIT 1") == [("succeeded",)]
    # the nightly pipeline, started by hand: seven steps, followed on the Jobs screen
    # (the seeded dry-run campaign keeps one job queued for its next step, three days ahead; it is not part of this)
    tab.nav("Jobs & pipeline")
    tab.content.get_by_role("button", name="Run pipeline now").click()
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        done = _rows(site, "SELECT count(*) FROM audit_events WHERE action = 'pipeline.completed'")[0][0]
        if done and not _rows(site, "SELECT count(*) FROM jobs WHERE status IN ('queued', 'running') AND job_type <> 'campaign.tick'")[0][0]:
            break
        tab.page.wait_for_timeout(300)
    tab.settle()
    assert _rows(site, "SELECT count(*) FROM jobs WHERE status NOT IN ('succeeded') AND job_type <> 'campaign.tick'") == [(0,)]
    tab.nav("Overview")
    tab.nav("Jobs & pipeline")
    steps = tab.content.locator("ol.steps li").all_inner_texts()
    assert [" ".join(step.split()) for step in steps] == [
        "Data quality checks succeeded", "Refresh customer signals succeeded", "Refresh labels succeeded", "Compute features succeeded",
        "Score customers skipped: already up to date",
        "Recommend actions succeeded", "Monitor drift succeeded"], steps  # fmt: skip
    assert "Last run: job #" in tab.content.inner_text() and ", succeeded, finished" in tab.content.inner_text()
    # the "jobs running" pill is refreshed every five seconds, so it may outlive the last job by one refresh
    tab.page.locator(".jobs-pill").wait_for(state="hidden", timeout=15_000)


# ----------------------------------------------------------------------------- phone
@pytest.mark.req("REQ-OPS-06")
def test_the_application_is_usable_on_a_phone(open_tab, site):
    tab = open_tab(viewport=PHONE, mobile=True)
    page = tab.page
    page.goto("/")
    page.wait_for_selector(".login")
    assert page.locator(".login-art").is_hidden() and page.locator(".login-form").is_visible() and tab.overflow() == 0
    tab.shot("phone-login")
    tab.sign_in("csm")
    sidebar, menu = page.locator(".sidebar"), page.get_by_role("button", name="Navigation")
    assert menu.is_visible() and menu.get_attribute("aria-expanded") == "false"
    assert sidebar.is_hidden(), "the navigation drawer is closed (and out of the tab order)"
    assert tab.overflow() == 0
    tab.shot("phone-overview")
    # open the drawer, choose a screen: the drawer closes
    menu.click()
    page.wait_for_function("() => document.querySelector('.sidebar').getBoundingClientRect().left === 0")
    assert sidebar.is_visible() and menu.get_attribute("aria-expanded") == "true"
    tab.shot("phone-menu")
    sidebar.get_by_role("link", name="Customers", exact=True).click()
    tab.settle()
    page.wait_for_function("() => getComputedStyle(document.querySelector('.sidebar')).visibility === 'hidden'")
    assert tab.heading() == "Customers" and menu.get_attribute("aria-expanded") == "false" and tab.overflow() == 0
    # Escape and a tap outside close it too
    menu.click()
    page.keyboard.press("Escape")
    page.wait_for_function("() => getComputedStyle(document.querySelector('.sidebar')).visibility === 'hidden'")
    menu.click()
    page.wait_for_function("() => document.querySelector('.sidebar').getBoundingClientRect().left === 0")
    page.touchscreen.tap(360, 500)
    page.wait_for_function("() => getComputedStyle(document.querySelector('.sidebar')).visibility === 'hidden'")
    assert tab.heading() == "Customers", "the tap that closes the drawer does not also press what was underneath"
    # wide tables scroll inside their own frame, the page itself never scrolls sideways
    wrap = tab.content.locator(".table-wrap").first
    assert wrap.evaluate("el => el.scrollWidth >= el.clientWidth") and tab.overflow() == 0
    tab.shot("phone-customers")
    tab.content.locator("table.data tbody tr").first.click()
    tab.settle()
    assert re.fullmatch(r"#/customers/\d+", page.evaluate("() => window.location.hash")) and tab.overflow() == 0
    assert tab.content.locator("svg.chart").count() >= 1
    tab.shot("phone-customer-360")
    for label in ("Recommendations", "Predictions", "Analytics", "Experiments & uplift", "CRM sync", "Jobs & pipeline", "Policies", "Overview"):
        menu.click()
        sidebar.get_by_role("link", name=label, exact=True).click()
        tab.settle()
        assert tab.overflow() == 0, f"{label} scrolls sideways on a phone by {tab.overflow()}px"
        if label == "Recommendations":
            page.wait_for_function("() => getComputedStyle(document.querySelector('.sidebar')).visibility === 'hidden'")
            tab.shot("phone-recommendations")
            # a dialog fits the screen
            tab.content.locator("table.data tbody tr").first.locator("td").first.click()
            box = tab.dialog().bounding_box()
            assert box and box["x"] >= 0 and box["x"] + box["width"] <= PHONE["width"] and box["height"] <= PHONE["height"], box
            tab.shot("phone-dialog", full_page=False)
            tab.dialog().get_by_role("button", name="Close").click()
    # the account screen is reachable (the name is hidden on a phone, the initials are the link)
    page.get_by_role("link", name="My account").click()
    tab.settle()
    assert tab.heading() == "My account" and tab.overflow() == 0
    page.get_by_role("button", name="Sign out").click()
    page.wait_for_selector(".login")


# ----------------------------------------------------------------------------- monitoring without a usable batch
@pytest.mark.req("REQ-OPS-03")
def test_the_monitoring_screen_explains_a_comparison_that_could_not_be_made(open_tab, site):
    """Reports made before the model has scored a batch hold no figures.  The "Input drift" tab answered them with
    "Could not load this", and a fresh default demo opened in exactly that state."""
    tab = open_tab("admin")
    con = sqlite3.connect(site.db, timeout=30)
    completed = [row[0] for row in con.execute("SELECT id FROM prediction_batches WHERE status = 'completed'")]
    assert len(completed) >= 2
    change = "UPDATE prediction_batches SET status = ? WHERE id = ?"
    newest = "SELECT kind, status FROM drift_reports ORDER BY id DESC LIMIT 3"
    measured = _rows(site, newest)
    assert all(status != "insufficient_data" for _kind, status in measured), measured
    try:
        con.executemany(change, [("failed", batch_id) for batch_id in completed])  # as if nothing had been scored yet
        con.commit()
        tab.nav("Monitoring")
        tab.content.get_by_role("button", name="Run monitoring now").click()
        tab.content.locator(".kpis", has_text="too few rows to compare").wait_for(timeout=60_000)
        tab.settle()
        kpis = " ".join(tab.content.locator(".kpis").inner_text().split())
        assert "Input drift insufficient data too few rows to compare" in kpis and "Score drift insufficient data too few scores to compare" in kpis, kpis
        assert {status for _kind, status in _rows(site, newest)} == {"insufficient_data"}
        seen = {}
        tabs = tab.content.locator("[role=tab]")
        for index in range(tabs.count()):
            name = tabs.nth(index).inner_text()
            tabs.nth(index).click()
            tab.settle()
            _check_screen(tab, f"monitoring before the first batch / {name}")
            tab.shot(f"monitoring-before-first-batch-{name}")
            seen[name] = " ".join(tab.content.locator("[role=tabpanel]").inner_text().split())
        assert list(seen) == ["Realised performance", "Input drift", "Score drift", "History"]
        assert "This model version has not scored a batch yet." in seen["Realised performance"]
        assert seen["Input drift"] == ("Not enough data to compare. This model version has not scored a batch yet. "
                                       "Input drift could not be measured: at least 30 rows are needed on each side.")  # fmt: skip
        assert seen["Score drift"] == ("Not enough data to compare. This model version has not scored a batch yet. "
                                       "Score drift could not be measured: a completed batch with at least 30 scored customers is needed.")  # fmt: skip
    finally:
        con.executemany(change, [("completed", batch_id) for batch_id in completed])
        con.commit()
        con.close()
    # with the batches back, the next run measures again and says where the feature values came from
    tab.content.get_by_role("button", name="Run monitoring now").click()
    tab.content.locator(".kpis", has_text="features moved").wait_for(timeout=60_000)
    tab.settle()
    tab.content.get_by_role("tab", name="Input drift").click()
    tab.settle()
    _check_screen(tab, "monitoring / Input drift")
    panel = " ".join(tab.content.locator("[role=tabpanel]").inner_text().split())
    assert "982 training rows vs 212 customers in the latest batch (2026-11-01); feature values: offline feature store" in panel, panel[:600]
    assert _rows(site, newest) == measured, "the same three verdicts as before the batches were hidden"
    assert tab.problems == [], tab.problems
