"""Browser tests: a real server process (with its embedded worker), a real Chromium, the seeded demo tenant.

Every tab opened through ``open_tab`` records what a user would never see but a developer must: console errors,
uncaught exceptions, failed requests and every HTTP answer of 400 or above.  A test that expects such an answer
(a wrong password, a refused self-approval) takes it off the list explicitly; whatever is left fails the test.
The server's own log is checked the same way when the server stops.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx2
import pytest

from tests.conftest import PASSWORD, require_or_skip

API = "/api/v1"
DESKTOP = {"width": 1440, "height": 900}
PHONE = {"width": 390, "height": 844}
ROLES = ("admin", "approver", "data_engineer", "data_scientist", "analyst", "csm", "auditor", "viewer")
EXTRA_USERS = {"data_engineer": "data.engineer@demo.example", "auditor": "auditor@demo.example", "locked_out": "locked.out@demo.example",
               "two_factor": "two.factor@demo.example"}  # fmt: skip


def email_of(role: str) -> str:
    return EXTRA_USERS.get(role, f"{role.replace('_', '.')}@demo.example")


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@dataclass
class Site:
    """The running application under test."""

    base: str
    db: Path
    data: Path
    log: Path
    summary: dict
    _tokens: dict[str, str] = field(default_factory=dict)

    def token(self, role: str) -> str:
        if role not in self._tokens:
            answer = httpx2.post(f"{self.base}{API}/auth/login", json={"email": email_of(role), "password": PASSWORD}, timeout=30)
            assert answer.status_code == 200, answer.text
            self._tokens[role] = answer.json()["token"]
        return self._tokens[role]

    def get(self, role: str, path: str, **params: Any) -> Any:
        """Read through the API as ``role`` (to look up ids and to verify what a screen did)."""
        answer = httpx2.get(f"{self.base}{API}{path}", params=params or None, headers={"Authorization": "Bearer " + self.token(role)}, timeout=30)
        assert answer.status_code == 200, f"GET {path} as {role}: {answer.status_code} {answer.text[:300]}"
        return answer.json()

    def permissions(self, role: str) -> set[str]:
        return set(self.get(role, "/auth/me")["permissions"])


@pytest.fixture(scope="module")
def site(template, tmp_path_factory: pytest.TempPathFactory) -> Iterator[Site]:
    root = tmp_path_factory.mktemp("site")
    db, data, log = root / "site.db", root / "data", root / "server.log"
    shutil.copyfile(template.demo_db, db)
    shutil.copytree(template.demo_data, data)
    env = {k: v for k, v in os.environ.items() if not k.startswith("CHURN_")}
    env.update({"CHURN_ENV": "test", "CHURN_LOG_LEVEL": "INFO", "CHURN_SECRET_KEY": os.environ["CHURN_SECRET_KEY"], "CHURN_DATABASE_URL": f"sqlite:///{db}",
                "CHURN_DATA_DIR": str(data), "CHURN_EMBEDDED_WORKER": "true", "CHURN_WORKER_POLL_SECONDS": "0.2",
                # all browser sessions come from one address within seconds; the limiter itself is tested in test_security.py
                "CHURN_RATE_LIMIT_LOGIN_PER_MINUTE": "100000", "CHURN_RATE_LIMIT_LOGIN_ACCOUNT_PER_MINUTE": "100000",
                "CHURN_RATE_LIMIT_IP_PER_MINUTE": "100000", "CHURN_RATE_LIMIT_API_PER_MINUTE": "100000", "CHURN_SENTIMENT_PROVIDER": "lexicon_baseline",
                "E2E_PW": PASSWORD})  # fmt: skip
    for role, email in EXTRA_USERS.items():  # roles the demo seed does not create, and accounts to lock out and to enrol in two-factor sign-in
        made = subprocess.run([sys.executable, "-m", "churn_platform", "create-user", "--tenant", "demo", "--email", email, "--name", role.replace("_", " ").title(),
                               "--role", role if role in ROLES else "viewer", "--password-env", "E2E_PW"], env=env, capture_output=True, text=True, check=False)  # fmt: skip
        assert made.returncode == 0, made.stderr
    port = _free_port()
    with log.open("w") as sink:
        # CHURN_TEST_SERVE_WORKERS=N runs the same screens against N server processes: anything a screen needs that one
        # process keeps to itself then shows up as a failure
        workers = int(os.environ.get("CHURN_TEST_SERVE_WORKERS", "1"))
        command = [sys.executable, "-m", "churn_platform", "serve", "--port", str(port), *(["--workers", str(workers)] if workers > 1 else [])]
        process = subprocess.Popen(command, env=env, stdout=sink, stderr=sink, stdin=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{port}"
    try:
        deadline = time.monotonic() + 60
        while True:
            try:
                if httpx2.get(f"{base}/readyz", timeout=5).status_code == 200:
                    break
            except httpx2.HTTPError:
                pass
            assert process.poll() is None, f"the server exited during start-up:\n{log.read_text()[-3000:]}"
            assert time.monotonic() < deadline, f"the server did not become ready:\n{log.read_text()[-3000:]}"
            time.sleep(0.2)
        yield Site(base, db, data, log, template.summary)
    finally:
        process.send_signal(signal.SIGTERM)
        try:
            code = process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            code = process.wait()
    assert code == 0, f"the server exits cleanly (exit {code})\n{log.read_text()[-3000:]}"
    # what the server logged while the screens were used: nothing at error level, nothing that is not a JSON record
    records, stray = [], []
    for line in log.read_text().splitlines():
        if line.strip():
            try:
                records.append(json.loads(line))
            except ValueError:
                stray.append(line)
    assert stray == [], f"unstructured output on the server log: {stray[:10]}"
    errors = [r for r in records if r.get("level") in ("ERROR", "CRITICAL")]
    assert errors == [], f"the server logged errors while the screens were used: {json.dumps(errors[:5], indent=1)[:4000]}"


@pytest.fixture(scope="session")
def browser() -> Iterator[Any]:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        require_or_skip(False, "the playwright package is not installed (pip install -e '.[dev]')")
    manager = sync_playwright().start()
    try:
        chromium = manager.chromium.launch()
    except Exception as exc:
        manager.stop()
        require_or_skip(False, f"Chromium for Playwright is not available ({str(exc).splitlines()[0]}); run: playwright install chromium")
    try:
        yield chromium
    finally:
        chromium.close()
        manager.stop()


class Tab:
    """One browser tab plus everything it reported."""

    def __init__(self, browser: Any, site: Site, *, viewport: dict | None = None, mobile: bool = False) -> None:
        self.site = site
        self.context = browser.new_context(base_url=site.base, viewport=viewport or DESKTOP, is_mobile=mobile, has_touch=mobile, accept_downloads=True)
        self.context.set_default_timeout(20_000)
        self.page = self.context.new_page()
        self.problems: list[str] = []
        self.requests: list[str] = []
        self._inflight = 0
        self.page.on("console", self._on_console)
        self.page.on("pageerror", lambda exc: self.problems.append(f"uncaught exception: {exc}"))
        self.page.on("request", self._on_request)
        self.page.on("requestfinished", self._on_done)
        self.page.on("requestfailed", self._on_failed)
        self.page.on("response", self._on_response)

    # ---- collectors
    def _path(self, url: str) -> str:
        return url.removeprefix(self.site.base)

    def _on_console(self, message: Any) -> None:
        if message.type in ("error", "warning") and "Failed to load resource" not in message.text:  # those are recorded with their status below
            self.problems.append(f"console {message.type}: {message.text}")

    def _on_request(self, request: Any) -> None:
        self._inflight += 1
        self.requests.append(f"{request.method} {self._path(request.url)}")

    def _on_done(self, _request: Any) -> None:
        self._inflight -= 1

    def _on_failed(self, request: Any) -> None:
        self._inflight -= 1
        if "ERR_ABORTED" not in (request.failure or ""):  # a reload abandons what was in flight
            self.problems.append(f"request failed: {request.method} {self._path(request.url)} ({request.failure})")

    def _on_response(self, response: Any) -> None:
        if response.status >= 400:
            self.problems.append(f"{response.status} {response.request.method} {self._path(response.url)}")

    def expected(self, *problems: str) -> None:
        """Take answers the test provoked on purpose off the list (each must have happened)."""
        for problem in problems:
            assert problem in self.problems, f"expected {problem!r}; the page reported {self.problems}"
            self.problems.remove(problem)

    # ---- driving
    def settle(self, timeout: float = 30.0) -> None:
        """Wait until the page is at rest: nothing loading, no request in flight (twice in a row)."""
        deadline = time.monotonic() + timeout
        calm = 0
        while calm < 2:
            busy = self._inflight > 0 or self.page.locator(".loading").count() > 0
            calm = 0 if busy else calm + 1
            assert time.monotonic() < deadline, f"the page did not come to rest within {timeout}s ({self._inflight} request(s) in flight)"
            self.page.wait_for_timeout(40)

    def sign_in(self, role: str, password: str = PASSWORD) -> Tab:
        self.page.goto("/")
        self.page.fill("#login-email", email_of(role))
        self.page.fill("#login-password", password)
        self.page.get_by_role("button", name="Sign in").click()
        self.page.wait_for_selector(".shell")
        self.settle()
        return self

    def go(self, route: str) -> None:
        self.page.evaluate("route => { window.location.hash = '#/' + route; }", route)
        self.page.wait_for_function("route => window.location.hash === '#/' + route", arg=route)
        self.settle()

    def nav(self, label: str) -> None:
        self.page.locator("nav.nav").get_by_role("link", name=label, exact=True).click()
        self.settle()

    @property
    def content(self) -> Any:
        return self.page.locator("#content")

    def heading(self) -> str:
        return self.content.locator("h1").first.inner_text()

    def toasts(self) -> list[str]:
        return self.page.locator(".toasts .toast").all_inner_texts()

    def wait_toast(self, text: str) -> None:
        self.page.locator(".toasts .toast", has_text=text).first.wait_for()

    def row(self, text: str | re.Pattern) -> Any:
        return self.content.locator("table.data tbody tr", has_text=text).first

    def dialog(self) -> Any:
        return self.page.locator("dialog[open]")

    def overflow(self) -> int:
        """Pixels by which the document is wider than the window (0 = no sideways scrolling)."""
        return self.page.evaluate("() => Math.max(0, document.documentElement.scrollWidth - document.documentElement.clientWidth)")

    def shot(self, name: str, *, full_page: bool = True) -> None:
        """Keep a picture for review when CHURN_TEST_SCREENSHOT_DIR is set (dialogs: ``full_page=False``, they belong to the window)."""
        folder = os.environ.get("CHURN_TEST_SCREENSHOT_DIR")
        if folder:
            Path(folder).mkdir(parents=True, exist_ok=True)
            self.page.screenshot(path=str(Path(folder) / (re.sub(r"[^A-Za-z0-9_.-]+", "-", name) + ".png")), full_page=full_page)

    def close(self) -> None:
        self.context.close()


@pytest.fixture
def open_tab(browser: Any, site: Site) -> Iterator[Callable[..., Tab]]:
    tabs: list[Tab] = []

    def make(role: str | None = None, **options: Any) -> Tab:
        tab = Tab(browser, site, **options)
        tabs.append(tab)
        return tab.sign_in(role) if role else tab

    yield make
    left = [problem for tab in tabs for problem in tab.problems]
    for tab in tabs:
        tab.close()
    assert left == [], f"the browser reported problems the test did not expect: {left}"
