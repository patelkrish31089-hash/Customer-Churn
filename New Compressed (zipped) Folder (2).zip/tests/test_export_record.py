"""The canonical prediction record: one description of a prediction for every destination (1.3.0).

These tests are about the rules a record has to satisfy before anything leaves the platform, not about a particular
destination.  The interesting cases are the ones a destination cannot check for itself: a model that is not approved,
a timestamp with no zone, a probability that arrived as a string, and three reasons that are actually two.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from types import SimpleNamespace

import pytest

from churn_platform.errors import ValidationFailed
from churn_platform.services import export_record as record

pytestmark = pytest.mark.req("REQ-ACT-02")

GOOD = {
    "tenant_id": 1,
    "customer_id": 7,
    "account_id": "acc-7",
    "external_customer_id": "C000007",
    "crm_contact_id": None,
    "churn_probability": 0.8123456,
    "risk_tier": "high",
    "risk_decile": 1,
    "prediction_horizon_days": 30,
    "prediction_timestamp": datetime(2026, 11, 1, 6, 30, tzinfo=UTC),
    "data_cutoff_timestamp": datetime(2026, 10, 31, tzinfo=UTC),
    "model_name": "churn-gbm",
    "model_version": "4",
    "feature_version": "contract-3",
    "model_checksum": "a" * 64,
    "top_reason_1": "No login for 21 days",
    "top_reason_2": None,
    "top_reason_3": None,
    "recommended_intervention": "Success call within 48 hours",
    "approval_status": "approved",
}


def _broken(**changes):
    bad = dict(GOOD)
    bad.update(changes)
    for key, value in changes.items():
        if value is KeyError:
            bad.pop(key, None)
    return bad


# --------------------------------------------------------------------------- the schema itself
def test_the_schema_is_the_nineteen_named_fields_in_a_fixed_order_with_a_version():
    """Nineteen named fields plus the approval status.  ``tenant_id`` leads because it is part of every identity."""
    assert len(record.FIELDS) == 20 and len(record.FIELD_NAMES) == 20
    assert record.FIELD_NAMES[0] == "tenant_id" and record.FIELD_NAMES[-1] == "approval_status"
    described = record.describe()
    assert described["schema_version"] == record.SCHEMA_VERSION
    assert [field["name"] for field in described["fields"]] == list(record.FIELD_NAMES)
    assert set(described["required"]) | set(described["optional"]) == set(record.FIELD_NAMES)
    assert described["enumerations"]["approval_status"] == ["pending", "approved", "rejected"]
    assert "approval_status" in record.explain()


def test_a_valid_record_passes_and_is_not_otherwise_touched():
    assert record.validate(GOOD) == []
    normalised = record.ensure_valid(GOOD)
    assert normalised["churn_probability"] == 0.812346 and isinstance(normalised["churn_probability"], float)
    assert normalised["prediction_timestamp"].tzinfo is UTC
    assert normalised["top_reason_2"] is None


# --------------------------------------------------------------------------- what is refused
@pytest.mark.parametrize(
    "changes, expected",
    [
        ({"customer_id": KeyError}, "customer_id is missing"),
        ({"customer_id": "7"}, "customer_id must be an integer"),
        ({"churn_probability": "0.81"}, "churn_probability must be a number, not str"),
        ({"churn_probability": 1.4}, "churn_probability must be between 0 and 1"),
        ({"risk_decile": 0}, "risk_decile must be between 1 and 10"),
        ({"risk_tier": "urgent"}, "risk_tier must be one of high, medium, low"),
        ({"prediction_horizon_days": 0}, "prediction_horizon_days must be positive"),
        ({"prediction_timestamp": datetime(2026, 11, 1, 6, 30)}, "must carry a UTC offset"),
        ({"prediction_timestamp": date(2026, 11, 1)}, "prediction_timestamp must be a datetime"),
        ({"model_checksum": "abc"}, "model_checksum must be the 64 hexadecimal characters"),
        ({"approval_status": "pending"}, "may not be exported"),
        ({"approval_status": "blessed"}, "approval_status must be one of pending, approved, rejected"),
        ({"top_reason_1": ""}, "top_reason_1 must not be blank"),
        ({"model_name": None}, "model_name is required and was null"),
        ({"surprise": 1}, "surprise is not part of schema"),
    ],
)
def test_each_way_a_record_can_be_wrong_is_named(changes, expected):
    problems = record.validate(_broken(**changes))
    assert any(expected in problem for problem in problems), problems


def test_a_record_from_a_model_that_is_not_approved_never_reaches_a_destination():
    with pytest.raises(ValidationFailed) as refused:
        record.ensure_valid(_broken(approval_status="pending"))
    assert refused.value.code == "validation_failed"
    assert "may not be exported" in refused.value.message
    assert refused.value.details["problems"] and refused.value.details["schema_version"] == record.SCHEMA_VERSION


def test_every_problem_is_reported_at_once_so_a_caller_fixes_them_together():
    problems = record.validate(_broken(churn_probability=2.0, risk_decile=44, risk_tier="nope"))
    assert len(problems) >= 3


def test_an_internal_column_the_caller_keeps_is_not_an_exported_field():
    """``_prediction_id`` and its like are the caller's bookkeeping; they are ignored, not exported and not refused."""
    assert record.validate(_broken(_prediction_id=99)) == []
    assert "_prediction_id" not in record.as_row(_broken(_prediction_id=99))


# --------------------------------------------------------------------------- the bytes and the checksum
def test_the_checksum_is_stable_over_the_same_records_and_changes_with_any_of_them():
    first = record.checksum([GOOD])
    assert first == record.checksum([dict(reversed(list(GOOD.items())))])  # key order is not content
    assert first != record.checksum([_broken(churn_probability=0.812347)])
    assert len(first) == 64 and int(first, 16) >= 0


def test_the_checksum_is_order_sensitive_because_a_destination_stores_an_order():
    other = _broken(customer_id=8, external_customer_id="C000008")
    assert record.checksum([GOOD, other]) != record.checksum([other, GOOD])


def test_the_row_is_json_safe_with_offset_bearing_timestamps():
    row = record.as_row(GOOD)
    assert row["prediction_timestamp"] == "2026-11-01T06:30:00+00:00"
    assert row["data_cutoff_timestamp"] == "2026-10-31T00:00:00+00:00"
    assert row["churn_probability"] == 0.812346
    assert row["top_reason_1"] == "No login for 21 days" and row["top_reason_2"] is None


def test_a_line_is_the_row_compact_and_in_schema_order():
    import json

    lines = record.canonical_lines([GOOD])
    assert len(lines) == 1
    assert lines[0] == json.dumps(record.as_row(GOOD), ensure_ascii=False, separators=(",", ":"))
    assert lines[0].startswith('{"tenant_id":1,"customer_id":7,"account_id":"acc-7"'), "keys follow the schema's order, not the dict's"
    assert '": ' not in lines[0] and '", "' not in lines[0], "no separator padding: the bytes are the checksum's input"


# --------------------------------------------------------------------------- from the stored rows
def _prediction(**overrides):
    base = {"id": 11, "tenant_id": 1, "customer_id": 7, "probability": 0.8123456, "risk_tier": "high", "risk_decile": 1, "horizon_days": 30,
                "as_of_date": date(2026, 10, 31), "created_at": datetime(2026, 11, 1, 6, 30),  # naive on purpose: SQLite-like
                "top_reasons": [{"text": "No login for 21 days"}, {"text": "Open ticket for 3 days"}]}
    base.update(overrides)
    return SimpleNamespace(**base)


def test_a_record_built_from_the_stored_rows_carries_the_three_reasons_padded_with_null():
    built = record.from_prediction(_prediction(), SimpleNamespace(id=7, external_id="C000007"),
                                   SimpleNamespace(name="churn-gbm", version=4, approval_status="approved"),
                                   feature_version="contract-3", model_checksum="a" * 64,
                                   recommended_intervention="Success call", account_id="acc-7")
    assert built["top_reason_1"] == "No login for 21 days" and built["top_reason_3"] is None
    assert built["model_version"] == "4" and built["model_name"] == "churn-gbm"
    assert built["prediction_timestamp"].tzinfo is UTC, "a naive stored timestamp is read as UTC, and says so"
    assert built["data_cutoff_timestamp"] == datetime(2026, 10, 31, tzinfo=UTC)
    assert built["crm_contact_id"] is None


def test_blank_and_missing_reasons_become_null_rather_than_empty_strings():
    reasons = record.reasons_from(SimpleNamespace(top_reasons=[{"text": "  "}, {"text": "Second"}, "Third", None]))
    assert reasons == ["Second", "Third", None]


def test_building_from_an_unapproved_model_fails_before_the_record_exists():
    with pytest.raises(ValidationFailed) as refused:
        record.from_prediction(_prediction(), SimpleNamespace(id=7, external_id="C000007"),
                               SimpleNamespace(name="churn-gbm", version=4, approval_status="pending"),
                               feature_version="contract-3", model_checksum="a" * 64)
    assert refused.value.details["approval_status"] == "pending"


def test_a_rejected_model_is_refused_the_same_way_as_a_pending_one():
    for approval in ("pending", "rejected"):
        with pytest.raises(ValidationFailed):
            record.from_prediction(_prediction(), SimpleNamespace(id=7, external_id="C000007"),
                                   SimpleNamespace(name="churn-gbm", version=4, approval_status=approval),
                                   feature_version="contract-3", model_checksum="a" * 64)


def test_a_stored_probability_outside_the_range_is_refused_although_the_column_should_prevent_it():
    with pytest.raises(ValidationFailed):
        record.from_prediction(_prediction(probability=1.2), SimpleNamespace(id=7, external_id="C000007"),
                               SimpleNamespace(name="churn-gbm", version=4, approval_status="approved"),
                               feature_version="contract-3", model_checksum="a" * 64)


def test_the_described_schema_matches_what_a_record_must_contain():
    """The documentation and the validator are one fact: every required field is refused when absent."""
    for name in record.REQUIRED_FIELDS:
        with pytest.raises(ValidationFailed):
            record.ensure_valid(_broken(**{name: None}))
