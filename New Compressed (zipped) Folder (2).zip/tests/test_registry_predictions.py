"""Model registry (approval, promotion) and batch / single scoring with risk tiers and reasons."""

from __future__ import annotations

import csv
import io
import math
import pickle
from datetime import UTC, date, datetime

import numpy as np
import pytest
from sqlalchemy import func, select

from churn_platform import storage
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, Forbidden, NotFound, ValidationFailed
from churn_platform.models import (
    AuditEvent,
    ChurnLabel,
    Customer,
    FeatureContract,
    FeatureVector,
    Job,
    ModelEvaluation,
    ModelRun,
    ModelVersion,
    Prediction,
    PredictionBatch,
    Subscription,
    SubscriptionEvent,
)
from churn_platform.services import evaluation, features, labels, predictions, registry, training
from churn_platform.services.policies import RiskPolicy
from churn_platform.worker.runner import Worker

pytestmark = pytest.mark.req("REQ-ML-06")


def _algorithm(name: str) -> str:
    """Which algorithm a name used below stands for.  These tests register further models; which algorithm won the seeded
    comparison is not their subject, so "lightgbm", "random_forest" and "xgboost" stand for the three seeded runs that
    are not in the registry (each keeps its own name when it can)."""
    with read_session() as s:
        champion = s.execute(select(ModelRun.algorithm).join(ModelVersion, ModelVersion.model_run_id == ModelRun.id).order_by(ModelVersion.id).limit(1)).scalar_one()
    wanted = ("lightgbm", "random_forest", "xgboost")
    if name not in wanted or champion not in wanted:
        return name
    return "logistic_regression" if name == champion else name


def _run_id(algorithm: str) -> int:
    actual = _algorithm(algorithm)
    with read_session() as s:
        return s.execute(select(ModelRun.id).where(ModelRun.algorithm == actual)).scalar_one()


def _promote(demo, algorithm: str = "random_forest") -> int:
    """Take a second model through the full gate: TEST evaluation, registration, independent approval, production."""
    scientist, approver = demo.principal("data_scientist"), demo.principal("approver")
    run_id = _run_id(algorithm)
    with session_scope() as s:
        evaluation.evaluate(s, scientist, run_id, split="test")
        version_id = registry.register(s, scientist, run_id).id
    with session_scope() as s:
        registry.review(s, approver, version_id, approve=True, note="metrics reviewed")
        registry.set_stage(s, approver, version_id, "production")
    return version_id


# ----------------------------------------------------------------------------- registry
def test_registration_needs_a_validation_evaluation_and_copies_its_threshold(demo):
    scientist = demo.principal("data_scientist")
    run_id = _run_id("lightgbm")
    with session_scope() as s:
        s.execute(ModelRun.__table__.update().where(ModelRun.id == run_id).values(status="failed"))
    with session_scope() as s, pytest.raises(Conflict, match="only completed runs"):
        registry.register(s, scientist, run_id)
    with session_scope() as s:
        s.execute(ModelRun.__table__.update().where(ModelRun.id == run_id).values(status="completed"))
        s.execute(ModelEvaluation.__table__.delete().where(ModelEvaluation.model_run_id == run_id))
    with session_scope() as s, pytest.raises(Conflict) as exc:
        registry.register(s, scientist, run_id)
    assert exc.value.code == "not_evaluated"
    with session_scope() as s:
        threshold = evaluation.evaluate(s, scientist, run_id, split="valid").threshold_analysis["threshold"]
        version = registry.register(s, scientist, run_id, name=" churn-model ")
        seeded = s.execute(select(ModelVersion).where(ModelVersion.id != version.id)).scalar_one()
        assert (version.name, version.version, version.stage, version.approval_status) == ("churn-model", seeded.version + 1, "none", "pending")
        assert version.threshold == threshold and version.contract_id == seeded.contract_id
        assert version.threshold_basis["basis"] == "cost_matrix" and version.threshold_basis["selected_on"] == "validation split"
        assert version.threshold_basis["is_example"] is True, "the example cost matrix stays labelled as an example"
        other = registry.register(s, scientist, _run_id("xgboost"), name="experimental")
        assert other.version == 1, "version numbers run per model name"
        view = registry.version_view(version, s.get(ModelRun, run_id))
        assert view["algorithm"] == _algorithm("lightgbm") and view["test_pr_auc"] is None and view["valid_pr_auc"] is not None
    with session_scope() as s, pytest.raises(Conflict, match="already registered"):
        registry.register(s, scientist, run_id)
    with session_scope() as s, pytest.raises(ValidationFailed, match="name is required"):
        registry.register(s, scientist, _run_id("random_forest"), name="  ")
    with session_scope() as s, pytest.raises(NotFound):
        registry.register(s, scientist, 999_999)


@pytest.mark.req("REQ-GOV-01")
def test_a_model_reaches_production_only_after_test_evaluation_and_independent_approval(demo):
    scientist, approver, admin = demo.principal("data_scientist"), demo.principal("approver"), demo.principal("admin")
    run_id = _run_id("random_forest")
    with session_scope() as s:
        version_id = registry.register(s, scientist, run_id).id
        seeded_id = s.execute(select(ModelVersion.id).where(ModelVersion.stage == "production")).scalar_one()
    with session_scope() as s, pytest.raises(Conflict) as unapproved:
        registry.set_stage(s, admin, version_id, "production")
    assert unapproved.value.code == "model_not_approved"
    with session_scope() as s, pytest.raises(Forbidden) as own:
        registry.review(s, scientist, version_id, approve=True)
    assert own.value.code == "self_approval_forbidden"
    with session_scope() as s, pytest.raises(Forbidden):
        registry.review(s, scientist, version_id, approve=False)
    with session_scope() as s, pytest.raises(Conflict) as untested:
        registry.review(s, approver, version_id, approve=True)
    assert untested.value.code == "test_evaluation_required"
    with session_scope() as s:
        evaluation.evaluate(s, scientist, run_id, split="test")
    with session_scope() as s:
        approved = registry.review(s, approver, version_id, approve=True, note="lift and calibration reviewed")
        assert (approved.approval_status, approved.reviewed_by, approved.review_note) == ("approved", approver.user_id, "lift and calibration reviewed")
        assert approved.stage == "none", "approval does not deploy"
        assert registry.production_version(s, demo.tenant_id).id == seeded_id
    with session_scope() as s, pytest.raises(Conflict, match="already approved"):
        registry.review(s, approver, version_id, approve=False)
    with session_scope() as s, pytest.raises(Conflict) as not_servable:
        registry.production_version(s, demo.tenant_id, version_id=version_id)
    assert not_servable.value.code == "model_not_servable" and "needs approved + production" in not_servable.value.message
    with session_scope() as s, pytest.raises(ValidationFailed, match="stage must be one of"):
        registry.set_stage(s, admin, version_id, "live")
    with session_scope() as s:
        assert registry.set_stage(s, admin, version_id, "staging").stage == "staging"
        assert registry.production_version(s, demo.tenant_id).id == seeded_id, "staging does not serve"
        registry.set_stage(s, admin, version_id, "production")
    with read_session() as s:
        stages = dict(s.execute(select(ModelVersion.id, ModelVersion.stage)).all())
        assert stages == {seeded_id: "archived", version_id: "production"}, "exactly one production version per model name"
        assert registry.production_version(s, demo.tenant_id).id == version_id
        actions = s.execute(select(AuditEvent.action, AuditEvent.detail).where(AuditEvent.entity_type == "model_version",
                                                                               AuditEvent.entity_id == str(version_id)).order_by(AuditEvent.id)).all()  # fmt: skip
    assert [a for a, _ in actions] == ["ml.model_registered", "ml.model_approved", "ml.model_stage_changed", "ml.model_stage_changed"]
    assert actions[-1][1]["from"] == "staging" and actions[-1][1]["to"] == "production" and actions[1][1]["test_pr_auc"] is not None
    # a rejected model can never be promoted
    with session_scope() as s:
        rejected_id = registry.register(s, scientist, _run_id("xgboost")).id
    with session_scope() as s:
        assert registry.review(s, approver, rejected_id, approve=False, note="worse than the baseline").approval_status == "rejected"
    with session_scope() as s, pytest.raises(Conflict):
        registry.set_stage(s, admin, rejected_id, "staging")
    # rollback: archive the new version and nothing serves until a version is promoted again
    with session_scope() as s:
        registry.set_stage(s, admin, version_id, "archived")
    with session_scope() as s, pytest.raises(NotFound) as none_serving:
        registry.production_version(s, demo.tenant_id)
    assert none_serving.value.code == "no_production_model"
    with session_scope() as s:
        registry.set_stage(s, admin, seeded_id, "production")
        assert registry.production_version(s, demo.tenant_id).id == seeded_id


# ----------------------------------------------------------------------------- tiers
def test_risk_tiers_are_rank_based_top_shares():
    prob = np.array([0.05, 0.9, 0.2, 0.6, 0.1, 0.3, 0.8, 0.4, 0.7, 0.5])
    tiers, deciles, cut = predictions.assign_tiers(prob, RiskPolicy(high_risk_top_share=0.2, medium_risk_top_share=0.5))
    assert [t for _, t in sorted(zip(-prob, tiers, strict=True))] == ["high"] * 2 + ["medium"] * 3 + ["low"] * 5
    assert [int(d) for _, d in sorted(zip(-prob, deciles, strict=True))] == list(range(1, 11)), "decile 1 is the riskiest tenth"
    assert cut["high_min_probability"] == 0.8 and cut["medium_min_probability"] == 0.5, "the lowest score still inside each tier"
    assert cut["decile_min_probability"] == sorted(prob, reverse=True)
    for p, tier, decile in zip(prob, tiers, deciles, strict=True):
        assert predictions.place(float(p), cut) == (tier, int(decile)), "a single score is placed consistently with the batch"
    assert predictions.place(0.95, cut) == ("high", 1) and predictions.place(0.01, cut) == ("low", 10)
    # shares round up, so a tiny book still has a high tier; ties are broken by position, never by chance
    tiers, deciles, _ = predictions.assign_tiers(np.array([0.5, 0.5, 0.5]), RiskPolicy())
    assert tiers == ["high", "medium", "low"] and deciles.tolist() == [1, 4, 7]
    assert predictions.assign_tiers(np.array([]), RiskPolicy()) == ([], pytest.approx(np.array([])), {
        "high_min_probability": None, "medium_min_probability": None, "decile_min_probability": []})  # fmt: skip
    assert predictions.place(0.4, {}) == ("low", 10)


# ----------------------------------------------------------------------------- the seeded batch
@pytest.fixture
def batch(ro):
    with read_session() as s:
        b = s.get(PredictionBatch, ro.summary["batch_id"])
        rows = s.execute(select(Prediction).where(Prediction.batch_id == b.id).order_by(Prediction.id)).scalars().all()
        version = s.get(ModelVersion, b.model_version_id)
        run = s.get(ModelRun, version.model_run_id)
        contract = s.get(FeatureContract, version.contract_id)
        stored = features.offline_frame(s, ro.tenant_id, contract, dates=[b.as_of_date])
    return b, rows, version, run, stored


def test_batch_scores_every_active_customer_once_with_probability_tier_and_reasons(batch):
    b, rows, version, run, stored = batch
    assert (b.status, b.kind, b.as_of_date) == ("completed", "batch", date(2026, 11, 1)), "scored for the day after the data cutoff"
    assert b.total == b.succeeded == len(rows) == len(stored) == 212 and b.failed == 0
    assert len({r.customer_id for r in rows}) == len(rows) and {r.customer_id for r in rows} == set(stored["customer_id"])
    policy = RiskPolicy()
    n_high, n_medium = math.ceil(len(rows) * policy.high_risk_top_share), math.ceil(len(rows) * policy.medium_risk_top_share)
    counts = {tier: sum(r.risk_tier == tier for r in rows) for tier in predictions.TIERS}
    assert counts == {"high": n_high, "medium": n_medium - n_high, "low": len(rows) - n_medium} == b.summary["tiers"]
    assert min(r.probability for r in rows if r.risk_tier == "high") >= max(r.probability for r in rows if r.risk_tier == "medium")
    assert min(r.probability for r in rows if r.risk_tier == "medium") >= max(r.probability for r in rows if r.risk_tier == "low")
    assert sorted({r.risk_decile for r in rows}) == list(range(1, 11))
    for r in rows:
        assert 0.0 <= r.probability <= 1.0 and r.horizon_days == 30 and r.model_version_id == version.id
        assert r.threshold == version.threshold and r.predicted_label == int(r.probability >= version.threshold)
        assert r.top_reasons is not None and len(r.top_reasons) <= 3
        assert all(reason["contribution"] > 0 and reason["direction"] == "raises" and reason["text"] for reason in r.top_reasons)
    assert sum(len(r.top_reasons) == 3 for r in rows) > 0.9 * len(rows), "almost every customer gets three reasons"
    assert b.summary["explanations"]["status"] == "available" and b.summary["explanations"]["max_additivity_error"] <= 1e-3
    assert b.summary["feature_source"] == "offline feature store" and b.summary["risk_policy"]["source"] == "approved policy"
    assert b.summary["model"] == {"name": version.name, "version": version.version, "algorithm": run.algorithm}
    assert b.summary["flagged_at_threshold"] == sum(r.predicted_label for r in rows)
    assert b.decile_cutpoints["high_min_probability"] == min(r.probability for r in rows if r.risk_tier == "high")


def test_stored_probabilities_are_reproducible_from_the_model_and_the_feature_store(batch):
    b, rows, _version, run, stored = batch
    bundle = training.load_bundle(run)
    recomputed = dict(zip(stored["customer_id"], training.predict_proba(bundle, stored), strict=True))
    assert {r.customer_id: r.probability for r in rows} == pytest.approx(recomputed, abs=1e-12)
    # ... and the feature store itself equals a fresh point-in-time computation for that date
    fresh = features.compute_for(b.tenant_id, bundle["features"], [b.as_of_date])
    again = dict(zip(fresh["customer_id"], training.predict_proba(bundle, fresh), strict=True))
    assert again == pytest.approx(recomputed, abs=1e-12)


def test_local_explanation_reproduces_the_stored_probability_and_is_cached(demo):
    csm = demo.principal("csm")
    with read_session() as s:
        top = s.execute(select(Prediction).where(Prediction.batch_id == demo.summary["batch_id"]).order_by(Prediction.probability.desc())).scalars().first()
    with session_scope() as s:
        first = predictions.local_explanation(s, csm, top.id)
    with session_scope() as s:
        second = predictions.local_explanation(s, csm, top.id)
    assert first["id"] == second["id"], "computed once, then served from the cache"
    assert first["status"] == "available" and first["probability"] == top.probability and first["scope"] == "local"
    body = first["contributions"]
    assert body["reproduces_stored_probability"] is True and body["probability_difference"] < 1e-6
    wf = body["waterfall"]
    assert wf["final_probability"] == pytest.approx(top.probability, abs=1e-6)
    assert wf["base_probability"] + sum(step["probability_delta"] for step in wf["steps"]) == pytest.approx(top.probability, abs=1e-6)
    assert first["base_value"] + sum(body["values"].values()) == pytest.approx(first["output_value"], abs=1e-3)
    stored_reasons = [r["feature"] for r in top.top_reasons]
    ranked = sorted(body["values"], key=lambda k: -body["values"][k])[: len(stored_reasons)]
    assert ranked == stored_reasons, "the reasons shown in the list are the top of the full explanation"
    with session_scope() as s, pytest.raises(NotFound):
        predictions.local_explanation(s, csm, 999_999)


def test_export_file_has_user_id_probability_tier_and_three_reasons(demo):
    with session_scope() as s:
        riskiest = s.execute(select(Prediction).where(Prediction.batch_id == demo.summary["batch_id"]).order_by(Prediction.probability.desc())).scalars().first()
        customer = s.get(Customer, riskiest.customer_id)
        external_id, customer.name = customer.external_id, '=HYPERLINK("http://evil.example","click")'
    with read_session() as s:
        text = predictions.export_csv(s, demo.tenant_id, demo.summary["batch_id"])
        dist = predictions.distribution(s, demo.tenant_id, demo.summary["batch_id"])
        with pytest.raises(NotFound):
            predictions.export_csv(s, demo.tenant_id + 1, demo.summary["batch_id"])
    rows = list(csv.DictReader(io.StringIO(text)))
    assert list(rows[0]) == predictions.EXPORT_COLUMNS == ["user_id", "customer_name", "as_of_date", "churn_probability", "risk_tier", "risk_decile",
                                                           "top_reason_1", "top_reason_2", "top_reason_3", "model_version_id"]  # fmt: skip
    assert len(rows) == 212 and len({r["user_id"] for r in rows}) == 212
    probabilities = [float(r["churn_probability"]) for r in rows]
    assert probabilities == sorted(probabilities, reverse=True) and all(r["risk_tier"] in predictions.TIERS for r in rows)
    assert rows[0]["user_id"] == external_id and rows[0]["risk_tier"] == "high" and rows[0]["top_reason_1"]
    assert rows[0]["customer_name"].startswith("'="), "a formula in a name is neutralised for spreadsheets"
    assert all(r["as_of_date"] == "2026-11-01" for r in rows)
    assert sum(dist["histogram"]["counts"]) == 212 and len(dist["histogram"]["edges"]) == 21 and sum(dist["tiers"].values()) == 212


# ----------------------------------------------------------------------------- running batches
def test_batch_scoring_is_idempotent_and_validates_its_inputs(demo):
    admin = demo.principal("admin")
    with session_scope() as s:
        before = s.execute(select(func.count()).select_from(Prediction)).scalar_one()
        same, job = predictions.start_batch(s, admin, tenant_id=demo.tenant_id)
        assert same.id == demo.summary["batch_id"] and job is None, "the same model and date are never scored twice"
        same, job = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-11-01")
        assert same.id == demo.summary["batch_id"] and job is None
    assert predictions.run_scheduled(demo.tenant_id, None) == {"batch_id": demo.summary["batch_id"], "status": "already_scored"}
    with session_scope() as s, pytest.raises(ValidationFailed, match="cannot be later than the day after the data cutoff"):
        predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-11-02")
    with session_scope() as s, pytest.raises(ValidationFailed):
        predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="next week")
    # a past date that is not in the feature store is computed point-in-time for the batch
    with session_scope() as s:
        batch, job = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-10-15")
        batch_id, job_id = batch.id, job.id
        assert predictions.default_as_of(s, demo.tenant_id) == date(2026, 11, 1)
    Worker().drain()
    with read_session() as s:
        batch, job = s.get(PredictionBatch, batch_id), s.get(Job, job_id)
        rows = s.execute(select(Prediction).where(Prediction.batch_id == batch_id)).scalars().all()
        after = s.execute(select(func.count()).select_from(Prediction)).scalar_one()
    assert (batch.status, job.status) == ("completed", "succeeded") and batch.summary["feature_source"] == "computed for this batch"
    assert batch.total == len(rows) > 150 and after == before + len(rows) and {r.as_of_date for r in rows} == {date(2026, 10, 15)}
    assert job.result["customers_scored"] == len(rows) and batch.summary["adopted_single_predictions"] == 0


def test_only_an_approved_production_model_can_score(demo):
    admin = demo.principal("admin")
    with session_scope() as s:
        version = s.execute(select(ModelVersion)).scalar_one()
        registry.set_stage(s, admin, version.id, "archived")
        version_id = version.id
    with session_scope() as s, pytest.raises(NotFound) as none:
        predictions.start_batch(s, admin, tenant_id=demo.tenant_id)
    assert none.value.code == "no_production_model"
    with session_scope() as s, pytest.raises(Conflict) as archived:
        predictions.start_batch(s, admin, tenant_id=demo.tenant_id, model_version_id=version_id)
    assert archived.value.code == "model_not_servable"
    with session_scope() as s, pytest.raises(NotFound):
        predictions.predict_single(s, admin, s.execute(select(Customer.id).limit(1)).scalar_one())


def test_a_batch_whose_model_no_longer_matches_its_feature_contract_fails_loudly(demo):
    admin = demo.principal("admin")
    with session_scope() as s:
        batch, job = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-09-15")
        batch_id, job_id = batch.id, job.id
        version = s.get(ModelVersion, batch.model_version_id)
        run = s.get(ModelRun, version.model_run_id)
    bundle = training.load_bundle(run)
    training._BUNDLE_CACHE.clear()
    tampered = {**bundle, "contract_schema_hash": "0" * 64}
    path = storage.resolve(run.artifact_path)
    path.write_bytes(pickle.dumps(tampered))
    with session_scope() as s:
        s.execute(ModelRun.__table__.update().where(ModelRun.id == run.id).values(artifact_sha256=training.sha256_path(path)))
    Worker().drain()
    with read_session() as s:
        batch, job = s.get(PredictionBatch, batch_id), s.get(Job, job_id)
        assert (batch.status, job.status, job.attempts) == ("failed", "failed", 1)
        assert "different feature contract" in batch.summary["error"] and "different feature contract" in job.error
        assert s.execute(select(func.count()).select_from(Prediction).where(Prediction.batch_id == batch_id)).scalar_one() == 0


# ----------------------------------------------------------------------------- single scoring
def test_single_scoring_and_adoption_of_single_scores_by_the_next_batch(demo):
    csm, admin = demo.principal("csm"), demo.principal("admin")
    with read_session() as s:
        seeded = s.execute(select(Prediction).where(Prediction.batch_id == demo.summary["batch_id"]).order_by(Prediction.probability.desc())).scalars().first()
        inactive = s.execute(select(Customer.id).where(Customer.id.not_in(select(Prediction.customer_id)))).scalars().first()
    with session_scope() as s:
        again = predictions.predict_single(s, csm, seeded.customer_id)
    assert again["id"] == seeded.id and again["source"] == "existing prediction for this model and date"
    with session_scope() as s, pytest.raises(Conflict) as none:
        predictions.predict_single(s, csm, inactive)
    assert none.value.code == "customer_not_active"
    with session_scope() as s, pytest.raises(NotFound):
        predictions.predict_single(s, csm, 999_999)
    # a new production model: no batch exists for it yet
    version_id = _promote(demo)
    with session_scope() as s:
        single = predictions.predict_single(s, csm, seeded.customer_id)
    assert single["model_version_id"] == version_id and single["as_of_date"] == "2026-11-01" and 0 <= single["probability"] <= 1
    assert single["risk_tier"] is None and "relative risk tier cannot be assigned" in single["tier_note"]
    assert single["source"] == "offline feature store" and single["customer_external_id"] and len(single["top_reasons"]) <= 3
    with session_scope() as s:
        cached = predictions.local_explanation(s, csm, single["id"])
        assert cached["status"] == "available" and cached["contributions"]["reproduces_stored_probability"] is True
        batch, job = predictions.start_batch(s, admin, tenant_id=demo.tenant_id)
        batch_id = batch.id
        assert job is not None and batch.model_version_id == version_id
    Worker().drain()
    with read_session() as s:
        batch = s.get(PredictionBatch, batch_id)
        rows = s.execute(select(Prediction).where(Prediction.batch_id == batch_id)).scalars().all()
        adopted = s.get(Prediction, single["id"])
        single_batch = s.execute(select(PredictionBatch).where(PredictionBatch.kind == "single")).scalar_one()
        text = predictions.export_csv(s, demo.tenant_id, batch_id)
    assert batch.status == "completed" and batch.total == len(rows) == 212, "the batch owns a row for every scored customer"
    assert adopted.batch_id == batch_id and adopted.risk_tier in predictions.TIERS and 1 <= adopted.risk_decile <= 10
    assert adopted.probability == pytest.approx(single["probability"], abs=1e-12), "same model, same date, same features: same score"
    assert batch.summary["adopted_single_predictions"] == 1 and single_batch.summary["adopted_by_batch_id"] == batch_id
    assert len(text.strip().splitlines()) == 213
    # a later single request is placed against that batch's cut points
    other = next(r for r in rows if r.id != adopted.id and r.risk_tier == "medium")
    with session_scope() as s:
        s.execute(Prediction.__table__.delete().where(Prediction.id == other.id))
    with session_scope() as s:
        placed = predictions.predict_single(s, csm, other.customer_id)
    assert (placed["risk_tier"], placed["risk_decile"]) == (other.risk_tier, other.risk_decile) and placed["tier_note"] is None
    assert placed["probability"] == pytest.approx(other.probability, abs=1e-12) and placed["id"] != other.id


# ----------------------------------------------------------------------------- who is scored
def test_a_batch_scores_the_population_the_model_was_trained_on_and_says_who_was_left_out(demo):
    """DEF-024: trial customers have feature vectors but no churn label under the definition, yet they used to be scored."""
    admin = demo.principal("admin")
    day = date(2026, 9, 15)
    with session_scope() as s:
        batch, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date=day, kind="backtest")
        labels.start_run(s, admin, as_of_dates=[day])
        batch_id = batch.id
    demo.drain()
    with read_session() as s:
        batch = s.get(PredictionBatch, batch_id)
        scored = set(s.execute(select(Prediction.customer_id).where(Prediction.batch_id == batch_id)).scalars())
        vectors = set(s.execute(select(FeatureVector.customer_id).where(FeatureVector.as_of_date == day)).scalars())
        by_status: dict[str, set] = {}
        for customer_id, status, detail in s.execute(select(ChurnLabel.customer_id, ChurnLabel.status, ChurnLabel.detail).where(ChurnLabel.as_of_date == day)):
            by_status.setdefault(status if status != "ineligible" else detail["reason"], set()).add(customer_id)
    population = batch.summary["population"]
    assert population["not_scored"] == {"in_trial": 1} and population["churn_definition_version"] == 1
    assert population["rule"] == "customers covered by the churn definition the model was trained under"
    assert (batch.total, batch.succeeded, batch.summary["customers_scored"]) == (213, 213, 213)
    # every scored customer has an outcome label for that date, and nobody with an outcome label was skipped
    assert scored == by_status["churned"] | by_status["retained"] and len(scored) == 213
    assert not vectors or vectors - scored <= by_status["in_trial"], "a trial customer may have features, but gets no score"
    assert len(by_status["in_trial"] & scored) == 0 and len(by_status["in_trial"]) >= 1


def test_single_scoring_refuses_a_customer_outside_the_model_population(demo):
    analyst = demo.principal("analyst")
    with session_scope() as s:
        trial = Customer(tenant_id=demo.tenant_id, external_id="TRIAL-1", name="Trial GmbH", acquired_at=datetime(2026, 10, 20, tzinfo=UTC))
        gone = Customer(tenant_id=demo.tenant_id, external_id="GONE-1", name="Gone Ltd", acquired_at=datetime(2026, 3, 1, tzinfo=UTC))
        s.add_all([trial, gone])
        s.flush()
        for customer, start, trial_end in ((trial, datetime(2026, 10, 20, tzinfo=UTC), datetime(2026, 11, 19, tzinfo=UTC)), (gone, datetime(2026, 3, 1, tzinfo=UTC), None)):
            sub = Subscription(tenant_id=demo.tenant_id, external_id=f"S-{customer.external_id}", customer_id=customer.id, started_at=start,
                               trial_end_at=trial_end, billing_period="monthly", mrr=99)  # fmt: skip
            s.add(sub)
            s.flush()
            s.add(SubscriptionEvent(tenant_id=demo.tenant_id, external_id=f"E-{customer.external_id}", subscription_id=sub.id, customer_id=customer.id,
                                    event_type="started", occurred_at=start, mrr=99))  # fmt: skip
            if customer is gone:
                s.add(SubscriptionEvent(tenant_id=demo.tenant_id, external_id="E-GONE-2", subscription_id=sub.id, customer_id=customer.id,
                                        event_type="ended", occurred_at=datetime(2026, 6, 1, tzinfo=UTC), reason="cancellation"))  # fmt: skip
        trial_id, gone_id = trial.id, gone.id
    with session_scope() as s, pytest.raises(Conflict) as refused:
        predictions.predict_single(s, analyst, trial_id)
    assert refused.value.code == "customer_not_in_scope" and refused.value.details == {"reason": "in_trial"}
    assert refused.value.message == "no prediction is made for this customer: the customer is still in a trial, and the churn definition covers paying subscribers only"
    with session_scope() as s, pytest.raises(Conflict) as inactive:
        predictions.predict_single(s, analyst, gone_id)
    assert inactive.value.code == "customer_not_active"
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(Prediction).where(Prediction.customer_id.in_([trial_id, gone_id]))).scalar_one() == 0
