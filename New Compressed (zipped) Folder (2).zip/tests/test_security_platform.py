"""Security additions of 1.1.0: request limits shared by all server processes, trust in forwarded headers,
session-token rotation, and single sign-on with OpenID Connect."""

from __future__ import annotations

from urllib.parse import parse_qs, urlparse

import pytest
from sqlalchemy import delete, select, update

from churn_platform import netpolicy
from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import ExternalServiceError, RateLimited, ServiceUnavailable, ValidationFailed
from churn_platform.models import AuditEvent, AuthSession, IdentityProvider, OidcLoginState, RateLimitCounter, User
from churn_platform.security import SecretBox
from churn_platform.services import ratelimit, sso
from tests.conftest import PASSWORD, activate
from tests.fakes import FakeIdp

API = "/api/v1"


def actions(action: str) -> list[AuditEvent]:
    with read_session() as s:
        return list(s.execute(select(AuditEvent).where(AuditEvent.action == action).order_by(AuditEvent.id)).scalars())


# ============================================================================= rate limits
@pytest.fixture
def one_window(monkeypatch):
    """One counting window for the whole test, so that a minute boundary cannot fall between two requests."""
    monkeypatch.setattr(ratelimit, "WINDOW_SECONDS", 10**9)


@pytest.mark.req("REQ-SEC-07")
def test_the_limit_is_counted_in_the_database_so_every_server_process_sees_the_same_total(demo, one_window):
    first = [ratelimit.hit("probe", "client-1", 5) for _ in range(5)]
    assert [v.allowed for v in first] == [True] * 5 and [v.remaining for v in first] == [4, 3, 2, 1, 0] and {v.store for v in first} == {"shared"}
    # a second server process has its own memory and the same database: it sees the five hits
    ratelimit.reset_local()
    sixth = ratelimit.hit("probe", "client-1", 5)
    assert (sixth.allowed, sixth.hits, sixth.remaining) == (False, 6, 0) and sixth.retry_after >= 1
    assert sixth.headers() == {"X-RateLimit-Limit": "5", "X-RateLimit-Remaining": "0", "Retry-After": str(sixth.retry_after)}
    assert ratelimit.hit("probe", "client-2", 5).allowed and ratelimit.hit("other", "client-1", 5).allowed, "limits are per bucket and per subject"
    with pytest.raises(RateLimited) as limited:
        ratelimit.enforce("probe", "client-1", 5)
    assert limited.value.details["limit_per_minute"] == 5 and limited.value.details["bucket"] == "probe"
    with read_session() as s:
        rows = {(r.bucket, r.subject): r.hits for r in s.execute(select(RateLimitCounter)).scalars()}
    assert rows[("probe", "client-1")] == 7 and rows[("probe", "client-2")] == 1
    assert any(entry["bucket"] == "probe" and entry["hits"] == 7 for entry in ratelimit.snapshot())


@pytest.mark.req("REQ-SEC-07")
def test_when_the_counter_store_fails_the_limiter_falls_back_or_refuses_but_never_switches_itself_off(demo, one_window, monkeypatch):
    def broken():
        raise RuntimeError("database unavailable")

    monkeypatch.setattr(ratelimit, "get_engine", broken)
    local = [ratelimit.hit("probe", "client-1", 2) for _ in range(3)]
    assert [v.allowed for v in local] == [True, True, False] and {v.store for v in local} == {"local"}, "counted per process while the store is down"
    activate(demo.db_path, demo.data_dir, CHURN_RATE_LIMIT_STORE_FAILURE="deny")
    with pytest.raises(ServiceUnavailable) as refused:
        ratelimit.hit("probe", "client-1", 2)
    assert refused.value.code == "rate_limiter_unavailable"
    monkeypatch.undo()
    activate(demo.db_path, demo.data_dir, CHURN_RATE_LIMIT_ENABLED="false")
    assert ratelimit.hit("probe", "client-9", 1).store == "off" and ratelimit.hit("probe", "client-9", 1).allowed


@pytest.mark.req("REQ-SEC-07")
def test_sign_in_is_limited_per_account_and_changes_are_limited_per_address_over_http(demo, one_window):
    activate(demo.db_path, demo.data_dir, CHURN_RATE_LIMIT_LOGIN_ACCOUNT_PER_MINUTE="3", CHURN_RATE_LIMIT_IP_PER_MINUTE="12")
    with demo.client() as c:
        for _ in range(3):
            assert c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": "wrong"}).status_code == 401
        blocked = c.post(f"{API}/auth/login", json={"email": demo.email("viewer"), "password": PASSWORD})
        assert blocked.status_code == 429 and blocked.json()["error"]["code"] == "rate_limited", "the right password does not get past the account limit either"
        assert blocked.json()["error"]["details"]["bucket"] == "login_account"
        other = c.post(f"{API}/auth/login", json={"email": demo.email("admin"), "password": PASSWORD})
        assert other.status_code == 200 and other.headers["X-RateLimit-Limit"] == "12", "another account is not affected"
        headers = {"Authorization": "Bearer " + other.json()["token"]}
        # reads are not counted; changes are (5 sign-in attempts so far, 12 allowed per address)
        for _ in range(20):
            assert c.get(f"{API}/auth/me", headers=headers).status_code == 200
        codes = [c.post(f"{API}/auth/rotate", headers=headers, json={}).status_code for _ in range(8)]
        assert codes[:7] == [200] * 7 or codes.count(429) >= 1
        last = c.post(f"{API}/admin/users", headers=headers, json={})
        assert last.status_code == 429 and int(last.headers["Retry-After"]) >= 1 and last.headers["X-RateLimit-Remaining"] == "0"
        assert last.json()["error"]["details"]["limit_per_minute"] == 12


@pytest.mark.req("REQ-SEC-07")
def test_expensive_operations_have_their_own_limit_per_user(demo, one_window):
    activate(demo.db_path, demo.data_dir, CHURN_RATE_LIMIT_EXPORT_PER_MINUTE="2")
    with demo.client() as c:
        analyst, admin = demo.login(c, "analyst"), demo.login(c, "admin")
        batch = c.get(f"{API}/predictions/batches", headers=analyst).json()["items"][0]["id"]
        answers = [c.get(f"{API}/predictions/batches/{batch}/export.csv", headers=analyst) for _ in range(3)]
        assert [a.status_code for a in answers] == [200, 200, 429]
        assert int(answers[2].headers["Retry-After"]) >= 1 and answers[2].json()["error"]["details"]["bucket"] == "export"
        assert c.get(f"{API}/predictions/batches/{batch}/export.csv", headers=admin).status_code == 200, "the limit is per user"
        overview = c.get(f"{API}/admin/security/overview", headers=admin).json()
        assert overview["rate_limits"]["per_minute"]["exports_per_user"] == 2 and "shared by every server process" in overview["rate_limits"]["store"]
        # the screen shows a tenant the counters of its own users, by name - and nothing that is counted per address or account
        assert overview["rate_limits"]["own_users_this_minute"] == [
            {"limit": "export", "user": "analyst@demo.example", "requests": 3, "allowed": 2}, {"limit": "export", "user": "admin@demo.example", "requests": 1, "allowed": 2}]
        assert "login_ip" in {b["bucket"] for b in ratelimit.snapshot()} and "busiest_now" not in overview["rate_limits"]
        assert c.get(f"{API}/admin/security/overview", headers=analyst).status_code == 403


# ============================================================================= proxies and transport security
@pytest.mark.req("REQ-SEC-07")
def test_forwarded_headers_are_believed_only_from_configured_proxies(demo, monkeypatch, capsys):
    activate(demo.db_path, demo.data_dir)
    assert netpolicy.client_address("203.0.113.9", "198.51.100.7") == "203.0.113.9", "no proxy is trusted: the header is ignored"
    assert netpolicy.is_secure("http", "203.0.113.9", "https") is False
    activate(demo.db_path, demo.data_dir, CHURN_TRUSTED_PROXIES="10.0.0.0/8, 192.168.1.5")
    netpolicy._networks.cache_clear()
    assert netpolicy.client_address("10.1.2.3", "198.51.100.7") == "198.51.100.7"
    assert netpolicy.client_address("10.1.2.3", "198.51.100.7, 10.9.9.9") == "198.51.100.7", "the right-most address that is not a proxy"
    assert netpolicy.client_address("10.1.2.3", "6.6.6.6, 198.51.100.7") == "198.51.100.7", "a client cannot put a false address in front"
    assert netpolicy.client_address("203.0.113.9", "198.51.100.7") == "203.0.113.9", "a peer that is not a proxy is not believed"
    assert netpolicy.client_address("10.1.2.3", "not-an-address") == "10.1.2.3" and netpolicy.client_address("10.1.2.3", None) == "10.1.2.3"
    assert netpolicy.is_secure("http", "10.1.2.3", "https") is True and netpolicy.is_secure("http", "203.0.113.9", "https") is False
    assert netpolicy.is_secure("https", None, None) is True
    from starlette.testclient import TestClient

    from churn_platform.api import create_app

    with TestClient(create_app(), client=("203.0.113.9", 4000)) as outsider:
        spoofed = outsider.get("/healthz", headers={"X-Forwarded-Proto": "https"})
        assert "Strict-Transport-Security" not in spoofed.headers, "release 1.0 set this header for anyone who sent X-Forwarded-Proto"
        login = outsider.post(f"{API}/auth/login", headers={"X-Forwarded-For": "198.51.100.7"}, json={"email": demo.email("viewer"), "password": PASSWORD})
        assert login.status_code == 200
    with TestClient(create_app(), client=("10.1.2.3", 4000)) as proxied:
        assert proxied.get("/healthz", headers={"X-Forwarded-Proto": "https"}).headers["Strict-Transport-Security"] == "max-age=31536000; includeSubDomains"
        assert "Strict-Transport-Security" not in proxied.get("/healthz", headers={"X-Forwarded-Proto": "http"}).headers
        login = proxied.post(f"{API}/auth/login", headers={"X-Forwarded-For": "198.51.100.7"}, json={"email": demo.email("viewer"), "password": PASSWORD})
        assert login.status_code == 200
    with read_session() as s:
        addresses = [row.ip for row in s.execute(select(AuthSession).order_by(AuthSession.id.desc()).limit(2)).scalars()]
    assert addresses == ["198.51.100.7", "203.0.113.9"], "the session records the client behind the trusted proxy, and the peer itself otherwise"
    activate(demo.db_path, demo.data_dir, CHURN_FORCE_HTTPS="true", CHURN_HSTS_SECONDS="600")
    with TestClient(create_app()) as forced:
        assert forced.get("/healthz").headers["Strict-Transport-Security"] == "max-age=600; includeSubDomains"
    # The server command adds no second list.  uvicorn's own handling of forwarded headers trusts 127.0.0.1 unless told
    # otherwise, so with it switched on a client on the same machine chose its address and claimed HTTPS whatever
    # CHURN_TRUSTED_PROXIES said.  It is switched off, and the 1.0 option that fed it is refused with a pointer to the setting.
    import uvicorn

    from churn_platform import cli

    started: dict = {}
    monkeypatch.setattr(uvicorn, "run", lambda *args, **kwargs: started.update(kwargs))
    monkeypatch.setattr("signal.signal", lambda *args: None)
    assert cli.main(["serve", "--port", "8099"]) == 0
    assert started["proxy_headers"] is False and "forwarded_allow_ips" not in started and started["port"] == 8099
    started.clear()
    assert cli.main(["serve", "--forwarded-allow-ips", "10.0.0.5"]) == 2 and not started, "refused before anything listens"
    assert "CHURN_TRUSTED_PROXIES" in capsys.readouterr().err


# ============================================================================= session rotation
@pytest.mark.req("REQ-SEC-07")
def test_a_session_token_is_replaced_and_a_replaced_token_presented_later_revokes_what_came_after(demo):
    with demo.client() as c:
        login = c.post(f"{API}/auth/login", json={"email": demo.email("analyst"), "password": PASSWORD}).json()
        old = {"Authorization": "Bearer " + login["token"]}
        me = c.get(f"{API}/auth/me", headers=old).json()
        assert me["session"]["auth_method"] == "password" and me["session"]["rotate_after"] <= me["session"]["expires_at"]
        rotated = c.post(f"{API}/auth/rotate", headers=old, json={})
        assert rotated.status_code == 200 and rotated.json()["token"] != login["token"] and rotated.json()["expires_at"] == me["session"]["expires_at"], \
            "rotation does not extend the session"
        new = {"Authorization": "Bearer " + rotated.json()["token"]}
        assert c.get(f"{API}/auth/me", headers=new).status_code == 200
        assert c.get(f"{API}/auth/me", headers=old).status_code == 200, "requests already under way with the old token still finish (30 seconds)"
        with read_session() as s:
            sessions = s.execute(select(AuthSession).join(User, User.id == AuthSession.user_id).where(User.email == demo.email("analyst")).order_by(AuthSession.id)).scalars().all()
            assert [(x.rotated_from, x.revoked_reason) for x in sessions] == [(None, "rotated"), (sessions[0].id, None)]
        second = c.post(f"{API}/auth/rotate", headers=new, json={}).json()
        newest = {"Authorization": "Bearer " + second["token"]}
        # the grace period of the first token is over
        with session_scope() as s:
            s.execute(update(AuthSession).where(AuthSession.id == sessions[0].id).values(expires_at=utcnow().replace(year=2020)))
        stale = c.get(f"{API}/auth/me", headers=old)
        assert stale.status_code == 401 and stale.json()["error"]["code"] == "session_expired"
        # somebody still holds the replaced token: every session that descends from it ends, the thief's and the owner's alike
        for headers in (new, newest):
            assert c.get(f"{API}/auth/me", headers=headers).status_code == 401
        reuse = actions("auth.rotated_token_reused")
        assert len(reuse) == 1 and reuse[0].detail == {"sessions_revoked": 2} and reuse[0].actor_label == demo.email("analyst")
        assert [e.detail["replaces"] for e in actions("auth.session_rotated")] == [sessions[0].id, sessions[1].id]
        assert c.post(f"{API}/auth/rotate", json={}).status_code == 401


# ============================================================================= single sign-on
@pytest.fixture
def idp(demo):
    """The seeded tenant with one enabled identity provider, backed by an in-memory OpenID Connect server."""
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL="https://churn.corp.example")
    fake = FakeIdp()
    sso.set_transport(fake.transport())
    with session_scope() as s:
        provider = sso.create_provider(s, demo.principal("admin"), {
            "name": "Corp SSO", "issuer": fake.issuer + "/", "client_id": fake.client_id, "client_secret": "s3cret-of-the-client",
            "allowed_email_domains": ["corp.example", "demo.example"], "role_mapping": {"churn-admins": "admin", "churn-analysts": "analyst"}, "default_role": "viewer",
            "auto_provision": True})  # fmt: skip
        fake.provider_id = provider.id
        assert provider.issuer == "https://idp.example" and provider.client_secret_enc != "s3cret-of-the-client"
        assert SecretBox().decrypt(provider.client_secret_enc) == "s3cret-of-the-client"
    return fake


def start_login(c, idp) -> dict:
    """Begin a login in the browser ``c`` and return what the identity provider received."""
    response = c.get(f"{API}/auth/oidc/{idp.provider_id}/start", follow_redirects=False)
    assert response.status_code == 302, response.text
    url = urlparse(response.headers["location"])
    query = {k: v[0] for k, v in parse_qs(url.query).items()}
    assert f"{url.scheme}://{url.netloc}{url.path}" == "https://idp.example/authorize"
    idp.nonce, idp.expected_challenge = query["nonce"], query["code_challenge"]
    return query


def finish_login(c, state: str, code: str = "good-code") -> dict:
    response = c.get(f"{API}/auth/oidc/callback", params={"state": state, "code": code}, follow_redirects=False)
    assert response.status_code == 302 and response.headers["location"].startswith("/#/sso?"), response.text
    return {k: v[0] for k, v in parse_qs(response.headers["location"].split("?", 1)[1]).items()}


@pytest.mark.req("REQ-SEC-08")
def test_single_sign_on_signs_a_user_in_and_hands_the_session_over_once(demo, idp):
    with demo.client() as c:
        offered = c.get(f"{API}/auth/oidc/providers", params={"tenant": "demo"}).json()
        assert offered == {"items": [{"id": idp.provider_id, "name": "Corp SSO"}]} and c.get(f"{API}/auth/oidc/providers", params={"tenant": "nobody"}).json() == {"items": []}
        query = start_login(c, idp)
        assert query["response_type"] == "code" and query["client_id"] == "churn-client" and query["code_challenge_method"] == "S256"
        assert query["redirect_uri"] == "https://churn.corp.example/api/v1/auth/oidc/callback" and set(query["scope"].split()) == {"openid", "email", "profile"}
        assert len(query["state"]) >= 32 and len(query["nonce"]) >= 32 and "churn_sso" in c.cookies
        idp.claims = {"email": "new.person@corp.example", "sub": "abc-123", "groups": ["everyone", "churn-analysts"]}
        back = finish_login(c, query["state"])
        assert set(back) == {"code"}, back
        exchanged = c.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]})
        assert exchanged.status_code == 200 and exchanged.json()["user"]["email"] == "new.person@corp.example" and exchanged.json()["user"]["role"] == "analyst"
        headers = {"Authorization": "Bearer " + exchanged.json()["token"]}
        me = c.get(f"{API}/auth/me", headers=headers).json()
        assert me["session"]["auth_method"] == "oidc" and me["session"]["identity_provider_id"] == idp.provider_id and "analytics:run" in me["permissions"]
        # the one-time code and the state are spent
        assert c.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]}).status_code == 401
        replay = finish_login(c, query["state"])
        assert replay["error"] == "sso_state_reused"
    token_call = next(form for method, path, form in idp.calls if path == "/token")
    assert token_call["redirect_uri"] == "https://churn.corp.example/api/v1/auth/oidc/callback" and len(token_call["code_verifier"]) >= 43
    with read_session() as s:
        user = s.execute(select(User).where(User.email == "new.person@corp.example")).scalar_one()
        assert (user.tenant_id, user.role, user.external_subject, user.identity_provider_id, user.password_hash) == (demo.tenant_id, "analyst", "abc-123", idp.provider_id, None)
        state = s.execute(select(OidcLoginState).order_by(OidcLoginState.id.desc()).limit(1)).scalar_one()
        assert state.used_at and state.exchanged_at and state.session_token_enc is None, "the session token does not stay in the database"
        assert query["state"] not in (state.state_hash, state.nonce_hash) and len(state.state_hash) == 64
        session = s.execute(select(AuthSession).where(AuthSession.user_id == user.id)).scalar_one()
        assert session.id_token_enc and "." not in session.id_token_enc[:20] and SecretBox().decrypt(session.id_token_enc).count(".") == 2
    assert [e.detail["role"] for e in actions("sso.user_provisioned")] == ["analyst"]
    # a password sign-in for an account that only exists through single sign-on does not work
    with demo.client() as c:
        assert c.post(f"{API}/auth/login", json={"email": "new.person@corp.example", "password": PASSWORD}).status_code == 401


@pytest.mark.req("REQ-SEC-08")
def test_an_existing_account_is_linked_by_verified_email_and_roles_follow_the_identity_provider(demo, idp):
    with demo.client() as c:
        idp.claims = {"email": demo.email("viewer"), "sub": "viewer-sub", "groups": ["churn-admins"]}
        back = finish_login(c, start_login(c, idp)["state"])
        token = c.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]}).json()
        assert token["user"]["email"] == demo.email("viewer")
        # the admin role requires a second factor here, and this provider's second factor is not accepted
    assert "code" in back
    with read_session() as s:
        user = s.execute(select(User).where(User.email == demo.email("viewer"))).scalar_one()
        assert user.external_subject == "viewer-sub" and user.role == "admin"
    assert [e.detail for e in actions("sso.role_updated")] == [{"from": "viewer", "to": "admin", "provider": "Corp SSO"}] and len(actions("sso.account_linked")) == 1
    with demo.client() as c:
        # next time the subject decides, even though the e-mail address at the provider changed
        idp.claims = {"email": "renamed@corp.example", "sub": "viewer-sub", "groups": ["churn-analysts"]}
        back = finish_login(c, start_login(c, idp)["state"])
        assert c.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]}).json()["user"]["email"] == demo.email("viewer")


REFUSALS = [
    ({"claims": {"aud": "another-app"}}, "sso_audience_mismatch"),
    ({"claims": {"aud": ["churn-client", "other"], "azp": "other"}}, "sso_audience_mismatch"),
    ({"claims": {"iss": "https://evil.example"}}, "sso_issuer_mismatch"),
    ({"claims": {"exp": 1_600_000_000}}, "sso_token_expired"),
    ({"claims": {"iat": 4_000_000_000, "exp": 4_000_000_300}}, "sso_token_not_yet_valid"),
    ({"claims": {"nonce": "somebody-elses-nonce"}}, "sso_nonce_mismatch"),
    ({"claims": {"sub": ""}}, "sso_subject_missing"),
    ({"claims": {"email_verified": False}}, "sso_email_unverified"),
    ({"claims": {"email": "someone@elsewhere.example"}}, "sso_domain_refused"),
    ({"algorithm": "none"}, "sso_algorithm_refused"),
    ({"algorithm": "HS256"}, "sso_algorithm_refused"),
    ({"code": "wrong-code"}, "sso_code_refused"),
]


@pytest.mark.req("REQ-SEC-08")
@pytest.mark.parametrize(("change", "code"), REFUSALS, ids=["audience", "audience_azp", "issuer", "expired", "not_yet_valid", "nonce", "subject", "email_unverified",
                                                           "domain", "alg_none", "alg_hs256", "bad_code"])  # fmt: skip
def test_single_sign_on_refuses_tokens_that_do_not_check_out(demo, idp, change, code):
    with demo.client() as c:
        query = start_login(c, idp)
        idp.claims = {"email": "new.person@corp.example", **change.get("claims", {})}
        idp.algorithm = "RS256" if change.get("algorithm") in (None, "HS256") else change["algorithm"]
        if change.get("algorithm") == "HS256":
            original = idp.id_token

            def forged():  # signed correctly, but the header claims a shared-secret algorithm
                import json

                _head, body, signature = original().split(".")
                return f"{FakeIdp.b64(json.dumps({'alg': 'HS256', 'typ': 'JWT', 'kid': 'k1'}).encode())}.{body}.{signature}"

            idp.id_token = forged
        back = finish_login(c, query["state"], change.get("code", "good-code"))
        assert back["error"] == code and "message" in back and "code" not in back
        assert finish_login(c, query["state"])["error"] in ("sso_state_reused", "sso_state_unknown"), "a refused login cannot be tried again with the same state"
    with read_session() as s:
        assert s.execute(select(User).where(User.email == "new.person@corp.example")).first() is None, "nobody was provisioned"
        assert s.execute(select(AuthSession).where(AuthSession.auth_method == "oidc")).first() is None
    refused = [e for e in actions("auth.login_failed") if e.detail.get("method") == "oidc"]
    assert refused[0].detail["reason"] == code


@pytest.mark.req("REQ-SEC-08")
def test_single_sign_on_is_bound_to_the_browser_and_to_keys_the_provider_publishes(demo, idp):
    from cryptography.hazmat.primitives.asymmetric import rsa

    idp.claims = {"email": "new.person@corp.example"}
    with demo.client() as victim, demo.client() as attacker:
        # login CSRF: a state started in the attacker's browser is finished in the victim's
        query = start_login(attacker, idp)
        assert finish_login(victim, query["state"])["error"] == "sso_browser_mismatch"
        # a one-time code issued to one browser cannot be redeemed in another
        back = finish_login(victim, start_login(victim, idp)["state"])
        assert attacker.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]}).status_code == 401
        assert victim.post(f"{API}/auth/oidc/exchange", json={"code": back["code"]}).status_code == 200
        assert finish_login(victim, "a-state-that-was-never-issued")["error"] == "sso_state_unknown"
        # a token signed with a key the provider does not publish
        query = start_login(victim, idp)
        stranger = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        genuine = idp.id_token
        idp.id_token = lambda: genuine(key=stranger)
        assert finish_login(victim, query["state"])["error"] == "sso_signature_invalid"
        idp.id_token = genuine
        # the provider rotates its keys: the new key is fetched once and the login succeeds
        keys_before = sum(1 for _, path, _ in idp.calls if path == "/keys")
        idp.rotate_key("k2")
        back = finish_login(victim, start_login(victim, idp)["state"])
        assert "code" in back and sum(1 for _, path, _ in idp.calls if path == "/keys") == keys_before + 1
        # an expired state
        query = start_login(victim, idp)
        with session_scope() as s:
            s.execute(update(OidcLoginState).where(OidcLoginState.used_at.is_(None)).values(expires_at=utcnow().replace(year=2020)))
        assert finish_login(victim, query["state"])["error"] == "sso_state_expired"


@pytest.mark.req("REQ-SEC-08")
def test_second_factor_rules_hold_for_single_sign_on(demo, idp):
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL="https://churn.corp.example", CHURN_MFA_REQUIRED_ROLES="admin")
    sso.set_transport(idp.transport())
    with demo.client() as c:
        idp.claims = {"email": "boss@corp.example", "sub": "boss", "groups": ["churn-admins"], "amr": ["pwd", "mfa"]}
        refused = finish_login(c, start_login(c, idp)["state"])
        assert refused["error"] == "sso_mfa_required", "the provider's second factor counts only when the administrator said so"
        with session_scope() as s:
            sso.update_provider(s, demo.principal("admin"), idp.provider_id, {"trust_idp_mfa": True})
        accepted = finish_login(c, start_login(c, idp)["state"])
        token = c.post(f"{API}/auth/oidc/exchange", json={"code": accepted["code"]}).json()
        assert token["user"]["role"] == "admin" and token["mfa_enrollment_required"] is False
        assert "admin:users" in c.get(f"{API}/auth/me", headers={"Authorization": "Bearer " + token["token"]}).json()["permissions"]
        idp.claims = {"email": "boss@corp.example", "sub": "boss", "groups": ["churn-admins"], "amr": ["pwd"]}
        assert finish_login(c, start_login(c, idp)["state"])["error"] == "sso_mfa_required", "a password alone at the provider is not a second factor"


@pytest.mark.req("REQ-SEC-08")
def test_identity_providers_are_configured_by_administrators_and_checked_before_use(demo, idp):
    with demo.client() as c:
        admin, analyst = demo.login(c, "admin"), demo.login(c, "analyst")
        listed = c.get(f"{API}/admin/security/identity-providers", headers=admin).json()
        assert listed["redirect_uri"] == "https://churn.corp.example/api/v1/auth/oidc/callback" and listed["public_base_url_set"] is True
        provider = listed["items"][0]
        assert provider["has_client_secret"] is True and "client_secret_enc" not in provider and "jwks_cache" not in provider
        assert c.get(f"{API}/admin/security/identity-providers", headers=analyst).status_code == 403
        tested = c.post(f"{API}/admin/security/identity-providers/{provider['id']}/test", headers=admin, json={}).json()
        assert tested == {"ok": True, "issuer": "https://idp.example", "authorization_endpoint": "https://idp.example/authorize", "token_endpoint": "https://idp.example/token",
                          "signing_keys": 1, "algorithms": ["RS256"]}  # fmt: skip
        for body, field in (({"name": "x", "issuer": "http://idp.example", "client_id": "a"}, "issuer"), ({"name": "x", "issuer": "https://idp.example", "client_id": "a", "scopes": "email"}, "scopes"),
                            ({"name": "x", "issuer": "https://idp.example", "client_id": "a", "role_mapping": {"g": "superuser"}}, "role_mapping"),
                            ({"name": "x", "issuer": "https://idp.example", "client_id": "a", "default_role": "root"}, "default_role")):  # fmt: skip
            bad = c.post(f"{API}/admin/security/identity-providers", headers=admin, json=body)
            assert bad.status_code == 422 and bad.json()["error"]["details"]["field"] == field
        assert c.post(f"{API}/admin/security/identity-providers", headers=admin, json={"name": "Corp SSO", "issuer": "https://idp.example", "client_id": "a"}).status_code == 409
        # switched off: not offered, and a login that was started cannot finish
        query = start_login(c, idp)
        assert c.patch(f"{API}/admin/security/identity-providers/{provider['id']}", headers=admin, json={"enabled": False}).json()["enabled"] is False
        assert c.get(f"{API}/auth/oidc/providers", params={"tenant": "demo"}).json() == {"items": []}
        assert finish_login(c, query["state"])["error"] == "sso_provider_disabled"
        assert c.get(f"{API}/auth/oidc/{provider['id']}/start", follow_redirects=False).status_code == 404
        assert c.delete(f"{API}/admin/security/identity-providers/{provider['id']}", headers=admin).json() == {"ok": True}
    # a discovery document that names another issuer is not accepted, and the problem is kept for the administrator
    idp.discovery_overrides = {"issuer": "https://evil.example"}
    with session_scope() as s:
        provider = sso.create_provider(s, demo.principal("admin"), {"name": "Second", "issuer": "https://idp.example", "client_id": "churn-client"})
        with pytest.raises(ExternalServiceError) as mismatch:
            sso.discover(s, provider, force=True)
        assert "different issuer" in mismatch.value.message and "different issuer" in s.get(IdentityProvider, provider.id).last_error
        with pytest.raises(ValidationFailed):
            sso.update_provider(s, demo.principal("admin"), provider.id, {"issuer": "ftp://idp.example"})
    with session_scope() as s:
        s.execute(delete(OidcLoginState))
