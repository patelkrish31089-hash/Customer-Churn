"""Data-quality rules, scorecards, and four-eyes corrections with full history."""

from __future__ import annotations

from datetime import timedelta

import pytest
from sqlalchemy import select

from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import Conflict, Forbidden, NotFound, ValidationFailed
from churn_platform.models import Correction, Customer, DQFinding, DQRule, DQRun, EntityHistory
from churn_platform.services import quality
from churn_platform.worker.runner import Worker
from tests.test_ingestion import source, upload

pytestmark = pytest.mark.req("REQ-DATA-04")

CUSTOMERS = """customer_id,company,email,industry,employees
C1,Acme Ltd,ops@acme.example,software,120
C2,Beta GmbH,not-an-email,retail,15
C3,Gamma SA,,finance,300
C4,Delta BV,ops@acme.example,,8
"""


@pytest.fixture
def loaded(empty):
    tid = empty.tenant()
    admin, approver = empty.user(tid, "admin"), empty.user(tid, "approver")
    upload(admin, source(admin, "customers", "customers"), "customers.csv", CUSTOMERS)
    fresh = (utcnow() - timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ")
    upload(admin, source(admin, "subscriptions", "subscriptions"), "subs.csv",
           "id,customer_id,start_date,mrr,billing_period\nS1,C1,2025-01-10,100,monthly\nS2,C2,2025-01-10,,monthly\nS3,C3,2025-01-10,50,annual\n")  # fmt: skip
    upload(admin, source(admin, "usage", "usage_events"), "usage.csv",
           f"customer_id,timestamp,event,duration\nC1,{fresh},session,600\nC1,{fresh},session,90000\nC2,{fresh},login,\n")  # fmt: skip
    return empty, tid, admin, approver


def _run(principal, entity_types=None) -> DQRun:
    with session_scope() as s:
        run_id = quality.start_run(s, principal, entity_types)[0].id
    Worker().drain()
    with read_session() as s:
        return s.get(DQRun, run_id)


def test_rules_produce_exact_pass_rates_findings_and_a_weighted_score(loaded):
    _, _tid, admin, _ = loaded
    run = _run(admin)
    assert run.status == "completed" and run.rules_evaluated == len(quality.DEFAULT_RULES)
    rules = {r["name"]: r for r in run.scorecard["rules"]}
    expect = {  # name: (rows_checked, rows_failed)
        "customer_email_present": (4, 1), "customer_email_format": (3, 1), "customer_industry_present": (4, 1),
        "customer_has_subscription": (4, 1), "customer_email_unique": (3, 2), "subscription_mrr_present": (3, 1),
        "subscription_mrr_range": (2, 0), "subscription_billing_period_valid": (3, 0), "usage_duration_range": (2, 1),
        "usage_not_in_future": (3, 0), "usage_data_fresh": (1, 0), "subscription_plan_present": (3, 3),
        "subscription_dates_ordered": (0, 0),
    }  # fmt: skip
    for name, (checked, failed) in expect.items():
        assert (rules[name]["rows_checked"], rules[name]["rows_failed"]) == (checked, failed), name
        if checked == 0:
            assert (rules[name]["pass_rate"], rules[name]["status"]) == (None, "no_data"), name
            continue
        assert rules[name]["pass_rate"] == round(1 - failed / checked, 6), name
        assert rules[name]["status"] == ("pass" if failed == 0 else "fail"), name
    assert {n for n, r in rules.items() if r["rows_failed"]} == {n for n, (_, failed) in expect.items() if failed}, "no other rule fails"
    assert rules["invoice_amount_range"]["status"] == "no_data" and rules["invoice_amount_range"]["pass_rate"] is None
    scored = [r for r in rules.values() if r["pass_rate"] is not None]
    weights = {"error": 3.0, "warning": 2.0, "info": 1.0}
    expected_score = round(sum(weights[r["severity"]] * r["pass_rate"] for r in scored) / sum(weights[r["severity"]] for r in scored), 6)
    assert run.score == run.scorecard["overall"] == expected_score and 0 < run.score < 1
    assert set(run.scorecard["dimensions"]) == set(quality.DIMENSIONS)
    assert run.scorecard["dimensions"]["integrity"] == 0.75 and run.scorecard["dimensions"]["uniqueness"] == round(1 / 3, 6)
    with read_session() as s:
        findings = s.execute(select(DQFinding).where(DQFinding.run_id == run.id)).scalars().all()
        by_rule: dict[str, list] = {}
        for f in findings:
            by_rule.setdefault(f.rule_name, []).append(f)
        assert run.findings_count == len(findings) == sum(failed for _, failed in expect.values())
        assert [f.entity_ref for f in by_rule["customer_email_format"]] == ["C2"] and by_rule["customer_email_format"][0].detail["value"] == "not-an-email"
        assert sorted(f.entity_ref for f in by_rule["customer_email_unique"]) == ["C1", "C4"]
        assert [f.entity_ref for f in by_rule["customer_has_subscription"]] == ["C4"]
        assert by_rule["usage_duration_range"][0].detail == {"value": 90000.0}


def test_scoped_runs_and_stale_data_detection(loaded):
    _, tid, admin, _ = loaded
    run = _run(admin, ["customers"])
    assert {r["entity_type"] for r in run.scorecard["rules"]} == {"customers"}
    with session_scope() as s, pytest.raises(ValidationFailed, match="unknown entity types"):
        quality.start_run(s, admin, ["widgets"])
    with session_scope() as s:
        quality.save_rule(s, admin, tenant_id=tid, name="usage_data_fresh", entity_type="usage_events", rule_type="freshness", severity="warning",
                          params={"field": "occurred_at", "max_age_days": 1})  # fmt: skip
    rule = next(r for r in _run(admin, ["usage_events"]).scorecard["rules"] if r["name"] == "usage_data_fresh")
    assert (rule["status"], rule["version"], rule["rows_failed"]) == ("fail", 2, 1) and "days old" in rule["note"]


def test_rules_are_versioned_and_validated(loaded):
    _, tid, admin, _ = loaded
    with session_scope() as s:
        quality.seed_default_rules(s, tid, admin)
        assert quality.seed_default_rules(s, tid, admin) == 0, "seeding twice creates nothing"
        v2 = quality.save_rule(s, admin, tenant_id=tid, name="subscription_mrr_range", entity_type="subscriptions", rule_type="range", params={"field": "mrr", "min": 60})
        versions = s.execute(select(DQRule).where(DQRule.name == "subscription_mrr_range").order_by(DQRule.version)).scalars().all()
        assert [(r.version, r.is_active) for r in versions] == [(1, False), (2, True)]
        quality.set_rule_active(s, admin, versions[0].id, True)
        assert [(r.version, r.is_active) for r in versions] == [(1, True), (2, False)], "only one version of a rule is active"
        assert v2.dimension == "validity"
    bad = [
        ({"entity_type": "widgets", "rule_type": "not_null", "params": {"field": "x"}}, "entity_type must be one of"),
        ({"entity_type": "customers", "rule_type": "regex", "params": {}}, "rule_type must be one of"),
        ({"entity_type": "customers", "rule_type": "not_null", "params": {}}, "parameters missing: field"),
        ({"entity_type": "customers", "rule_type": "not_null", "params": {"field": "shoe_size"}}, "not a column"),
        ({"entity_type": "customers", "rule_type": "not_null", "params": {"field": "email", "extra": 1}}, "unknown rule parameters"),
        ({"entity_type": "customers", "rule_type": "range", "params": {"field": "employee_count"}}, "min and/or max"),
        ({"entity_type": "customers", "rule_type": "range", "params": {"field": "employee_count", "min": "0; DROP TABLE"}}, "must be a number"),
        ({"entity_type": "customers", "rule_type": "pattern", "params": {"field": "email", "pattern": "(a+)+$"}}, "pattern must be one of"),
        ({"entity_type": "customers", "rule_type": "allowed_values", "params": {"field": "industry", "values": []}}, "missing|non-empty"),
        ({"entity_type": "usage_events", "rule_type": "freshness", "params": {"field": "occurred_at", "max_age_days": -1}}, "positive number"),
        ({"entity_type": "usage_events", "rule_type": "has_related", "params": {"related_entity": "customers"}}, "do not reference"),
    ]  # fmt: skip
    for kwargs, message in bad:
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            quality.save_rule(s, admin, tenant_id=tid, name="bad rule", **kwargs)
    with session_scope() as s, pytest.raises(ValidationFailed, match="severity"):
        quality.save_rule(s, admin, tenant_id=tid, name="x", entity_type="customers", rule_type="not_null", params={"field": "email"}, severity="fatal")


@pytest.mark.req("REQ-GOV-01")
def test_corrections_need_a_second_person_and_keep_the_before_and_after(loaded):
    _empty, tid, admin, approver = loaded
    run = _run(admin, ["customers"])
    with read_session() as s:
        customer_id = s.execute(select(Customer.id).where(Customer.external_id == "C2")).scalar_one()
        finding_id = s.execute(select(DQFinding.id).where(DQFinding.run_id == run.id, DQFinding.rule_name == "customer_email_format")).scalar_one()
    with session_scope() as s:
        cid = quality.propose_correction(s, admin, entity_type="customers", entity_id=customer_id, field="email", new_value="hello@beta.example",
                                         reason="confirmed with the account owner", finding_id=finding_id).id  # fmt: skip
        assert s.get(Customer, customer_id).email == "not-an-email", "nothing changes until the correction is approved"
    with session_scope() as s, pytest.raises(Forbidden) as exc:
        quality.review_correction(s, admin, cid, approve=True)
    assert exc.value.code == "self_approval_forbidden"
    with session_scope() as s:
        assert quality.review_correction(s, approver, cid, approve=True, note="ok").status == "applied"
    with read_session() as s:
        row = s.get(Customer, customer_id)
        assert (row.email, row.record_version) == ("hello@beta.example", 2)
        history = s.execute(select(EntityHistory).where(EntityHistory.entity_id == customer_id)).scalar_one()
        assert (history.before, history.after, history.change_source, history.correction_id, history.changed_by) == (
            {"email": "not-an-email"}, {"email": "hello@beta.example"}, "correction", cid, approver.user_id)  # fmt: skip
        assert s.get(DQFinding, finding_id).status == "corrected"
        view = quality.record_history(s, tid, "customers", customer_id)
        assert view["record"]["email"] == "hello@beta.example" and len(view["history"]) == 1
    with session_scope() as s, pytest.raises(Conflict, match="already applied"):
        quality.review_correction(s, approver, cid, approve=False)
    # the approved value survives a re-import of the stale source file, which still says "not-an-email"
    with read_session() as s:
        source_id = s.execute(select(Customer.dataset_version_id).where(Customer.id == customer_id)).scalar_one()
    from churn_platform.models import DatasetVersion
    from churn_platform.services import ingestion

    with session_scope() as s:
        dv = s.get(DatasetVersion, source_id)
        rerun_id = ingestion.start_import(s, admin, dv.source_id, dataset_version_id=dv.id)[0].id
    Worker().drain()
    with read_session() as s:
        from churn_platform.models import ImportRun

        rerun = s.get(ImportRun, rerun_id)
        assert s.get(Customer, customer_id).email == "hello@beta.example"
        assert rerun.reconciliation["fields_protected_by_approved_corrections"] == 1 and rerun.status == "completed"


def test_correction_validation_rejection_and_staleness(loaded):
    empty, _tid, admin, approver = loaded
    with read_session() as s:
        ids = dict(s.execute(select(Customer.external_id, Customer.id)).all())
    bad = [
        ({"entity_type": "widgets", "entity_id": 1, "field": "x", "new_value": 1, "reason": "because yes"}, "entity_type must be one of"),
        ({"entity_type": "customers", "entity_id": ids["C1"], "field": "email", "new_value": "a@b.example", "reason": "no"}, "at least 5 characters"),
        ({"entity_type": "customers", "entity_id": ids["C1"], "field": "external_id", "new_value": "C9", "reason": "rename it"}, "cannot be corrected"),
        ({"entity_type": "customers", "entity_id": ids["C1"], "field": "tenant_id", "new_value": 2, "reason": "move tenant"}, "cannot be corrected"),
        ({"entity_type": "customers", "entity_id": ids["C1"], "field": "employee_count", "new_value": "many", "reason": "typo fix"}, "not valid for employee_count"),
        ({"entity_type": "customers", "entity_id": ids["C1"], "field": "employee_count", "new_value": 120, "reason": "same value"}, "identical"),
    ]  # fmt: skip
    for kwargs, message in bad:
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            quality.propose_correction(s, admin, **kwargs)
    stranger = empty.user(empty.tenant("other", "Other"), "admin")
    with session_scope() as s, pytest.raises(NotFound):
        quality.propose_correction(s, stranger, entity_type="customers", entity_id=ids["C1"], field="industry", new_value="media", reason="cross-tenant attempt")
    with session_scope() as s:
        rejected = quality.propose_correction(s, admin, entity_type="customers", entity_id=ids["C1"], field="industry", new_value="media", reason="reclassified").id
        stale = quality.propose_correction(s, admin, entity_type="customers", entity_id=ids["C4"], field="industry", new_value="media", reason="fill the gap").id
        cleared = quality.propose_correction(s, admin, entity_type="customers", entity_id=ids["C3"], field="industry", new_value="", reason="unknown industry").id
    with session_scope() as s:
        assert quality.review_correction(s, approver, rejected, approve=False, note="keep").status == "rejected"
        assert s.get(Customer, ids["C1"]).industry == "software"
        s.get(Customer, ids["C4"]).industry = "changed meanwhile"
    with session_scope() as s, pytest.raises(Conflict) as exc:
        quality.review_correction(s, approver, stale, approve=True)
    assert exc.value.code == "stale_correction"
    with session_scope() as s, pytest.raises(NotFound):
        quality.review_correction(s, stranger, cleared, approve=True)
    with session_scope() as s:
        quality.review_correction(s, approver, cleared, approve=True)
        assert s.get(Customer, ids["C3"]).industry is None and s.get(Correction, cleared).new_value is None
