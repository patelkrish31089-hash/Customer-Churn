"""Retention tiers (white-glove, automated, involuntary), eligibility blocks, review, execution and outcomes."""

from __future__ import annotations

from datetime import timedelta
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import func, select

from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import Conflict, Forbidden, NotFound, ValidationFailed
from churn_platform.models import (
    Account,
    AuditEvent,
    Customer,
    DataSource,
    FeatureContract,
    Intervention,
    Job,
    Prediction,
    PredictionBatch,
    RetentionRecommendation,
)
from churn_platform.services import experiments, features, policies, predictions, retention
from churn_platform.worker.runner import Worker
from tests.test_ingestion import upload

pytestmark = pytest.mark.req("REQ-ACT-01")
RISK = policies.RiskPolicy()
PLAYBOOK = policies.RetentionPlaybook.model_validate(policies.DEFAULT_PLAYBOOK)


def _scored(rows: list[dict]) -> pd.DataFrame:
    base = {"risk_tier": "low", "mrr": 100.0, "days_to_card_expiry": np.nan, "days_since_last_failed_payment": np.nan, "last_payment_failed": 0.0}
    return pd.DataFrame([{**base, **row} for row in rows])


# ----------------------------------------------------------------------------- tiering
def test_segments_follow_risk_tier_value_and_payment_triggers():
    frame = _scored([
        {"name": "top risk, top value", "risk_tier": "high", "mrr": 900.0},
        {"name": "top risk, small account", "risk_tier": "high", "mrr": 20.0},
        {"name": "rising risk, small account", "risk_tier": "medium", "mrr": 30.0},
        {"name": "rising risk, big account", "risk_tier": "medium", "mrr": 800.0},
        {"name": "low risk, big account", "risk_tier": "low", "mrr": 1000.0},
        {"name": "low risk, card expires in 10 days", "mrr": 40.0, "days_to_card_expiry": 10.0},
        {"name": "top risk and value, payment just failed", "risk_tier": "high", "mrr": 950.0, "days_since_last_failed_payment": 3.0, "last_payment_failed": 1.0},
        {"name": "card expires in 15 days", "mrr": 50.0, "days_to_card_expiry": 15.0},
        {"name": "card expires in 16 days", "mrr": 60.0, "days_to_card_expiry": 16.0},
        {"name": "card already expired", "mrr": 70.0, "days_to_card_expiry": -4.0},
        {"name": "old failure, since recovered", "mrr": 80.0, "days_since_last_failed_payment": 5.0, "last_payment_failed": 0.0},
        {"name": "failure outside the lookback", "mrr": 90.0, "days_since_last_failed_payment": 45.0, "last_payment_failed": 1.0},
    ])  # fmt: skip
    out = retention.classify(frame, RISK).set_index("name")
    assert out["segment"].to_dict() == {
        "top risk, top value": "high_risk_high_value",
        "top risk, small account": "medium_risk_low_value",  # not enough revenue for a personal call: automated tier
        "rising risk, small account": "medium_risk_low_value",
        "rising risk, big account": None,
        "low risk, big account": None,
        "low risk, card expires in 10 days": "involuntary",
        "top risk and value, payment just failed": "involuntary",  # fixing the payment comes first
        "card expires in 15 days": "involuntary",
        "card expires in 16 days": None,
        "card already expired": "involuntary",
        "old failure, since recovered": None,
        "failure outside the lookback": None,
    }
    assert out.loc["top risk, top value", "high_value"] and not out.loc["top risk, small account", "high_value"]
    assert out["value_percentile"].between(0, 1).all() and out["value_percentile"].idxmax() == "low risk, big account"
    assert (out["high_value"] == (out["value_percentile"] >= RISK.high_value_percentile)).all(), "high value = top 30% of MRR by default"
    assert out.loc["card already expired", "card_expiring"] and out.loc["top risk and value, payment just failed", "payment_failing"]
    stricter = retention.classify(frame, policies.RiskPolicy(involuntary_payment_expiry_days=30)).set_index("name")
    assert stricter.loc["card expires in 16 days", "segment"] == "involuntary", "the trigger window is policy"


def test_playbook_action_per_segment():
    def action(segment, group=None):
        chosen = retention.choose_action(PLAYBOOK, segment, group)
        return chosen and (chosen.code, chosen.channel, chosen.requires_human_review)

    assert action("high_risk_high_value") == ("csm_white_glove_call", "crm_task", True), "a person decides and makes the call"
    assert action("medium_risk_low_value", "usage") == ("reengagement_drip", "email", False)
    assert action("medium_risk_low_value", "financial") == ("retention_discount_offer", "email", True), "a discount is offered when price is the issue"
    assert action("involuntary", "financial") == ("payment_method_reminder", "in_app", False)
    offer = retention.choose_action(PLAYBOOK, "medium_risk_low_value", "financial").offer
    assert offer == {"discount_pct": 15, "is_example": True}, "the 15% figure is the brief's example, flagged as such"
    only_calls = policies.RetentionPlaybook(actions=[PLAYBOOK.actions[0]])
    assert retention.choose_action(only_calls, "involuntary", None) is None
    assert set(retention.FEATURE_GROUPS.values()) <= {"usage", "support", "financial", "rfm", "customer"}


# ----------------------------------------------------------------------------- the seeded recommendations
def test_seeded_recommendations_are_consistent_with_scores_features_and_policies(ro):
    with read_session() as s:
        batch = s.get(PredictionBatch, ro.summary["batch_id"])
        recs = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch.id)).scalars().all()
        preds = {p.customer_id: p for p in s.execute(select(Prediction).where(Prediction.batch_id == batch.id)).scalars()}
        contract = s.get(FeatureContract, next(iter(preds.values())).contract_id)
        vectors = features.offline_frame(s, ro.tenant_id, contract, dates=[batch.as_of_date])
        customers = {c.id: c for c in s.execute(select(Customer)).scalars()}
        owners = dict(s.execute(select(Account.customer_id, Account.csm_owner)).all())
        generated = s.execute(select(AuditEvent.detail).where(AuditEvent.action == "retention.recommendations_generated")
                              .order_by(AuditEvent.id.desc())).scalars().first()  # fmt: skip
    frame = pd.DataFrame([{"customer_id": cid, "risk_tier": p.risk_tier} for cid, p in preds.items()])
    expected = retention.classify(frame.merge(vectors[["customer_id", *retention.NEEDED]], on="customer_id"), RISK).set_index("customer_id")
    by_customer = {r.customer_id: r for r in recs}
    assert len(by_customer) == len(recs), "one recommendation per customer"
    assert {cid: r.segment for cid, r in by_customer.items()} == expected["segment"].dropna().to_dict(), "every covered customer, no one else"
    counts = pd.Series([r.segment for r in recs]).value_counts().to_dict()
    assert set(counts) == {"high_risk_high_value", "medium_risk_low_value", "involuntary"}, counts
    high = [cid for cid, p in preds.items() if p.risk_tier == "high"]
    assert all(cid in by_customer for cid in high), "nobody in the top risk tier is left without a proposed action"
    assert generated["created"] == len(recs) and generated["by_segment"] == counts and generated["blocked"] == sum(r.status == "blocked" for r in recs)
    assert generated["not_covered_by_playbook"] == len(preds) - len(recs) == sum(generated["not_covered_detail"].values())
    assert set(generated["not_covered_detail"]) <= {"low_risk", "medium_risk_high_value"}
    assert generated["playbook"]["source"] == "approved policy" and generated["carried_over"] == 0
    assert generated["uplift"] == {"applied": False, "model_id": None, "scored_for_this_batch": False,
                                   "note": "no approved uplift model: targeting is by risk and value only"}  # fmt: skip
    for rec in recs:
        action = next(a for a in PLAYBOOK.actions if a.code == rec.action_code)
        why = rec.rationale
        assert action.segment == rec.segment and rec.channel == action.channel and rec.priority == retention.PRIORITY[rec.segment]
        assert rec.prediction_id == preds[rec.customer_id].id and why["probability"] == preds[rec.customer_id].probability
        assert why["top_reasons"] == preds[rec.customer_id].top_reasons and why["requires_human_review"] == action.requires_human_review
        assert why["disclaimer"].startswith("Decision support only") and rec.assigned_to == owners.get(rec.customer_id)
        assert len(why["talking_points"]) <= len(why["top_reasons"]) and all(point in PLAYBOOK.reason_plays.values() for point in why["talking_points"])
        consent = customers[rec.customer_id].consent_marketing
        if action.requires_marketing_consent and consent is not True:
            assert (rec.status, rec.blocked_reason) == ("blocked", "marketing consent is not recorded for this customer")
        else:
            assert rec.status == "proposed" and rec.blocked_reason is None
        assert rec.eligibility == {"consent_required": action.requires_marketing_consent, "consent_marketing": consent, "in_cooldown": False}
        if rec.segment == "involuntary":
            assert why["payment_triggers"], "the payment trigger is spelled out"
            assert action.requires_marketing_consent is False, "a payment reminder is transactional"
    assert counts == {"high_risk_high_value": 4, "involuntary": 41, "medium_risk_low_value": 46}
    assert sum(r.status == "blocked" for r in recs) == 3 and sum(r.action_code == "retention_discount_offer" for r in recs) == 1
    assert generated["not_covered_detail"] == {"low_risk": 110, "medium_risk_high_value": 11}


# ----------------------------------------------------------------------------- review, execution, outcomes
def _pick(action_code: str, status: str = "proposed") -> RetentionRecommendation:
    with read_session() as s:
        return s.execute(select(RetentionRecommendation).where(RetentionRecommendation.action_code == action_code, RetentionRecommendation.status == status)
                         .order_by(RetentionRecommendation.id)).scalars().first()  # fmt: skip


def test_white_glove_actions_need_an_approver_and_execution_records_an_intervention(demo):
    csm, approver = demo.principal("csm"), demo.principal("approver")
    call = _pick("csm_white_glove_call")
    with session_scope() as s, pytest.raises(Conflict) as early:
        retention.execute(s, csm, call.id)
    assert early.value.code == "not_approved"
    with session_scope() as s, pytest.raises(Forbidden) as not_allowed:
        retention.review(s, csm, call.id, approve=True)
    assert not_allowed.value.code == "approval_required"
    with session_scope() as s:
        approved = retention.review(s, approver, call.id, approve=True, note="call this week")
        assert (approved.status, approved.reviewed_by) == ("approved", approver.user_id) and approved.reviewed_at is not None
    with session_scope() as s, pytest.raises(Conflict, match="only a proposed recommendation"):
        retention.review(s, approver, call.id, approve=True)
    with session_scope() as s:
        result = retention.execute(s, csm, call.id)
    intervention = result["intervention"]
    assert result["recommendation"]["status"] == "executed" and result["crm_delivery_id"] is None
    assert (intervention["status"], intervention["customer_id"], intervention["action_code"]) == ("recorded", call.customer_id, "csm_white_glove_call")
    assert "nothing was sent" in intervention["note"] and intervention["outcome"] is None and intervention["created_by"] == csm.user_id
    with session_scope() as s, pytest.raises(Conflict, match="already been executed"):
        retention.execute(s, csm, call.id)
    # outcomes
    with session_scope() as s, pytest.raises(ValidationFailed, match="outcome must be"):
        retention.record_outcome(s, csm, intervention["id"], "saved")
    with session_scope() as s:
        item = retention.record_outcome(s, csm, intervention["id"], "retained", note="renewed after the training session")
        assert (item.outcome, item.note) == ("retained", "renewed after the training session") and item.outcome_at is not None
        summary = retention.summary(s, demo.tenant_id)
        assert summary["interventions_by_outcome"] == {"retained": 1} and summary["by_segment"]["high_risk_high_value"]["executed"] == 1
        assert "Only a randomised experiment can attribute retention to an action" in summary["note"]
        actions = s.execute(select(AuditEvent.action).where(AuditEvent.actor_label.in_([csm.email, approver.email])).order_by(AuditEvent.id)).scalars().all()
    assert actions[-3:] == ["retention.recommendation_approved", "retention.recommendation_executed", "retention.outcome_recorded"]
    with session_scope() as s, pytest.raises(NotFound):
        retention.record_outcome(s, csm, 999_999, "churned")


def test_automated_actions_run_without_review_and_blocked_or_dismissed_ones_never_run(demo):
    csm = demo.principal("csm")
    reminder, blocked, drip = _pick("payment_method_reminder"), _pick("reengagement_drip", "blocked"), _pick("reengagement_drip")
    with session_scope() as s:
        done = retention.execute(s, csm, reminder.id)
        assert done["recommendation"]["status"] == "executed" and done["recommendation"]["reviewed_by"] == csm.user_id
    with session_scope() as s, pytest.raises(Conflict) as is_blocked:
        retention.execute(s, csm, blocked.id)
    assert is_blocked.value.code == "not_approved"
    with session_scope() as s, pytest.raises(Conflict):
        retention.review(s, csm, blocked.id, approve=True)
    with session_scope() as s:
        assert retention.review(s, csm, drip.id, approve=False, note="customer already in a renewal conversation").status == "dismissed"
    with session_scope() as s, pytest.raises(Conflict):
        retention.execute(s, csm, drip.id)
    with session_scope() as s, pytest.raises(NotFound):
        retention.execute(s, csm, 999_999)
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(Intervention)).scalar_one() == 1


def test_regeneration_keeps_decisions_and_applies_the_contact_cool_down(demo):
    csm, admin = demo.principal("csm"), demo.principal("admin")
    batch_id = demo.summary["batch_id"]
    executed, dismissed, pending = _pick("payment_method_reminder"), _pick("reengagement_drip"), None
    with read_session() as s:
        before = s.execute(select(func.count()).select_from(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id)).scalar_one()
        pending = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.status == "proposed", RetentionRecommendation.batch_id == batch_id,
                                                                  RetentionRecommendation.id.not_in([executed.id, dismissed.id]))).scalars().first()  # fmt: skip
    with session_scope() as s:
        retention.execute(s, csm, executed.id)
        retention.review(s, csm, dismissed.id, approve=False)
        # somebody contacted this customer yesterday through another campaign
        s.add(Intervention(tenant_id=demo.tenant_id, customer_id=pending.customer_id, action_code="webinar_invite", channel="email",
                           status="delivered", delivered_at=utcnow() - timedelta(days=1)))  # fmt: skip
        job = retention.start_generation(s, admin, batch_id)
        assert job.job_type == "retention.generate"
    Worker().drain()
    with read_session() as s:
        recs = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id)).scalars().all()
        by_customer = {r.customer_id: r for r in recs}
    assert len(recs) == len(by_customer) == before, "no duplicates and nothing lost"
    assert by_customer[executed.customer_id].id == executed.id and by_customer[executed.customer_id].status == "executed"
    assert by_customer[dismissed.customer_id].id == dismissed.id and by_customer[dismissed.customer_id].status == "dismissed", "a dismissal is not re-proposed"
    cooled = by_customer[pending.customer_id]
    assert (cooled.status, cooled.blocked_reason) == ("blocked", "contacted within the last 14 days (cool-down)") and cooled.eligibility["in_cooldown"] is True
    assert by_customer[executed.customer_id].status == "executed"
    with session_scope() as s:
        single = PredictionBatch(tenant_id=demo.tenant_id, model_version_id=1, as_of_date=pending.created_at.date(), kind="single", status="completed",
                                 idempotency_key="single:test")  # fmt: skip
        s.add(single)
        s.flush()
        with pytest.raises(Conflict, match="completed batch prediction run"):
            retention.start_generation(s, admin, single.id)
        with pytest.raises(NotFound):
            retention.start_generation(s, admin, 999_999)


@pytest.mark.req("REQ-ACT-03")
def test_approved_uplift_segments_block_sleeping_dogs_and_prioritise_persuadables(demo, monkeypatch):
    admin = demo.principal("admin")
    batch_id = demo.summary["batch_id"]
    with read_session() as s:
        recs = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id, RetentionRecommendation.status == "proposed")
                         .order_by(RetentionRecommendation.id)).scalars().all()  # fmt: skip
    drip_a, drip_b = [r for r in recs if r.action_code == "reengagement_drip"][:2]
    reminder = next(r for r in recs if r.segment == "involuntary")
    segments = {drip_a.customer_id: "sleeping_dog", drip_b.customer_id: "persuadable", reminder.customer_id: "sleeping_dog"}
    monkeypatch.setattr(experiments, "approved_model", lambda session, tenant_id: SimpleNamespace(id=77, contract_id=demo.summary["contract_id"], reviewed_at=None))
    monkeypatch.setattr(experiments, "stored_segments", lambda session, model_id, as_of: segments if model_id == 77 else {})
    with session_scope() as s:
        retention.start_generation(s, admin, batch_id)
    Worker().drain()
    with read_session() as s:
        by_customer = {r.customer_id: r for r in s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id)).scalars()}
        detail = s.execute(select(AuditEvent.detail).where(AuditEvent.action == "retention.recommendations_generated").order_by(AuditEvent.id.desc())).scalars().first()
    dog, persuadable, payment = by_customer[drip_a.customer_id], by_customer[drip_b.customer_id], by_customer[reminder.customer_id]
    assert dog.status == "blocked" and "sleeping dog" in dog.blocked_reason and dog.rationale["uplift_segment"] == "sleeping_dog"
    assert (persuadable.status, persuadable.priority, persuadable.rationale["uplift_segment"]) == ("proposed", 0, "persuadable"), "persuadables go first"
    assert payment.status == "proposed" and payment.priority == retention.PRIORITY["involuntary"], "a payment reminder is transactional and still goes out"
    assert detail["uplift"] == {"applied": True, "model_id": 77, "scored_for_this_batch": False, "note": "approved uplift model #77 applied"}
    untouched = [r for cid, r in by_customer.items() if cid not in segments and r.status == "proposed"]
    assert untouched and all(r.priority == retention.PRIORITY[r.segment] and r.rationale["uplift_segment"] is None for r in untouched)


# ----------------------------------------------------------------------------- the work queue across scoring dates
def test_the_work_queue_shows_the_newest_scoring_date_and_approved_work_is_carried_over(demo):
    """DEF-031: with nightly scoring the list mixed every proposal ever made, and a customer approved yesterday was proposed again today."""
    admin, csm, approver = demo.principal("admin"), demo.principal("csm"), demo.principal("approver")
    first_batch = demo.summary["batch_id"]
    call, drip, other_drip = _pick("csm_white_glove_call"), _pick("reengagement_drip"), None
    with read_session() as s:
        before = retention.listing(s, demo.tenant_id)
        other_drip = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.action_code == "reengagement_drip",
                               RetentionRecommendation.status == "proposed", RetentionRecommendation.id != drip.id).order_by(RetentionRecommendation.id)).scalars().first()  # fmt: skip
    assert before["total"] == 91 and before["scope"] == {"mode": "current", "batch_id": first_batch, "as_of_date": "2026-11-01"}
    assert before["summary"]["uplift_model_in_force"] is None
    with session_scope() as s:
        retention.review(s, approver, call.id, approve=True)  # approved, not yet carried out
        retention.review(s, csm, drip.id, approve=True)
        retention.review(s, csm, other_drip.id, approve=False)  # dismissed: a fresh look tomorrow is wanted
    # new usage data arrives and the next scoring date comes round (the nightly pipeline scores the same customers again)
    with read_session() as s:
        usage_source = s.execute(select(DataSource.id).where(DataSource.entity_type == "usage_events")).scalar_one()
    run = upload(admin, usage_source, "usage_2_november.csv", "customer_id,timestamp,event,feature,duration_seconds,count\n"
                 "C000001,2026-11-02T08:00:00Z,login,,120,1\n", mode="incremental")  # fmt: skip
    assert run.status == "completed" and run.rows_inserted == 1
    with session_scope() as s:
        batch, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-11-03", kind="scheduled")
        second_batch = batch.id
    demo.drain()
    with session_scope() as s:
        retention.start_generation(s, admin, second_batch)
    worker = demo.drain()
    assert worker is not None
    with read_session() as s:
        result = s.execute(select(Job.result).where(Job.job_type == "retention.generate").order_by(Job.id.desc())).scalars().first()
        new = {r.customer_id: r for r in s.execute(select(RetentionRecommendation).where(RetentionRecommendation.batch_id == second_batch)).scalars()}
        queue = retention.listing(s, demo.tenant_id, page_size=500)
        only_new = retention.listing(s, demo.tenant_id, batch_id=second_batch, page_size=500)
        only_old = retention.listing(s, demo.tenant_id, batch_id=first_batch, page_size=500)
        everything = retention.listing(s, demo.tenant_id, scope="all", page_size=500)
        with pytest.raises(ValidationFailed, match="scope must be"):
            retention.listing(s, demo.tenant_id, scope="mine")
        with pytest.raises(NotFound):
            retention.listing(s, demo.tenant_id, batch_id=999_999)
    assert result["carried_over"] == 2, "the two customers with an approved action waiting are not proposed again"
    assert call.customer_id not in new and drip.customer_id not in new
    assert other_drip.customer_id in new, "a dismissed proposal does not stop tomorrow's proposal"
    assert queue["scope"] == {"mode": "current", "batch_id": second_batch, "as_of_date": "2026-11-03"}
    ids = {item["id"] for item in queue["items"]}
    assert ids == {r.id for r in new.values()} | {call.id, drip.id}, "today's proposals plus the approved work that is still open"
    assert queue["total"] == len(new) + 2 == only_new["total"] + 2 and only_old["total"] == 91
    assert everything["total"] == 91 + len(new) and everything["scope"]["mode"] == "all"
    assert sum(n for by_status in queue["summary"]["by_segment"].values() for n in by_status.values()) == queue["total"]
    assert queue["summary"]["by_segment"]["high_risk_high_value"]["approved"] == 1
    # carrying the approved action out removes it from the open work; an approved action can also be withdrawn
    with session_scope() as s:
        retention.execute(s, csm, call.id)
        withdrawn = retention.review(s, csm, drip.id, approve=False, note="customer cancelled the meeting")
        assert withdrawn.status == "dismissed"
    with session_scope() as s, pytest.raises(Conflict, match="only a proposed recommendation"):
        retention.review(s, csm, drip.id, approve=False)
    with read_session() as s:
        after = retention.listing(s, demo.tenant_id, page_size=500)
        event = s.execute(select(AuditEvent.detail).where(AuditEvent.action == "retention.recommendation_dismissed").order_by(AuditEvent.id.desc())).scalars().first()
    assert after["total"] == len(new) and {item["id"] for item in after["items"]} == {r.id for r in new.values()}
    assert event["withdrawn"] is True and event["note"] == "customer cancelled the meeting"
