"""Reverse ETL to CRM tools: request shapes, the outbox, retries, TEST_ONLY / SANDBOX / PRODUCTION modes, SSRF guard.

Outbound HTTP is the one thing replaced in this suite: ``httpx.MockTransport`` plays the vendor.
"""

from __future__ import annotations

import importlib.util
import json
import socket
from pathlib import Path

import httpx
import pytest
from sqlalchemy import func, select

from churn_platform import netguard
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, NotFound, ValidationFailed
from churn_platform.models import CRMConnection, CRMDelivery, Customer, Intervention, Job, Prediction, RetentionRecommendation
from churn_platform.security import ROLE_PERMISSIONS, Principal
from churn_platform.services import auth, crm, retention
from churn_platform.worker.runner import Worker
from tests.conftest import PASSWORD, activate

pytestmark = pytest.mark.req("REQ-ACT-02")
PUBLIC_IP = "93.184.216.34"
TOKEN = "sandbox-token-3f9a"
RISK = {"external_id": "C000123", "probability": 0.812345, "risk_tier": "high", "top_reasons": ["No login for 21 days", "Open ticket for 3 days"], "as_of_date": "2026-11-01"}
TASK = {"external_id": "C000123", "subject": "[Churn risk] Senior CSM call - Acme", "body": "Churn probability: 81.2%", "priority": 1, "segment": "high_risk_high_value",
        "action_code": "csm_white_glove_call", "created_at": "2026-11-01T08:00:00+00:00", "created_epoch": 1793520000}  # fmt: skip


class Vendor:
    """Scripted CRM endpoint: answers with the queued responses (the last one repeats) and records every request."""

    def __init__(self, *script: httpx.Response | Exception) -> None:
        self.script, self.requests = list(script) or [httpx.Response(200, json={"id": "0015g00000XyZ"})], []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        step = self.script.pop(0) if len(self.script) > 1 else self.script[0]
        if isinstance(step, Exception):
            raise step
        return step


@pytest.fixture
def dns(monkeypatch) -> dict[str, list[str]]:
    """Name resolution for vendor hosts (a routable address, nothing is ever connected to)."""
    table = {"acme.my.salesforce.test": [PUBLIC_IP], "api.hubapi.test": [PUBLIC_IP], "api.intercom.test": [PUBLIC_IP]}
    real = socket.getaddrinfo

    def resolve(host, port, *args, **kwargs):
        if host in table:
            return [(socket.AF_INET6 if ":" in address else socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, port)) for address in table[host]]
        if str(host).endswith(".test"):
            raise socket.gaierror(socket.EAI_NONAME, "Name or service not known")
        return real(host, port, *args, **kwargs)

    monkeypatch.setattr(netguard.socket, "getaddrinfo", resolve)
    return table


def _connect(principal, provider="salesforce", mode="SANDBOX", host="acme.my.salesforce.test", **kw) -> int:
    with session_scope() as s:
        return crm.create_connection(s, principal, provider=provider, name=kw.pop("name", f"{provider} {mode}"), base_url=f"https://{host}", mode=mode,
                                     access_token=None if mode == "TEST_ONLY" else TOKEN, **kw).id  # fmt: skip


def _queue(principal, connection_id: int, key: str = "one", kind: str = "risk_score", payload: dict | None = None) -> int:
    with session_scope() as s:
        return crm.enqueue_delivery(s, principal, s.get(CRMConnection, connection_id), customer_id=None, kind=kind, payload=payload or RISK, key=key).id


def _delivery(delivery_id: int) -> CRMDelivery:
    with read_session() as s:
        return s.get(CRMDelivery, delivery_id)


# ----------------------------------------------------------------------------- request shapes
def _unsaved(provider: str, base_url: str, **mapping) -> CRMConnection:
    return CRMConnection(provider=provider, base_url=base_url, field_mapping={**crm.DEFAULT_MAPPING[provider], **mapping})


def test_salesforce_requests():
    sf = _unsaved("salesforce", "https://acme.my.salesforce.test")
    assert crm.build_request(sf, "risk_score", RISK) == {
        "method": "PATCH", "url": "https://acme.my.salesforce.test/services/data/v61.0/sobjects/Account/External_Id__c/C000123",
        "params": {"updateOnly": "true"},  # an unknown customer is reported as not found, never created in the CRM
        "json": {"Churn_Probability__c": 0.812345, "Churn_Risk_Tier__c": "high", "Churn_Top_Reasons__c": "No login for 21 days; Open ticket for 3 days",
                 "Churn_Scored_On__c": "2026-11-01"}}  # fmt: skip
    task = crm.build_request(sf, "task", TASK)
    assert (task["method"], task["url"]) == ("POST", "https://acme.my.salesforce.test/services/data/v61.0/sobjects/Task")
    assert task["json"] == {"Subject": TASK["subject"], "Description": TASK["body"], "Priority": "High", "Status": "Not Started",
                            "What": {"attributes": {"type": "Account"}, "External_Id__c": "C000123"}}  # fmt: skip
    assert crm.build_request(sf, "task", {**TASK, "priority": 3})["json"]["Priority"] == "Normal"
    custom = _unsaved("salesforce", "https://acme.my.salesforce.test", object="Contract", probability="Risk__c", api_version="v62.0")
    request = crm.build_request(custom, "risk_score", RISK)
    assert request["url"].endswith("/services/data/v62.0/sobjects/Contract/External_Id__c/C000123") and request["json"]["Risk__c"] == 0.812345


def test_hubspot_and_intercom_requests():
    hubspot = _unsaved("hubspot", "https://api.hubapi.test")
    assert crm.build_request(hubspot, "risk_score", RISK) == {
        "method": "PATCH", "url": "https://api.hubapi.test/crm/v3/objects/companies/C000123", "params": {"idProperty": "external_customer_id"},
        "json": {"properties": {"churn_probability": "0.812345", "churn_risk_tier": "high", "churn_top_reasons": "No login for 21 days; Open ticket for 3 days",
                                "churn_scored_on": "2026-11-01"}}}  # fmt: skip
    assert [crm.build_request(hubspot, "risk_score", {**RISK, "probability": p})["json"]["properties"]["churn_probability"]
            for p in (0.5, 1.0, 0.0, 0.00001234, 1e-9)] == ["0.5", "1", "0", "0.000012", "0"], "a plain decimal number as text, never an exponent"  # fmt: skip
    task = crm.build_request(hubspot, "task", TASK)
    assert task["url"] == "https://api.hubapi.test/crm/v3/objects/tasks" and task["json"] == {"associations": [], "properties": {
        "hs_task_subject": TASK["subject"], "hs_task_body": TASK["body"], "hs_task_status": "NOT_STARTED", "hs_task_priority": "HIGH",
        "hs_timestamp": "2026-11-01T08:00:00.000Z", "churn_platform_customer_id": "C000123"}}  # fmt: skip
    intercom = _unsaved("intercom", "https://api.intercom.test")
    assert crm.build_request(intercom, "risk_score", RISK) == {
        "method": "POST", "url": "https://api.intercom.test/companies", "headers": {"Intercom-Version": "2.14"},
        "json": {"company_id": "C000123", "custom_attributes": {"churn_probability": 0.812345, "churn_risk_tier": "high",
                                                                "churn_top_reasons": "No login for 21 days; Open ticket for 3 days", "churn_scored_on": "2026-11-01"}}}  # fmt: skip
    # a recommended action is written to the company as well: Intercom accepts an event only for a contact
    action = crm.build_request(intercom, "task", TASK)
    assert action == {"method": "POST", "url": "https://api.intercom.test/companies", "headers": {"Intercom-Version": "2.14"},
                      "json": {"company_id": "C000123", "custom_attributes": {
                          "churn_recommended_action": "csm_white_glove_call", "churn_action_subject": TASK["subject"],
                          "churn_action_recommended_at": 1793520000, "churn_action_segment": "high_risk_high_value"}}}  # fmt: skip
    without_segment = crm.build_request(intercom, "task", {**TASK, "segment": None, "subject": "s" * 400})["json"]["custom_attributes"]
    assert "churn_action_segment" not in without_segment and len(without_segment["churn_action_subject"]) == 255
    # a connection saved before these mapping keys existed still builds a complete request, and its own choices win
    older = CRMConnection(provider="intercom", base_url="https://api.intercom.test", field_mapping={"probability": "risk", "event_prefix": "churn_platform"})
    assert crm.build_request(older, "risk_score", RISK)["json"]["custom_attributes"]["risk"] == 0.812345
    assert crm.build_request(older, "task", TASK)["json"]["custom_attributes"]["churn_recommended_action"] == "csm_white_glove_call"
    pinned = crm.build_request(_unsaved("intercom", "https://api.intercom.test", api_version="2.11"), "risk_score", RISK)
    assert pinned["headers"] == {"Intercom-Version": "2.11"}
    long_reasons = crm.build_request(hubspot, "risk_score", {**RISK, "top_reasons": ["x" * 200, "y" * 200]})
    assert len(long_reasons["json"]["properties"]["churn_top_reasons"]) == 255, "kept within the usual CRM text-field limit"


def _contract_checker():
    """scripts/check_crm_contracts.py as a module (it is a script, not part of the package)."""
    spec = importlib.util.spec_from_file_location("check_crm_contracts", Path(__file__).resolve().parents[1] / "scripts" / "check_crm_contracts.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_the_contract_checker_reports_what_a_vendor_description_forbids():
    """The checker is only worth running if it objects to a wrong request.  A small description, written here in
    the shape the vendors use, and the mistakes release 1.0.0 made against the real ones."""
    check = _contract_checker()
    text = {"type": "object", "additionalProperties": {"type": "string"}}
    document = {
        "servers": [{"url": "https://api.vendor.test"}],
        "components": {"schemas": {"Create": {"type": "object", "required": ["associations", "properties"],
                                              "properties": {"properties": text, "associations": {"type": "array", "items": {"type": "object", "required": ["to"]}}}}}},
        "paths": {
            "/crm/v3/objects/tasks": {"post": {"requestBody": {"content": {"application/json": {"schema": {"$ref": "#/components/schemas/Create"}}}}}},
            "/crm/v3/objects/companies/{companyId}": {"patch": {
                "parameters": [{"name": "companyId", "in": "path", "required": True}, {"name": "idProperty", "in": "query"}],
                "requestBody": {"content": {"application/json": {"schema": {"type": "object", "required": ["properties"], "properties": {"properties": text}}}}}}},
            "/events": {"post": {
                "parameters": [{"name": "Vendor-Version", "in": "header", "schema": {"type": "string", "enum": ["2.13", "2.14"]}}],
                "requestBody": {"content": {"application/json": {"schema": {
                    "type": "object", "properties": {"event_name": {"type": "string"}, "created_at": {"type": "integer"}},
                    "anyOf": [{"required": ["event_name", "created_at", "id"]}, {"required": ["event_name", "created_at", "email"]}]}}}}}},
            "/companies": {"post": {"requestBody": {"content": {"application/json": {"schema": {"type": "object", "properties": {
                "company_id": {"type": "string"}, "custom_attributes": {**text, "example": {"paid": True, "spend": 155.5}}}}}}}}},
        },
    }  # fmt: skip
    base = "https://api.vendor.test"

    def found(method: str, path: str, body: dict, **extra) -> list[str]:
        return check.check_request(document, base, {"method": method, "url": base + path, "json": body, **extra})

    assert found("POST", "/crm/v3/objects/tasks", {"properties": {"subject": "call"}, "associations": []}) == []
    assert found("POST", "/crm/v3/objects/tasks", {"properties": {"subject": "call"}}) == ["body: required member 'associations' is missing"]
    assert found("POST", "/crm/v3/objects/tasks", {"properties": {}, "associations": [{}]}) == ["body.associations[0]: required member 'to' is missing"]
    patch = "/crm/v3/objects/companies/C000123"
    assert found("PATCH", patch, {"properties": {"churn_probability": "0.81"}}, params={"idProperty": "external_customer_id"}) == []
    assert found("PATCH", patch, {"properties": {"churn_probability": 0.81}}) == ["body.properties.churn_probability: expected string, got float (0.81)"]
    assert found("PATCH", patch, {"properties": {"won": True}}) == ["body.properties.won: expected string, got bool (True)"]
    assert found("PATCH", patch, {"properties": {}}, params={"updateOnly": "true"}) == [
        "query parameter 'updateOnly' is not declared by PATCH /crm/v3/objects/companies/{companyId}"]
    assert found("PUT", patch, {"properties": {}}) == ["/crm/v3/objects/companies/{companyId} does not accept PUT (it accepts PATCH)"]
    assert found("PATCH", "/crm/v3/objects/companies/C1/extra", {}) == ["no path in the description matches /crm/v3/objects/companies/C1/extra"]
    assert check.check_request(document, "https://elsewhere.test", {"method": "POST", "url": "https://elsewhere.test/events", "json": {}}) == [
        "https://elsewhere.test is not a server of this description (https://api.vendor.test)"]
    # an event without a contact: none of the alternatives is satisfied
    event = {"event_name": "churn_platform_call", "created_at": 1793520000, "metadata": {"company_id": "C000123"}}
    assert found("POST", "/events", event) == ["body: matches 0 of the 2 alternatives of anyOf (closest: body: required member 'id' is missing)"]
    assert found("POST", "/events", {**event, "id": "6657"}, headers={"vendor-version": "2.14"}) == []
    assert found("POST", "/events", {**event, "id": "6657"}, headers={"Vendor-Version": "1.0"}) == ["header parameter 'Vendor-Version': '1.0' is not one of ['2.13', '2.14']"]
    assert found("POST", "/events", {**event, "id": "6657", "created_at": "2026-11-01"})[0] == "body.created_at: expected integer, got str ('2026-11-01')"
    # a description whose own example breaks the type it declares proves nothing: reported, not enforced
    assert found("POST", "/companies", {"company_id": "C000123", "custom_attributes": {"churn_probability": 0.81}}) == []
    assert len(check.NOTES) == 1 and "breaks the value type it declares (string)" in next(iter(check.NOTES))
    assert found("POST", "/companies", {"company_id": 123}) == ["body.company_id: expected string, got int (123)"]


def test_the_contract_checker_runs_on_the_requests_the_connectors_build(tmp_path, capsys):
    """End to end on local files: the checker builds the HubSpot and Intercom requests with the product's own code
    and exits 0 only when all of them conform.  (The vendors' real descriptions are downloaded when the script is
    run without --spec-dir; that run needs the network and is not part of this suite.)"""
    check = _contract_checker()
    assert [(name, label) for name, _base, label, _request in check.built_requests()] == [
        ("hubspot-companies.json", "HubSpot risk score"), ("hubspot-tasks.json", "HubSpot task"),
        ("intercom.yaml", "Intercom risk score"), ("intercom.yaml", "Intercom recommended action")]
    properties = {"type": "object", "additionalProperties": {"type": "string"}}

    def operation(schema: dict, *parameters: dict) -> dict:
        return {"parameters": list(parameters), "requestBody": {"content": {"application/json": {"schema": schema}}}}

    companies = {"info": {"title": "Companies", "version": "v3"}, "servers": [{"url": "https://api.hubapi.com"}], "paths": {
        "/crm/v3/objects/companies/{companyId}": {"patch": operation({"type": "object", "required": ["properties"], "properties": {"properties": properties}},
                                                                     {"name": "idProperty", "in": "query"})}}}  # fmt: skip
    tasks = {"info": {"title": "Tasks", "version": "v3"}, "servers": [{"url": "https://api.hubapi.com"}], "paths": {
        "/crm/v3/objects/tasks": {"post": operation({"type": "object", "required": ["associations", "properties"],
                                                     "properties": {"properties": properties, "associations": {"type": "array"}}})}}}  # fmt: skip
    intercom = {"info": {"title": "Intercom API", "version": "2.14"}, "servers": [{"url": "https://api.intercom.io"}], "paths": {
        "/companies": {"post": operation({"type": "object", "properties": {"company_id": {"type": "string"}, "custom_attributes": {"type": "object"}}},
                                         {"name": "Intercom-Version", "in": "header", "schema": {"type": "string", "enum": ["2.13", "2.14"]}})}}}  # fmt: skip
    (tmp_path / "hubspot-companies.json").write_text(json.dumps(companies))
    (tmp_path / "hubspot-tasks.json").write_text(json.dumps(tasks))
    (tmp_path / "intercom.yaml").write_text(json.dumps(intercom))  # JSON is YAML
    assert check.main(["--spec-dir", str(tmp_path)]) == 0
    assert "4 of 4 requests conform to the vendor's description" in capsys.readouterr().out
    # the vendor withdraws an API version: the run fails and names the request
    intercom["paths"]["/companies"]["post"]["parameters"][0]["schema"]["enum"] = ["2.15"]
    (tmp_path / "intercom.yaml").write_text(json.dumps(intercom))
    assert check.main(["--spec-dir", str(tmp_path)]) == 1
    out = capsys.readouterr().out
    assert "FAIL  Intercom risk score" in out and "'2.14' is not one of ['2.15']" in out and "2 of 4 requests conform" in out
    (tmp_path / "hubspot-tasks.json").unlink()
    assert check.main(["--spec-dir", str(tmp_path)]) == 2, "a description that cannot be read is an error of its own, not a pass"
    capsys.readouterr()


@pytest.mark.req("REQ-SEC-05")
@pytest.mark.parametrize("hostile", ["../../../services/oauth2/revoke", "C1/../../Opportunity/006", "C1?_HttpMethod=DELETE", "C1#fragment", "C 1%2F..", "ü/é"])
def test_identifiers_from_imported_data_cannot_change_the_request_path(hostile):
    for provider, base, prefix in (("salesforce", "https://acme.my.salesforce.test", "/services/data/v61.0/sobjects/Account/External_Id__c/"),
                                   ("hubspot", "https://api.hubapi.test", "/crm/v3/objects/companies/")):  # fmt: skip
        url = httpx.URL(crm.build_request(_unsaved(provider, base), "risk_score", {**RISK, "external_id": hostile})["url"])
        sent = httpx.Request("PATCH", url).url.raw_path.decode()  # the request target as it goes on the wire
        assert sent.startswith(prefix) and "/" not in sent[len(prefix):] and "?" not in sent, "the id stays one path segment"
        assert url.query == b"" and url.fragment == "" and url.path[len(prefix):] == hostile, "and it still addresses exactly that id"
    mapped = crm.build_request(_unsaved("salesforce", "https://acme.my.salesforce.test", object="Account/../../../x"), "risk_score", RISK)
    assert "/sobjects/Account%2F..%2F..%2F..%2Fx/External_Id__c/C000123" in mapped["url"], "mapping values are escaped as well"


@pytest.mark.req("REQ-SEC-05")
def test_an_identifier_that_would_address_the_parent_resource_is_never_sent(demo, dns):
    # an HTTP client collapses ".../External_Id__c/.." to the parent path, so such ids are refused outright
    for bad in ("..", ".", "", "   "):
        with pytest.raises(ValidationFailed, match="cannot be used as an identifier"):
            crm.build_request(_unsaved("salesforce", "https://acme.my.salesforce.test"), "risk_score", {**RISK, "external_id": bad})
    admin = demo.principal("admin")
    vendor = Vendor()
    crm.set_transport(httpx.MockTransport(vendor))
    delivery_id = _queue(admin, _connect(admin), payload={**RISK, "external_id": ".."})
    assert crm.deliver(delivery_id)["status"] == "dead" and vendor.requests == []
    assert _delivery(delivery_id).last_error == "request not built: '..' cannot be used as an identifier in a CRM request path"


# ----------------------------------------------------------------------------- connections
def test_connection_rules_and_secrets_at_rest(demo, dns):
    admin = demo.principal("admin")
    bad = [({"provider": "zendesk"}, "provider must be one of"), ({"mode": "LIVE"}, "mode must be one of"), ({"name": "  "}, "name is required"),
           ({"mode": "SANDBOX", "access_token": None}, "access token is required"), ({"field_mapping": {"colour": "x"}}, "unknown mapping keys: colour"),
           ({"base_url": "ftp://files.example.test"}, "absolute http"), ({"base_url": "https://user:secret@acme.my.salesforce.test"}, "must not contain credentials"),
           ({"base_url": "not a url"}, "absolute http"),
           # a Salesforce API older than 61.0 ignores updateOnly and would create accounts for unknown customers
           ({"field_mapping": {"api_version": "v60.0"}}, "v61.0 or later"), ({"field_mapping": {"api_version": "61"}}, "must look like v61.0"),
           ({"provider": "intercom", "base_url": "https://api.intercom.test", "field_mapping": {"api_version": "latest"}}, "must look like 2.14")]  # fmt: skip
    for overrides, message in bad:
        args = {"provider": "salesforce", "name": "Salesforce", "base_url": "https://acme.my.salesforce.test", "mode": "TEST_ONLY", **overrides}
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            crm.create_connection(s, admin, **args)
    with session_scope() as s, pytest.raises(Conflict) as production:
        crm.create_connection(s, admin, provider="salesforce", name="Live", base_url="https://acme.my.salesforce.test", mode="PRODUCTION", access_token=TOKEN)
    assert production.value.code == "crm_production_disabled", "production delivery is off unless the deployment enables it"
    connection_id = _connect(admin, field_mapping={"object": "Contract"})
    with read_session() as s:
        connection = s.get(CRMConnection, connection_id)
        view = crm.connection_view(connection)
    assert connection.credentials_enc and TOKEN not in connection.credentials_enc, "the token is encrypted at rest"
    assert crm._box().decrypt(connection.credentials_enc) == TOKEN
    assert view["has_credentials"] is True and "credentials_enc" not in view and TOKEN not in str(view)
    assert view["field_mapping"]["object"] == "Contract" and view["field_mapping"]["probability"] == "Churn_Probability__c", "overrides merge into the defaults"
    assert (view["mode"], view["status"], view["base_url"]) == ("SANDBOX", "unverified", "https://acme.my.salesforce.test")
    with session_scope() as s, pytest.raises(Conflict, match="already exists"):
        crm.create_connection(s, admin, provider="salesforce", name="salesforce SANDBOX", base_url="https://acme.my.salesforce.test")
    activate(demo.db_path, demo.data_dir, CHURN_ENV="staging", CHURN_DATABASE_URL="postgresql+psycopg://u:p@db.internal/churn",
             CHURN_SECRET_KEY="k" * 40)  # only the settings are consulted below
    from churn_platform.config import get_settings

    assert get_settings().is_production_like
    with pytest.raises(ValidationFailed, match="only https"):
        netguard.vet("http://acme.my.salesforce.test")


@pytest.mark.req("REQ-SEC-05")
def test_connections_cannot_point_at_internal_addresses(demo, dns):
    admin = demo.principal("admin")
    dns["rebind.test"] = [PUBLIC_IP, "10.0.0.5"]
    dns["mapped.test"] = ["::ffff:127.0.0.1"]
    for host, reason in (("127.0.0.1", "non-public"), ("localhost", "non-public"), ("169.254.169.254", "non-public"), ("10.1.2.3", "non-public"),
                         ("100.64.0.9", "non-public"), ("[::1]", "non-public"), ("rebind.test", "non-public"), ("mapped.test", "non-public"),
                         ("unknown-vendor.test", "cannot resolve")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed, match=reason):
            crm.create_connection(s, admin, provider="hubspot", name=f"to {host}", base_url=f"https://{host}", mode="SANDBOX", access_token=TOKEN)
    # a TEST_ONLY connection never transmits, so a placeholder host is acceptable there
    assert _connect(admin, mode="TEST_ONLY", host="unknown-vendor.test", name="placeholder") > 0
    pinned = netguard.vet("https://acme.my.salesforce.test:8443/a/b?c=d")
    assert pinned.url == f"https://{PUBLIC_IP}:8443/a/b?c=d" and pinned.headers == {"Host": "acme.my.salesforce.test:8443"}
    assert pinned.extensions == {"sni_hostname": "acme.my.salesforce.test"} and pinned.address == PUBLIC_IP
    dns["v6.test"] = ["2606:2800:220:1:248:1893:25c8:1946"]
    assert netguard.vet("https://v6.test/x").url == "https://[2606:2800:220:1:248:1893:25c8:1946]/x"
    literal = netguard.vet(f"https://{PUBLIC_IP}/x")
    assert literal.url == f"https://{PUBLIC_IP}/x" and literal.headers == {} and literal.extensions == {}
    addresses = (PUBLIC_IP, "192.168.1.1", "224.0.0.1", "0.0.0.0", "fe80::1%eth0", "fc00::1")  # noqa: S104 - classified, never bound
    assert [netguard.is_public(a) for a in addresses] == [True] + [False] * 5


# ----------------------------------------------------------------------------- delivery
def test_seeded_test_only_sync_built_every_request_and_sent_nothing(ro):
    with read_session() as s:
        connection = s.execute(select(CRMConnection)).scalar_one()
        deliveries = s.execute(select(CRMDelivery)).scalars().all()
        high = {p.id: p for p in s.execute(select(Prediction).where(Prediction.batch_id == ro.summary["batch_id"], Prediction.risk_tier == "high")).scalars()}
        external = dict(s.execute(select(Customer.id, Customer.external_id)).all())
        jobs = s.execute(select(func.count()).select_from(Job).where(Job.job_type == "crm.deliver", Job.status == "succeeded")).scalar_one()
    assert (connection.mode, connection.provider, connection.status, connection.credentials_enc) == ("TEST_ONLY", "hubspot", "test_only", None)
    assert len(deliveries) == len(high) == jobs == 22, "one update per customer in the top risk tier"
    by_customer = {d.customer_id: d for d in deliveries}
    for prediction in high.values():
        delivery = by_customer[prediction.customer_id]
        assert (delivery.status, delivery.kind, delivery.attempts, delivery.sent_at) == ("skipped", "risk_score", 1, None)
        assert delivery.idempotency_key == f"{connection.id}:risk_score:pred:{prediction.id}"
        response = delivery.response
        assert response["sent"] is False and response["mode"] == "TEST_ONLY" and "not transmitted" in response["note"]
        request = response["request"]
        assert request["method"] == "PATCH" and request["url"] == f"{connection.base_url}/crm/v3/objects/companies/{external[prediction.customer_id]}"
        properties = request["json"]["properties"]
        sent = properties["churn_probability"]  # HubSpot takes every property value as text
        assert isinstance(sent, str) and "e" not in sent and float(sent) == round(prediction.probability, 6) and properties["churn_risk_tier"] == "high"
        assert properties["churn_top_reasons"] == "; ".join(r["text"] for r in prediction.top_reasons)[:255] and properties["churn_scored_on"] == "2026-11-01"
        assert len(prediction.top_reasons) == 3, "user id, probability, tier and the top three reasons are what gets synchronised"


def test_sandbox_sync_sends_authenticated_idempotent_requests_to_the_vetted_address(demo, dns):
    admin = demo.principal("admin")
    vendor = Vendor()
    crm.set_transport(httpx.MockTransport(vendor))
    connection_id = _connect(admin)
    with session_scope() as s:
        queued = crm.sync_risk_scores(s, admin, connection_id, demo.summary["batch_id"], tiers=("high",))
    assert queued == {"queued": 22, "already_queued": 0, "mode": "SANDBOX"}
    demo.drain()
    with read_session() as s:
        deliveries = s.execute(select(CRMDelivery).where(CRMDelivery.connection_id == connection_id)).scalars().all()
        connection = s.get(CRMConnection, connection_id)
    assert len(vendor.requests) == 22 and {d.status for d in deliveries} == {"sent"} and connection.status == "ok" and connection.last_error is None
    assert all(d.external_id == "0015g00000XyZ" and d.sent_at is not None and d.attempts == 1 and d.response == {"status_code": 200, "mode": "SANDBOX"} for d in deliveries)
    keys = set()
    for request in vendor.requests:
        assert request.method == "PATCH" and request.url.host == PUBLIC_IP, "the request goes to the address that was vetted"
        assert request.headers["host"] == "acme.my.salesforce.test" and request.extensions["sni_hostname"] == "acme.my.salesforce.test"
        assert request.url.path.startswith("/services/data/v61.0/sobjects/Account/External_Id__c/C")
        assert request.headers["authorization"] == f"Bearer {TOKEN}" and request.headers["accept"] == "application/json"
        keys.add(request.headers["idempotency-key"])
    assert keys == {d.idempotency_key for d in deliveries} and len(keys) == 22
    assert TOKEN not in str([(d.payload, d.response, d.last_error) for d in deliveries]), "the token is never stored with a delivery"
    # asking again does not create or send anything twice
    with session_scope() as s:
        assert crm.sync_risk_scores(s, admin, connection_id, demo.summary["batch_id"], tiers=("high",)) == {"queued": 0, "already_queued": 22, "mode": "SANDBOX"}
    demo.drain()
    assert len(vendor.requests) == 22
    assert crm.deliver(deliveries[0].id) == {"delivery_id": deliveries[0].id, "status": "sent", "note": "already final"} and len(vendor.requests) == 22
    with session_scope() as s, pytest.raises(NotFound):
        crm.sync_risk_scores(s, admin, 999_999, demo.summary["batch_id"])
    with session_scope() as s, pytest.raises(NotFound):
        crm.sync_risk_scores(s, admin, connection_id, 999_999)


def test_transient_failures_are_retried_with_backoff_and_then_parked(demo, dns):
    admin = demo.principal("admin")
    connection_id = _connect(admin)
    vendor = Vendor(httpx.Response(503, text="upstream busy"), httpx.ConnectTimeout("timed out"), httpx.Response(429, text="slow down"), httpx.Response(502),
                    httpx.Response(500, text="still broken"))  # fmt: skip
    crm.set_transport(httpx.MockTransport(vendor))
    delivery_id = _queue(admin, connection_id)
    waits = []
    for attempt in range(1, 6):
        before = _delivery(delivery_id)
        result = crm.deliver(delivery_id)
        after = _delivery(delivery_id)
        assert result["attempts"] == after.attempts == attempt == len(vendor.requests)
        if attempt < 5:
            assert after.status == "failed" and after.sent_at is None
            waits.append(round((after.next_attempt_at - before.created_at).total_seconds() / 60))
            with read_session() as s:
                retry = s.execute(select(Job).where(Job.idempotency_key == f"crm.deliver:{delivery_id}:{attempt}")).scalar_one()
            assert retry.status == "queued" and retry.run_after == after.next_attempt_at, "the retry is a scheduled job, not a sleeping worker"
    assert waits == [1, 2, 4, 8], "exponential backoff: 1, 2, 4, 8 minutes"
    parked = _delivery(delivery_id)
    assert (parked.status, parked.attempts, parked.next_attempt_at) == ("dead", crm.MAX_ATTEMPTS, None) and parked.last_error == "HTTP 500: still broken"
    with read_session() as s:
        assert s.get(CRMConnection, connection_id).status == "error" and s.get(CRMConnection, connection_id).last_error == "HTTP 500: still broken"
        assert s.execute(select(func.count()).select_from(Job).where(Job.idempotency_key == f"crm.deliver:{delivery_id}:5")).scalar_one() == 0
    assert crm.deliver(delivery_id)["note"] == "already final" and len(vendor.requests) == 5
    Worker().drain()  # retries are scheduled in the future: nothing is due, nothing is re-sent
    assert len(vendor.requests) == 5
    assert all(request.headers["idempotency-key"] == parked.idempotency_key for request in vendor.requests), "every attempt carries the same key"


@pytest.mark.parametrize(("response", "status", "error"), [
    (httpx.Response(400, text='{"message": "No such column"}'), "dead", 'HTTP 400: {"message": "No such column"}'),
    (httpx.Response(401, text="expired"), "dead", "HTTP 401: expired"),
    (httpx.Response(404), "dead", "HTTP 404: "),
    (httpx.Response(302, headers={"location": "http://169.254.169.254/latest/meta-data"}), "dead", "HTTP 302: "),
    (httpx.Response(408), "failed", "HTTP 408: "),
    (httpx.ReadTimeout("no answer"), "failed", "ReadTimeout: no answer"),
    (httpx.Response(204), "sent", None),
    (httpx.Response(200, content=b"<html>ok</html>", headers={"content-type": "application/json"}), "sent", None),
    (httpx.Response(201, json=["unexpected", "list"]), "sent", None),
])  # fmt: skip
def test_delivery_outcome_by_vendor_response(demo, dns, response, status, error):
    admin = demo.principal("admin")
    vendor = Vendor(response)
    crm.set_transport(httpx.MockTransport(vendor))
    delivery_id = _queue(admin, _connect(admin, provider="hubspot", host="api.hubapi.test"))
    assert crm.deliver(delivery_id)["status"] == status
    delivery = _delivery(delivery_id)
    assert (delivery.status, delivery.last_error, delivery.external_id) == (status, error, None)
    assert len(vendor.requests) == 1, "exactly one request: a redirect is not followed and a client error is not retried"
    assert (delivery.next_attempt_at is None) == (status == "dead") or status == "sent"
    assert vendor.requests[0].url.params["idProperty"] == "external_customer_id"


@pytest.mark.req("REQ-SEC-05")
def test_a_host_that_turns_internal_after_setup_is_refused_at_send_time(demo, dns):
    admin = demo.principal("admin")
    vendor = Vendor()
    crm.set_transport(httpx.MockTransport(vendor))
    connection_id = _connect(admin)
    first, second, third = (_queue(admin, connection_id, key=key) for key in ("a", "b", "c"))
    assert crm.deliver(first)["status"] == "sent" and len(vendor.requests) == 1
    dns["acme.my.salesforce.test"] = ["127.0.0.1"]  # DNS rebinding: the name now points inside the network
    assert crm.deliver(second)["status"] == "dead"
    refused = _delivery(second)
    assert refused.last_error == "request refused: URL resolves to a non-public address, which is not allowed" and refused.next_attempt_at is None
    assert len(vendor.requests) == 1, "nothing was transmitted"
    del dns["acme.my.salesforce.test"]  # a DNS outage, on the other hand, is worth retrying
    assert crm.deliver(third)["status"] == "failed"
    waiting = _delivery(third)
    assert waiting.last_error.startswith("request refused: cannot resolve host") and waiting.next_attempt_at is not None and len(vendor.requests) == 1


def test_production_mode_needs_the_deployment_switch_at_setup_and_at_send_time(demo, dns):
    activate(demo.db_path, demo.data_dir, CHURN_CRM_ALLOW_PRODUCTION="true")
    admin = demo.principal("admin")
    vendor = Vendor(httpx.Response(201, json={"id": 4711}))
    crm.set_transport(httpx.MockTransport(vendor))
    connection_id = _connect(admin, mode="PRODUCTION")
    first, second = _queue(admin, connection_id, key="a"), _queue(admin, connection_id, key="b")
    assert crm.deliver(first)["status"] == "sent" and _delivery(first).external_id == "4711"
    activate(demo.db_path, demo.data_dir, CHURN_CRM_ALLOW_PRODUCTION="false")  # the switch is turned off again
    assert crm.deliver(second)["status"] == "dead"
    assert _delivery(second).last_error == "PRODUCTION deliveries are disabled by configuration" and len(vendor.requests) == 1


def test_executing_a_recommendation_through_a_connection_queues_a_crm_task(demo):
    admin, approver, csm = demo.principal("admin"), demo.principal("approver"), demo.principal("csm")
    crm.set_transport(httpx.MockTransport(lambda request: pytest.fail("a TEST_ONLY connection must never transmit")))
    connection_id = _connect(admin, mode="TEST_ONLY")
    with read_session() as s:
        call = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.action_code == "csm_white_glove_call")).scalars().first()
        reminder = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.action_code == "payment_method_reminder")).scalars().first()
        customer = s.get(Customer, call.customer_id)
    with session_scope() as s:
        retention.review(s, approver, call.id, approve=True)
    with session_scope() as s:
        done = retention.execute(s, csm, call.id, connection_id=connection_id)
        other = retention.execute(s, csm, reminder.id, connection_id=connection_id)
    assert done["intervention"]["status"] == "queued_for_crm" and done["intervention"]["note"] is None and done["crm_delivery_id"]
    demo.drain()
    task, action = _delivery(done["crm_delivery_id"]), _delivery(other["crm_delivery_id"])
    assert (task.kind, task.status, task.customer_id, task.created_by) == ("task", "skipped", call.customer_id, csm.user_id)
    assert (action.kind, action.status) == ("action", "skipped"), "an in-app reminder is not a CRM task"
    request = task.response["request"]
    assert request["url"].endswith("/sobjects/Task") and request["json"]["Priority"] == "High" and request["json"]["What"]["External_Id__c"] == customer.external_id
    assert request["json"]["Subject"] == f"[Churn risk] Senior CSM call (white-glove) - {customer.name}"
    body = request["json"]["Description"].splitlines()
    assert body[0] == f"Churn probability: {call.rationale['probability']:.1%} (tier: high)"
    assert body[1] == "Top model factors: " + "; ".join(r["text"] for r in call.rationale["top_reasons"])
    assert [line for line in body if line.startswith("Talking point: ")] == [f"Talking point: {t}" for t in call.rationale["talking_points"]]
    assert body[-1] == "Model factors describe the prediction; they are not established causes."
    with read_session() as s:
        assert s.get(RetentionRecommendation, call.id).crm_delivery_id == task.id and s.execute(select(func.count()).select_from(Intervention)).scalar_one() == 2


@pytest.mark.req("REQ-SEC-04")
def test_connections_and_deliveries_are_tenant_scoped(demo, dns):
    admin = demo.principal("admin")
    connection_id = _connect(admin, mode="TEST_ONLY")
    with session_scope() as s:
        tenant_id = auth.create_tenant(s, "other", "Other Ltd").id
        user = auth.create_user(s, tenant_id=tenant_id, email="admin@other.example", full_name="Other Admin", role="admin", password=PASSWORD)
        outsider = Principal(user_id=user.id, tenant_id=tenant_id, email=user.email, role="admin", session_id=0, permissions=ROLE_PERMISSIONS["admin"])
    with session_scope() as s, pytest.raises(NotFound, match=f"CRM connection {connection_id} was not found"):
        crm.sync_risk_scores(s, outsider, connection_id, demo.summary["batch_id"])
    with read_session() as s:
        rec = s.execute(select(RetentionRecommendation).where(RetentionRecommendation.status == "proposed")).scalars().first()
    with session_scope() as s, pytest.raises(NotFound):
        retention.execute(s, outsider, rec.id, connection_id=connection_id)
    assert _connect(outsider, mode="TEST_ONLY") != connection_id, "the same connection name is free in another tenant"


@pytest.mark.req("REQ-ACT-02")
def test_an_oauth_connection_can_be_opened_before_anybody_has_authorised_it(demo, dns):
    """The consent screen comes after the connection exists: a connection that signs in with OAuth is created
    without an access token (the token is what the CRM issues at the end of the flow, not the other way round)."""
    with demo.client() as c:
        headers = demo.login(c, "admin")
        body = {"provider": "hubspot", "name": "HubSpot via consent", "base_url": "https://api.hubapi.com", "mode": "TEST_ONLY", "auth_type": "oauth"}
        created = c.post("/api/v1/crm/connections", json=body, headers=headers)
        assert created.status_code == 201, created.text
        view = created.json()
        assert (view["auth_type"], view["status"], view["has_credentials"]) == ("oauth", "unverified", False)
        # the same connection with a token as its way in, and no token: refused, as before
        naive = c.post("/api/v1/crm/connections", json={**body, "name": "HubSpot without a token", "auth_type": "token", "mode": "SANDBOX"}, headers=headers)
        assert naive.status_code == 422 and "access token" in naive.text
        # and an unknown auth_type is refused rather than stored
        wrong = c.post("/api/v1/crm/connections", json={**body, "name": "HubSpot odd", "auth_type": "magic"}, headers=headers)
        assert wrong.status_code == 422 and "auth_type" in wrong.text
