"""The outbox, the run record and the tenant checkpoint (1.3.0).

The pipeline in ``destinations/base`` says what happened while the process was running.  These tables are how that
survives the process: a run that stops after twenty of fifty records leaves thirty rows behind in ``PENDING`` or
``FAILED``, the checkpoint stays where the last acknowledged record was, and a resumed run asks the database what is
outstanding instead of re-deriving it from a count.

What is asserted here, and why each one matters:

* the migration is **additive and reversible** — ``upgrade`` adds exactly three tables and ``downgrade`` removes them,
  leaving every table of 1.2.0 untouched (checked against the migration script itself and against a real database);
* a run is recorded **once per (tenant, destination, run_id)** — a retried job updates its row rather than writing a
  second history that disagrees with the first;
* the per-record state is written for **every** record — acknowledged, failed and quarantined — because the backlog is
  what a restart resumes from;
* the checkpoint **only moves forward** and it is **per tenant**;
* a record that failed stops the watermark even when later records were acknowledged, and the resumed run sends exactly
  the ones that were not.

The PostgreSQL case runs when ``CHURN_TEST_POSTGRES_URL`` is set, which the release run always sets; without it the test
skips locally and the release run fails the skip (``CHURN_TEST_STRICT=1``) rather than passing on a guess.
"""

from __future__ import annotations

import importlib.util
from datetime import UTC, datetime
from pathlib import Path

import pytest
from sqlalchemy import inspect, text

from churn_platform import dbadmin
from churn_platform.db import dispose_engine, session_scope
from churn_platform.services import export_outbox as outbox
from churn_platform.services import export_record as record
from churn_platform.services.destinations.base import RetryPolicy, deliver

pytestmark = pytest.mark.req("REQ-ACT-02")

ROOT = Path(__file__).resolve().parents[1]
APPROVED = "a" * 64
TABLES = ("export_runs", "export_outbox", "export_checkpoints")


def _row(customer: str = "C000001", *, day: int = 5, tenant: int = 1, probability: float = 0.81) -> dict:
    return {
        "tenant_id": tenant,
        "customer_id": 7,
        "account_id": None,
        "external_customer_id": customer,
        "crm_contact_id": None,
        "churn_probability": probability,
        "risk_tier": "high",
        "risk_decile": 1,
        "prediction_horizon_days": 30,
        "prediction_timestamp": datetime(2026, 11, day, 6, tzinfo=UTC),
        "data_cutoff_timestamp": datetime(2026, 11, day, tzinfo=UTC),
        "model_name": "churn-gbm",
        "model_version": "4",
        "feature_version": "contract-3",
        "model_checksum": APPROVED,
        "top_reason_1": "No login for 21 days",
        "top_reason_2": None,
        "top_reason_3": None,
        "recommended_intervention": "Success call",
        "approval_status": "approved",
    }


class Refusing:
    name = "snowflake"

    def __init__(self, *refused: str):
        self.refused = set(refused)
        self.rows: list[dict] = []

    def test_connection(self):
        return {"ok": True}

    def ensure_schema(self):
        return None

    def write(self, records, *, run_id):
        for item in records:
            if item["external_customer_id"] in self.refused:
                raise ValueError(f"refused {item['external_customer_id']}")
        self.rows.extend(records)
        return len(self.rows)

    def count_stored(self, *, run_id):
        return len(self.rows)


# --------------------------------------------------------------------------- the migration itself
def test_migration_0005_is_additive_reversible_and_revises_0004():
    path = ROOT / "src" / "churn_platform" / "migrations" / "versions" / "0005_export_outbox.py"
    spec = importlib.util.spec_from_file_location("migration_0005", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    assert module.revision == "0005" and module.down_revision == "0004"
    source = path.read_text()
    assert source.count("op.create_table(") == 3, "three tables, and no existing table is altered"
    assert "op.drop_column" not in source and "op.alter_column" not in source, "nothing of 1.2.0 is changed"
    assert source.count("op.drop_table(") == 3, "the downgrade removes exactly what the upgrade created"


def test_the_migrated_database_has_the_tables_and_the_constraints(demo):
    from churn_platform.db import read_session

    expected = {
        "export_runs": ("uq_export_runs_identity", ["tenant_id", "destination", "run_id"]),
        "export_outbox": ("uq_export_outbox_idempotency", ["destination", "idempotency_key"]),
        "export_checkpoints": ("uq_export_checkpoints_identity", ["tenant_id", "destination"]),
    }
    with read_session() as session:
        inspector = inspect(session.get_bind())
        names = set(inspector.get_table_names())
        assert set(TABLES) <= names
        for table, (_name, columns) in expected.items():
            constraints = {item["name"]: item["column_names"] for item in inspector.get_unique_constraints(table)}
            assert columns in constraints.values(), f"{table} has no unique key on {columns}"
            if table != "export_checkpoints":
                checks = " ".join(item["sqltext"] for item in inspector.get_check_constraints(table))
                assert "status IN" in checks, f"{table} accepts any status"


# --------------------------------------------------------------------------- recording a run
def test_a_run_is_recorded_with_every_state_and_the_checksum_of_the_acknowledged_set(demo):
    tenant_id = demo.tenant_id
    destination = Refusing("C000002")
    result = deliver(destination, [_row("C000001", day=1, tenant=tenant_id), _row("C000002", day=2, tenant=tenant_id),
                                   _row("C000003", day=3, tenant=tenant_id)], run_id="run-A", batch_size=1,
                     policy=RetryPolicy(attempts=1))  # fmt: skip

    with session_scope() as session:
        run = outbox.record_run(session, result, tenant_id=tenant_id)
        assert run.status == "partial", "one record failed, some were acknowledged"
        assert (run.records_selected, run.records_acknowledged, run.records_failed, run.records_quarantined) == (3, 2, 1, 0)
        assert run.checksum == result.checksum
        assert run.watermark == datetime(2026, 11, 1, 6, tzinfo=UTC), "C000002 is a hole: the watermark stops at day 1"

        states = session.execute(text("SELECT status, COUNT(*) FROM export_outbox GROUP BY status")).all()
        assert dict(states) == {"ACKNOWLEDGED": 2, "FAILED": 1}


def test_a_retried_run_updates_its_row_instead_of_recording_a_second_history(demo):
    tenant_id = demo.tenant_id
    first = deliver(Refusing("C000002"), [_row("C000001", day=1, tenant=demo.tenant_id), _row("C000002", day=2, tenant=demo.tenant_id)], run_id="run-B",
                    batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    with session_scope() as session:
        outbox.record_run(session, first, tenant_id=tenant_id)

    second = deliver(Refusing(), [_row("C000002", day=2, tenant=demo.tenant_id)], run_id="run-B", policy=RetryPolicy(attempts=1))
    with session_scope() as session:
        run = outbox.record_run(session, second, tenant_id=tenant_id)
        runs = session.execute(text("SELECT COUNT(*) FROM export_runs WHERE run_id = 'run-B'")).scalar()
        assert runs == 1, "one run, one row"
        assert run.records_acknowledged == 1
        acknowledged = session.execute(text("SELECT COUNT(*) FROM export_outbox WHERE status = 'ACKNOWLEDGED'")).scalar()
        assert acknowledged == 2, "the retry acknowledged C000002, and C000001 stays acknowledged"


def test_a_quarantined_record_is_written_down_with_its_reason(demo):
    tenant_id = demo.tenant_id
    broken = _row("C000009", tenant=demo.tenant_id)
    broken["churn_probability"] = 1.5
    result = deliver(Refusing(), [broken], run_id="run-C")
    with session_scope() as session:
        run = outbox.record_run(session, result, tenant_id=tenant_id)
        assert run.records_quarantined == 1 and run.records_acknowledged == 0
        assert run.status == "completed", "a quarantine is not a delivery failure: nothing was attempted"
        assert session.execute(text("SELECT COUNT(*) FROM export_outbox")).scalar() == 0, "a record that never reached the destination has no outcome"
        assert run.checksum == record.checksum([])


# --------------------------------------------------------------------------- the checkpoint
def test_the_checkpoint_advances_only_forward_and_only_on_acknowledgement(demo):
    tenant_id = demo.tenant_id
    first = deliver(Refusing(), [_row("C000001", day=1, tenant=demo.tenant_id), _row("C000002", day=2, tenant=demo.tenant_id)], run_id="run-D")
    with session_scope() as session:
        outbox.record_run(session, first, tenant_id=tenant_id)
        assert outbox.watermark_for(session, tenant_id, "snowflake") == datetime(2026, 11, 2, 6, tzinfo=UTC)

    older = deliver(Refusing(), [_row("C000003", day=1, tenant=demo.tenant_id)], run_id="run-E")
    with session_scope() as session:
        outbox.record_run(session, older, tenant_id=tenant_id)
        assert outbox.watermark_for(session, tenant_id, "snowflake") == datetime(2026, 11, 2, 6, tzinfo=UTC), \
            "an older run cannot pull the watermark back"
        checkpoint = outbox.checkpoint_for(session, tenant_id, "snowflake")
        assert checkpoint.last_run_id == "run-D", "the checkpoint names the run that moved it"


def test_the_checkpoint_of_one_tenant_is_not_the_other_tenants(demo):
    from churn_platform.services import auth

    with session_scope() as session:
        other = auth.create_tenant(session, "globex", "Globex Inc").id  # a second tenant in the same database
    tenant_id = demo.tenant_id
    delivered = deliver(Refusing(), [_row("C000001", day=4, tenant=tenant_id)], run_id="run-F")
    with session_scope() as session:
        outbox.record_run(session, delivered, tenant_id=tenant_id)
        assert outbox.watermark_for(session, tenant_id, "snowflake") is not None
        assert outbox.watermark_for(session, other, "snowflake") is None, "globex has delivered nothing"


def test_a_destination_that_acknowledged_nothing_leaves_the_watermark_where_it_was(demo):
    tenant_id = demo.tenant_id
    good = deliver(Refusing(), [_row("C000001", day=4, tenant=demo.tenant_id)], run_id="run-G")
    with session_scope() as session:
        outbox.record_run(session, good, tenant_id=tenant_id)

    bad = deliver(Refusing("C000002"), [_row("C000002", day=9, tenant=demo.tenant_id)], run_id="run-H", policy=RetryPolicy(attempts=1))
    with session_scope() as session:
        run = outbox.record_run(session, bad, tenant_id=tenant_id)
        assert run.status == "failed"
        assert outbox.watermark_for(session, tenant_id, "snowflake") == datetime(2026, 11, 4, 6, tzinfo=UTC)


# --------------------------------------------------------------------------- resuming
def test_outstanding_is_the_backlog_a_restart_delivers(demo):
    tenant_id = demo.tenant_id
    result = deliver(Refusing("C000002"), [_row("C000001", day=1, tenant=demo.tenant_id), _row("C000002", day=2, tenant=demo.tenant_id)], run_id="run-I",
                     batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    with session_scope() as session:
        outbox.record_run(session, result, tenant_id=tenant_id)
        backlog = outbox.outstanding(session, tenant_id, "snowflake")
        assert [row.identity_key for row in backlog] == [f"{tenant_id}|C000002|churn-gbm|4|2026-11-02"]
        assert backlog[0].status == "FAILED" and backlog[0].attempts == 1
        assert backlog[0].error_code == "ValueError"

        keys = outbox.acknowledged_keys(session, tenant_id, "snowflake")
        assert f"{tenant_id}|C000001|churn-gbm|4|2026-11-01" in " ".join(keys), "the acknowledged key is remembered"


def test_a_second_run_of_the_backlog_empties_it_and_moves_the_watermark(demo):
    tenant_id = demo.tenant_id
    first = deliver(Refusing("C000002"), [_row("C000001", day=1, tenant=demo.tenant_id), _row("C000002", day=2, tenant=demo.tenant_id)], run_id="run-J",
                    batch_size=1, policy=RetryPolicy(attempts=1))  # fmt: skip
    with session_scope() as session:
        outbox.record_run(session, first, tenant_id=tenant_id)

    with session_scope() as session:
        backlog = outbox.outstanding(session, tenant_id, "snowflake")
    resumed = [_row(row.identity_key.split("|")[1], day=int(row.identity_key.split("|")[4][-2:]), tenant=tenant_id)
               for row in backlog]  # fmt: skip
    second = deliver(Refusing(), resumed, run_id="run-K")
    with session_scope() as session:
        outbox.record_run(session, second, tenant_id=tenant_id)
        assert outbox.outstanding(session, tenant_id, "snowflake") == []
        # the watermark is the newest contiguous instant *of the second run*; the checkpoint keeps the higher one
        assert outbox.watermark_for(session, tenant_id, "snowflake") == datetime(2026, 11, 2, 6, tzinfo=UTC)


def test_an_empty_outbox_reports_no_backlog_rather_than_failing(demo):
    with session_scope() as session:
        assert outbox.outstanding(session, demo.tenant_id, "snowflake") == []
        assert outbox.acknowledged_keys(session, demo.tenant_id, "snowflake") == set()
        assert outbox.watermark_for(session, demo.tenant_id, "snowflake") is None


def test_the_run_view_is_what_the_screen_shows(demo):
    result = deliver(Refusing(), [_row("C000001", day=1, tenant=demo.tenant_id)], run_id="run-L")
    with session_scope() as session:
        run = outbox.record_run(session, result, tenant_id=demo.tenant_id)
        view = outbox.run_view(run)
    assert view["run_id"] == "run-L" and view["acknowledged"] == 1 and view["failed"] == 0
    assert view["watermark"] == "2026-11-01T06:00:00+00:00"


# --------------------------------------------------------------------------- PostgreSQL
def test_the_migration_and_the_outbox_work_on_postgresql(empty, postgres_url):
    from sqlalchemy import create_engine

    engine = create_engine(postgres_url)
    try:
        with engine.begin() as connection:
            connection.execute(text("DROP SCHEMA public CASCADE"))
            connection.execute(text("CREATE SCHEMA public"))
        dbadmin.upgrade(url=postgres_url)
        with engine.connect() as connection:
            names = set(inspect(connection).get_table_names())
            assert set(TABLES) <= names
            for column in ("tenant_id", "idempotency_key", "status", "acknowledged_at"):
                columns = {item["name"] for item in inspect(connection).get_columns("export_outbox")}
                assert column in columns
        dbadmin.downgrade(url=postgres_url, revision="0004")
        with engine.connect() as connection:
            inspector = inspect(connection)
            names = set(inspector.get_table_names())
            assert not (set(TABLES) & names), "the downgrade removed exactly the three tables"
            assert {"customers", "predictions", "tenants"} <= names, "and left every table of 1.2.0 in place"
            revision = connection.execute(text("SELECT version_num FROM alembic_version")).scalar()
            assert revision == "0004"
    finally:
        # clean the schema first, then dispose exactly once: a pool disposed after a new connection was opened from it
        # leaves a psycopg connection to the garbage collector, and the warning it raises on collection is attributed to
        # whichever test happens to be starting when that happens
        try:
            with engine.begin() as connection:
                connection.execute(text("DROP SCHEMA public CASCADE"))
                connection.execute(text("CREATE SCHEMA public"))
        finally:
            engine.dispose()
            dispose_engine()
