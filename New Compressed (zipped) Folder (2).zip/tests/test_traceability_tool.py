"""The evidence chain: test markers -> JUnit report -> scripts/build_traceability.py -> traceability matrix."""

from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / "scripts" / "build_traceability.py"

pytestmark = pytest.mark.req("REQ-QA-01")

CATALOGUE = """
[[requirement]]
id = "REQ-A"
title = "Scores | are stored"
origin = "brief"
brief = ["8.2"]
statement = "Scores are stored."

[[requirement]]
id = "REQ-B"
title = "Access is controlled"
origin = "derived"
brief = []
statement = "Access is controlled."

[[brief]]
section = "8.2"
topic = "Output stored in a warehouse"
coverage = "partial"
requirements = ["REQ-A"]
note = "PostgreSQL only."
"""


def _tool():
    spec = importlib.util.spec_from_file_location("build_traceability", SCRIPT)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module  # dataclasses look the module up while the class is being built
    try:
        spec.loader.exec_module(module)
    finally:
        sys.modules.pop(spec.name, None)
    return module


def _report(path: Path, cases: list[tuple[str, str, tuple[str, ...]]]) -> Path:
    """A JUnit file in the shape pytest writes: (test name, outcome, requirement ids)."""
    suite = ET.Element("testsuite", name="pytest", tests=str(len(cases)), timestamp="2026-11-10T10:00:00+00:00")
    for name, outcome, reqs in cases:
        case = ET.SubElement(suite, "testcase", classname="tests.test_sample", name=name)
        props = ET.SubElement(case, "properties")
        for req in reqs:
            ET.SubElement(props, "property", name="requirement", value=req)
        if outcome == "failed":
            ET.SubElement(case, "failure", message="assert 1 == 2")
        elif outcome == "error":
            ET.SubElement(case, "error", message="fixture blew up")
        elif outcome == "skipped":
            ET.SubElement(case, "skipped", message="PostgreSQL is not available")
    root = ET.Element("testsuites")
    root.append(suite)
    ET.ElementTree(root).write(path)
    return path


def _build(tmp_path: Path, cases: list[tuple[str, str, tuple[str, ...]]], *extra: str, catalogue: str = CATALOGUE) -> tuple[int, str, dict, str]:
    tmp_path.mkdir(parents=True, exist_ok=True)
    (tmp_path / "requirements.toml").write_text(catalogue)
    report = _report(tmp_path / "junit.xml", cases)
    done = subprocess.run([sys.executable, str(SCRIPT), "--junit", str(report), "--catalogue", str(tmp_path / "requirements.toml"), *extra],
                          capture_output=True, text=True, timeout=60, check=False)  # fmt: skip
    result = json.loads((tmp_path / "traceability.json").read_text()) if (tmp_path / "traceability.json").exists() else {}
    matrix = (tmp_path / "TRACEABILITY.md").read_text() if (tmp_path / "TRACEABILITY.md").exists() else ""
    return done.returncode, done.stderr, result, matrix


def test_the_catalogue_is_consistent_and_knows_every_requirement_named_by_a_test(request):
    tool = _tool()
    requirements, brief, problems = tool.load_catalogue(tool.CATALOGUE)
    assert problems == [], problems
    ids = [r["id"] for r in requirements]
    assert len(ids) == len(set(ids)) == 38 and all(r["statement"].strip() and r["title"].strip() for r in requirements)
    assert {r["origin"] for r in requirements} == {"brief", "derived"}
    # the brief has eleven numbered sections; each one with something to build is listed, and every difference is spelled out
    assert {e["section"].split()[0].split(".")[0] for e in brief} == {str(n) for n in range(1, 12)}
    assert all(e["note"].strip() for e in brief if e["coverage"] == "partial") and {e["coverage"] for e in brief} == {"full", "partial", "context"}
    used = {req_id for item in request.session.items for mark in item.iter_markers("req") for req_id in mark.args}
    assert used and used <= set(ids), f"tests name requirements that the catalogue does not list: {sorted(used - set(ids))}"
    unmarked = [item.nodeid for item in request.session.items if not list(item.iter_markers("req"))]
    assert unmarked == [], f"tests without a requirement: {unmarked}"


def test_complete_evidence_builds_the_matrix(tmp_path):
    code, stderr, result, matrix = _build(tmp_path, [("test_scores_are_stored", "passed", ("REQ-A",)), ("test_roles", "passed", ("REQ-A", "REQ-B"))])
    assert code == 0 and stderr == "", stderr
    assert result["complete"] is True and result["problems"] == [] and result["totals"] == {"tests": 2, "passed": 2, "failed": 0, "skipped": 0}
    rows = {r["id"]: r for r in result["requirements"]}
    assert rows["REQ-A"]["status"] == rows["REQ-B"]["status"] == "verified"
    assert [t["name"] for t in rows["REQ-A"]["tests"]] == ["test_sample::test_roles", "test_sample::test_scores_are_stored"]
    assert rows["REQ-B"]["counts"] == {"passed": 1, "failed": 0, "skipped": 0}
    assert result["brief"][0]["verified"] is True and result["reports"] == [{"file": "junit.xml", "timestamp": "2026-11-10T10:00:00+00:00", "tests": 2}]
    assert "**Result:** every requirement is verified by passing tests." in matrix and "## Problems" not in matrix
    assert "| 8.2 | Output stored in a warehouse | partial | REQ-A | yes | PostgreSQL only. |" in matrix
    assert "| REQ-A | Scores \\| are stored | brief | 8.2 | 2 of 2 | verified |" in matrix, "a pipe in a title cannot break the table"
    assert "| REQ-B | Access is controlled | derived | - | 1 of 1 | verified |" in matrix
    assert "- passed: `test_sample::test_scores_are_stored`" in matrix


@pytest.mark.parametrize(("cases", "problem", "status"), [
    ([("test_a", "passed", ("REQ-A",))], "REQ-B has no passing test", {"REQ-B": "NO EVIDENCE"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "failed", ("REQ-B",))], "failed test: test_sample::test_b", {"REQ-B": "FAILED"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "error", ("REQ-B",))], "failed test: test_sample::test_b", {"REQ-B": "FAILED"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-B",)), ("test_c", "failed", ("REQ-B",))], "failed test: test_sample::test_c", {"REQ-B": "FAILED"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "skipped", ("REQ-B",))], "skipped test (missing evidence): test_sample::test_b", {"REQ-B": "NO EVIDENCE"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-B",)), ("test_c", "skipped", ("REQ-B",))], "skipped test (missing evidence): test_sample::test_c",
     {"REQ-B": "INCOMPLETE"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-B", "REQ-Z"))], "test test_sample::test_b names unknown requirement REQ-Z", {"REQ-B": "verified"}),
    ([("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-B",)), ("test_c", "passed", ())], "test without a requirement: test_sample::test_c", {"REQ-B": "verified"}),
])  # fmt: skip
def test_incomplete_evidence_fails_the_build_and_says_why(tmp_path, cases, problem, status):
    code, stderr, result, matrix = _build(tmp_path, cases)
    assert code == 1 and f"problem: {problem}" in stderr.splitlines()
    assert result["complete"] is False and problem in result["problems"]
    assert {r["id"]: r["status"] for r in result["requirements"] if r["id"] in status} == status
    assert "**Result:** INCOMPLETE, see the problems below." in matrix and f"- {problem}" in matrix, "the files are written even when the build fails"


def test_skipped_tests_are_tolerated_only_on_request_and_never_count_as_a_pass(tmp_path):
    cases = [("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-B",)), ("test_c", "skipped", ("REQ-B",))]
    code, stderr, result, _ = _build(tmp_path / "local", cases, "--allow-skips")
    assert code == 0 and stderr == "" and {r["id"]: r["status"] for r in result["requirements"]} == {"REQ-A": "verified", "REQ-B": "verified (some tests skipped)"}
    only_skipped = [("test_a", "passed", ("REQ-A",)), ("test_b", "skipped", ("REQ-B",))]
    code, stderr, result, _ = _build(tmp_path / "none", only_skipped, "--allow-skips")
    assert code == 1 and "problem: REQ-B has no passing test" in stderr, "a requirement whose only test was skipped has no evidence"


def test_a_contradictory_catalogue_and_missing_files_are_reported(tmp_path):
    broken = CATALOGUE.replace('id = "REQ-B"', 'id = "REQ-A"').replace('requirements = ["REQ-A"]', 'requirements = ["REQ-A", "REQ-C"]').replace(
        'note = "PostgreSQL only."', 'note = ""') + '\n[[requirement]]\nid = "REQ-D"\ntitle = "t"\norigin = "invented"\nbrief = ["12"]\nstatement = "s"\n'  # fmt: skip
    code, stderr, _, _ = _build(tmp_path, [("test_a", "passed", ("REQ-A",)), ("test_d", "passed", ("REQ-D",))], catalogue=broken)
    assert code == 1
    for expected in ("catalogue: REQ-A is listed twice", "catalogue: brief section 8.2 points at unknown requirement REQ-C",
                     "catalogue: brief section 8.2 is partial but does not say what differs", "catalogue: REQ-D has origin 'invented' (expected one of brief, derived)",
                     "catalogue: REQ-D cites brief section '12', which has no [[brief]] entry"):  # fmt: skip
        assert f"problem: {expected}" in stderr.splitlines(), expected
    missing = subprocess.run([sys.executable, str(SCRIPT), "--junit", str(tmp_path / "nope.xml")], capture_output=True, text=True, timeout=60, check=False)
    assert missing.returncode == 2 and missing.stderr.strip() == f"error: {tmp_path / 'nope.xml'} does not exist"


@pytest.mark.runtime
def test_a_real_test_run_writes_the_requirement_of_each_test_into_its_report(tmp_path):
    """The whole chain once, for real: pytest with this suite's conftest -> JUnit -> the tool with the real catalogue."""
    env = {**os.environ, "TMPDIR": str(tmp_path)}
    report = tmp_path / "junit.xml"
    run = subprocess.run([sys.executable, "-m", "pytest", "tests/test_security.py::test_hmac_helpers", "tests/test_security.py::test_role_model_is_least_privilege",
                          "-q", "-p", "no:cacheprovider", f"--junitxml={report}"], cwd=ROOT, env=env, capture_output=True, text=True, timeout=240, check=False)  # fmt: skip
    assert run.returncode == 0, run.stdout[-2000:] + run.stderr[-2000:]
    written = ET.parse(report).getroot()  # noqa: S314 - written a moment ago by our own test run
    cases = {case.get("name"): sorted(p.get("value") for p in case.iter("property") if p.get("name") == "requirement") for case in written.iter("testcase")}
    assert cases == {"test_hmac_helpers": ["REQ-SEC-01"], "test_role_model_is_least_privilege": ["REQ-SEC-01", "REQ-SEC-02"]}
    built = subprocess.run([sys.executable, str(SCRIPT), "--junit", str(report), "--out", str(tmp_path / "T.md"), "--json", str(tmp_path / "t.json")],
                           capture_output=True, text=True, timeout=60, check=False)  # fmt: skip
    result = json.loads((tmp_path / "t.json").read_text())
    rows = {r["id"]: r for r in result["requirements"]}
    assert built.returncode == 1, "two tests cannot verify 38 requirements"
    assert rows["REQ-SEC-01"]["status"] == rows["REQ-SEC-02"]["status"] == "verified" and rows["REQ-ML-01"]["status"] == "NO EVIDENCE"
    assert [t["name"] for t in rows["REQ-SEC-02"]["tests"]] == ["test_security::test_role_model_is_least_privilege"]
    assert sum(1 for p in result["problems"] if p.endswith("has no passing test")) == 36 and len(result["problems"]) == 36


# ----------------------------------------------------------------------------- release manifest and archive
MANIFEST_SCRIPT = ROOT / "scripts" / "build_manifest.py"


def _manifest(*args: str | Path, script: Path = MANIFEST_SCRIPT) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(script), *map(str, args)], capture_output=True, text=True, timeout=120, check=False)


def _tree(root: Path) -> Path:
    for name, text in (("pyproject.toml", '[project]\nname = "demo-app"\nversion = "2.3.4"\n'), ("src/app.py", "print('hello')\n"), ("docs/guide.md", "# Guide\n"),
                       ("scripts/run.sh", "#!/bin/sh\necho run\n"), ("docs/traceability/traceability.json",
                        json.dumps({"complete": True, "totals": {"tests": 3, "passed": 3}, "requirements": [{"id": "REQ-A", "status": "verified"}]})),
                       # never part of a release: caches, runtime state, secrets, earlier release output
                       ("src/__pycache__/app.cpython-312.pyc", "x"), ("var/demo.db", "x"), ("release/old.zip", "x"), (".env", "SECRET=1"),
                       ("demo_app.egg-info/PKG-INFO", "x"), ("local.db-wal", "x"), ("build/lib/app.py", "x"), ("dist/demo_app-2.3.4-py3-none-any.whl", "x")):  # fmt: skip
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    (root / "scripts/run.sh").chmod(0o755)
    return root


def test_the_manifest_lists_every_release_file_and_the_archive_is_verified_against_it(tmp_path):
    import hashlib
    import zipfile

    tree = _tree(tmp_path / "tree")
    report = _report(tmp_path / "junit.xml", [("test_a", "passed", ("REQ-A",)), ("test_b", "passed", ("REQ-A",)), ("test_c", "passed", ("REQ-A",))])
    archive = tmp_path / "out" / "demo-app.zip"
    built = _manifest("--root", tree, "--junit", report, "--zip", archive)
    assert built.returncode == 0 and built.stderr == "", built.stderr
    manifest = json.loads((tree / "release" / "MANIFEST.json").read_text())
    expected = ["docs/guide.md", "docs/traceability/traceability.json", "pyproject.toml", "scripts/run.sh", "src/app.py"]
    assert [f["path"] for f in manifest["files"]] == expected and manifest["file_count"] == 5
    assert all(f["sha256"] == hashlib.sha256((tree / f["path"]).read_bytes()).hexdigest() and f["bytes"] == (tree / f["path"]).stat().st_size for f in manifest["files"])
    assert (manifest["name"], manifest["version"], manifest["git"]) == ("demo-app", "2.3.4", None) and manifest["total_bytes"] == sum(f["bytes"] for f in manifest["files"])
    assert manifest["tests"]["tests"] == manifest["tests"]["passed"] == 3 and manifest["tests"]["reports"][0]["sha256"] == hashlib.sha256(report.read_bytes()).hexdigest()
    assert manifest["traceability"] == {"requirements": 1, "verified": 1, "complete": True, "tests": {"tests": 3, "passed": 3}}
    # the archive: one top-level directory, exactly the listed files plus the manifest, byte for byte
    with zipfile.ZipFile(archive) as z:
        assert sorted(z.namelist()) == sorted(f"demo-app-2.3.4/{name}" for name in [*expected, "MANIFEST.json"])
        assert all(z.read(f"demo-app-2.3.4/{name}") == (tree / name).read_bytes() for name in expected)
        assert json.loads(z.read("demo-app-2.3.4/MANIFEST.json")) == manifest
        assert z.getinfo("demo-app-2.3.4/scripts/run.sh").external_attr >> 16 == 0o755 and z.getinfo("demo-app-2.3.4/src/app.py").external_attr >> 16 == 0o644
        z.extractall(tmp_path / "unpacked")
    assert f"sha256 {hashlib.sha256(archive.read_bytes()).hexdigest()}" in built.stdout
    again = tmp_path / "out" / "again.zip"
    assert _manifest("--root", tree, "--junit", report, "--zip", again, "--out", tmp_path / "second.json").returncode == 0
    with zipfile.ZipFile(archive) as first, zipfile.ZipFile(again) as second:
        assert [(i.filename, i.date_time, i.CRC) for i in first.infolist()[:-1]] == [(i.filename, i.date_time, i.CRC) for i in second.infolist()[:-1]], "same files, same members"
    # the recipient checks the unpacked release against its manifest
    unpacked = tmp_path / "unpacked" / "demo-app-2.3.4"
    ok = _manifest("--check", "--root", unpacked)
    assert ok.returncode == 0 and ok.stdout.strip() == "demo-app 2.3.4: 5 files listed, 0 difference(s)" and ok.stderr == ""
    (unpacked / "src" / "__pycache__").mkdir()
    (unpacked / "src" / "__pycache__" / "app.pyc").write_text("cache written by running the code")
    for left_behind in ("build/lib/app.py", "dist/demo_app-2.3.4-py3-none-any.whl"):  # the recipient built the package in the unpacked tree
        (unpacked / left_behind).parent.mkdir(parents=True)
        (unpacked / left_behind).write_text("build output")
    assert _manifest("--check", "--root", unpacked).returncode == 0, "caches, runtime files and build output are not differences"
    (unpacked / "src" / "build").mkdir()
    (unpacked / "src" / "build" / "extra.py").write_text("a directory called build is only ignored at the top")
    hidden = _manifest("--check", "--root", unpacked)
    assert hidden.returncode == 1 and hidden.stderr.splitlines() == ["not in the manifest: src/build/extra.py"]
    (unpacked / "src" / "build" / "extra.py").unlink()
    (unpacked / "src/app.py").write_text("print('tampered')\n")
    (unpacked / "docs/guide.md").unlink()
    (unpacked / "extra.txt").write_text("not shipped")
    bad = _manifest("--check", "--root", unpacked)
    assert bad.returncode == 1 and bad.stderr.splitlines() == ["missing: docs/guide.md", "changed: src/app.py", "not in the manifest: extra.txt"]
    assert bad.stdout.strip() == "demo-app 2.3.4: 5 files listed, 3 difference(s)"
    nothing = _manifest("--check", "--root", tmp_path / "out")
    assert nothing.returncode == 2 and "no MANIFEST.json found" in nothing.stderr
    # the earlier script name still works
    alias = _manifest("--root", tree, "--out", tmp_path / "alias.json", script=ROOT / "scripts" / "build_phase2_manifest.py")
    assert alias.returncode == 0 and [f["path"] for f in json.loads((tmp_path / "alias.json").read_text())["files"]] == expected


def test_a_release_is_refused_from_an_unclean_checkout_or_with_incomplete_evidence(tmp_path):
    tree = _tree(tmp_path / "tree")
    clean_report = _report(tmp_path / "junit.xml", [("test_a", "passed", ("REQ-A",))])
    no_git = _manifest("--root", tree, "--require-clean", "--out", tmp_path / "m.json")
    assert no_git.returncode == 1 and no_git.stderr.splitlines() == ["error: not a git checkout", "error: no test report given (--junit)"]
    assert not (tmp_path / "m.json").exists(), "nothing is written for a refused release"

    def git(*args: str) -> None:
        subprocess.run(["git", "-C", str(tree), "-c", "user.name=t", "-c", "user.email=t@example.com", *args], check=True, capture_output=True, timeout=60)

    (tree / ".gitignore").write_text("var/\nrelease/\n*.db-wal\n.env\n__pycache__/\n*.egg-info/\n")
    git("init", "-q", "-b", "main")
    git("add", "-A")
    git("commit", "-q", "-m", "release tree")
    ready = _manifest("--root", tree, "--require-clean", "--junit", clean_report, "--out", tmp_path / "m.json")
    assert ready.returncode == 0, ready.stderr
    manifest = json.loads((tmp_path / "m.json").read_text())
    assert manifest["git"]["dirty"] is False and len(manifest["git"]["commit"]) == 40 and manifest["git"]["branch"] == "main"
    assert ".gitignore" in [f["path"] for f in manifest["files"]] and not any(f["path"].startswith(("var/", "release/")) or f["path"] == ".env" for f in manifest["files"])
    # an uncommitted change, a new untracked file, a skipped test, an incomplete matrix: each one stops the release
    (tree / "src/app.py").write_text("print('edited after the commit')\n")
    (tree / "src/new_module.py").write_text("x = 1\n")
    dirty = _manifest("--root", tree, "--require-clean", "--junit", clean_report, "--out", tmp_path / "dirty.json")
    assert dirty.returncode == 1 and "error: uncommitted changes:" in dirty.stderr and "src/app.py" in dirty.stderr and "src/new_module.py" in dirty.stderr
    unforced = _manifest("--root", tree, "--junit", clean_report, "--out", tmp_path / "dirty.json")
    assert unforced.returncode == 0 and json.loads((tmp_path / "dirty.json").read_text())["git"]["dirty"] is True, "without --require-clean the state is recorded, not hidden"
    assert "src/new_module.py" in [f["path"] for f in json.loads((tmp_path / "dirty.json").read_text())["files"]], "a file that was never added is not silently left out"
    git("add", "-A")
    git("commit", "-q", "-m", "more")
    skipped = _report(tmp_path / "skipped.xml", [("test_a", "passed", ("REQ-A",)), ("test_b", "skipped", ("REQ-A",))])
    # pytest writes the totals as attributes of the suite; the helper only writes "tests", so add what a real report carries
    text = skipped.read_text().replace('tests="2"', 'tests="2" skipped="1" failures="0" errors="0"')
    skipped.write_text(text)
    refused = _manifest("--root", tree, "--require-clean", "--junit", skipped, "--out", tmp_path / "s.json")
    assert refused.returncode == 1 and refused.stderr.strip() == "error: the test run is not clean: 0 failed, 0 errors, 1 skipped of 2"
    (tree / "docs/traceability/traceability.json").write_text(json.dumps({"complete": False, "requirements": []}))
    git("add", "-A")
    git("commit", "-q", "-m", "incomplete matrix")
    incomplete = _manifest("--root", tree, "--require-clean", "--junit", clean_report, "--out", tmp_path / "i.json")
    assert incomplete.returncode == 1 and "the traceability matrix is missing or incomplete" in incomplete.stderr


# ----------------------------------------------------------------------------- the wheel carries the whole package
WHEEL_SCRIPT = ROOT / "scripts" / "check_wheel.py"


def _wheel(path: Path, names: list[str]) -> Path:
    import zipfile

    with zipfile.ZipFile(path, "w") as z:
        for name in [*names, "pkg-1.0.dist-info/METADATA", "pkg-1.0.dist-info/RECORD"]:
            z.writestr(name, "x")
    return path


def test_a_wheel_that_lost_a_package_file_is_refused(tmp_path):
    """Migrations, templates and web assets are data files: an editable install finds them in the source tree,
    so only a check of the built wheel notices when the packaging configuration stops including one."""
    src = tmp_path / "src"
    files = ["pkg/__init__.py", "pkg/migrations/versions/0001_baseline.py", "pkg/migrations/script.py.mako", "pkg/web/js/app.js"]
    for name in [*files, "pkg/__pycache__/__init__.cpython-312.pyc", "pkg.egg-info/PKG-INFO"]:
        (src / name).parent.mkdir(parents=True, exist_ok=True)
        (src / name).write_text("x")

    def check(names: list[str]) -> subprocess.CompletedProcess:
        wheel = _wheel(tmp_path / "pkg-1.0-py3-none-any.whl", names)
        return subprocess.run([sys.executable, str(WHEEL_SCRIPT), str(wheel), str(src)], capture_output=True, text=True, timeout=60)

    complete = check(files)
    assert (complete.returncode, complete.stdout.strip(), complete.stderr) == (0, "pkg-1.0-py3-none-any.whl: all 4 package files are present", "")
    lost = check([n for n in files if not n.endswith((".mako", ".js"))])
    assert lost.returncode == 1 and lost.stdout == ""
    assert lost.stderr.splitlines() == ["missing from the wheel: pkg/migrations/script.py.mako", "missing from the wheel: pkg/web/js/app.js"]
    stray = check([*files, "pkg/old_module.py"])
    assert stray.returncode == 1 and stray.stderr.splitlines() == ["in the wheel without a source file: pkg/old_module.py"]
    usage = subprocess.run([sys.executable, str(WHEEL_SCRIPT)], capture_output=True, text=True, timeout=60)
    absent = subprocess.run([sys.executable, str(WHEEL_SCRIPT), str(tmp_path / "none.whl"), str(src)], capture_output=True, text=True, timeout=60)
    assert (usage.returncode, absent.returncode) == (2, 2) and "not found" in absent.stderr and "check_wheel.py" in usage.stderr


# ----------------------------------------------------------------------------- the defect log names tests that exist
def test_every_test_the_defect_log_points_to_exists():
    """A defect counts as guarded only while the test named next to it is still there under that name."""
    import re

    tests_dir = ROOT / "tests"
    functions = {path.name: set(re.findall(r"^def (test_\w+)\(", path.read_text(), flags=re.M))
                 for path in [*tests_dir.glob("test_*.py"), *(tests_dir / "e2e").glob("test_*.py")]}  # fmt: skip
    rows = [line for line in (ROOT / "docs" / "DEFECT_LOG.md").read_text().splitlines() if line.startswith("| DEF-")]
    ids = [row.split(" | ")[0].strip("| ") for row in rows]
    assert ids == [f"DEF-{n:03d}" for n in range(1, len(rows) + 1)], "defect ids are consecutive and unique"
    broken, checked = [], 0
    for row in rows:
        cells = [cell.strip() for cell in row.strip().strip("|").split(" | ")]
        assert len(cells) == 5, f"{cells[0]}: expected five columns"
        current = None  # the test file named last in this cell: `::name` and `…fragment` refer to it
        for token in re.findall(r"`([^`]+)`", cells[-1]):
            named = re.fullmatch(r"(?:tests/(?:e2e/)?)?(test_\w+\.py)(?:::(test_\w+…?))?", token)
            if named:
                current, wanted = named.groups()
                if current not in functions:
                    broken.append(f"{cells[0]}: there is no test file {current}")
                    current = None
            elif current and token.startswith(("::", "…")):
                wanted = token.removeprefix("…").removeprefix("::")
            else:
                continue  # some other code fragment
            if not current or not wanted:
                continue
            checked += 1
            name = wanted.strip("…")
            found = name in functions[current] if "…" not in token else any(name in function for function in functions[current])
            if not found:
                broken.append(f"{cells[0]}: {current} has no test matching `{token}`")
    assert not broken, "\n".join(broken)
    assert checked >= 30, "the parser found the test references"
