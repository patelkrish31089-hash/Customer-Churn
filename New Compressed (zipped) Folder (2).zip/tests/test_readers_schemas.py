"""File readers, schema discovery, mapping suggestions and value coercion."""

from __future__ import annotations

import json
from datetime import UTC, date, datetime
from decimal import Decimal

import pandas as pd
import pytest

from churn_platform.services import readers, schemas
from churn_platform.services.schemas import ENTITY_SCHEMAS, CoercionError, coerce

pytestmark = pytest.mark.req("REQ-DATA-01")
NOW = datetime(2026, 11, 1, tzinfo=UTC)


def _spec(entity: str, name: str):
    return next(s for s in ENTITY_SCHEMAS[entity] if s.name == name)


# ----------------------------------------------------------------------------- readers
def test_format_detection():
    assert readers.detect_format("Customers.CSV") == "csv" and readers.detect_format("a.tab") == "tsv"
    assert readers.detect_format("a.unknown", "jsonl") == "jsonl"
    with pytest.raises(readers.ReaderError, match="cannot determine"):
        readers.detect_format("a.pdf")
    with pytest.raises(readers.ReaderError, match="unsupported format"):
        readers.detect_format("a.csv", "xml")


def test_delimited_files_bom_quotes_short_rows_and_sniffing(tmp_path):
    csv_path = tmp_path / "a.csv"
    csv_path.write_bytes('\ufeffid,name,note\n1,"Acme, Inc.","line one\nline two"\n\n2,Beta\n'.encode())
    rows = list(readers.iter_rows(csv_path, "csv"))
    assert rows == [{"id": "1", "name": "Acme, Inc.", "note": "line one\nline two"}, {"id": "2", "name": "Beta", "note": ""}]
    semi = tmp_path / "b.txt"
    semi.write_text("id;amount\n1;10,5\n2;7\n")
    assert list(readers.iter_rows(semi, "txt")) == [{"id": "1", "amount": "10,5"}, {"id": "2", "amount": "7"}]
    tsv = tmp_path / "c.tsv"
    tsv.write_text("id\tname\n1\tA B\n")
    assert list(readers.iter_rows(tsv, "tsv")) == [{"id": "1", "name": "A B"}]


@pytest.mark.parametrize(("content", "message"), [
    (b"id,id\n1,2\n", "unique, non-empty"), (b"id,,x\n1,2,3\n", "unique, non-empty"), (b"id,name\n1,a,EXTRA\n", "has 3 fields"),
    ("id,name\n1,caf\xe9\n".encode("latin-1"), "UTF-8"),
])  # fmt: skip
def test_malformed_delimited_files_are_rejected(tmp_path, content, message):
    path = tmp_path / "bad.csv"
    path.write_bytes(content)
    with pytest.raises(readers.ReaderError, match=message):
        list(readers.iter_rows(path, "csv"))


def test_json_jsonl_xlsx_parquet(tmp_path):
    records = [{"id": 1, "name": "A", "nested": {"k": 1}}, {"id": 2, "name": "B", "nested": None}]
    array, wrapped, lines = tmp_path / "a.json", tmp_path / "w.json", tmp_path / "l.jsonl"
    array.write_text(json.dumps(records))
    wrapped.write_text(json.dumps({"meta": {"page": 1}, "data": records}))
    lines.write_text("\n".join(json.dumps(r) for r in records) + "\n\n")
    for path, fmt in ((array, "json"), (wrapped, "json"), (lines, "jsonl")):
        assert list(readers.iter_rows(path, fmt)) == records, path.name
    bad = tmp_path / "bad.jsonl"
    bad.write_text('{"id": 1}\nnot json\n')
    with pytest.raises(readers.ReaderError, match="line 2"):
        list(readers.iter_rows(bad, "jsonl"))
    single = tmp_path / "single.json"
    single.write_text('{"id": 9, "name": "only"}')
    assert list(readers.iter_rows(single, "json")) == [{"id": 9, "name": "only"}], "a lone object is one record"
    for name, content, message in (("scalar.json", "42", "not an object"), ("mixed.json", '[{"id": 1}, 5]', "record 2 is not an object"),
                                   ("cut.json", '[{"id": 1}, {"id": ', "JSON"), ("broken.json", '{"data": [', "invalid JSON")):
        path = tmp_path / name
        path.write_text(content)
        with pytest.raises(readers.ReaderError, match=message):
            list(readers.iter_rows(path, "json"))

    frame = pd.DataFrame({"id": [1, 2], "when": pd.to_datetime(["2026-01-05", "2026-02-06"]), "amount": [1.5, 2.25]})
    xlsx, parquet = tmp_path / "a.xlsx", tmp_path / "a.parquet"
    frame.to_excel(xlsx, index=False)
    frame.to_parquet(parquet, index=False)
    for path, fmt in ((xlsx, "xlsx"), (parquet, "parquet")):
        rows = list(readers.iter_rows(path, fmt))
        assert [r["id"] for r in rows] == [1, 2] and [float(r["amount"]) for r in rows] == [1.5, 2.25], fmt
        assert schemas.to_datetime(rows[1]["when"]) == datetime(2026, 2, 6, tzinfo=UTC), fmt


def test_schema_discovery_profiles_types_nulls_and_counts(tmp_path):
    path = tmp_path / "a.csv"
    path.write_text("id,amount,flag,when,label,mixed\n1,10.5,true,2026-01-05,alpha,1\n2,7,false,2026-01-06 10:00:00,,x\n3,,yes,2026-01-07,gamma,2\n")
    schema = readers.discover_schema(path, "csv", sample_rows=2)
    assert schema["row_count"] == 3 and schema["sampled_rows"] == 2
    schema = readers.discover_schema(path, "csv")
    kinds = {c["name"]: c["inferred_type"] for c in schema["columns"]}
    assert kinds == {"id": "int", "amount": "float", "flag": "bool", "when": "datetime", "label": "str", "mixed": "str"}
    nulls = {c["name"]: c["nulls_in_sample"] for c in schema["columns"]}
    assert nulls["amount"] == 1 and nulls["label"] == 1 and nulls["id"] == 0
    assert next(c for c in schema["columns"] if c["name"] == "label")["examples"] == ["alpha", "gamma"]


def test_mapping_suggestions_use_synonyms_without_reusing_a_column():
    got = readers.suggest_mapping("subscriptions", ["Subscription ID", "Customer-Id", "Plan Code", "Start Date", "Churned At", "Monthly Recurring Revenue", "junk"])
    assert got == {"external_id": "Subscription ID", "customer_external_id": "Customer-Id", "plan_external_id": "Plan Code", "started_at": "Start Date",
                   "ended_at": "Churned At", "mrr": "Monthly Recurring Revenue"}  # fmt: skip
    usage = readers.suggest_mapping("usage_events", ["id", "customer_id", "timestamp", "event", "session_length"])
    assert usage == {"external_id": "id", "customer_external_id": "customer_id", "occurred_at": "timestamp", "event_type": "event", "duration_seconds": "session_length"}
    assert len(set(got.values())) == len(got)


# ----------------------------------------------------------------------------- coercion
@pytest.mark.parametrize(("raw", "expected"), [
    ("2026-01-05", datetime(2026, 1, 5, tzinfo=UTC)), ("2026-01-05T10:30:00Z", datetime(2026, 1, 5, 10, 30, tzinfo=UTC)),
    ("2026-01-05T10:30:00+02:00", datetime(2026, 1, 5, 8, 30, tzinfo=UTC)), ("2026/01/05 23:59:59", datetime(2026, 1, 5, 23, 59, 59, tzinfo=UTC)),
    ("20260105", datetime(2026, 1, 5, tzinfo=UTC)), (1767571200, datetime(2026, 1, 5, tzinfo=UTC)), (1767571200000, datetime(2026, 1, 5, tzinfo=UTC)),
    (date(2026, 1, 5), datetime(2026, 1, 5, tzinfo=UTC)), (pd.Timestamp("2026-01-05 01:00", tz="Europe/Paris"), datetime(2026, 1, 5, 0, 0, tzinfo=UTC)),
])  # fmt: skip
def test_datetimes_are_normalised_to_utc(raw, expected):
    assert schemas.to_datetime(raw) == expected


@pytest.mark.parametrize("raw", ["05/01/2026", "01-05-2026", "Jan 5 2026", "2026-13-45", "yesterday", -5, 1e15, "1066-10-14"])
def test_ambiguous_or_implausible_datetimes_are_rejected_not_guessed(raw):
    with pytest.raises(CoercionError):
        schemas.to_datetime(raw)


def test_numbers_booleans_strings_and_choices():
    assert coerce(_spec("invoices", "amount"), "1,234.50") == Decimal("1234.5000")
    assert coerce(_spec("invoices", "amount"), 0.1) + coerce(_spec("invoices", "amount"), 0.2) == Decimal("0.3000"), "money is exact, not binary float"
    assert coerce(_spec("customers", "employee_count"), "12.0") == 12 and coerce(_spec("customers", "employee_count"), 7.0) == 7
    for bad in ("12.5", "abc", "1,23", True, "inf", "NaN"):
        with pytest.raises(CoercionError):
            coerce(_spec("customers", "employee_count"), bad)
    truthy, falsy = ("true", "T", "yes", "Y", "1", 1, True), ("false", "F", "no", "N", "0", 0, False)
    assert all(coerce(_spec("customers", "consent_marketing"), v) is True for v in truthy)
    assert all(coerce(_spec("customers", "consent_marketing"), v) is False for v in falsy)
    with pytest.raises(CoercionError):
        coerce(_spec("customers", "consent_marketing"), "maybe")
    assert coerce(_spec("plans", "billing_period"), " Annual ") == "annual"
    with pytest.raises(CoercionError, match="not one of"):
        coerce(_spec("plans", "billing_period"), "weekly")
    assert coerce(_spec("customers", "external_id"), 1001.0) == "1001", "ids read as floats from spreadsheets keep their integer form"
    with pytest.raises(CoercionError, match="longer than"):
        coerce(_spec("customers", "external_id"), "x" * 121)
    assert coerce(_spec("accounts", "payment_method_expires_on"), "2027-03-31") == date(2027, 3, 31)
    assert coerce(_spec("subscription_events", "detail"), '{"a": 1}') == {"a": 1}
    with pytest.raises(CoercionError, match="JSON"):
        coerce(_spec("subscription_events", "detail"), "{broken")
    assert all(schemas.is_missing(v) for v in (None, "", "  ", "NULL", "n/a", "NaN", float("nan"), pd.NaT, pd.NA))
    assert not any(schemas.is_missing(v) for v in (0, "0", False, "none of the above"))


@pytest.mark.parametrize(("entity", "row", "fragment"), [
    ("subscriptions", {"started_at": NOW, "ended_at": datetime(2026, 1, 1, tzinfo=UTC)}, "ended_at is earlier than started_at"),
    ("subscriptions", {"started_at": datetime(2026, 1, 1, tzinfo=UTC), "mrr": Decimal("-1")}, "mrr must not be negative"),
    ("subscriptions", {"started_at": datetime(2026, 1, 1, tzinfo=UTC), "discount_pct": 120.0}, "discount_pct"),
    ("subscriptions", {"started_at": datetime(2026, 1, 1, tzinfo=UTC), "end_reason": "cancellation"}, "end_reason given without ended_at"),
    ("usage_events", {"occurred_at": datetime(2026, 11, 3, tzinfo=UTC)}, "occurred_at is in the future"),
    ("usage_events", {"occurred_at": datetime(2026, 1, 1, tzinfo=UTC), "quantity": 0}, "quantity must be at least 1"),
    ("support_interactions", {"opened_at": datetime(2026, 2, 1, tzinfo=UTC), "resolved_at": datetime(2026, 1, 1, tzinfo=UTC)}, "resolved_at is earlier"),
    ("support_interactions", {"opened_at": datetime(2026, 2, 1, tzinfo=UTC), "nps_score": 11}, "nps_score"),
    ("support_interactions", {"opened_at": datetime(2026, 2, 1, tzinfo=UTC), "csat": 5.5}, "csat"),
    ("invoices", {"issued_at": datetime(2026, 2, 1, tzinfo=UTC), "amount": Decimal("-0.01")}, "amount must not be negative"),
    ("payments", {"attempted_at": datetime(2027, 2, 1, tzinfo=UTC), "amount": Decimal("1")}, "attempted_at is in the future"),
    ("customers", {"employee_count": -3}, "employee_count must not be negative"),
])  # fmt: skip
def test_hard_row_rules(entity, row, fragment):
    assert any(fragment in v for v in schemas.row_rule_violations(entity, row, NOW))


def test_valid_rows_have_no_violations_and_clock_skew_of_a_day_is_tolerated():
    assert schemas.row_rule_violations("usage_events", {"occurred_at": datetime(2026, 11, 1, 12, tzinfo=UTC), "quantity": 1}, NOW) == []
    assert schemas.row_rule_violations("customers", {"email": "not-an-email", "employee_count": 5}, NOW) == [], "e-mail format is a soft quality rule"
