"""Hand-built point-in-time frames for label and feature tests (no database involved)."""

from __future__ import annotations

from typing import Any

import pandas as pd

from churn_platform.services import timeline

_TIME = timeline._TIME_COLS
_FLOAT = timeline._FLOAT_COLS


def _table(name: str, rows: list[dict]) -> pd.DataFrame:
    columns = timeline.FRAME_COLUMNS[name][1]
    unknown = {k for r in rows for k in r} - set(columns)
    assert not unknown, f"{name}: unknown columns {unknown}"
    df = pd.DataFrame([{c: r.get(c) for c in columns} for r in rows], columns=columns)
    for col in columns:
        if col in _TIME:
            df[col] = pd.to_datetime(df[col], format="ISO8601").astype("datetime64[ns]")
        elif col in _FLOAT:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
    return df


class World:
    """A tiny subscription business described row by row."""

    def __init__(self) -> None:
        self.rows: dict[str, list[dict]] = {name: [] for name in timeline.FRAME_COLUMNS}
        self.history: list[tuple] = []
        self._ids = dict.fromkeys(timeline.FRAME_COLUMNS, 0)
        # derived signals (1.1.0): each frame exists only once something was put into it
        self.signals: dict[str, list[dict]] = {"sentiment": [], "catalog": [], "identity": [], "attributes": []}
        self.activity: dict | None = None

    def _next(self, name: str) -> int:
        self._ids[name] += 1
        return self._ids[name]

    def customer(self, cid: int, **kw: Any) -> int:
        self.rows["customers"].append({"id": cid, "external_id": f"C{cid}", "name": f"Customer {cid}", **kw})
        return cid

    def account(self, customer_id: int, **kw: Any) -> int:
        aid = self._next("accounts")
        self.rows["accounts"].append({"id": aid, "customer_id": customer_id, **kw})
        return aid

    def plan(self, pid: int, tier: str = "pro", billing_period: str = "monthly") -> int:
        self.rows["plans"].append({"id": pid, "external_id": f"P{pid}", "tier": tier, "billing_period": billing_period})
        return pid

    def subscription(self, sid: int, customer_id: int, started_at: str, *, events: bool = True, **kw: Any) -> int:
        self.rows["subscriptions"].append({"id": sid, "customer_id": customer_id, "started_at": started_at, "billing_period": "monthly", "mrr": 100.0, **kw})
        if events:
            self.event(sid, "started", started_at, mrr=kw.get("mrr", 100.0), plan_id=kw.get("plan_id"))
        return sid

    def event(self, subscription_id: int, event_type: str, occurred_at: str, **kw: Any) -> None:
        customer_id = next(s["customer_id"] for s in self.rows["subscriptions"] if s["id"] == subscription_id)
        self.rows["sub_events"].append({"id": self._next("sub_events"), "subscription_id": subscription_id, "customer_id": customer_id,
                                        "event_type": event_type, "occurred_at": occurred_at, **kw})  # fmt: skip

    def usage(self, customer_id: int, occurred_at: str, event_type: str = "login", **kw: Any) -> None:
        self.rows["usage"].append({"customer_id": customer_id, "occurred_at": occurred_at, "event_type": event_type, "quantity": 1, **kw})

    def ticket(self, customer_id: int, opened_at: str, **kw: Any) -> None:
        self.rows["support"].append({"id": self._next("support"), "customer_id": customer_id, "kind": "ticket", "opened_at": opened_at, "escalated": False, **kw})

    def invoice(self, customer_id: int, issued_at: str, amount: float = 100.0, **kw: Any) -> None:
        self.rows["invoices"].append({"id": self._next("invoices"), "customer_id": customer_id, "issued_at": issued_at, "amount": amount, **kw})

    def payment(self, customer_id: int, attempted_at: str, status: str = "succeeded", amount: float = 100.0) -> None:
        self.rows["payments"].append({"id": self._next("payments"), "customer_id": customer_id, "attempted_at": attempted_at, "status": status, "amount": amount})

    def card_expiry_changed(self, account_id: int, changed_at: str, previous_expiry: str | None) -> None:
        self.history.append((account_id, changed_at, previous_expiry))

    # ---- derived signals
    def sentiment(self, ticket_id: int, label: str, score: float | None, state: str = "ok") -> None:
        self.signals["sentiment"].append({"interaction_id": ticket_id, "label": label, "score": score, "state": state})

    def feature(self, key: str, names: tuple[str, ...] | None = None, *, event_types: tuple[str, ...] = ("feature_use",), is_core: bool = False,
                release_date: str | None = None, retired_date: str | None = None, plan_tiers: tuple[str, ...] | None = None, min_events: int = 1,
                min_days: int = 1, first_seen: str | None = "2020-01-01") -> None:
        """A catalogue entry.  ``first_seen`` is when its telemetry was first recorded (None = never)."""
        self.signals["catalog"].append({"feature_key": key, "name": key.title(), "is_core": is_core, "release_date": release_date, "retired_date": retired_date,
                                        "plan_tiers": plan_tiers, "names": tuple(n.casefold() for n in (names or (key,))), "event_types": event_types,
                                        "min_events": min_events, "min_days": min_days, "first_seen": first_seen})  # fmt: skip

    def link(self, external_user_id: str, user_key: str, *, customer_id: int | None = None, status: str = "active", valid_from: str | None = None,
             valid_to: str | None = None) -> None:
        self.signals["identity"].append({"link_id": len(self.signals["identity"]) + 1, "external_user_id": external_user_id.strip().casefold(), "user_key": user_key,
                                         "status": status, "customer_id": customer_id, "valid_from": valid_from, "valid_to": valid_to})  # fmt: skip

    def attribute(self, customer_id: int, attribute: str, value: str | None, *, valid_from: str | None = None, valid_to: str | None = None,
                  basis: str = "initial", recorded_at: str = "2020-01-01", superseded_at: str | None = None) -> None:
        self.signals["attributes"].append({"id": len(self.signals["attributes"]) + 1, "customer_id": customer_id, "attribute": attribute, "value": value,
                                           "valid_from": valid_from, "valid_to": valid_to, "basis": basis, "recorded_at": recorded_at,
                                           "superseded_at": superseded_at})  # fmt: skip

    def _signal_frames(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        when = lambda frame, columns: frame.assign(**{c: pd.to_datetime(frame[c], format="ISO8601").astype("datetime64[ns]") for c in columns})  # noqa: E731
        if self.signals["sentiment"]:
            out["sentiment"] = pd.DataFrame(self.signals["sentiment"])
        if self.signals["catalog"]:
            out["catalog"] = when(pd.DataFrame(self.signals["catalog"]), ["release_date", "retired_date", "first_seen"])
        if self.signals["identity"]:
            links = when(pd.DataFrame(self.signals["identity"]), ["valid_from", "valid_to"])
            out["identity"] = links.assign(customer_id=pd.to_numeric(links["customer_id"], errors="coerce").astype("float64"))
        if self.signals["attributes"]:
            history = when(pd.DataFrame(self.signals["attributes"]), ["valid_from", "valid_to", "recorded_at", "superseded_at"])
            out["attributes"] = history.assign(known_from=history["recorded_at"].where(history["basis"].isin(["observed", "correction"]), pd.NaT))
        if self.activity is not None:
            out["activity"] = self.activity
        return out

    def frames(self) -> dict[str, pd.DataFrame]:
        frames = {name: _table(name, rows) for name, rows in self.rows.items()}
        frames.update(self._signal_frames())
        hist = pd.DataFrame(self.history, columns=["account_id", "changed_at", "previous_expiry"])
        hist["changed_at"] = pd.to_datetime(hist["changed_at"], format="ISO8601").astype("datetime64[ns]")
        hist["previous_expiry"] = pd.to_datetime(hist["previous_expiry"], format="ISO8601").astype("datetime64[ns]")
        frames["account_history"] = hist
        return frames
