"""The nightly chain (data quality -> labels -> features -> scoring -> recommendations -> monitoring),
its scheduler and its failure behaviour."""

from __future__ import annotations

from datetime import UTC, date, datetime, timedelta
from types import SimpleNamespace

import pytest
from sqlalchemy import func, select, update

from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import ValidationFailed
from churn_platform.models import (
    Alert,
    AuditEvent,
    ChurnLabel,
    Customer,
    DataSource,
    DQRun,
    DriftReport,
    FeatureVector,
    Job,
    LabelRun,
    MLDataset,
    ModelVersion,
    Prediction,
    PredictionBatch,
    RetentionRecommendation,
    Schedule,
    UsageEvent,
    User,
)
from churn_platform.services import jobs, mlprep, monitoring, pipeline, predictions
from churn_platform.worker.runner import Worker
from tests.test_ingestion import upload

pytestmark = pytest.mark.req("REQ-OPS-04")

USAGE_SOURCE = "Synthetic usage events"


def _chain(job_type: str = "pipeline.nightly") -> list[Job]:
    with read_session() as s:
        return list(s.execute(select(Job).where(Job.job_type == job_type).order_by(Job.id)).scalars())


def _count(model, *where) -> int:
    with read_session() as s:
        return s.execute(select(func.count()).select_from(model).where(*where)).scalar_one()


def _audit_actions(action: str) -> list[AuditEvent]:
    with read_session() as s:
        return list(s.execute(select(AuditEvent).where(AuditEvent.action == action).order_by(AuditEvent.id)).scalars())


def _start(demo, role: str = "admin") -> int:
    with session_scope() as s:
        return pipeline.start(s, demo.principal(role))[0].id


# ----------------------------------------------------------------------------- the happy path
def test_the_chain_runs_every_step_in_order_and_reports_what_it_did(demo):
    before = {"dq": _count(DQRun), "labels": _count(LabelRun), "reports": _count(DriftReport), "batches": _count(PredictionBatch)}
    root = _start(demo)
    demo.drain()
    ticks = _chain()
    final = ticks[-1].result
    assert final["state"] == "completed" and [s["step"] for s in final["steps"]] == list(pipeline.STEPS)
    assert pipeline.STEPS == ("data_quality", "signals", "labels", "features", "scoring", "recommendations", "monitoring")
    steps = {s["step"]: s for s in final["steps"]}
    assert {k: v["status"] for k, v in steps.items()} == {
        "data_quality": "succeeded", "signals": "succeeded", "labels": "succeeded", "features": "succeeded", "scoring": "skipped",
        "recommendations": "succeeded", "monitoring": "succeeded"}  # fmt: skip
    # nothing new arrived since the seeded batch, so this date is not scored a second time
    assert steps["scoring"] == {"step": "scoring", "job_id": None, "status": "skipped", "batch_id": demo.summary["batch_id"], "already_scored": True}
    assert (steps["labels"]["from"], steps["labels"]["to"], steps["labels"]["scored_dates_labelled"]) == ("2026-08-01", "2026-11-01", [])
    assert steps["features"]["as_of_date"] == "2026-11-01" and steps["recommendations"]["batch_id"] == demo.summary["batch_id"]
    # one tick per step plus the closing tick; each continuation is keyed so that it can exist only once
    assert len(ticks) == 8 and ticks[0].id == root and [t.result["state"] for t in ticks] == ["queued"] * 7 + ["completed"]
    assert [t.idempotency_key for t in ticks] == [None] + [f"pipeline.nightly:chain:{root}:step:{n}" for n in range(1, 8)]
    with read_session() as s:
        order = [s.get(Job, steps[name]["job_id"]).job_type for name in pipeline.STEPS if steps[name]["job_id"]]
        label_run = s.get(LabelRun, steps["labels"]["label_run_id"])
        actions = s.execute(select(AuditEvent.action).where(AuditEvent.action.in_(("pipeline.started", "pipeline.completed")))
                            .order_by(AuditEvent.id)).scalars().all()  # fmt: skip
        runs = pipeline.last_runs(s, demo.tenant_id)
    assert order == ["quality.run", "signals.refresh", "labels.run", "features.materialize", "retention.generate", "monitoring.run"]
    assert label_run.as_of_dates == ["2026-08-01", "2026-09-01", "2026-10-01", "2026-11-01"], "recent months are re-labelled: their outcomes mature later"
    assert actions == ["pipeline.started", "pipeline.completed"]
    assert len(runs) == 1 and runs[0]["status"] == "succeeded" and runs[0]["result"]["state"] == "completed"
    after = {"dq": _count(DQRun), "labels": _count(LabelRun), "reports": _count(DriftReport), "batches": _count(PredictionBatch)}
    assert after == {"dq": before["dq"] + 1, "labels": before["labels"] + 1, "reports": before["reports"] + 3, "batches": before["batches"]}
    assert _count(Alert) == 0


def test_new_data_moves_the_scoring_date_and_the_chain_scores_recommends_and_monitors_it(demo):
    admin = demo.principal("admin")
    with read_session() as s:
        source_id = s.execute(select(DataSource.id).where(DataSource.name == USAGE_SOURCE)).scalar_one()
        assert predictions.default_as_of(s, demo.tenant_id) == date(2026, 11, 1)
    rows = ["customer_id,timestamp,event,feature,duration_seconds,count"]
    rows += [f"C00000{n},2026-11-0{day}T09:15:00Z,login,,300,1" for n in (1, 3, 4) for day in (2, 3, 5)]
    run = upload(admin, source_id, "usage_november.csv", "\n".join(rows) + "\n", mode="incremental")
    assert (run.status, run.rows_inserted, run.rows_quarantined) == ("completed", 9, 0)
    with read_session() as s:
        assert predictions.default_as_of(s, demo.tenant_id) == date(2026, 11, 6), "the day after the newest observed day"
    _start(demo)
    demo.drain()
    final = _chain()[-1].result
    steps = {s["step"]: s for s in final["steps"]}
    assert final["state"] == "completed" and all(s["status"] == "succeeded" for s in steps.values()), steps
    assert steps["features"]["as_of_date"] == "2026-11-06" and steps["scoring"]["already_scored"] is False
    with read_session() as s:
        batch = s.get(PredictionBatch, steps["scoring"]["batch_id"])
        assert (batch.kind, batch.status, batch.as_of_date, batch.created_by) == ("scheduled", "completed", date(2026, 11, 6), admin.user_id)
        assert (batch.total, batch.succeeded, batch.failed) == (212, 212, 0)
        assert s.execute(select(func.count()).select_from(Prediction).where(Prediction.batch_id == batch.id)).scalar_one() == 212
        assert s.execute(select(func.count()).select_from(FeatureVector).where(FeatureVector.as_of_date == date(2026, 11, 6))).scalar_one() == 212
        assert steps["recommendations"]["batch_id"] == batch.id
        assert s.execute(select(func.count()).select_from(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch.id)).scalar_one() > 0
        reports = monitoring.latest_reports(s, demo.tenant_id)
        ids = s.execute(select(Customer.id).where(Customer.external_id.in_(["C000001", "C000003", "C000004"]))).scalars().all()
        vectors = dict(s.execute(select(FeatureVector.customer_id, FeatureVector.values).where(
            FeatureVector.as_of_date == date(2026, 11, 6), FeatureVector.customer_id.in_(ids))).all())  # fmt: skip
        week = dict(s.execute(select(UsageEvent.customer_id, func.sum(func.coalesce(UsageEvent.quantity, 1))).where(
            UsageEvent.customer_id.in_(ids), UsageEvent.event_type.in_(("login", "session")), UsageEvent.occurred_at >= datetime(2026, 10, 30, tzinfo=UTC),
            UsageEvent.occurred_at < datetime(2026, 11, 6, tzinfo=UTC)).group_by(UsageEvent.customer_id)).all())  # fmt: skip
    assert len(vectors) == 3 and {c: v["logins_7d"] for c, v in vectors.items()} == week, "the new usage reached the feature vectors"
    assert all(n >= 3 for n in week.values()), "each of the three customers logged in on three of the new days"
    assert reports["prediction"]["current"] == {"batch_id": batch.id, "as_of_date": "2026-11-06"}
    # the chain stores the vectors of its date before it scores, so monitoring reads them back instead of computing them
    assert reports["feature"]["current"] == {"batch_id": batch.id, "as_of_date": "2026-11-06", "feature_source": "offline feature store"}
    counts = reports["concept"]["result"]["batch_counts"]
    assert counts == {"scored": 3, "with_outcomes": 1, "awaiting_outcomes": 2, "shown": 3}
    # a second night with no new data: the same date is not scored twice
    _start(demo)
    demo.drain()
    assert _chain()[-1].result["steps"][4] == {"step": "scoring", "job_id": None, "status": "skipped", "batch_id": batch.id, "already_scored": True}
    assert _count(PredictionBatch, PredictionBatch.kind == "scheduled") == 1


# ----------------------------------------------------------------------------- outcomes of scored dates
def test_scored_dates_are_labelled_once_their_window_closes_so_performance_can_be_measured(demo):
    """DEF-019: only month starts were labelled, so a nightly batch scored on any other day never got outcomes."""
    admin = demo.principal("admin")
    with session_scope() as s:
        closed, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-09-15", kind="backtest")
        still_open, _ = predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date="2026-10-15", kind="backtest")
        closed_id, open_id = closed.id, still_open.id
    demo.drain()
    with read_session() as s:
        # 15 September + 30 days has passed (data runs to 31 October); 15 October + 30 days has not
        assert pipeline.scored_dates_due(s, demo.tenant_id, date(2026, 11, 1)) == [date(2026, 9, 15)]
        assert pipeline.scored_dates_due(s, demo.tenant_id, date(2026, 11, 14)) == [date(2026, 10, 15), date(2026, 9, 15)], "newest first"
        assert pipeline.scored_dates_due(s, demo.tenant_id, date(2026, 10, 14)) == []
    before = _count(ChurnLabel)
    _start(demo)
    demo.drain()
    final = _chain()[-1].result
    labels_step = final["steps"][2]
    assert labels_step["scored_dates_labelled"] == ["2026-09-15"] and final["state"] == "completed"
    with read_session() as s:
        by_status = dict(s.execute(select(ChurnLabel.status, func.count()).where(ChurnLabel.as_of_date == date(2026, 9, 15)).group_by(ChurnLabel.status)).all())
        assert pipeline.scored_dates_due(s, demo.tenant_id, date(2026, 11, 1)) == [], "labelled once: it is not requested again"
        concept = monitoring.latest_reports(s, demo.tenant_id)["concept"]["result"]
        scored = s.execute(select(func.count()).select_from(Prediction).where(Prediction.batch_id == closed_id)).scalar_one()
    assert set(by_status) == {"churned", "retained", "ineligible"} and by_status["churned"] > 0 and _count(ChurnLabel) == before + sum(by_status.values())
    rows = {b["batch_id"]: b for b in concept["batches"]}
    measured = rows[closed_id]
    assert measured["status"] == "ok" and measured["labelled"] == by_status["churned"] + by_status["retained"] == scored
    assert measured["positives"] == by_status["churned"] and measured["pr_auc"] is not None
    assert measured["sample"] == "test_period", "inside the model's test period by date: a back-test, not new evidence"
    assert rows[open_id]["status"] == "insufficient_data" and rows[open_id]["labelled"] == 0
    assert [b["as_of_date"] for b in concept["batches"]] == ["2026-11-01", "2026-10-15", "2026-10-01", "2026-09-15"], "newest first"
    assert concept["batch_counts"] == {"scored": 4, "with_outcomes": 2, "awaiting_outcomes": 2, "shown": 4}
    assert concept["latest"]["batch_id"] == 2, "rules are driven by the newest date with known outcomes"
    # labels for scoring dates never become training rows: the training grid stays monthly
    with session_scope() as s:
        dataset, _ = mlprep.start_build(s, admin, name="with-scored-dates", contract_id=demo.summary["contract_id"])
        dataset_id = dataset.id
    demo.drain()
    with read_session() as s:
        new, old = s.get(MLDataset, dataset_id), s.get(MLDataset, demo.summary["dataset_id"])
        assert new.status == "ready" and new.fingerprint == old.fingerprint, "identical to the dataset built before the scoring-date labels existed"
        assert all(d.endswith("-01") for part in new.class_balance.values() for d in part["as_of_dates"])


def test_sample_of_classifies_scoring_dates_against_the_model_data_window():
    ends = {"train": "2026-06-01", "valid": "2026-08-01", "test": "2026-10-01"}
    assert [monitoring.sample_of(d, ends) for d in ("2025-09-01", "2026-06-01", "2026-06-02", "2026-08-01", "2026-09-15", "2026-10-01", "2026-10-02")] == [
        "in_sample_training", "in_sample_training", "validation_period", "validation_period", "test_period", "test_period", "after_model_data"]  # fmt: skip
    assert monitoring.sample_of("2026-01-01", {}) == "after_model_data"


def test_the_performance_report_stays_bounded_when_batches_pile_up(demo):
    admin = demo.principal("admin")
    days = [date(2026, 9, 2) + timedelta(days=n) for n in range(15)]  # 15 more scored dates whose windows have closed
    with session_scope() as s:
        for day in days:
            predictions.start_batch(s, admin, tenant_id=demo.tenant_id, as_of_date=day, kind="backtest")
    demo.drain()
    _start(demo)
    demo.drain()
    with read_session() as s:
        concept = monitoring.latest_reports(s, demo.tenant_id)["concept"]["result"]
    assert concept["batch_counts"] == {"scored": 17, "with_outcomes": 16, "awaiting_outcomes": 1, "shown": 13}
    shown = [b["as_of_date"] for b in concept["batches"]]
    assert shown == ["2026-11-01", "2026-10-01", *[d.isoformat() for d in reversed(days)][:11]] and len(shown) == monitoring.MAX_MEASURED_BATCHES + 1


# ----------------------------------------------------------------------------- failure
def test_the_chain_stops_when_a_step_cannot_start_and_raises_an_alert(demo):
    with session_scope() as s:
        s.execute(update(ModelVersion).values(stage="archived"))
    root = _start(demo)
    Worker().drain()
    ticks = _chain()
    assert [t.status for t in ticks] == ["succeeded", "succeeded", "succeeded", "failed"], "data quality, signals and labels ran; 'features' needs a production model"
    failed = ticks[-1]
    assert "nightly pipeline stopped at 'features'" in failed.error and "production" in failed.error and failed.attempts == 1
    with read_session() as s:
        alert = s.execute(select(Alert)).scalar_one()
        runs = pipeline.last_runs(s, demo.tenant_id)
    assert (alert.kind, alert.severity, alert.status, alert.source_type, alert.source_id) == ("pipeline_nightly_failed", "critical", "open", "job", failed.id)
    assert alert.title == "The nightly pipeline stopped at step 'features'" and alert.detail["root_job_id"] == root
    assert [s["step"] for s in alert.detail["steps"]] == ["data_quality", "signals", "labels"] and alert.message in failed.error
    assert len(runs) == 1 and runs[0]["status"] == "failed"
    assert _count(Job, Job.status.in_(("queued", "running")), Job.job_type != "campaign.tick") == 0, "nothing is left behind to run later"


def test_the_chain_stops_when_a_step_fails_while_running(demo, monkeypatch):
    def broken(ctx):
        raise jobs.PermanentJobError("the warehouse is unreachable")

    jobs.load_handlers()
    monkeypatch.setitem(jobs.HANDLERS, "labels.run", broken)
    _start(demo)
    Worker().drain()
    ticks = _chain()
    assert [t.status for t in ticks] == ["succeeded", "succeeded", "succeeded", "failed"]
    assert "nightly pipeline stopped: step 'labels' failed" in ticks[-1].error and "the warehouse is unreachable" in ticks[-1].error
    with read_session() as s:
        alert = s.execute(select(Alert)).scalar_one()
    assert alert.title == "The nightly pipeline stopped at step 'labels'" and alert.detail["steps"][-1]["status"] == "failed"
    assert _count(Job, Job.job_type == "features.materialize", Job.id > ticks[0].id) == 0, "later steps never started"


# ----------------------------------------------------------------------------- at-least-once delivery
def test_a_tick_that_is_delivered_twice_never_starts_its_step_again(demo):
    admin = demo.principal("admin")
    root = _start(demo)
    assert Worker().run_once() is True  # the first tick: starts data quality and queues its continuation
    assert _count(DQRun, DQRun.status == "running") == 1 and len(_chain()) == 2
    # the worker died after committing and the queue hands the same tick to another worker
    redelivered = SimpleNamespace(payload={"step": 0, "log": []}, tenant_id=demo.tenant_id, created_by=admin.user_id, job_id=root)
    assert pipeline.run(redelivered) == {"state": "already_advanced", "step": "data_quality"}
    assert _count(DQRun, DQRun.status == "running") == 1 and len(_chain()) == 2
    demo.drain()
    assert _chain()[-1].result["state"] == "completed" and len(_chain()) == 8


def test_a_tick_waits_for_a_step_that_is_still_running(demo, monkeypatch):
    _start(demo)
    orchestrator = Worker(job_types=["pipeline.nightly"])  # a worker that only runs chain ticks: the steps stay queued
    assert orchestrator.run_once() is True and orchestrator.run_once() is True
    ticks = _chain()
    assert [t.result["state"] for t in ticks[:2]] == ["queued", "waiting"] and ticks[1].result["step"] == "data_quality"
    poll = ticks[2]
    assert poll.status == "queued" and poll.payload == ticks[1].payload, "the same tick, to be looked at again"
    wait = (poll.run_after - utcnow()).total_seconds()
    assert pipeline.POLL_SECONDS - 2 < wait <= pipeline.POLL_SECONDS and orchestrator.run_once() is False, "not before the polling interval has passed"
    monkeypatch.setattr(pipeline, "POLL_SECONDS", 0)
    with session_scope() as s:
        s.execute(update(Job).where(Job.id == poll.id).values(run_after=utcnow()))
    demo.drain()
    assert _chain()[-1].result["state"] == "completed"
    assert _count(DQRun) == 2, "the seeded run plus exactly one from this chain"


def test_a_second_start_joins_the_run_that_is_under_way_instead_of_doing_the_night_twice(demo):
    """Pressing "run now" twice, or the schedule firing during a manual run, used to run every step twice in parallel."""
    admin = demo.principal("admin")
    with session_scope() as s:
        first, started = pipeline.start(s, admin)
        assert started is True and first.status == "queued"
        root = first.id
    with session_scope() as s:
        again, started_again = pipeline.start(s, demo.principal("data_scientist"))
        assert (again.id, started_again) == (root, False), "the run that is under way is returned; nothing new is queued"
    assert len(_chain()) == 1 and len(_audit_actions("pipeline.started")) == 1
    assert Worker().run_once() is True  # first tick: data quality queued, continuation queued
    with session_scope() as s:
        live, started_mid = pipeline.start(s, admin)
        assert started_mid is False and live.payload["root_job_id"] == root, "mid-run, the live tick of the same chain is returned"
    # the schedule fires while that run is under way: its job is queued by the scheduler, which knows nothing about the manual run
    slot = utcnow().replace(microsecond=0) - timedelta(minutes=1)
    with session_scope() as s:
        s.execute(update(Schedule).values(next_run_at=slot, enabled=True))
    assert Worker().maintenance()["scheduled"] == 1
    before = {"dq": _count(DQRun), "labels": _count(LabelRun), "reports": _count(DriftReport)}
    demo.drain()
    ticks = _chain()
    scheduled = next(t for t in ticks if (t.idempotency_key or "").startswith("schedule:"))
    assert scheduled.status == "succeeded" and scheduled.result == {
        "state": "skipped", "reason": f"another nightly pipeline run is under way (started by job {root})", "active_root_job_id": root}
    assert [t.result["state"] for t in ticks].count("completed") == 1 and len(ticks) == 9, "one chain of eight ticks plus the skipped start"
    assert (_count(DQRun), _count(LabelRun)) == (before["dq"], before["labels"] + 1), "each step ran once (data quality had started already)"
    assert _count(DriftReport) > before["reports"] and _count(Alert) == 0
    # once that run has finished, the next start is a new run
    with session_scope() as s:
        later, started_later = pipeline.start(s, admin)
        assert started_later is True and later.id > ticks[-1].id
    assert pipeline.active_chain.__doc__ and len(_audit_actions("pipeline.started")) == 2


def test_two_chains_started_at_the_same_moment_do_not_cancel_each_other(demo):
    """The guard compares who started first, so of two roots queued together exactly one runs."""
    admin = demo.principal("admin")
    with session_scope() as s:  # two roots queued behind the guard's back (two schedulers, or a schedule next to a manual start)
        a = jobs.enqueue(s, tenant_id=demo.tenant_id, job_type="pipeline.nightly", payload={"step": 0, "log": []}, created_by=admin.user_id).id
        b = jobs.enqueue(s, tenant_id=demo.tenant_id, job_type="pipeline.nightly", payload={"step": 0, "log": []}, created_by=admin.user_id).id
    demo.drain()
    with read_session() as s:
        first, second = s.get(Job, a), s.get(Job, b)
    assert first.result["state"] == "queued" and second.result["state"] == "skipped" and second.result["active_root_job_id"] == a
    assert [t.result["state"] for t in _chain()].count("completed") == 1
    # another tenant's chain is not affected by this one
    with read_session() as s:
        assert pipeline.active_chain(s, demo.tenant_id + 1000, "pipeline.nightly") is None


# ----------------------------------------------------------------------------- scheduling and ownership
def test_the_schedule_is_created_once_and_fires_one_chain_per_night(demo):
    admin = demo.principal("admin")
    with session_scope() as s, pytest.raises(ValidationFailed, match="hour_utc must be between 0 and 23"):
        pipeline.ensure_schedule(s, admin, hour_utc=24)
    with session_scope() as s:
        schedule = pipeline.ensure_schedule(s, admin, hour_utc=3)
        schedule_id = schedule.id
        assert (schedule.job_type, schedule.interval_seconds, schedule.enabled, schedule.payload) == ("pipeline.nightly", 86400, True, {"step": 0, "log": []})
        assert schedule.next_run_at.hour == 3 and timedelta(0) < schedule.next_run_at - utcnow() <= timedelta(days=1)
    with session_scope() as s:
        assert pipeline.ensure_schedule(s, admin, hour_utc=5, enabled=False).id == schedule_id
    assert _count(Schedule) == 1, "saving again updates the one schedule"
    slot = utcnow().replace(microsecond=0) - timedelta(days=3, minutes=5)  # the platform was down for three nights
    with session_scope() as s:
        s.execute(update(Schedule).values(next_run_at=slot))
    assert Worker().maintenance()["scheduled"] == 0, "a disabled schedule does not fire"
    with session_scope() as s:
        s.execute(update(Schedule).values(enabled=True))
    assert Worker().maintenance()["scheduled"] == 1 and Worker().maintenance()["scheduled"] == 0
    with read_session() as s:
        schedule = s.get(Schedule, schedule_id)
        job = s.get(Job, schedule.last_job_id)
    assert job.idempotency_key == f"schedule:{schedule_id}:{slot.isoformat()}" and job.created_by == admin.user_id
    assert schedule.next_run_at == slot + timedelta(days=4), "missed nights collapse into one run; the next slot is in the future"
    demo.drain()
    assert _chain()[-1].result["state"] == "completed" and len(_chain()) == 8


def test_scheduled_work_runs_as_its_owner_or_falls_back_to_an_active_admin(demo):
    analyst, admin = demo.principal("analyst"), demo.principal("admin")
    with read_session() as s:
        assert pipeline.owner_principal(s, demo.tenant_id, analyst.user_id).user_id == analyst.user_id
        assert pipeline.owner_principal(s, demo.tenant_id, None).user_id == admin.user_id
        assert pipeline.owner_principal(s, demo.tenant_id, 999_999).user_id == admin.user_id
    with session_scope() as s:
        s.execute(update(User).where(User.id == analyst.user_id).values(is_active=False))
    with read_session() as s:
        fallback = pipeline.owner_principal(s, demo.tenant_id, analyst.user_id)
        assert (fallback.user_id, fallback.role, fallback.tenant_id) == (admin.user_id, "admin", demo.tenant_id), "a deactivated owner does not strand the schedule"
    with session_scope() as s:
        s.execute(update(User).where(User.role == "admin").values(is_active=False))
    _start(demo, "approver")
    with session_scope() as s:
        s.execute(update(User).values(is_active=False))
    Worker().drain()
    assert "no active admin user to own scheduled work" in _chain()[-1].error
