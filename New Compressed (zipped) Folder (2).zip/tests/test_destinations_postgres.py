"""A destination that is a real database, exercised against a real server (1.3.0).

Every other test of the delivery layer uses a destination written for the test.  That is honest — it says the pipeline
does what the pipeline says — and it is not the same thing as a destination that has constraints the platform did not
choose, enforced by a server in another process, holding rows that can be read back with a connection that has never
heard of this module.  These tests are that second thing, against PostgreSQL.

What they do **not** prove, and the register says so: PostgreSQL is not Snowflake.  The statement GATE 12 has to accept
is a ``MERGE``; the statement here is ``INSERT … ON CONFLICT``.  A row in this table says the record, the identity, the
outbox and the watermark are right; it says nothing about an account nobody has.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

import psycopg
import pytest

from churn_platform.db import session_scope
from churn_platform.errors import ValidationFailed
from churn_platform.services import exports
from churn_platform.services.destinations.base import FAILED, deliver
from churn_platform.services.destinations.postgres import PostgresConfig, PostgresDestination

pytestmark = [pytest.mark.req("REQ-ACT-02"), pytest.mark.postgres]


def _dsn(url: str) -> str:
    """psycopg wants the driver-relative URL; SQLAlchemy's ``+psycopg`` suffix is not libpq syntax."""
    return url.replace("postgresql+psycopg://", "postgresql://", 1)


@pytest.fixture
def schema(postgres_url: str):
    """A schema of its own per test, dropped afterwards: these tests write to a real database and tidy up after it."""
    name = f"dest_{uuid.uuid4().hex[:12]}"
    yield name
    with psycopg.connect(_dsn(postgres_url), connect_timeout=10) as connection:
        connection.autocommit = True
        connection.execute(f'DROP SCHEMA IF EXISTS "{name}" CASCADE')


@pytest.fixture
def destination(postgres_url: str, schema: str) -> PostgresDestination:
    config = PostgresConfig(url=_dsn(postgres_url), schema=schema)
    built = PostgresDestination(config=config, connect=psycopg.connect)
    yield built
    built.close()


def _read(postgres_url: str, schema: str, query: str, parameters: dict[str, Any] | None = None) -> list[tuple]:
    """Read the destination's tables with a connection that is not the adapter's, in the same schema."""
    with psycopg.connect(_dsn(postgres_url), connect_timeout=10) as connection:
        connection.autocommit = True
        connection.execute(f'SET search_path TO "{schema}"')
        return connection.execute(query, parameters).fetchall()


def _records(demo: Any, limit: int = 25) -> list[dict]:
    """The real canonical records of the seeded batch: built by the product, not by the test."""
    with session_scope() as session:
        return exports.records_for(session, demo.tenant_id, {"batch_id": demo.summary["batch_id"], "limit": limit})


# ----------------------------------------------------------------------------- the session and the schema
def test_the_connection_reports_its_session_and_lands_in_the_configured_schema(destination):
    """A destination that reports the wrong schema is the 1.2.0 defect, in another dialect: the session is asked, and
    the answer has to be the configuration rather than the server's default."""
    report = destination.test_connection()
    assert report["ok"] is True and report["session"]["schema"] == destination.config.schema
    assert report["session"]["database"] == "churn_test" and "PostgreSQL 17" in report["session"]["version"]
    assert report["health"] == "the session answered and is the configured one"
    # a destination configured for the session's default schema reports that schema and not the request's
    plain = PostgresDestination(config=PostgresConfig(url=destination.config.url, schema="public"), connect=destination.connect)
    try:
        assert plain.test_connection()["session"]["schema"] == "public"
    finally:
        plain.close()


def test_a_refused_connection_is_a_refusal_with_a_reason(postgres_url):
    """An unreachable server raises the error an operator can act on, naming no password."""
    config = PostgresConfig(url="postgresql://nobody:secret@127.0.0.1:1/nothing", schema="public")
    refused = PostgresDestination(config=config, connect=psycopg.connect)
    with pytest.raises(ValidationFailed) as raised:
        refused.test_connection()
    assert "PostgreSQL refused the connection" in raised.value.message
    assert "secret" not in str(raised.value.details), "the password never reaches the details of an error"


def test_an_identifier_that_is_not_one_is_refused_not_quoted(destination):
    """Configuration is input.  A schema or table name that could end a statement never becomes one."""
    from churn_platform.services.destinations.postgres import quote

    for bad in ('public; DROP TABLE x', "two words", "", "a" * 70, "9starts_with_a_digit"):
        with pytest.raises(ValidationFailed):
            quote(bad)
        assert PostgresConfig(url=destination.config.url, schema=bad).problems(), f"{bad!r} must be a problem"
    assert quote("a_normal_name") == '"a_normal_name"' and quote("_x9") == '"_x9"'  # a valid name is quoted, not changed


# ----------------------------------------------------------------------------- rows in a real table
def test_real_records_land_in_a_real_table_and_can_be_read_back(destination, demo, postgres_url):
    """The whole point: a batch the product selected is in a PostgreSQL table, readable by somebody else."""
    records = _records(demo)
    assert len(records) >= 20
    destination.ensure_schema()
    result = deliver(destination, records, run_id="run-1")
    assert result.written == len(records) and result.failed == 0 and not result.quarantined
    assert result.watermark is not None

    rows = _read(postgres_url, destination.config.schema, "SELECT COUNT(*) FROM churn_predictions")[0][0]
    assert rows == len(records)
    stored = _read(
        postgres_url,
        destination.config.schema,
        'SELECT "external_customer_id", "churn_probability", "risk_tier", "model_version", "sync_run_id" '
        'FROM churn_predictions WHERE "external_customer_id" = %(external)s',
        {"external": records[0]["external_customer_id"]},
    )
    assert len(stored) == 1
    external, probability, tier, version, run_id = stored[0]
    source = next(record for record in records if record["external_customer_id"] == external)
    assert probability == pytest.approx(source["churn_probability"])
    assert (tier, version, run_id) == (source["risk_tier"], source["model_version"], "run-1")


def test_the_identity_is_enforced_by_the_server_not_by_the_adapter(destination, demo, postgres_url):
    """Two writes of the same customer-day are one row; a second tenant with the same customer id is another row."""
    records = _records(demo)[:5]
    destination.ensure_schema()
    assert deliver(destination, records, run_id="run-1").written == len(records)
    assert deliver(destination, records, run_id="run-2").written == len(records)
    count = _read(postgres_url, destination.config.schema, "SELECT COUNT(*) FROM churn_predictions")[0][0]
    assert count == len(records), "the same identity twice is one row"
    latest = _read(postgres_url, destination.config.schema, 'SELECT DISTINCT "sync_run_id" FROM churn_predictions')
    assert latest == [("run-2",)], "the later write is the one that stands"

    # the same customer id, another tenant: the identity leads with the tenant, so this is a new row
    elsewhere = [{**records[0], "tenant_id": records[0]["tenant_id"] + 1000}]
    assert deliver(destination, elsewhere, run_id="run-3").written == 1
    count = _read(postgres_url, destination.config.schema, "SELECT COUNT(*) FROM churn_predictions")[0][0]
    assert count == len(records) + 1
    assert destination.count_stored(run_id="run-3") == 1


def test_a_record_that_may_not_be_exported_never_reaches_the_table(destination, demo, postgres_url):
    """Validation happens before the destination sees anything, and the quarantine is a result rather than a crash."""
    records = _records(demo)[:4]
    records[1] = {**records[1], "churn_probability": 1.7}
    destination.ensure_schema()
    result = deliver(destination, records, run_id="run-1")
    assert len(result.quarantined) == 1 and result.written == 3
    assert _read(postgres_url, destination.config.schema, "SELECT COUNT(*) FROM churn_predictions")[0][0] == 3


def test_a_constraint_the_server_enforces_is_a_failed_record_and_not_a_lost_batch(destination, demo, postgres_url):
    """The table is not the adapter's to assume: a column somebody added with NOT NULL fails the write, and says so."""
    records = _records(demo)[:3]
    destination.ensure_schema()
    with psycopg.connect(_dsn(destination.config.url), connect_timeout=10) as connection:
        connection.autocommit = True
        connection.execute(f'ALTER TABLE "{destination.config.schema}".churn_predictions ADD COLUMN "drifted" TEXT NOT NULL')
    result = deliver(destination, records, run_id="run-1")
    assert result.written == 0 and result.failed == len(records)
    assert all(outcome.status == FAILED and "drifted" in (outcome.error_description or "") for outcome in result.outcomes)
    with psycopg.connect(_dsn(destination.config.url), connect_timeout=10) as connection:
        connection.autocommit = True
        connection.execute(f'ALTER TABLE "{destination.config.schema}".churn_predictions DROP COLUMN "drifted"')
    repaired = deliver(destination, records, run_id="run-2")
    assert repaired.written == len(records) and repaired.failed == 0, "the same records go in once the table allows them"


def test_the_count_it_reports_is_the_table_s_count(destination, demo, postgres_url):
    records = _records(demo)[:7]
    destination.ensure_schema()
    deliver(destination, records, run_id="run-1")
    assert destination.count_stored(run_id="run-1") == len(records) == _read(
        postgres_url, destination.config.schema, "SELECT COUNT(*) FROM churn_predictions"
    )[0][0]
    assert destination.count_stored(run_id="no-such-run") == 0
    assert destination.health() == {"ok": True, "table": "churn_predictions", "rows": len(records)}


def test_the_run_row_is_written_where_an_operator_can_read_it(destination, postgres_url):
    """Anyone who may read the database can reconcile a run without this platform: that is the point of the row."""
    started = datetime.now(UTC)
    destination.ensure_schema()
    destination.record_run(run_id="run-9", tenant_id=7, expected=10, written=9, checksum="abc", watermark=started,
                           actor="admin@corp.example", started_at=started)  # fmt: skip
    rows = _read(postgres_url, destination.config.schema,
                 'SELECT "tenant_id", "destination", "rows_expected", "rows_written", "checksum", "actor" '
                 'FROM churn_export_runs WHERE "run_id" = %(run)s', {"run": "run-9"})  # fmt: skip
    assert rows == [(7, "postgres", 10, 9, "abc", "admin@corp.example")]
    destination.record_run(run_id="run-9", tenant_id=7, expected=10, written=10, checksum="def", watermark=started,
                           actor="admin@corp.example", started_at=started)  # fmt: skip
    assert _read(postgres_url, destination.config.schema,
                 'SELECT "rows_written", "checksum" FROM churn_export_runs WHERE "run_id" = %(run)s',
                 {"run": "run-9"}) == [(10, "def")], "a retried run updates its row instead of writing a second history"  # fmt: skip


# ----------------------------------------------------------------------------- through the product, into the table
def test_an_export_reaches_a_real_table_through_the_api_and_the_worker(demo, monkeypatch, postgres_url, schema):
    """The claim this whole module exists for: an operator starts an export in the product, and the rows are in
    PostgreSQL — written by the worker, through the registry, and read back by a connection this code never touched."""
    from churn_platform.config import get_settings

    monkeypatch.setenv("CHURN_EXPORT_POSTGRES_URL", _dsn(postgres_url))
    monkeypatch.setenv("CHURN_EXPORT_POSTGRES_SCHEMA", schema)
    monkeypatch.setenv("CHURN_RATE_LIMIT_EXPORT_PER_MINUTE", "1000")
    get_settings.cache_clear()
    try:
        with demo.client() as client:
            headers = demo.login(client)
            listed = client.get("/api/v1/exports/destinations", headers=headers).json()["items"]
            assert {item["name"]: item["state"] for item in listed}["postgres"] == "configured"
            started = client.post("/api/v1/exports/runs", json={"destination": "postgres", "limit": 20}, headers=headers)
            assert started.status_code == 202, started.text
            run = started.json()["run"]
            demo.drain()
            detail = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers)
            reconciled = client.post(f"/api/v1/exports/runs/{run['id']}/reconcile", headers=headers)
        body = detail.json()["run"]
        assert body["status"] == "completed" and body["acknowledged"] == 20 and body["failed"] == 0
        verification = body["verification"]
        assert verification["delivery"]["destination_run_row"] == "recorded in postgres", verification

        rows = _read(postgres_url, schema, 'SELECT COUNT(*) FROM churn_predictions WHERE "sync_run_id" = %(run)s',
                     {"run": run["run_id"]})  # fmt: skip
        assert rows[0][0] == 20, "the rows are in the table, under this run's id"
        run_rows = _read(postgres_url, schema, 'SELECT "rows_written", "destination" FROM churn_export_runs WHERE "run_id" = %(run)s',
                         {"run": run["run_id"]})  # fmt: skip
        assert run_rows == [(20, "postgres")], "and the database carries the run's own row"
        result = reconciled.json()["reconciliation"]
        assert result["checked"] == "counted" and result["stored"] == 20 and result["matches"] is True
        # the reconciliation read the same table the assertion above did, through the adapter
        stored = _read(postgres_url, schema, "SELECT COUNT(*) FROM churn_predictions")[0][0]
        assert stored == 20, "nothing else was written"
    finally:
        get_settings.cache_clear()
