"""What leaves the platform (1.1.0): CRM sign-in with OAuth and signed CRM events, governed reverse-ETL syncs,
messages to customers through e-mail / SMS / push / in-app providers, and campaigns.

No test talks to a real vendor.  Vendors are stood in for by httpx transports that record what was sent."""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from datetime import timedelta
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
from sqlalchemy import func, select, update
from sqlalchemy.exc import IntegrityError

from churn_platform.config import get_settings
from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import Conflict, Forbidden, Unauthorized, ValidationFailed
from churn_platform.models import (
    Account,
    AuditEvent,
    Campaign,
    CampaignEnrollment,
    CRMConnection,
    CRMDelivery,
    Customer,
    Intervention,
    NotificationMessage,
    NotificationSuppression,
    Prediction,
    PredictionBatch,
    RetentionRecommendation,
    ReverseEtlRun,
)
from churn_platform.security import SecretBox
from churn_platform.services import campaigns, crm, crm_oauth, notify, retention, reverse_etl
from tests.conftest import activate

API = "/api/v1"
BASE = "https://churn.corp.example"


class Vendor:
    """Records requests and answers from a queue (default: 200 with ``reply``)."""

    def __init__(self, reply: dict | None = None, status: int = 200) -> None:
        self.requests: list[httpx.Request] = []
        self.queue: list[httpx.Response] = []
        self.reply, self.status = reply or {}, status

    def handler(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        return self.queue.pop(0) if self.queue else httpx.Response(self.status, json=self.reply)

    def transport(self) -> httpx.MockTransport:
        return httpx.MockTransport(self.handler)

    def forms(self) -> list[dict]:
        return [{k: v[0] for k, v in parse_qs(r.content.decode()).items()} for r in self.requests]


@pytest.fixture(autouse=True)
def without_seeded_outbound(request):
    """The seeded demo already has message providers, templates, a running dry-run campaign and an export sync.
    These tests build their own from nothing, so each starts from a tenant without any of it."""
    if "demo" not in request.fixturenames:
        return
    request.getfixturevalue("demo")
    from churn_platform.models import CampaignStep, Job, NotificationEvent, NotificationPreference, NotificationProvider, NotificationTemplate, ReverseEtlSync

    with session_scope() as s:
        for model in (NotificationEvent, NotificationMessage, CampaignEnrollment, CampaignStep, Campaign, NotificationTemplate, NotificationSuppression,
                      NotificationPreference, NotificationProvider, ReverseEtlRun, ReverseEtlSync):  # fmt: skip
            s.execute(model.__table__.delete())
        s.execute(Job.__table__.delete().where(Job.job_type == "campaign.tick", Job.status == "queued"))


def latest_batch() -> PredictionBatch:
    with read_session() as s:
        return s.execute(select(PredictionBatch).where(PredictionBatch.status == "completed").order_by(PredictionBatch.as_of_date.desc(), PredictionBatch.id.desc()).limit(1)).scalar_one()


def audit_actions(prefix: str) -> list[str]:
    with read_session() as s:
        return [e.action for e in s.execute(select(AuditEvent).where(AuditEvent.action.like(prefix + "%")).order_by(AuditEvent.id)).scalars()]


# ============================================================================= CRM: OAuth
def oauth_connection(demo, provider: str = "hubspot", mode: str = "SANDBOX") -> int:
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL=BASE, CHURN_CRM_ALLOW_PRIVATE_HOSTS="true")
    with session_scope() as s:
        base_url = {"hubspot": "https://api.hubapi.com", "salesforce": "https://login.salesforce.com", "intercom": "https://api.intercom.io"}[provider]
        connection = crm.create_connection(s, demo.principal("admin"), provider=provider, name=f"{provider} oauth", base_url=base_url, mode=mode, auth_type="oauth")
        crm_oauth.configure(s, demo.principal("admin"), connection.id, client_id="app-123", client_secret="app-secret", webhook_secret="w" * 24)
        return connection.id


@pytest.mark.req("REQ-ACT-04")
def test_a_crm_is_connected_through_its_consent_screen_and_tokens_are_kept_encrypted_and_fresh(demo):
    connection_id = oauth_connection(demo)
    vendor = Vendor({"access_token": "access-1", "refresh_token": "refresh-1", "expires_in": 1800, "token_type": "bearer"})
    crm_oauth.set_transport(vendor.transport())
    with session_scope() as s:
        started = crm_oauth.begin(s, demo.principal("admin"), connection_id)
    url = urlparse(started["authorization_url"])
    query = {k: v[0] for k, v in parse_qs(url.query).items()}
    assert f"{url.scheme}://{url.netloc}{url.path}" == "https://app.hubspot.com/oauth/authorize"
    assert query["client_id"] == "app-123" and query["redirect_uri"] == f"{BASE}/api/v1/crm/oauth/callback" == started["redirect_uri"] and len(query["state"]) >= 32
    assert query["scope"] == "crm.objects.companies.write crm.objects.companies.read"
    with demo.client() as c:
        back = c.get(f"{API}/crm/oauth/callback", params={"state": query["state"], "code": "auth-code"}, follow_redirects=False)
        assert back.status_code == 302 and back.headers["location"] == f"/#/syncs?connected={connection_id}"
        replay = c.get(f"{API}/crm/oauth/callback", params={"state": query["state"], "code": "auth-code"}, follow_redirects=False)
        assert "oauth_error" in replay.headers["location"], "a state is good for one authorisation"
    form = vendor.forms()[0]
    assert form == {"grant_type": "authorization_code", "code": "auth-code", "redirect_uri": f"{BASE}/api/v1/crm/oauth/callback", "client_id": "app-123",
                    "client_secret": "app-secret"} and str(vendor.requests[0].url) == "https://api.hubapi.com/oauth/v1/token"  # fmt: skip
    with read_session() as s:
        connection = s.get(CRMConnection, connection_id)
        assert connection.status == "connected" and connection.health["state"] == "connected" and connection.health["can_refresh"] is True
        assert "access-1" not in connection.credentials_enc and SecretBox().decrypt(connection.credentials_enc) == "access-1"
        assert SecretBox().decrypt(connection.refresh_token_enc) == "refresh-1" and connection.token_expires_at > utcnow() + timedelta(minutes=25)
        view = crm.connection_view(connection)
        assert not {"credentials_enc", "refresh_token_enc", "client_secret_enc", "webhook_secret_enc"} & set(view) and view["has_credentials"] is True
    # the token is about to expire: it is replaced before the next delivery, and the delivery carries the new one
    with session_scope() as s:
        s.execute(update(CRMConnection).where(CRMConnection.id == connection_id).values(token_expires_at=utcnow() + timedelta(seconds=30)))
    vendor.queue = [httpx.Response(200, json={"access_token": "access-2", "refresh_token": "refresh-2", "expires_in": 1800})]
    crm_oauth.ensure_fresh_token(connection_id)
    assert vendor.forms()[-1]["grant_type"] == "refresh_token" and vendor.forms()[-1]["refresh_token"] == "refresh-1"
    with read_session() as s:
        connection = s.get(CRMConnection, connection_id)
        assert SecretBox().decrypt(connection.credentials_enc) == "access-2" and SecretBox().decrypt(connection.refresh_token_enc) == "refresh-2"
    crm_oauth.ensure_fresh_token(connection_id)
    assert len(vendor.requests) == 2, "a token that is still good is not refreshed"
    assert audit_actions("crm.oauth") == ["crm.oauth_configured", "crm.oauth_connected", "crm.oauth_token_refreshed"]


@pytest.mark.req("REQ-ACT-04")
def test_a_dead_token_stops_deliveries_until_the_crm_is_authorised_again_and_disconnect_erases_it(demo):
    connection_id = oauth_connection(demo, "salesforce")
    vendor = Vendor({"access_token": "sf-access", "refresh_token": "sf-refresh", "instance_url": "https://acme.my.salesforce.com", "scope": "api refresh_token"})
    crm_oauth.set_transport(vendor.transport())
    crm.set_transport(vendor.transport())
    with session_scope() as s:
        state = parse_qs(urlparse(crm_oauth.begin(s, demo.principal("admin"), connection_id)["authorization_url"]).query)
        assert state["code_challenge_method"] == ["S256"], "Salesforce is asked with PKCE"
        crm_oauth.callback(s, state=state["state"][0], code="c")
        connection = s.get(CRMConnection, connection_id)
        assert connection.base_url == "https://acme.my.salesforce.com" and connection.token_expires_at is None and connection.scopes == ["api", "refresh_token"]
    assert "code_verifier" in vendor.forms()[0]
    batch = latest_batch()
    with session_scope() as s:
        crm.sync_risk_scores(s, demo.principal("admin"), connection_id, batch.id, tiers=("high",))
        delivery_id = s.execute(select(CRMDelivery.id).where(CRMDelivery.connection_id == connection_id).order_by(CRMDelivery.id).limit(1)).scalar_one()
    # the CRM says the token is not valid (401): one refresh is attempted, and the CRM refuses that too
    vendor.queue = [httpx.Response(401, json=[{"errorCode": "INVALID_SESSION_ID"}]), httpx.Response(400, json={"error": "invalid_grant"})]
    result = crm.deliver(delivery_id)
    assert result["status"] == "failed", "kept for a retry: nothing is lost while the connection waits for a new authorisation"
    assert vendor.requests[-2].headers["authorization"] == "Bearer sf-access" and vendor.forms()[-1]["grant_type"] == "refresh_token"
    with read_session() as s:
        connection = s.get(CRMConnection, connection_id)
        assert connection.status == "reauthorisation_required" and "invalid_grant" in connection.last_error
    sent_before = len(vendor.requests)
    assert crm.deliver(delivery_id)["status"] == "failed" and len(vendor.requests) == sent_before, "nothing is sent with a token known to be dead"
    with read_session() as s:
        assert "not authorised" in s.get(CRMDelivery, delivery_id).last_error and s.get(CRMConnection, connection_id).status == "reauthorisation_required"
    # disconnect: revoked at the vendor (Salesforce offers that) and erased here
    vendor.queue = [httpx.Response(200)]
    with session_scope() as s:
        gone = crm_oauth.disconnect(s, demo.principal("admin"), connection_id)
        assert gone.credentials_enc is None and gone.refresh_token_enc is None and gone.status == "disconnected" and gone.health["revoked_at_vendor"] is True
    assert str(vendor.requests[-1].url) == "https://login.salesforce.com/services/oauth2/revoke" and vendor.forms()[-1] == {"token": "sf-refresh"}
    # the consent screen was declined
    with session_scope() as s:
        state = parse_qs(urlparse(crm_oauth.begin(s, demo.principal("admin"), connection_id)["authorization_url"]).query)["state"][0]
    with session_scope() as s, pytest.raises(Unauthorized):
        crm_oauth.callback(s, state=state, code=None, error="access_denied")
    with read_session() as s:
        assert s.get(CRMConnection, connection_id).health["state"] == "authorisation_refused"
    with session_scope() as s, pytest.raises(Unauthorized):
        crm_oauth.callback(s, state="never-issued", code="c")


def hubspot_signature(secret: str, method: str, url: str, body: bytes, stamp: str) -> str:
    return base64.b64encode(hmac.new(secret.encode(), f"{method}{url}".encode() + body + stamp.encode(), hashlib.sha256).digest()).decode()


@pytest.mark.req("REQ-ACT-04")
def test_signed_crm_events_are_stored_once_and_confirm_what_the_crm_holds(demo):
    connection_id = oauth_connection(demo)
    with session_scope() as s:
        connection = s.get(CRMConnection, connection_id)
        connection.credentials_enc = SecretBox().encrypt("token")
        delivery = CRMDelivery(tenant_id=demo.tenant_id, connection_id=connection_id, kind="risk_score", payload={"external_id": "C000001", "probability": 0.8125},
                               idempotency_key="k1", status="sent", external_id="555", attempts=1)  # fmt: skip
        s.add(delivery)
        s.flush()
        delivery_id, score_property = delivery.id, connection.field_mapping["probability"]
    events = [{"eventId": 9001, "subscriptionType": "company.propertyChange", "propertyName": score_property, "propertyValue": "0.8125", "objectId": 555},
              {"eventId": 9002, "subscriptionType": "company.creation", "objectId": 777}]
    body = json.dumps(events).encode()
    url = f"{BASE}/api/v1/crm/webhooks/{connection_id}"
    stamp = str(int(utcnow().timestamp() * 1000))
    good = {"X-HubSpot-Signature-v3": hubspot_signature("app-secret", "POST", url, body, stamp), "X-HubSpot-Request-Timestamp": stamp, "Content-Type": "application/json"}
    with demo.client() as c:
        accepted = c.post(f"{API}/crm/webhooks/{connection_id}", content=body, headers=good)
        assert accepted.status_code == 202 and accepted.json() == {"received": 2, "stored": 2, "duplicates": 0, "deliveries_verified": 1}
        assert c.post(f"{API}/crm/webhooks/{connection_id}", content=body, headers=good).json() == {"received": 2, "stored": 0, "duplicates": 2, "deliveries_verified": 0}
        for headers in ({**good, "X-HubSpot-Signature-v3": hubspot_signature("wrong-secret", "POST", url, body, stamp)}, {"Content-Type": "application/json"},
                        {**good, "X-HubSpot-Request-Timestamp": str(int(stamp) - 10 * 60 * 1000),
                         "X-HubSpot-Signature-v3": hubspot_signature("app-secret", "POST", url, body, str(int(stamp) - 10 * 60 * 1000))}):  # fmt: skip
            refused = c.post(f"{API}/crm/webhooks/{connection_id}", content=body, headers=headers)
            assert refused.status_code == 401 and refused.json()["error"]["code"] == "webhook_signature_invalid"
        assert c.post(f"{API}/crm/webhooks/{connection_id}", content=body + b" ", headers=good).status_code == 401, "a changed body does not match the signature"
        # the generic scheme (for CRMs without signed webhooks of their own, through a small relay)
        generic = json.dumps({"id": "evt-1", "type": "note"}).encode()
        signed = {"X-Signature": "sha256=" + hmac.new(b"w" * 24, generic, hashlib.sha256).hexdigest(), "Content-Type": "application/json"}
        assert c.post(f"{API}/crm/webhooks/{connection_id}", content=generic, headers=signed).json()["stored"] == 1
        listed = c.get(f"{API}/crm/connections/{connection_id}/events", headers=demo.login(c, "viewer")).json()
        assert [(e["event_type"], e["status"]) for e in listed["items"]] == [("note", "ignored"), ("company.creation", "ignored"), ("company.propertyChange", "processed")]
    with read_session() as s:
        delivery = s.get(CRMDelivery, delivery_id)
        assert delivery.verified_at is not None and delivery.verification["matches"] is True and delivery.verification["value_in_crm"] == "0.8125"


# ============================================================================= reverse ETL
@pytest.mark.req("REQ-ACT-04")
def test_a_sync_is_approved_by_a_second_person_and_its_export_matches_what_was_selected(demo):
    author, reviewer = demo.principal("admin"), demo.principal("approver")
    payload = {"name": "High risk to the warehouse", "entity": "risk_scores", "destination": "export", "export_format": "csv", "filters": {"risk_tiers": ["high"]},
               "field_mapping": {"company_id": "customer_external_id", "churn_probability": "probability", "tier": "risk_tier", "reasons": "top_reasons", "scored_for": "as_of_date"}}  # fmt: skip
    with session_scope() as s:
        sync = reverse_etl.create(s, author, payload)
        sync_id = sync.id
        with pytest.raises(Conflict) as early:
            reverse_etl.start_run(s, author, sync_id)
        assert early.value.code == "sync_not_approved"
        reverse_etl.submit(s, author, sync_id)
        with pytest.raises(Forbidden):
            reverse_etl.review(s, author, sync_id, approve=True)
        reverse_etl.review(s, reviewer, sync_id, approve=True, note="columns checked")
        run, _job = reverse_etl.start_run(s, author, sync_id)
        run_id = run.id
    demo.drain()
    batch = latest_batch()
    with read_session() as s:
        expected = s.execute(select(Prediction, Customer.external_id).join(Customer, Customer.id == Prediction.customer_id)
                             .where(Prediction.batch_id == batch.id, Prediction.risk_tier == "high").order_by(Prediction.probability.desc(), Prediction.id)).all()  # fmt: skip
        entry = s.get(ReverseEtlRun, run_id)
        assert (entry.status, entry.rows, entry.counts, entry.batch_id) == ("completed", len(expected), {"written": len(expected)}, batch.id) and len(expected) > 5
        assert entry.verification["matches"] is True and entry.verification["columns"] == ["company_id", "churn_probability", "tier", "reasons", "scored_for"]
    with demo.client() as c:
        analyst, viewer, admin = demo.login(c, "analyst"), demo.login(c, "viewer"), demo.login(c, "admin")
        assert c.get(f"{API}/crm/reverse-etl/runs/{run_id}/download", headers=viewer).status_code == 403
        file = c.get(f"{API}/crm/reverse-etl/runs/{run_id}/download", headers=analyst)
        assert file.status_code == 200 and file.headers["content-type"].startswith("text/csv") and hashlib.sha256(file.content).hexdigest() == entry.export_sha256
        lines = file.text.strip().splitlines()
        assert lines[0] == "company_id,churn_probability,tier,reasons,scored_for" and len(lines) == len(expected) + 1
        first = lines[1].split(",")
        assert first[0] == expected[0][1] and float(first[1]) == round(expected[0][0].probability, 6) and first[2] == "high"
        overview = c.get(f"{API}/crm/reverse-etl", headers=viewer).json()
        assert overview["runs"][0]["has_file"] is True and "export_path" not in overview["runs"][0] and overview["syncs"][0]["status"] == "approved"
        verified = c.post(f"{API}/crm/reverse-etl/runs/{run_id}/verify", headers=admin, json={}).json()
        assert verified["verification"]["unchanged"] is True and verified["verification"]["file_present"] is True
        # somebody edits the file afterwards: verification says so and the download is refused
        from churn_platform import storage

        with read_session() as s:
            path = storage.resolve(s.get(ReverseEtlRun, run_id).export_path)
        manifest = json.loads(path.with_suffix(".csv.manifest.json").read_text())
        assert manifest["rows"] == len(expected) and manifest["sha256"] == entry.export_sha256
        path.write_text(path.read_text() + "C999,1.0,high,,2026-10-31\n")
        assert c.post(f"{API}/crm/reverse-etl/runs/{run_id}/verify", headers=admin, json={}).json()["verification"]["unchanged"] is False
        assert c.get(f"{API}/crm/reverse-etl/runs/{run_id}/download", headers=analyst).status_code == 409
        switched = c.post(f"{API}/crm/reverse-etl/syncs/{sync_id}/enabled", headers=demo.login(c, "approver"), json={"enabled": False}).json()
        assert switched["status"] == "disabled" and c.post(f"{API}/crm/reverse-etl/syncs/{sync_id}/runs", headers=admin, json={}).status_code == 409
    for bad, field in (({**payload, "name": "x", "field_mapping": {"p": "probability"}}, "field_mapping"), ({**payload, "name": "x", "field_mapping": {"a": "ssn"}}, "field_mapping"),
                       ({**payload, "name": "x", "entity": "invoices"}, "entity"), ({**payload, "name": "x", "export_format": "xml"}, "export_format"),
                       ({**payload, "name": "x", "filters": {"country": "DE"}}, "filters")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed) as invalid:
            reverse_etl.create(s, author, bad)
        assert invalid.value.details["field"] == field


@pytest.mark.req("REQ-ACT-04")
def test_a_sync_to_a_crm_goes_through_the_connection_and_a_test_only_connection_sends_nothing(demo):
    author, reviewer = demo.principal("admin"), demo.principal("approver")
    with read_session() as s:
        connection = s.execute(select(CRMConnection).where(CRMConnection.mode == "TEST_ONLY")).scalar_one()
    vendor = Vendor()
    crm.set_transport(vendor.transport())
    with session_scope() as s:
        sync = reverse_etl.create(s, author, {"name": "Medium risk to HubSpot", "destination": "crm", "connection_id": connection.id, "filters": {"risk_tiers": ["medium"]}})
        reverse_etl.submit(s, author, sync.id)
        reverse_etl.review(s, reviewer, sync.id, approve=True)
        run, _job = reverse_etl.start_run(s, author, sync.id)
        run_id, sync_id = run.id, sync.id
        assert run.mode == "TEST_ONLY"
    demo.drain()
    with session_scope() as s:
        verified = reverse_etl.verify(s, author, run_id)
        rows = verified.rows
        assert rows > 10 and verified.counts == {"queued": rows, "already_queued": 0}
        assert verified.verification["by_status"] == {"skipped": rows} and verified.verification["transmitted"] == 0 and verified.verification["complete"] is True
        assert "nothing was transmitted" in verified.verification["note"]
        assert s.execute(select(func.count()).select_from(CRMDelivery).where(CRMDelivery.sync_run_id == run_id)).scalar_one() == rows
    assert vendor.requests == [], "TEST_ONLY: requests are built and none is sent"
    # running the same sync again for the same scores queues nothing twice
    with session_scope() as s:
        again, _job = reverse_etl.start_run(s, author, sync_id)
        again_id = again.id
    demo.drain()
    with read_session() as s:
        assert s.get(ReverseEtlRun, again_id).counts == {"queued": 0, "already_queued": rows}
    with session_scope() as s, pytest.raises(ValidationFailed):
        reverse_etl.create(s, author, {"name": "recs to crm", "entity": "recommendations", "destination": "crm", "connection_id": connection.id})


# ============================================================================= notifications
def approved_template(demo, code: str, channel: str, body: str, *, subject: str | None = None, category: str = "marketing") -> None:
    with session_scope() as s:
        template = notify.create_template(s, demo.principal("admin"), code=code, channel=channel, subject=subject, body=body, category=category)
        notify.submit_template(s, demo.principal("admin"), template.id)
        notify.review_template(s, demo.principal("approver"), template.id, approve=True)


def customers_with(demo, *, consent: bool, n: int = 5) -> list[Customer]:
    with read_session() as s:
        return list(s.execute(select(Customer).where(Customer.tenant_id == demo.tenant_id, Customer.consent_marketing.is_(consent), Customer.phone.is_not(None),
                                                     Customer.email.like("%@%")).order_by(Customer.id).limit(n)).scalars())  # fmt: skip


def provider(demo, channel: str, vendor_name: str, config: dict, credentials: dict | None = None, mode: str = "DRY_RUN") -> int:
    with session_scope() as s:
        entry = notify.create_provider(s, demo.principal("admin"), name=f"{vendor_name} {channel}", channel=channel, provider=vendor_name, config=config,
                                       credentials=credentials, webhook_secret="n" * 24)  # fmt: skip
        if mode != "DRY_RUN":
            notify.set_mode(s, demo.principal("approver"), entry.id, mode)
        return entry.id


def send(demo, customer_id: int, channel: str, code: str, key: str, **kw) -> NotificationMessage:
    with session_scope() as s:
        message = notify.send(s, tenant_id=demo.tenant_id, customer_id=customer_id, channel=channel, template_code=code, idempotency_key=key, **kw)
        s.expunge(message)
        return message


@pytest.mark.req("REQ-ACT-05")
def test_a_dry_run_message_is_built_checked_stored_and_never_counted_as_sent(demo):
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL=BASE)
    vendor = Vendor()
    notify.set_transport(vendor.transport())
    provider_id = provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example", "from_name": "Retention"}, {"api_key": "SG.secret"})
    approved_template(demo, "offer", "email", "Hello {{customer_name}}, use {{offer_code}} for {{offer_percent}}% off.\nStop: {{unsubscribe_url}}", subject="{{offer_percent}}% off for {{customer_name}}")
    customer = customers_with(demo, consent=True, n=1)[0]
    message = send(demo, customer.id, "email", "offer", "k-1", variables={"offer_code": "STAY15", "offer_percent": 15})
    assert (message.status, message.is_dry_run, message.attempts) == ("dry_run", True, 0) and "nothing was sent" in message.status_reason
    assert message.subject == f"15% off for {customer.name}" and "STAY15" in message.body and f"{BASE}/api/v1/notifications/unsubscribe?t=" in message.body
    assert message.recipient_hint == f"{customer.email[0]}***@{customer.email.split('@')[1]}" and customer.email not in message.recipient_enc
    assert SecretBox().decrypt(message.recipient_enc) == customer.email
    assert message.request["url"] == "https://api.sendgrid.com/v3/mail/send" and message.request["auth"] == "bearer" and "SG.secret" not in json.dumps(message.request)
    assert vendor.requests == [], "DRY_RUN never touches the network"
    assert send(demo, customer.id, "email", "offer", "k-1", variables={"offer_code": "X", "offer_percent": 1}).id == message.id, "the same key is the same message"
    # the database itself refuses a dry-run message in a sent state
    with pytest.raises(IntegrityError), session_scope() as s:
        s.execute(update(NotificationMessage).where(NotificationMessage.id == message.id).values(status="sent"))
    with session_scope() as s:
        overview = notify.overview(s, demo.tenant_id)
        assert overview["dry_run"] == 1 and overview["really_sent"] == 0 and overview["by_channel"] == {"email": {"dry_run": 1}}
        assert overview["providers"][0]["mode"] == "DRY_RUN" and overview["providers"][0]["has_credentials"] is True and "credentials_enc" not in overview["providers"][0]
        # leaving dry run is deliberate: LIVE needs the installation's permission
        with pytest.raises(Forbidden) as live:
            notify.set_mode(s, demo.principal("approver"), provider_id, "LIVE")
        assert live.value.code == "live_not_allowed"
    with demo.client() as c:
        page = c.get(f"{API}/notifications", headers=demo.login(c, "viewer")).json()
        assert page["live_allowed_by_configuration"] is False and page["templates"][0]["status"] == "approved"
        listed = c.get(f"{API}/notifications/messages", headers=demo.login(c, "viewer"), params={"status": "dry_run"}).json()
        assert listed["total"] == 1 and "recipient_enc" not in listed["items"][0] and "recipient_hash" not in listed["items"][0]
        assert c.post(f"{API}/notifications/providers/{provider_id}/mode", headers=demo.login(c, "data_scientist"), json={"mode": "SANDBOX"}).status_code == 403


@pytest.mark.req("REQ-ACT-05")
def test_consent_preferences_suppression_caps_and_missing_addresses_hold_a_message_back(demo):
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL=BASE, CHURN_NOTIFY_MAX_PER_CUSTOMER_PER_DAY="2")
    provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example"})
    provider(demo, "sms", "twilio", {"account_sid": "AC123", "from_number": "+15005550006"})
    approved_template(demo, "offer", "email", "Hi {{customer_name}}. Stop: {{unsubscribe_url}}", subject="An offer")
    approved_template(demo, "notice", "email", "Your invoice is ready, {{customer_name}}.", subject="Invoice", category="transactional")
    approved_template(demo, "card", "sms", "Card of {{customer_name}} expires on {{card_expiry_date}}.", category="transactional")
    willing, unwilling = customers_with(demo, consent=True, n=3), customers_with(demo, consent=False, n=1)[0]
    no_consent = send(demo, unwilling.id, "email", "offer", "c-1")
    assert (no_consent.status, no_consent.status_reason) == ("blocked", "no marketing consent on record")
    assert send(demo, unwilling.id, "email", "notice", "c-2").status == "dry_run", "a transactional message does not need marketing consent"
    # frequency cap: two marketing messages a day, the third is held back; transactional messages are not capped
    first, second, third = (send(demo, willing[0].id, "email", "offer", f"cap-{n}") for n in range(3))
    assert (first.status, second.status, third.status) == ("dry_run", "dry_run", "blocked") and "frequency cap" in third.status_reason
    assert send(demo, willing[0].id, "email", "notice", "cap-t").status == "dry_run"
    # the customer's own preference
    with session_scope() as s:
        notify.set_preference(s, demo.tenant_id, willing[1].id, "email", "marketing", False, source="support call")
    opted_out = send(demo, willing[1].id, "email", "offer", "p-1")
    assert opted_out.status == "blocked" and "opted out" in opted_out.status_reason
    # suppression list
    with session_scope() as s:
        notify.suppress(s, demo.tenant_id, "email", willing[2].email.upper(), reason="bounce", source="test", customer_id=willing[2].id)
    suppressed = send(demo, willing[2].id, "email", "offer", "s-1")
    assert suppressed.status == "suppressed" and "bounce" in suppressed.status_reason
    # no usable address
    with session_scope() as s:
        s.execute(update(Customer).where(Customer.id == willing[2].id).values(phone=None))
        s.execute(update(Customer).where(Customer.id == willing[1].id).values(phone="0171 555 0100"))
    assert send(demo, willing[2].id, "sms", "card", "a-1", variables={"card_expiry_date": "2026-12-31"}).status_reason == "no phone number on record"
    assert "international format" in send(demo, willing[1].id, "sms", "card", "a-2", variables={"card_expiry_date": "2026-12-31"}).status_reason
    # a template variable without a value, an unapproved template, no provider for the channel
    assert "needs a value for: card_expiry_date" in send(demo, willing[0].id, "sms", "card", "v-1").status_reason
    with pytest.raises(Conflict) as unapproved, session_scope() as s:
        notify.send(s, tenant_id=demo.tenant_id, customer_id=willing[0].id, channel="push", template_code="offer", idempotency_key="x")
    assert unapproved.value.code == "template_not_approved"
    approved_template(demo, "ping", "push", "Hello {{customer_name}}", subject="Hi", category="transactional")
    assert send(demo, willing[0].id, "push", "ping", "n-1").status_reason.startswith("no device token")
    assert send(demo, willing[0].id, "push", "ping", "n-2", recipient="device-token-abc").status_reason == "no push provider is configured"
    with read_session() as s:
        reasons = {r["reason"] for r in notify.overview(s, demo.tenant_id)["not_sent_reasons"]}
        assert {"no marketing consent on record", "no phone number on record", "no push provider is configured"} <= reasons
        assert s.execute(select(func.count()).select_from(NotificationMessage).where(NotificationMessage.status.in_(("sent", "delivered")))).scalar_one() == 0


@pytest.mark.req("REQ-ACT-05")
def test_template_rules_and_approval(demo):
    author, reviewer = demo.principal("admin"), demo.principal("approver")
    cases = [({"code": "Bad Code", "channel": "email", "subject": "s", "body": "b {{unsubscribe_url}}"}, "code"), ({"code": "ok", "channel": "fax", "subject": "s", "body": "b"}, "channel"),
             ({"code": "ok", "channel": "email", "subject": None, "body": "b {{unsubscribe_url}}"}, "subject"), ({"code": "ok", "channel": "email", "subject": "s", "body": "no link"}, "body"),
             ({"code": "ok", "channel": "email", "subject": "s", "body": "{{password}} {{unsubscribe_url}}"}, "body"), ({"code": "ok", "channel": "sms", "subject": None, "body": "x" * 481}, "body"),
             ({"code": "ok", "channel": "sms", "subject": None, "body": "b", "category": "spam"}, "category")]  # fmt: skip
    for values, field in cases:
        with session_scope() as s, pytest.raises(ValidationFailed) as invalid:
            notify.create_template(s, author, **values)
        assert invalid.value.details["field"] == field, values
    with session_scope() as s:
        v1 = notify.create_template(s, author, code="welcome", channel="email", subject="Hi {{customer_name}}", body="Welcome. {{unsubscribe_url}}")
        assert (v1.version, v1.status, v1.variables) == (1, "draft", ["customer_name", "unsubscribe_url"]) and notify.approved_template(s, demo.tenant_id, "welcome", "email") is None
        notify.submit_template(s, author, v1.id)
        with pytest.raises(Forbidden):
            notify.review_template(s, author, v1.id, approve=True)
        notify.review_template(s, reviewer, v1.id, approve=True)
        v2 = notify.create_template(s, author, code="welcome", channel="email", subject="Hello {{customer_name}}", body="Welcome back. {{unsubscribe_url}}")
        notify.submit_template(s, author, v2.id)
        assert notify.approved_template(s, demo.tenant_id, "welcome", "email").id == v1.id, "the approved version stays in force while the next one is reviewed"
        notify.review_template(s, reviewer, v2.id, approve=True)
        assert notify.approved_template(s, demo.tenant_id, "welcome", "email").id == v2.id and s.get(type(v1), v1.id).status == "retired"
        assert notify.render(v2, {"customer_name": "Acme", "unsubscribe_url": "https://u"}) == ("Hello Acme", "Welcome back. https://u")
        with pytest.raises(ValidationFailed):
            notify.render(v2, {"customer_name": "Acme"})


def set_mode_allowed(demo, **env) -> None:
    activate(demo.db_path, demo.data_dir, CHURN_PUBLIC_BASE_URL=BASE, **env)


@pytest.mark.req("REQ-ACT-05")
def test_sandbox_requests_have_the_shape_each_vendor_expects(demo):
    set_mode_allowed(demo)
    vendor = Vendor()
    notify.set_transport(vendor.transport())
    provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example", "from_name": "Retention"}, {"api_key": "SG.key"}, mode="SANDBOX")
    provider(demo, "sms", "twilio", {"account_sid": "AC123", "from_number": "+15005550006"}, {"auth_token": "tw-token"}, mode="SANDBOX")
    provider(demo, "push", "fcm", {"project_id": "proj-1"}, {"access_token": "ya29.token"}, mode="SANDBOX")
    approved_template(demo, "notice", "email", "Invoice for {{customer_name}}", subject="Invoice", category="transactional")
    approved_template(demo, "card", "sms", "Card of {{customer_name}} expires.", category="transactional")
    approved_template(demo, "ping", "push", "Hello {{customer_name}}", subject="Hi", category="transactional")
    customer = customers_with(demo, consent=True, n=1)[0]
    vendor.queue = [httpx.Response(202, headers={"X-Message-Id": "sg-777"}), httpx.Response(201, json={"sid": "SM123"}), httpx.Response(200, json={"name": "projects/proj-1/messages/1"})]
    ids = [send(demo, customer.id, channel, code, f"sb-{channel}", **extra).id for channel, code, extra in
           (("email", "notice", {}), ("sms", "card", {}), ("push", "ping", {"recipient": "device-token-abc"}))]  # fmt: skip
    demo.drain()
    mail, sms, push = vendor.requests
    body = json.loads(mail.content)
    assert str(mail.url) == "https://api.sendgrid.com/v3/mail/send" and mail.headers["authorization"] == "Bearer SG.key"
    assert body["personalizations"] == [{"to": [{"email": customer.email}], "custom_args": {"message_ref": "sb-email"}}] and body["from"] == {"email": "retention@corp.example", "name": "Retention"}
    assert body["subject"] == "Invoice" and body["content"] == [{"type": "text/plain", "value": f"Invoice for {customer.name}"}] and body["mail_settings"] == {"sandbox_mode": {"enable": True}}
    assert str(sms.url) == "https://api.twilio.com/2010-04-01/Accounts/AC123/Messages.json" and sms.headers["content-type"] == "application/x-www-form-urlencoded"
    assert sms.headers["authorization"] == "Basic " + base64.b64encode(b"AC123:tw-token").decode()
    assert {k: v[0] for k, v in parse_qs(sms.content.decode()).items()} == {"To": customer.phone, "From": "+15005550006", "Body": f"Card of {customer.name} expires."}
    fcm = json.loads(push.content)
    assert str(push.url) == "https://fcm.googleapis.com/v1/projects/proj-1/messages:send" and push.headers["authorization"] == "Bearer ya29.token"
    assert fcm == {"message": {"token": "device-token-abc", "notification": {"title": "Hi", "body": f"Hello {customer.name}"}, "data": {"message_ref": "sb-push"}}, "validate_only": True}
    with read_session() as s:
        messages = [s.get(NotificationMessage, i) for i in ids]
        assert [(m.status, m.is_dry_run, m.provider_message_id) for m in messages] == [("sent", False, "sg-777"), ("sent", False, "SM123"), ("sent", False, "projects/proj-1/messages/1")]
        assert all("validation mode" in m.status_reason for m in messages), "sandbox: accepted by the vendor, delivered to nobody - and labelled so"
        assert all("SG.key" not in json.dumps(m.request) and customer.email not in json.dumps(m.request) for m in messages)
    # Amazon SES is signed with AWS Signature Version 4 and, in sandbox, addressed to the mailbox simulator
    with session_scope() as s:
        ses = notify.create_provider(s, demo.principal("admin"), name="ses", channel="email", provider="ses", config={"from_email": "r@corp.example", "region": "eu-west-1"},
                                     credentials={"access_key_id": "AKIAEXAMPLE", "secret_access_key": "secret"}, is_default=False)  # fmt: skip
        request = notify.build_request(ses, {"access_key_id": "AKIAEXAMPLE", "secret_access_key": "secret"}, recipient="a@b.example", subject="S", body="B", message_ref="m1", validate_only=True)
    assert request["url"] == "https://email.eu-west-1.amazonaws.com/v2/email/outbound-emails" and request["json"]["Destination"] == {"ToAddresses": ["success@simulator.amazonses.com"]}
    from datetime import UTC, datetime

    when = datetime(2026, 11, 11, 12, 0, 0, tzinfo=UTC)
    signed = notify.sigv4_headers("POST", request["url"], b"{}", now=when, **request["sigv4"])
    assert signed["X-Amz-Date"] == "20261111T120000Z" and signed["X-Amz-Content-Sha256"] == hashlib.sha256(b"{}").hexdigest()
    assert signed["Authorization"].startswith("AWS4-HMAC-SHA256 Credential=AKIAEXAMPLE/20261111/eu-west-1/ses/aws4_request, SignedHeaders=content-type;host;x-amz-content-sha256;x-amz-date, Signature=")
    assert len(signed["Authorization"].rsplit("=", 1)[1]) == 64
    assert signed == notify.sigv4_headers("POST", request["url"], b"{}", now=when, **request["sigv4"]), "deterministic"
    assert signed["Authorization"] != notify.sigv4_headers("POST", request["url"], b"{ }", now=when, **request["sigv4"])["Authorization"], "the body is part of the signature"
    # Apple's push service needs HTTP/2, which this build does not have: it can be rehearsed, not used
    with session_scope() as s:
        apns = notify.create_provider(s, demo.principal("admin"), name="apns", channel="push", provider="apns", config={"bundle_id": "com.corp.app", "team_id": "T", "key_id": "K"},
                                      credentials={"key": "x"}, is_default=False)  # fmt: skip
        with pytest.raises(Conflict) as unsupported:
            notify.set_mode(s, demo.principal("approver"), apns.id, "SANDBOX")
        assert unsupported.value.code == "not_supported"
        assert notify.build_request(apns, {}, recipient="tok", subject="S", body="B", message_ref="m", validate_only=True)["url"] == "https://api.sandbox.push.apple.com/3/device/tok"


@pytest.mark.req("REQ-ACT-05")
def test_delivery_retries_temporary_failures_stops_on_refusals_and_live_needs_permission(demo):
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true")
    vendor = Vendor()
    notify.set_transport(vendor.transport())
    provider_id = provider(demo, "sms", "twilio", {"account_sid": "AC123", "from_number": "+15005550006"}, {"auth_token": "tw"}, mode="LIVE")
    approved_template(demo, "card", "sms", "Card of {{customer_name}} expires.", category="transactional")
    customers = customers_with(demo, consent=True, n=3)
    # 503, then accepted
    vendor.queue = [httpx.Response(503, text="try later"), httpx.Response(201, json={"sid": "SM1"})]
    first = send(demo, customers[0].id, "sms", "card", "r-1")
    assert first.status == "queued" and first.is_dry_run is False
    assert notify.deliver(first.id) == {"status": "queued", "attempts": 1, "http_status": 503}
    with read_session() as s:
        waiting = s.get(NotificationMessage, first.id)
        assert waiting.next_attempt_at > utcnow() and waiting.response["retryable"] is True
    assert notify.deliver(first.id) == {"status": "sent", "attempts": 2, "http_status": 201}
    assert notify.deliver(first.id)["skipped"] == "already handled", "a message that was sent is never sent again"
    # refused by the vendor: final
    vendor.queue = [httpx.Response(400, json={"code": 21211, "message": "Invalid 'To' Phone Number"})]
    second = send(demo, customers[1].id, "sms", "card", "r-2")
    assert notify.deliver(second.id)["status"] == "failed"
    with read_session() as s:
        failed = s.get(NotificationMessage, second.id)
        assert "21211" in failed.status_reason and failed.attempts == 1
        live = s.get(NotificationMessage, first.id)
        assert (live.status, live.status_reason, live.provider_message_id) == ("sent", None, "SM1")
        assert notify.overview(s, demo.tenant_id)["really_sent"] == 1
    # the installation's permission is withdrawn: a LIVE provider's messages are held back, and the mode cannot be chosen
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="false")
    held = send(demo, customers[2].id, "sms", "card", "r-3")
    assert held.status == "blocked" and "CHURN_NOTIFY_ALLOW_LIVE" in held.status_reason and len(vendor.requests) == 3
    with session_scope() as s, pytest.raises(Forbidden):
        notify.set_mode(s, demo.principal("approver"), provider_id, "LIVE")
    with session_scope() as s, pytest.raises(Conflict) as no_credentials:
        bare = notify.create_provider(s, demo.principal("admin"), name="bare", channel="email", provider="sendgrid", config={"from_email": "a@b.example"}, is_default=False)
        notify.set_mode(s, demo.principal("approver"), bare.id, "SANDBOX")
    assert no_credentials.value.code == "credentials_missing"


@pytest.mark.req("REQ-ACT-05")
def test_vendor_events_update_messages_and_feed_the_suppression_list_and_unsubscribe_links_work(demo):
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true")
    vendor = Vendor()
    notify.set_transport(vendor.transport())
    provider_id = provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example"}, {"api_key": "k"}, mode="LIVE")
    approved_template(demo, "offer", "email", "Hi {{customer_name}}. Stop: {{unsubscribe_url}}", subject="Offer")
    a, b, c3 = customers_with(demo, consent=True, n=3)
    vendor.queue = [httpx.Response(202, headers={"X-Message-Id": f"sg-{n}"}) for n in range(3)]
    messages = [send(demo, customer.id, "email", "offer", f"e-{customer.id}") for customer in (a, b, c3)]
    demo.drain()
    events = [{"id": "ev-1", "type": "delivered", "message_ref": f"e-{a.id}"}, {"id": "ev-2", "type": "bounce", "provider_message_id": "sg-1", "recipient": b.email},
              {"id": "ev-3", "type": "spamreport", "message_ref": f"e-{c3.id}"}, {"id": "ev-4", "type": "delivered", "message_ref": "unknown"}, {"type": "delivered"}]
    body = json.dumps(events).encode()
    signature = "sha256=" + hmac.new(b"n" * 24, body, hashlib.sha256).hexdigest()
    with demo.client() as c:
        assert c.post(f"{API}/notifications/webhooks/{provider_id}", content=body, headers={"X-Signature": "sha256=" + "0" * 64}).status_code == 401
        assert c.post(f"{API}/notifications/webhooks/{provider_id}", content=body).status_code == 401
        assert c.post(f"{API}/notifications/webhooks/987654", content=body, headers={"X-Signature": signature}).status_code == 401
        applied = c.post(f"{API}/notifications/webhooks/{provider_id}", content=body, headers={"X-Signature": signature})
        assert applied.status_code == 202 and applied.json() == {"received": 5, "applied": 3, "duplicates": 0, "unmatched": 2}
        assert c.post(f"{API}/notifications/webhooks/{provider_id}", content=body, headers={"X-Signature": signature}).json()["duplicates"] == 4
        with read_session() as s:
            states = [s.get(NotificationMessage, m.id).status for m in messages]
            assert states == ["delivered", "bounced", "complained"] and s.get(NotificationMessage, messages[0].id).delivered_at is not None
            suppressions = {x.customer_id: x.reason for x in s.execute(select(NotificationSuppression)).scalars()}
            assert suppressions == {b.id: "bounce", c3.id: "complaint"}
        # nobody on the suppression list is written to again
        assert send(demo, b.id, "email", "offer", "again-b").status == "suppressed" and send(demo, c3.id, "email", "offer", "again-c").status in ("blocked", "suppressed")
        # the unsubscribe link in the message works without a sign-in, exactly once is enough, and a forged link does nothing
        with read_session() as s:
            link = next(word for word in s.get(NotificationMessage, messages[0].id).body.split() if word.startswith(BASE))
        path = link[len(BASE):]
        page = c.get(path)
        assert page.status_code == 200 and "unsubscribed" in page.text.lower()
        assert c.get(path[:-3] + "abc").status_code == 401 and c.get(f"{API}/notifications/unsubscribe", params={"t": "1.2.email.x"}).status_code == 401
        after = send(demo, a.id, "email", "offer", "again-a")
        assert after.status == "blocked" and "opted out" in after.status_reason
        approver = demo.login(c, "approver")
        listed = c.get(f"{API}/notifications", headers=approver).json()["suppression_list"]
        by_reason = {x["reason"]: x for x in listed}
        assert set(by_reason) == {"bounce", "complaint", "unsubscribe"} and all("recipient_hash" not in x and "***@" in x["recipient_hint"] for x in listed)
        assert c.post(f"{API}/notifications/suppressions/{by_reason['complaint']['id']}/lift", headers=approver, json={"note": "asked nicely"}).status_code == 403
        lifted = c.post(f"{API}/notifications/suppressions/{by_reason['bounce']['id']}/lift", headers=approver, json={"note": "mailbox fixed"})
        assert lifted.status_code == 200 and lifted.json()["lifted_at"] is not None
    assert "notify.unsubscribed" in audit_actions("notify.") and "notify.suppression_lifted" in audit_actions("notify.")


@pytest.mark.req("REQ-ACT-05")
def test_in_app_messages_wait_for_the_product_and_are_delivered_when_it_reports_them_read(demo):
    set_mode_allowed(demo)
    with session_scope() as s:
        inbox = notify.create_provider(s, demo.principal("admin"), name="inbox", channel="in_app", provider="inbox")
        assert inbox.mode == "DRY_RUN"
        inbox_id = inbox.id
    approved_template(demo, "card", "in_app", "The card on file expires on {{card_expiry_date}}.", subject="Card expiring", category="transactional")
    customer = customers_with(demo, consent=True, n=1)[0]
    rehearsal = send(demo, customer.id, "in_app", "card", "i-1", variables={"card_expiry_date": "2026-12-31"})
    assert rehearsal.status == "dry_run"
    with session_scope() as s:
        notify.set_mode(s, demo.principal("approver"), inbox_id, "SANDBOX")
        with pytest.raises(Conflict):
            notify.mark_read(s, demo.tenant_id, rehearsal.id)
    real = send(demo, customer.id, "in_app", "card", "i-2", variables={"card_expiry_date": "2026-12-31"})
    assert (real.status, real.is_dry_run, real.recipient_hint) == ("sent", False, f"{customer.external_id[:4]}***")
    with demo.client() as c:
        read = c.post(f"{API}/notifications/messages/{real.id}/read", headers=demo.login(c, "admin"), json={})
        assert read.status_code == 200 and read.json()["status"] == "delivered" and read.json()["read_at"] is not None


# ============================================================================= campaigns
def run_due_jobs(demo) -> None:
    """Run what is due now.  A running campaign leaves one job queued for its next step, which is not a failure."""
    demo.drain(expect_success=False)
    with read_session() as s:
        from churn_platform.models import Job

        bad = s.execute(select(Job.id, Job.job_type, Job.status, Job.error).where(Job.status.in_(("failed", "dead")))).all()
        waiting = s.execute(select(Job.job_type).where(Job.status == "queued")).scalars().all()
    assert not bad, bad
    assert set(waiting) <= {"campaign.tick"}, waiting


def approve_all_templates(demo) -> None:
    from churn_platform.models import NotificationTemplate

    with session_scope() as s:
        for template in s.execute(select(NotificationTemplate).where(NotificationTemplate.status == "draft")).scalars().all():
            notify.submit_template(s, demo.principal("admin"), template.id)
            notify.review_template(s, demo.principal("approver"), template.id, approve=True)


def approved_campaign(demo, preset: str) -> int:
    with session_scope() as s:
        campaign = campaigns.create_preset(s, demo.principal("admin"), preset)
        campaign_id = campaign.id
    approve_all_templates(demo)
    with session_scope() as s:
        campaigns.submit(s, demo.principal("admin"), campaign_id)
        campaigns.review(s, demo.principal("approver"), campaign_id, approve=True)
    return campaign_id


def recommendations(batch_id: int, **where) -> list[RetentionRecommendation]:
    with read_session() as s:
        stmt = select(RetentionRecommendation).where(RetentionRecommendation.batch_id == batch_id, *(getattr(RetentionRecommendation, k) == v for k, v in where.items()))
        return list(s.execute(stmt.order_by(RetentionRecommendation.id)).scalars())


@pytest.mark.req("REQ-ACT-05")
def test_the_automated_tier_drip_runs_as_a_dry_run_with_a_control_group_and_sends_its_steps_on_schedule(demo):
    """Brief 9.2: the customers the playbook put in the automated tier (medium risk, lower value) get the e-mail sequence."""
    set_mode_allowed(demo, CHURN_NOTIFY_MAX_PER_CUSTOMER_PER_DAY="5", CHURN_NOTIFY_MAX_PER_CUSTOMER_PER_WEEK="9")
    provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example"})
    author, reviewer = demo.principal("admin"), demo.principal("approver")
    with session_scope() as s:
        campaign = campaigns.create_preset(s, author, "automated_tier_drip")
        campaign_id = campaign.id
        view = campaigns.campaign_view(s, campaign)
        assert (view["status"], view["run_state"], view["dry_run"], view["offer"]) == ("draft", "idle", True, None)
        assert (view["segment"], view["action_code"], view["eligibility"]) == ("medium_risk_low_value", "reengagement_drip",
                                                                              {"segments": ["medium_risk_low_value"], "action_codes": ["reengagement_drip"]})  # fmt: skip
        assert [(x["delay_hours"], x["channel"], x["template_code"]) for x in view["steps"]] == [
            (0.0, "email", "reengage_content"), (72.0, "email", "reengage_webinar"), (168.0, "email", "reengage_check_in")]
        with pytest.raises(Conflict) as templates:
            campaigns.submit(s, author, campaign_id)
        assert templates.value.code == "template_not_approved" and len(templates.value.details) == 3
    approve_all_templates(demo)
    with session_scope() as s:
        campaigns.submit(s, author, campaign_id)
        with pytest.raises(Forbidden):
            campaigns.review(s, author, campaign_id, approve=True)
        with pytest.raises(Conflict):
            campaigns.start(s, reviewer, campaign_id)
        campaigns.review(s, reviewer, campaign_id, approve=True)
        preview = campaigns.preview(s, reviewer, campaign_id)
        started = campaigns.start(s, reviewer, campaign_id)
    batch = latest_batch()
    drip = recommendations(batch.id, action_code="reengagement_drip")
    cleared = {r.customer_id for r in drip if r.status == "proposed"}
    assert len(cleared) == 42 and {r.segment for r in drip} == {"medium_risk_low_value"} and not any(r.rationale["requires_human_review"] for r in drip)
    # everybody the playbook cleared, nobody it blocked (no consent, recently contacted): the campaign does not decide that again
    assert preview["matched"] == preview["eligible"] == started["enrolled"] == 42 and preview["excluded"] == {"already_enrolled": 0, "in_cooldown": 0, "no_marketing_consent": 0}
    assert preview["recommendations"] == {"batch_id": batch.id, "as_of_date": batch.as_of_date.isoformat(), "cleared": 42,
                                          "left_out": {"blocked_by_playbook": 3, "waiting_for_review": 0, "dismissed": 0, "already_carried_out": 0}}  # fmt: skip
    assert started["groups"] == preview["groups"] and set(started["groups"]) == {"A", "control"} and started["groups"]["A"] > started["groups"]["control"] > 0
    run_due_jobs(demo)
    with read_session() as s:
        enrollments = s.execute(select(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign_id)).scalars().all()
        messages = s.execute(select(NotificationMessage).where(NotificationMessage.campaign_id == campaign_id)).scalars().all()
        active = [e for e in enrollments if e.status == "active"]
        assert {e.customer_id for e in enrollments} == cleared and len(active) == started["groups"]["A"]
        assert all(e.source["action_code"] == "reengagement_drip" and e.source["recommendation_id"] for e in enrollments)
        assert all(e.status == "control" and e.next_step_at is None for e in enrollments if e.variant == "control")
        assert len(messages) == len(active) and {m.status for m in messages} == {"dry_run"} and {m.step_index for m in messages} == {0}
        assert all("/notifications/unsubscribe?t=" in m.body and "STAY15" not in m.body for m in messages), "content, not the offer"
        assert all(e.current_step == 1 and e.next_step_at > utcnow() + timedelta(hours=71) for e in active), "the second e-mail is due in three days"
        assert not {m.customer_id for m in messages} & {e.customer_id for e in enrollments if e.variant == "control"}, "the control group receives nothing"
        assert s.get(Campaign, campaign_id).run_state == "running"
    # three days later, then a week later: the remaining steps go out and the campaign completes
    for expected_step in (1, 2):
        with session_scope() as s:
            s.execute(update(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign_id, CampaignEnrollment.status == "active").values(next_step_at=utcnow() - timedelta(minutes=1)))
        outcome = campaigns.tick(campaign_id)
        assert outcome["steps_processed"] == len(active), expected_step
    with read_session() as s:
        campaign = s.get(Campaign, campaign_id)
        counts = dict(s.execute(select(NotificationMessage.step_index, func.count()).where(NotificationMessage.campaign_id == campaign_id).group_by(NotificationMessage.step_index)).all())
        assert (campaign.run_state, campaign.status) == ("completed", "completed") and counts == {0: len(active), 1: len(active), 2: len(active)}
        assert s.execute(select(func.count()).select_from(NotificationMessage).where(NotificationMessage.status.in_(("sent", "delivered")))).scalar_one() == 0
        results = campaigns.results(s, reviewer, campaign_id)
        assert results["effect"].startswith("not measurable: this campaign ran as a dry run") and results["groups"]["A"]["by_status"] == {"completed": len(active)}
        assert results["groups"]["A"]["messages"] == {"dry_run": 3 * len(active)}
        # a dry run is a rehearsal: no action is on record and every recommendation is still open
        assert s.execute(select(func.count()).select_from(Intervention)).scalar_one() == 0
    assert {(r.status, r.campaign_id) for r in recommendations(batch.id, action_code="reengagement_drip") if r.customer_id in cleared} == {("proposed", None)}
    assert campaigns.tick(campaign_id)["skipped"] == "the campaign is not running"
    # a second campaign for the same segment respects the cool-down: nobody who just went through one is enrolled again
    second = approved_campaign(demo, "automated_tier_drip")
    with session_scope() as s:
        again = campaigns.preview(s, reviewer, second)
        assert again["eligible"] == 0 and again["excluded"]["in_cooldown"] == started["enrolled"], "the control group is held back as well"


@pytest.mark.req("REQ-ACT-05", "REQ-ACT-01")
def test_the_offer_goes_only_to_reviewed_recommendations_and_a_sent_message_closes_the_recommendation(demo):
    """Brief 9.2, the 15 % offer.  The playbook wants a person to review every discount; the campaign does not get round that."""
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true")
    vendor = Vendor()
    notify.set_transport(vendor.transport())
    provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example"}, {"api_key": "k"}, mode="LIVE")
    campaign_id = approved_campaign(demo, "automated_tier_offer")
    reviewer, batch = demo.principal("approver"), latest_batch()
    offers = recommendations(batch.id, action_code="retention_discount_offer")
    assert [(r.segment, r.status, r.rationale["requires_human_review"]) for r in offers] == [("medium_risk_low_value", "proposed", True)]
    chosen = offers[0]
    with session_scope() as s:
        s.get(Campaign, campaign_id).ab_test = {"control_share": 0.0, "variants": {"A": 1.0}}  # no control group here: the one customer is certain to be written to
        s.get(Customer, chosen.customer_id).consent_marketing = True
    with session_scope() as s:
        before = campaigns.preview(s, reviewer, campaign_id)
        assert before["eligible"] == 0 and before["recommendations"]["left_out"]["waiting_for_review"] == 1, "nobody reviewed the discount yet"
        assert campaigns.start(s, reviewer, campaign_id, dry_run=False)["enrolled"] == 0
        retention.review(s, reviewer, chosen.id, approve=True)
        assert campaigns.preview(s, reviewer, campaign_id)["eligible"] == 1
        vendor.queue = [httpx.Response(202, headers={"X-Message-Id": "sg-offer-1"})]
        started = campaigns.start(s, reviewer, campaign_id, dry_run=False)
        assert started["enrolled"] == 1 and started["groups"] == {"A": 1}
    run_due_jobs(demo)
    with session_scope() as s:
        message = s.execute(select(NotificationMessage).where(NotificationMessage.campaign_id == campaign_id)).scalar_one()
        assert (message.status, message.is_dry_run, message.customer_id, message.provider_message_id) == ("sent", False, chosen.customer_id, "sg-offer-1")
        assert "STAY15" in message.body and "15%" in message.body and len(vendor.requests) == 1
        recommendation = s.get(RetentionRecommendation, chosen.id)
        action = s.execute(select(Intervention).where(Intervention.recommendation_id == chosen.id)).scalar_one()
        assert (recommendation.status, recommendation.campaign_id) == ("executed", campaign_id)
        assert (action.status, action.campaign_id, action.customer_id, action.action_code, action.channel) == (
            "sent_by_campaign", campaign_id, chosen.customer_id, "retention_discount_offer", "email")
        assert f"Message {message.id} of the campaign" in action.note
        audited = s.execute(select(AuditEvent).where(AuditEvent.action == "retention.recommendation_executed", AuditEvent.entity_id == str(chosen.id))).scalars().all()
        assert len(audited) == 1 and audited[0].detail["campaign_id"] == campaign_id and audited[0].detail["message_id"] == message.id
        with pytest.raises(Conflict, match="already been executed"):
            retention.execute(s, demo.principal("csm"), chosen.id)  # the same action is not handed to the CRM as well
        # the later steps of the sequence add messages, not actions
        s.execute(update(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign_id).values(next_step_at=utcnow() - timedelta(minutes=1)))
    vendor.queue = [httpx.Response(202, headers={"X-Message-Id": "sg-offer-2"})]
    campaigns.tick(campaign_id)
    run_due_jobs(demo)
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(NotificationMessage).where(NotificationMessage.campaign_id == campaign_id)).scalar_one() == 2
        assert s.execute(select(func.count()).select_from(Intervention).where(Intervention.recommendation_id == chosen.id)).scalar_one() == 1
    with session_scope() as s:
        assert campaigns.preview(s, reviewer, campaign_id)["recommendations"]["left_out"]["already_carried_out"] == 1


@pytest.mark.req("REQ-ACT-05")
def test_the_card_expiry_reminder_reaches_customers_whose_card_expires_soon_by_text_and_in_app(demo):
    """Brief 9.3: the customers the playbook flagged for involuntary churn get a text message and an in-app reminder."""
    set_mode_allowed(demo)
    provider(demo, "sms", "twilio", {"account_sid": "AC123", "from_number": "+15005550006"})
    reviewer = demo.principal("approver")
    flagged = recommendations(latest_batch().id, segment="involuntary")
    assert len(flagged) == 41 and {r.status for r in flagged} == {"proposed"} and not any(r.rationale["requires_human_review"] for r in flagged)
    assert {t for r in flagged for t in r.rationale["payment_triggers"]} <= {"payment method expires soon or has expired", "most recent payment failed"}
    with session_scope() as s:
        notify.create_provider(s, demo.principal("admin"), name="inbox", channel="in_app", provider="inbox")
        today = utcnow().date()
        by_card = [r.customer_id for r in flagged if "payment method expires soon or has expired" in r.rationale["payment_triggers"]]
        accounts = s.execute(select(Account).where(Account.tenant_id == demo.tenant_id, Account.status != "closed", Account.customer_id.in_(by_card))
                             .order_by(Account.id).limit(2)).scalars().all()  # fmt: skip
        accounts[0].payment_method_expires_on, accounts[1].payment_method_expires_on = today + timedelta(days=10), today - timedelta(days=3)
        soon, expired = accounts[0].customer_id, accounts[1].customer_id
    campaign_id = approved_campaign(demo, "card_expiry_reminder")
    with session_scope() as s:
        preview = campaigns.preview(s, reviewer, campaign_id)
        assert preview["recommendations"]["cleared"] == 41 and preview["matched"] == 41, "the playbook's flag decides, not a second threshold in the campaign"
        started = campaigns.start(s, reviewer, campaign_id, dry_run=True)
        assert started["enrolled"] == 41 and started["groups"] == {"A": 41}, "a transactional reminder has no control group and needs no marketing consent"
    run_due_jobs(demo)
    with read_session() as s:
        enrolled = {e.customer_id: e for e in s.execute(select(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign_id)).scalars()}
        assert set(enrolled) == {r.customer_id for r in flagged} and all(e.status == "completed" for e in enrolled.values())
        assert (enrolled[soon].source["days_left"], enrolled[expired].source["days_left"]) == (10, -3)
        messages = s.execute(select(NotificationMessage).where(NotificationMessage.campaign_id == campaign_id).order_by(NotificationMessage.id)).scalars().all()
        assert sorted((m.channel, m.step_index) for m in messages) == sorted([("sms", 0)] * 41 + [("in_app", 1)] * 41)
        assert all(m.category == "transactional" for m in messages) and {m.status for m in messages} <= {"dry_run", "blocked"}
        in_app = {m.customer_id: m for m in messages if m.channel == "in_app"}
        assert {m.status for m in in_app.values()} == {"dry_run"} and in_app[soon].subject == "Your payment method needs attention"
        # the message says what is on record for this customer, and nothing else
        assert in_app[soon].body.startswith(f"The payment card on file expires on {today + timedelta(days=10)}.")
        assert in_app[expired].body.startswith(f"The payment card on file expired on {today - timedelta(days=3)}.")
        only_failing = [r.customer_id for r in flagged if r.rationale["payment_triggers"] == ["most recent payment failed"]]
        assert all(in_app[c].body.startswith("The latest payment did not go through.") for c in only_failing)
        texts = [m for m in messages if m.channel == "sms"]
        sent_text = next((m for m in texts if m.status == "dry_run"), None)
        if sent_text is not None:
            assert "Update the payment method" in sent_text.body and sent_text.request["url"].endswith("/Accounts/AC123/Messages.json")
        assert all(m.status_reason == "no phone number on record" for m in texts if m.status == "blocked")
        assert s.get(Campaign, campaign_id).run_state == "completed"
    # a campaign may also select by the card's expiry date alone, whatever the playbook flagged
    with session_scope() as s:
        s.execute(update(Account).where(Account.tenant_id == demo.tenant_id).values(payment_method_expires_on=today + timedelta(days=900)))
        accounts = s.execute(select(Account).where(Account.tenant_id == demo.tenant_id, Account.status != "closed").order_by(Account.id).limit(6)).scalars().all()
        for n, account in enumerate(accounts):
            account.payment_method_expires_on = today + timedelta(days=(10, 20, 29, 45, 400, -3)[n])
        expected = {a.customer_id for a in accounts[:3]}
        by_date = campaigns.create(s, demo.principal("admin"), {"name": "Cards by date", "eligibility": {"card_expires_within_days": 30}, "requires_consent": False,
                                                              "steps": [{"channel": "in_app", "template_code": "card_expiring"}]})  # fmt: skip
        picked, info = campaigns.eligible_customers(s, by_date)
        assert {p["customer_id"] for p in picked} == expected and info["matched"] == 3, "within 30 days; not the one in 45 days, in 400 days, or already expired"
        assert sorted(p["source"]["days_left"] for p in picked) == [10, 20, 29] and all(p["source"]["payment_issue"].startswith("The payment card on file expires on") for p in picked)


@pytest.mark.req("REQ-ACT-05")
def test_a_campaign_can_be_paused_resumed_and_cancelled_and_its_rules_are_validated(demo):
    set_mode_allowed(demo)
    provider(demo, "email", "sendgrid", {"from_email": "retention@corp.example"})
    campaign_id = approved_campaign(demo, "automated_tier_drip")
    reviewer = demo.principal("approver")
    with session_scope() as s:
        campaigns.start(s, reviewer, campaign_id)
    run_due_jobs(demo)
    with session_scope() as s:
        assert campaigns.set_run_state(s, reviewer, campaign_id, "pause").run_state == "paused"
        s.execute(update(CampaignEnrollment).where(CampaignEnrollment.campaign_id == campaign_id, CampaignEnrollment.status == "active").values(next_step_at=utcnow() - timedelta(minutes=1)))
    assert campaigns.tick(campaign_id)["skipped"] == "the campaign is not running", "nothing goes out while the campaign is paused"
    with session_scope() as s:
        with pytest.raises(Conflict):
            campaigns.set_run_state(s, reviewer, campaign_id, "pause")
        assert campaigns.set_run_state(s, reviewer, campaign_id, "resume").run_state == "running"
    run_due_jobs(demo)
    with session_scope() as s:
        assert set(s.execute(select(NotificationMessage.step_index).where(NotificationMessage.campaign_id == campaign_id)).scalars()) == {0, 1}
        cancelled = campaigns.set_run_state(s, reviewer, campaign_id, "cancel")
        assert cancelled.run_state == "cancelled" and cancelled.finished_at is not None
        assert set(s.execute(select(CampaignEnrollment.status).where(CampaignEnrollment.campaign_id == campaign_id, CampaignEnrollment.variant != "control")).scalars()) == {"cancelled"}
        with pytest.raises(Conflict):
            campaigns.start(s, reviewer, campaign_id)
        with pytest.raises(ValidationFailed):
            campaigns.set_run_state(s, reviewer, campaign_id, "explode")
    base = {"name": "Custom", "eligibility": {"risk_tiers": ["high"]}, "steps": [{"channel": "email", "template_code": "offer_intro"}]}
    for bad, field in (({**base, "eligibility": {}}, "eligibility"), ({**base, "eligibility": {"risk_tiers": ["severe"]}}, "eligibility"), ({**base, "steps": []}, "steps"),
                       ({**base, "eligibility": {"segments": ["everyone"]}}, "eligibility"), ({**base, "eligibility": {"action_codes": ["reengagement_drip"]}}, "eligibility"),
                       ({**base, "eligibility": {"plan_tiers": ["pro"]}}, "eligibility"),
                       ({**base, "steps": [{"channel": "fax", "template_code": "x"}]}, "steps"), ({**base, "steps": [{"channel": "email", "template_code": "x", "delay_hours": -1}]}, "steps"),
                       ({**base, "ab_test": {"control_share": 0.9}}, "ab_test"), ({**base, "steps": [{"channel": "email", "template_code": "x", "variant": "B"}]}, "steps"),
                       ({**base, "cooldown_days": 999}, "cooldown_days"), ({**base, "name": " "}, "name")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed) as invalid:
            campaigns.create(s, demo.principal("admin"), bad)
        assert invalid.value.details["field"] == field, bad
    with demo.client() as c:
        viewer, scientist = demo.login(c, "viewer"), demo.login(c, "data_scientist")
        page = c.get(f"{API}/campaigns", headers=viewer).json()
        assert set(page["presets"]) == {"automated_tier_drip", "automated_tier_offer", "card_expiry_reminder"} and page["items"][0]["run_state"] == "cancelled"
        assert c.post(f"{API}/campaigns/presets", headers=viewer, json={"preset": "card_expiry_reminder"}).status_code == 403
        created = c.post(f"{API}/campaigns/presets", headers=scientist, json={"preset": "card_expiry_reminder"})
        assert created.status_code == 201 and created.json()["status"] == "draft"
        assert c.post(f"{API}/campaigns/{created.json()['id']}/start", headers=scientist, json={}).status_code == 403, "starting a campaign needs the approval permission"
        listed = c.get(f"{API}/campaigns/{campaign_id}/enrollments", headers=viewer, params={"page_size": 5}).json()
        assert listed["total"] > 0 and {"customer_external_id", "variant", "status"} <= set(listed["items"][0])


class LittleSmtpServer:
    """A mail submission server, in this process: enough of ESMTP for what the platform sends.

    It answers the greeting, EHLO, MAIL FROM, RCPT TO, DATA and QUIT, and keeps every message it received
    and every command it was given, so a test can say what the platform really put on the wire.
    """

    def __init__(self) -> None:
        self.messages: list[str] = []
        self.commands: list[str] = []
        self._buffer: list[str] = []

    def __enter__(self) -> LittleSmtpServer:
        import socketserver
        import threading

        outer = self

        class Handler(socketserver.StreamRequestHandler):
            def handle(self) -> None:
                self.wfile.write(b"220 little ESMTP service ready\r\n")
                in_data = False
                while True:
                    raw = self.rfile.readline()
                    if not raw:
                        return
                    line = raw.decode("utf-8", "replace").rstrip("\r\n")
                    if in_data:
                        if line == ".":
                            in_data = False
                            outer.messages.append("\n".join(outer._buffer))
                            outer._buffer = []
                            self.wfile.write(b"250 2.0.0 queued as <little@test>\r\n")
                        else:
                            outer._buffer.append(line)
                        continue
                    outer.commands.append(line.split(" ")[0].upper() if line else "")
                    upper = line.upper()
                    if upper.startswith(("EHLO", "HELO")):
                        self.wfile.write(b"250-little.test\r\n250 8BITMIME\r\n")
                    elif upper.startswith(("MAIL FROM", "RCPT TO", "NOOP", "RSET")):
                        self.wfile.write(b"250 2.0.0 OK\r\n")
                    elif upper.startswith("DATA"):
                        in_data = True
                        self.wfile.write(b"354 End data with <CR><LF>.<CR><LF>\r\n")
                    elif upper.startswith("QUIT"):
                        self.wfile.write(b"221 2.0.0 Bye\r\n")
                        return
                    else:
                        self.wfile.write(b"502 5.5.2 Command not implemented\r\n")

        self._server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Handler)
        self._server.daemon_threads = True
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=5)


@pytest.mark.req("REQ-ACT-05")
def test_the_e_mail_channel_can_be_delivered_through_an_smtp_server(demo):
    """The fourth way to reach a customer's inbox: SMTP itself, spoken to a mail server."""
    # the test's mail server is on this machine, which the outbound guard allows only when told to
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true", CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS="true")
    assert "smtp" in notify.PROVIDERS["email"]
    approved_template(demo, "hello", "email", "Hello {{customer_name}}, your plan changed.", subject="Your plan", category="transactional")
    customer = customers_with(demo, consent=True, n=1)[0]
    with LittleSmtpServer() as server:
        provider_id = provider(demo, "email", "smtp", {"host": "127.0.0.1", "port": server.port, "from_email": "retention@corp.example",
                                                      "from_name": "Retention"}, None, mode="SANDBOX")
        with read_session() as s:
            entry = s.get(notify.NotificationProvider, provider_id)
            request = notify.build_request(entry, {}, recipient="a@b.example", subject="S", body="B", message_ref="m-1", validate_only=True)
        assert request["method"] == "SMTP" and request["url"] == f"smtp://127.0.0.1:{server.port}"
        assert request["json"] == {"to": "a@b.example", "from": "retention@corp.example", "from_name": "Retention", "subject": "S", "body": "B",
                                  "message_ref": "m-1", "validate_only": True}
        assert request["smtp"] == {"host": "127.0.0.1", "port": server.port, "starttls": False, "username": None, "password": None}

        # SANDBOX: the handshake is made, the message is not transmitted (there is no vendor to ask "is this valid?")
        rehearsed = send(demo, customer.id, "email", "hello", "smtp-sandbox")
        demo.drain()
        with read_session() as s:
            sandbox_message = s.get(NotificationMessage, rehearsed.id)
            assert sandbox_message.status == "sent" and server.messages == [], "nothing went on the wire in SANDBOX"
            assert sandbox_message.provider_message_id is None and "validation mode" in sandbox_message.status_reason
            assert sandbox_message.request["url"] == f"smtp://127.0.0.1:{server.port}" and "a@b.example" not in json.dumps(sandbox_message.request)
        assert "DATA" not in server.commands and "NOOP" in server.commands

        # LIVE: the message is transmitted, and what the server received is what the platform rendered
        with session_scope() as s:
            notify.set_mode(s, demo.principal("approver"), provider_id, "LIVE")
        delivered = send(demo, customer.id, "email", "hello", "smtp-live")
        demo.drain()
        with read_session() as s:
            live = s.get(NotificationMessage, delivered.id)
            assert (live.status, live.status_reason) == ("sent", None), "a real send carries no sandbox note"
            assert live.provider_message_id and live.provider_message_id.startswith("<") and live.provider_message_id.endswith(">")
        assert len(server.messages) == 1, "exactly one message reached the mail server"
        received = server.messages[0]
        assert "Subject: Your plan" in received and f"To: {customer.email}" in received
        assert "From: Retention <retention@corp.example>" in received
        assert f"Hello {customer.name}, your plan changed." in received
        assert "X-Churn-Message-Ref: smtp-live" in received

    # a mail server that is not there: a temporary failure, so the message waits for the next attempt
    with session_scope() as s:
        notify.set_mode(s, demo.principal("approver"), provider_id, "SANDBOX")
        down = notify.create_provider(s, demo.principal("admin"), name="smtp gone", channel="email", provider="smtp",
                                      config={"host": "127.0.0.1", "port": 9, "from_email": "r@corp.example"}, is_default=False)  # fmt: skip
        notify.set_mode(s, demo.principal("approver"), down.id, "LIVE")
    # an SMTP relay may take mail without authentication, so leaving DRY_RUN needs no credential (a server that
    # wants AUTH answers 530, which is recorded on the message instead)
    assert notify.deliver(send(demo, customer.id, "email", "hello", "smtp-down").id)["http_status"] is None
    with read_session() as s:
        stored = s.execute(select(NotificationMessage).where(NotificationMessage.idempotency_key == "smtp-down")).scalar_one()
        assert stored.attempts == 1 and stored.response["retryable"] is True and stored.next_attempt_at is not None
        assert stored.status == "queued", "a mail server that cannot be reached is retried, not written off"
    # configuration: a host and a sender are required, and so is an address that looks like one
    with session_scope() as s, pytest.raises(ValidationFailed) as no_host:
        notify.create_provider(s, demo.principal("admin"), name="smtp bare", channel="email", provider="smtp", config={"from_email": "r@corp.example"})
    assert "host" in no_host.value.message
    with session_scope() as s, pytest.raises(ValidationFailed):
        notify.create_provider(s, demo.principal("admin"), name="smtp weird", channel="email", provider="smtp",
                               config={"host": "127.0.0.1", "from_email": "not-an-address"})  # fmt: skip


@pytest.mark.req("REQ-SEC-05")
def test_a_mail_server_on_a_private_address_must_be_allowed_explicitly(demo):
    """A mail server is reached by an address an administrator types, so it is checked like a URL.

    The HTTP providers refuse a name that resolves to a private, loopback or link-local address
    unless ``CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS`` says otherwise.  SMTP is no different: a relay on
    the same machine needs the setting, and without it nothing is sent.
    """
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true")  # deliberately without the private-host escape
    approved_template(demo, "hello", "email", "Hello {{customer_name}}.", subject="Hello", category="transactional")
    customer = customers_with(demo, consent=True, n=1)[0]
    with LittleSmtpServer() as server:
        provider_id = provider(demo, "email", "smtp", {"host": "127.0.0.1", "port": server.port, "from_email": "r@corp.example"}, None, mode="LIVE")
        refused = send(demo, customer.id, "email", "hello", "smtp-private")
        demo.drain()
        with read_session() as s:
            message = s.get(NotificationMessage, refused.id)
            assert message.status == "failed", "a refused address is not retried: waiting will not change the answer"
            assert message.next_attempt_at is None and message.attempts == 1
            assert "non-public address" in message.status_reason and message.provider_message_id is None
        assert server.commands == [] and server.messages == [], "the platform never spoke to the mail server"

    # an unresolvable name and something that is not a plain host are refused the same way
    for host, expected in (("no-such-host.invalid", "cannot resolve host"), ("http://relay.example/", "plain host name")):
        with session_scope() as s:
            # the default provider for the channel is the one a message goes to, so this one takes its place
            broken = notify.create_provider(s, demo.principal("admin"), name=f"smtp {host[:8]}", channel="email", provider="smtp",
                                            config={"host": host, "port": 2525, "from_email": "r@corp.example"}, is_default=True)  # fmt: skip
            notify.set_mode(s, demo.principal("approver"), broken.id, "LIVE")
            notified_id = notify.send(s, tenant_id=demo.tenant_id, customer_id=customer.id, channel="email", template_code="hello",
                                      idempotency_key=f"smtp-{host[:8]}").id  # fmt: skip
        notify.deliver(notified_id)
        with read_session() as s:
            message = s.get(NotificationMessage, notified_id)
            assert message.status == "failed" and expected in message.status_reason
            assert message.response["retryable"] is False

    with session_scope() as s:
        notify.set_mode(s, demo.principal("approver"), provider_id, "DRY_RUN")


@pytest.mark.req("REQ-ACT-05")
def test_a_marketing_message_outside_the_quiet_hours_is_held_and_released_rather_than_dropped(demo, monkeypatch):
    """Quiet hours are a hold, not a refusal: the message keeps its place in the queue and goes out at the window's end."""
    set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true", CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS="true")
    approved_template(demo, "hello", "email", "Hello {{customer_name}}, your plan changed.", subject="Your plan", category="transactional")
    approved_template(demo, "offer", "email", "Hello {{customer_name}}, an offer: {{unsubscribe_url}}", subject="An offer", category="marketing")
    customer = customers_with(demo, consent=True, n=1)[0]
    with LittleSmtpServer() as server:
        provider_id = provider(demo, "email", "smtp", {"host": "127.0.0.1", "port": server.port, "from_email": "r@corp.example"}, None, mode="LIVE")

        # a window that contains "now", whatever time the suite runs: the previous and the next hour
        this_hour = utcnow().hour
        window = f"{(this_hour - 1) % 24:02d}:00-{(this_hour + 1) % 24:02d}:00"
        set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true", CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS="true",
                         CHURN_NOTIFY_QUIET_HOURS=window)  # fmt: skip
        held = send(demo, customer.id, "email", "offer", "quiet-marketing")
        assert held.status == "queued", "a marketing message is held, not sent and not dropped"
        assert held.next_attempt_at is not None and held.next_attempt_at > utcnow()
        assert "quiet hours: held until" in held.status_reason
        assert held.provider_message_id is None and server.messages == [], "nothing left the process"

        # a transactional message is not held: a receipt is not marketing
        receipt = send(demo, customer.id, "email", "hello", "quiet-transactional")
        assert receipt.status == "queued" and receipt.next_attempt_at is None

        # the window is validated rather than ignored: an installation that thinks it is quiet may not be
        set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true", CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS="true", CHURN_NOTIFY_QUIET_HOURS="21:00")
        for bad in ("21:00", "25:00-08:00", "21:00-08:00-extra"):
            monkeypatch.setenv("CHURN_NOTIFY_QUIET_HOURS", bad)
            get_settings.cache_clear()
            with pytest.raises(ValidationFailed) as invalid:
                notify.quiet_hours(utcnow())
            assert invalid.value.details["field"] == "quiet_hours"
        monkeypatch.setenv("CHURN_NOTIFY_QUIET_HOURS", "21:00-08:00")
        monkeypatch.setenv("CHURN_NOTIFY_QUIET_TIMEZONE", "Mars/Olympus")
        get_settings.cache_clear()
        with pytest.raises(ValidationFailed) as zone:
            notify.quiet_hours(utcnow())
        assert zone.value.details["field"] == "quiet_timezone"

        # switched off, the same message is delivered as before
        monkeypatch.delenv("CHURN_NOTIFY_QUIET_HOURS", raising=False)
        monkeypatch.setenv("CHURN_NOTIFY_QUIET_TIMEZONE", "UTC")
        get_settings.cache_clear()
        set_mode_allowed(demo, CHURN_NOTIFY_ALLOW_LIVE="true", CHURN_NOTIFY_ALLOW_PRIVATE_HOSTS="true")
        live = send(demo, customer.id, "email", "offer", "no-quiet-marketing")
        # the held message keeps its delivery job for the end of the window, so the drain has one job still waiting
        demo.drain(expect_success=False)
        with read_session() as s:
            assert s.get(NotificationMessage, live.id).status == "sent"
            still_held = s.get(NotificationMessage, held.id)
            assert still_held.status == "queued" and still_held.next_attempt_at > utcnow(), "the hold survives later sends"
        sent_refs = " ".join(server.messages)
        assert "X-Churn-Message-Ref: no-quiet-marketing" in sent_refs and "X-Churn-Message-Ref: quiet-transactional" in sent_refs
        assert "quiet-marketing " not in sent_refs.replace("no-quiet-marketing", ""), "the held message never reached the server"
        with session_scope() as s:
            notify.set_mode(s, demo.principal("approver"), provider_id, "DRY_RUN")
    get_settings.cache_clear()
