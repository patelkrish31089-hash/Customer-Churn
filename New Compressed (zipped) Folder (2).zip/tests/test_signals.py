"""Customer signals (1.1.0): support sentiment, feature adoption, identity and active users, attribute history.

Each signal is tested at three levels: the arithmetic on hand-built frames, the service against a seeded tenant,
and the point-in-time rule (nothing dated at or after T may move a feature for T).
"""

from __future__ import annotations

import os
import shutil
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from sqlalchemy import func, select, update

from churn_platform import synthetic_text
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, Forbidden, ValidationFailed
from churn_platform.models import (
    AdoptionFact,
    AdoptionRun,
    Customer,
    CustomerAttributeHistory,
    EntityHistory,
    IdentityLink,
    IdentityMergeCandidate,
    SentimentModel,
    SentimentScore,
    SupportInteraction,
)
from churn_platform.services import adoption, attributes, identity, policies, sentiment, signals, timeline
from churn_platform.services import feature_engine as fe
from tests.builders import World
from tests.conftest import activate, require_or_skip

T = date(2026, 4, 1)
API = "/api/v1"
MODEL_DIR = os.environ.get("CHURN_TEST_SENTIMENT_MODEL_DIR", "")


def vector(world: World, as_of: date = T, customer_id: int = 1) -> dict:
    out = fe.compute_features(world.frames(), [as_of])
    rows = out[out["customer_id"] == customer_id]
    assert len(rows) == 1, f"expected one vector for customer {customer_id}, got {len(rows)}"
    return rows.iloc[0].to_dict()


def base_world(tier: str = "pro", seats: int = 10) -> World:
    w = World()
    w.plan(1, tier=tier, billing_period="monthly")
    w.customer(1, industry="software", employee_count=100, company_size="mid_market", region="emea", acquisition_channel="organic", acquired_at="2026-01-01")
    w.account(1, payment_method_expires_on="2026-12-31")
    w.subscription(1, 1, "2026-01-01", plan_id=1, mrr=200.0, quantity=seats, discount_pct=0.0)
    return w


def missing(value: object) -> bool:
    return value is None or (isinstance(value, float) and np.isnan(value))


# ============================================================================= sentiment
@pytest.mark.req("REQ-SIG-01")
def test_text_is_prepared_before_it_is_scored_and_every_unscorable_text_has_a_state():
    baseline = sentiment.LexiconBaseline()
    texts = ["", "   ", "ok", "👍", "Das Dashboard ist seit Tagen kaputt und niemand antwortet uns.",
             "Thanks, great support. The issue was solved quickly.",
             "The export is broken again and this is unacceptable. We want a refund.",
             "Great support and we love the dashboards, thank you. But the export is broken and useless.",
             "Mail me at jane.doe@example.com or call +44 20 7946 0958; card 4111 1111 1111 1111. The export is broken.",
             "The report is terrible. " + "word " * 2000]
    results = sentiment.analyse(texts, baseline)
    assert [r.state for r in results] == ["empty", "empty", "too_short", "too_short", "unsupported_language", "ok", "ok", "ok", "ok", "ok"]
    assert all(r.label == "uncertain" and r.confidence is None and r.score is None for r in results[:5]), "what cannot be scored carries no score"
    assert results[4].language == "de" and results[5].language == "en"
    assert [r.label for r in results[5:8]] == ["positive", "negative", "mixed"]
    assert all(0 <= r.confidence <= 1 and abs(r.p_positive + r.p_neutral + r.p_negative - 1) < 1e-3 for r in results[5:])
    redacted = results[8]
    assert redacted.redactions == {"email": 1, "card": 1, "phone": 1} and "redacted" in redacted.flags
    assert "jane.doe" not in redacted.excerpt and "4111" not in redacted.excerpt and "7946" not in redacted.excerpt
    assert "[EMAIL]" in redacted.excerpt and "[CARD]" in redacted.excerpt and "[PHONE]" in redacted.excerpt
    assert "truncated" in results[9].flags and results[9].label == "negative", "a very long text is shortened, not dropped"
    # the same text is scored once: identical inputs give identical results, and the key ignores case
    assert sentiment.text_key("The Export is BROKEN") == sentiment.text_key("the export is broken")
    # a number that merely looks like a card number is left alone (Luhn check), as is an ordinary amount
    kept, counts = sentiment.redact_pii("Invoice 1234 5678 9012 3456 for 1,250.00 EUR")
    assert counts == {} and kept.startswith("Invoice 1234")


@pytest.mark.req("REQ-SIG-01")
def test_language_detection_separates_supported_languages_and_admits_what_it_cannot_tell():
    cases = {"how do I configure this for a second team, please send the steps": "en", "Wie richten wir das für ein zweites Team ein? Bitte senden Sie uns die Schritte.": "de",
             "Comment configurer cela pour une deuxième équipe ? Merci de nous envoyer les étapes.": "fr",
             "¿Cómo configuramos esto para un segundo equipo? Por favor envíen los pasos.": "es", "हम दूसरी टीम के लिए इसे कैसे सेट करें? कृपया चरण भेजें।": "hi"}  # fmt: skip
    for text, expected in cases.items():
        assert sentiment.detect_language(text)[0] == expected, text
    assert sentiment.detect_language("xqzv wkpl")[0] == "und" or sentiment.detect_language("xqzv wkpl")[1] < 0.9


@pytest.mark.req("REQ-SIG-01")
def test_every_support_text_has_one_score_per_model_and_rescoring_is_idempotent(demo):
    with read_session() as s:
        model = sentiment.active_model(s, demo.tenant_id)
        texts = s.execute(select(func.count()).select_from(SupportInteraction).where(SupportInteraction.tenant_id == demo.tenant_id,
                                                                                    SupportInteraction.kind != "nps_survey")).scalar_one()  # fmt: skip
        scores = s.execute(select(func.count()).select_from(SentimentScore).where(SentimentScore.sentiment_model_id == model.id)).scalar_one()
        per_text = s.execute(select(func.max(func.count()).over()).select_from(SentimentScore).group_by(SentimentScore.interaction_id).limit(1)).scalar_one()
        states = dict(s.execute(select(SentimentScore.state, func.count()).group_by(SentimentScore.state)).all())
        assert (model.provider, model.is_baseline, model.is_active) == ("lexicon_baseline", True, True), "the suite scores with the labelled baseline"
        assert texts == scores > 300 and per_text == 1, "one score per interaction and model"
        assert states["ok"] > 100 and states.get("unsupported_language", 0) > 50 and states.get("empty", 0) >= 1, states
        assert sentiment.pending_count(s, demo.tenant_id, model.id) == 0
        # the score carries the interaction's own time (what point-in-time features read), not the time of scoring
        row = s.execute(select(SentimentScore, SupportInteraction).join(SupportInteraction, SupportInteraction.id == SentimentScore.interaction_id).limit(1)).one()
        assert row[0].occurred_at == row[1].opened_at and row[0].scored_at > row[1].opened_at
        assert row[0].source_record_version == row[1].record_version and len(model.checksum_sha256) == 64
    again = sentiment.score_pending(demo.tenant_id)
    assert again["scored"] == 0 and again["model"]["is_baseline"] is True
    # a changed text is scored again, and only that one
    with session_scope() as s:
        target = s.execute(select(SupportInteraction).where(SupportInteraction.tenant_id == demo.tenant_id, SupportInteraction.kind != "nps_survey").limit(1)).scalar_one()
        target.body, target.record_version, changed = "This is terrible, the worst outage so far and nobody answers.", target.record_version + 1, target.id
    assert sentiment.score_pending(demo.tenant_id)["scored"] == 1
    with read_session() as s:
        score = s.execute(select(SentimentScore).where(SentimentScore.interaction_id == changed)).scalar_one()
        assert (score.label, score.state, score.source_record_version) == ("negative", "ok", 2)
    assert signals.ensure_ready(demo.tenant_id)["sentiment_model"]["provider"] == "lexicon_baseline"


@pytest.mark.req("REQ-SIG-01")
def test_the_baseline_is_always_labelled_and_a_missing_model_is_reported_not_hidden(demo, tmp_path):
    activate(demo.db_path, demo.data_dir, CHURN_SENTIMENT_PROVIDER="auto", CHURN_SENTIMENT_MODEL_DIR=str(tmp_path / "no-model-here"))
    info, fallback, problem = sentiment.describe_provider()
    assert info.is_baseline and info.provider == "lexicon_baseline" and problem is None
    assert fallback and ("not installed" in fallback or "no model in" in fallback), fallback
    with read_session() as s:
        status = sentiment.status(s, demo.tenant_id)
    assert status["provider"]["is_baseline"] is True and status["fallback_reason"] == fallback
    assert status["production_accuracy"]["status"] == "BLOCKED" and "no labelled sample of real support text" in status["production_accuracy"]["reason"]
    assert status["inference"].startswith("local"), "no text leaves the installation"
    # demanding the transformer when it cannot be used is an error, not a silent fallback
    activate(demo.db_path, demo.data_dir, CHURN_SENTIMENT_PROVIDER="onnx_transformer", CHURN_SENTIMENT_MODEL_DIR=str(tmp_path / "no-model-here"))
    sentiment.reset_provider_cache()
    with pytest.raises(Conflict) as refused:
        sentiment.get_provider()
    assert refused.value.code == "sentiment_model_unavailable"
    with read_session() as s:
        assert "cannot be used" in sentiment.status(s, demo.tenant_id)["problem"]


@pytest.mark.req("REQ-SIG-01")
def test_the_transformer_runs_locally_on_pinned_weights_and_scores_several_languages(demo, tmp_path, monkeypatch):
    require_or_skip(bool(MODEL_DIR) and (Path(MODEL_DIR) / sentiment.DEFAULT_PIN / "onnx" / "model_quantized.onnx").is_file(),
                    "the pinned sentiment model is not in CHURN_TEST_SENTIMENT_MODEL_DIR (fetch it with: churn-platform sentiment-model fetch)")
    require_or_skip(sentiment.runtime_problem() is None, f"sentiment runtime missing: {sentiment.runtime_problem()}")
    activate(demo.db_path, demo.data_dir, CHURN_SENTIMENT_PROVIDER="auto", CHURN_SENTIMENT_MODEL_DIR=MODEL_DIR)
    sentiment.reset_provider_cache()
    provider, fallback = sentiment.get_provider()
    pin = sentiment.PINS[sentiment.DEFAULT_PIN]
    assert fallback is None and provider.info.provider == "onnx_transformer" and provider.info.is_baseline is False
    assert provider.info.model_version == pin["revision"] and provider.info.checksum_sha256 == pin["files"]["onnx/model_quantized.onnx"][1]
    # inference opens no network connection
    import socket

    def no_network(*_args, **_kwargs):
        raise AssertionError("sentiment inference tried to open a network connection")

    monkeypatch.setattr(socket.socket, "connect", no_network)
    texts = ["Thank you, great support. The issue with the reports was solved quickly.",
             "Das ist inakzeptabel. Die Berichte fallen ständig aus und unser Team verliert Stunden.",
             "Merci beaucoup, excellent support. Le problème avec les rapports a été résolu rapidement.",
             "La exportación de informes falla siempre. Es la peor experiencia que hemos tenido con un proveedor.",
             "The onboarding was excellent and we love the new dashboards, but the export is terrible and keeps failing.",
             "हम बहुत परेशान हैं: रिपोर्ट कई दिनों से खराब है और कोई जवाब नहीं दे रहा।"]
    results = sentiment.analyse(texts, provider)
    assert [(r.state, r.label, r.language) for r in results] == [
        ("ok", "positive", "en"), ("ok", "negative", "de"), ("ok", "positive", "fr"), ("ok", "negative", "es"), ("ok", "mixed", "en"),
        ("unsupported_language", "uncertain", "hi")]  # fmt: skip
    assert all(r.confidence >= 0.8 for r in results[:4])
    # a text gets the same score whatever it is scored together with (the quantised weights would make a batch's texts
    # depend on each other: OnnxTransformer.predict scores them one by one)
    alone = provider.predict([texts[0]])[0]
    assert np.array_equal(provider.predict([texts[0], texts[1]])[0], alone) and np.array_equal(provider.predict([texts[5], texts[4], texts[0]])[2], alone)
    assert np.array_equal(provider.predict(texts), provider.predict(texts[::-1])[::-1]), "order does not matter either"
    monkeypatch.undo()
    # scoring the tenant replaces the baseline's scores by the model's, and the model row records what scored
    counts = sentiment.score_pending(demo.tenant_id)
    assert counts["model"]["is_baseline"] is False and counts["scored"] > 300 and counts["by_language"].get("de", 0) > 0
    with read_session() as s:
        models = s.execute(select(SentimentModel).where(SentimentModel.tenant_id == demo.tenant_id).order_by(SentimentModel.id)).scalars().all()
        assert [(m.provider, m.is_active) for m in models] == [("lexicon_baseline", False), ("onnx_transformer", True)]
        assert models[1].license == "mit" and "huggingface.co" in models[1].source
        frames = timeline.load_signal_frames(s, demo.tenant_id)
        assert set(frames["sentiment"]["state"]) >= {"ok", "unsupported_language"} and len(frames["sentiment"]) == counts["scored"]
        evaluation = sentiment.evaluate(s, demo.principal("admin"), dataset_name="synthetic templates", is_synthetic=True,
                                        rows=[{"text": r["text"], "label": r["label"]} for r in synthetic_text.labelled_set()])  # fmt: skip
        assert evaluation.metrics["polarity_errors"] == 0 and evaluation.metrics["accuracy_on_covered"] >= 0.95 and "SYNTHETIC" in evaluation.metrics["caveat"]
        assert sentiment.status(s, demo.tenant_id)["production_accuracy"]["status"] == "BLOCKED", "a synthetic set is not an accuracy measurement"
    # a model directory whose files do not match the pinned checksums is refused, and the baseline says why it stands in
    broken = tmp_path / "models"
    shutil.copytree(Path(MODEL_DIR) / sentiment.DEFAULT_PIN, broken / sentiment.DEFAULT_PIN, ignore=shutil.ignore_patterns("*.onnx"))
    (broken / sentiment.DEFAULT_PIN / "onnx").mkdir(exist_ok=True)
    (broken / sentiment.DEFAULT_PIN / "onnx" / "model_quantized.onnx").write_bytes(b"not the pinned weights")
    activate(demo.db_path, demo.data_dir, CHURN_SENTIMENT_PROVIDER="auto", CHURN_SENTIMENT_MODEL_DIR=str(broken))
    sentiment.reset_provider_cache()
    info, fallback, _problem = sentiment.describe_provider()
    assert info.is_baseline and "does not match its pinned checksums" in fallback


@pytest.mark.req("REQ-SIG-01", "REQ-ML-02")
def test_sentiment_features_use_scores_of_tickets_before_T_only_and_are_missing_without_scores():
    w = base_world()
    w.ticket(1, "2026-01-20T10:00:00", body="a")   # id 1, outside 30 days, inside 90
    w.ticket(1, "2026-03-10T10:00:00", body="b")   # id 2
    w.ticket(1, "2026-03-20T10:00:00", body="c")   # id 3
    w.ticket(1, "2026-03-25T10:00:00", body="d")   # id 4: could not be scored
    w.ticket(1, "2026-04-02T10:00:00", body="e")   # id 5: after T
    for ticket, label, score, state in ((1, "positive", 0.8, "ok"), (2, "negative", -0.9, "ok"), (3, "neutral", 0.1, "ok"), (4, "uncertain", None, "unsupported_language"),
                                        (5, "negative", -1.0, "ok")):  # fmt: skip
        w.sentiment(ticket, label, score, state)
    v = vector(w)
    assert v["negative_ticket_share_90d"] == pytest.approx(1 / 3), "one negative among the three scored tickets; the unscored one is not in the denominator"
    assert v["negative_tickets_30d"] == 1 and v["sentiment_avg_score_30d"] == pytest.approx(-0.4) and v["sentiment_avg_score_90d"] == pytest.approx(0.0)
    assert v["sentiment_delta_30d_prev60d"] == pytest.approx(-0.4 - 0.8) and v["last_ticket_sentiment_score"] == pytest.approx(0.1)
    assert v["tickets_90d"] == 4, "ticket counts do not depend on scoring"
    later = vector(w, date(2026, 4, 3))
    assert later["negative_tickets_30d"] == 2 and later["last_ticket_sentiment_score"] == pytest.approx(-1.0), "the later ticket counts once T has passed it"
    # no sentiment frame at all (nothing was ever scored): unknown, never zero
    bare = base_world()
    bare.ticket(1, "2026-03-10T10:00:00", body="the export is broken")
    unknown = vector(bare)
    assert all(missing(unknown[name]) for name in ("negative_ticket_share_90d", "negative_tickets_30d", "sentiment_avg_score_30d", "sentiment_avg_score_90d",
                                                    "sentiment_delta_30d_prev60d", "last_ticket_sentiment_score"))  # fmt: skip
    # tickets exist in the window but none could be scored: the count is unknown too
    w2 = base_world()
    w2.ticket(1, "2026-03-10T10:00:00", body="x")
    w2.sentiment(1, "uncertain", None, "unsupported_language")
    assert missing(vector(w2)["negative_tickets_30d"]) and missing(vector(w2)["negative_ticket_share_90d"])


@pytest.mark.req("REQ-SIG-01")
def test_sentiment_api_shows_the_model_the_states_and_scores_a_text_without_storing_it(demo):
    with demo.client() as c:
        admin, viewer = demo.login(c, "admin"), demo.login(c, "viewer")
        page = c.get(f"{API}/signals/sentiment", headers=viewer).json()
        assert page["status"]["provider"]["is_baseline"] is True and page["status"]["pending"] == 0 and page["status"]["active_model_is_current"] is True
        assert page["summary"]["total"] > 100 and set(page["summary"]["by_label"]) <= set(sentiment.LABELS) and page["summary"]["weekly"]
        assert page["status"]["production_accuracy"]["evaluations"][0]["is_synthetic"] is True
        scores = c.get(f"{API}/signals/sentiment/scores", headers=viewer, params={"label": "negative", "page_size": 5}).json()
        assert scores["total"] > 10 and all(row["label"] == "negative" and "text_sha256" not in row for row in scores["items"])
        unsupported = c.get(f"{API}/signals/sentiment/scores", headers=viewer, params={"state": "unsupported_language", "page_size": 1}).json()
        assert unsupported["total"] > 50 and unsupported["items"][0]["confidence"] is None
        assert c.get(f"{API}/signals/sentiment/scores", headers=viewer, params={"label": "angry"}).status_code == 422
        before = c.get(f"{API}/signals/sentiment", headers=viewer).json()["summary"]["total"]
        tried = c.post(f"{API}/signals/sentiment/analyse", headers=admin, json={"texts": ["Terrible, the export is broken. Call +1 415 555 0100."]}).json()
        assert tried["results"][0]["label"] == "negative" and tried["results"][0]["redactions"] == {"phone": 1} and tried["provider"]["is_baseline"] is True
        assert c.get(f"{API}/signals/sentiment", headers=viewer).json()["summary"]["total"] == before, "trying a message stores nothing"
        assert c.post(f"{API}/signals/sentiment/analyse", headers=viewer, json={"texts": ["x"]}).status_code == 403
        real = c.post(f"{API}/signals/sentiment/evaluations", headers=admin, json={"dataset_name": "desk sample", "is_synthetic": False, "rows": [
            {"text": "Thanks, great support, the issue was solved.", "label": "positive"}, {"text": "The export is broken and useless.", "label": "negative"},
            {"text": "Please change the billing contact on our account.", "label": "neutral"}, {"text": "Vielen Dank, toller Support.", "label": "positive"}]})
        assert real.status_code == 201 and real.json()["metrics"]["rows"] == 4 and real.json()["metrics"]["not_scored_by_state"] == {"unsupported_language": 1}
        assert real.json()["metrics"]["caveat"] is None
        assert c.get(f"{API}/signals/sentiment", headers=viewer).json()["status"]["production_accuracy"]["status"] == "PASS"
        bad = c.post(f"{API}/signals/sentiment/evaluations", headers=admin, json={"dataset_name": "x", "rows": [{"text": "a", "label": "furious"}]})
        assert bad.status_code == 422


# ============================================================================= feature adoption
def adoption_world() -> World:
    w = base_world(tier="pro")
    w.feature("reports", is_core=True, min_events=2, min_days=2)
    w.feature("dashboards", is_core=True)
    w.feature("automation", plan_tiers=("enterprise",))                      # not in this customer's plan
    w.feature("collaboration", release_date="2026-03-15")                    # released two weeks before T
    w.feature("legacy", retired_date="2026-02-01")                           # retired before T
    w.feature("api_access", first_seen=None)                                 # telemetry never arrived
    for day in ("2026-03-05T09:00:00", "2026-03-06T09:00:00"):
        w.usage(1, day, "feature_use", feature_name="Reports", user_ref="u1")  # two events on two days: adopted (names are matched case-insensitively)
    w.usage(1, "2026-03-07T09:00:00", "feature_use", feature_name="dashboards", user_ref="u1")
    w.usage(1, "2026-03-08T09:00:00", "feature_use", feature_name="automation", user_ref="u1")   # used, but not eligible: must not count
    w.usage(1, "2026-01-10T09:00:00", "feature_use", feature_name="legacy", user_ref="u1")
    w.usage(1, "2026-04-01T09:00:00", "feature_use", feature_name="collaboration", user_ref="u1")  # at T: not before T
    return w


@pytest.mark.req("REQ-SIG-02", "REQ-ML-02")
def test_adoption_rate_has_an_explicit_denominator_and_follows_the_catalogue_rules():
    v = vector(adoption_world())
    # eligible at T: reports, dashboards, collaboration (released, in plan, telemetry seen). Not: automation (plan), legacy (retired), api_access (never seen).
    assert v["feature_adoption_rate_30d"] == pytest.approx(2 / 3) and v["feature_adoption_rate_90d"] == pytest.approx(2 / 3)
    assert v["core_feature_adoption_rate_90d"] == pytest.approx(1.0) and v["lifetime_feature_adoption_rate"] == pytest.approx(2 / 3)
    assert v["feature_adoption_delta_30d_prev30d"] == pytest.approx(2 / 3), "nothing was adopted in the 30 days before the last 30"
    assert v["distinct_features_30d"] == 3, "the raw breadth counts every name in telemetry; the governed rate does not"
    # one day later the event at T counts: collaboration is adopted as well
    assert vector(adoption_world(), date(2026, 4, 2))["feature_adoption_rate_30d"] == pytest.approx(1.0)
    # before collaboration was released it is not in the denominator: 2 of 2
    assert vector(adoption_world(), date(2026, 3, 10))["feature_adoption_rate_30d"] == pytest.approx(1.0)
    # the adoption rule: one event on one day is not enough for 'reports' (needs two events on two days)
    early = vector(adoption_world(), date(2026, 3, 6))
    assert early["feature_adoption_rate_30d"] == pytest.approx(0.0), "reports has one event so far and dashboards none"
    # no approved catalogue: the rate is unknown, never zero
    bare = base_world()
    bare.usage(1, "2026-03-05T09:00:00", "feature_use", feature_name="reports")
    assert all(missing(vector(bare)[name]) for name in ("feature_adoption_rate_30d", "feature_adoption_rate_90d", "core_feature_adoption_rate_90d",
                                                        "lifetime_feature_adoption_rate", "feature_adoption_delta_30d_prev30d"))  # fmt: skip
    # a catalogue with nothing this customer could use: no denominator, so no rate
    none = base_world(tier="basic")
    none.feature("automation", plan_tiers=("enterprise",))
    none.usage(1, "2026-03-05T09:00:00", "feature_use", feature_name="automation")
    assert missing(vector(none)["feature_adoption_rate_30d"])
    # a customer who used nothing has a rate of zero (the denominator exists): that is a fact, not missing data
    idle = base_world()
    idle.feature("reports")
    assert vector(idle)["feature_adoption_rate_30d"] == 0.0


@pytest.mark.req("REQ-SIG-02")
def test_catalogue_entries_are_versioned_and_count_only_after_a_second_person_approved_them(empty):
    tid = empty.tenant()
    author, reviewer = empty.user(tid, "data_scientist"), empty.user(tid, "approver")
    payload = {"feature_key": "reports", "name": "Reports", "event_mapping": [{"event_type": "feature_use", "feature_name": "Reports"}],
               "adoption_rule": {"min_events": 3, "min_days": 2}, "is_core": True}  # fmt: skip
    with session_scope() as s:
        draft = adoption.create_feature(s, author, payload)
        assert (draft.version, draft.status) == (1, "draft") and draft.event_mapping == [{"event_type": "feature_use", "feature_name": "reports"}]
        assert timeline.approved_catalog(s, tid) == [], "a draft has no effect"
        with pytest.raises(Conflict):
            adoption.review(s, reviewer, draft.id, approve=True)
        adoption.submit(s, author, draft.id)
        with pytest.raises(Forbidden) as four_eyes:
            adoption.review(s, author, draft.id, approve=True)
        assert four_eyes.value.code == "self_approval_forbidden"
        adoption.review(s, reviewer, draft.id, approve=True, note="ok")
        assert [f.feature_key for f in timeline.approved_catalog(s, tid)] == ["reports"]
        with pytest.raises(Conflict):
            adoption.start_run(s, author)  # there is a catalogue, but no data yet
        # a second feature may not claim the same telemetry
        clash = adoption.create_feature(s, author, {"feature_key": "reporting", "name": "Reporting", "event_mapping": [{"feature_name": "reports"}]})
        adoption.submit(s, author, clash.id)
        with pytest.raises(Conflict) as conflict:
            adoption.review(s, reviewer, clash.id, approve=True)
        assert conflict.value.code == "mapping_conflict" and conflict.value.details[0]["claimed_by"] == ["reporting", "reports"]
        # a new version replaces the old one once approved; until then the old one stays in force
        v2 = adoption.create_feature(s, author, {**payload, "adoption_rule": {"min_events": 1, "min_days": 1}})
        assert v2.version == 2 and timeline.approved_catalog(s, tid)[0].version == 1
        adoption.submit(s, author, v2.id)
        adoption.review(s, reviewer, v2.id, approve=True)
        in_force = timeline.approved_catalog(s, tid)
        assert [(f.version, f.adoption_rule) for f in in_force] == [(2, {"min_events": 1, "min_days": 1})]
        adoption.set_active(s, reviewer, v2.id, False)
        assert timeline.approved_catalog(s, tid) == [], "a switched-off entry is out of every denominator"
        listing = adoption.list_catalog(s, tid)
        assert listing["total"] == 3 and listing["in_force"] == 0
    for bad, field in (({**payload, "feature_key": "Bad Key"}, "feature_key"), ({**payload, "event_mapping": []}, "event_mapping"),
                       ({**payload, "adoption_rule": {"min_events": 0}}, "adoption_rule"), ({**payload, "event_mapping": [{"event_type": "page_view", "feature_name": "x"}]}, "event_mapping"),
                       ({**payload, "release_date": "2026-05-01", "retired_date": "2026-01-01"}, "retired_date"), ({**payload, "eligibility": {"plan_tiers": []}}, "eligibility")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed) as invalid:
            adoption.create_feature(s, author, bad)
        assert invalid.value.details["field"] == field


@pytest.mark.req("REQ-SIG-02")
def test_adoption_report_agrees_with_the_feature_vectors_and_names_what_it_cannot_measure(demo):
    with read_session() as s:
        run = adoption.latest_run(s, demo.tenant_id)
        result = run.result
        facts = dict(s.execute(select(AdoptionFact.state, func.count()).where(AdoptionFact.run_id == run.id).group_by(AdoptionFact.state)).all())
        frames = timeline.load_frames(s, demo.tenant_id)
    assert run.as_of_date == date(2026, 11, 1) and run.window_days == 30 and len(run.catalog_hash) == 64
    by_key = {f["feature_key"]: f for f in result["features"]}
    assert set(by_key) == {"dashboards", "reports", "integrations", "automation", "exports", "collaboration", "workflows", "api_access"}
    # the entry whose telemetry never arrives is in nobody's denominator, and says so
    assert by_key["api_access"]["mapping_state"] == "never_seen_in_telemetry" and by_key["api_access"]["eligible_customers"] == 0
    assert facts["invalid_mapping"] == result["customers_measured"] + result["customers_without_telemetry"]
    # plan-gated features have a smaller denominator than features every plan includes
    assert 0 < by_key["automation"]["eligible_customers"] < by_key["dashboards"]["eligible_customers"] == result["customers_measured"]
    assert all(0 <= f["adoption_rate"] <= 1 and f["adopted_customers"] <= f["eligible_customers"] for f in by_key.values() if f["mapping_state"] == "ok")
    assert result["unmapped_telemetry"] == [{"event_type": "feature_use", "feature_name": "legacy_export", "events": result["unmapped_events"]}]
    assert {s["segment"].split(":")[0] for s in result["segments"]} == {"plan_tier", "tenure"}
    # the same arithmetic feeds the model: the report's mean equals the mean of the 30-day feature
    vectors = fe.compute_features(frames, [run.as_of_date])
    assert len(vectors) == result["customers_measured"] + result["customers_without_telemetry"] + result["customers_without_eligible_features"]
    measured = vectors[vectors["customer_id"].isin(frames["usage"]["customer_id"].unique())]["feature_adoption_rate_30d"].dropna()
    assert result["mean_adoption_rate"] == pytest.approx(float(measured.mean()), abs=1e-4)
    assert sum(facts.get(k, 0) for k in ("adopted", "not_adopted")) == sum(f["eligible_customers"] for f in by_key.values())
    # measuring an earlier date gives a second point of the trend, and the as-of rule holds (collaboration was released later than the first data)
    with session_scope() as s:
        earlier, job = adoption.start_run(s, demo.principal("admin"), as_of=date(2026, 3, 1), window_days=30)
        earlier_id = earlier.id
    demo.drain()
    with read_session() as s:
        trend = adoption.trend(s, demo.tenant_id)
        early = s.get(AdoptionRun, earlier_id).result
    assert [p["as_of_date"] for p in trend] == ["2026-03-01", "2026-11-01"] and job.job_type == "adoption.compute"
    late_day = date.fromisoformat(demo.summary["expected"]["late_feature_day"])
    released = {f["feature_key"]: f["eligible_customers"] for f in early["features"]}
    assert (released["collaboration"] > 0) == (late_day < date(2026, 3, 1)), "a feature is in the denominator only after its release"


@pytest.mark.req("REQ-SIG-02")
def test_adoption_api_lists_facts_and_refuses_to_measure_without_a_catalogue(demo, empty):
    activate(demo.db_path, demo.data_dir)
    with demo.client() as c:
        viewer, scientist = demo.login(c, "viewer"), demo.login(c, "data_scientist")
        overview = c.get(f"{API}/signals/adoption", headers=viewer).json()
        run_id = overview["latest"]["id"]
        facts = c.get(f"{API}/signals/adoption/runs/{run_id}/facts", headers=viewer, params={"feature_key": "reports", "state": "adopted", "page_size": 3}).json()
        assert facts["total"] > 10 and all(f["feature_key"] == "reports" and f["state"] == "adopted" and f["events"] >= 3 and f["active_days"] >= 2 for f in facts["items"])
        catalog = c.get(f"{API}/signals/catalog", headers=viewer).json()
        assert catalog["in_force"] == 8 and catalog["conflicts"] == []
        unmapped = [t for t in catalog["telemetry"] if t["mapped_to"] is None]
        assert [t["feature_name"] for t in unmapped] == ["legacy_export"]
        assert c.post(f"{API}/signals/adoption/runs", headers=viewer, json={}).status_code == 403
        started = c.post(f"{API}/signals/adoption/runs", headers=scientist, json={"window_days": 90})
        assert started.status_code == 202 and started.json()["run"]["window_days"] == 90
        assert c.post(f"{API}/signals/adoption/runs", headers=scientist, json={"window_days": 0}).status_code == 422


# ============================================================================= identity and active users
def usage_frame(rows: list[tuple]) -> pd.DataFrame:
    frame = pd.DataFrame(rows, columns=["customer_id", "user_ref", "occurred_at"])
    frame["occurred_at"] = pd.to_datetime(frame["occurred_at"]).astype("datetime64[ns]")
    return frame


def links_frame(rows: list[dict]) -> pd.DataFrame:
    w = World()
    for row in rows:
        w.link(**row)
    return w._signal_frames()["identity"]


@pytest.mark.req("REQ-SIG-03")
def test_identifiers_resolve_to_people_by_explicit_rules():
    usage = usage_frame([(1, "u1", "2026-03-01"), (1, " U1 ", "2026-03-01"), (1, "anna@x.example", "2026-03-01"), (1, None, "2026-03-01"), (1, "", "2026-03-01"),
                         (2, "u1", "2026-03-01"), (1, "bot-7", "2026-03-01"), (1, "staff@vendor.example", "2026-03-01"), (1, "q1", "2026-03-01"),
                         (1, "old", "2026-01-15"), (1, "old", "2026-03-01")])  # fmt: skip
    # without links: an identifier is its own person; spelling variants fold together; missing stays missing
    plain = fe.resolve_users(usage, None)
    assert list(plain[:6]) == ["u1", "u1", "anna@x.example", None, None, "u1"] or (plain[0] == plain[1] == plain[5] == "u1" and pd.isna(plain[3]) and pd.isna(plain[4]))
    # exclusion patterns: staff and automation count for nobody
    excluded = fe.resolve_users(usage, None, ["bot-*", "*@vendor.example"])
    assert pd.isna(excluded[6]) and pd.isna(excluded[7]) and excluded[0] == "u1"
    links = links_frame([
        {"external_user_id": "u1", "user_key": "person-A", "customer_id": 1},
        {"external_user_id": "anna@x.example", "user_key": "person-A"},                       # the same person under a second identifier
        {"external_user_id": "u1", "user_key": "person-B", "customer_id": 2},                 # "u1" of another customer is somebody else
        {"external_user_id": "q1", "user_key": "person-Q", "customer_id": 1, "status": "quarantined"},
        {"external_user_id": "old", "user_key": "person-early", "customer_id": 1, "valid_to": "2026-02-01"},
        {"external_user_id": "old", "user_key": "person-late", "customer_id": 1, "valid_from": "2026-02-01"}])
    resolved = fe.resolve_users(usage, links)
    assert resolved[0] == resolved[1] == resolved[2] == "person-A" and resolved[5] == "person-B"
    assert pd.isna(resolved[8]), "a quarantined link counts for nobody until somebody reviewed it"
    assert resolved[9] == "person-early" and resolved[10] == "person-late", "a link applies only during its validity"
    assert resolved[6] == "bot-7", "an identifier without a link still counts, as itself"
    # the join never pairs one customer's identifier with another customer's link (this once multiplied rows by the number of customers)
    many = usage_frame([(c, "u1", "2026-03-01") for c in range(1, 201)])
    wide = links_frame([{"external_user_id": "u1", "user_key": f"p{c}", "customer_id": c} for c in range(1, 201)])
    assert list(fe.resolve_users(many, wide)) == [f"p{c}" for c in range(1, 201)]
    assert fe.normalise_ref("  Anna@X.Example ") == "anna@x.example" and fe.normalise_ref("  ") is None and fe.normalise_ref(None) is None


@pytest.mark.req("REQ-SIG-03", "REQ-ML-02")
def test_active_user_features_count_people_per_day_and_are_unknown_when_identities_are_missing():
    w = base_world(seats=10)
    for day in range(2, 32):  # 30 days before T (March 2 .. 31): u1 every day, u2 on ten days, anna twice under two identifiers on one day
        stamp = f"2026-03-{day:02d}T10:00:00"
        w.usage(1, stamp, "login", user_ref="u1")
        if day <= 11:
            w.usage(1, stamp, "login", user_ref="u2")
    w.usage(1, "2026-03-20T11:00:00", "feature_use", feature_name="reports", user_ref="anna@x.example")
    w.usage(1, "2026-03-20T12:00:00", "feature_use", feature_name="reports", user_ref="ANNA")
    v = vector(w)
    assert v["monthly_active_users_30d"] == 4 and v["avg_daily_active_users_30d"] == pytest.approx((30 + 10 + 2) / 30)
    assert v["dau_mau_ratio_30d"] == pytest.approx((42 / 30) / 4) and v["active_user_seat_share_30d"] == pytest.approx(0.4)
    assert v["avg_daily_active_users_7d"] == pytest.approx(1.0) and v["dau_delta_7d_30d_pct"] == pytest.approx(1.0 / (42 / 30) - 1)
    # a link says the two identifiers are one person: one fewer person, one fewer user-day
    w.link("anna@x.example", "anna", customer_id=1)
    w.link("anna", "anna", customer_id=1)
    merged = vector(w)
    assert merged["monthly_active_users_30d"] == 3 and merged["avg_daily_active_users_30d"] == pytest.approx(41 / 30)
    # the definition excludes u2: those events count for nobody
    w.activity = {"exclude_user_patterns": ["u2"]}
    assert vector(w)["monthly_active_users_30d"] == 2
    # only logins count as activity: the feature-use events of anna no longer make her active
    w.activity = {"active_event_types": ["login"]}
    assert vector(w)["monthly_active_users_30d"] == 2
    # time zone: an event at 23:30 UTC on March 31 belongs to April 1 in Asia/Kolkata and so to no day before T's local date boundary...
    tz = base_world()
    tz.usage(1, "2026-03-30T23:30:00", "login", user_ref="u1")
    tz.usage(1, "2026-03-31T01:00:00", "login", user_ref="u1")
    assert vector(tz)["avg_daily_active_users_30d"] == pytest.approx(2 / 30), "two UTC days"
    tz.activity = {"timezone": "Asia/Kolkata"}
    assert vector(tz)["avg_daily_active_users_30d"] == pytest.approx(1 / 30), "both events fall on March 31 in India: one user-day"
    # too few events name a user: the counts are unknown, not small
    sparse = base_world()
    for day in range(2, 12):
        sparse.usage(1, f"2026-03-{day:02d}T10:00:00", "login", user_ref="u1" if day < 5 else None)
    unknown = vector(sparse)
    assert all(missing(unknown[n]) for n in ("avg_daily_active_users_30d", "avg_daily_active_users_7d", "monthly_active_users_30d", "dau_mau_ratio_30d",
                                             "active_user_seat_share_30d", "dau_delta_7d_30d_pct"))  # fmt: skip
    sparse.activity = {"min_identified_share": 0.2}
    assert vector(sparse)["monthly_active_users_30d"] == 1, "3 of 10 events name a user: known once the threshold allows it"
    silent = base_world()
    silent.usage(1, "2026-03-10T10:00:00", "login")
    assert missing(vector(silent)["avg_daily_active_users_30d"]) and vector(silent)["logins_30d"] == 1


@pytest.mark.req("REQ-SIG-03")
def test_reconciliation_builds_links_proposes_duplicates_and_reports_what_is_missing(demo):
    with read_session() as s:
        overview = identity.overview(s, demo.tenant_id)
        recon = overview["reconciliation"]["result"]
        open_candidates = s.execute(select(func.count()).select_from(IdentityMergeCandidate).where(IdentityMergeCandidate.status == "open")).scalar_one()
        emails = s.execute(select(IdentityLink).where(IdentityLink.match_rule == "email").limit(1)).scalar_one()
        plain = s.execute(select(IdentityLink).where(IdentityLink.match_rule == "source_id").limit(1)).scalar_one()
    totals = recon["totals"]
    assert overview["definition_is_default"] is False and overview["definition"]["exclude_user_patterns"] == ["*@synthetic-vendor.example"]
    assert overview["links_by_status"] == {"active": sum(overview["active_links_by_rule"].values())} and set(overview["active_links_by_rule"]) == {"email", "source_id"}
    assert emails.user_key == identity.user_key(demo.tenant_id, emails.external_user_id, None), "an e-mail address names one person everywhere"
    assert plain.user_key == identity.user_key(demo.tenant_id, plain.external_user_id, plain.customer_id) != identity.user_key(demo.tenant_id, plain.external_user_id, plain.customer_id + 1)
    assert recon["links"]["raw_variants_folded"] > 0 and recon["links"]["non_email_identifiers_under_several_customers"] > 0
    assert 0 < totals["events_without_user"] < totals["events"] and totals["identified_event_share"] == pytest.approx(1 - totals["events_without_user"] / totals["events"], abs=1e-4)
    assert totals["excluded_identifiers"] == 3 and totals["excluded_events"] > 0 and totals["customers_without_any_user"] > 0
    assert totals["customers_below_identified_threshold"] >= totals["customers_without_any_user"]
    assert open_candidates == overview["open_merge_candidates"] > 0
    days = recon["days"]
    assert len(days) == recon["window_days"] == 90 and all(d["dau"] <= d["wau"] <= d["mau"] for d in days) and days[-1]["day"] == "2026-10-31"
    assert all(d["stickiness"] == pytest.approx(d["dau"] / d["mau"], abs=1e-4) for d in days if d["mau"])
    # reconciling again creates nothing new
    with session_scope() as s:
        again = identity.ensure_links(s, demo.tenant_id)
    assert again["links_created"] == 0 and again["merge_candidates_proposed"] == 0


@pytest.mark.req("REQ-SIG-03")
def test_merges_are_decided_by_people_can_be_undone_and_change_the_count(demo):
    admin = demo.principal("approver")
    before = identity.activity_series(demo.tenant_id, 30)["totals"]["people"]
    with session_scope() as s:
        candidate = s.execute(select(IdentityMergeCandidate).where(IdentityMergeCandidate.status == "open").order_by(IdentityMergeCandidate.id).limit(1)).scalar_one()
        keys = (candidate.user_key_a, candidate.user_key_b)
        assert candidate.reason == "email_local_part_matches_id" and len(candidate.evidence["identifiers"]) == 2
        identity.review_candidate(s, admin, candidate.id, merge_them=True, note="same person, confirmed by the customer")
        with pytest.raises(Conflict):
            identity.review_candidate(s, admin, candidate.id, merge_them=False)
        merged = s.execute(select(IdentityLink).where(IdentityLink.user_key == keys[1], IdentityLink.status == "merged")).scalars().all()
        replacement = s.execute(select(IdentityLink).where(IdentityLink.user_key == keys[0], IdentityLink.match_rule == "candidate_merge")).scalars().all()
        assert merged and len(replacement) == len(merged) and all(m.merged_into == keys[0] for m in merged)
    after = identity.activity_series(demo.tenant_id, 30)["totals"]["people"]
    assert after <= before, "two identifiers of one person no longer count twice"
    with session_scope() as s:
        undone = identity.unmerge(s, admin, keys[1], note="wrong match")
        assert undone["restored"] == len(merged)
        assert s.execute(select(func.count()).select_from(IdentityLink).where(IdentityLink.user_key == keys[1], IdentityLink.status == "active")).scalar_one() == len(merged)
    assert identity.activity_series(demo.tenant_id, 30)["totals"]["people"] == before
    # rejecting a candidate closes it; quarantining a link takes its events out of every count
    with session_scope() as s:
        other = s.execute(select(IdentityMergeCandidate).where(IdentityMergeCandidate.status == "open").limit(1)).scalar_one()
        assert identity.review_candidate(s, admin, other.id, merge_them=False).status == "rejected"
        busy = s.execute(select(IdentityLink).where(IdentityLink.status == "active", IdentityLink.match_rule == "source_id").limit(1)).scalar_one()
        identity.set_status(s, admin, busy.id, "quarantined", "looks like a shared login")
        with pytest.raises(ValidationFailed):
            identity.set_status(s, admin, busy.id, "merged")
    quarantined = identity.activity_series(demo.tenant_id, 30)["totals"]
    assert quarantined["people"] <= before and quarantined["events_counting_for_nobody_after_review"] >= 0


@pytest.mark.req("REQ-SIG-03")
def test_an_imported_mapping_makes_identifiers_one_person_and_rejects_rows_it_cannot_place(demo):
    admin = demo.principal("admin")
    with read_session() as s:
        customer = s.execute(select(Customer).where(Customer.tenant_id == demo.tenant_id).order_by(Customer.id).limit(1)).scalar_one()
    rows = [{"external_user_id": "U01", "person_id": "emp-1", "customer_external_id": customer.external_id},
            {"external_user_id": "u02", "person_id": "EMP-1", "customer_external_id": customer.external_id},
            {"external_user_id": "anna@elsewhere.example", "person_id": "emp-1"},
            {"external_user_id": "u03", "person_id": "emp-2"},                                  # not an e-mail and no customer
            {"external_user_id": "u04", "person_id": "emp-3", "customer_external_id": "NOPE"},
            {"external_user_id": "", "person_id": "emp-4"},
            {"external_user_id": "u05", "person_id": "emp-5", "customer_external_id": customer.external_id, "valid_from": "2026-05-01", "valid_to": "2026-01-01"}]
    with session_scope() as s:
        result = identity.import_links(s, admin, rows)
        links = s.execute(select(IdentityLink).where(IdentityLink.match_rule == "import", IdentityLink.status == "active")).scalars().all()
    assert (result["created"], result["rejected_rows"]) == (3, 4) and [p["row"] for p in result["problems"]] == [4, 5, 6, 7]
    assert len({link.user_key for link in links}) == 1 and links[0].user_key == identity.person_key(demo.tenant_id, "emp-1"), "person ids are compared without regard to case"
    with demo.client() as c:
        viewer = demo.login(c, "viewer")
        listed = c.get(f"{API}/signals/identity/links", headers=viewer, params={"user_key": links[0].user_key}).json()
        assert listed["total"] == 3 and {row["external_user_id"] for row in listed["items"]} == {"u01", "u02", "anna@elsewhere.example"}
        assert c.post(f"{API}/signals/identity/links/import", headers=viewer, json={"rows": rows}).status_code == 403
        page = c.get(f"{API}/signals/identity", headers=viewer).json()
        assert page["people"] > 0 and page["candidates"] and "result" not in page["runs"][0]


@pytest.mark.req("REQ-SIG-03")
def test_the_activity_definition_is_a_governed_policy(empty):
    tid = empty.tenant()
    author, reviewer = empty.user(tid, "admin"), empty.user(tid, "approver")
    with session_scope() as s:
        assert timeline.activity_definition(s, tid) is None, "without an approved definition the built-in default applies"
        policy = policies.create(s, author, kind="activity_definition", name="default", payload={"timezone": "Europe/Berlin", "exclude_user_patterns": ["*@vendor.example"]})
        assert timeline.activity_definition(s, tid) is None
        policies.submit(s, author, policy.id)
        policies.review(s, reviewer, policy.id, approve=True)
        assert timeline.activity_definition(s, tid)["timezone"] == "Europe/Berlin"
    for bad in ({"timezone": "Mars/Olympus"}, {"active_event_types": []}, {"min_identified_share": 2}, {"exclude_user_patterns": [" "]}, {"unknown": 1}):
        with pytest.raises(ValidationFailed):
            policies.validate_payload("activity_definition", bad)


# ============================================================================= attribute history
def moment(text: str) -> datetime:
    return datetime.fromisoformat(text).replace(tzinfo=UTC)


@pytest.mark.req("REQ-SIG-04")
def test_attribute_history_keeps_what_was_true_and_what_was_believed(empty):
    tid = empty.tenant()
    admin = empty.user(tid, "admin")
    with session_scope() as s:
        customer = Customer(tenant_id=tid, external_id="C1", name="One", industry="retail", company_size="smb", employee_count=40, region="emea", country="DE")
        s.add(customer)
        s.flush()
        cid = customer.id
        created = attributes.ensure_initial(s, tid)
        assert created == {"customers": 1, "rows": len(attributes.TRACKED), "replayed_changes": 0} and attributes.ensure_initial(s, tid)["customers"] == 0
        first = attributes.current_rows(s, tid, cid, "company_size")
        assert [(r.value, r.basis, r.valid_from, r.valid_to) for r in first] == [("smb", "initial", None, None)]
        assert attributes.as_text(40.0) == "40" and attributes.as_text("") is None
        # a change with an effective date in the past: the open period closes there, and past dates after it see the new value
        attributes.apply(s, tid, cid, "company_size", "mid_market", valid_from=moment("2026-03-01"), basis="effective", now=moment("2026-06-01"))
        assert [(r.value, r.basis) for r in attributes.current_rows(s, tid, cid, "company_size")] == [("smb", "initial"), ("mid_market", "effective")]
        assert attributes.value_at(s, tid, cid, "company_size", moment("2026-02-01")) == "smb"
        assert attributes.value_at(s, tid, cid, "company_size", moment("2026-04-01")) == "mid_market"
        assert attributes.apply(s, tid, cid, "company_size", "mid_market", valid_from=moment("2026-07-01"), basis="observed") is None, "nothing changes when the value is the same"
    with session_scope() as s:
        # a correction of the past (recorded now): what was believed on a past date stays answerable
        fix = attributes.record(s, admin, cid, attribute="industry", value="software", valid_from=moment("2025-01-01"), basis="correction", note="was mis-keyed at onboarding")
        fixed_at = fix.recorded_at
        rows = s.execute(select(CustomerAttributeHistory).where(CustomerAttributeHistory.customer_id == cid, CustomerAttributeHistory.attribute == "industry")).scalars().all()
        assert sorted((r.value, r.basis, r.superseded_at is not None) for r in rows) == [("retail", "initial", False), ("retail", "initial", True), ("software", "correction", False)]
        past = moment("2026-01-15")
        assert attributes.value_at(s, tid, cid, "industry", past) == "retail", "as known then"
        assert attributes.value_at(s, tid, cid, "industry", past, as_known=False) == "software", "as known today"
        assert attributes.value_at(s, tid, cid, "industry", fixed_at + timedelta(days=1)) == "software"
        # a backfill is declared history: it holds for past dates too, and only inside its period
        attributes.record(s, admin, cid, attribute="region", value="apac", valid_from=moment("2025-06-01"), valid_to=moment("2025-12-01"), basis="backfill", note="moved for half a year")
        assert [attributes.value_at(s, tid, cid, "region", moment(d)) for d in ("2025-03-01", "2025-09-01", "2026-02-01")] == ["emea", "apac", "emea"]
        with pytest.raises(ValidationFailed):
            attributes.record(s, admin, cid, attribute="region", value="apac", valid_from=moment("2025-06-01"), valid_to=moment("2025-12-01"), basis="backfill", note="again")
        for bad in ({"attribute": "name"}, {"basis": "observed"}, {"note": " "}, {"valid_from": moment("2026-01-01"), "valid_to": moment("2025-01-01")}):
            with pytest.raises(ValidationFailed):
                attributes.record(s, admin, cid, **{"attribute": "region", "value": "amer", "valid_from": None, "basis": "correction", "note": "x", **bad})
        view = attributes.timeline(s, tid, cid)
        assert view["current"]["company_size"] == "smb" or view["current"]["company_size"] == "mid_market"
        assert sum(1 for p in view["periods"] if not p["is_current"]) >= 2 and attributes.summary(s, tid)["superseded_rows"] >= 2


@pytest.mark.req("REQ-SIG-04", "REQ-ML-02")
def test_customer_attributes_in_a_feature_vector_are_the_ones_that_held_at_T():
    w = base_world()
    # today's row says enterprise / 900 employees; the history says when that became true
    w.rows["customers"][0].update(company_size="enterprise", employee_count=900, industry="software")
    w.attribute(1, "company_size", "smb")                                                       # id 1: initial, superseded below by a re-cut copy
    w.signals["attributes"][0].update(valid_to="2026-03-01")
    w.attribute(1, "company_size", "enterprise", valid_from="2026-03-01", basis="effective")
    w.attribute(1, "employee_count", "100", valid_to="2026-05-01")
    w.attribute(1, "employee_count", "900", valid_from="2026-05-01", basis="observed", recorded_at="2026-05-01")
    w.attribute(1, "industry", "retail", superseded_at="2026-06-01")                            # believed until the correction of June 1
    w.attribute(1, "industry", "software", basis="correction", recorded_at="2026-06-01")
    feb, apr, jul = (vector(w, d) for d in (date(2026, 2, 1), date(2026, 4, 1), date(2026, 7, 1)))
    assert (feb["company_size"], apr["company_size"], jul["company_size"]) == ("smb", "enterprise", "enterprise")
    assert (feb["employee_count"], apr["employee_count"], jul["employee_count"]) == (100, 100, 900)
    assert (feb["industry"], apr["industry"], jul["industry"]) == ("retail", "retail", "software"), "a correction applies from when it was recorded"
    assert apr["region"] == "emea", "an attribute without history falls back to today's row ..."
    out = fe.compute_features(w.frames(), [T])
    assert out.attrs["row_fallback"]["attributes"] == 2, "... and the fallback is counted (region and acquisition channel)"
    # without any history frame the engine behaves as release 1.0 did: today's row
    plain = base_world()
    plain.rows["customers"][0].update(company_size="enterprise")
    assert vector(plain)["company_size"] == "enterprise" and fe.compute_features(plain.frames(), [T]).attrs["row_fallback"]["attributes"] == 0
    assert {f.name for f in fe.CATALOG if f.pit == "history"} == set(fe.HISTORY_ATTRIBUTES)


@pytest.mark.req("REQ-SIG-04")
def test_imports_and_corrections_write_attribute_history_and_an_upgrade_replays_the_change_log(demo):
    expected = demo.summary["expected"]["attribute_changes"]
    with read_session() as s:
        summary = attributes.summary(s, demo.tenant_id)
        changed = s.execute(select(CustomerAttributeHistory).where(CustomerAttributeHistory.basis == "effective", CustomerAttributeHistory.attribute == "company_size")
                            .order_by(CustomerAttributeHistory.id).limit(1)).scalar_one()  # fmt: skip
        customer = s.get(Customer, changed.customer_id)
        before = attributes.value_at(s, demo.tenant_id, customer.id, "company_size", changed.valid_from - timedelta(days=1))
        after = attributes.value_at(s, demo.tenant_id, customer.id, "company_size", changed.valid_from + timedelta(days=1))
    assert expected > 0 and summary["customers_with_history"] == summary["customers"] == 300
    assert summary["periods_by_basis"]["initial"] == 300 * len(attributes.TRACKED) and summary["customers_with_changes"]["company_size"] == expected
    assert summary["periods_by_basis"]["effective"] == 2 * expected, "company size and head count changed, each with the date from the file"
    assert customer.company_size == changed.value == after != before and customer.attributes_effective_at == changed.valid_from
    # an approved data-quality correction of a tracked attribute opens a new period (basis: correction)
    from churn_platform.services import quality

    with session_scope() as s:
        target = s.execute(select(Customer).where(Customer.tenant_id == demo.tenant_id, Customer.industry.is_not(None)).order_by(Customer.id).limit(1)).scalar_one()
        proposal = quality.propose_correction(s, demo.principal("admin"), entity_type="customers", entity_id=target.id, field="industry", new_value="aerospace",
                                              reason="confirmed with the customer")  # fmt: skip
        quality.review_correction(s, demo.principal("approver"), proposal.id, approve=True, note="ok")
        target_id, old = target.id, proposal.old_value
    with read_session() as s:
        periods = attributes.current_rows(s, demo.tenant_id, target_id, "industry")
        assert [(p.value, p.basis) for p in periods] == [(old, "initial"), ("aerospace", "correction")] and periods[0].valid_to == periods[1].valid_from
    # an installation upgraded from 1.0 has a change log and no history: the history is rebuilt from it
    with session_scope() as s:
        s.execute(CustomerAttributeHistory.__table__.delete())
        logged = s.execute(select(func.count()).select_from(EntityHistory).where(EntityHistory.entity_type == "customers")).scalar_one()
        rebuilt = attributes.ensure_initial(s, demo.tenant_id)
        periods = attributes.current_rows(s, demo.tenant_id, target_id, "industry")
        assert logged >= expected + 1 and rebuilt["customers"] == 300 and rebuilt["replayed_changes"] == 2 * expected + 1
        assert [(p.value, p.basis) for p in periods] == [(old, "initial"), ("aerospace", "correction")]
        replayed = attributes.current_rows(s, demo.tenant_id, customer.id, "company_size")
        # the change log knows when a change was seen, not when it took effect: replayed changes are 'observed'
        assert [p.basis for p in replayed] == ["initial", "observed"] and replayed[1].value == customer.company_size


@pytest.mark.req("REQ-SIG-04")
def test_attribute_history_api_shows_timelines_and_needs_the_approval_permission_to_rewrite(demo):
    with read_session() as s:
        row = s.execute(select(CustomerAttributeHistory).where(CustomerAttributeHistory.basis == "effective").limit(1)).scalar_one()
    with demo.client() as c:
        viewer, scientist, approver = demo.login(c, "viewer"), demo.login(c, "data_scientist"), demo.login(c, "approver")
        summary = c.get(f"{API}/signals/attributes", headers=viewer).json()
        assert summary["tracked"] == list(attributes.TRACKED) and summary["recent_changes"] and "assumption" in summary["note"]
        at = (row.valid_from - timedelta(days=2)).isoformat()
        view = c.get(f"{API}/signals/attributes/customers/{row.customer_id}", headers=viewer, params={"at": at}).json()
        assert view["at"]["as_known_then"][row.attribute] != row.value and len(view["periods"]) >= len(attributes.TRACKED) + 2
        body = {"attribute": "region", "value": "amer", "valid_from": "2025-01-01T00:00:00Z", "basis": "backfill", "note": "contract was signed in the US"}
        assert c.post(f"{API}/signals/attributes/customers/{row.customer_id}", headers=scientist, json=body).status_code == 403
        created = c.post(f"{API}/signals/attributes/customers/{row.customer_id}", headers=approver, json=body)
        assert created.status_code == 201 and created.json()["basis"] == "backfill"
        assert c.post(f"{API}/signals/attributes/customers/987654321", headers=approver, json=body).status_code == 404
        assert c.post(f"{API}/signals/attributes/customers/{row.customer_id}", headers=approver, json={**body, "note": ""}).status_code == 422


# ============================================================================= the signals together
@pytest.mark.req("REQ-SIG-01", "REQ-SIG-02", "REQ-SIG-03", "REQ-SIG-04", "REQ-ML-02")
def test_signals_dated_at_or_after_T_never_move_a_feature_vector(ro):
    as_of = date(2026, 7, 1)
    t0 = pd.Timestamp(as_of)
    with read_session() as s:
        frames = timeline.load_frames(s, ro.tenant_id)
    baseline = fe.compute_features(frames, [as_of])
    assert baseline["feature_adoption_rate_30d"].notna().sum() > 100 and baseline["monthly_active_users_30d"].notna().sum() > 100
    assert baseline["sentiment_avg_score_90d"].notna().sum() > 20
    # what the future would add: a much worse score for every later ticket, an attribute change dated after T, usage after T
    poisoned = dict(frames)
    later_tickets = set(frames["support"].loc[frames["support"]["opened_at"] >= t0, "id"])
    sentiment_frame = frames["sentiment"].copy()
    sentiment_frame.loc[sentiment_frame["interaction_id"].isin(later_tickets), ["label", "score", "state"]] = ["negative", -1.0, "ok"]
    poisoned["sentiment"] = sentiment_frame
    history = frames["attributes"].copy()
    extra = history[history["valid_from"].isna()].head(50).assign(value="POISON", valid_from=t0, basis="effective", id=lambda d: d["id"] + 10_000_000)
    poisoned["attributes"] = pd.concat([history, extra], ignore_index=True)
    usage = frames["usage"]
    future = usage[usage["occurred_at"] >= t0].assign(user_ref="someone-new", feature_name="api_call")
    poisoned["usage"] = pd.concat([usage, future], ignore_index=True)
    after = fe.compute_features(poisoned, [as_of])
    pd.testing.assert_frame_equal(baseline.reset_index(drop=True), after.reset_index(drop=True), check_exact=True, check_dtype=False)
    # and removing everything dated at or after T changes nothing either
    trimmed = dict(frames)
    trimmed["usage"] = usage[usage["occurred_at"] < t0]
    trimmed["support"] = frames["support"][frames["support"]["opened_at"] < t0]
    trimmed["sentiment"] = frames["sentiment"][~frames["sentiment"]["interaction_id"].isin(later_tickets)]
    trimmed["attributes"] = history[history["valid_from"].isna() | (history["valid_from"] < t0)]
    partial = fe.compute_features(trimmed, [as_of])
    signal_columns = [c for c in fe.FEATURE_NAMES if any(k in c for k in ("sentiment", "negative_ticket", "adoption", "active_user", "dau_", "company_size", "employee_count", "industry", "region"))]
    pd.testing.assert_frame_equal(baseline[["customer_id", *signal_columns]].reset_index(drop=True), partial[["customer_id", *signal_columns]].reset_index(drop=True),
                                  check_exact=True, check_dtype=False)  # fmt: skip


@pytest.mark.req("REQ-SIG-01", "REQ-SIG-02", "REQ-SIG-03", "REQ-SIG-04")
def test_the_nightly_signals_step_is_idempotent_and_reuses_an_unchanged_adoption_run(demo):
    first = signals.refresh(demo.tenant_id, None)
    assert first["sentiment"]["scored"] == 0 and first["attribute_history"]["customers"] == 0 and first["identity"]["links_created"] == 0
    assert first["adoption"].get("reused") is True, "same date, same catalogue: the existing measurement is kept"
    with session_scope() as s:
        s.execute(update(SupportInteraction).where(SupportInteraction.tenant_id == demo.tenant_id).values(record_version=SupportInteraction.record_version))  # no change
        entry = s.execute(select(AdoptionRun).order_by(AdoptionRun.id.desc()).limit(1)).scalar_one()
        entry.catalog_hash = "0" * 64  # as if the catalogue had changed since
    second = signals.refresh(demo.tenant_id, None)
    assert second["adoption"].get("reused") is None and second["adoption"]["facts"] > 0
