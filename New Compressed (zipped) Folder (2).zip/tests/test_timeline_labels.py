"""Churn labels: the target is "churns within [T, T + horizon)", derived from subscription events.

Every scenario is a hand-built timeline whose correct answer is known by inspection.
"""

from __future__ import annotations

from datetime import date, datetime

import pandas as pd
import pytest
from sqlalchemy import func, select

from churn_platform.db import read_session
from churn_platform.errors import ValidationFailed
from churn_platform.models import ChurnLabel, Customer, LabelRun
from churn_platform.services import labels, timeline
from churn_platform.services.policies import ChurnDefinition
from tests.builders import World

pytestmark = pytest.mark.req("REQ-ML-01")
CUTOFF = "2026-09-30 23:59:59"


def label(world: World, as_of: str, cutoff: str = CUTOFF, customer_id: int = 1, **definition) -> dict:
    out = labels.compute_labels(world.frames(), ChurnDefinition(**definition), [date.fromisoformat(as_of)], cutoff)
    rows = out[out["customer_id"] == customer_id]
    assert len(rows) <= 1
    return rows.iloc[0].to_dict() if len(rows) else {}


def one_customer(start: str = "2026-01-01", **sub) -> World:
    w = World()
    w.customer(1, acquired_at=start)
    w.subscription(1, 1, start, **sub)
    return w


# ----------------------------------------------------------------------------- the 30-day window
def test_label_window_is_half_open_at_both_ends():
    w = one_customer()
    w.event(1, "ended", "2026-04-01 00:00:00", reason="cancellation")
    assert label(w, "2026-03-01")["status"] == "retained", "ends on day T+31: outside [T, T+30)"
    retained = label(w, "2026-03-02")
    assert (retained["status"], retained["label"]) == ("retained", 0), "ends exactly at T+30 00:00: outside the window"
    churned = label(w, "2026-03-03")
    assert (churned["status"], churned["label"], churned["churn_date"], churned["churn_type"], churned["churn_reason"]) == (
        "churned", 1, date(2026, 4, 1), "voluntary", "cancellation")  # fmt: skip
    assert label(w, "2026-03-31")["status"] == "churned", "ends one day after T"
    gone = label(w, "2026-04-01")
    assert gone["status"] == "ineligible" and gone["detail"] == {"reason": "no_active_subscription"}, "not a subscriber at T: nothing to predict"
    assert label(w, "2025-12-31") == {}, "the customer did not exist yet: no row at all"

    last_second = one_customer()
    last_second.event(1, "ended", "2026-03-31 23:59:59", reason="cancellation")
    assert label(last_second, "2026-03-02")["status"] == "churned", "one second before T+30 is inside the window"


def test_horizon_is_configurable_and_defaults_to_30_days():
    w = one_customer()
    w.event(1, "ended", "2026-04-20", reason="cancellation")
    assert ChurnDefinition().horizon_days == 30
    assert label(w, "2026-03-01")["status"] == "retained"
    assert label(w, "2026-03-01", horizon_days=60)["status"] == "churned"


def test_unfinished_observation_windows_are_never_labelled():
    w = one_customer()
    immature = label(w, "2026-09-15")
    assert immature["status"] == "immature" and pd.isna(immature["label"])
    assert immature["detail"]["observable_from"] == "2026-10-15"
    # data observed through 30 Sep 23:59:59 covers the whole window [1 Sep, 1 Oct) but not [2 Sep, 2 Oct)
    assert label(w, "2026-09-01")["status"] == "retained"
    assert label(w, "2026-09-02")["status"] == "immature"
    # a churn that is already visible is still not a label until the window closes: otherwise recent
    # periods would contain their positives but not yet their negatives
    w.event(1, "ended", "2026-09-20", reason="cancellation")
    assert label(w, "2026-09-15")["status"] == "immature"
    assert label(w, "2026-09-02")["status"] == "immature"
    assert label(w, "2026-09-01")["status"] == "churned"
    assert label(w, "2026-09-01", cutoff="2026-09-29 23:59:59")["status"] == "immature", "one day of the window is still unobserved"


# ----------------------------------------------------------------------------- voluntary vs involuntary
@pytest.mark.parametrize(("reason", "expected"), [("cancellation", "voluntary"), ("non_renewal", "voluntary"), ("payment_failure", "involuntary"),
                                                    ("suspension", "involuntary"), ("merger", "unknown"), (None, "unknown")])  # fmt: skip
def test_churn_type_follows_the_end_reason(reason, expected):
    w = one_customer()
    w.event(1, "ended", "2026-03-10", reason=reason)
    got = label(w, "2026-03-01")
    assert (got["status"], got["churn_type"]) == ("churned", expected)


def test_excluded_reasons_are_removed_from_the_population_not_counted_as_retained():
    w = one_customer()
    w.event(1, "ended", "2026-03-10", reason="migration")
    got = label(w, "2026-03-01", excluded_reasons=["migration"])
    assert got["status"] == "ineligible" and got["detail"]["reason"] == "excluded_reason:migration" and pd.isna(got["label"])
    assert label(w, "2026-02-01", excluded_reasons=["migration"])["status"] == "retained", "outside the window the exclusion does not apply"
    with pytest.raises(ValueError, match="only one of"):
        ChurnDefinition(voluntary_reasons=["x"], excluded_reasons=["x"])


def test_involuntary_churn_happens_when_the_grace_period_runs_out():
    w = one_customer()
    w.event(1, "payment_failed", "2026-03-10")
    got = label(w, "2026-03-01")
    assert (got["status"], got["churn_type"], got["churn_reason"], got["churn_date"]) == ("churned", "involuntary", "payment_failure", date(2026, 3, 24))
    assert label(w, "2026-03-01", grace_period_days=30)["status"] == "retained", "with a 30-day grace the lapse (9 Apr) is outside the window"
    assert label(w, "2026-03-11", grace_period_days=30)["churn_date"] == date(2026, 4, 9)
    assert label(w, "2026-03-25")["status"] == "ineligible", "after the lapse the customer is no longer a subscriber"


def test_recovered_payments_do_not_count_as_churn():
    by_event, by_payment, too_late = one_customer(), one_customer(), one_customer()
    by_event.event(1, "payment_failed", "2026-03-10")
    by_event.event(1, "recovered", "2026-03-20")
    by_payment.event(1, "payment_failed", "2026-03-10")
    by_payment.payment(1, "2026-03-15", "succeeded")
    too_late.event(1, "payment_failed", "2026-03-10")
    too_late.event(1, "recovered", "2026-04-05")
    assert label(by_event, "2026-03-01")["status"] == "retained"
    assert label(by_payment, "2026-03-01")["status"] == "retained", "a successful retry inside the grace period recovers the subscription"
    late = label(too_late, "2026-03-01")
    assert (late["status"], late["churn_date"]) == ("churned", date(2026, 3, 24)), "recovery after the grace period is a win-back, the churn stands"
    intervals = timeline.build_intervals(too_late.frames(), 14, timeline.ts(CUTOFF))
    assert [(str(r.start.date()), None if pd.isna(r.end) else str(r.end.date()), r.end_reason) for r in intervals.itertuples()] == [
        ("2026-01-01", "2026-03-24", "payment_failure"), ("2026-04-05", None, None)]  # fmt: skip
    # a failed payment that is too recent to have lapsed leaves the subscription open at the cutoff
    recent = one_customer()
    recent.event(1, "payment_failed", "2026-09-25")
    assert pd.isna(timeline.build_intervals(recent.frames(), 14, timeline.ts(CUTOFF))["end"].iloc[0])


def test_an_explicit_end_inside_the_grace_period_wins_over_the_lapse():
    w = one_customer()
    w.event(1, "payment_failed", "2026-03-10")
    w.event(1, "ended", "2026-03-12", reason="cancellation")
    got = label(w, "2026-03-01")
    assert (got["churn_type"], got["churn_date"]) == ("voluntary", date(2026, 3, 12))


# ----------------------------------------------------------------------------- eligibility
def test_trials_are_not_subscribers_unless_the_definition_says_so():
    w = one_customer(trial_end_at="2026-01-15")
    in_trial = label(w, "2026-01-10")
    assert in_trial["status"] == "ineligible" and in_trial["detail"] == {"reason": "in_trial"}
    assert label(w, "2026-01-10", include_trials=True)["status"] == "retained"
    paying = label(w, "2026-02-01")
    assert paying["status"] == "retained" and paying["detail"]["tenure_days"] == 17, "tenure counts from the first paid day"
    expired = one_customer(trial_end_at="2026-01-15")
    expired.event(1, "ended", "2026-01-15", reason="trial_expired")
    assert label(expired, "2026-01-10")["status"] == "ineligible", "a trial that never converts is not churn"
    assert label(expired, "2026-01-10", include_trials=True)["status"] == "churned"


def test_covered_population_is_who_gets_a_label_later_judged_only_from_the_past():
    """The population a model is trained on (and may score) at T: decided without looking past T."""
    w = World()
    for cid in range(1, 8):
        w.customer(cid, acquired_at="2026-01-01")
    w.subscription(1, 1, "2026-01-01")  # paying, stays
    w.subscription(2, 2, "2026-01-01")  # paying at T, cancels AFTER T: not knowable at T, so covered
    w.event(2, "ended", "2026-03-10", reason="cancellation")
    w.subscription(3, 3, "2026-02-20", trial_end_at="2026-03-06")  # still in trial at T
    w.subscription(4, 4, "2026-01-01")  # ended before T
    w.event(4, "ended", "2026-02-10", reason="cancellation")
    w.subscription(5, 5, "2026-02-15")  # paying for 14 days at T
    w.subscription(6, 6, "2026-03-05")  # a known customer whose subscription starts after T
    w.customer(8, acquired_at="2026-03-02")  # acquired after T: does not exist yet at T
    w.subscription(8, 8, "2026-03-02")
    w.subscription(7, 7, "2026-01-01", events=False)  # the row says January, an event says it ended before that
    w.event(7, "ended", "2025-12-01", reason="cancellation")
    frames, as_of = w.frames(), date(2026, 3, 1)
    covered, left_out = labels.covered_population(frames, ChurnDefinition(), as_of)
    assert covered == {1, 2, 5}
    assert left_out == {3: "in_trial", 4: "no_active_subscription", 6: "no_active_subscription", 7: "contradictory_subscription_history"}
    assert 8 not in covered and 8 not in left_out, "a customer acquired after T is not part of the picture at T at all"
    assert labels.covered_population(frames, ChurnDefinition(include_trials=True), as_of)[0] == {1, 2, 3, 5}
    strict, why = labels.covered_population(frames, ChurnDefinition(min_tenure_days=30), as_of)
    assert strict == {1, 2} and why[5] == "below_min_tenure"
    assert set(left_out.values()) <= set(labels.NOT_COVERED), "every reason has a plain-language explanation"
    # the same customers are exactly the ones that get a churned / retained label for T once the window has closed
    later = labels.compute_labels(frames, ChurnDefinition(), [as_of], "2026-06-30 23:59:59")
    assert set(later.loc[later["status"].isin(["churned", "retained"]), "customer_id"]) == covered
    assert later.set_index("customer_id").loc[2, "status"] == "churned"
    # an excluded ending inside the window is an outcome: it cannot remove anybody from the population at T
    excluded = ChurnDefinition(voluntary_reasons=["non_renewal"], excluded_reasons=["cancellation"])
    assert 2 in labels.covered_population(frames, excluded, as_of)[0]
    assert labels.compute_labels(frames, excluded, [as_of], "2026-06-30 23:59:59").set_index("customer_id").loc[2, "status"] == "ineligible"


def test_minimum_tenure():
    w = one_customer()
    young = label(w, "2026-01-20", min_tenure_days=30)
    assert young["status"] == "ineligible" and young["detail"]["reason"] == "below_min_tenure" and young["detail"]["tenure_days"] == 19
    assert label(w, "2026-01-31", min_tenure_days=30)["status"] == "retained"


def test_contradictory_history_is_unknown_rather_than_guessed():
    w = World()
    w.customer(1, acquired_at="2026-01-01")
    w.subscription(1, 1, "2026-01-01", events=False, status="cancelled")  # says it ended, but not when
    got = label(w, "2026-03-01")
    assert got["status"] == "unknown" and got["detail"]["reason"] == "contradictory_subscription_history" and pd.isna(got["label"])
    # without events the subscription row is the fallback source of truth
    w2 = World()
    w2.customer(1, acquired_at="2026-01-01")
    w2.subscription(1, 1, "2026-01-01", events=False, status="ended", ended_at="2026-03-10", end_reason="non_renewal")
    got = label(w2, "2026-03-01")
    assert (got["status"], got["churn_type"], got["churn_date"]) == ("churned", "voluntary", date(2026, 3, 10))
    assert timeline.build_intervals(w2.frames(), 14, timeline.ts(CUTOFF))["state_source"].tolist() == ["subscription_row"]


def test_an_event_history_that_begins_mid_life_is_still_honoured():
    """A truncated export has no ``started`` event; the later events must not be thrown away."""
    w = World()
    w.customer(1, acquired_at="2026-01-01")
    w.subscription(1, 1, "2026-01-01", events=False)  # the row still says nothing about an end
    w.event(1, "ended", "2026-03-10", reason="cancellation")
    got = label(w, "2026-03-01")
    assert (got["status"], got["churn_type"], got["churn_date"]) == ("churned", "voluntary", date(2026, 3, 10))
    assert label(w, "2026-04-01")["detail"] == {"reason": "no_active_subscription"}
    intervals = timeline.build_intervals(w.frames(), 14, timeline.ts(CUTOFF))
    assert intervals["state_source"].tolist() == ["events+row_start"] and intervals["start"].tolist() == [pd.Timestamp("2026-01-01")]

    dunning = World()
    dunning.customer(1, acquired_at="2026-01-01")
    dunning.subscription(1, 1, "2026-01-01", events=False)
    dunning.event(1, "payment_failed", "2026-03-05")
    lapsed = label(dunning, "2026-03-01")
    assert (lapsed["status"], lapsed["churn_type"], lapsed["churn_date"]) == ("churned", "involuntary", date(2026, 3, 19))

    impossible = World()
    impossible.customer(1, acquired_at="2026-01-01")
    impossible.subscription(1, 1, "2026-03-01", events=False)
    impossible.event(1, "ended", "2026-02-10", reason="cancellation")  # ended before it started?
    odd = label(impossible, "2026-04-01")
    assert odd["status"] == "unknown" and odd["detail"]["reason"] == "contradictory_subscription_history"


# ----------------------------------------------------------------------------- reactivation and several subscriptions
def test_reactivation_window_bridges_short_gaps():
    w = one_customer()
    w.event(1, "ended", "2026-03-10", reason="cancellation")
    w.event(1, "reactivated", "2026-03-20")
    assert label(w, "2026-03-01")["status"] == "churned", "by default any end is churn"
    assert label(w, "2026-03-01", reactivation_window_days=14)["status"] == "retained", "a 10-day gap inside a 14-day window is not churn"
    assert label(w, "2026-03-01", reactivation_window_days=7)["status"] == "churned"
    # the label must wait for the reactivation window as well, or late win-backs would flip it afterwards
    waiting = label(w, "2026-08-25", cutoff="2026-09-30 23:59:59", reactivation_window_days=14)
    assert waiting["status"] == "immature" and waiting["detail"]["observable_from"] == "2026-10-08"


def test_multi_subscription_rules():
    w = World()
    w.customer(1, acquired_at="2026-01-01")
    w.subscription(1, 1, "2026-01-01", mrr=500.0)
    w.subscription(2, 1, "2026-01-01", mrr=50.0)
    w.event(2, "ended", "2026-03-15", reason="cancellation")
    assert label(w, "2026-03-01")["status"] == "retained", "'all': the customer stays while any subscription is active"
    assert label(w, "2026-03-01")["detail"]["active_subscriptions"] == 2
    assert label(w, "2026-03-01", multi_subscription_rule="any")["status"] == "churned", "'any': losing one subscription counts"
    assert label(w, "2026-03-01", multi_subscription_rule="primary")["status"] == "retained", "'primary': the largest subscription decides"
    w.event(1, "ended", "2026-03-20", reason="payment_failure")
    both = label(w, "2026-03-01")
    assert (both["status"], both["churn_date"], both["churn_type"]) == ("churned", date(2026, 3, 20), "involuntary"), "'all': churn on the last end"
    primary = label(w, "2026-03-01", multi_subscription_rule="primary")
    assert (primary["status"], primary["churn_date"]) == ("churned", date(2026, 3, 20))


def test_an_upgrade_to_a_new_subscription_is_not_churn():
    w = World()
    w.customer(1, acquired_at="2026-01-01")
    w.subscription(1, 1, "2026-01-01")
    w.event(1, "ended", "2026-03-10", reason="cancellation")
    w.subscription(2, 1, "2026-03-10")
    assert label(w, "2026-03-01")["status"] == "retained"


# ----------------------------------------------------------------------------- dates
def test_as_of_dates_are_month_starts_inside_the_observed_range():
    assert labels.month_starts(date(2026, 1, 15), date(2026, 4, 1)) == [date(2026, 2, 1), date(2026, 3, 1), date(2026, 4, 1)]
    assert labels.month_starts(date(2025, 11, 1), date(2026, 1, 31)) == [date(2025, 11, 1), date(2025, 12, 1), date(2026, 1, 1)]
    cutoff = datetime(2026, 9, 30, 23, 59, 59)
    assert labels.resolve_dates(None, "2026-08-10", "2026-10-01", cutoff) == [date(2026, 9, 1), date(2026, 10, 1)]
    assert labels.resolve_dates(["2026-09-01", "2026-03-01", "2026-09-01"], None, None, cutoff) == [date(2026, 3, 1), date(2026, 9, 1)]
    for args, message in (((None, "2026-01-01", None), "either as_of_dates or both"), ((None, "2026-05-01", "2026-04-01"), "must not be before"),
                          ((None, "2026-05-02", "2026-05-20"), "no as-of dates"), ((["2026-10-02"], None, None), "later than the data cutoff"),
                          (([f"2020-{m:02d}-{d:02d}" for m in range(1, 13) for d in range(1, 12)], None, None), "at most 120")):  # fmt: skip
        with pytest.raises(ValidationFailed, match=message):
            labels.resolve_dates(*args, cutoff)


# ----------------------------------------------------------------------------- persisted labels of the seeded tenant
def test_stored_labels_equal_a_recomputation_and_obey_the_window(ro):
    with read_session() as s:
        run = s.execute(select(LabelRun).where(LabelRun.tenant_id == ro.tenant_id).order_by(LabelRun.id.desc()).limit(1)).scalar_one()
        stored = pd.DataFrame(s.execute(select(ChurnLabel.customer_id, ChurnLabel.as_of_date, ChurnLabel.status, ChurnLabel.label, ChurnLabel.churn_type,
                                                ChurnLabel.churn_date).where(ChurnLabel.label_run_id == run.id)).all(),
                              columns=["customer_id", "as_of_date", "status", "label", "churn_type", "churn_date"])  # fmt: skip
        frames = timeline.load_frames(s, ro.tenant_id, tables=("customers", "subscriptions", "sub_events", "payments"))
        n_customers = s.execute(select(func.count()).select_from(Customer).where(Customer.tenant_id == ro.tenant_id)).scalar_one()
    dates = [date.fromisoformat(d) for d in run.as_of_dates]
    again = labels.compute_labels(frames, ChurnDefinition(), dates, run.data_cutoff)
    key = ["customer_id", "as_of_date"]
    merged = stored.merge(again[[*key, "status", "churn_date"]], on=key, suffixes=("", "_again"), how="outer", indicator=True)
    assert (merged["_merge"] == "both").all() and (merged["status"] == merged["status_again"]).all(), "labels are reproducible from the stored events"
    assert len(stored) == len(again) and stored["customer_id"].nunique() <= n_customers
    churned = stored[stored["status"] == "churned"]
    assert len(churned) >= 30 and set(churned["churn_type"]) >= {"voluntary", "involuntary"}
    days = [(r.churn_date - r.as_of_date).days for r in churned.itertuples()]
    assert min(days) >= 0 and max(days) < 30, "every churn date lies inside [T, T+30)"
    assert (stored.loc[stored["status"] == "retained", "label"] == 0).all() and (churned["label"] == 1).all()
    assert stored.loc[~stored["status"].isin(["churned", "retained"]), "label"].isna().all(), "only mature, eligible rows carry a label"
    assert set(stored["status"]) >= {"churned", "retained", "immature", "ineligible"}
    cutoff = timeline.ts(run.data_cutoff)
    immature = stored[stored["status"] == "immature"]
    assert all(timeline.ts(d) + pd.Timedelta(days=30) > cutoff for d in immature["as_of_date"]), "immature means the window is still open"
    with read_session() as s:
        summary = labels.summary(s, ro.tenant_id)
    assert summary["totals"]["churned"] == len(churned) and sum(d["voluntary"] + d["involuntary"] for d in summary["dates"]) <= len(churned)
    rates = [d["churn_rate"] for d in summary["dates"] if d["churn_rate"] is not None]
    assert rates and all(0 <= r < 0.5 for r in rates)
