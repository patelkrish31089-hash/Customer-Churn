"""The delivery layer, reachable from the product (1.3.0, R-98).

Before these tests the canonical record, the destination pipeline, the outbox and the Snowflake adapter had no caller:
no route started an export, no worker handler drained one, and nothing in the browser application showed a run.  The
register said so in two entries — R-60 PARTIAL and R-98 NOT_IMPLEMENTED — and this module is the acceptance for the
answer.

What is asserted, and why each one is not ceremony:

* a run is **started through the API**, and the run row exists before the job does, so a job that never runs is visible
  rather than invisible;
* the **worker drains it** through the registered destination and the outbox records every record's own outcome;
* a record the destination **refuses does not advance the watermark**, and the run that follows sends only the rest —
  the same defect 1, seen through the product path rather than through the pipeline directly;
* **resuming** a run with nothing outstanding is refused, and resuming one with a backlog is not;
* the **selection is written down**, so a retried job exports what the original run selected;
* a destination that cannot be built **says what is missing** — for Snowflake, the exact environment variables — and
  never pretends a vendor is reachable;
* a run is **tenant-scoped**: another tenant's run id is a 404, not someone else's history;
* the endpoints require **``customers:export``** to move data and ``customers:read`` to look at it.

The destination used here is a stand-in registered through the same seam a real vendor would use.  Nothing in this
module claims a warehouse accepted anything: GATE 12 is BLOCKED and stays BLOCKED.
"""

from __future__ import annotations

import pytest

from churn_platform.db import session_scope
from churn_platform.errors import ValidationFailed
from churn_platform.services import auth, exports, jobs
from churn_platform.services.destinations.base import FAILED

pytestmark = pytest.mark.req("REQ-ACT-02")

ACCEPT_ALL = "test-warehouse"


class Warehouse:
    """A destination that answers like a warehouse: it keeps what it was given, and can refuse named customers."""

    def __init__(self, name: str = ACCEPT_ALL, *, refuse: tuple[str, ...] = (), refuse_first: bool = False,
                 unreachable: bool = False, can_count: bool = True):
        self.name = name
        self.refuse = set(refuse)
        self.refuse_first = refuse_first
        self.doomed: str | None = None
        self.refused: set[str] = set()
        self.unreachable = unreachable
        self.can_count = can_count
        self.rows: dict[tuple, str] = {}
        self.schema_checked = False
        self.batches: list[int] = []

    def test_connection(self) -> dict:
        return {"ok": True}

    def ensure_schema(self) -> None:
        if self.unreachable:
            raise ValidationFailed("the warehouse refused the connection: account is not configured on the server")
        self.schema_checked = True

    def write(self, records, *, run_id):
        self.batches.append(len(records))
        if self.refuse_first and self.doomed is None:
            # the same customer every time, so a split batch cannot quietly succeed where the whole batch failed
            self.doomed = min(record["external_customer_id"] for record in records)
        doomed = set(self.refuse) | ({self.doomed} if self.doomed else set())
        for record in records:
            if record["external_customer_id"] in doomed:
                self.refused.add(record["external_customer_id"])
                raise RuntimeError(f"constraint violation for {record['external_customer_id']}")
        for record in records:
            key = (record["tenant_id"], record["external_customer_id"], record["model_version"],
                   str(record["data_cutoff_timestamp"])[:10])  # fmt: skip
            self.rows[key] = run_id
        return len(records)

    def count_stored(self, *, run_id):
        if not self.can_count:
            return None
        return sum(1 for value in self.rows.values() if value == run_id)


@pytest.fixture(autouse=True)
def _room_to_start(monkeypatch):
    """The per-minute export limit has its own tests; here it would only measure the shared store."""
    from churn_platform.config import get_settings

    monkeypatch.setenv("CHURN_RATE_LIMIT_EXPORT_PER_MINUTE", "1000")
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def registered():
    """Register a destination for one test and take it out of the registry afterwards."""
    added: list[str] = []

    def register(destination, name: str | None = None):
        key = name or destination.name
        exports.register_destination(key, lambda: destination)
        added.append(key)
        return key

    yield register
    for key in added:
        exports._DESTINATIONS.pop(key, None)


def _start(client, headers, **body):
    return client.post("/api/v1/exports/runs", json={"destination": ACCEPT_ALL, **body}, headers=headers)


# ----------------------------------------------------------------------------- the registry
def test_the_worker_registers_the_export_handler():
    """Without this handler a run would sit in ``pending`` for ever, which is how 1.3.0 shipped."""
    jobs.load_handlers()
    assert exports.JOB_TYPE in jobs.HANDLERS


def test_snowflake_is_a_known_destination_that_says_what_it_needs(monkeypatch):
    """The vendor adapter is reachable through the registry and refuses in words an operator can act on."""
    assert "snowflake" in exports.registered()
    from churn_platform.config import get_settings

    get_settings.cache_clear()
    monkeypatch.delenv("CHURN_EXPORT_SNOWFLAKE_ACCOUNT", raising=False)
    with pytest.raises(ValidationFailed) as refused:
        exports.destination_for("snowflake")
    assert "CHURN_EXPORT_SNOWFLAKE_ACCOUNT" in refused.value.message
    get_settings.cache_clear()


def test_an_unknown_destination_is_refused_by_name(empty):
    tenant_id = empty.tenant("acme")
    principal = empty.user(tenant_id, "admin")
    with session_scope() as session, pytest.raises(ValidationFailed) as refused:
        exports.start(session, principal, {"destination": "no-such-warehouse"})
    assert "not a destination this installation knows about" in refused.value.message
    assert refused.value.details["known"], "the refusal names what is available instead"


def test_the_destinations_endpoint_reports_configured_and_unconfigured(registered, demo):
    registered(Warehouse())
    with demo.client() as client:
        headers = demo.login(client)
        listed = client.get("/api/v1/exports/destinations", headers=headers)
    assert listed.status_code == 200, listed.text
    by_name = {item["name"]: item for item in listed.json()["items"]}
    assert by_name[ACCEPT_ALL]["state"] == "configured"
    assert by_name["snowflake"]["state"] == "unconfigured"
    assert "CHURN_EXPORT_SNOWFLAKE_ACCOUNT" in by_name["snowflake"]["reason"]


# ----------------------------------------------------------------------------- the run, end to end
def test_an_export_run_is_started_through_the_api_and_drained_by_the_worker(registered, demo):
    warehouse = Warehouse()
    registered(warehouse)
    with demo.client() as client:
        headers = demo.login(client)
        started = _start(client, headers)
        assert started.status_code == 202, started.text
        run = started.json()["run"]
        assert run["status"] == "pending" and run["destination"] == ACCEPT_ALL
        assert run["selected"] > 0 and run["selection"]["batch_id"], "a run records what it selected"
        assert started.json()["job"]["job_type"] == "export.run"
        # the run row exists before the job runs: a job that never starts is visible rather than absent
        assert client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers).json()["run"]["status"] == "pending"
        demo.drain()
        finished = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers)
    assert finished.status_code == 200, finished.text
    body = finished.json()["run"]
    assert body["status"] == "completed"
    assert body["acknowledged"] == body["selected"] > 0
    assert body["failed"] == 0 and body["quarantined"] == 0
    assert body["watermark"] and body["checksum"], "an acknowledged run moves the watermark and has a checksum"
    assert warehouse.schema_checked and sum(warehouse.batches) == body["acknowledged"]


def test_the_outbox_and_the_checkpoint_both_say_what_happened(registered, demo):
    warehouse = Warehouse()
    registered(warehouse)
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        demo.drain()
        backlog = client.get(f"/api/v1/exports/backlog?destination={ACCEPT_ALL}", headers=headers).json()
        detail = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers).json()
    assert backlog["outstanding"] == 0, "everything the destination accepted is out of the backlog"
    assert detail["backlog"]["outstanding"] == 0
    with session_scope() as session:
        from churn_platform.services import export_outbox

        checkpoint = export_outbox.checkpoint_for(session, demo.tenant_id, ACCEPT_ALL)
    assert checkpoint is not None and checkpoint.watermark is not None
    assert checkpoint.last_run_id == run["run_id"]


def test_a_refused_record_stops_the_watermark_and_the_resume_sends_only_the_rest(registered, demo):
    """Defect 1 through the product path: an acknowledged successor must not pull the watermark past a failure."""
    warehouse = Warehouse(refuse_first=True)
    registered(warehouse)
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        demo.drain()
        body = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers).json()["run"]

    assert body["status"] == "partial", "some records were acknowledged and one was not"
    assert body["failed"] == 1 and body["acknowledged"] == body["selected"] - 1
    with session_scope() as session:
        from churn_platform.services import export_outbox

        checkpoint = export_outbox.checkpoint_for(session, demo.tenant_id, ACCEPT_ALL)
        backlog = export_outbox.outstanding(session, demo.tenant_id, ACCEPT_ALL)
    assert len(backlog) == 1 and backlog[0].status == FAILED
    refused_at = backlog[0].prediction_timestamp
    watermark = checkpoint.watermark if checkpoint else None
    if watermark is not None and refused_at is not None:
        assert watermark < refused_at, "the watermark must not be at or past a refused record's instant"
    assert warehouse.refused, "the stand-in refused a record, which is the point of the test"

    # the destination now accepts everything; the resume sends exactly the record that was outstanding
    sent = len(warehouse.rows)
    warehouse.refuse_first, warehouse.doomed = False, None
    with demo.client() as client:
        headers = demo.login(client)
        resumed = client.post(f"/api/v1/exports/runs/{run['id']}/resume", json={}, headers=headers)
        assert resumed.status_code == 202, resumed.text
        demo.drain()
        after = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers).json()
    assert len(warehouse.rows) == sent + 1, "the resume sent the one record that was outstanding, not the batch again"
    assert after["backlog"]["outstanding"] == 0
    with session_scope() as session:
        from churn_platform.services import export_outbox

        checkpoint = export_outbox.checkpoint_for(session, demo.tenant_id, ACCEPT_ALL)
    assert checkpoint is not None and checkpoint.watermark is not None


def test_resuming_a_run_with_nothing_outstanding_is_refused(registered, demo):
    registered(Warehouse())
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        demo.drain()
        again = client.post(f"/api/v1/exports/runs/{run['id']}/resume", json={}, headers=headers)
    assert again.status_code == 409
    assert "nothing outstanding" in again.text


def test_a_second_export_of_the_same_batch_is_refused_by_the_watermark(registered, demo):
    registered(Warehouse())
    with demo.client() as client:
        headers = demo.login(client)
        _start(client, headers)
        demo.drain()
        again = _start(client, headers)
    assert again.status_code == 409
    assert "watermark" in again.text


def test_a_full_export_ignores_the_watermark_and_rewrites_the_same_rows(registered, demo):
    warehouse = Warehouse()
    registered(warehouse)
    with demo.client() as client:
        headers = demo.login(client)
        first = _start(client, headers).json()["run"]
        demo.drain()
        rows_after_first = len(warehouse.rows)
        second = _start(client, headers, full=True).json()["run"]
        demo.drain()
    assert second["selected"] == first["selected"]
    assert len(warehouse.rows) == rows_after_first, "the same records under the same identity are written once"


def test_a_destination_that_cannot_be_reached_fails_the_run_and_says_why(registered, demo):
    registered(Warehouse(unreachable=True))
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        demo.drain(expect_success=False)
        body = client.get(f"/api/v1/exports/runs/{run['id']}", headers=headers).json()["run"]
    assert body["status"] == "failed"
    assert "refused the connection" in (body["error"] or "")
    assert body["acknowledged"] == 0


def test_reconcile_compares_the_record_with_what_the_destination_holds(registered, demo):
    warehouse = Warehouse()
    registered(warehouse)
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        demo.drain()
        counted = client.post(f"/api/v1/exports/runs/{run['id']}/reconcile", json={}, headers=headers).json()
        warehouse.can_count = False
        counted = {"matches": counted["reconciliation"]["matches"], "checked": counted["reconciliation"]["checked"]}
        unknown = client.post(f"/api/v1/exports/runs/{run['id']}/reconcile", json={}, headers=headers).json()
    assert counted == {"matches": True, "checked": "counted"}
    assert unknown["reconciliation"]["checked"] == "unknown", "a destination that cannot count is not a green tick"


def test_a_run_is_tenant_scoped(registered, demo):
    """Another tenant's run id is a 404: a run names a destination, a batch and counts, and none of them are theirs."""
    registered(Warehouse())
    with session_scope() as session:
        other = auth.create_tenant(session, "otherco", "Other Co")
        auth.create_user(session, tenant_id=other.id, email="admin@otherco.example", full_name="Other Admin",
                         role="admin", password="correct-horse-battery-2")  # fmt: skip
    with demo.client() as client:
        headers = demo.login(client)
        run = _start(client, headers).json()["run"]
        login = client.post("/api/v1/auth/login", json={"email": "admin@otherco.example", "password": "correct-horse-battery-2"})
        assert login.status_code == 200, login.text
        other_headers = {"Authorization": "Bearer " + login.json()["token"]}
        theirs = client.get(f"/api/v1/exports/runs/{run['id']}", headers=other_headers)
        resume = client.post(f"/api/v1/exports/runs/{run['id']}/resume", json={}, headers=other_headers)
    assert theirs.status_code == 404 and resume.status_code == 404


def test_moving_customer_data_needs_the_export_permission(registered, demo):
    registered(Warehouse())
    with demo.client() as client:
        headers = demo.login(client, "viewer")
        started = _start(client, headers)
        listed = client.get("/api/v1/exports/runs", headers=headers)
    assert started.status_code == 403, "a viewer may read the platform; exporting customers is not reading"
    assert listed.status_code == 200


def test_an_export_with_an_unknown_batch_is_refused(registered, demo):
    registered(Warehouse())
    with demo.client() as client:
        headers = demo.login(client)
        refused = _start(client, headers, batch_id=999_999)
    assert refused.status_code == 404
    assert "does not exist for this tenant" in refused.text
