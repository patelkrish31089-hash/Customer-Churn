"""Human labels for support text: two reviewers, the agreement between them, adjudication, freezing, export (1.2.0).

The point of these rules is that a sentiment accuracy figure can only ever come from a set that people labelled
independently and nobody edited afterwards.
"""

from __future__ import annotations

import pytest

from churn_platform.services import annotations

pytestmark = pytest.mark.req("REQ-SIG-03")


def _error(response) -> dict:
    """The API answers a refusal with {"error": {code, message, details, correlation_id}}."""
    return response.json()["error"]


def _items(client, headers, batch_id) -> list[dict]:
    r = client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/items", headers=headers, params={"page_size": 50})
    assert r.status_code == 200, r.text
    return r.json()["items"]


def test_a_labelled_set_cannot_be_frozen_or_exported_until_two_people_agree_or_a_third_decides(demo):
    demo.drain()
    with demo.client() as client:
        admin, analyst = demo.login(client, "admin"), demo.login(client, "analyst")
        created = client.post("/api/v1/signals/sentiment/annotation-batches", headers=admin,
                              json={"name": "support sample 1", "description": "first pass", "is_synthetic": False, "sample": 6})
        assert created.status_code == 201, created.text
        batch = created.json()
        assert (batch["status"], batch["rows"], batch["is_synthetic"]) == ("open", 6, False)
        assert batch["can_freeze"] is False and batch["reviewers_needed"] == 2
        batch_id = batch["id"]

        items = _items(client, admin, batch_id)
        assert len(items) == 6 and all(item["text"] for item in items), "every item carries the support text it was drawn from"
        assert all(item["labels"] == 0 and item["my_label"] is None for item in items)

        # an open batch cannot be exported or evaluated: the numbers would belong to a moving set
        assert client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/export", headers=admin).status_code == 409
        assert client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/evaluate", headers=admin).status_code == 409

        # two people label every text; they agree on four of six
        agreement_plan = {0: "negative", 1: "positive", 2: "neutral", 3: "negative", 4: "positive", 5: "neutral"}
        analyst_plan = {0: "negative", 1: "positive", 2: "neutral", 3: "mixed", 4: "positive", 5: "negative"}
        for n, item in enumerate(items):
            first = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=admin,
                                json={"interaction_id": item["interaction_id"], "label": agreement_plan[n], "note": "admin"})
            assert first.status_code == 201, first.text
            second = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=analyst,
                                 json={"interaction_id": item["interaction_id"], "label": analyst_plan[n]})
            assert second.status_code == 201, second.text

        # a person may revise their own label, and the revision counts once instead of adding a third
        revised = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=analyst,
                              json={"interaction_id": items[3]["interaction_id"], "label": "negative", "note": "re-read the thread"})
        assert revised.status_code == 201 and revised.json()["changed"] is True
        still = client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/agreement", headers=admin).json()
        assert len(still["disagreements"]) == 1, "one disagreement is left: the revision fixed one of the two"
        client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=analyst,
                    json={"interaction_id": items[5]["interaction_id"], "label": "neutral"})
        assert all(item["labels"] == 2 and item["labels_agree"] is True for item in _items(client, admin, batch_id)), "both reviewers agree on every text now"

        report = client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/agreement", headers=admin).json()
        assert report["items"] == 6 and report["items_with_two_reviewers"] == 6
        pair = report["pairs"][0]
        assert (pair["together"], pair["agree"], pair["exact_agreement"]) == (6, 6, 1.0)
        assert pair["kappa"] is None or pair["kappa"] == 1.0, "one label per reader, or perfect agreement"
        assert report["disagreements"] == [], "the revision removed the only disagreement"

        # put two disagreements back, then freeze must refuse
        for n, label in ((3, "mixed"), (5, "negative")):
            client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=analyst,
                        json={"interaction_id": items[n]["interaction_id"], "label": label})
        report = client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/agreement", headers=admin).json()
        assert len(report["disagreements"]) == 2 and report["pairs"][0]["exact_agreement"] == pytest.approx(4 / 6, abs=1e-4)
        assert isinstance(report["pairs"][0]["kappa"], float) and -1.0 <= report["pairs"][0]["kappa"] <= 1.0

        refused = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/freeze", headers=admin)
        assert refused.status_code == 409 and _error(refused)["details"]["count"] == 2, refused.text
        assert _error(refused)["code"] == "annotation_batch_incomplete"

        # adjudication is a separate permission from labelling, and each decision is recorded
        for n, label in ((3, "negative"), (5, "neutral")):
            decided = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/adjudications", headers=admin,
                                  json={"interaction_id": items[n]["interaction_id"], "label": label, "note": "adjudicated"})
            assert decided.status_code == 200, decided.text
            assert decided.json()["final_label"] == label

        frozen = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/freeze", headers=admin)
        assert frozen.status_code == 200 and frozen.json()["status"] == "frozen" and frozen.json()["items_decided"] == 6
        assert frozen.json()["frozen_at"]

        # after freezing nothing changes: no labels, no adjudications, no second freeze
        late = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/labels", headers=admin,
                           json={"interaction_id": items[0]["interaction_id"], "label": "positive"})
        assert late.status_code == 409 and _error(late)["code"] == "annotation_batch_frozen"
        assert client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/freeze", headers=admin).status_code == 409

        # export is in the shape the evaluation reads, and evaluation carries the synthetic flag through
        exported = client.get(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/export", headers=admin).json()
        assert exported["rows"] == 6
        assert {row["label"] for row in exported["labelled"]} <= {"positive", "negative", "neutral", "mixed"}
        assert all(set(row) >= {"text", "label"} for row in exported["labelled"])

        evaluated = client.post(f"/api/v1/signals/sentiment/annotation-batches/{batch_id}/evaluate", headers=admin)
        assert evaluated.status_code == 201, evaluated.text
        body = evaluated.json()
        assert body["is_synthetic"] is False, "these are real texts, so the result is not a synthetic one"
        assert body["evaluation"]["metrics"] and body["evaluation"]["rows"] == 6, "the evaluation reports on the six labelled texts"
        metrics = body["evaluation"]["metrics"]
        assert {"rows", "covered", "coverage", "accuracy_on_covered"} <= set(metrics), "coverage is reported next to accuracy"
        assert metrics["rows"] == 6 and 0 <= metrics["coverage"] <= 1
        assert body["batch"]["status"] == "frozen"

        # the list view shows the progress a reviewer needs
        listing = client.get("/api/v1/signals/sentiment/annotation-batches", headers=admin).json()
        assert listing["total"] >= 1 and listing["items"][0]["items"] == 6

        # a second batch with the same name is refused, and an empty tenant has nothing to label
        clash = client.post("/api/v1/signals/sentiment/annotation-batches", headers=admin, json={"name": "support sample 1", "sample": 5})
        assert clash.status_code == 409 and _error(clash)["code"] == "annotation_batch_exists"


def test_the_batch_draws_only_text_a_person_can_judge(demo):
    demo.drain()
    with demo.client() as client:
        admin = demo.login(client, "admin")
        made = client.post("/api/v1/signals/sentiment/annotation-batches", headers=admin, json={"name": "short draw", "sample": 3})
        assert made.status_code == 201, made.text
        assert made.json()["is_synthetic"] is True, "a batch says where its text came from, and synthetic is the default"
        items = _items(client, admin, made.json()["id"])
        assert items and all(len(item["text"]) >= 20 for item in items), "text too short to judge is not put in front of a reviewer"

        # the sample is not the same list every time by accident: an explicit set is respected exactly
        wanted = [item["interaction_id"] for item in items[:2]]
        picked = client.post("/api/v1/signals/sentiment/annotation-batches", headers=admin,
                             json={"name": "chosen by hand", "sample": 5, "interaction_ids": wanted})
        assert picked.status_code == 201, picked.text
        assert sorted(item["interaction_id"] for item in _items(client, admin, picked.json()["id"])) == sorted(wanted)

        # a text that is not part of the batch cannot be labelled through it
        other = annotations.LABELS  # keeps the import honest without inventing an id
        assert "positive" in other
