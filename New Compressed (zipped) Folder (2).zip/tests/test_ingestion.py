"""Ingestion: immutable dataset versions, mapping, validation, quarantine, idempotency, reconciliation,
REST pulls (against a real local HTTP server) and signed webhooks."""

from __future__ import annotations

import json
import stat
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import func, select

from churn_platform import security, storage
from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import Conflict, NotFound, Unauthorized, ValidationFailed
from churn_platform.models import (
    AuditEvent,
    Customer,
    DatasetVersion,
    DataSource,
    EntityHistory,
    ImportRun,
    Invoice,
    Job,
    QuarantineRecord,
    Subscription,
    UsageEvent,
    WebhookEvent,
)
from churn_platform.services import ingestion, jobs
from churn_platform.worker.runner import Worker
from tests.conftest import activate
from tests.fakes import RestApi as _Api

pytestmark = pytest.mark.req("REQ-DATA-02")

CUSTOMERS = """customer_id,company,email,industry,employees,acquired_at
C1,Acme Ltd,ops@acme.example,software,120,2025-01-10
C2,Beta GmbH,hello@beta.example,retail,15,2025-02-11
C3,Gamma SA,team@gamma.example,finance,300,2025-03-12
"""


def source(principal, name: str, entity: str, **kw) -> int:
    with session_scope() as s:
        return ingestion.create_source(s, principal, name=name, entity_type=entity, **kw).id


def upload(principal, source_id: int, file_name: str, content: str | bytes, *, mode: str = "full", mapping: dict | None = None) -> ImportRun:
    path = ingestion.new_temp_path(Path(file_name).suffix)
    path.write_bytes(content.encode() if isinstance(content, str) else content)
    with session_scope() as s:
        src = s.get(DataSource, source_id)
        dv, _ = ingestion.register_file(s, source=src, tmp_path=path, file_name=file_name, created_by=principal.user_id, actor=principal)
        if mapping is not None:
            ingestion.set_mapping(s, principal, src, mapping)
        run, _ = ingestion.start_import(s, principal, source_id, dataset_version_id=dv.id, mode=mode)
        run_id = run.id
    Worker().drain()
    with read_session() as s:
        return s.get(ImportRun, run_id)


def quarantined(run_id: int) -> list[QuarantineRecord]:
    with read_session() as s:
        return list(s.execute(select(QuarantineRecord).where(QuarantineRecord.import_run_id == run_id).order_by(QuarantineRecord.row_number)).scalars())


@pytest.fixture
def acme(empty):
    tid = empty.tenant()
    return empty, tid, empty.user(tid, "admin")


# ----------------------------------------------------------------------------- versions and raw storage
def test_raw_files_become_immutable_checksummed_versions(acme):
    _, _tid, admin = acme
    sid = source(admin, "crm customers", "customers")
    run = upload(admin, sid, "customers.csv", CUSTOMERS)
    assert (run.status, run.rows_read, run.rows_inserted, run.rows_quarantined) == ("completed", 3, 3, 0)
    with read_session() as s:
        dv = s.get(DatasetVersion, run.dataset_version_id)
        path = storage.resolve(dv.storage_path)
        assert not Path(dv.storage_path).is_absolute(), "locations are stored relative to the data directory"
        assert (dv.version_no, dv.row_count, dv.file_format, dv.origin, dv.is_synthetic) == (1, 3, "csv", "upload", False)
        assert dv.checksum_sha256 == ingestion.sha256_file(path)[0] and path.read_text() == CUSTOMERS
        assert stat.S_IMODE(path.stat().st_mode) == 0o444, "raw data is read-only on disk"
        assert [c["name"] for c in dv.schema["columns"]] == ["customer_id", "company", "email", "industry", "employees", "acquired_at"]
        row = s.execute(select(Customer).where(Customer.external_id == "C1")).scalar_one()
        assert (row.name, row.employee_count, row.dataset_version_id, row.source_row, row.record_version) == ("Acme Ltd", 120, dv.id, 1, 1)
    # the same bytes again are recognised, not stored twice
    tmp = ingestion.new_temp_path(".csv")
    tmp.write_text(CUSTOMERS)
    with session_scope() as s:
        again, duplicate = ingestion.register_file(s, source=s.get(DataSource, sid), tmp_path=tmp, file_name="renamed.csv", created_by=admin.user_id)
        assert duplicate is True and again.id == run.dataset_version_id and not tmp.exists()
    # a changed file is a new version that points at its parent
    run2 = upload(admin, sid, "customers.csv", CUSTOMERS.replace("Acme Ltd", "Acme Limited"))
    with read_session() as s:
        dv2 = s.get(DatasetVersion, run2.dataset_version_id)
        assert (dv2.version_no, dv2.parent_version_id) == (2, run.dataset_version_id)


def test_empty_and_unreadable_uploads_are_refused_without_leaving_files(acme):
    _empty, _, admin = acme
    sid = source(admin, "customers", "customers")
    for name, content, message in (("empty.csv", b"", "empty"), ("bad.csv", b"id,id\n1,2\n", "unique"), ("data.pdf", b"%PDF", "cannot determine")):
        tmp = ingestion.new_temp_path(Path(name).suffix)
        tmp.write_bytes(content)
        with pytest.raises(ValidationFailed, match=message), session_scope() as s:
            ingestion.register_file(s, source=s.get(DataSource, sid), tmp_path=tmp, file_name=name, created_by=admin.user_id)
        if name != "data.pdf":
            assert not tmp.exists()
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(DatasetVersion)).scalar_one() == 0


def test_tampered_or_missing_raw_file_fails_the_import_permanently(acme):
    _, _, admin = acme
    sid = source(admin, "customers", "customers")
    run = upload(admin, sid, "customers.csv", CUSTOMERS)
    with read_session() as s:
        path = storage.resolve(s.get(DatasetVersion, run.dataset_version_id).storage_path)
    path.chmod(0o644)
    path.write_text(CUSTOMERS.replace("C1", "CX"))
    with session_scope() as s:
        rerun, job = ingestion.start_import(s, admin, sid)
        rerun_id, job_id = rerun.id, job.id
    Worker().drain()
    with read_session() as s:
        assert (s.get(ImportRun, rerun_id).status, s.get(Job, job_id).status, s.get(Job, job_id).attempts) == ("failed", "failed", 1)
        assert "integrity check" in s.get(ImportRun, rerun_id).error
        assert s.execute(select(func.count()).select_from(Customer).where(Customer.external_id == "CX")).scalar_one() == 0
    path.unlink()
    with session_scope() as s:
        rerun_id = ingestion.start_import(s, admin, sid)[0].id
    Worker().drain()
    with read_session() as s:
        assert "missing from storage" in s.get(ImportRun, rerun_id).error


# ----------------------------------------------------------------------------- validation, quarantine, reconciliation
def test_bad_rows_are_quarantined_with_reasons_and_every_row_is_accounted_for(acme):
    _, _, admin = acme
    sid = source(admin, "customers", "customers")
    content = CUSTOMERS + "\n".join([
        ",No Id Ltd,x@example.com,software,10,2025-01-01",          # row 4: missing required id
        "C5,Bad Date Ltd,y@example.com,software,10,31/12/2025",      # row 5: ambiguous date
        "C6,Bad Number Ltd,z@example.com,software,many,2025-01-01",  # row 6: not a number
        "C2,Beta GmbH,hello@beta.example,retail,15,2025-02-11",      # row 7: exact duplicate of row 2
        "C3,Gamma CONFLICT,team@gamma.example,finance,300,2025-03-12",  # row 8: same id, different values
    ]) + "\n"  # fmt: skip
    run = upload(admin, sid, "customers.csv", content)
    assert run.status == "completed"
    assert (run.rows_read, run.rows_inserted, run.rows_duplicate, run.rows_quarantined, run.rows_updated) == (8, 3, 1, 4, 0)
    recon = run.reconciliation
    assert recon["balanced"] is True and recon["rows_in_file"] == recon["rows_read"] == recon["accounted_for"] == 8
    assert recon["rows_written_expected"] == recon["rows_written_in_database"] == 3
    reasons = {q.row_number: q.reasons for q in quarantined(run.id)}
    assert set(reasons) == {4, 5, 6, 8}
    assert reasons[4] == ["missing required field 'external_id'"]
    assert "acquired_at" in reasons[5][0] and "not a recognised date/time" in reasons[5][0]
    assert "employee_count" in reasons[6][0]
    assert "conflicting values (first seen at row 3)" in reasons[8][0]
    with read_session() as s:
        assert s.execute(select(Customer.name).where(Customer.external_id == "C3")).scalar_one() == "Gamma SA", "first occurrence wins; the conflict is not guessed"
        assert s.execute(select(func.count()).select_from(Customer)).scalar_one() == 3
        assert quarantined(run.id)[0].payload["company"] == "No Id Ltd", "the original raw row is kept for review"


def test_reimport_is_idempotent_and_changes_create_history(acme):
    _, _, admin = acme
    sid = source(admin, "customers", "customers")
    first = upload(admin, sid, "customers.csv", CUSTOMERS)
    with session_scope() as s:
        again_id = ingestion.start_import(s, admin, sid, dataset_version_id=first.dataset_version_id)[0].id
    Worker().drain()
    with read_session() as s:
        again = s.get(ImportRun, again_id)
        assert (again.status, again.rows_inserted, again.rows_updated, again.rows_unchanged) == ("completed", 0, 0, 3)
        assert again.reconciliation["balanced"] and s.execute(select(func.count()).select_from(EntityHistory)).scalar_one() == 0
    changed = upload(admin, sid, "customers_v2.csv", CUSTOMERS.replace("software,120", "software,150") + "C4,Delta BV,d@delta.example,media,8,2025-04-01\n")
    assert (changed.rows_inserted, changed.rows_updated, changed.rows_unchanged) == (1, 1, 2)
    with read_session() as s:
        row = s.execute(select(Customer).where(Customer.external_id == "C1")).scalar_one()
        assert (row.employee_count, row.record_version, row.dataset_version_id) == (150, 2, changed.dataset_version_id)
        history = s.execute(select(EntityHistory)).scalar_one()
        assert (history.entity_id, history.before, history.after, history.change_source) == (row.id, {"employee_count": 120}, {"employee_count": 150}, "import")
        untouched = s.execute(select(Customer).where(Customer.external_id == "C2")).scalar_one()
        assert (untouched.record_version, untouched.dataset_version_id) == (1, first.dataset_version_id), "unchanged rows keep their lineage"


def test_references_are_resolved_and_orphans_wait_in_quarantine_until_reprocessed(acme):
    _, _, admin = acme
    customers, subs = source(admin, "customers", "customers"), source(admin, "subscriptions", "subscriptions")
    upload(admin, customers, "customers.csv", CUSTOMERS)
    run = upload(admin, subs, "subs.csv", "id,customer_id,start_date,mrr,billing_period\nS1,C1,2025-01-10,99.90,monthly\nS9,C9,2025-05-01,10,monthly\n")
    assert (run.rows_inserted, run.rows_quarantined) == (1, 1)
    orphan = quarantined(run.id)[0]
    assert orphan.reasons == ["unknown customer reference 'C9'"]
    with read_session() as s:
        sub = s.execute(select(Subscription).where(Subscription.external_id == "S1")).scalar_one()
        assert sub.customer_id == s.execute(select(Customer.id).where(Customer.external_id == "C1")).scalar_one() and sub.mrr == Decimal("99.9000")
    with session_scope() as s:
        assert ingestion.review_quarantine(s, admin, [orphan.id], "reprocess") == {"rejected": 0, "corrected": 0, "reprocessed": 0, "still_failing": 1}
    upload(admin, customers, "more.csv", "customer_id,company\nC9,Late Parent Ltd\n")
    with session_scope() as s:
        assert ingestion.review_quarantine(s, admin, [orphan.id], "reprocess")["reprocessed"] == 1
    with read_session() as s:
        assert s.execute(select(func.count()).select_from(Subscription)).scalar_one() == 2
        assert s.get(QuarantineRecord, orphan.id).status == "reprocessed" and s.get(ImportRun, run.id).rows_quarantined == 0
    with session_scope() as s, pytest.raises(Conflict, match="already reprocessed"):
        ingestion.review_quarantine(s, admin, [orphan.id], "reject")


def test_quarantine_correct_reject_and_validation(acme):
    empty, _, admin = acme
    sid = source(admin, "customers", "customers")
    run = upload(admin, sid, "c.csv", "customer_id,company,employees\nC1,Acme,many\nC2,Beta,lots\n")
    a, b = (q.id for q in quarantined(run.id))
    with session_scope() as s, pytest.raises(ValidationFailed, match="no corrected payload"):
        ingestion.review_quarantine(s, admin, [a], "correct")
    with session_scope() as s:
        out = ingestion.review_quarantine(s, admin, [a], "correct", corrected={a: {"customer_id": "C1", "company": "Acme", "employees": "25"}}, note="fixed typo")
        assert out["corrected"] == 1
        assert ingestion.review_quarantine(s, admin, [a], "reprocess")["reprocessed"] == 1
        assert ingestion.review_quarantine(s, admin, [b], "reject", note="junk")["rejected"] == 1
    with read_session() as s:
        assert s.execute(select(Customer.employee_count).where(Customer.external_id == "C1")).scalar_one() == 25
        assert s.get(QuarantineRecord, a).payload["employees"] == "many", "the original payload is preserved next to the correction"
        assert s.get(QuarantineRecord, b).status == "rejected" and s.get(QuarantineRecord, b).review_note == "junk"
    other = empty.user(empty.tenant("other", "Other"), "admin")
    for ids, action, error in (([a], "explode", ValidationFailed), ([], "reject", ValidationFailed), ([999_999], "reject", NotFound)):
        with session_scope() as s, pytest.raises(error):
            ingestion.review_quarantine(s, admin, ids, action)
    with session_scope() as s, pytest.raises(NotFound):
        ingestion.review_quarantine(s, other, [b], "reject")


def test_money_control_totals_are_exact(acme):
    _, _, admin = acme
    upload(admin, source(admin, "customers", "customers"), "customers.csv", CUSTOMERS)
    lines = ["id,customer_id,invoice_date,amount,status"] + [f"I{n},C1,2025-06-{n:02d},0.10,paid" for n in range(1, 11)] + ["I11,C2,2025-06-11,\"1,234.56\",paid", "I12,C3,2025-06-12,-5,paid"]
    run = upload(admin, source(admin, "invoices", "invoices"), "invoices.csv", "\n".join(lines) + "\n")
    assert (run.rows_inserted, run.rows_quarantined) == (11, 1)
    assert run.reconciliation["control_total"] == {"field": "amount", "file": "1235.5600", "database": "1235.5600"} and run.reconciliation["balanced"]
    with read_session() as s:
        assert sum(s.execute(select(Invoice.amount)).scalars()) == Decimal("1235.56"), "ten times 0.10 is exactly 1.00"
    assert "amount must not be negative" in quarantined(run.id)[0].reasons[0]


def test_explicit_mapping_defaults_and_mapping_errors(acme):
    _, _, admin = acme
    sid = source(admin, "customers", "customers")
    mapping = {"external_id": "Ref", "name": "Title", "industry": {"default": "unknown"}, "country": {"source": "Land", "default": "DE"}}
    run = upload(admin, sid, "odd.csv", "Ref,Title,Land\nX1,Xavier AG,\nX2,Yvonne KG,AT\n", mapping=mapping)
    assert run.rows_inserted == 2 and run.mapping_version == 2, "the auto-suggested mapping (v1) was replaced by the explicit one"
    with read_session() as s:
        rows = {c.external_id: (c.name, c.industry, c.country) for c in s.execute(select(Customer)).scalars()}
    assert rows == {"X1": ("Xavier AG", "unknown", "DE"), "X2": ("Yvonne KG", "unknown", "AT")}
    for bad, message in (({"external_id": "Ref", "favourite_colour": "x"}, "not a canonical field"), ({"name": "Title"}, "required canonical fields are not mapped"),
                         ({"external_id": {"nothing": 1}}, "must be a source column name")):  # fmt: skip
        with pytest.raises(ValidationFailed, match=message):
            ingestion.validate_mapping("customers", bad)
    # a file whose columns cannot be matched automatically cannot be imported until it is mapped
    other = source(admin, "unmappable", "subscriptions")
    tmp = ingestion.new_temp_path(".csv")
    tmp.write_text("a,b\n1,2\n")
    with session_scope() as s:
        ingestion.register_file(s, source=s.get(DataSource, other), tmp_path=tmp, file_name="x.csv", created_by=admin.user_id)
    with session_scope() as s, pytest.raises(ValidationFailed, match="required canonical fields are not mapped"):
        ingestion.start_import(s, admin, other)


@pytest.mark.req("REQ-DATA-02")
def test_a_mapping_that_points_at_a_column_the_file_lacks_is_refused_before_anything_is_quarantined(acme):
    """DEF-034: a typo in the mapping (or a renamed column in a new delivery) used to quarantine every row of the file."""
    _, _, admin = acme
    assert upload(admin, source(admin, "customers", "customers"), "customers.csv", CUSTOMERS).rows_inserted == 3
    sid = source(admin, "logins", "usage_events")

    def register(file_name: str, content: str, mapping: dict) -> int:
        tmp = ingestion.new_temp_path(Path(file_name).suffix)
        tmp.write_text(content)
        with session_scope() as s:
            src = s.get(DataSource, sid)
            dv, _ = ingestion.register_file(s, source=src, tmp_path=tmp, file_name=file_name, created_by=admin.user_id, actor=admin)
            ingestion.set_mapping(s, admin, src, mapping)
            return dv.id

    def counts() -> tuple[int, int, int]:
        with read_session() as s:
            return tuple(s.execute(select(func.count()).select_from(m).where(*w)).scalar_one() for m, w in (
                (ImportRun, [ImportRun.source_id == sid]), (QuarantineRecord, []), (UsageEvent, [])))  # fmt: skip

    typo = {"customer_external_id": "customer", "occurred_at": "when", "event_type": "kind"}  # the file calls it "what"
    version = register("logins.csv", "customer,when,what\nC1,2026-01-05T08:00:00Z,login\nC2,2026-01-06T09:00:00Z,login\n", typo)
    with session_scope() as s, pytest.raises(ValidationFailed) as refused:
        ingestion.start_import(s, admin, sid, dataset_version_id=version)
    assert refused.value.code == "mapped_column_missing" and refused.value.status_code == 422
    assert refused.value.details == {"missing": ["kind"], "columns_in_file": ["customer", "what", "when"]}
    assert "'kind' (mapped to event_type)" in refused.value.message
    assert counts() == (0, 0, 0), "no import run, nothing quarantined, nothing loaded"
    # a default makes the column optional: the rows load with the default
    with session_scope() as s:
        ingestion.set_mapping(s, admin, s.get(DataSource, sid), {**typo, "event_type": {"source": "kind", "default": "login"}})
        run_id = ingestion.start_import(s, admin, sid, dataset_version_id=version)[0].id
    Worker().drain()
    with read_session() as s:
        run = s.get(ImportRun, run_id)
        assert (run.status, run.rows_inserted, run.rows_quarantined) == ("completed", 2, 0)
        assert {e.event_type for e in s.execute(select(UsageEvent)).scalars()} == {"login"}
    # an OPTIONAL field mapped to an absent column is tolerated (deliveries may omit optional columns)
    optional = {"customer_external_id": "customer", "occurred_at": "when", "event_type": "what", "feature_name": "module"}
    run = upload(admin, sid, "optional.csv", "customer,when,what\nC3,2026-01-07T10:00:00Z,feature_use\n", mapping=optional, mode="incremental")
    assert (run.status, run.rows_inserted, run.rows_quarantined) == ("completed", 1, 0), [q.reasons for q in quarantined(run.id)]
    # JSON has no header: a key may simply be absent from the rows that were profiled, so the check only
    # applies when every row was profiled
    lines = "".join(json.dumps({"customer": "C1", "when": f"2026-02-0{i + 1}T08:00:00Z", "what": "login"}) + "\n" for i in range(3))
    small = register("small.jsonl", lines, typo)
    with session_scope() as s, pytest.raises(ValidationFailed) as refused_json:
        ingestion.start_import(s, admin, sid, dataset_version_id=small)
    assert refused_json.value.code == "mapped_column_missing"
    with read_session() as s:
        schema = s.get(DatasetVersion, small).schema
    assert (schema["row_count"], schema["sampled_rows"]) == (3, 3)
    partially_profiled = DatasetVersion(file_format="jsonl", schema={**schema, "row_count": 5003})
    header_only = DatasetVersion(file_format="csv", schema={"columns": [], "row_count": 0, "sampled_rows": 0})
    ingestion.require_mapped_columns("usage_events", typo, partially_profiled)  # no error: the key may appear in a later row
    ingestion.require_mapped_columns("usage_events", typo, header_only)  # nothing is known about the columns
    with pytest.raises(ValidationFailed):
        ingestion.require_mapped_columns("usage_events", typo, DatasetVersion(file_format="csv", schema={**schema, "row_count": 5003}))


def test_incremental_import_skips_rows_at_or_before_the_cursor(acme):
    _, _, admin = acme
    upload(admin, source(admin, "customers", "customers"), "customers.csv", CUSTOMERS)
    sid = source(admin, "usage", "usage_events", config={"cursor_field": "occurred_at"})
    header = "customer_id,timestamp,event,feature_name\n"
    first = upload(admin, sid, "day1.csv", header + "C1,2026-01-01T08:00:00Z,login,\nC1,2026-01-01T09:00:00Z,feature_use,reports\n", mode="incremental")
    assert first.rows_inserted == 2 and first.cursor_before is None and first.cursor_after.startswith("2026-01-01T09:00:00")
    second = upload(admin, sid, "day2.csv", header + "C1,2026-01-01T09:00:00Z,feature_use,reports\nC2,2026-01-02T10:00:00Z,login,\n", mode="incremental")
    assert (second.rows_read, second.rows_inserted, second.reconciliation["skipped_by_cursor"], second.reconciliation["balanced"]) == (2, 1, 1, True)
    assert second.cursor_before == first.cursor_after and second.cursor_after.startswith("2026-01-02T10:00:00")
    # events without an id get a deterministic content hash, so replaying a file cannot double-count usage
    replay = upload(admin, sid, "day2_again.csv", header + "C2,2026-01-02T10:00:00Z,login,\n\n", mode="full")
    assert (replay.rows_inserted, replay.rows_unchanged) == (0, 1)


@pytest.mark.req("REQ-SEC-04")
def test_tenants_are_isolated(acme):
    empty, tid, admin = acme
    other_tid = empty.tenant("other", "Other Ltd")
    other = empty.user(other_tid, "admin")
    sid = source(admin, "customers", "customers")
    upload(admin, sid, "customers.csv", CUSTOMERS)
    upload(other, source(other, "customers", "customers"), "customers.csv", CUSTOMERS.replace("Acme Ltd", "Other Acme"))
    with read_session() as s:
        names = dict(s.execute(select(Customer.tenant_id, Customer.name).where(Customer.external_id == "C1")).all())
    assert names == {tid: "Acme Ltd", other_tid: "Other Acme"}, "the same external id lives independently in each tenant"
    with session_scope() as s, pytest.raises(NotFound):
        ingestion.start_import(s, other, sid)
    with session_scope() as s, pytest.raises(Conflict, match="already exists"):
        ingestion.create_source(s, admin, name="customers", entity_type="customers")
    for kwargs, message in (({"name": "", "entity_type": "customers"}, "name is required"), ({"name": "x", "entity_type": "widgets"}, "entity_type must be one of"),
                            ({"name": "x", "entity_type": "customers", "kind": "ftp"}, "kind must be one of"),
                            ({"name": "x", "entity_type": "customers", "kind": "webhook"}, "signing secret"),
                            ({"name": "x", "entity_type": "customers", "kind": "webhook", "webhook_secret": "short"}, "at least 16"),
                            ({"name": "x", "entity_type": "customers", "kind": "rest_api", "config": {}}, "config.url")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            ingestion.create_source(s, admin, **kwargs)


# ----------------------------------------------------------------------------- webhooks
@pytest.mark.req("REQ-DATA-03")
def test_signed_webhooks_are_verified_deduplicated_and_imported(acme):
    _, _tid, admin = acme
    secret = "whsec_0123456789abcdef"
    sid = source(admin, "crm webhook", "customers", kind="webhook", webhook_secret=secret)
    with session_scope() as s:
        src = s.get(DataSource, sid)
        ingestion.set_mapping(s, admin, src, {"external_id": "id", "name": "name"})
        assert secret not in src.webhook_secret_enc and ingestion.source_view(src)["webhook_secret_set"] is True
    body = json.dumps({"event_id": "evt-1", "records": [{"id": "W1", "name": "Webhook One"}, {"id": "W2", "name": "Webhook Two"}]}).encode()
    signature = "sha256=" + security.hmac_sha256_hex(secret, body)
    for bad in (None, "", "sha256=" + "0" * 64, security.hmac_sha256_hex(secret, body)):
        with pytest.raises(Unauthorized) as exc, session_scope() as s:
            ingestion.receive_webhook(s, sid, body, bad, None)
        assert exc.value.code == "invalid_signature" and exc.value.status_code == 401
    with session_scope() as s, pytest.raises(Unauthorized):
        ingestion.receive_webhook(s, sid, body + b" ", signature, None)  # body changed after signing
    with session_scope() as s:
        accepted = ingestion.receive_webhook(s, sid, body, signature, None)
        assert accepted["status"] == "accepted" and accepted["records"] == 2
        assert ingestion.receive_webhook(s, sid, body, signature, None) == {"status": "duplicate", "event_id": accepted["event_id"]}
    Worker().drain()
    with read_session() as s:
        assert sorted(s.execute(select(Customer.external_id)).scalars()) == ["W1", "W2"]
        event = s.get(WebhookEvent, accepted["event_id"])
        assert (event.status, event.signature_valid) == ("processed", True)
        assert s.execute(select(DatasetVersion.origin)).scalar_one() == "webhook"
        rejected = s.execute(select(func.count()).select_from(AuditEvent).where(AuditEvent.action == "webhook.rejected")).scalar_one()
        assert rejected == 5, "rejected deliveries are audited"
    file_source = source(admin, "plain file source", "customers")
    with session_scope() as s, pytest.raises(NotFound):
        ingestion.receive_webhook(s, file_source, body, signature, None)
    not_json = b"<xml/>"
    with session_scope() as s, pytest.raises(ValidationFailed, match="JSON"):
        ingestion.receive_webhook(s, sid, not_json, "sha256=" + security.hmac_sha256_hex(secret, not_json), None)


# ----------------------------------------------------------------------------- REST pulls against a real HTTP server
@pytest.mark.req("REQ-DATA-03")
def test_rest_source_paginates_authenticates_retries_and_pulls_incrementally(acme, api_server):
    empty, _, admin = acme
    activate(empty.db_path, empty.data_dir, CHURN_INGEST_ALLOW_PRIVATE_HOSTS="true")
    config = {"url": f"{api_server}/customers", "records_path": "data", "cursor_field": "consent_updated_at",
              "pagination": {"type": "page", "page_size": 2}, "incremental": {"param": "since"}, "auth": {"type": "bearer", "secret": "rest-secret-token"}}  # fmt: skip
    sid = source(admin, "rest customers", "customers", kind="rest_api", config=config)
    with session_scope() as s:
        src = s.get(DataSource, sid)
        view = ingestion.source_view(src)
        assert "rest-secret-token" not in json.dumps(src.config) and view["config"]["auth"] == {"type": "bearer", "secret_set": True}
        ingestion.set_mapping(s, admin, src, {"external_id": "id", "name": "name", "consent_updated_at": "updated"})
        _, job = ingestion.start_import(s, admin, sid)
        job_id = job.id
    _Api.failures_left = 1  # the first request gets a 503 and must be retried
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
        assert job.status == "succeeded" and job.result["records_fetched"] == 3 and job.result["inserted"] == 3, job.error
        assert sorted(s.execute(select(Customer.external_id)).scalars()) == ["R1", "R2", "R3"]
        assert s.get(DataSource, sid).incremental_cursor.startswith("2026-01-03")
    pages = [q.get("page") for _, q, _ in _Api.seen]
    assert pages == ["1", "1", "2"] and all(auth == "Bearer rest-secret-token" for _, _, auth in _Api.seen)

    _Api.pages = [*_Api.pages, [{"id": "R4", "name": "Rest Four", "updated": "2026-01-04T00:00:00Z"}]]
    _Api.seen = []
    try:
        with session_scope() as s:
            job_id = ingestion.start_import(s, admin, sid, mode="incremental")[1].id
        Worker().drain()
        with read_session() as s:
            result = s.get(Job, job_id).result
        assert result["records_fetched"] == 1 and result["inserted"] == 1
        assert _Api.seen[0][1]["since"].startswith("2026-01-03"), "the stored cursor is sent to the API"
        with session_scope() as s:
            job_id = ingestion.start_import(s, admin, sid, mode="incremental")[1].id
        Worker().drain()
        with read_session() as s:
            assert s.get(Job, job_id).result == {"records_fetched": 0, "status": "no_new_records"}
    finally:
        _Api.pages = _Api.pages[:2]


def _due_now(job_id: int) -> None:
    with session_scope() as s:
        s.get(Job, job_id).run_after = utcnow()


@pytest.mark.req("REQ-DATA-03")
def test_a_pull_whose_import_failed_after_the_payload_was_stored_is_loaded_by_the_retry(acme, api_server, monkeypatch):
    """Storing and loading are separate commits.  A retry used to find the stored payload, call it a duplicate
    and report success, so the records were never loaded."""
    empty, _, admin = acme
    activate(empty.db_path, empty.data_dir, CHURN_INGEST_ALLOW_PRIVATE_HOSTS="true")
    config = {"url": f"{api_server}/customers", "records_path": "data", "pagination": {"type": "page", "page_size": 2},
              "auth": {"type": "bearer", "secret": "rest-secret-token"}}  # fmt: skip
    sid = source(admin, "rest customers", "customers", kind="rest_api", config=config)
    with session_scope() as s:
        ingestion.set_mapping(s, admin, s.get(DataSource, sid), {"external_id": "id", "name": "name"})
        job_id = ingestion.start_import(s, admin, sid)[1].id
    real_import, calls = ingestion._import_inline, []

    def flaky(*args, **kwargs):
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("database went away while loading")
        return real_import(*args, **kwargs)

    monkeypatch.setattr(ingestion, "_import_inline", flaky)
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
        assert (job.status, job.attempts) == ("queued", 1) and "database went away" in job.error
        assert s.execute(select(func.count()).select_from(DatasetVersion)).scalar_one() == 1, "the payload was stored"
        assert s.execute(select(func.count()).select_from(Customer)).scalar_one() == 0, "and nothing was loaded"
    _due_now(job_id)
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
        assert job.status == "succeeded" and job.result["status"] == "completed" and job.result["inserted"] == 3, job.result
        assert sorted(s.execute(select(Customer.external_id)).scalars()) == ["R1", "R2", "R3"]
        assert s.execute(select(func.count()).select_from(DatasetVersion)).scalar_one() == 1, "the same bytes are not stored twice"
    # the same payload again, now that it HAS been loaded, is a harmless duplicate
    with session_scope() as s:
        again = ingestion.start_import(s, admin, sid)[1].id
    Worker().drain()
    with read_session() as s:
        assert s.get(Job, again).result == {"records_fetched": 3, "status": "duplicate_payload", "dataset_version_id": 1}
        assert s.execute(select(func.count()).select_from(ImportRun).where(ImportRun.status == "completed")).scalar_one() == 1


@pytest.mark.req("REQ-DATA-03")
def test_fetched_records_that_cannot_be_mapped_stop_the_job_with_instructions_instead_of_retrying(acme, api_server):
    empty, _, admin = acme
    activate(empty.db_path, empty.data_dir, CHURN_INGEST_ALLOW_PRIVATE_HOSTS="true")
    config = {"url": f"{api_server}/customers", "records_path": "data", "pagination": {"type": "page", "page_size": 2},
              "auth": {"type": "bearer", "secret": "rest-secret-token"}}  # fmt: skip
    # the records have the keys id, name, updated: nothing a subscription import could use
    sid = source(admin, "rest subscriptions", "subscriptions", kind="rest_api", config=config)
    with session_scope() as s:
        job_id = ingestion.start_import(s, admin, sid)[1].id
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
        version = s.execute(select(DatasetVersion)).scalar_one()
        assert s.execute(select(func.count()).select_from(ImportRun)).scalar_one() == 0
        assert s.execute(select(func.count()).select_from(QuarantineRecord)).scalar_one() == 0
    assert (job.status, job.attempts) == ("failed", 1), "a mapping problem needs a person: it is not retried"
    assert f"stored as dataset version {version.version_no} but cannot be loaded" in job.error
    assert "required canonical fields are not mapped" in job.error and "then retry this job" in job.error
    assert len(_Api.seen) == 2, "the API was fetched once (two pages), not once per retry"
    # after the mapping is corrected, retrying the job loads the stored records... which then fail row validation
    # (no such customers), so every row is accounted for in quarantine rather than lost
    with session_scope() as s:
        ingestion.set_mapping(s, admin, s.get(DataSource, sid), {"external_id": "id", "customer_external_id": "name", "started_at": "updated"})
        jobs.retry(s, admin, job_id)
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
        assert job.status == "succeeded" and (job.result["read"], job.result["quarantined"], job.result["inserted"]) == (3, 3, 0), job.result
        assert job.result["reconciliation"]["balanced"] is True


@pytest.mark.req("REQ-DATA-03")
def test_webhook_deliveries_survive_a_failed_flush(acme, monkeypatch):
    _, _tid, admin = acme
    secret = "whsec_0123456789abcdef"
    sid = source(admin, "crm webhook", "customers", kind="webhook", webhook_secret=secret)
    with session_scope() as s:
        ingestion.set_mapping(s, admin, s.get(DataSource, sid), {"external_id": "id", "name": "name"})
    body = json.dumps({"event_id": "evt-9", "records": [{"id": "W9", "name": "Webhook Nine"}]}).encode()
    with session_scope() as s:
        accepted = ingestion.receive_webhook(s, sid, body, "sha256=" + security.hmac_sha256_hex(secret, body), None)
    real_import, calls = ingestion._import_inline, []

    def flaky(*args, **kwargs):
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("worker lost its database connection")
        return real_import(*args, **kwargs)

    monkeypatch.setattr(ingestion, "_import_inline", flaky)
    Worker().drain()
    with read_session() as s:
        assert s.get(WebhookEvent, accepted["event_id"]).status == "received", "a delivery is only marked processed once it is loaded"
        assert s.execute(select(func.count()).select_from(Customer)).scalar_one() == 0
    _due_now(accepted["job_id"])
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, accepted["job_id"])
        assert job.status == "succeeded" and job.result["status"] == "completed" and job.result["inserted"] == 1, job.result
        assert s.get(WebhookEvent, accepted["event_id"]).status == "processed"
        assert s.execute(select(Customer.external_id)).scalars().all() == ["W9"]


@pytest.mark.req("REQ-SEC-05")
def test_rest_sources_cannot_reach_private_addresses_or_follow_redirects(acme, api_server):
    empty, _, admin = acme
    for url, message in ((f"{api_server}/customers", "non-public address"), ("http://169.254.169.254/latest/meta-data", "non-public address"),
                         ("file:///etc/passwd", "absolute http"), ("ftp://example.com/x", "absolute http"), ("http://no-such-host.invalid/x", "cannot resolve")):  # fmt: skip
        with pytest.raises(ValidationFailed, match=message):
            ingestion.assert_fetchable_url(url)
    with session_scope() as s, pytest.raises(ValidationFailed, match="non-public address"):
        ingestion.create_source(s, admin, name="ssrf", entity_type="customers", kind="rest_api", config={"url": f"{api_server}/customers"})
    activate(empty.db_path, empty.data_dir, CHURN_INGEST_ALLOW_PRIVATE_HOSTS="true", CHURN_JOB_MAX_ATTEMPTS="1")
    sid = source(admin, "redirecting", "customers", kind="rest_api", config={"url": f"{api_server}/redirect"})
    with session_scope() as s:
        job_id = ingestion.start_import(s, admin, sid)[1].id
    Worker().drain()
    with read_session() as s:
        job = s.get(Job, job_id)
    assert job.status == "failed" and [path for path, _, _ in _Api.seen] == ["/redirect"], "a redirect is not followed"


@pytest.mark.req("REQ-SEC-06")
def test_forged_webhooks_cannot_flood_the_audit_trail(acme):
    """The receiver is public: every forged delivery is refused, but only a bounded number is written to the audit chain."""
    _, _tid, admin = acme
    secret = "whsec_0123456789abcdef"
    sid = source(admin, "billing webhook", "customers", kind="webhook", webhook_secret=secret)
    other = source(admin, "second webhook", "customers", kind="webhook", webhook_secret=secret)
    body = b'{"id": "W1"}'
    for _ in range(ingestion.REJECTION_AUDITS_PER_MINUTE + 15):
        with pytest.raises(Unauthorized), session_scope() as s:
            ingestion.receive_webhook(s, sid, body, "sha256=" + "0" * 64, None)
    with pytest.raises(Unauthorized), session_scope() as s:
        ingestion.receive_webhook(s, other, body, None, None)
    with read_session() as s:
        per_source = dict(s.execute(select(AuditEvent.entity_id, func.count()).where(AuditEvent.action == "webhook.rejected").group_by(AuditEvent.entity_id)).all())
    assert per_source == {str(sid): ingestion.REJECTION_AUDITS_PER_MINUTE == 20 and 20, str(other): 1}, "the limit is per source"
    # a correctly signed delivery is never throttled
    with session_scope() as s:
        assert ingestion.receive_webhook(s, sid, body, "sha256=" + security.hmac_sha256_hex(secret, body), None)["status"] == "accepted"
