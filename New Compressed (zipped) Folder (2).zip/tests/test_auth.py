"""Sign-in, sessions, lockout, MFA and user administration (service level)."""

from __future__ import annotations

import time
from datetime import timedelta

import pytest
from sqlalchemy import select, update

from churn_platform import security
from churn_platform.db import read_session, session_scope, utcnow
from churn_platform.errors import Conflict, Forbidden, NotFound, Unauthorized, ValidationFailed
from churn_platform.models import AuditEvent, AuthSession, User
from churn_platform.services import auth
from tests.conftest import PASSWORD, activate

pytestmark = pytest.mark.req("REQ-SEC-01")


def _login(email: str, password: str = PASSWORD, otp: str | None = None) -> dict:
    with session_scope() as s:
        return auth.login(s, email=email, password=password, otp=otp, ip="10.0.0.1", user_agent="pytest")


def _principal(token: str):
    return auth.authenticate_token(token)


def test_login_returns_token_once_and_stores_only_its_hash(empty):
    tid = empty.tenant()
    empty.user(tid, "admin", "admin@acme.example")
    out = _login("  ADMIN@acme.example ")
    assert out["user"]["email"] == "admin@acme.example" and "password_hash" not in out["user"] and "mfa_secret_enc" not in out["user"]
    with read_session() as s:
        row = s.execute(select(AuthSession)).scalar_one()
        assert row.token_hash == security.hash_token(out["token"]) and out["token"] not in row.token_hash
        assert row.ip == "10.0.0.1" and row.user_agent == "pytest"
    principal = _principal(out["token"])
    assert principal.role == "admin" and principal.tenant_id == tid and principal.can("admin:users")


def test_unknown_user_and_wrong_password_are_indistinguishable(empty):
    tid = empty.tenant()
    empty.user(tid, "viewer", "v@acme.example")
    errors = []
    for email, password in (("nobody@acme.example", PASSWORD), ("v@acme.example", "wrong-password-123")):
        with pytest.raises(Unauthorized) as exc:
            _login(email, password)
        errors.append((exc.value.code, str(exc.value)))
    assert errors[0] == errors[1] == ("invalid_credentials", "Invalid email or password")
    with read_session() as s:
        reasons = [e.detail["reason"] for e in s.execute(select(AuditEvent).where(AuditEvent.action == "auth.login_failed")).scalars()]
    assert sorted(reasons) == ["bad_password", "unknown_user"], "failed sign-ins are audited even though the request fails"


def test_lockout_after_repeated_failures_and_admin_reset(empty):
    tid = empty.tenant()
    admin = empty.user(tid, "admin", "admin@acme.example")
    target = empty.user(tid, "analyst", "a@acme.example")
    for _ in range(5):
        with pytest.raises(Unauthorized):
            _login("a@acme.example", "wrong-password-123")
    with pytest.raises(Unauthorized) as exc:
        _login("a@acme.example")  # correct password, but locked
    assert exc.value.code == "account_locked"
    with session_scope() as s:
        auth.update_user(s, admin, target.user_id, password="Another-Strong-Pass-77")
    assert _login("a@acme.example", "Another-Strong-Pass-77")["token"]


def test_lock_expires_on_its_own(empty):
    tid = empty.tenant()
    empty.user(tid, "analyst", "a@acme.example")
    with session_scope() as s:
        s.execute(select(User).where(User.email == "a@acme.example")).scalar_one().locked_until = utcnow() - timedelta(seconds=1)
    assert _login("a@acme.example")["token"]


def test_inactive_user_cannot_sign_in_and_existing_session_stops_working(empty):
    tid = empty.tenant()
    admin = empty.user(tid, "admin", "admin@acme.example")
    target = empty.user(tid, "viewer", "v@acme.example")
    token = _login("v@acme.example")["token"]
    with session_scope() as s:
        auth.update_user(s, admin, target.user_id, is_active=False)
    with pytest.raises(Unauthorized) as exc:
        _principal(token)
    assert exc.value.code == "session_revoked"
    with pytest.raises(Unauthorized) as exc:
        _login("v@acme.example")
    assert exc.value.code == "invalid_credentials"


def test_session_expiry_idle_timeout_and_logout(empty):
    tid = empty.tenant()
    empty.user(tid, "viewer", "v@acme.example")
    token = _login("v@acme.example")["token"]
    with session_scope() as s:
        s.execute(select(AuthSession)).scalar_one().last_seen_at = utcnow() - timedelta(minutes=121)
    with pytest.raises(Unauthorized) as exc:
        _principal(token)
    assert exc.value.code == "session_expired"
    with session_scope() as s:
        row = s.execute(select(AuthSession)).scalar_one()
        row.last_seen_at, row.expires_at = utcnow(), utcnow() - timedelta(seconds=1)
    with pytest.raises(Unauthorized) as exc:
        _principal(token)
    assert exc.value.code == "session_expired"

    token = _login("v@acme.example")["token"]
    principal = _principal(token)
    with session_scope() as s:
        auth.logout(s, principal)
    with pytest.raises(Unauthorized) as exc:
        _principal(token)
    assert exc.value.code == "session_revoked"
    for bad in (None, "", "not-a-token"):
        with pytest.raises(Unauthorized):
            _principal(bad)


def test_password_change_revokes_other_sessions_and_enforces_policy(empty):
    tid = empty.tenant()
    empty.user(tid, "viewer", "v@acme.example")
    first, second = _login("v@acme.example")["token"], _login("v@acme.example")["token"]
    me = _principal(second)
    with session_scope() as s, pytest.raises(ValidationFailed, match="current password"):
        auth.change_password(s, me, "wrong", "Brand-New-Password-55")
    with session_scope() as s, pytest.raises(ValidationFailed, match="at least 12"):
        auth.change_password(s, me, PASSWORD, "short1")
    with session_scope() as s:
        auth.change_password(s, me, PASSWORD, "Brand-New-Password-55")
    assert _principal(second).user_id == me.user_id, "the session that changed the password stays signed in"
    with pytest.raises(Unauthorized):
        _principal(first)
    with pytest.raises(Unauthorized):
        _login("v@acme.example")
    assert _login("v@acme.example", "Brand-New-Password-55")["token"]


def test_mfa_enrolment_login_and_replay(empty):
    tid = empty.tenant()
    empty.user(tid, "admin", "admin@acme.example")
    me = _principal(_login("admin@acme.example")["token"])
    with session_scope() as s:
        begin = auth.mfa_begin(s, me)
    secret = begin["secret"]
    assert begin["otpauth_uri"].startswith("otpauth://totp/") and secret in begin["otpauth_uri"]
    with read_session() as s:
        stored = s.get(User, me.user_id).mfa_secret_enc
    assert secret not in stored, "the TOTP secret is encrypted at rest"
    with session_scope() as s, pytest.raises(ValidationFailed, match="one-time code"):
        auth.mfa_confirm(s, me, "000000" if security.totp_code(secret) != "000000" else "111111")
    # confirm with the previous time step so that the current step is still unused for the login below
    with session_scope() as s:
        auth.mfa_confirm(s, me, security.totp_code(secret, at=time.time() - 30))
    with session_scope() as s, pytest.raises(Conflict):
        auth.mfa_begin(s, me)

    with pytest.raises(Unauthorized) as exc:
        _login("admin@acme.example")
    assert exc.value.code == "mfa_required"
    with pytest.raises(Unauthorized) as exc:
        _login("admin@acme.example", otp="12345x")
    assert exc.value.code == "invalid_credentials"
    code = security.totp_code(secret)
    assert _login("admin@acme.example", otp=code)["token"]
    with pytest.raises(Unauthorized):
        _login("admin@acme.example", otp=code)  # same code again: replay is refused
    with session_scope() as s, pytest.raises(ValidationFailed):
        auth.mfa_disable(s, me, "wrong")
    with session_scope() as s:
        auth.mfa_disable(s, me, PASSWORD)
    assert _login("admin@acme.example")["token"]


def test_enabling_mfa_ends_every_session_that_was_opened_with_the_password_alone(empty):
    """DEF-029: `mfa_verified` was stored but never enforced, so a password-only session outlived the enrolment."""
    tid = empty.tenant()
    empty.user(tid, "admin", "admin@acme.example")
    mine, stolen = _login("admin@acme.example")["token"], _login("admin@acme.example")["token"]
    me = _principal(mine)
    with session_scope() as s:
        secret = auth.mfa_begin(s, me)["secret"]
    assert _principal(stolen).user_id == me.user_id, "before the enrolment both sessions work"
    with session_scope() as s:
        auth.mfa_confirm(s, me, security.totp_code(secret, at=time.time() - 30))
    with read_session() as s:
        sessions = {row.id: row for row in s.execute(select(AuthSession).where(AuthSession.user_id == me.user_id)).scalars()}
    assert sessions[me.session_id].mfa_verified is True and sessions[me.session_id].revoked_at is None, "this session proved the code"
    other = next(row for sid, row in sessions.items() if sid != me.session_id)
    assert other.revoked_reason == "mfa_enabled" and other.mfa_verified is False
    assert _principal(mine).user_id == me.user_id
    with pytest.raises(Unauthorized) as exc:
        _principal(stolen)
    assert exc.value.code == "session_revoked"
    # even if such a session is not revoked (restored backup, manual edit), it cannot be used
    with session_scope() as s:
        s.execute(update(AuthSession).where(AuthSession.id == other.id).values(revoked_at=None, revoked_reason=None))
    with pytest.raises(Unauthorized) as exc:
        _principal(stolen)
    assert exc.value.code == "mfa_required" and str(exc.value.message) == "Sign in again with a one-time code"
    fresh = _login("admin@acme.example", otp=security.totp_code(secret))
    with read_session() as s:
        assert s.execute(select(AuthSession.mfa_verified).order_by(AuthSession.id.desc())).scalars().first() is True
    assert _principal(fresh["token"]).user_id == me.user_id


def test_mfa_can_be_mandatory_for_a_role(empty, monkeypatch):
    tid = empty.tenant()
    empty.user(tid, "admin", "admin@acme.example")
    activate(empty.db_path, empty.data_dir, CHURN_MFA_REQUIRED_ROLES="admin")
    out = _login("admin@acme.example")
    assert out["mfa_enrollment_required"] is True
    principal = _principal(out["token"])
    assert principal.mfa_enrollment_required and principal.permissions == frozenset(), "no permissions until MFA is set up"


def test_user_administration_rules(empty):
    tid = empty.tenant()
    admin = empty.user(tid, "admin", "admin@acme.example")
    with session_scope() as s, pytest.raises(Conflict):
        auth.create_user(s, tenant_id=tid, email="ADMIN@acme.example", full_name="Dup", role="viewer", password=PASSWORD)
    with session_scope() as s, pytest.raises(ValidationFailed, match="role"):
        auth.create_user(s, tenant_id=tid, email="x@acme.example", full_name="X", role="root", password=PASSWORD)
    with session_scope() as s, pytest.raises(ValidationFailed, match="password"):
        auth.create_user(s, tenant_id=tid, email="x@acme.example", full_name="X", role="viewer", password="weak")
    with session_scope() as s, pytest.raises(ValidationFailed, match="email"):
        auth.create_user(s, tenant_id=tid, email="not-an-email", full_name="X", role="viewer", password=PASSWORD)
    with session_scope() as s, pytest.raises(Forbidden, match="own role"):
        auth.update_user(s, admin, admin.user_id, role="viewer")
    with session_scope() as s, pytest.raises(Forbidden, match="deactivate yourself"):
        auth.update_user(s, admin, admin.user_id, is_active=False)
    other_tenant = empty.tenant("other", "Other Ltd")
    stranger = empty.user(other_tenant, "viewer", "v@other.example")
    with session_scope() as s, pytest.raises(NotFound):
        auth.update_user(s, admin, stranger.user_id, role="admin")
    with session_scope() as s, pytest.raises(Conflict):
        auth.create_tenant(s, "acme", "Again")
    with session_scope() as s, pytest.raises(ValidationFailed):
        auth.create_tenant(s, "Bad Slug!", "Bad")


def test_session_revocation_permissions(empty):
    tid = empty.tenant()
    empty.user(tid, "admin", "admin@acme.example")
    empty.user(tid, "viewer", "v@acme.example")
    empty.user(tid, "analyst", "a@acme.example")
    admin, viewer, analyst = (_principal(_login(e)["token"]) for e in ("admin@acme.example", "v@acme.example", "a@acme.example"))
    with session_scope() as s, pytest.raises(Forbidden):
        auth.revoke_session(s, viewer, analyst.session_id)
    with session_scope() as s:
        assert auth.revoke_session(s, admin, analyst.session_id).revoked_reason == "revoked_by_admin"
        assert auth.revoke_session(s, viewer, viewer.session_id).revoked_reason == "revoked_by_user"
