"""The schema the session is in must be the schema the configuration names (1.3.0, BUG 2).

The reproduction this file was written from, run against the code as it stood at ``b4fd131``, with a stand-in session
that reports ``OTHER_SCHEMA`` while the configuration says ``PUBLIC``::

    configured schema PUBLIC, session schema OTHER_SCHEMA -> {'ok': True, 'session': {... 'schema': 'OTHER_SCHEMA'},
                                                              'health': 'the session answered and matches the configuration'}

A green tick, and a lie.  The 1.2.0 check compared the warehouse and the database, ignored the schema, the account and
the region, and treated a value the session did not report as agreement — three separate ways to pass while pointing at
the wrong place.  It also built its statements by pasting configured names into SQL, and refused a table name containing
``;`` as its only defence.

What this file holds the code to: **read the session back and compare it with the configuration, field by field; a silent
value is a mismatch; and validate every configured identifier before quoting it.**  It proves nothing about a real
Snowflake account — no account exists here — and GATE 12 stays BLOCKED for that reason.
"""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from churn_platform.errors import ValidationFailed
from churn_platform.services import export_record as record
from churn_platform.services.destinations import snowflake

pytestmark = pytest.mark.req("REQ-ACT-02")


def _session(**overrides) -> tuple:
    values = {"version": "8.20.0", "user": "CHURN_SVC", "role": "CHURN_WRITER", "warehouse": "CHURN_WH", "database": "CHURN_DB",
                  "schema": "PUBLIC", "account": "XY12345", "region": "EU-WEST-1"}  # fmt: skip
    values.update(overrides)
    return tuple(values[key] for key in ("version", "user", "role", "warehouse", "database", "schema", "account", "region"))


class Cursor:
    def __init__(self, connection):
        self.connection = connection
        self.description = None
        self._rows: list[tuple] = []

    def execute(self, statement, parameters=None):
        self.connection.statements.append(statement)
        rows = self.connection.answer(statement, parameters)
        self.description = [("col",)] if rows is not None else None
        self._rows = rows or []
        return self

    def fetchall(self):
        return self._rows

    def close(self):
        return None


class Connection:
    """A stand-in session.  ``answer`` is the only thing that pretends to be Snowflake, and it says so."""

    def __init__(self, *, session: tuple | None = None, raise_on_select: BaseException | None = None):
        self.session = session or _session()
        self.raise_on_select = raise_on_select
        self.statements: list[str] = []

    def cursor(self):
        return Cursor(self)

    def answer(self, statement, parameters=None):
        if "CURRENT_VERSION" in statement.upper():
            if self.raise_on_select is not None:
                raise self.raise_on_select
            return [self.session]
        if "COUNT(*)" in statement.upper():
            return [(0,)]
        return None

    def close(self):
        return None


def _destination(connection: Connection, **config) -> snowflake.SnowflakeDestination:
    options = {"account": "xy12345.eu-west-1", "user": "CHURN_SVC", "warehouse": "CHURN_WH", "database": "CHURN_DB",
                   "schema": "PUBLIC", "role": "CHURN_WRITER"}  # fmt: skip
    options.update(config)
    return snowflake.SnowflakeDestination(config=snowflake.SnowflakeConfig(**options), connect=lambda **_: connection)


# --------------------------------------------------------------------------- the defect
def test_schema_mismatch_fails_validation():
    """The exact defect: configured PUBLIC, session OTHER_SCHEMA, and the connection must be refused."""
    with pytest.raises(ValidationFailed) as refused:
        _destination(Connection(session=_session(schema="OTHER_SCHEMA"))).test_connection()
    assert "schema is OTHER_SCHEMA, configured PUBLIC" in refused.value.message
    assert refused.value.details["session"]["schema"] == "OTHER_SCHEMA"
    assert refused.value.details["configured"]["schema"] == "PUBLIC"


@pytest.mark.parametrize(
    ("field", "reported", "compared"),
    [
        ("warehouse", "OTHER_WH", "configured CHURN_WH"),
        ("database", "OTHER_DB", "configured CHURN_DB"),
        ("role", "SYSADMIN", "configured CHURN_WRITER"),
        ("account", "AB99999", "configured XY12345"),
        ("region", "US-EAST-1", "configured EU-WEST-1"),
    ],
)
def test_every_compared_field_refuses_a_session_that_is_not_the_configuration(field, reported, compared):
    """``xy12345.eu-west-1`` is compared as the account locator and the region the surface actually reports."""
    with pytest.raises(ValidationFailed) as refused:
        _destination(Connection(session=_session(**{field: reported}))).test_connection()
    assert f"{field} is {reported}" in refused.value.message
    assert compared in refused.value.message


def test_a_value_the_session_does_not_report_is_a_mismatch_not_an_agreement():
    """1.2.0 skipped the comparison when the session returned nothing: silence was a pass."""
    with pytest.raises(ValidationFailed) as refused:
        _destination(Connection(session=_session(schema=None))).test_connection()
    assert "schema is not reported by the session, configured PUBLIC" in refused.value.message


def test_case_is_not_a_difference_but_a_different_name_is():
    health = _destination(Connection(session=_session(schema="public", warehouse="churn_wh"))).test_connection()
    assert health["ok"] is True, "Snowflake upper-cases unquoted names; case alone cannot be a mismatch"
    with pytest.raises(ValidationFailed):
        _destination(Connection(session=_session(schema="PUBLIC_2"))).test_connection()


def test_a_connection_that_cannot_be_made_is_refused_with_its_kind_rather_than_escaping():
    with pytest.raises(ValidationFailed) as refused:
        _destination(Connection(raise_on_select=OSError("250001: Could not connect to Snowflake backend"))).test_connection()
    assert refused.value.details["kind"] == "connection"
    assert "OSError" in refused.value.message

    with pytest.raises(ValidationFailed) as timed_out:
        _destination(Connection(raise_on_select=TimeoutError("login timeout"))).test_connection()
    assert timed_out.value.details["kind"] == "timeout"


def test_the_health_report_names_what_was_compared_and_how_the_transport_is_protected():
    health = _destination(Connection()).test_connection()
    assert health["ok"] is True
    assert set(health["compared"]) == {"account", "region", "warehouse", "database", "schema", "role"}
    assert health["tls"]["verified"] is True
    assert "insecure_mode" in health["tls"]["mechanism"], "the claim says what it rests on, not just that it holds"
    assert health["session"]["account"] == "XY12345"


def test_a_configuration_that_turns_off_tls_is_refused_before_a_connection_is_attempted():
    connection = Connection()
    with pytest.raises(ValidationFailed) as refused:
        _destination(connection, tls=False).test_connection()
    assert "tls must not be disabled" in refused.value.message
    assert connection.statements == [], "nothing reached the network"


def test_a_region_that_was_not_configured_is_not_compared():
    health = _destination(Connection(session=_session(region="AP-SOUTHEAST-2")), account="xy12345").test_connection()
    assert health["ok"] is True and "region" not in health["compared"]


# --------------------------------------------------------------------------- identifiers
@pytest.mark.parametrize("name", ["PUBLIC", "CHURN_DB", "DB_2", "_STAGE", "A$B", "ORDER", "SELECT"])
def test_a_usable_identifier_is_accepted_and_quoted(name):
    assert snowflake.quote(name) == f'"{name.upper()}"'


@pytest.mark.parametrize("name", ["", " ", "DB; DROP TABLE X", 'A"B', "A B", "1ABC", "A\nB", "x" * 256, None])
def test_an_unusable_identifier_is_refused(name):
    with pytest.raises(ValidationFailed):
        snowflake.quote(name)


def test_a_reserved_word_is_a_working_table_name_and_an_injection_is_not_a_table_name():
    assert snowflake.ddl(table="ORDER").startswith('CREATE TABLE IF NOT EXISTS "ORDER"')
    with pytest.raises(ValidationFailed):
        snowflake.ddl(table="T; DROP TABLE X")


def test_configuration_problems_name_the_offending_identifier():
    assert snowflake.SnowflakeConfig(account="a", user="u", warehouse="W", database="D", table="T; DROP TABLE X").problems()
    problems = snowflake.SnowflakeConfig(account="a", user="u", warehouse="W", database="D", schema="PUBLIC; --").problems()
    assert any(problem.startswith("schema") and "PUBLIC; --" in problem for problem in problems), problems


def test_no_configured_name_reaches_a_statement_without_being_quoted():
    """Every statement the adapter issues quotes the names it was configured with."""
    destination = _destination(Connection(), database="CHURN_DB", schema="PUBLIC", table="CHURN_PREDICTIONS",
                               runs_table="CHURN_EXPORT_RUNS")  # fmt: skip
    destination.test_connection()
    destination.ensure_schema()
    destination.count_stored(run_id="run-1")
    destination.record_run(run_id="run-1", tenant_id=1, expected=1, written=1, checksum="c" * 64, watermark=None,
                           actor="tester", started_at=datetime(2026, 11, 10, tzinfo=UTC))  # fmt: skip
    issued = [statement for statement in destination._conn().statements if "CURRENT_VERSION" not in statement]
    assert issued, "the adapter issued statements"
    for statement in issued:
        for bare in ("FROM CHURN_PREDICTIONS", "INTO CHURN_PREDICTIONS", "INTO CHURN_EXPORT_RUNS",
                     'PRIMARY KEY (RUN_ID)'):  # fmt: skip
            assert bare not in statement, bare
    assert any('"CHURN_PREDICTIONS"' in statement for statement in issued)
    assert any('"CHURN_EXPORT_RUNS"' in statement for statement in issued)


def test_the_ddl_covers_every_field_of_the_canonical_record():
    statement = snowflake.ddl()
    for definition in record.FIELDS:
        assert f'"{definition.name.upper()}"' in statement, definition.name
