"""Model training (imbalance handling, temporal CV, calibration) and evaluation (PR-AUC first, cost-based threshold)."""

from __future__ import annotations

from decimal import Decimal

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sqlalchemy import select

from churn_platform import storage
from churn_platform.db import read_session, session_scope
from churn_platform.errors import Conflict, NotFound, ValidationFailed
from churn_platform.models import AuditEvent, MLDataset, ModelEvaluation, ModelRun
from churn_platform.services import evaluation, mlprep, training
from churn_platform.services.policies import CostMatrix

pytestmark = pytest.mark.req("REQ-ML-04")
BRIEF_COST = {"currency": "USD", "intervention_cost": "50", "clv": "5000", "contribution_margin": "1", "save_rate": "1",
              "evidence": "Example figures from the project brief ($50 offer, $5,000 lost customer)", "is_example": True}  # fmt: skip


def _problem(n: int = 600, positives: float = 0.08, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < positives).astype(int)
    X = rng.normal(size=(n, 6)) + y[:, None] * np.array([1.5, -1.0, 0.5, 0.0, 0.0, 0.0])
    return X, y


@pytest.fixture
def splits(ro):
    with read_session() as s:
        dataset = s.get(MLDataset, ro.summary["dataset_id"])
    train, valid = mlprep.load_split(dataset, "train"), mlprep.load_split(dataset, "valid")
    names = [c for c in train.columns if c not in mlprep.META_COLUMNS]
    return dataset, train, valid, names


# ----------------------------------------------------------------------------- algorithms and class imbalance
def test_all_four_algorithms_are_installed():
    status = training.algorithm_status()
    assert set(status) == set(training.ALGORITHMS) == {"logistic_regression", "random_forest", "xgboost", "lightgbm"}
    assert all(s["available"] and s["version"] for s in status.values()), status


@pytest.mark.parametrize("algorithm", training.ALGORITHMS)
def test_class_weighting_is_wired_into_each_algorithm(algorithm):
    X, y = _problem()
    ratio = (len(y) - y.sum()) / y.sum()
    weighted = training.build_estimator(algorithm, training.DEFAULTS[algorithm], "class_weight", y, seed=1).named_steps["model"]
    plain = training.build_estimator(algorithm, training.DEFAULTS[algorithm], "none", y, seed=1).named_steps["model"]
    if algorithm == "logistic_regression":
        assert (weighted.class_weight, plain.class_weight) == ("balanced", None)
    elif algorithm == "random_forest":
        assert (weighted.class_weight, plain.class_weight) == ("balanced_subsample", None)
    else:
        assert weighted.get_params()["scale_pos_weight"] == pytest.approx(ratio) and plain.get_params()["scale_pos_weight"] == 1.0
    assert training.resolve_imbalance(algorithm, "auto") == "class_weight" and training.resolve_imbalance(algorithm, "smote") == "smote"
    model = training.build_estimator(algorithm, training.DEFAULTS[algorithm], "class_weight", y, seed=1).fit(X, y)
    p = model.predict_proba(X)[:, 1]
    assert p.shape == (len(y),) and np.isfinite(p).all() and p.min() >= 0 and p.max() <= 1
    assert roc_auc_score(y, p) > 0.8, "the planted signal is learnt"
    # weighting the minority class raises its predicted probabilities
    unweighted = training.build_estimator(algorithm, training.DEFAULTS[algorithm], "none", y, seed=1).fit(X, y).predict_proba(X)[:, 1]
    assert p[y == 1].mean() > unweighted[y == 1].mean()


@pytest.mark.parametrize("algorithm", training.ALGORITHMS)
def test_a_fitted_model_gives_the_same_bytes_on_every_call_and_every_refit(algorithm):
    """A forest predicting on two threads adds up its trees in the order the threads finish, so the last bits moved from call to call."""
    X, y = _problem(n=1500)

    def fit():
        return training.fit_estimator(training.build_estimator(algorithm, training.DEFAULTS[algorithm], "class_weight", y, seed=1), X, y)

    model = fit()
    answers = {model.predict_proba(X)[:, 1].tobytes() for _ in range(25)}
    assert len(answers) == 1, f"{len(answers)} different answers to the same question in 25 calls"
    assert fit().predict_proba(X)[:, 1].tobytes() in answers, "the same rows and seed fit the same model"


def test_the_stored_forest_scores_and_evaluates_identically_every_time(ro, splits):
    _dataset, _train, valid, names = splits
    with read_session() as s:
        run = s.execute(select(ModelRun).where(ModelRun.algorithm == "random_forest")).scalar_one()
    bundle = training.load_bundle(run)
    assert bundle["model"].named_steps["model"].n_jobs == 1, "prediction order must not depend on thread timing"
    y = valid["label"].to_numpy()
    scored = [training.predict_proba(bundle, valid[names]) for _ in range(25)]
    assert len({p.tobytes() for p in scored}) == 1
    assert len({repr(evaluation.core_metrics(y, p, seed=1, bootstrap=0)) for p in scored}) == 1


class _SpySampler:
    def __init__(self) -> None:
        from imblearn.over_sampling import SMOTE

        self.inner, self.seen = SMOTE(random_state=0, k_neighbors=3), []

    def fit_resample(self, X, y):
        self.seen.append((len(y), int(np.sum(y))))
        return self.inner.fit_resample(X, y)

    def get_params(self, deep=False):
        return {}

    def set_params(self, **params):
        return self


def test_smote_resamples_only_the_data_being_fitted_never_the_data_being_scored():
    X, y = _problem()
    spy = _SpySampler()
    model = training.build_estimator("logistic_regression", {"C": 0.1}, "smote", y[:400], seed=1, sampler=spy)
    assert [name for name, _ in model.steps] == ["scale", "smote", "model"]
    model.fit(X[:400], y[:400])
    assert spy.seen == [(400, int(y[:400].sum()))], "resampling happened once, on the training rows"
    p = model.predict_proba(X[400:])[:, 1]
    assert len(p) == 200 and len(spy.seen) == 1, "scoring never resamples: 200 rows in, 200 probabilities out"
    with pytest.raises(ValueError, match="at least two positive"):
        training.build_estimator("logistic_regression", {"C": 0.1}, "smote", np.array([0, 0, 0, 1]), seed=1)
    with pytest.raises(ValueError, match="unknown algorithm"):
        training.build_estimator("svm", {}, "none", y, seed=1)


def test_smote_inside_cross_validation_sees_fit_folds_only(splits, monkeypatch):
    from imblearn.over_sampling import SMOTE

    dataset, train, valid, names = splits
    seen: list[int] = []
    original = SMOTE.fit_resample

    def spying(self, X, y, **kw):
        seen.append(len(y))
        return original(self, X, y, **kw)

    monkeypatch.setattr(SMOTE, "fit_resample", spying)
    result = training.fit_one("logistic_regression", "smote", train, valid, dataset.preprocessing, names, 30, 0, n_iter=2, cv_folds=3, seed=7)
    folds = result["search"]["folds"]
    fit_sizes = {int(train["as_of_date"].astype(str).isin(f["fit_dates"]).sum()) for f in folds}
    assert set(seen) <= fit_sizes | {len(train)} and len(valid) not in seen
    assert len(seen) == result["search"]["n_iter"] * len(folds) + 1, "one resampling per candidate and fold, plus the final fit on TRAIN"
    assert result["bundle"]["imbalance"] == "smote" and 0 <= result["valid_metrics"]["pr_auc"] <= 1


def test_hyperparameter_candidates_are_deterministic_and_start_from_the_defaults():
    for algorithm in training.ALGORITHMS:
        first, again = training.sample_candidates(algorithm, 5, seed=3), training.sample_candidates(algorithm, 5, seed=3)
        assert first == again and first[0] == training.DEFAULTS[algorithm]
        assert len({repr(sorted(c.items(), key=str)) for c in first}) == len(first) <= 5
        assert all(c[k] in training.SEARCH_SPACE[algorithm][k] for c in first[1:] for k in c)
        assert training.sample_candidates(algorithm, 5, seed=4) != first or algorithm == "logistic_regression"
    assert len(training.sample_candidates("logistic_regression", 40, seed=0)) == 7, "the search stops when the space is exhausted"


# ----------------------------------------------------------------------------- fitting
def test_fit_is_temporally_cross_validated_calibrated_out_of_fold_and_reproducible(splits):
    dataset, train, valid, names = splits
    a = training.fit_one("logistic_regression", "class_weight", train, valid, dataset.preprocessing, names, 30, 0, n_iter=3, cv_folds=3, seed=7)
    b = training.fit_one("logistic_regression", "class_weight", train, valid, dataset.preprocessing, names, 30, 0, n_iter=3, cv_folds=3, seed=7)
    assert a["search"]["selection_metric"].startswith("mean PR-AUC") and a["search"]["n_iter"] == 3
    for fold in a["search"]["folds"]:
        assert max(fold["fit_dates"]) < min(fold["validate_dates"]), "each fold validates on later dates"
        gap = pd.Timestamp(min(fold["validate_dates"])) - pd.Timestamp(max(fold["fit_dates"]))
        assert gap >= pd.Timedelta(days=30), "the fit label windows are closed before the fold's validation starts"
    best = max(a["search"]["candidates"], key=lambda c: c["cv_pr_auc_mean"])
    assert a["params"] == best["params"] and a["cv_metrics"]["pr_auc_mean"] == best["cv_pr_auc_mean"], "the candidate with the best CV PR-AUC is refitted"
    assert a["calibration"]["method"] == "sigmoid" and a["calibration"]["fitted_on"] == "out-of-fold predictions of the TRAIN split"
    pa, pb = training.predict_proba(a["bundle"], valid), training.predict_proba(b["bundle"], valid)
    np.testing.assert_array_equal(pa, pb)
    assert a["valid_metrics"] == b["valid_metrics"] and a["valid_metrics"]["n"] == len(valid)
    assert a["valid_metrics"]["pr_auc"] == pytest.approx(average_precision_score(valid["label"], pa))
    # calibrated probabilities are on the scale of the base rate: class weighting alone would inflate them
    raw, _ = training.raw_scores(a["bundle"], valid)
    assert raw.mean() > 3 * pa.mean() and abs(pa.mean() - train["label"].mean()) < 0.05
    assert a["calibration"]["valid_brier_calibrated"] < a["calibration"]["valid_brier_raw"]
    # the calibration map is monotone: it never reverses a ranking.  Raw scores below one in a million (or above
    # 0.999999) share one calibrated value, so there - and only there - customers can tie
    by_raw = np.argsort(raw, kind="stable")
    assert (np.diff(pa[by_raw]) >= 0).all(), "a higher raw score never gets a lower probability"
    inside = (raw > 1e-6) & (raw < 1 - 1e-6)
    assert inside.sum() > 0.5 * len(raw) and len(np.unique(pa[inside])) == len(np.unique(raw[inside])), "no ties where nothing was clipped"
    assert roc_auc_score(valid["label"][inside], raw[inside]) == pytest.approx(roc_auc_score(valid["label"][inside], pa[inside]))
    assert abs(roc_auc_score(valid["label"], raw) - roc_auc_score(valid["label"], pa)) < 0.005
    # scoring needs exactly the contract's columns, in any order, and nothing about the label
    shuffled = valid[list(reversed(names))]
    np.testing.assert_array_equal(training.predict_proba(a["bundle"], shuffled), pa)


def test_training_refuses_impossible_cross_validation(splits):
    from churn_platform.services import jobs

    dataset, train, valid, names = splits
    no_churn = train.assign(label=0)
    with pytest.raises(jobs.PermanentJobError, match="no fold has churners on both sides"):
        training.fit_one("logistic_regression", "class_weight", no_churn, valid, dataset.preprocessing, names, 30, 0, n_iter=1, cv_folds=3, seed=7)


def test_seeded_runs_record_search_calibration_and_integrity_checked_artifacts(ro):
    with read_session() as s:
        runs = s.execute(select(ModelRun).where(ModelRun.tenant_id == ro.tenant_id).order_by(ModelRun.id)).scalars().all()
        board = training.leaderboard(s, ro.tenant_id)
    assert [r.algorithm for r in runs] == list(training.ALGORITHMS) and all(r.status == "completed" for r in runs)
    assert [r.is_baseline for r in runs] == [True, False, False, False], "logistic regression is the interpretable baseline"
    for run in runs:
        assert run.imbalance_strategy == "class_weight" and run.seed == 7 and len(run.group_id) == 12
        assert run.search["cv_folds"] >= 2 and len(run.search["candidates"]) == run.search["n_iter"] == 3
        assert 0 < run.cv_metrics["pr_auc_mean"] <= 1 and len(run.cv_metrics["folds"]) == run.search["cv_folds"]
        assert run.valid_metrics["pr_auc"] > run.valid_metrics["pr_auc_baseline"], "better than ranking at random"
        assert not run.artifact_path.startswith("/") and len(run.artifact_sha256) == 64
        assert training.sha256_path(storage.resolve(run.artifact_path)) == run.artifact_sha256
    ranked = [b["valid_pr_auc"] for b in board]
    assert ranked == sorted(ranked, reverse=True) and board[0]["algorithm"] == "xgboost"
    assert sum(b["test_pr_auc"] is not None for b in board) == 1, "TEST was spent on one model only"
    assert "artifact_path" not in board[0]
    bundle = training.load_bundle(runs[0])
    assert bundle["run_id"] == runs[0].id and bundle["horizon_days"] == 30 and len(bundle["features"]) == 84
    assert set(bundle["library_versions"]) == set(training.ALGORITHMS)


def test_a_modified_model_file_is_never_loaded(demo):
    with read_session() as s:
        run = s.execute(select(ModelRun).where(ModelRun.algorithm == "xgboost")).scalar_one()
    path = storage.resolve(run.artifact_path)
    training._BUNDLE_CACHE.clear()
    path.write_bytes(path.read_bytes() + b"\x00")
    with pytest.raises(RuntimeError, match="failed its SHA-256 integrity check"):
        training.load_bundle(run)
    path.unlink()
    with pytest.raises(RuntimeError, match="missing from storage"):
        training.load_bundle(run)


def test_training_requests_are_validated_and_one_failing_algorithm_does_not_hide_the_others(demo, monkeypatch):
    admin = demo.principal("admin")
    dataset_id = demo.summary["dataset_id"]
    for overrides, message in (({"algorithms": ["svm"]}, "algorithms must be chosen"), ({"imbalance": "oversample"}, "imbalance must be one of"),
                               ({"n_iter": 0}, "n_iter must be"), ({"n_iter": 41}, "n_iter must be"), ({"cv_folds": 1}, "n_iter must be")):  # fmt: skip
        with session_scope() as s, pytest.raises(ValidationFailed, match=message):
            training.start_training(s, admin, dataset_id=dataset_id, **overrides)
    with session_scope() as s, pytest.raises(NotFound):
        training.start_training(s, admin, dataset_id=999_999)
    real = training.build_estimator

    def flaky(algorithm, *args, **kwargs):
        if algorithm == "xgboost":
            raise RuntimeError("simulated library failure")
        return real(algorithm, *args, **kwargs)

    monkeypatch.setattr(training, "build_estimator", flaky)
    with session_scope() as s:
        runs, job = training.start_training(s, admin, dataset_id=dataset_id, algorithms=["logistic_regression", "xgboost"], n_iter=1, cv_folds=2, seed=11)
        run_ids, job_id = [r.id for r in runs], job.id
    from churn_platform.models import Job
    from churn_platform.worker.runner import Worker

    Worker().drain()
    with read_session() as s:
        lr, xgb = (s.get(ModelRun, i) for i in run_ids)
        job = s.get(Job, job_id)
    assert (lr.status, xgb.status, job.status) == ("completed", "failed", "succeeded")
    assert "simulated library failure" in xgb.error and xgb.artifact_path is None and lr.seed == 11
    assert [r["status"] for r in job.result["runs"]] == ["completed", "failed"]


# ----------------------------------------------------------------------------- metrics
def test_headline_metrics_are_pr_auc_and_friends_not_accuracy():
    y = np.array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1])
    p = np.array([0.05, 0.1, 0.1, 0.2, 0.2, 0.3, 0.6, 0.7, 0.4, 0.9])
    m = evaluation.core_metrics(y, p, seed=1)
    assert "accuracy" not in m, "accuracy is misleading on imbalanced data and is deliberately not reported"
    assert m["pr_auc"] == pytest.approx(average_precision_score(y, p)) and m["roc_auc"] == pytest.approx(roc_auc_score(y, p))
    assert m["brier"] == pytest.approx(brier_score_loss(y, p)) and (m["n"], m["positives"], m["base_rate"], m["pr_auc_baseline"]) == (10, 2, 0.2, 0.2)
    assert m["pr_auc_lift_over_baseline"] == pytest.approx(m["pr_auc"] / 0.2)
    lo, hi = m["pr_auc_ci95"]
    assert 0 <= lo <= m["pr_auc"] <= hi <= 1 and "bootstrap" in m["pr_auc_ci_method"]
    assert evaluation.core_metrics(y, p, seed=1) == m, "the bootstrap is seeded"
    # a model that predicts "nobody churns" is 80% accurate here and still useless
    useless = evaluation.core_metrics(y, np.zeros(10), bootstrap=0)
    assert useless["pr_auc"] == pytest.approx(0.2) and useless["roc_auc"] == 0.5
    single = evaluation.core_metrics(np.zeros(5), np.full(5, 0.1))
    assert single["pr_auc"] is None and "single class" in single["note"]


def test_confusion_matrix_precision_and_recall_at_a_threshold():
    y = np.array([1, 0, 0, 1, 0])
    p = np.array([0.9, 0.8, 0.3, 0.2, 0.1])
    c = evaluation.confusion_at(y, p, 0.5)
    assert (c["tp"], c["fp"], c["fn"], c["tn"], c["flagged"]) == (1, 1, 1, 2, 2) and (c["precision"], c["recall"]) == (0.5, 0.5)
    assert evaluation.confusion_at(y, p, 0.2)["recall"] == 1.0 and evaluation.confusion_at(y, p, 0.2)["precision"] == 0.5, ">= threshold is flagged"
    nobody = evaluation.confusion_at(y, p, 0.95)
    assert (nobody["flagged"], nobody["precision"], nobody["recall"], nobody["f1"]) == (0, None, 0.0, None)
    assert evaluation.best_f1_threshold(y, p)["threshold"] in (0.2, 0.9)
    ece, table = evaluation.expected_calibration_error(np.array([0] * 10 + [1] * 10), np.array([0.0] * 10 + [1.0] * 10))
    assert ece == 0.0 and sum(row["n"] for row in table) == 20 and len(table) == 4, "equal-frequency bins"
    assert evaluation.expected_calibration_error(np.array([0] * 20), np.array([0.3] * 20))[0] == pytest.approx(0.3)


# ----------------------------------------------------------------------------- the cost matrix of the brief
def test_threshold_minimises_expected_cost_with_the_50_dollar_and_5000_dollar_example():
    y = np.array([1, 0, 0, 1, 0])
    p = np.array([0.9, 0.8, 0.3, 0.2, 0.1])
    out = evaluation.optimise_threshold(y, p, CostMatrix(**BRIEF_COST))
    by_threshold = {row["threshold"]: row for row in out["table"]}
    # flag nobody: two lost customers = 10,000.  Flag the top 1: 50 + 5,000.  Top 4 (both churners): 4 x 50 = 200.  Everyone: 250.
    assert out["do_nothing_cost"] == "10000.0000"
    assert (by_threshold[0.9]["flagged"], by_threshold[0.9]["total_cost"]) == (1, "5050.0000")
    assert (by_threshold[0.8]["flagged"], by_threshold[0.8]["total_cost"]) == (2, "5100.0000")
    assert (by_threshold[0.3]["flagged"], by_threshold[0.3]["total_cost"]) == (3, "5150.0000")
    assert (by_threshold[0.2]["flagged"], by_threshold[0.2]["total_cost"]) == (4, "200.0000")
    assert (by_threshold[0.1]["flagged"], by_threshold[0.1]["total_cost"]) == (5, "250.0000")
    best = out["optimal"]
    assert (best["threshold"], best["tp"], best["fp"], best["fn"], best["total_cost"], best["net_benefit_vs_no_action"]) == (0.2, 2, 2, 0, "200.0000", "9800.0000")
    assert out["recommendation"] == "intervene_above_threshold" and out["currency"] == "USD"
    assert out["is_example"] is True and out["disclaimer"].startswith("ILLUSTRATIVE ONLY"), "example money is never presented as fact"
    # a missed churner costs 100x a wasted offer, so the optimum trades precision (50%) for full recall
    assert (best["precision"], best["recall"]) == (0.5, 1.0)


def test_cost_assumptions_change_the_decision():
    y = np.array([1, 0, 0, 1, 0])
    p = np.array([0.9, 0.8, 0.3, 0.2, 0.1])
    half = evaluation.optimise_threshold(y, p, CostMatrix(**{**BRIEF_COST, "save_rate": "0.5"}))
    assert half["optimal"]["total_cost"] == "5200.0000", "4 offers (200) + half of the 10,000 still lost"
    capped = evaluation.optimise_threshold(y, p, CostMatrix(**{**BRIEF_COST, "capacity": 1}))
    assert (capped["optimal"]["threshold"], capped["optimal"]["flagged"], capped["optimal"]["total_cost"]) == (0.9, 1, "5050.0000")
    assert [r["within_capacity"] for r in capped["table"] if r["flagged"] > 1] and not any(r["within_capacity"] for r in capped["table"] if r["flagged"] > 1)
    per_date = evaluation.optimise_threshold(y, p, CostMatrix(**{**BRIEF_COST, "capacity": 2}), groups=np.array(["a", "b", "a", "b", "a"]))
    assert per_date["optimal"]["flagged"] == 4, "capacity applies per scoring date: 2 + 2 fits"
    pricey = evaluation.optimise_threshold(y, p, CostMatrix(**{**BRIEF_COST, "intervention_cost": "6000"}))
    assert pricey["recommendation"] == "no_threshold_beats_doing_nothing" and pricey["optimal"] == {
        "threshold": None, "flagged": 0, "total_cost": "10000.0000", "net_benefit_vs_no_action": "0.0000"}  # fmt: skip
    fixed = evaluation.optimise_threshold(y, p, CostMatrix(**{**BRIEF_COST, "campaign_fixed_cost": "1000"}))
    assert fixed["optimal"]["total_cost"] == "1200.0000"
    by_mrr = CostMatrix(currency="USD", intervention_cost="50", clv_mode="mrr_multiple", clv_months="12", contribution_margin="0.8", save_rate="1",
                        evidence="twelve months of margin per customer")  # fmt: skip
    valued = evaluation.optimise_threshold(y, p, by_mrr, mrr=np.array([100.0, 1.0, 1.0, 10.0, 1.0]))
    assert valued["do_nothing_cost"] == "1056.0000", "(100 + 10) x 12 months x 80% margin"
    assert valued["optimal"]["threshold"] == 0.9 and valued["optimal"]["total_cost"] == "146.0000", "saving the small account costs more than it is worth"
    assert valued["is_example"] is False and not valued["disclaimer"].startswith("ILLUSTRATIVE")
    with pytest.raises(ValidationFailed, match="no 'mrr' feature"):
        evaluation.optimise_threshold(y, p, by_mrr)
    assert isinstance(CostMatrix(**BRIEF_COST).intervention_cost, Decimal)


# ----------------------------------------------------------------------------- persisted evaluations and the TEST split
def test_seeded_evaluations_choose_the_threshold_on_validation_and_apply_it_to_test(ro):
    with read_session() as s:
        evals = s.execute(select(ModelEvaluation).where(ModelEvaluation.tenant_id == ro.tenant_id).order_by(ModelEvaluation.id)).scalars().all()
        champion = s.get(ModelRun, evals[-1].model_run_id)
    valid, test = next(e for e in evals if e.model_run_id == champion.id and e.split == "valid"), evals[-1]
    assert test.split == "test" and sum(e.split == "test" for e in evals) == 1
    for e in (valid, test):
        assert e.threshold_analysis["basis"] == "cost_matrix" and e.threshold_analysis["threshold_selected_on"] == "validation split"
        assert e.threshold_analysis["is_example"] is True and "ILLUSTRATIVE ONLY" in e.threshold_analysis["disclaimer"]
        assert e.metrics["at_threshold"]["threshold"] == e.threshold_analysis["threshold"]
        assert {"pr_auc", "roc_auc", "brier", "ece", "log_loss", "base_rate"} <= set(e.metrics) and "accuracy" not in e.metrics
        curves = e.curves
        assert curves["pr"]["recall"] == sorted(curves["pr"]["recall"]) and curves["roc"]["fpr"] == sorted(curves["roc"]["fpr"])
        assert len(curves["deciles"]) == 10 and curves["deciles"][-1]["cumulative_capture"] == 1.0
        assert sum(d["churners"] for d in curves["deciles"]) == e.metrics["positives"]
        assert set(e.subgroups) == set(evaluation.SEGMENT_FEATURES) and sum(g["n"] for g in e.subgroups["plan_tier"]) == e.metrics["n"]
    assert test.threshold_analysis["threshold"] == valid.threshold_analysis["threshold"], "the TEST threshold is the validation one, not re-optimised"
    outcome = test.threshold_analysis["test_outcome_at_validation_threshold"]
    assert abs(outcome["threshold"] - test.threshold_analysis["threshold"]) < 0.02 and outcome["flagged"] > 0
    assert champion.test_metrics["pr_auc"] == test.metrics["pr_auc"] and champion.test_evaluated_at is not None
    assert test.metrics["n"] == 424 and test.metrics["positives"] == 17, "small sample: reported with its confidence interval"
    assert test.metrics["pr_auc_ci95"][0] < test.metrics["pr_auc"] < test.metrics["pr_auc_ci95"][1]


def test_test_split_can_be_spent_exactly_once_per_model(demo):
    scientist = demo.principal("data_scientist")
    with read_session() as s:
        champion = s.execute(select(ModelRun).where(ModelRun.test_evaluated_at.is_not(None))).scalar_one()
        fresh = s.execute(select(ModelRun).where(ModelRun.algorithm == "random_forest")).scalar_one()
    with session_scope() as s, pytest.raises(Conflict) as again:
        evaluation.evaluate(s, scientist, champion.id, split="test")
    assert again.value.code == "test_already_evaluated" and again.value.details["evaluation_id"]
    with session_scope() as s:
        first = evaluation.evaluate(s, scientist, fresh.id, split="test")
        first_metrics, first_id = dict(first.metrics), first.id
        assert s.get(ModelRun, fresh.id).test_metrics["pr_auc"] == first_metrics["pr_auc"]
    with session_scope() as s, pytest.raises(Conflict) as second:
        evaluation.evaluate(s, scientist, fresh.id, split="test")
    assert second.value.code == "test_already_evaluated" and second.value.details == {"evaluation_id": first_id}
    with session_scope() as s:
        a = evaluation.evaluate(s, scientist, fresh.id, split="valid")
        b = evaluation.evaluate(s, scientist, fresh.id, split="valid")
        assert a.metrics == b.metrics, "validation can be re-evaluated freely and is deterministic"
        audited = s.execute(select(AuditEvent).where(AuditEvent.action == "ml.evaluated_test", AuditEvent.entity_id == str(fresh.id))).scalars().all()
        assert len(audited) == 1 and audited[0].actor_label == scientist.email
    with session_scope() as s, pytest.raises(ValidationFailed, match="split must be"):
        evaluation.evaluate(s, scientist, fresh.id, split="train")
    with session_scope() as s, pytest.raises(NotFound):
        evaluation.evaluate(s, scientist, 999_999)


def test_without_an_approved_cost_matrix_no_financial_claim_is_made(demo):
    from churn_platform.models import Policy

    scientist = demo.principal("data_scientist")
    with session_scope() as s:
        s.execute(Policy.__table__.update().where(Policy.kind == "cost_matrix").values(status="retired"))
        run_id = s.execute(select(ModelRun.id).where(ModelRun.algorithm == "xgboost")).scalar_one()
        result = evaluation.evaluate(s, scientist, run_id, split="valid")
        analysis = result.threshold_analysis
    assert analysis["basis"] == "max_f1" and "No approved cost matrix" in analysis["note"] and result.cost_policy_id is None
    assert "table" not in analysis and "optimal" not in analysis


# ----------------------------------------------------------------------------- a feature nobody has a value for
@pytest.mark.slow
@pytest.mark.req("REQ-ML-02", "REQ-ML-04", "REQ-ML-06", "REQ-OPS-03")
def test_a_source_without_user_identifiers_runs_the_whole_lifecycle_on_an_empty_feature(demo):
    """Daily active users needs a user identifier on usage events.  A source that never sends one leaves
    that feature empty for every customer on every date; nothing downstream may stumble or warn."""
    from sqlalchemy import update

    from churn_platform.models import DriftReport, FeatureRun, PredictionBatch, UsageEvent
    from churn_platform.services import explain, features, monitoring, predictions, registry

    admin, approver = demo.principal("admin"), demo.principal("approver")
    feature = "avg_daily_active_users_30d"
    with session_scope() as s:
        s.execute(update(UsageEvent).where(UsageEvent.tenant_id == demo.tenant_id).values(user_ref=None))
        seeded = s.execute(select(FeatureRun).where(FeatureRun.tenant_id == demo.tenant_id, FeatureRun.kind == "materialize")
                           .order_by(FeatureRun.id)).scalars().first()  # fmt: skip
        features.start_materialization(s, admin, contract_id=demo.summary["contract_id"], as_of_dates=list(seeded.as_of_dates))
    demo.drain()
    with session_scope() as s:
        dataset_id = mlprep.start_build(s, admin, name="no-user-identifiers", contract_id=demo.summary["contract_id"])[0].id
    demo.drain()
    with read_session() as s:
        dataset = s.get(MLDataset, dataset_id)
    train = mlprep.load_split(dataset, "train")
    assert train[feature].isna().all() and train["logins_30d"].notna().all()
    with session_scope() as s:
        runs, _job = training.start_training(s, admin, dataset_id=dataset_id, n_iter=1, cv_folds=2, seed=5)
        run_ids = [r.id for r in runs]
    demo.drain()
    with read_session() as s:
        trained = [s.get(ModelRun, i) for i in run_ids]
    assert {r.algorithm: (r.status, r.error) for r in trained} == dict.fromkeys(training.ALGORITHMS, ("completed", None))
    spec = training.load_bundle(trained[0])["prep"]
    assert spec["numeric"][feature] == {"median": 0.0, "indicator": True}  # a constant plus a "was missing" flag
    with session_scope() as s:
        for run_id in run_ids:
            evaluation.evaluate(s, admin, run_id, split="valid")
            assert explain.global_explanation(s, admin, run_id).status == "available"
        version = registry.register(s, admin, run_ids[0])
        evaluation.evaluate(s, admin, run_ids[0], split="test")
        registry.review(s, approver, version.id, approve=True, note="empty-feature model")
        registry.set_stage(s, admin, version.id, "production")
        batch_id = predictions.start_batch(s, admin, tenant_id=demo.tenant_id)[0].id
        monitoring.start(s, admin, tenant_id=demo.tenant_id, with_evidently=True)
    demo.drain()
    with read_session() as s:
        batch = s.get(PredictionBatch, batch_id)
        report = s.execute(select(DriftReport).where(DriftReport.tenant_id == demo.tenant_id, DriftReport.kind == "feature",
                                                     DriftReport.model_version_id == version.id)
                           .order_by(DriftReport.id.desc())).scalars().first()  # fmt: skip
    assert (batch.status, batch.failed, batch.succeeded) == ("completed", 0, demo.summary["batch"]["customers_scored"])
    drift = {e["feature"]: e for e in report.result["features"]}[feature]
    assert (drift["missing_reference"], drift["missing_current"], drift["psi"], drift["status"]) == (1.0, 1.0, 0.0, "ok")
    assert feature in report.result["evidently"]["excluded_columns"] and report.result["evidently"]["status"] == "available"
