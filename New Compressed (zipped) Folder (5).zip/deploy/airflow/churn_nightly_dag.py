"""Apache Airflow DAG: the nightly churn pipeline, one Airflow task per pipeline step.

    database_in_sync -> data_quality -> signals -> labels -> features -> scoring -> recommendations -> monitoring

Airflow owns the schedule, the order and the retries; the platform does the work.  Every task runs

    churn-platform pipeline-step --tenant <slug> --step <step> --run-key <DAG run id> --wait

which is idempotent per (tenant, step, run key): a retried task whose step already finished does nothing, a
retried task whose step is still running waits for the same jobs, and only a failed step is started again.  A
task therefore never scores a customer base twice, however often Airflow re-runs it.

REQUIRED on the platform side: set CHURN_ORCHESTRATOR=airflow for the API, the worker and the Airflow worker.
With that setting the platform's own nightly schedule stands down; without it the platform refuses these calls,
because otherwise every step would run twice.  A platform worker (`churn-platform worker`) must be running: the
task queues the step and waits for the worker to finish it (add `--inline` to run the jobs inside the task when
there is no separate worker).

The scoring step uses the model that the registry clears to serve.  With CHURN_MODEL_REGISTRY=mlflow that is the
version MLflow's `production` alias names (the latest validated and promoted model); see docs/ORCHESTRATION.md.

HOW FAR THIS WAS RUN is recorded per release in docs/ORCHESTRATION.md and CHANGELOG.md, not here.

Deployment: copy this file into the Airflow DAGs folder.  The Airflow worker needs the `churn-platform` package
and the same CHURN_* environment as the API (database URL, data directory, secret key).  Tenants come from the
Airflow Variable `churn_tenants` (comma-separated slugs).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable

try:  # Airflow 3, and Airflow 2 with the "standard" provider installed
    from airflow.providers.standard.operators.bash import BashOperator
except ImportError:  # Airflow 2 without that provider
    from airflow.operators.bash import BashOperator

STEPS = ("data_quality", "signals", "labels", "features", "scoring", "recommendations", "monitoring")
TENANTS = [slug.strip() for slug in Variable.get("churn_tenants", default_var="").split(",") if slug.strip()]
COMMAND = (
    "churn-platform pipeline-step --tenant {{ params.tenant }} --step {{ params.step }} "
    "--run-key '{{ dag_run.run_id }}' --dag-id {{ dag.dag_id }} --task-id {{ task.task_id }} --wait --timeout 10000"
)

with DAG(
    dag_id="churn_nightly_pipeline",
    description="Nightly churn pipeline: one idempotent task per step (delegates to the churn-platform CLI)",
    schedule="0 2 * * *",
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=1,
    default_args={"retries": 2, "retry_delay": timedelta(minutes=5)},
    tags=["churn"],
) as dag:
    migrate_check = BashOperator(task_id="database_in_sync", bash_command="churn-platform db-status")
    for tenant in TENANTS:
        previous = migrate_check
        for step in STEPS:
            task = BashOperator(
                task_id=f"{step}_{tenant.replace('-', '_')}",
                bash_command=COMMAND,
                params={"tenant": tenant, "step": step},
                execution_timeout=timedelta(hours=3),
            )
            previous >> task
            previous = task
